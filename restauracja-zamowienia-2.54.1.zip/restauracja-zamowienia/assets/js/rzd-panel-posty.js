/* Restauracja – Panel restauracji: sekcja „Post dnia” (2.48.0, moduł 38-posty). Zakładki: Nowy post (zestaw + dzień →
 * dania, zdjęcia, dopisek → Gemini → podgląd jak na Facebooku → zatwierdzenie: zaplanuj / opublikuj teraz), Plan tygodnia
 * (posty na najbliższe dni naraz), Historia, Ustawienia (Gemini, wskazówki, sekcje posta, Facebook, automat).
 * Tekst zawsze przez textContent / value. */
(function () {
	'use strict';
	var K = window.rzdPanelKit;
	if (!K) { return; }
	var h = K.h, S = K.S;
	var TABS = [['nowy', 'Nowy post'], ['tydzien', 'Plan tygodnia'], ['odlozone', 'Odłożone'], ['historia', 'Historia'], ['ustawienia', 'Ustawienia']];
	var MEDIA = { list: 'posts_media_list', upload: 'posts_media_upload' };
	var urlPost = parseInt(new URLSearchParams(location.search).get('post') || '0', 10) || 0;
	function copy(o) { return JSON.parse(JSON.stringify(o)); }
	function fail(b) { return function (e) { K.busy(b, false); K.toast(e.message, true); }; }
	function pad(n) { return ('0' + n).slice(-2); }
	function tsToLocal(ts) { var d = new Date(ts * 1000); return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + 'T' + pad(d.getHours()) + ':' + pad(d.getMinutes()); }
	function localToTs(v) { var d = new Date(v); return isNaN(d.getTime()) ? 0 : Math.round(d.getTime() / 1000); }
	function whenLabel(ts) { var d = new Date(ts * 1000); return ['niedz.', 'pon.', 'wt.', 'śr.', 'czw.', 'pt.', 'sob.'][d.getDay()] + ' ' + d.getDate() + '.' + pad(d.getMonth() + 1) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes()); }
	function badge(p, d) {
		var st = p ? p.status : '';
		var txt = !p ? 'brak posta' : (d.statuses[st] || st) + (st === 'scheduled' && p.when ? ' · ' + whenLabel(p.when) : '') + (p.parked && st === 'draft' ? ' · odłożony' : '');
		return h('span', { class: 'rp-pstat rp-pstat-' + (st || 'none'), text: txt });
	}
	function mainPost(list) { // najważniejszy post dnia: opublikowany > zaplanowany > szkic > błąd
		var order = { published: 0, scheduled: 1, draft: 2, error: 3 };
		return (list || []).slice().sort(function (a, b) { return (order[a.status] - order[b.status]) || (b.id - a.id); })[0] || null;
	}
	function reload() { S.data.posts = null; K.render(); }
	// (2.53.0) Pole „AI:” – jeden wybrany dostawca na jedno „Generuj”; nieskonfigurowani wyszarzeni.
	// Ostatni wybór pamięta przeglądarka (localStorage rzd_ai_posty) – tylko gdy dostawca nadal połączony.
	function aiPick(d) {
		var A = d.ai || { list: [], def: '' }, ok = A.list.filter(function (x) { return x.ready; });
		var mem = ''; try { mem = localStorage.getItem('rzd_ai_posty') || ''; } catch (e) { /* tryb prywatny */ }
		if (!S.aiPosts) { S.aiPosts = ok.some(function (x) { return x.k === mem; }) ? mem : A.def; }
		if (ok.length < 2) { return ok.length ? h('span', { class: 'rp-muted', text: 'AI: ' + ok[0].n }) : null; }
		var sel = h('select', { class: 'rp-in rp-in-m', 'aria-label': 'Dostawca AI', onchange: function () { S.aiPosts = sel.value; try { localStorage.setItem('rzd_ai_posty', sel.value); } catch (e) { /* tryb prywatny */ } } }, A.list.map(function (x) {
			return h('option', { value: x.k, text: x.n + (x.ready ? '' : ' (brak klucza)'), disabled: x.ready ? null : true, selected: x.k === S.aiPosts ? true : null });
		}));
		return h('label', { class: 'rp-check' }, [h('span', { class: 'rp-muted', text: 'AI:' }), sel]);
	}
	// (2.50.0) Format zdjęć posta i punkt kadru – podgląd = docięty plik (object-fit: cover + object-position fx% fy%,
	// ta sama zasada co rzd_posts_crop_rect() w PHP).
	function ratioKey(W, d) { return W.ratio || d.values.ratio || '4:5'; }
	function ratioVal(k, d) { var r = (d.ratios || []).filter(function (x) { return x.k === k; })[0]; return r ? +r.r : 0; }
	function focusPos(ph) { return Math.round((ph.fx == null ? 0.5 : +ph.fx) * 100) + '% ' + Math.round((ph.fy == null ? 0.5 : +ph.fy) * 100) + '%'; }
	function syncFocus(i, ph) { document.querySelectorAll('img[data-rp-ph="' + i + '"]').forEach(function (im) { im.style.objectPosition = focusPos(ph); }); }
	function photoBody(list) { return list.map(function (x) { var o = { id: x.id }; if (x.fx != null) { o.fx = x.fx; o.fy = x.fy; } return o; }); }
	// Miniatura w formacie posta; przeciąganie przesuwa kadr (Pointer Events – mysz i palec), dwuklik – środek.
	function cropThumb(ph, i, r, editable) {
		var img = h('img', { src: ph.url, alt: '', 'data-rp-ph': String(i), draggable: 'false' });
		img.style.objectPosition = focusPos(ph);
		var box = h('div', { class: 'rp-pphoto' + (editable && r ? ' rp-pphoto-drag' : ''), title: editable && r ? 'Przeciągnij, żeby ustawić kadr (dwuklik – środek)' : null }, [img]);
		if (r) { box.style.height = 'auto'; box.style.aspectRatio = String(r); }
		if (!editable || !r) { return box; }
		var st = null;
		box.addEventListener('pointerdown', function (e) {
			if (e.target.closest('button') || !img.naturalWidth) { return; }
			var bw = box.clientWidth, bh = box.clientHeight, sc = Math.max(bw / img.naturalWidth, bh / img.naturalHeight);
			st = { x: e.clientX, y: e.clientY, ox: img.naturalWidth * sc - bw, oy: img.naturalHeight * sc - bh, fx: ph.fx == null ? 0.5 : +ph.fx, fy: ph.fy == null ? 0.5 : +ph.fy };
			box.setPointerCapture(e.pointerId);
			e.preventDefault();
		});
		box.addEventListener('pointermove', function (e) {
			if (!st) { return; }
			function cl(v) { return Math.round(Math.max(0, Math.min(1, v)) * 1000) / 1000; }
			ph.fx = st.ox > 1 ? cl(st.fx - (e.clientX - st.x) / st.ox) : 0.5;
			ph.fy = st.oy > 1 ? cl(st.fy - (e.clientY - st.y) / st.oy) : 0.5;
			syncFocus(i, ph);
		});
		function end() { if (st) { st = null; K.dirty(); } }
		box.addEventListener('pointerup', end);
		box.addEventListener('pointercancel', end);
		box.addEventListener('dblclick', function () { ph.fx = 0.5; ph.fy = 0.5; syncFocus(i, ph); K.dirty(); });
		return box;
	}
	// Licznik na przycisku podczas pracy AI (modele potrafią odpowiadać kilkadziesiąt sekund) – widać, że coś się dzieje.
	function aiBusy(b, label) {
		var t0 = Date.now(), base = label || 'AI pisze';
		K.busy(b, true);
		b.dataset.txt = b.dataset.txt || b.textContent;
		b.textContent = base + '… 0 s';
		var iv = setInterval(function () {
			var s = Math.round((Date.now() - t0) / 1000);
			b.textContent = base + '… ' + s + ' s' + (s >= 45 ? ' (Gemini odpowiada długo)' : '');
		}, 1000);
		return function () { clearInterval(iv); if (b.dataset.txt) { b.textContent = b.dataset.txt; } K.busy(b, false); };
	}

	function secPosts(main) {
		var d = S.data.posts;
		if (!d) {
			K.loading(main, 'Post dnia');
			K.load('posts', 'posts').then(K.render).catch(function (e) { main.textContent = ''; K.failBox(main, e, K.render); });
			return;
		}
		var tab = TABS.some(function (t) { return t[0] === S.tab; }) ? S.tab : (urlPost ? 'nowy' : 'nowy');
		main.appendChild(K.pageHead('Post dnia', 'Posty na Facebooka – o zestawie dnia, o produkcie albo na dowolny temat: AI pisze tekst według Twoich wskazówek, Ty sprawdzasz i zatwierdzasz – Facebook publikuje o wybranej godzinie (zestaw: domyślnie dzień wcześniej o ' + d.pubTime + ').'));
		main.appendChild(K.tabsEl(TABS, tab));
		if (!d.ready && tab !== 'ustawienia') {
			main.appendChild(h('div', { class: 'rp-warn warn', role: 'note' }, [h('span', { text: 'Najpierw uzupełnij połączenia: ' + [!d.hasKey ? 'klucz Gemini' : '', !(d.api && d.api.model) ? 'model AI' : '', !d.hasToken ? 'token strony Facebooka' : '', !(d.api && d.api.fb_page) ? 'ID strony' : ''].filter(Boolean).join(', ') + '.' }), d.canApi ? K.btn('Połączenia API', function () { K.go('polaczenia'); }, 'rp-btn-link') : K.btn('Ustawienia', function () { K.setTab('ustawienia'); }, 'rp-btn-link')]));
		}
		if (tab === 'tydzien') { week(main, d); }
		else if (tab === 'historia') { history(main, d); }
		else if (tab === 'odlozone') { parked(main, d); }
		else if (tab === 'ustawienia') { settings(main, d); }
		else { editor(main, d); }
	}

	/* ============================================================
	 * NOWY POST
	 * ============================================================ */
	function editor(main, d) {
		var W = S.work.post;
		if (!W) {
			W = S.work.post = { kind: 'set', day: d.days[1] ? d.days[1].day : d.days[0].day, set: d.sets[0] ? d.sets[0].id : 0, product: 0, topic: '', extra: '', dd: null, post: null, photos: [], text: '', when: 0, place: +d.values.place_def, ratio: '', loading: false };
			if (S.postNew) { Object.assign(W, S.postNew); S.postNew = null; } // np. „Nowy post z tym zestawem” z Odłożonych
			var open = S.postOpen || urlPost;
			S.postOpen = 0; urlPost = 0;
			var found = open ? d.history.concat(d.parked || []).filter(function (p) { return p.id === open; })[0] : null;
			if (found) {
				W.post = found; W.kind = found.kind || 'set'; W.day = found.day || W.day; W.set = found.set || W.set; W.product = found.product || 0; W.topic = found.topic || '';
				W.photos = copy(found.photos); W.text = found.text; W.when = found.when; W.extra = found.extra || ''; W.place = +found.place; W.ratio = found.ratio || '';
				if (W.kind === 'topic') { W.dd = { kind: 'topic' }; }
			}
		}
		function reset(o) { // nowy, pusty post (zmiana rodzaju, dnia, zestawu, produktu)
			if (S.dirty && !window.confirm('Masz niezapisane zmiany w poście. Przejść mimo to?')) { K.render(); return; }
			S.dirty = false;
			S.work.post = Object.assign({ kind: W.kind, day: W.day, set: W.set, product: 0, topic: '', extra: '', dd: null, post: null, photos: [], text: '', when: 0, place: +d.values.place_def, ratio: W.ratio || '' }, o);
			if (S.work.post.kind === 'topic') { S.work.post.dd = { kind: 'topic' }; S.work.post.when = d.nextPub; }
			K.render();
		}

		// rodzaj posta
		var kinds = h('div', { class: 'rp-pkinds', role: 'radiogroup', 'aria-label': 'Rodzaj posta' }, Object.keys(d.kinds).map(function (k) {
			return h('button', { type: 'button', role: 'radio', 'aria-checked': W.kind === k ? 'true' : 'false', class: 'rp-pkind' + (W.kind === k ? ' on' : ''), text: d.kinds[k], onclick: function () { if (W.kind !== k) { reset({ kind: k }); } } });
		}));
		main.appendChild(h('section', { class: 'rp-card' }, [h('h2', { text: 'Rodzaj posta' }), kinds]));

		if (W.kind === 'set') {
			if (!d.sets.length) { main.appendChild(h('p', { class: 'rp-muted', text: 'Nie ma żadnego zestawu – post o zestawie powstaje z zestawu i jego dań na wybrany dzień.' })); return; }
			if (!W.dd && !W.loading) {
				W.loading = true;
				K.api('posts_day', { day: W.day, set: W.set }).then(function (x) {
					W.loading = false; W.dd = x;
					if (!W.post) {
						var ex = mainPost(x.posts);
						if (ex) { W.post = ex; W.photos = copy(ex.photos); W.text = ex.text; W.when = ex.when; W.extra = ex.extra || ''; W.place = +ex.place; }
						else { W.photos = copy(x.photos); W.when = x.when; }
					}
					K.render();
				}, function (e) { W.loading = false; K.toast(e.message, true); });
			}
			var card = h('section', { class: 'rp-card' }, [h('h2', { text: 'Zestaw i dzień' })]);
			var dayOpts = d.days.some(function (x) { return x.day === W.day; }) ? d.days : [{ day: W.day, label: W.day + ' (dzień minął)' }].concat(d.days); // odłożony post z minionym dniem
			var daySel = h('select', { class: 'rp-in', 'aria-label': 'Dzień', onchange: function () { reset({ day: daySel.value }); } }, dayOpts.map(function (x) { return h('option', { value: x.day, text: x.label, selected: x.day === W.day ? true : null }); }));
			var setSel = h('select', { class: 'rp-in', 'aria-label': 'Zestaw', onchange: function () { reset({ set: parseInt(setSel.value, 10) }); } }, d.sets.map(function (x) { return h('option', { value: String(x.id), text: x.name, selected: x.id === W.set ? true : null }); }));
			card.appendChild(h('div', { class: 'rp-row2' }, [K.field('Dzień obiadu (post publikujemy dzień wcześniej)', daySel), K.field('Zestaw', setSel)]));
			if (!W.dd) { card.appendChild(h('p', { class: 'rp-load', text: 'Wczytuję dania…' })); main.appendChild(card); return; }
			var dd = W.dd;
			if (W.day < d.today) { card.appendChild(h('p', { class: 'rp-fnote warn', text: '⚠ Ten dzień już minął – dania mogły się zmienić. Wybierz nowy dzień (powstanie nowy post), albo popraw tekst i zaplanuj.' })); }
			if (dd.missing && dd.missing.length) {
				card.appendChild(h('p', { class: 'rp-fnote warn', text: '⚠ Bez dania na ten dzień: ' + dd.missing.join(', ') + ' – uzupełnij w Zestawach (do AI idą tylko zaplanowane dania).' }));
			}
			if (!dd.dishes.length) {
				card.appendChild(h('p', { class: 'rp-fnote warn', text: 'Zestaw nie ma dań na ten dzień – uzupełnij harmonogram (Panel → Zestawy albo Edycja menu).' }));
				main.appendChild(card);
				return;
			}
			card.appendChild(h('ul', { class: 'rp-pdishes' }, dd.dishes.map(function (x) { return h('li', null, [h('strong', { text: x.name }), x.role ? h('span', { class: 'rp-muted', text: ' · ' + x.role }) : null]); })));
			var other = dd.posts.filter(function (p) { return !W.post || p.id !== W.post.id; });
			if (other.length) {
				card.appendChild(h('p', { class: 'rp-fnote' }, ['Na ten dzień są też inne posty: ', other.map(function (p) { return (d.statuses[p.status] || p.status) + ' #' + p.id; }).join(', '), ' – zobacz Historię.']));
			}
			main.appendChild(card);
		} else if (W.kind === 'product') {
			var pc = h('section', { class: 'rp-card' }, [h('h2', { text: 'Produkt' })]);
			var q = h('input', { type: 'search', class: 'rp-in', placeholder: 'Szukaj dania…', 'aria-label': 'Szukaj produktu', value: W.q || '', oninput: function () { W.q = q.value; fill(); } });
			var sel = h('select', { class: 'rp-in', 'aria-label': 'Produkt', onchange: function () { var id = parseInt(sel.value, 10) || 0; if (id !== W.product) { reset({ product: id, q: W.q }); } } });
			function fill() {
				var t = (W.q || '').toLowerCase();
				sel.textContent = '';
				sel.appendChild(h('option', { value: '0', text: '— wybierz produkt —' }));
				d.products.filter(function (x) { return !t || (x.name + ' ' + x.cat).toLowerCase().indexOf(t) > -1 || x.id === W.product; }).forEach(function (x) {
					sel.appendChild(h('option', { value: String(x.id), text: x.name + (x.cat ? ' · ' + x.cat : ''), selected: x.id === W.product ? true : null }));
				});
			}
			fill();
			pc.appendChild(h('div', { class: 'rp-row2' }, [K.field('Szukaj', q), K.field('Danie / produkt', sel)]));
			if (!W.product) { pc.appendChild(h('p', { class: 'rp-muted', text: 'Wybierz produkt – do AI pójdzie jego nazwa, kategoria i opis z karty, a jego zdjęcia podpowiedzą się do posta.' })); main.appendChild(pc); return; }
			if (!W.dd && !W.loading) {
				W.loading = true;
				K.api('posts_product', { product: W.product }).then(function (x) {
					W.loading = false; W.dd = x;
					if (!W.post) { W.photos = copy(x.photos); W.when = d.nextPub; }
					K.render();
				}, function (e) { W.loading = false; K.toast(e.message, true); });
			}
			if (!W.dd) { pc.appendChild(h('p', { class: 'rp-load', text: 'Wczytuję produkt…' })); main.appendChild(pc); return; }
			if (W.dd.desc) { pc.appendChild(h('p', { class: 'rp-muted', text: W.dd.desc.slice(0, 240) + (W.dd.desc.length > 240 ? '…' : '') })); }
			main.appendChild(pc);
		} else {
			var tc = h('section', { class: 'rp-card' }, [h('h2', { text: 'O czym post' })]);
			var locked0 = W.post && (W.post.status === 'scheduled' || W.post.status === 'published');
			var topic = h('textarea', { class: 'rp-in', rows: '4', maxlength: '1500', 'aria-label': 'Temat posta', readonly: locked0 ? true : null, placeholder: 'np. „Od poniedziałku dowozimy też do Ujścia”, „Catering na Wigilię – zapisy do 15 grudnia”, „Szukamy kucharza na zmianę poranną”', oninput: function () { W.topic = topic.value; } });
			topic.value = W.topic;
			tc.appendChild(K.field('Temat – AI napisze post według Twoich wskazówek i sekcji', topic));
			main.appendChild(tc);
		}

		// zdjęcia
		var phCard = h('section', { class: 'rp-card' }, [h('h2', { text: 'Zdjęcia do posta' }), h('p', { class: 'rp-muted', text: 'Idą do posta w tej kolejności (pierwsze – największe na Facebooku). ' + (W.kind === 'topic' ? 'Dodaj z biblioteki albo prosto z telefonu.' : 'Podpowiadamy zdjęcia ' + (W.kind === 'set' ? 'dań z zestawu.' : 'produktu.')) })]);
		var locked = W.post && (W.post.status === 'scheduled' || W.post.status === 'published');
		var rk = ratioKey(W, d), rv = ratioVal(rk, d);
		var rsel = h('select', { class: 'rp-in rp-in-m', 'aria-label': 'Format zdjęć', disabled: locked ? true : null, onchange: function () { W.ratio = rsel.value === d.values.ratio ? '' : rsel.value; K.dirty(); K.render(); } }, (d.ratios || []).map(function (x) { return h('option', { value: x.k, text: x.n + (x.k === d.values.ratio ? ' – domyślny' : ''), selected: x.k === rk ? true : null }); }));
		phCard.appendChild(h('div', { class: 'rp-inline' }, [h('span', { class: 'rp-muted', text: 'Format zdjęć:' }), rsel]));
		if (rv && !locked && W.photos.length) { phCard.appendChild(h('p', { class: 'rp-muted rp-psec-help', text: 'Tak zdjęcia pójdą na Facebooka (docięte, oryginał w bibliotece zostaje). Przeciągnij zdjęcie, żeby przesunąć kadr; dwuklik – środek.' })); }
		var grid = h('div', { class: 'rp-pphotos' });
		W.photos.forEach(function (ph, i) {
			var th = cropThumb(ph, i, rv, !locked);
			if (!locked) {
				th.appendChild(h('div', { class: 'rp-pphoto-act' }, [
					i ? h('button', { type: 'button', class: 'rp-ico', 'aria-label': 'Wcześniej', text: '←', onclick: function () { W.photos.splice(i - 1, 0, W.photos.splice(i, 1)[0]); K.dirty(); K.render(); } }) : null,
					h('button', { type: 'button', class: 'rp-ico', 'aria-label': 'Usuń zdjęcie', html: K.ICON.x, onclick: function () { W.photos.splice(i, 1); K.dirty(); K.render(); } })
				]));
			}
			grid.appendChild(th);
		});
		if (!locked && W.photos.length < 10) {
			grid.appendChild(h('button', { type: 'button', class: 'rp-pphoto rp-pphoto-add', text: '+ Dodaj zdjęcie', onclick: function () { K.pickImage(function (it) { W.photos.push({ id: it.id, url: it.url }); K.dirty(); K.render(); }, MEDIA); } }));
		}
		if (!W.photos.length && locked) { grid.appendChild(h('p', { class: 'rp-muted', text: 'Bez zdjęć.' })); }
		phCard.appendChild(grid);
		main.appendChild(phCard);

		// AI
		var aiCard = h('section', { class: 'rp-card' }, [h('h2', { text: 'Tekst (AI)' })]);
		var extra = h('textarea', { class: 'rp-in', rows: '2', maxlength: '500', placeholder: 'Opcjonalnie: np. „jutro ma padać”, „nowość w karcie”, „ostatni dzień przed świętami”', oninput: function () { W.extra = extra.value; } });
		extra.value = W.extra;
		aiCard.appendChild(K.field('Dopisek dla AI', extra));
		if (!locked) {
			aiCard.appendChild(h('div', { class: 'rp-inline' }, [aiPick(d), K.btn(W.post ? 'Wygeneruj ponownie' : 'Generuj post', function (e) {
				if (W.kind === 'topic' && !String(W.topic || '').trim()) { K.toast('Napisz, o czym ma być post.', true); return; }
				if (W.post && S.dirty && !window.confirm('Nowy tekst zastąpi Twoje poprawki. Generować?')) { return; }
				var b = e.currentTarget; var done = aiBusy(b);
				K.api('posts_generate', { ai: S.aiPosts || '', kind: W.kind, day: W.day, set: W.set, product: W.product, topic: W.topic, extra: W.extra, place: W.place ? 1 : 0, ratio: W.ratio || '', photos: photoBody(W.photos), post: W.post ? W.post.id : 0 }).then(function (x) {
					done(); W.post = x.post; W.text = x.post.text; W.photos = copy(x.post.photos); W.when = x.post.when; S.dirty = false; S.data.posts = null; K.toast(x.message); refreshKeep();
				}, function (er) { done(); K.toast(er.message, true); });
			}, 'rp-btn-pri')]));
		}
		main.appendChild(aiCard);
		if (W.post) { preview(main, d, W, locked); }
	}

	function refreshKeep() { // dane sekcji od nowa (Plan, Historia), edytor zostaje
		K.load('posts', 'posts').then(K.render, K.render);
	}

	function preview(main, d, W, locked) {
		var p = W.post;
		var box = h('section', { class: 'rp-card' }, [h('h2', { text: 'Podgląd i zatwierdzenie' }), badge(p, d)]);
		if (p.err) { box.appendChild(h('p', { class: 'rp-fnote warn', text: (p.status === 'draft' || p.status === 'error' ? 'Ostatni błąd: ' : 'Uwaga: ') + p.err })); }
		var ta = h('textarea', { class: 'rp-in rp-ptext', rows: '16', 'aria-label': 'Tekst posta', readonly: locked ? true : null, oninput: function () { W.text = ta.value; fbText.textContent = ta.value; K.dirty(); } });
		ta.value = W.text;
		var fbText = h('div', { class: 'rp-fb-text', text: W.text });
		var n = W.photos.length;
		var prv = ratioVal(ratioKey(W, d), d);
		var fbPh = h('div', { class: 'rp-fb-photos rp-fb-n' + Math.min(n, 5) }, W.photos.slice(0, 5).map(function (ph, i) {
			var im = h('img', { src: ph.url, alt: '', 'data-rp-ph': String(i) });
			im.style.objectPosition = focusPos(ph);
			var cell = h('div', { class: 'rp-fb-ph' }, [im, i === 4 && n > 5 ? h('span', { class: 'rp-fb-more', text: '+' + (n - 5) }) : null]);
			if (n === 1) { if (prv) { cell.style.aspectRatio = String(prv); } else { cell.classList.add('rp-fb-ph-orig'); } }
			return cell;
		}));
		var fb = h('div', { class: 'rp-fb', 'aria-label': 'Podgląd posta na Facebooku' }, [
			h('div', { class: 'rp-fb-head' }, [h('span', { class: 'rp-fb-av', text: 'f' }), h('div', null, [h('strong', { text: 'Twoja strona' }), h('small', { text: (p.when ? whenLabel(p.when) + ' · ' : '') + (W.place ? '📍 ' : '') + '🌍' })])]),
			fbText, n ? fbPh : null
		]);
		box.appendChild(h('div', { class: 'rp-pprev' }, [h('div', { class: 'rp-pprev-ed' }, [K.field('Tekst posta – możesz poprawić', ta, locked ? null : 'Sekcje oddzielone pustą linią, jak w ustawieniach.')]), fb]));
		if (locked) {
			var acts = [];
			if (p.fbUrl || p.fb) { acts.push(h('a', { class: 'rp-btn', href: p.fbUrl || ('https://www.facebook.com/' + p.fb), target: '_blank', rel: 'noopener', text: 'Zobacz na Facebooku ↗' })); }
			if (p.status === 'scheduled') {
				acts.push(K.btn('Cofnij planowanie', function (e) {
					if (!window.confirm('Usunąć zaplanowany post z Facebooka? Wróci do szkiców.')) { return; }
					var b = e.currentTarget; K.busy(b, true);
					K.api('posts_unschedule', { post: p.id }).then(function (x) { W.post = x.post; K.toast(x.message); S.data.posts = null; refreshKeep(); }, fail(b));
				}, 'rp-btn-link'));
			}
			box.appendChild(h('div', { class: 'rp-inline' }, acts));
			main.appendChild(box);
			return;
		}
		var when = h('input', { type: 'datetime-local', class: 'rp-in rp-in-m', value: W.when ? tsToLocal(W.when) : '', 'aria-label': 'Kiedy opublikować', onchange: function () { W.when = localToTs(when.value); } });
		if (S.postFocusWhen) { S.postFocusWhen = false; setTimeout(function () { when.scrollIntoView({ block: 'center' }); when.focus(); }, 60); } // „Zaplanuj” z Odłożonych
		box.appendChild(K.field('Publikacja na Facebooku', when, (W.kind === 'set' ? 'Domyślnie dzień wcześniej o ' : 'Domyślnie najbliższa ') + d.pubTime + '. Facebook planuje od 10 minut do 30 dni naprzód.'));
		var pl = h('input', { type: 'checkbox', checked: W.place ? true : null, onchange: function () { W.place = pl.checked ? 1 : 0; K.dirty(); } });
		box.appendChild(h('label', { class: 'rp-check' }, [pl, h('span', { text: '📍 Oznacz lokalizację' + (d.values.place ? ' (ID ' + d.values.place + ')' : ' (Wasza strona – musi mieć adres)') })]));
		function body() { return { post: p.id, text: W.text, place: W.place ? 1 : 0, ratio: W.ratio || '', photos: photoBody(W.photos) }; }
		box.appendChild(h('div', { class: 'rp-inline rp-pacts' }, [
			K.btn('✓ Zatwierdź i zaplanuj', function (e) {
				if (!W.when) { K.toast('Wybierz datę i godzinę publikacji.', true); return; }
				var b = e.currentTarget; K.busy(b, true);
				var q = body(); q.mode = 'schedule'; q.when = W.when;
				K.api('posts_publish', q).then(function (x) { W.post = x.post; S.dirty = false; K.toast(x.message); S.data.posts = null; refreshKeep(); }, fail(b));
			}, 'rp-btn-pri'),
			K.btn('Opublikuj teraz', function (e) {
				if (!window.confirm('Opublikować post na Facebooku teraz?')) { return; }
				var b = e.currentTarget; K.busy(b, true);
				var q = body(); q.mode = 'now';
				K.api('posts_publish', q).then(function (x) { W.post = x.post; S.dirty = false; K.toast(x.message); S.data.posts = null; refreshKeep(); }, fail(b));
			}),
			K.btn('Zapisz szkic', function (e) {
				var b = e.currentTarget; K.busy(b, true);
				K.api('posts_save', body()).then(function (x) { W.post = x.post; S.dirty = false; K.busy(b, false); K.toast(x.message); S.data.posts = null; refreshKeep(); }, fail(b));
			}),
			K.btn('Odłóż na potem', function (e) {
				var b = e.currentTarget; K.busy(b, true);
				K.api('posts_park', body()).then(function (x) { S.data.posts = x; S.dirty = false; K.toast(x.message); K.setTab('odlozone'); K.render(); }, fail(b));
			}),
			K.btn('Usuń szkic', function (e) {
				if (!window.confirm('Usunąć ten szkic?')) { return; }
				var b = e.currentTarget; K.busy(b, true);
				K.api('posts_delete', { post: p.id }).then(function (x) { S.data.posts = x; S.work.post = null; S.dirty = false; K.toast(x.message); K.render(); }, fail(b));
			}, 'rp-btn-link')
		]));
		main.appendChild(box);
	}

	/* ============================================================
	 * PLAN TYGODNIA
	 * ============================================================ */
	function week(main, d) {
		var card = h('section', { class: 'rp-card' }, [h('h2', { text: 'Najbliższe dni z zestawem' }), h('p', { class: 'rp-muted', text: 'Gdy w weekend ułożysz zestawy na cały tydzień: „Generuj brakujące”, przejrzyj posty (Otwórz), potem „Zatwierdź i zaplanuj szkice” – każdy wyjdzie dzień wcześniej o ' + d.pubTime + '. Dni bez posta automat przygotuje o ' + d.genTime + ' dzień wcześniej jako szkic do zatwierdzenia.' })]);
		if (!d.week.length) { card.appendChild(h('p', { class: 'rp-muted', text: 'W najbliższych 7 dniach żaden zestaw nie ma dań.' })); main.appendChild(card); return; }
		var list = h('div', { class: 'rp-pweek' });
		var missing = [], drafts = [];
		// (2.53.2) zestaw dnia: domyślnie „Zestaw do postów” z Ustawień (w.set), w wierszu można wybrać inny (S.weekPick – do przeładowania strony)
		if (!S.weekPick) { S.weekPick = {}; }
		d.week.forEach(function (w0) {
			var opts = w0.opts || [w0];
			var chosen = S.weekPick[w0.day] !== undefined ? S.weekPick[w0.day] : w0.set;
			var o = opts.filter(function (x) { return x.set === chosen; })[0] || null;
			var w = { day: w0.day, label: w0.label, when: w0.when, set: o ? o.set : 0, setName: o ? o.setName : '', dishes: o ? o.dishes : [], missing: o ? o.missing : [] };
			var mine = (w0.posts || []).filter(function (x) { return !o || !x.set || x.set === o.set; });
			var p = mainPost(mine);
			if (o && (!p || p.status === 'error')) { missing.push(w); }
			if (p && p.status === 'draft') { drafts.push({ w: w, p: p }); }
			var pick = null;
			if (opts.length > 1 || !o) {
				var sel = h('select', { class: 'rp-in rp-in-m', 'aria-label': 'Zestaw – ' + w.label, onchange: function () { S.weekPick[w.day] = parseInt(sel.value, 10) || 0; K.render(); } },
					(o ? [] : [h('option', { value: '0', text: '— zestaw do postów nie ma dań; wybierz inny —', selected: true })]).concat(opts.map(function (x) {
						return h('option', { value: String(x.set), text: x.setName, selected: o && x.set === o.set ? true : null });
					})));
				pick = h('label', { class: 'rp-inline', style: 'margin-top:4px' }, [h('span', { class: 'rp-muted', text: 'Zestaw:' }), sel]);
			}
			var edLink = d.edUrl && (o || opts[0]) ? h('a', { class: 'rp-btn', href: d.edUrl + (d.edUrl.indexOf('?') < 0 ? '?' : '&') + 'zestaw=' + (o ? o.set : opts[0].set) + '&dzien=' + w.day, text: 'Zmień dania' }) : null;
			list.appendChild(h('div', { class: 'rp-pweek-r' }, [
				h('div', null, [
					h('strong', { text: w.label }),
					o ? h('div', { class: 'rp-muted', text: w.setName + ': ' + w.dishes.join(', ') }) : h('div', { class: 'rp-muted', text: 'Zestaw do postów nie ma dań w tym dniu – automat nie przygotuje posta.' }),
					pick,
					w.missing && w.missing.length ? h('div', { class: 'rp-fnote warn', text: '⚠ bez dania: ' + w.missing.join(', ') }) : null
				]),
				badge(p && p.status !== 'error' ? p : null, d),
				h('div', { class: 'rp-inline' }, [
					edLink,
					p && p.status !== 'error' ? K.btn('Otwórz', function () { S.postOpen = p.id; K.setTab('nowy'); }) : (o ? K.btn('Generuj', function (e) { gen([w], e.currentTarget); }) : null)
				])
			]));
		});
		card.appendChild(list);
		function gen(items, b) {
			if (!d.ready) { K.toast('Najpierw uzupełnij ustawienia.', true); return; }
			K.busy(b, true);
			var i = 0;
			(function next() {
				if (i >= items.length) { K.busy(b, false); K.toast('Gotowe – przejrzyj szkice.'); reload(); return; }
				var w = items[i++];
				K.toast('AI pisze post na ' + w.label + ' (' + i + '/' + items.length + ')…');
				K.api('posts_generate', { ai: S.aiPosts || '', day: w.day, set: w.set, src: 'week' }).then(next, function (e) { K.busy(b, false); K.toast(w.label + ': ' + e.message, true); reload(); });
			})();
		}
		var acts = [];
		if (missing.length) { acts.push(aiPick(d)); acts.push(K.btn('Generuj brakujące (' + missing.length + ')', function (e) { gen(missing, e.currentTarget); }, 'rp-btn-pri')); }
		if (drafts.length) {
			acts.push(K.btn('Zatwierdź i zaplanuj szkice (' + drafts.length + ')', function (e) {
				if (!window.confirm('Zaplanować ' + drafts.length + ' szkic(e) na Facebooku – każdy dzień wcześniej o ' + d.pubTime + '? Najpierw przejrzyj je (Otwórz).')) { return; }
				var b = e.currentTarget; K.busy(b, true);
				var i = 0, okN = 0, errs = [];
				(function next() {
					if (i >= drafts.length) { K.busy(b, false); K.toast('Zaplanowano: ' + okN + (errs.length ? '. Błędy: ' + errs.join('; ') : '.'), !!errs.length); reload(); return; }
					var x = drafts[i++];
					K.api('posts_publish', { post: x.p.id, mode: 'schedule', when: x.p.when || x.w.when }).then(function () { okN++; next(); }, function (er) { errs.push(x.w.label + ': ' + er.message); next(); });
				})();
			}));
		}
		if (acts.length) { card.appendChild(h('div', { class: 'rp-inline' }, acts)); }
		main.appendChild(card);
	}

	/* ============================================================
	 * HISTORIA
	 * ============================================================ */
	function history(main, d) {
		var card = h('section', { class: 'rp-card' }, [h('h2', { text: 'Historia postów' })]);
		if (!d.history.length) { card.appendChild(h('p', { class: 'rp-muted', text: 'Jeszcze nie ma postów.' })); main.appendChild(card); return; }
		var src = { manual: 'ręcznie', week: 'plan tygodnia', auto: 'automat' };
		card.appendChild(h('div', { class: 'rp-phist' }, d.history.map(function (p) {
			return h('div', { class: 'rp-phist-r' }, [
				p.photos && p.photos[0] ? h('img', { src: p.photos[0].url, alt: '' }) : h('span', { class: 'rp-phist-noimg' }),
				h('div', { class: 'rp-phist-t' }, [
					h('div', null, [h('strong', { text: p.dayLabel || p.day }), ' ', badge(p, d)]),
					h('div', { class: 'rp-muted', text: (d.kinds[p.kind] || '') + ' · ' + (src[p.src] || p.src || '') + (p.by ? ' · ' + p.by : '') }),
					h('p', { class: 'rp-phist-x', text: (p.text || '').slice(0, 160) + ((p.text || '').length > 160 ? '…' : '') }),
					p.err ? h('p', { class: 'rp-fnote warn', text: p.err }) : null
				]),
				h('div', { class: 'rp-inline' }, [
					p.fbUrl ? h('a', { class: 'rp-btn', href: p.fbUrl, target: '_blank', rel: 'noopener', text: 'Facebook ↗' }) : null,
					p.status !== 'error' ? K.btn('Otwórz', function () { S.postOpen = p.id; K.setTab('nowy'); }) : null,
					p.text ? K.btn('Użyj ponownie', function (e) { reuse(e, p); }, 'rp-btn-link') : null
				])
			]);
		})));
		main.appendChild(card);
	}

	// (2.50.0) kopia posta jako nowy szkic → edytor
	function reuse(e, p) {
		var b = e.currentTarget; K.busy(b, true);
		K.api('posts_copy', { post: p.id }).then(function (x) { S.data.posts = x; S.postOpen = x.post.id; K.toast(x.message); if (S.tab === 'nowy') { S.work = {}; K.render(); } else { K.setTab('nowy'); } }, fail(b));
	}

	/* ============================================================
	 * ODŁOŻONE (2.50.0) – bank postów na potem
	 * ============================================================ */
	function parked(main, d) {
		var F = S.work.pk = S.work.pk || { kind: '', q: '' };
		var all = d.parked || [];
		var card = h('section', { class: 'rp-card' }, [h('h2', { text: 'Odłożone posty' }), h('p', { class: 'rp-muted', text: 'Posty odłożone na potem („Odłóż na potem” przy poście) – nic z nich nie idzie na Facebooka, dopóki ich nie zaplanujesz. „Użyj ponownie” robi kopię (np. post sezonowy co roku), oryginał zostaje tutaj. Facebook planuje do 30 dni naprzód.' })]);
		if (!all.length) { card.appendChild(h('p', { class: 'rp-muted', text: 'Nie ma odłożonych postów.' })); main.appendChild(card); return; }
		var q = h('input', { type: 'search', class: 'rp-in rp-in-m', placeholder: 'Szukaj w tekście…', 'aria-label': 'Szukaj w odłożonych', value: F.q, oninput: function () { F.q = q.value; fill(); } });
		var ks = h('select', { class: 'rp-in rp-in-m', 'aria-label': 'Rodzaj posta', onchange: function () { F.kind = ks.value; fill(); } }, [h('option', { value: '', text: 'Wszystkie rodzaje' })].concat(Object.keys(d.kinds).map(function (k) { return h('option', { value: k, text: d.kinds[k], selected: F.kind === k ? true : null }); })));
		card.appendChild(h('div', { class: 'rp-inline' }, [ks, q]));
		var list = h('div', { class: 'rp-phist' });
		card.appendChild(list);
		function fill() {
			var t = (F.q || '').toLowerCase();
			var rows = all.filter(function (p) { return (!F.kind || p.kind === F.kind) && (!t || ((p.text || '') + ' ' + (p.topic || '') + ' ' + (p.dayLabel || '')).toLowerCase().indexOf(t) > -1); });
			list.textContent = '';
			if (!rows.length) { list.appendChild(h('p', { class: 'rp-muted', text: 'Nic nie pasuje do filtra.' })); return; }
			rows.forEach(function (p) {
				var passed = p.kind === 'set' && p.day && p.day < d.today;
				var dt = new Date((p.modified || p.date) * 1000);
				list.appendChild(h('div', { class: 'rp-phist-r' }, [
					p.photos && p.photos[0] ? h('img', { src: p.photos[0].url, alt: '' }) : h('span', { class: 'rp-phist-noimg' }),
					h('div', { class: 'rp-phist-t' }, [
						h('div', null, [h('strong', { text: p.dayLabel || d.kinds[p.kind] || '' })]),
						h('div', { class: 'rp-muted', text: (d.kinds[p.kind] || '') + ' · odłożony ' + dt.getDate() + '.' + pad(dt.getMonth() + 1) + '.' + dt.getFullYear() + (p.by ? ' · ' + p.by : '') }),
						h('p', { class: 'rp-phist-x', text: (p.text || '').slice(0, 160) + ((p.text || '').length > 160 ? '…' : '') }),
						passed ? h('p', { class: 'rp-fnote warn', text: '⚠ Dzień minął – dania mogły się zmienić.' }) : null
					]),
					h('div', { class: 'rp-inline' }, [
						K.btn('Otwórz', function () { S.postOpen = p.id; K.setTab('nowy'); }),
						passed ? K.btn('Nowy post z tym zestawem', function () { S.postNew = { kind: 'set', set: p.set }; K.setTab('nowy'); }) : K.btn('Zaplanuj', function () { S.postOpen = p.id; S.postFocusWhen = true; K.setTab('nowy'); }),
						K.btn('Użyj ponownie', function (e) { reuse(e, p); }, 'rp-btn-link'),
						K.btn('Usuń', function (e) {
							if (!window.confirm('Usunąć odłożony post?')) { return; }
							var b = e.currentTarget; K.busy(b, true);
							K.api('posts_delete', { post: p.id }).then(function (x) { S.data.posts = x; K.toast(x.message); K.render(); }, fail(b));
						}, 'rp-btn-link')
					])
				]));
			});
		}
		fill();
		main.appendChild(card);
	}

	/* ============================================================
	 * USTAWIENIA
	 * ============================================================ */
	function settings(main, d) {
		if (!S.work.pset) { S.work.pset = copy(d.values); }
		var v = S.work.pset;
		function inp(k, attrs) {
			var a = Object.assign({ class: 'rp-in', value: v[k] == null ? '' : String(v[k]), oninput: function (e) { v[k] = e.target.value; K.dirty(); } }, attrs || {});
			return h('input', a);
		}
		// AI – połączenie w Połączeniach API (2.51.0)
		var g = h('section', { class: 'rp-card' }, [h('h2', { text: 'AI' })]);
		g.appendChild(h('div', { class: d.api && d.api.ai && d.api.fb ? 'rp-fnote' : 'rp-warn warn' }, [h('span', { text: 'AI: ' + (d.api && d.api.ai ? 'połączone (' + d.api.model + ')' : 'nie ustawione') + ' · Facebook: ' + (d.api && d.api.fb ? 'połączone (strona ' + d.api.fb_page + ')' : 'nie ustawione') + ' – klucz, model, token i test w Połączeniach API. ' }), d.canApi ? K.btn('Połączenia API', function () { K.go('polaczenia'); }, 'rp-btn-link') : null]));
		var ai = h('input', { type: 'checkbox', checked: +v.ai_images ? true : null, onchange: function () { v.ai_images = ai.checked ? 1 : 0; K.dirty(); } });
		g.appendChild(h('label', { class: 'rp-check' }, [ai, h('span', { text: 'AI widzi zdjęcia (wolniej i drożej; zwykle wystarczą nazwy i opisy dań)' })]));
		var instr = h('textarea', { class: 'rp-in', rows: '10', oninput: function () { v.instructions = instr.value; K.dirty(); } });
		instr.value = v.instructions;
		g.appendChild(K.field('Zasady wspólne (styl, zasady)', instr, 'Idą do AI przy KAŻDYM poście – zestaw, produkt i dowolny temat. Każda linia to jedna zasada. Co dotyczy tylko obiadu dnia, wpisz niżej w „O czym jest post” → Zestaw dnia.'));
		if (d.instrWarn) { g.appendChild(h('div', { class: 'rp-warn' }, [h('span', { text: d.instrWarn })])); }
		v.about = v.about || {};
		g.appendChild(h('h3', { text: 'O czym jest post' }));
		g.appendChild(h('p', { class: 'rp-muted', text: 'Do AI idzie tylko opis rodzaju, który tworzysz – dzięki temu post o rogalach nie dostaje poleceń o obiedzie dnia.' }));
		Object.keys(d.kinds).forEach(function (k) {
			var ta = h('textarea', { class: 'rp-in', rows: '2', 'aria-label': 'O czym jest post – ' + d.kinds[k], oninput: function () { v.about[k] = ta.value; K.dirty(); } });
			ta.value = v.about[k] || '';
			g.appendChild(K.field(d.kinds[k], ta));
		});
		main.appendChild(g);

		// Sekcje
		var sc = h('section', { class: 'rp-card' }, [h('h2', { text: 'Sekcje posta' }), h('p', { class: 'rp-muted', text: 'W tej kolejności. „Odstęp nad / pod” – puste linie między sekcjami; między dwiema sekcjami liczy się większa z wartości (np. pod Wstępem 1, nad Menu 2 → 2 puste linie), 0 – następna sekcja od nowej linii. „Pisze AI” – Gemini pisze sekcję; w polu pod spodem możesz dać mu wskazówki tylko do tej sekcji. „Stały tekst” – doklejany bez AI (możesz użyć {zestaw}, {dzien}, {dania}). Odznaczona sekcja nie idzie do AI i nie pojawia się w poście. „W postach” – w jakich rodzajach postów jest sekcja (np. Menu tylko w zestawie).' })]);
		v.sections.forEach(function (sec, i) {
			var name = h('input', { class: 'rp-in rp-in-m', value: sec.n, 'aria-label': 'Nazwa sekcji', oninput: function () { sec.n = name.value; K.dirty(); layout(); } });
			var mode = h('select', { class: 'rp-in rp-in-m', 'aria-label': 'Kto pisze', onchange: function () { sec.m = mode.value; K.dirty(); K.render(); } }, [h('option', { value: 'ai', text: 'Pisze AI', selected: sec.m === 'ai' ? true : null }), h('option', { value: 'static', text: 'Stały tekst', selected: sec.m === 'static' ? true : null })]);
			var on = h('input', { type: 'checkbox', 'aria-label': 'Sekcja ' + sec.n + ' aktywna', checked: +sec.on !== 0 ? true : null, onchange: function () { sec.on = on.checked ? 1 : 0; K.dirty(); row.classList.toggle('rp-psec-off', !on.checked); } });
			var row = h('div', { class: 'rp-psec' + (+sec.on === 0 ? ' rp-psec-off' : '') }, [
				h('div', { class: 'rp-inline' }, [h('strong', { text: (i + 1) + '.' }), h('label', { class: 'rp-check rp-psec-on', title: 'Aktywna' }, [on, h('span', { text: 'Aktywna' })]), name, mode,
					i ? h('button', { type: 'button', class: 'rp-ico', 'aria-label': 'Wyżej', text: '↑', onclick: function () { v.sections.splice(i - 1, 0, v.sections.splice(i, 1)[0]); K.dirty(); K.render(); } }) : null,
					h('button', { type: 'button', class: 'rp-ico', 'aria-label': 'Usuń sekcję ' + sec.n, html: K.ICON.x, onclick: function () { v.sections.splice(i, 1); K.dirty(); K.render(); } })])
			]);
			sec.ty = sec.ty || Object.keys(d.kinds);
			row.appendChild(h('div', { class: 'rp-inline rp-psec-ty' }, [h('span', { class: 'rp-muted', text: 'W postach:' })].concat(Object.keys(d.kinds).map(function (k) {
				var c = h('input', { type: 'checkbox', 'aria-label': sec.n + ' – ' + d.kinds[k], checked: sec.ty.indexOf(k) > -1 ? true : null, onchange: function () { sec.ty = Object.keys(d.kinds).filter(function (x) { return x === k ? c.checked : sec.ty.indexOf(x) > -1; }); K.dirty(); } });
				var lb = h('label', { class: 'rp-check' }, [c, h('span', { text: d.kinds[k] })]);
				c.addEventListener('change', layout);
				return lb;
			}))));
			function gapSel(key, label, def) {
				var cur = sec[key] == null ? def : +sec[key];
				var sel = h('select', { class: 'rp-in rp-in-s', 'aria-label': label + ' – ' + sec.n, onchange: function () { sec[key] = +sel.value; K.dirty(); layout(); } }, [0, 1, 2, 3].map(function (n) {
					return h('option', { value: String(n), text: n === 0 ? '0' : n + (n === 1 ? ' linia' : ' linie'), selected: n === cur ? true : null });
				}));
				return h('label', { class: 'rp-check' }, [h('span', { class: 'rp-muted', text: label + ':' }), sel]);
			}
			row.appendChild(h('div', { class: 'rp-inline rp-psec-ty' }, [gapSel('sb', 'Odstęp nad', 0), gapSel('sa', 'Odstęp pod', 1)]));
			on.addEventListener('change', layout);
			if (sec.m === 'static') {
				var t = h('textarea', { class: 'rp-in', rows: '3', 'aria-label': 'Tekst sekcji ' + sec.n, oninput: function () { sec.t = t.value; K.dirty(); } });
				t.value = sec.t || '';
				row.appendChild(t);
				row.appendChild(h('p', { class: 'rp-muted rp-psec-help', text: 'Stały tekst – trafia do posta dokładnie tak, jak go wpiszesz.' }));
			} else {
				var hn = h('textarea', { class: 'rp-in', rows: '2', 'aria-label': 'Wskazówki dla AI – ' + sec.n, placeholder: 'np. krótko, maks. 8 słów, z emotką', oninput: function () { sec.h = hn.value; K.dirty(); } });
				hn.value = sec.h || '';
				row.appendChild(hn);
				row.appendChild(h('p', { class: 'rp-muted rp-psec-help', text: 'Wskazówki dla AI tylko do tej sekcji. Puste – AI pisze samo według ogólnych wskazówek.' }));
			}
			sc.appendChild(row);
		});
		sc.appendChild(K.btn('+ Sekcja', function () { v.sections.push({ k: '', n: 'Nowa sekcja', m: 'ai', t: '', h: '', on: 1, ty: Object.keys(d.kinds), sb: 0, sa: 1 }); K.dirty(); K.render(); }, 'rp-btn-link'));
		// Układ posta – podgląd odstępów (nazwy sekcji zamiast treści), ta sama reguła co rzd_posts_assemble()
		var lk = h('select', { class: 'rp-in rp-in-m', 'aria-label': 'Rodzaj posta w podglądzie układu', onchange: layout }, Object.keys(d.kinds).map(function (k) { return h('option', { value: k, text: d.kinds[k] }); }));
		var lbox = h('div', { class: 'rp-fb-text rp-psec-layout', 'aria-label': 'Układ posta' });
		sc.appendChild(h('h3', { text: 'Układ posta' }));
		sc.appendChild(h('div', { class: 'rp-inline' }, [h('span', { class: 'rp-muted', text: 'Rodzaj:' }), lk]));
		sc.appendChild(lbox);
		function layout() {
			var out = '', prev = null;
			v.sections.forEach(function (x) {
				if (+x.on === 0 || (x.ty || []).indexOf(lk.value) < 0) { return; }
				if (prev) { var g = Math.max(prev.sa == null ? 1 : +prev.sa, x.sb == null ? 0 : +x.sb); out += '\n' + (g ? new Array(g + 1).join('\n') : ''); }
				out += '[' + x.n + ']';
				prev = x;
			});
			lbox.textContent = out;
		}
		layout();
		main.appendChild(sc);

		// Facebook
		var fb = h('section', { class: 'rp-card' }, [h('h2', { text: 'Facebook – publikacja' })]);
		fb.appendChild(K.field('Lokalizacja do oznaczania (ID strony)', inp('place', { inputmode: 'numeric', placeholder: 'puste = Wasza strona (musi mieć adres)' }), 'Post dostaje „📍 w miejscu …”. Puste – lokalizacją jest Wasza strona; wpisz ID innej strony-miejsca, jeśli adres jest gdzie indziej. Gdy Facebook nie przyjmie lokalizacji, post wyjdzie bez niej.'));
		var rdef = h('select', { class: 'rp-in rp-in-m', 'aria-label': 'Domyślny format zdjęć', onchange: function () { v.ratio = rdef.value; K.dirty(); } }, (d.ratios || []).map(function (x) { return h('option', { value: x.k, text: x.n, selected: x.k === v.ratio ? true : null }); }));
		fb.appendChild(K.field('Format zdjęć (domyślny)', rdef, 'Wtyczka docina zdjęcia do tego formatu przy publikacji (kopia JPEG, oryginał w bibliotece zostaje). 4:5 – najwyższy, jaki Facebook pokazuje w aktualnościach bez przycinania; przy kilku zdjęciach bezpieczny jest też 1:1. Przy poście można zmienić i przesunąć kadr.'));
		var pd = h('input', { type: 'checkbox', checked: +v.place_def ? true : null, onchange: function () { v.place_def = pd.checked ? 1 : 0; K.dirty(); } });
		fb.appendChild(h('label', { class: 'rp-check' }, [pd, h('span', { text: 'Nowe posty z lokalizacją (można odznaczyć przy poście)' })]));
		main.appendChild(fb);

		// Automat
		var au = h('section', { class: 'rp-card' }, [h('h2', { text: 'Godziny i automat' })]);
		au.appendChild(h('div', { class: 'rp-row2' }, [
			K.field('Szkic gotowy o', inp('gen_time', { type: 'time', class: 'rp-in rp-in-s' }), 'Automat przygotuje szkic na jutro, gdy go jeszcze nie ma.'),
			K.field('Publikacja o', inp('pub_time', { type: 'time', class: 'rp-in rp-in-s' }), 'Domyślna godzina publikacji (dzień przed obiadem). Zawsze po zatwierdzeniu.')
		]));
		var auto = h('input', { type: 'checkbox', checked: +v.auto ? true : null, onchange: function () { v.auto = auto.checked ? 1 : 0; K.dirty(); } });
		au.appendChild(h('label', { class: 'rp-check' }, [auto, h('span', { text: 'Automat: codziennie o godzinie szkicu przygotuj post na jutro (gdy go nie ma) i wyślij mail „zatwierdź”' })]));
		var AL = (d.ai && d.ai.list) || [];
		var asel = h('select', { class: 'rp-in rp-in-m', 'aria-label': 'AI dla automatu', onchange: function () { v.auto_ai = asel.value; K.dirty(); } }, [h('option', { value: '', text: 'Domyślny z Połączeń API', selected: !v.auto_ai ? true : null })].concat(AL.map(function (x) {
			return h('option', { value: x.k, text: x.n + (x.ready ? '' : ' (brak klucza)'), disabled: x.ready ? null : true, selected: x.k === v.auto_ai ? true : null });
		})));
		var SL = d.sets || [];
		var wsel = h('select', { class: 'rp-in rp-in-m', 'aria-label': 'Zestaw do postów', onchange: function () { v.week_set = parseInt(wsel.value, 10) || 0; K.dirty(); } }, [h('option', { value: '0', text: 'Pierwszy zestaw z daniami (jak dotąd)', selected: !+v.week_set ? true : null })].concat(SL.map(function (x) {
			return h('option', { value: String(x.id), text: x.name, selected: x.id === +v.week_set ? true : null });
		})));
		au.appendChild(K.field('Zestaw do postów', wsel, 'O tym zestawie są posty w Planie tygodnia i szkice automatu. Dzień, w którym ten zestaw nie ma dań, automat pomija; w Planie tygodnia możesz wtedy wybrać inny zestaw.'));
		au.appendChild(K.field('AI dla automatu', asel, 'Automat o ' + (v.gen_time || '19:00') + ' sam pisze szkic – tym dostawcą (jeden szkic = jedno zapytanie). Gdy wybrany przestanie być połączony – użyje domyślnego.'));
		au.appendChild(K.field('Mail o szkicu do', inp('mail_to', { type: 'text', placeholder: 'puste = e-mail administratora; kilka – po przecinku' })));
		main.appendChild(au);

		main.appendChild(K.saveBar(function (b) {
			K.busy(b, true);
			K.api('posts_settings_save', { values: v }).then(function (x) { S.data.posts = x; S.work.pset = null; S.dirty = false; K.toast(x.message); K.render(); }, fail(b));
		}, 'Zapisz ustawienia postów'));
	}

	K.sections.posty = secPosts;
})();
