<?php
/**
 * Plugin Name:       Restauracja – Zamówienia i Dostawy
 * Description:       System zamówień restauracji na WooCommerce: lista produktów z alergenami, zestawy, kalendarz terminów dostawy, koszyk, dodatki do produktów, raporty.
 * Version:           2.49.0
 * Requires Plugins:  woocommerce
 * Text Domain:       rzd
 *
 * Moduły (includes/, ładowane w tej kolejności; duże moduły to katalogi – pliki 01-…, 02-… po kolei):
 *  00 Wspólne funkcje pomocnicze, menu „Restauracja” w panelu (00-menu)
 *  01 Alergeny                                         14 Dodatki (katalog)
 *  02 Lista zamówień [lista_zamowien]                  15 Wygląd listy
 *  03 Style listy                                      16 Aktualizacje (GitHub → WordPress)
 *  04 Zestaw dnia                                      17 Kategorie [kategorie_zamowien]
 *  05 Zestawy na liście                                18 Wzory modyfikacji
 *  06 Kalendarz terminów dostawy [wybierz_date_dostawy]  19 Kurier [kurier_dashboard]
 *  07 Koszyk                                           20 Dostawa wg miejscowości [koszty_dostawy]
 *  08 Brama dodawania do koszyka                       21 Opakowania
 *  09 Raporty                                          22 Edycja menu [edycja_produktow]
 *  10 Modyfikacje produktu                             23 Dashboard sprzedaży
 *  11 Zestawy dnia – menu                              24 Opisy produktów (edytor sekcji)
 *  12 Kuchnia [kuchnia_dashboard]                      25 Dostęp i uprawnienia (role, logowanie obsługi)
 *  13 Statusy zamówień                                 26 Konfigurator uprawnień
 *                                                      27 Poczta (SMTP), 28 Stan wtyczki (samotest, błędy)
 *                                                      29 Formularz zamówienia (kasa: wygląd, zgody, przycisk)
 *                                                      30 Formularze kontaktowe, 31 Menu strony, 32 Dosprzedaż
 *                                                      33 Sala, 34 Panel restauracji, 35 SEO
 *                                                      36 Odbiór osobisty, 37 Zamówienia telefoniczne, 38 Post dnia (Facebook)
 *                                                      99 Dawne nazwy funkcji (zgodność wstecz)
 *
 * Wszystkie funkcje mają przedrostek rzd_.
 *
 * Dane (meta, opcje, taksonomie, typy treści, shortcody, role) mają stałe nazwy –
 * to adresy danych żywych sklepów; zmieniać tylko z migracją.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'RZD_PLUGIN_FILE', __FILE__ );
define( 'RZD_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'RZD_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
// Wersja wtyczki – MUSI być równa „Version:” w nagłówku (pilnuje tego pakowanie).
// Stała zamiast get_file_data() – bez czytania tego pliku przy każdym wyświetleniu strony.
define( 'RZD_PLUGIN_VERSION', '2.49.0' );

// Wersja pliku z katalogu wtyczki do ?ver= (wersja + data zmiany pliku).
function rzd_asset_ver( $rel ) {
	return RZD_PLUGIN_VERSION . '.' . (int) @filemtime( RZD_PLUGIN_DIR . $rel ); // phpcs:ignore
}

/**
 * Zgodność z funkcjami WooCommerce (Ustawienia → Zaawansowane → Funkcje).
 * HPOS (nowy zapis zamówień) – zgodna: wtyczka korzysta z API zamówień, testy na HPOS.
 * Kasa blokowa – świadomie „niezgodna”, dopóki nie obsługujemy jej w pełni (PLAN B6):
 * WooCommerce ostrzeże w edytorze kasy zamiast po cichu przepuszczać np. minimum zamówienia.
 */
add_action( 'before_woocommerce_init', function () {
	if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', RZD_PLUGIN_FILE, true );
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', RZD_PLUGIN_FILE, false );
	}
} );

/**
 * Błąd krytyczny w pliku wtyczki → zapis (moduł 28 pokazuje go w panelu i wysyła mail).
 * Dwie drogi: filtr ekranu błędu WordPressa (jego obsługa kończy działanie, więc późniejsze
 * funkcje zamknięcia by się nie wykonały) oraz zwykła funkcja zamknięcia, gdy obsługa
 * WordPressa jest wyłączona (WP_DISABLE_FATAL_ERROR_HANDLER).
 */
function rzd_record_fatal( $error ) {
	static $done = false;
	if ( $done || ! is_array( $error ) || empty( $error['file'] ) ) {
		return;
	}
	if ( ! in_array( (int) $error['type'], array( E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR, E_RECOVERABLE_ERROR ), true ) ) {
		return;
	}
	$file = str_replace( '\\', '/', (string) $error['file'] );
	$dir  = str_replace( '\\', '/', RZD_PLUGIN_DIR );
	if ( 0 !== strpos( $file, $dir ) ) {
		return; // błąd nie w naszym pliku
	}
	$done = true;
	$full = (string) $error['message'];
	$msg  = preg_split( '/\s+Stack trace:/', $full )[0]; // panel i mail: pierwsza linia; całość w dzienniku
	$msg  = str_replace( array( $dir, str_replace( '\\', '/', ABSPATH ) ), '', str_replace( '\\', '/', $msg ) );
	$rec  = array(
		'time' => time(),
		'msg'  => substr( $msg, 0, 300 ),
		'file' => substr( $file, strlen( $dir ) ),
		'line' => (int) $error['line'],
		'url'  => isset( $_SERVER['REQUEST_URI'] ) ? substr( (string) $_SERVER['REQUEST_URI'], 0, 300 ) : '', // phpcs:ignore
	);
	if ( function_exists( 'update_option' ) ) {
		update_option( 'rzd_health_fatal', $rec, false );
	}
	if ( function_exists( 'rzd_log' ) ) {
		rzd_log( 'critical', 'Błąd krytyczny: ' . $full . ' (' . $rec['file'] . ':' . $rec['line'] . ', adres ' . $rec['url'] . ')' );
	}
}
add_filter( 'wp_php_error_args', function ( $args, $error ) {
	rzd_record_fatal( $error );
	return $args;
}, 10, 2 );
register_shutdown_function( function () {
	rzd_record_fatal( error_get_last() );
} );

/**
 * Arkusz stylów / skrypt z assets/ wstawiany W MIEJSCU dawnego <style> / <script>.
 * To samo miejsce w kodzie strony = ta sama kolejność reguł CSS i wykonania skryptów
 * (przeglądarka zapamiętuje plik, kod strony jest lżejszy).
 */
function rzd_css_tag( $rel, $id = '' ) {
	return '<link rel="stylesheet"' . ( $id ? ' id="' . esc_attr( $id ) . '"' : '' ) . ' href="' . esc_url( RZD_PLUGIN_URL . $rel . '?ver=' . rzd_asset_ver( $rel ) ) . '">';
}
function rzd_js_tag( $rel ) {
	return '<script src="' . esc_url( RZD_PLUGIN_URL . $rel . '?ver=' . rzd_asset_ver( $rel ) ) . '"></script>';
}

/**
 * WYDAJNOŚĆ: ustawienia czytane na KAŻDEJ stronie sklepu były zapisane
 * z autoload = nie – każde get_option() takiej opcji to osobne zapytanie SQL
 * przy każdym wyświetleniu strony (bez Redisa/Memcached). Raz przełączamy je
 * na autoload (WordPress wczytuje je wtedy jednym zapytaniem razem z resztą).
 */
add_action( 'init', function () {
	if ( '2' === get_option( 'rzd_perf_autoload' ) ) {
		return;
	}
	$names = array( 'dc_settings', 'rzd_list_style', 'rzd_towns', 'rzd_style_migrated_2131', 'kc_settings', 'rzd_style_css_file' );
	if ( function_exists( 'wp_set_option_autoload_values' ) ) {
		wp_set_option_autoload_values( array_fill_keys( $names, true ) );
	} else {
		foreach ( $names as $n ) {
			$v = get_option( $n, null );
			if ( null !== $v ) {
				delete_option( $n );
				add_option( $n, $v, '', 'yes' );
			}
		}
	}
	update_option( 'rzd_perf_autoload', '2', true );
}, 1 );

/**
 * WooCommerce musi być aktywny – reszta wtyczki zakłada jego obecność
 * (klasy WC_Product, WC_Order, funkcje wc_get_product() itd.).
 */
function rzd_woocommerce_missing_notice() {
	echo '<div class="notice notice-error"><p><strong>Restauracja – Zamówienia i Dostawy:</strong> ta wtyczka wymaga aktywnej wtyczki WooCommerce.</p></div>';
}

add_action( 'plugins_loaded', function () {
	if ( ! class_exists( 'WooCommerce' ) ) {
		add_action( 'admin_notices', 'rzd_woocommerce_missing_notice' );
		return;
	}

	$modules = array(
		'includes/00-wspolne.php',
		'includes/00-menu.php',
		'includes/01-alergeny.php',
		'includes/02-lista-zamowien.php',
		'includes/03-style-listy.php',
		'includes/04-zestaw-dnia',
		'includes/05-zestaw-dla-listy.php',
		'includes/06-kalendarz',
		'includes/07-koszyk.php',
		'includes/08-brama-dodawania.php',
		'includes/09-raporty.php',
		'includes/10-modyfikacje',
		'includes/11-zestawy-menu.php',
		'includes/12-kuchnia',
		'includes/13-statusy.php',
		'includes/14-dodatki.php',
		'includes/15-wyglad-listy',
		'includes/16-aktualizacje.php',
		'includes/17-kategorie.php',
		'includes/18-wzory-modyfikacji.php',
		'includes/19-kurier.php',
		'includes/20-miejscowosci.php',
		'includes/21-opakowania.php',
		'includes/22-edycja-menu',
		'includes/23-dashboard.php',
		'includes/24-opisy.php',
		'includes/25-dostep.php',
		'includes/26-uprawnienia.php',
		'includes/27-poczta',
		'includes/28-stan.php',
		'includes/29-formularz-zamowienia.php',
		'includes/30-kontakt',
		'includes/31-menu-strony',
		'includes/32-dosprzedaz',
		'includes/33-sala',
		'includes/34-panel',
		'includes/35-seo',
		'includes/36-odbior',
		'includes/37-telefon',
		'includes/38-posty',
		'includes/99-stare-nazwy.php',
	);

	// Moduł = plik albo katalog (duże moduły): pliki katalogu wczytywane po kolei wg nazwy (01-…, 02-…).
	foreach ( $modules as $relative_path ) {
		$path = RZD_PLUGIN_DIR . $relative_path;
		if ( is_dir( $path ) ) {
			$parts = glob( $path . '/*.php' );
			sort( $parts );
			foreach ( $parts as $part ) {
				require_once $part;
			}
		} elseif ( file_exists( $path ) ) {
			require_once $path;
		}
	}
}, 20 ); // po WooCommerce (plugins_loaded priorytet 10), przed większością motywów
