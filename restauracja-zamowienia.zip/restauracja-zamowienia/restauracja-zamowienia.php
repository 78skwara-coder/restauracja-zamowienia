<?php
/**
 * Plugin Name:       Restauracja – Zamówienia i Dostawy
 * Description:       System zamówień restauracji na WooCommerce: lista produktów z alergenami, zestawy dnia, kalendarz terminów dostawy, koszyk, dodatki do produktów, raporty.
 * Version:           2.26.22
 * Requires Plugins:  woocommerce
 * Text Domain:       rzd
 *
 * ZAWARTOŚĆ (moduły w includes/, w tej kolejności ładowania):
 *  01 – Alergeny (taksonomia + piktogramy)
 *  02 – Lista zamówień (shortcode [lista_zamowien])
 *  03 – Style listy (CSS)
 *  04 – Zestaw dnia (terminy, dania, dodatki w harmonogramie zestawu, kategoria "nie wyświetlaj w sklepie")
 *  05 – Połączenie zestawów z listą
 *  06 – DeliveryCalendar (terminy dostawy, shortcode [wybierz_date_dostawy])
 *  07 – Koszyk (konfigurator, koszyk mobilny, okienko po dodaniu, pusty koszyk)
 *  08 – Brama dodawania do koszyka (kroki: termin dostawy, dodatki)
 *  09 – Raporty (CSV)
 *  10 – Możliwe modyfikacje produktu (konfigurator + panel wyboru + wycena)
 *  11 – Zestawy dnia – szybki dostęp do konfiguracji z głównego menu
 *  12 – Kuchnia – dashboard (Zamówienia/Kuchnia/Pakowanie/Planowanie/Historia),
 *       dostępny też na froncie przez shortcode [kuchnia_dashboard] z bramką PIN
 *  13 – Własne statusy zamówień (Przyjęte/W przygotowaniu/Przygotowane/Spakowane/Dostarczone) –
 *       zarządzane w WooCommerce jak zwykle, albo "odklikiwane" w module 12
 *  14 – Dodatki – globalny katalog dodatków (nazwa/cena/ikonka/obowiązkowy),
 *       do którego odwołują się modyfikacje z modułu 10
 *  15 – Wygląd listy – panel do samodzielnego dostosowania czcionek, kolorów,
 *       rozmiaru zdjęcia, przycisku i plakietek alergenów na liście
 *  16 – Aktualizacje – podpięcie pod natywny mechanizm aktualizacji WordPressa
 *       (Wtyczki → Aktualizuj teraz), zamiast ręcznego usuwania/wgrywania
 *  17 – Kategorie – shortcode [kategorie_zamowien]: kafle kategorii (przyciski
 *       na mobile, zdjęcie+podpis na desktop), każda z własnym adresem URL
 *  18 – Wzory modyfikacji – predefiniowane grupy modyfikacji (menu Dodatki),
 *       wstawiane na produkt przyciskiem "Dodaj z predefiniowanych" (kopia)
 *  19 – Kurier – osobny widok z osobnym PIN-em, shortcode [kurier_dashboard]
 *  20 – Dostawa wg miejscowości – matryca (koszt, darmowa od, minimum, dni,
 *       godziny), metoda wysyłki, miejscowość w oknie terminu, [koszty_dostawy]
 *  21 – Opakowania – katalog (cena), przypięcie do kategorii i produktu
 *       (z pojemnością), opłaty w koszyku, opakowania w Kuchni/Pakowaniu/raportach
 *
 * WAŻNE PRZED AKTYWACJĄ:
 * Jeśli masz te funkcje wklejone jako snippety w Code Snippets (lub w
 * functions.php), WYŁĄCZ je przed aktywacją tej wtyczki – inaczej te same
 * funkcje/klasy zostaną zadeklarowane dwa razy i WordPress zgłosi błąd
 * krytyczny (fatal error: cannot redeclare...).
 *
 * Cała dotychczasowa konfiguracja (alergeny, zestawy, kalendarz, ustawienia
 * koszyka) jest zapisana w standardowych tabelach WordPressa (wp_postmeta,
 * wp_options, wp_termmeta) pod tymi samymi nazwami, których używa ta
 * wtyczka – po aktywacji nic nie trzeba przenosić ręcznie.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'RZD_PLUGIN_FILE', __FILE__ );
define( 'RZD_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'RZD_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
// Wersja wtyczki – MUSI być równa „Version:” w nagłówku (pilnuje tego pakowanie).
// 2.26.13: stała zamiast get_file_data() – bez czytania tego pliku z dysku
// przy każdym wyświetleniu strony.
define( 'RZD_PLUGIN_VERSION', '2.26.22' );

// Wersja pliku z katalogu wtyczki do ?ver= (wersja + data zmiany pliku).
function rzd_asset_ver( $rel ) {
	return RZD_PLUGIN_VERSION . '.' . (int) @filemtime( RZD_PLUGIN_DIR . $rel ); // phpcs:ignore
}

/**
 * 2.26.13 WYDAJNOŚĆ: ustawienia czytane na KAŻDEJ stronie sklepu były zapisane
 * z autoload = nie – każde get_option() takiej opcji to osobne zapytanie SQL
 * przy każdym wyświetleniu strony (bez Redisa/Memcached). Raz przełączamy je
 * na autoload (WordPress wczytuje je wtedy jednym zapytaniem razem z resztą).
 */
add_action( 'init', function () {
	if ( '2' === get_option( 'rzd_perf_autoload' ) ) {
		return;
	}
	$names = array( 'dc_settings', 'rzd_list_style', 'rzd_towns', 'rzd_style_migrated_2131', 'kc_settings', 'rzd_style_css_file' );
	if ( function_exists( 'wp_set_option_autoload_values' ) ) {
		wp_set_option_autoload_values( array_fill_keys( $names, true ) );
	} else {
		foreach ( $names as $n ) {
			$v = get_option( $n, null );
			if ( null !== $v ) {
				delete_option( $n );
				add_option( $n, $v, '', 'yes' );
			}
		}
	}
	update_option( 'rzd_perf_autoload', '2', true );
}, 1 );

/**
 * WooCommerce musi być aktywny – reszta wtyczki zakłada jego obecność
 * (klasy WC_Product, WC_Order, funkcje wc_get_product() itd.).
 */
function rzd_woocommerce_missing_notice() {
	echo '<div class="notice notice-error"><p><strong>Restauracja – Zamówienia i Dostawy:</strong> ta wtyczka wymaga aktywnej wtyczki WooCommerce.</p></div>';
}

add_action( 'plugins_loaded', function () {
	if ( ! class_exists( 'WooCommerce' ) ) {
		add_action( 'admin_notices', 'rzd_woocommerce_missing_notice' );
		return;
	}

	$modules = array(
		'includes/01-alergeny.php',
		'includes/02-lista-zamowien.php',
		'includes/03-style-listy.php',
		'includes/04-zestaw-dnia.php',
		'includes/05-zestaw-dla-listy.php',
		'includes/06-delivery-calendar.php',
		'includes/07-koszyk.php',
		'includes/08-brama-dodawania.php',
		'includes/09-raporty.php',
		'includes/10-modyfikacje.php',
		'includes/11-zestawy-menu.php',
		'includes/12-kuchnia.php',
		'includes/13-statusy.php',
		'includes/14-dodatki.php',
		'includes/15-wyglad-listy.php',
		'includes/16-aktualizacje.php',
		'includes/17-kategorie.php',
		'includes/18-wzory-modyfikacji.php',
		'includes/19-kurier.php',
		'includes/20-miejscowosci.php',
		'includes/21-opakowania.php',
	);

	foreach ( $modules as $relative_path ) {
		$path = RZD_PLUGIN_DIR . $relative_path;
		if ( file_exists( $path ) ) {
			require_once $path;
		}
	}
}, 20 ); // po WooCommerce (plugins_loaded priorytet 10), przed większością motywów
