/* Restauracja – Panel restauracji: sekcja Formularze (2.45.0) – formularze kontaktowe (moduł 30).
 * Lista (shortcode do skopiowania), kreator: pola (dodawanie, kolejność, opcje list), wygląd (styl, kolory,
 * zaokrąglenie, odstępy, etykiety, własny CSS), maile (adresaci, treść ze znacznikami, „Odpowiedz” do,
 * potwierdzenie dla klienta), po wysłaniu i RODO; podgląd NA ŻYWO obok (telefon / szeroko).
 * Pod listą: wspólny CSS; ochrona przed spamem i przechowywanie – tylko Administrator. */
(function () {
	'use strict';
	var K = window.rzdPanelKit;
	if (!K) { return; }
	var h = K.h, S = K.S;
	var OPT_TYPES = ['select', 'radio', 'checkbox'];
	function copy(o) { return JSON.parse(JSON.stringify(o)); }

	function copyText(t) {
		if (navigator.clipboard && navigator.clipboard.writeText) {
			navigator.clipboard.writeText(t).then(function () { K.toast('Skopiowano: ' + t); }, function () { K.toast('Zaznacz i skopiuj ręcznie: ' + t); });
		} else { K.toast('Zaznacz i skopiuj ręcznie: ' + t); }
	}
	function scBox(sc) {
		var inp = h('input', { type: 'text', class: 'rp-in rp-sc', value: sc, readonly: true, 'aria-label': 'Shortcode', onfocus: function () { inp.select(); } });
		return h('div', { class: 'rp-inline rp-scbox' }, [inp, K.btn('Kopiuj', function () { copyText(sc); })]);
	}

	/* ============================================================
	 * LISTA
	 * ============================================================ */
	function secForms(main) {
		var d = S.data.forms;
		if (!d) {
			K.loading(main, 'Formularze');
			K.load('forms', 'forms').then(function () {
				var want = new URLSearchParams(location.search).get('form');
				if (want && S.data.forms.forms.some(function (f) { return f.id === want; }) && !S.work.formsOpened) { S.work.formsOpened = 1; openForm(want); return; }
				K.render();
			}).catch(function (e) { main.textContent = ''; K.failBox(main, e, K.render); });
			return;
		}
		if (S.work.form) { editor(main); return; }
		main.appendChild(K.pageHead('Formularze', 'Formularz kontaktowy wstawiasz na dowolnej stronie shortcodem (krótkim kodem w nawiasach kwadratowych) – w edytorze strony blok „Kod skrócony” albo zwykły tekst. Styl zmienisz też w kodzie: [rzd_kontakt id="kontakt" styl="karta"]. Wiadomości trafiają mailem i do sekcji Wiadomości.', K.btn('+ Nowy formularz', newForm, 'rp-btn-pri')));
		var l = h('div', { class: 'rp-list' });
		if (!d.forms.length) { l.appendChild(h('p', { class: 'rp-empty-s', text: 'Nie ma formularzy – dodaj pierwszy.' })); }
		d.forms.forEach(function (f) {
			l.appendChild(h('div', { class: 'rp-row rp-frow' }, [
				h('button', { type: 'button', class: 'rp-row-main rp-frow-b', onclick: function () { openForm(f.id); } }, [h('strong', { text: f.title }), h('small', { text: 'Styl: ' + f.style + ' · pól: ' + f.fields + ' · wiadomości: ' + f.msgs })]),
				scBox(f.sc)
			]));
		});
		main.appendChild(l);
		cssCard(main, d);
		if (d.admin && d.protect) { protectCard(main, d.protect); }
	}

	function newForm() {
		var opts = [['blank', 'Pusty', 'imię, e-mail, wiadomość'], ['starter_kontakt', 'Wzór „Kontakt”', 'imię, e-mail, telefon, temat, wiadomość'], ['starter_catering', 'Wzór „Zapytanie o catering / imprezę”', 'rodzaj, data, liczba osób, miejsce, budżet…']];
		(S.data.forms.forms || []).forEach(function (f) { opts.push([f.id, 'Kopia: ' + f.title, 'te same pola i ustawienia']); });
		var sel = 'blank';
		var body = h('div', { class: 'rp-radios rp-radios-b' }, opts.map(function (o) {
			return h('label', { class: 'rp-radio rp-radio-b' }, [h('input', { type: 'radio', name: 'rp-kfnew', value: o[0], checked: o[0] === 'blank', onchange: function () { sel = o[0]; } }), h('span', null, [h('strong', { text: o[1] }), h('small', { text: o[2] })])]);
		}));
		K.openSheet('Nowy formularz', body, [K.btn('Utwórz', function (e) {
			K.busy(e.currentTarget, true);
			K.api('form_new', { from: sel }).then(function (x) { S.data.forms = x; K.closeSheet(); K.toast(x.message); openForm(x.id); }, function (er) { K.busy(e.currentTarget, false); K.toast(er.message, true); });
		}, 'rp-btn-pri')]);
	}

	function cssCard(main, d) {
		var ta = h('textarea', { class: 'rp-in rp-code', rows: '7', spellcheck: 'false', placeholder: '.rzd-kf .rzd-kf-btn { text-transform: uppercase; }', 'aria-label': 'Wspólny CSS' });
		ta.value = d.css || '';
		main.appendChild(h('section', { class: 'rp-card rp-form' }, [
			h('h2', { text: 'Wspólny CSS (wszystkie formularze)' }),
			h('p', { class: 'rp-muted', text: 'Klasy: .rzd-kf (cały formularz), .rzd-kf--karta (styl), .rzd-kf-id-kontakt (konkretny formularz), .rzd-kf-input, .rzd-kf-label, .rzd-kf-btn, .rzd-kf-field--email. Zmienne: --rzd-kf-accent, --rzd-kf-radius, --rzd-kf-gap. Reguła bez klasy formularza (np. body {…}) zmieni całą stronę.' }),
			ta,
			h('div', { class: 'rp-actions' }, [K.btn('Zapisz wspólny CSS', function (e) {
				K.busy(e.currentTarget, true);
				K.api('forms_css', { css: ta.value }).then(function (x) { S.data.forms = x; K.toast(x.message); K.render(); }, function (er) { K.busy(e.currentTarget, false); K.toast(er.message, true); });
			})])
		]));
	}

	function protectCard(main, p) {
		var rate = h('input', { type: 'number', class: 'rp-in rp-in-s', min: '0', max: '100', value: String(p.rate) });
		var keep = h('input', { type: 'number', class: 'rp-in rp-in-s', min: '0', max: '120', value: String(p.keep) });
		var cap = h('select', { class: 'rp-in' }, [['', 'wyłączone (wystarcza przy małym ruchu)'], ['turnstile', 'Cloudflare Turnstile (zwykle niewidoczne, darmowe)'], ['hcaptcha', 'hCaptcha (darmowe)']].map(function (o) { return h('option', { value: o[0], selected: p.captcha === o[0], text: o[1] }); }));
		var sk = h('input', { type: 'text', class: 'rp-in', value: p.site_key, autocomplete: 'off' });
		var sec = h('input', { type: 'password', class: 'rp-in', value: '', autocomplete: 'new-password', placeholder: p.hasSecret ? 'zapisany – wpisz, aby zmienić' : '' });
		var clr = h('input', { type: 'checkbox' });
		main.appendChild(h('section', { class: 'rp-card rp-form' }, [
			h('h2', { text: 'Ochrona przed spamem i przechowywanie' }),
			h('p', { class: 'rp-muted', text: 'Tylko Administrator. Zawsze działają: ukryte pole – pułapka na roboty, odrzucanie wysłań szybszych niż ' + p.min + ' s, sprawdzenie, czy wysłano z tej strony. Zatrzymanych prób spamu: ' + p.spam + '.' }),
			K.field('Limit wiadomości z jednego adresu IP na godzinę', rate, '0 = bez limitu.'),
			K.field('Sprawdzenie „nie jestem robotem”', cap, 'Klucze: Cloudflare → Turnstile → Add site, albo hCaptcha → Sites. Usługa ładuje swój skrypt na stronie formularza – warto wspomnieć o tym w polityce prywatności.' + (p.captcha && !p.on ? ' Teraz NIE działa – brakuje klucza.' : '')),
			h('div', { class: 'rp-grid2' }, [K.field('Klucz witryny (site key)', sk), K.field('Klucz tajny (secret)', sec)]),
			p.hasSecret ? h('label', { class: 'rp-check' }, [clr, h('span', { text: 'Usuń zapisany klucz tajny' })]) : null,
			K.field('Przechowywanie wiadomości (miesiące)', keep, 'Potem usuwane automatycznie. 0 = nie usuwaj; RODO: nie dłużej, niż potrzeba.'),
			h('div', { class: 'rp-actions' }, [K.btn('Zapisz ochronę', function (e) {
				K.busy(e.currentTarget, true);
				K.api('forms_protect', { protect: { rate: rate.value, keep: keep.value, captcha: cap.value, site_key: sk.value, secret: sec.value, secret_clear: clr.checked ? 1 : 0 } }).then(function (x) { S.data.forms = x; K.toast(x.message); K.render(); }, function (er) { K.busy(e.currentTarget, false); K.toast(er.message, true); });
			})])
		]));
	}

	/* ============================================================
	 * KREATOR
	 * ============================================================ */
	function openForm(id) {
		K.api('form_get', { id: id }).then(function (x) {
			S.work.form = copy(x.form); S.work.formX = x; S.work.formDoc = x.preview; S.work.fOpen = {}; S.dirty = false;
			K.render(); var m = K.root.querySelector('.rp-main'); if (m) { m.scrollTop = 0; }
		}).catch(function (e) { K.toast(e.message, true); });
	}

	var pvT = null, pvSeq = 0, lastTpl = null;
	function changed() { K.dirty(); clearTimeout(pvT); pvT = setTimeout(preview, 500); }
	function preview() {
		var my = ++pvSeq, f = S.work.form, st = K.root.querySelector('.rp-kfpv-state');
		if (!f) { return; }
		if (st) { st.textContent = 'odświeżam…'; st.classList.remove('err'); }
		K.api('form_preview', { id: f.id, form: f }).then(function (x) {
			if (my !== pvSeq) { return; }
			S.work.formDoc = x.preview;
			var fr = K.root.querySelector('.rp-kfpv iframe'); if (fr) { fr.srcdoc = x.preview; }
			if (st) { st.textContent = 'na żywo – jeszcze niezapisane'; }
		}).catch(function (e) { if (st) { st.textContent = e.message; st.classList.add('err'); } });
	}

	function inp(f, k, attrs, isArea) {
		var a = Object.assign({ class: 'rp-in' }, attrs || {});
		var el = h(isArea ? 'textarea' : 'input', a);
		el.value = f[k] === undefined || f[k] === null ? '' : String(f[k]);
		el.addEventListener('input', function () { f[k] = el.value; changed(); });
		el.addEventListener('focus', function () { if (/subject|body/.test(k)) { lastTpl = el; } });
		return el;
	}

	function fieldCard(list, i, x) {
		var fl = list[i], open = S.work.fOpen[i];
		var types = x.types;
		function redraw() { drawFields(); }
		var head = h('div', { class: 'rp-kff-h' }, [
			h('button', { type: 'button', class: 'rp-kff-t', 'aria-expanded': open ? 'true' : 'false', onclick: function () { S.work.fOpen[i] = !open; redraw(); } }, [
				h('strong', { text: fl.label ? fl.label.replace(/<[^>]*>/g, '') : '(bez etykiety)' }),
				h('small', { text: (types[fl.type] || fl.type) + (fl.width === 'half' ? ' · pół szerokości' : '') }),
				+fl.required ? h('span', { class: 'rp-pill', text: 'wymagane' }) : null
			]),
			h('button', { type: 'button', class: 'rp-ico', text: '↑', 'aria-label': 'Wyżej: ' + fl.label, disabled: i === 0 ? true : null, onclick: function () { list.splice(i - 1, 0, list.splice(i, 1)[0]); S.work.fOpen = {}; changed(); redraw(); } }),
			h('button', { type: 'button', class: 'rp-ico', text: '↓', 'aria-label': 'Niżej: ' + fl.label, disabled: i === list.length - 1 ? true : null, onclick: function () { list.splice(i + 1, 0, list.splice(i, 1)[0]); S.work.fOpen = {}; changed(); redraw(); } }),
			h('button', { type: 'button', class: 'rp-ico', html: K.ICON.x, 'aria-label': 'Usuń pole: ' + fl.label, onclick: function () { if (window.confirm('Usunąć pole „' + fl.label.replace(/<[^>]*>/g, '') + '”?')) { list.splice(i, 1); S.work.fOpen = {}; changed(); redraw(); } } })
		]);
		var kids = [head];
		if (open) {
			var type = h('select', { class: 'rp-in', onchange: function () { fl.type = type.value; changed(); redraw(); } }, Object.keys(types).map(function (t) { return h('option', { value: t, selected: fl.type === t, text: types[t] }); }));
			var req = h('input', { type: 'checkbox', checked: !!+fl.required, onchange: function () { fl.required = req.checked ? 1 : 0; changed(); redraw(); } });
			var half = h('input', { type: 'checkbox', checked: fl.width === 'half', onchange: function () { fl.width = half.checked ? 'half' : 'full'; changed(); redraw(); } });
			var isHead = fl.type === 'heading', isCons = fl.type === 'consent';
			var b = [
				K.field(isHead ? 'Nagłówek' : (isCons ? 'Treść zgody' : 'Etykieta'), inp(fl, 'label', { maxlength: '300' }), isCons ? 'Możesz wstawić link: <a href="adres">tekst</a>.' : null),
				K.field('Typ pola', type)
			];
			if (!isHead) {
				b.push(h('label', { class: 'rp-check' }, [req, h('span', { text: 'Wymagane' })]));
				if (['textarea', 'consent'].indexOf(fl.type) < 0) { b.push(h('label', { class: 'rp-check' }, [half, h('span', { text: 'Pół szerokości (dwa pola obok siebie na komputerze)' })])); }
			}
			if (OPT_TYPES.indexOf(fl.type) > -1) { b.push(K.field('Opcje do wyboru (każda w osobnej linii)', inp(fl, 'options', { rows: '4' }, true))); }
			if (!isHead && !isCons && OPT_TYPES.indexOf(fl.type) < 0) { b.push(K.field('Podpowiedź w polu (placeholder)', inp(fl, 'placeholder'))); }
			b.push(K.field(isHead ? 'Tekst pod nagłówkiem' : 'Opis pod polem', inp(fl, 'help', { rows: '2' }, true)));
			if (fl.type === 'number') { b.push(h('div', { class: 'rp-grid2' }, [K.field('Najmniej', inp(fl, 'min', { inputmode: 'decimal' })), K.field('Najwięcej', inp(fl, 'max', { inputmode: 'decimal' }))])); }
			if (fl.type === 'date') {
				var fut = h('input', { type: 'checkbox', checked: !!+fl.future, onchange: function () { fl.future = fut.checked ? 1 : 0; changed(); } });
				b.push(h('label', { class: 'rp-check' }, [fut, h('span', { text: 'Tylko dzisiaj i później' })]));
			}
			if (fl.key) { b.push(h('small', { class: 'rp-hint', text: 'W mailu: {' + fl.key + '}' })); }
			kids.push(h('div', { class: 'rp-kff-b' }, b));
		}
		return h('li', { class: 'rp-kff' + (open ? ' open' : '') }, kids);
	}
	function drawFields() {
		var ul = K.root.querySelector('.rp-kffs'), x = S.work.formX;
		if (!ul) { return; }
		var list = S.work.form.fields;
		ul.textContent = '';
		list.forEach(function (fl, i) { ul.appendChild(fieldCard(list, i, x)); });
		drawMailBits();
	}
	function drawMailBits() {
		var f = S.work.form;
		var tags = K.root.querySelector('.rp-kftags');
		if (tags) {
			tags.textContent = '';
			['{wszystkie_pola}', '{formularz}', '{sklep}', '{strona}', '{data}'].concat(f.fields.filter(function (x) { return x.key && x.type !== 'heading'; }).map(function (x) { return '{' + x.key + '}'; })).forEach(function (t) {
				tags.appendChild(h('button', { type: 'button', class: 'rp-chip rp-chip-s', text: t, onclick: function () {
					var el = lastTpl || K.root.querySelector('.rp-kf-body');
					if (!el) { return; }
					var s = el.selectionStart || el.value.length, e2 = el.selectionEnd || s;
					el.value = el.value.slice(0, s) + t + el.value.slice(e2);
					el.dispatchEvent(new Event('input')); el.focus(); el.selectionStart = el.selectionEnd = s + t.length;
				} }));
			});
		}
		var rep = K.root.querySelector('.rp-kfreply');
		if (rep) {
			var emails = f.fields.filter(function (x) { return x.type === 'email'; });
			rep.textContent = '';
			if (!emails.length) { rep.appendChild(h('option', { value: '', text: '– brak pola e-mail w formularzu –' })); }
			emails.forEach(function (x) { rep.appendChild(h('option', { value: x.key || '', selected: f.reply_to === x.key, text: x.label + (x.key ? '' : ' (zapisz, żeby wybrać)') })); });
		}
	}

	function editor(main) {
		var f = S.work.form, x = S.work.formX;
		f.look = f.look || {};
		main.classList.add('rp-main-wide');
		main.appendChild(h('button', { type: 'button', class: 'rp-back', onclick: function () {
			if (S.dirty && !window.confirm('Masz niezapisane zmiany w formularzu. Wyjść bez zapisu?')) { return; }
			S.dirty = false; S.work.form = null; K.render();
		} }, [h('span', { html: K.ICON.back }), 'Wszystkie formularze']));
		main.appendChild(K.pageHead('Formularz: ' + (f.title || ''), null, h('div', { class: 'rp-inline' }, [
			K.btn('Duplikuj', function (e) {
				if (S.dirty) { K.toast('Najpierw zapisz albo cofnij zmiany.', true); return; }
				K.busy(e.currentTarget, true);
				K.api('form_new', { from: f.id }).then(function (r) { S.data.forms = r; K.toast(r.message); openForm(r.id); }, function (er) { K.busy(e.currentTarget, false); K.toast(er.message, true); });
			}),
			K.btn('Usuń', function (e) {
				if (!window.confirm('Usunąć formularz „' + f.title + '”? Shortcode z nim przestanie się wyświetlać. Wiadomości zostają.')) { return; }
				K.busy(e.currentTarget, true);
				K.api('form_delete', { id: f.id }).then(function (r) { S.data.forms = r; S.work.form = null; S.dirty = false; K.toast(r.message); K.render(); }, function (er) { K.busy(e.currentTarget, false); K.toast(er.message, true); });
			}, 'rp-btn-del')
		])));
		main.appendChild(scBox('[rzd_kontakt id="' + f.id + '"]'));

		var addType = h('select', { class: 'rp-in', 'aria-label': 'Typ nowego pola' }, Object.keys(x.types).map(function (t) { return h('option', { value: t, text: x.types[t] }); }));
		var col = h('div', { class: 'rp-kf-ed' }, [
			h('section', { class: 'rp-card rp-form' }, [h('h2', { text: 'Nazwa' }), inp(f, 'title', { 'aria-label': 'Nazwa formularza', maxlength: '120' }), h('small', { class: 'rp-hint', text: 'Widzisz ją w panelu, w Wiadomościach i (jako {formularz}) w mailach.' })]),
			h('section', { class: 'rp-card rp-form' }, [h('h2', { text: 'Pola' }), h('ul', { class: 'rp-kffs' }),
				h('div', { class: 'rp-inline rp-kfadd' }, [addType, K.btn('+ Dodaj pole', function () {
					var t = addType.value;
					var nf = { key: '', label: t === 'heading' ? 'Nagłówek' : (t === 'consent' ? 'Wyrażam zgodę na…' : x.types[t].replace(/ \(.*\)$/, '')), type: t, required: 0, placeholder: '', help: '', width: 'full', options: OPT_TYPES.indexOf(t) > -1 ? 'Opcja 1\nOpcja 2' : '', min: '', max: '', future: 0 };
					f.fields.push(nf); S.work.fOpen = {}; S.work.fOpen[f.fields.length - 1] = true; changed(); drawFields();
				})])
			]),
			styleCard(f, x),
			mailCard(f, x),
			h('section', { class: 'rp-card rp-form' }, [h('h2', { text: 'Po wysłaniu i informacja o danych' }),
				K.field('Komunikat po wysłaniu', inp(f, 'success', { rows: '2' }, true)),
				K.field('albo przejście na stronę', pageSelect(f, x)),
				K.field('Informacja o danych (RODO)', inp(f, 'privacy', { rows: '3' }, true), 'Pod formularzem. [privacy_policy] = link do polityki prywatności, {sklep} = nazwa strony. Zgoda nie jest wymagana przy odpowiedzi na zapytanie – w razie potrzeby dodaj pole typu „Zgoda”.')
			])
		]);
		var fr = h('iframe', { title: 'Podgląd formularza' });
		fr.srcdoc = S.work.formDoc || x.preview;
		var w = S.work.pvW || '';
		var pv = h('aside', { class: 'rp-kfpv rp-pv' }, [
			h('div', { class: 'rp-pv-head' }, [h('strong', { text: 'Podgląd' }), h('small', { class: 'rp-kfpv-state rp-muted', text: S.dirty ? 'na żywo – jeszcze niezapisane' : 'zapisany formularz' }),
				h('span', { class: 'rp-chips' }, [['390', 'telefon'], ['', 'szeroko']].map(function (o) { return h('button', { type: 'button', class: 'rp-chip rp-chip-s' + (w === o[0] ? ' on' : ''), text: o[1], onclick: function () { S.work.pvW = o[0]; var b = K.root.querySelector('.rp-kfpv-frame'); b.style.maxWidth = o[0] ? o[0] + 'px' : ''; Array.prototype.forEach.call(this.parentNode.children, function (c) { c.classList.remove('on'); }); this.classList.add('on'); } }); }))
			]),
			h('div', { class: 'rp-kfpv-frame', style: w ? 'max-width:' + w + 'px' : null }, [fr])
		]);
		main.appendChild(h('div', { class: 'rp-st rp-kf-cols' }, [col, pv]));
		main.appendChild(K.saveBar(function (b) {
			K.busy(b, true);
			K.api('form_save', { id: f.id, form: f }).then(function (r) {
				S.work.form = copy(r.form); S.work.formX = r; S.work.formDoc = r.preview; S.data.forms = r.list; S.dirty = false; K.toast(r.message); K.render();
			}, function (e) { K.busy(b, false); K.toast(e.message, true); });
		}, 'Zapisz formularz'));
		drawFields();
	}

	function pageSelect(f, x) {
		var sel = h('select', { class: 'rp-in', onchange: function () { f.redirect = +sel.value; changed(); } }, x.pages.map(function (p) { return h('option', { value: String(p.id), selected: +f.redirect === p.id, text: p.title }); }));
		return sel;
	}

	function colorOwn(f, key, label, def, hint) {
		var l = f.look, own = !!l[key];
		var col = h('input', { type: 'color', class: 'rp-color', value: own ? l[key] : def, disabled: own ? null : true, 'aria-label': label, oninput: function () { l[key] = col.value; changed(); } });
		var cb = h('input', { type: 'checkbox', checked: own, onchange: function () { col.disabled = !cb.checked; l[key] = cb.checked ? col.value : ''; changed(); } });
		return h('div', { class: 'rp-field' }, [h('span', { class: 'rp-label', text: label }), h('span', { class: 'rp-inline' }, [h('label', { class: 'rp-check' }, [cb, h('span', { text: 'własny' })]), col]), h('small', { class: 'rp-hint', text: hint })]);
	}

	function styleCard(f, x) {
		var l = f.look;
		var styles = h('div', { class: 'rp-kfstyles' }, Object.keys(x.styles).map(function (k) {
			return h('label', { class: 'rp-radio rp-radio-b' }, [h('input', { type: 'radio', name: 'rp-kfstyle', checked: f.style === k, onchange: function () { f.style = k; changed(); } }), h('span', null, [h('strong', { text: x.styles[k].label }), h('small', { text: x.styles[k].desc })])]);
		}));
		var rad = h('input', { type: 'number', class: 'rp-in rp-in-s', min: '0', max: '40', placeholder: 'auto', value: l.radius === undefined ? '' : String(l.radius), oninput: function () { l.radius = rad.value; changed(); } });
		var sp = h('select', { class: 'rp-in', onchange: function () { l.spacing = sp.value; changed(); } }, [['compact', 'ciasne'], ['normal', 'normalne'], ['airy', 'przestronne']].map(function (o) { return h('option', { value: o[0], selected: (l.spacing || 'normal') === o[0], text: o[1] }); }));
		var lb = h('select', { class: 'rp-in', onchange: function () { l.labels = lb.value; changed(); } }, [['', 'jak w stylu'], ['above', 'nad polem'], ['inside', 'w polu (unoszą się przy wpisywaniu)']].map(function (o) { return h('option', { value: o[0], selected: (l.labels || '') === o[0], text: o[1] }); }));
		return h('section', { class: 'rp-card rp-form' }, [h('h2', { text: 'Wygląd' }), styles,
			h('div', { class: 'rp-grid2' }, [colorOwn(f, 'accent', 'Kolor akcentu', '#c08a2e', 'bez zaznaczenia – kolor przycisków z Wyglądu'), colorOwn(f, 'bg', 'Tło formularza', '#ffffff', 'dla stylów Karta i Ciemny (kolor tekstu dobiera się sam)')]),
			h('div', { class: 'rp-grid2' }, [K.field('Zaokrąglenie rogów (px)', rad, 'puste – jak przyciski z Wyglądu'), K.field('Odstępy', sp)]),
			h('div', { class: 'rp-grid2' }, [K.field('Etykiety', lb), K.field('Napis na przycisku', inp(f, 'button', { maxlength: '60' }))]),
			K.field('Własny CSS (tylko ten formularz)', inp(f, 'css', { rows: '5', spellcheck: 'false', class: 'rp-in rp-code', placeholder: '.rzd-kf-id-' + f.id + ' .rzd-kf-btn { border-radius: 999px; }' }, true), 'Zaczynaj reguły od .rzd-kf-id-' + f.id + '. Klasy: .rzd-kf-input, .rzd-kf-label, .rzd-kf-btn, .rzd-kf-field--textarea, .rzd-kf-h (nagłówek), .rzd-kf-privacy. Podgląd pokazuje zmiany od razu.')
		]);
	}

	function mailCard(f, x) {
		var rep = h('select', { class: 'rp-in rp-kfreply', onchange: function () { f.reply_to = rep.value; changed(); } });
		var ar = h('input', { type: 'checkbox', checked: !!+f.autoreply, onchange: function () { f.autoreply = ar.checked ? 1 : 0; arBox.hidden = !ar.checked; changed(); } });
		var arBox = h('div', { hidden: +f.autoreply ? null : true }, [
			K.field('Temat potwierdzenia', inp(f, 'ar_subject')),
			K.field('Treść potwierdzenia', inp(f, 'ar_body', { rows: '6' }, true), 'Potwierdzenie idzie na adres wpisany w formularzu – przy dużym spamie lepiej wyłączyć albo włączyć captchę.')
		]);
		var body = inp(f, 'body', { rows: '5', class: 'rp-in rp-kf-body' }, true);
		return h('section', { class: 'rp-card rp-form' }, [h('h2', { text: 'Maile' }),
			K.field('Do kogo', inp(f, 'to', { placeholder: x.admin }), 'Jeden lub kilka adresów oddzielonych przecinkiem. Puste – adres administratora strony.'),
			K.field('Temat', inp(f, 'subject')),
			K.field('Treść', body),
			h('div', { class: 'rp-field' }, [h('span', { class: 'rp-hint', text: 'Znaczniki – kliknij, żeby wstawić w ostatnio wybrane pole (temat lub treść):' }), h('div', { class: 'rp-kftags rp-inline' })]),
			K.field('„Odpowiedz” do', rep, 'Pole z adresem klienta – „Odpowiedz” w poczcie napisze prosto do niego.'),
			h('label', { class: 'rp-check' }, [ar, h('span', { text: 'Wyślij klientowi potwierdzenie (na adres z pola wyżej)' })]),
			arBox
		]);
	}

	K.sections.formularze = secForms;
})();
