/* Restauracja – Panel restauracji: sekcja „Shortcody i API” (2.59.0, moduł 42-api-strony). Spis wszystkich shortcodów
 * (do skopiowania), ustawienia API strony, adresy REST, generator kodu do wklejenia na inną stronę.
 * Tekst zawsze przez textContent / value. */
(function () {
	'use strict';
	var K = window.rzdPanelKit;
	if (!K) { return; }
	var h = K.h, S = K.S;
	var GROUPS = [['strona', 'Na stronie restauracji', 'Zestawy, godziny i formularze – na stronach tego WordPressa. Na stronie na innej domenie – „Kod do wklejenia” niżej.'], ['sklep', 'W sklepie', 'Elementy zamawiania – zwykle już wstawione na stronach sklepu.'], ['obsluga', 'Ekrany obsługi', 'Strony dla zespołu (tylko po zalogowaniu). Zwykle tworzą się same – nie wstawiaj ich na zwykłe strony.']];
	function fail(b) { return function (e) { K.busy(b, false); K.toast(e.message, true); }; }
	function copy(text) {
		var done = function () { K.toast('Skopiowano.'); };
		if (navigator.clipboard && window.isSecureContext) { navigator.clipboard.writeText(text).then(done, function () { fallback(text); done(); }); } else { fallback(text); done(); }
	}
	function fallback(text) { var t = h('textarea', { style: 'position:fixed;opacity:0' }); t.value = text; document.body.appendChild(t); t.select(); try { document.execCommand('copy'); } catch (e) { /* brak */ } t.remove(); }
	function codeRow(text, extra) {
		return h('div', { class: 'rp-inline rp-shc-code' }, [h('code', { class: 'rp-code', text: text }), K.btn('Kopiuj', function () { copy(text); }, 'rp-btn-s'), extra || null]);
	}

	function secSc(main) {
		var d = S.data.shortcodes;
		if (!d) {
			K.loading(main, 'Shortcody i API');
			K.load('shortcodes', 'shortcodes').then(K.render).catch(function (e) { main.textContent = ''; K.failBox(main, e, K.render); });
			return;
		}
		main.appendChild(K.pageHead('Shortcody i API', 'Ściąga: jakie shortcody ma wtyczka, gdzie je wstawić i z jakimi ustawieniami. Shortcode wklejasz w treść strony WordPressa (blok „Shortcode” albo zwykły tekst). Na stronie na innej domenie – „Kod do wklejenia”.'));

		GROUPS.forEach(function (g) {
			var items = d.list.filter(function (s) { return s.g === g[0]; });
			if (!items.length) { return; }
			main.appendChild(h('h2', { class: 'rp-h2', text: g[1] }));
			main.appendChild(h('p', { class: 'rp-muted', text: g[2] }));
			items.forEach(function (s) {
				var card = h('section', { class: 'rp-card rp-shc' }, [
					h('h2', null, [h('code', { class: 'rp-shc-tag', text: '[' + s.tag + ']' }), ' ', s.n, s.on ? null : h('span', { class: 'rp-pstat rp-pstat-error', text: 'niedostępny' })]),
					h('p', { text: s.d }),
					h('p', { class: 'rp-muted', text: 'Gdzie: ' + s.where })
				]);
				if (s.a.length) {
					card.appendChild(h('div', { class: 'rp-tablewrap' }, [h('table', { class: 'rp-table-r rp-shc-attrs' }, [
						h('thead', null, [h('tr', null, ['Atrybut', 'Wartości', 'Domyślnie', 'Opis'].map(function (t) { return h('th', { text: t }); }))]),
						h('tbody', null, s.a.map(function (a) { return h('tr', null, [h('td', null, [h('code', { text: a[0] })]), h('td', { text: a[1] }), h('td', { text: a[2] }), h('td', { text: a[3] })]); }))
					])]));
				}
				(s.ex || []).forEach(function (x) { card.appendChild(codeRow(x)); });
				main.appendChild(card);
			});
		});

		// API strony
		if (!S.work.sc) { S.work.sc = JSON.parse(JSON.stringify(d.api)); }
		var v = S.work.sc;
		main.appendChild(h('h2', { class: 'rp-h2', text: 'Na innej stronie (API)' }));
		var ac = h('section', { class: 'rp-card' }, [h('h2', { text: 'API strony' }), h('p', { class: 'rp-muted', text: 'Te same dane co w shortcodach (menu, zestawy ze składem, godziny) dla strony restauracji na innej domenie. Tylko odczyt i tylko to, co i tak widać w sklepie.' })]);
		var on = h('input', { type: 'checkbox', checked: +v.on ? true : null, onchange: function () { v.on = on.checked ? 1 : 0; K.dirty(); } });
		ac.appendChild(h('label', { class: 'rp-check' }, [on, h('span', { text: 'Włączone (adresy REST i kod do wklejenia działają)' })]));
		var bt = h('input', { class: 'rp-in rp-in-m', value: v.btn, maxlength: '30', oninput: function () { v.btn = bt.value; K.dirty(); } });
		ac.appendChild(K.field('Domyślny napis przycisku przy zestawie', bt, 'W shortcodzie i kodzie można podać inny (przycisk="…").'));
		var or = h('textarea', { class: 'rp-in', rows: '3', placeholder: 'np. https://www.mojarestauracja.pl', 'aria-label': 'Domeny', oninput: function () { v.origins = or.value; K.dirty(); } });
		or.value = v.origins || '';
		ac.appendChild(K.field('Strony, które mogą pobierać dane (puste = każda)', or, 'Po jednej w linii. Wpisz, jeśli chcesz, żeby tylko Twoja strona mogła czytać dane z przeglądarki (zabezpieczenie CORS). Dane są publiczne – to samo widać w sklepie.'));
		[['zestawy', 'Wszystkie zestawy ze składem', 'dzien=RRRR-MM-DD – inny dzień'], ['zestaw/' + (d.sets[0] ? d.sets[0].id : 'ID'), 'Jeden zestaw', 'dzien=RRRR-MM-DD – inny dzień'], ['godziny', 'Godziny dostaw i odbioru – dziś', 'dzien=RRRR-MM-DD – inny dzień'], ['menu', 'Pełne menu', 'kategoria=Zupy,Pierogi – tylko wybrane']].forEach(function (r) {
			var url = d.rest + r[0];
			ac.appendChild(h('p', { class: 'rp-muted', text: r[1] + ' (dodaj ?' + r[2] + ', ?html=1 – gotowy HTML):' }));
			ac.appendChild(codeRow(url, h('a', { class: 'rp-btn rp-btn-s', href: url, target: '_blank', rel: 'noopener', text: 'Otwórz ↗' })));
		});
		ac.appendChild(h('p', { class: 'rp-muted', text: 'Gdy adresy /wp-json/ nie działają (bez „ładnych” odnośników): ' + d.restAlt + '…' }));
		main.appendChild(ac);

		// generator kodu do wklejenia
		var g = S.scGen || (S.scGen = { kind: 'zestaw', id: d.sets[0] ? String(d.sets[0].id) : '', btn: '', foto: true, price: true, cats: '' });
		var gc = h('section', { class: 'rp-card' }, [h('h2', { text: 'Kod do wklejenia na inną stronę' }), h('p', { class: 'rp-muted', text: 'Dla strony, która nie jest tym WordPressem (np. strona-wizytówka na innej domenie). Wklej kod w miejscu, gdzie ma się pojawić; skrypt wystarczy raz na stronie. Wygląd dopasujesz zmiennymi CSS (.rzd-s { --rzd-s-acc: kolor; }).' })]);
		var out = h('div');
		function code() {
			var a = 'data-rzd="' + g.kind + '"';
			if (g.kind === 'zestaw' && g.id) { a += ' data-id="' + g.id + '"'; }
			if (g.kind === 'menu' && (g.cats || '').trim()) { a += ' data-kategoria="' + (g.cats || '').trim().replace(/"/g, '') + '"'; }
			if (g.kind !== 'godziny') {
				if (!g.foto) { a += ' data-zdjecie="nie"'; }
				if (!g.price) { a += ' data-cena="nie"'; }
				if (g.btn.trim()) { a += ' data-przycisk="' + g.btn.trim().replace(/"/g, '') + '"'; }
			}
			return '<div ' + a + '></div>\n<script src="' + d.js + '" defer></script>';
		}
		function redraw() { out.textContent = ''; var c = code(); out.appendChild(h('pre', { class: 'rp-pre', text: c })); out.appendChild(K.btn('Kopiuj kod', function () { copy(c); }, 'rp-btn-pri')); }
		var kind = h('select', { class: 'rp-in rp-in-m', 'aria-label': 'Co pokazać', onchange: function () { g.kind = kind.value; K.render(); } }, [['zestaw', 'Jeden zestaw'], ['zestawy', 'Wszystkie zestawy'], ['menu', 'Pełne menu'], ['godziny', 'Godziny dostaw']].map(function (x) { return h('option', { value: x[0], text: x[1], selected: g.kind === x[0] ? true : null }); }));
		var row = [K.field('Co pokazać', kind)];
		if (g.kind === 'zestaw') {
			var sel = h('select', { class: 'rp-in rp-in-m', 'aria-label': 'Zestaw', onchange: function () { g.id = sel.value; redraw(); } }, d.sets.map(function (x) { return h('option', { value: String(x.id), text: x.name + ' (id ' + x.id + ')', selected: String(x.id) === g.id ? true : null }); }));
			row.push(K.field('Zestaw', sel));
		}
		if (g.kind === 'menu') {
			var ct = h('input', { class: 'rp-in', value: g.cats || '', placeholder: 'puste = wszystkie, np. Zupy,Pierogi', 'aria-label': 'Kategorie', oninput: function () { g.cats = ct.value; redraw(); } });
			row.push(K.field('Kategorie', ct));
		}
		gc.appendChild(h('div', { class: 'rp-row2' }, row));
		if (g.kind !== 'godziny') {
			var ft = h('input', { type: 'checkbox', checked: g.foto ? true : null, onchange: function () { g.foto = ft.checked; redraw(); } });
			var pr = h('input', { type: 'checkbox', checked: g.price ? true : null, onchange: function () { g.price = pr.checked; redraw(); } });
			var bn = h('input', { class: 'rp-in rp-in-m', value: g.btn, placeholder: g.kind === 'menu' ? 'puste = bez przycisku' : (v.btn || 'Zamów'), 'aria-label': 'Napis przycisku', oninput: function () { g.btn = bn.value; redraw(); } });
			gc.appendChild(h('div', { class: 'rp-inline' }, [h('label', { class: 'rp-check' }, [ft, h('span', { text: 'Zdjęcie' })]), h('label', { class: 'rp-check' }, [pr, h('span', { text: 'Cena' })])]));
			gc.appendChild(K.field('Napis przycisku (puste = domyślny)', bn));
		}
		gc.appendChild(out); redraw();
		if (!d.api.on) { gc.appendChild(h('p', { class: 'rp-fnote warn', text: 'API strony jest wyłączone – kod nic nie pokaże, dopóki go nie włączysz (wyżej) i nie zapiszesz.' })); }
		main.appendChild(gc);

		main.appendChild(K.saveBar(function (b) {
			K.busy(b, true);
			K.api('shortcodes_save', { values: v }).then(function (x) { S.data.shortcodes = x; S.work.sc = null; S.dirty = false; K.toast(x.message); K.render(); }, fail(b));
		}, 'Zapisz ustawienia API'));
	}

	K.sections.shortcody = secSc;
})();
