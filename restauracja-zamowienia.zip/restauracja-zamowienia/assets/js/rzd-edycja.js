/* Restauracja – Edycja menu z telefonu (moduł 22, 2.27.0). Konfiguracja: window.rzdEd. */
(function () {
	'use strict';
	var C = window.rzdEd;
	var root = document.getElementById('rzd-ed');
	if (!C || !root) { return; }
	// Pełny ekran nad motywem (jak Kuchnia): kontener prosto w <body>.
	if (root.parentNode !== document.body) { document.body.appendChild(root); }
	document.documentElement.style.overflow = 'hidden';

	var ICON = {
		back: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 6l-6 6 6 6"/></svg>',
		search: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="#6E645C" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>',
		cam: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/></svg>',
		gal: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="4" y="5" width="16" height="14" rx="2"/><path d="M4 16l5-5 4 4 3-3 4 4"/></svg>',
		plus: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>',
		x: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>',
		out: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5M21 12H9"/></svg>',
		copy: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/></svg>'
	};

	/* ---------- Narzędzia ---------- */
	function h(tag, a, kids) {
		var e = document.createElement(tag);
		if (a) {
			Object.keys(a).forEach(function (k) {
				var v = a[k];
				if (v === null || v === undefined || v === false) { return; }
				if (k === 'class') { e.className = v; }
				else if (k === 'text') { e.textContent = v; }
				else if (k === 'html') { e.innerHTML = v; } // tylko stałe ikonki z ICON
				else if (k === 'value') { e.value = v; }
				else if (k === 'checked') { e.checked = !!v; }
				else if (k.slice(0, 2) === 'on') { e.addEventListener(k.slice(2), v); }
				else { e.setAttribute(k, v === true ? '' : v); }
			});
		}
		(kids || []).forEach(function (c) {
			if (c === null || c === undefined || c === false) { return; }
			e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
		});
		return e;
	}
	function th(url, cls) {
		var s = h('span', { class: cls || 'ed-th', 'aria-hidden': 'true' });
		if (url) { s.style.backgroundImage = 'url("' + String(url).replace(/"/g, '%22') + '")'; }
		return s;
	}
	function icoBtn(icon, label, fn) { return h('button', { type: 'button', class: 'ed-ico', 'aria-label': label, html: icon, onclick: fn }); }

	var toastT = null;
	function toast(msg, err) {
		var old = root.querySelector('.ed-toast');
		if (old) { old.remove(); }
		var t = h('div', { class: 'ed-toast' + (err ? ' err' : ''), role: 'status', text: msg });
		root.appendChild(t);
		clearTimeout(toastT);
		toastT = setTimeout(function () { t.remove(); }, err ? 5000 : 2600);
	}

	function api(action, data, file) {
		var fd = new FormData();
		fd.append('action', 'rzd_ed_' + action);
		fd.append('n', C.nonce);
		Object.keys(data || {}).forEach(function (k) {
			var v = data[k];
			fd.append(k, (v !== null && typeof v === 'object') ? JSON.stringify(v) : String(v));
		});
		if (file) { fd.append('file', file, 'zdjecie.jpg'); }
		return fetch(C.ajax, { method: 'POST', credentials: 'same-origin', body: fd })
			.then(function (r) {
				return r.json().catch(function () { return { success: false, data: { msg: 'Błąd serwera (' + r.status + ').' } }; });
			})
			.then(function (j) {
				if (!j || !j.success) { throw new Error((j && j.data && j.data.msg) || 'Nie udało się.'); }
				return j.data;
			});
	}

	// Zdjęcie z telefonu (4–8 MB) → JPG do 1600 px (~300 KB) jeszcze w przeglądarce.
	function shrink(file) {
		return new Promise(function (res) {
			if (!file || !/^image\//.test(file.type || 'image/')) { res(file); return; }
			var url = URL.createObjectURL(file);
			var img = new Image();
			img.onload = function () {
				var w = img.naturalWidth, hh = img.naturalHeight, k = Math.min(1, 1600 / Math.max(w, hh));
				var c = document.createElement('canvas');
				c.width = Math.round(w * k);
				c.height = Math.round(hh * k);
				var ctx = c.getContext('2d');
				ctx.fillStyle = '#fff';
				ctx.fillRect(0, 0, c.width, c.height);
				ctx.drawImage(img, 0, 0, c.width, c.height);
				URL.revokeObjectURL(url);
				if (c.toBlob) { c.toBlob(function (b) { res(b || file); }, 'image/jpeg', 0.82); } else { res(file); }
			};
			img.onerror = function () { URL.revokeObjectURL(url); res(file); };
			img.src = url;
		});
	}

	/* ---------- Stan ---------- */
	var S = {
		boot: null, tab: 'list', screen: 'list', cat: 0, q: '',
		prod: null, form: null, back: 'list',
		set: 0, date: '', day: null, owners: null, info: {}, dirty: {},
		sheet: null
	};
	function rowById(id) { return (S.boot.rows || []).filter(function (r) { return r.id === id; })[0]; }
	function putRow(row) {
		var i = S.boot.rows.findIndex(function (r) { return r.id === row.id; });
		if (i >= 0) { S.boot.rows[i] = row; } else { S.boot.rows.push(row); S.boot.rows.sort(function (a, b) { return a.name.localeCompare(b.name, 'pl'); }); }
	}
	function dayLabel(d) { var x = (S.boot.days || []).filter(function (o) { return o.date === d; })[0]; return x ? x.label : d; }
	function isDirtyDay() { return Object.keys(S.dirty).length > 0; }

	// Przycisk „Wstecz” telefonu: zamyka okno albo kartę produktu.
	function pushNav() { try { history.pushState({ rzdEd: 1 }, ''); } catch (e) { /* ignore */ } }
	window.addEventListener('popstate', function () {
		if (S.sheet) { S.sheet = null; render(); return; }
		if (S.screen === 'product') { leaveProduct(true); return; }
		render();
	});

	/* ---------- Szkielet ekranu ---------- */
	function head(kids) { return h('div', { class: 'ed-head' }, [h('div', { class: 'ed-wrap', style: 'gap:12px' }, kids)]); }
	function tabs() {
		return h('div', { class: 'ed-tabs', role: 'tablist' }, [
			h('button', { type: 'button', class: S.tab === 'list' ? 'on' : '', role: 'tab', 'aria-selected': S.tab === 'list' ? 'true' : 'false', text: 'Produkty', onclick: function () { switchTab('list'); } }),
			h('button', { type: 'button', class: S.tab === 'set' ? 'on' : '', role: 'tab', 'aria-selected': S.tab === 'set' ? 'true' : 'false', text: 'Zestaw dnia', onclick: function () { switchTab('set'); } })
		]);
	}
	function topBar(title, sub) {
		return h('div', { class: 'ed-top' }, [
			h('h1', { text: title }),
			sub ? h('small', { text: sub }) : null,
			h('a', { class: 'ed-ico', href: C.logout, 'aria-label': 'Wyloguj', title: 'Wyloguj (' + (C.user || '') + ')', html: ICON.out })
		]);
	}
	function switchTab(t) {
		if (t === S.tab) { return; }
		if (S.tab === 'set' && isDirtyDay() && !window.confirm('Masz niezapisane zmiany w zestawie. Porzucić je?')) { return; }
		S.tab = t;
		S.screen = t;
		if (t === 'set') { S.dirty = {}; openSetTab(); return; }
		render();
	}

	function render() {
		root.textContent = '';
		var main;
		if (S.screen === 'product') { main = renderProduct(); }
		else if (S.screen === 'set') { main = renderSet(); }
		else { main = renderList(); }
		root.appendChild(main);
		if (S.sheet) { root.appendChild(renderSheet()); }
	}

	/* ---------- Lista produktów ---------- */
	function filteredRows() {
		var q = S.q.trim().toLowerCase();
		return S.boot.rows.filter(function (r) {
			if (S.cat === -1 && !r.is_set) { return false; }
			if (S.cat > 0 && r.cats.indexOf(S.cat) < 0) { return false; }
			return !q || r.name.toLowerCase().indexOf(q) >= 0;
		});
	}
	function listBody(body) {
		body.textContent = '';
		var rows = filteredRows();
		if (!rows.length) { body.appendChild(h('p', { class: 'ed-note', text: 'Brak produktów dla tego filtra.' })); return; }
		rows.forEach(function (r) {
			var badges = [];
			if (r.sold) { badges.push(h('span', { class: 'ed-badge', text: 'Wyprzedane ' + r.sold })); }
			if (r.hidden) { badges.push(h('span', { class: 'ed-badge gray', text: 'Prywatny' })); }
			body.appendChild(h('button', { type: 'button', class: 'ed-row', onclick: function () { openProduct(r.id, 'list'); } }, [
				th(r.thumb),
				h('span', { class: 'ed-rt' }, [h('b', { text: r.name }), h('span', { text: r.is_set ? 'Zestaw' : catNames(r.cats) })].concat(badges)),
				h('span', { class: 'ed-pr' + (r.price === 'w zestawie' ? ' mut' : ''), text: r.price || '' })
			]));
		});
	}
	function catNames(ids) {
		return (S.boot.cats || []).filter(function (c) { return ids.indexOf(c.id) >= 0; }).map(function (c) { return c.name; }).join(', ');
	}
	function renderList() {
		var body = h('div', { class: 'ed-body' });
		var chips = [{ id: 0, name: 'Wszystkie' }];
		if ((S.boot.sets || []).length) { chips.push({ id: -1, name: 'Zestawy' }); }
		chips = chips.concat(S.boot.cats || []);
		var frag = h('div', { class: 'ed-wrap' }, [
			head([
				topBar('Menu', ''),
				tabs(),
				h('label', { class: 'ed-search' }, [
					h('span', { html: ICON.search }),
					h('input', { type: 'search', placeholder: 'Szukaj produktu', 'aria-label': 'Szukaj produktu', value: S.q, oninput: function (e) { S.q = e.target.value; listBody(body); } })
				]),
				h('div', { class: 'ed-chips' }, chips.map(function (c) {
					return h('button', { type: 'button', class: 'ed-chip' + (S.cat === c.id ? ' on' : ''), text: c.name, onclick: function () { S.cat = c.id; render(); } });
				}))
			]),
			h('div', { style: 'flex:1;min-height:0;display:flex' }, [h('div', { class: 'ed-wrap' }, [body])]),
			h('div', { class: 'ed-foot' }, [h('div', { class: 'ed-wrap' }, [
				h('button', { type: 'button', class: 'ed-btn pri', html: ICON.plus + '<span>Nowe danie</span>', onclick: function () { openPicker({ mode: 'new' }); } })
			])])
		]);
		listBody(body);
		return frag;
	}

	/* ---------- Karta produktu ---------- */
	function openProduct(id, back, noPush) {
		S.back = back || S.tab;
		api('get', { id: id }).then(function (d) {
			S.prod = d;
			var so = d.soldout || { always: 0, dates: [] };
			var mode = 'off', sdate = S.boot.today;
			if (so.always) { mode = 'always'; }
			else if (so.dates.length === 1 && so.dates[0] === S.boot.today) { mode = 'today'; }
			else if (so.dates.length) { mode = 'date'; sdate = so.dates[0]; }
			S.form = { name: d.name, price: d.price, short: d.short, desc: d.desc, allergens: d.allergens.slice(), sold: mode, sdate: sdate, soldTouched: false, dirty: false };
			S.screen = 'product';
			if (!noPush) { pushNav(); }
			render();
			var b = root.querySelector('.ed-body');
			if (b) { b.scrollTop = 0; }
		}).catch(function (e) { toast(e.message, true); });
	}
	function leaveProduct(fromPop) {
		if (S.form && S.form.dirty && !window.confirm('Masz niezapisane zmiany. Porzucić je?')) {
			if (fromPop) { pushNav(); }
			return;
		}
		S.screen = S.back === 'set' ? 'set' : 'list';
		S.tab = S.screen;
		S.prod = null;
		S.form = null;
		if (S.screen === 'set') { loadDay(); } else { render(); }
	}
	function touch() { if (S.form) { S.form.dirty = true; } }

	function photoBox(p, label) {
		var box = h('div', { class: 'ed-photo' });
		if (p.img) { box.style.backgroundImage = 'url("' + p.img.replace(/"/g, '%22') + '")'; } else { box.appendChild(h('span', { class: 'ed-empty', text: label })); }
		var mk = function (capture, icon, text) {
			var inp = h('input', { type: 'file', accept: 'image/*', capture: capture ? 'environment' : null, onchange: function (e) { var f = e.target.files && e.target.files[0]; if (f) { uploadPhoto(p.id, f, box); } e.target.value = ''; } });
			return h('label', {}, [inp, h('span', { html: icon }), text]);
		};
		box.appendChild(mk(true, ICON.cam, 'Zrób zdjęcie'));
		box.appendChild(mk(false, ICON.gal, 'Z galerii'));
		return box;
	}
	function uploadPhoto(id, file, box) {
		toast('Wysyłam zdjęcie…');
		shrink(file).then(function (b) { return api('photo', { id: id }, b); }).then(function (d) {
			if (box && d.img) {
				box.style.backgroundImage = 'url("' + d.img.replace(/"/g, '%22') + '")';
				var em = box.querySelector('.ed-empty');
				if (em) { em.remove(); }
			}
			if (S.prod && S.prod.id === id) { S.prod.img = d.img; }
			if (d.row) { putRow(d.row); }
			toast('Zdjęcie zapisane.');
		}).catch(function (e) { toast(e.message, true); });
	}

	function soldBox(f) {
		var seg = function (k, t) {
			return h('button', { type: 'button', class: f.sold === k ? 'on' : '', text: t, onclick: function () { f.sold = k; f.soldTouched = true; touch(); render(); } });
		};
		return h('div', { class: 'ed-box' }, [
			h('label', { class: 'ed-sw' }, [
				h('span', {}, [h('b', { text: 'Wyprzedane' }), h('small', { text: 'Klient nie zamówi na wybrany dzień dostawy' })]),
				h('input', { type: 'checkbox', checked: f.sold !== 'off', onchange: function (e) { f.sold = e.target.checked ? 'today' : 'off'; f.soldTouched = true; touch(); render(); } })
			]),
			f.sold !== 'off' ? h('div', { class: 'ed-seg' }, [seg('today', 'Dziś'), seg('date', 'Wybrany dzień'), seg('always', 'Do odwołania')]) : null,
			f.sold === 'date' ? h('input', { type: 'date', class: 'ed-in', min: S.boot.today, value: f.sdate, 'aria-label': 'Dzień dostawy', onchange: function (e) { f.sdate = e.target.value; f.soldTouched = true; touch(); } }) : null,
			(!f.soldTouched && f.sold === 'date' && S.prod.soldout.dates.length > 1) ? h('small', { style: 'color:#6E645C', text: 'Wyprzedane w dniach: ' + S.prod.soldout.dates.map(dayLabel).join(', ') + '. Zmiana ustawi jeden wybór.' }) : null
		]);
	}

	function renderProduct() {
		var p = S.prod, f = S.form;
		var body = h('div', { class: 'ed-body', style: 'padding-top:4px' });
		var w = h('div', { class: 'ed-wrap' });
		w.appendChild(photoBox(p, p.is_set ? 'zdjęcie zastępcze zestawu' : 'brak zdjęcia'));
		if (p.is_set) { w.appendChild(h('p', { class: 'ed-note', text: 'Klienci widzą zdjęcie dań z danego dnia (dzielone przy dwóch daniach). To zdjęcie pokazuje się, gdy na dany dzień nie ma dania ze zdjęciem.' })); }
		w.appendChild(h('label', { class: 'ed-field' }, [h('span', { text: 'Nazwa' }), h('input', { type: 'text', class: 'ed-in', value: f.name, oninput: function (e) { f.name = e.target.value; touch(); } })]));
		if (p.only) {
			w.appendChild(h('div', { class: 'ed-field' }, [h('span', { text: 'Cena' }), h('div', { class: 'ed-note', style: 'margin:0', text: 'Danie tylko w zestawie – cenę ma zestaw (zakładka „Zestaw dnia” → Edytuj zestaw).' })]));
		} else if (p.price_edit) {
			w.appendChild(h('label', { class: 'ed-field' }, [
				h('span', {}, ['Cena ', h('em', { text: '(brutto – tyle płaci klient)' })]),
				h('input', { type: 'text', inputmode: 'decimal', class: 'ed-in', style: 'font-family:Oswald,sans-serif;font-size:18px', value: f.price, placeholder: '0,00', oninput: function (e) { f.price = e.target.value; touch(); } }),
				p.sale ? h('small', { style: 'color:#7A3606', text: 'Produkt ma cenę promocyjną – klient płaci promocyjną. Promocję zmienisz w panelu.' }) : null
			]));
		} else {
			w.appendChild(h('div', { class: 'ed-note', text: 'Cena tego produktu jest w wariantach – zmienisz ją w panelu.' }));
		}
		w.appendChild(soldBox(f));
		if (!p.is_set && (S.boot.allergens || []).length) {
			w.appendChild(h('div', { class: 'ed-field' }, [
				h('span', { text: 'Alergeny' }),
				h('div', { class: 'ed-alg' }, S.boot.allergens.map(function (a) {
					var on = f.allergens.indexOf(a.id) >= 0;
					return h('button', { type: 'button', class: on ? 'on' : '', 'aria-pressed': on ? 'true' : 'false', text: a.name, onclick: function () {
						var i = f.allergens.indexOf(a.id);
						if (i >= 0) { f.allergens.splice(i, 1); } else { f.allergens.push(a.id); }
						touch();
						render();
					} });
				}))
			]));
		}
		var txt = function (key, label, sub, rows, locked) {
			if (locked) {
				return h('div', { class: 'ed-field' }, [h('span', {}, [label + ' ', h('em', { text: sub })]), h('div', { class: 'ed-note', style: 'margin:0' }, ['Ten opis ma formatowanie (listy, linki albo bloki) – zmień go w panelu, żeby go nie zepsuć. ', p.edit_url ? h('a', { href: p.edit_url, text: 'Otwórz w panelu' }) : null])]);
			}
			return h('label', { class: 'ed-field' }, [h('span', {}, [label + ' ', h('em', { text: sub })]), h('textarea', { class: 'ed-in', rows: rows, value: f[key], oninput: function (e) { f[key] = e.target.value; touch(); } })]);
		};
		w.appendChild(txt('short', 'Krótki opis', '(na liście)', 3, p.short_lock));
		w.appendChild(txt('desc', 'Pełny opis', '(strona produktu)', 6, p.desc_lock));
		body.appendChild(w);

		return h('div', { class: 'ed-wrap', style: 'max-width:none' }, [
			h('div', { class: 'ed-head' }, [h('div', { class: 'ed-wrap' }, [h('div', { class: 'ed-top' }, [
				icoBtn(ICON.back, 'Wróć', function () { history.back(); }),
				h('h1', { style: 'font-size:20px', text: p.is_set ? 'Edytuj zestaw' : 'Edytuj produkt' })
			])])]),
			h('div', { style: 'flex:1;min-height:0;display:flex;flex-direction:column' }, [body]),
			h('div', { class: 'ed-foot' }, [h('div', { class: 'ed-wrap' }, [
				h('button', { type: 'button', class: 'ed-btn', text: 'Anuluj', onclick: function () { history.back(); } }),
				h('button', { type: 'button', class: 'ed-btn pri', text: 'Zapisz zmiany', onclick: saveProduct })
			])])
		]);
	}

	function saveProduct(e) {
		var p = S.prod, f = S.form, btn = e && e.currentTarget;
		var data = { name: f.name };
		if (p.price_edit && !p.only) { data.price = f.price; }
		if (!p.short_lock) { data.short = f.short; }
		if (!p.desc_lock) { data.desc = f.desc; }
		if (!p.is_set) { data.allergens = f.allergens; }
		if (f.soldTouched) {
			if (f.sold === 'date' && !f.sdate) { toast('Wybierz dzień, w którym produkt jest wyprzedany.', true); return; }
			data.soldout = f.sold === 'always' ? { always: 1, dates: [] } : { always: 0, dates: f.sold === 'today' ? [S.boot.today] : (f.sold === 'date' ? [f.sdate] : []) };
		}
		if (btn) { btn.disabled = true; }
		api('save', { id: p.id, data: data }).then(function (d) {
			putRow(d.row);
			if (S.back === 'set' && S.boot.sets) {
				S.boot.sets.forEach(function (s) { if (s.id === d.row.id) { s.name = d.row.name; s.price = d.row.price; } });
			}
			S.form.dirty = false;
			toast('Zapisano.');
			history.back();
		}).catch(function (er) { if (btn) { btn.disabled = false; } toast(er.message, true); });
	}

	/* ---------- Zestaw dnia ---------- */
	function openSetTab() {
		if (!(S.boot.sets || []).length) { S.day = null; render(); return; }
		if (!S.set) { S.set = S.boot.sets[0].id; }
		if (!S.date) { S.date = S.boot.today; }
		loadDay();
	}
	function loadDay() {
		S.screen = 'set';
		S.tab = 'set';
		api('day', { set: S.set, date: S.date }).then(function (d) {
			S.day = d;
			S.owners = JSON.parse(JSON.stringify(d.owners));
			S.info = d.info || {};
			S.dirty = {};
			render();
		}).catch(function (e) { toast(e.message, true); });
	}
	function chooseSet(id) {
		if (id === S.set) { return; }
		if (isDirtyDay() && !window.confirm('Masz niezapisane zmiany. Porzucić je?')) { return; }
		S.set = id;
		loadDay();
	}
	function chooseDay(d) {
		if (d === S.date) { return; }
		if (isDirtyDay() && !window.confirm('Masz niezapisane zmiany. Porzucić je?')) { return; }
		S.date = d;
		loadDay();
	}

	// Dania do pokazania: rozwijamy zestawy zagnieżdżone (danie zapisze się w ICH harmonogramie).
	function flat(ownerId, roleIn, depth) {
		var out = [];
		var own = S.owners[ownerId];
		if (!own) { return out; }
		own.items.forEach(function (it, idx) {
			var inf = S.info[it.product_id] || { name: '#' + it.product_id, thumb: '', role: '' };
			var role = roleIn || inf.role || (it.type === 'addon' ? 'Dodatek' : 'Danie');
			if (S.owners[it.product_id] && depth < 4) {
				var sub = flat(it.product_id, inf.role || roleIn, depth + 1);
				if (sub.length) { out = out.concat(sub); }
				else { out.push({ empty: true, owner: it.product_id, idx: -1, role: inf.role || role, name: inf.name }); }
			} else {
				out.push({ owner: ownerId, idx: idx, pid: it.product_id, role: role, name: inf.name, thumb: inf.thumb, sold: inf.sold, addon: it.type === 'addon' });
			}
		});
		return out;
	}
	function removeRow(r) {
		S.owners[r.owner].items.splice(r.idx, 1);
		S.dirty[r.owner] = 1;
		render();
	}

	function renderSet() {
		var body = h('div', { class: 'ed-body' });
		var w = h('div', { class: 'ed-wrap' });
		var d = S.day;
		var headKids = [topBar('Menu', ''), tabs()];
		if ((S.boot.sets || []).length) {
			headKids.push(h('div', { class: 'ed-sets' }, S.boot.sets.map(function (s) {
				return h('button', { type: 'button', class: s.id === S.set ? 'on' : '', onclick: function () { chooseSet(s.id); } }, [h('b', { text: s.name }), h('span', { text: s.price || '' })]);
			})));
			headKids.push(h('div', { class: 'ed-days' }, S.boot.days.map(function (o) {
				var parts = o.label.split(' ');
				var mark = o.date === S.boot.today ? 'dziś' : '';
				return h('button', { type: 'button', class: o.date === S.date ? 'on' : '', 'aria-label': o.label, onclick: function () { chooseDay(o.date); } }, [
					h('small', { text: parts[0] }), h('b', { text: (parts[1] || '').split('.')[0] }), h('small', { text: mark })
				]);
			})));
		}
		if (!d) {
			w.appendChild(h('p', { class: 'ed-note', text: (S.boot.sets || []).length ? 'Wczytuję…' : 'Nie ma jeszcze żadnego zestawu (produktu z harmonogramem dań).' }));
		} else {
			var rows = flat(S.set, '', 0);
			w.appendChild(h('div', { class: 'ed-prev' }, [
				th(d.preview, 'ed-th'),
				h('div', { style: 'min-width:0' }, [h('small', { text: 'Klient zobaczy · ' + d.label + (isDirtyDay() ? ' (po zapisie)' : '') }), h('b', { text: isDirtyDay() ? rows.filter(function (r) { return !r.empty && !r.addon; }).map(function (r) { return r.name; }).join(' + ') : (d.title || '—') })])
			]));
			if (d.orders && d.orders.count) {
				w.appendChild(h('p', { class: 'ed-note warn', text: 'Na ' + d.label + ' są już złożone zamówienia z tym zestawem: ' + d.orders.count + '. Mają zapisany skład' + (d.orders.sklady.length ? ' (' + d.orders.sklady.join(' / ') + ')' : '') + ' – zmiana dania ich nie poprawi.' }));
			}
			if (!d.has_dish && !isDirtyDay()) {
				w.appendChild(h('p', { class: 'ed-note warn', text: 'Na ten dzień zestaw nie ma dania – klienci nie mogą go zamówić.' }));
			}
			var box = h('div', { class: 'ed-box', style: 'gap:0;padding:4px 14px' });
			rows.forEach(function (r) {
				if (r.empty) {
					box.appendChild(h('div', { class: 'ed-dish' }, [
						th('', 'ed-th'),
						h('span', { class: 'ed-rt' }, [h('span', { text: r.role || r.name }), h('b', { style: 'color:#7A3606', text: 'brak dania (' + r.name + ')' })]),
						h('button', { type: 'button', class: 'ed-btn sm', text: 'Wybierz', onclick: function () { openPicker({ mode: 'pick', owner: r.owner, idx: -1, role: r.role }); } })
					]));
					return;
				}
				box.appendChild(h('div', { class: 'ed-dish' }, [
					th(r.thumb, 'ed-th'),
					h('span', { class: 'ed-rt' }, [h('span', { text: r.role }), h('b', { text: r.name }), r.sold ? h('span', { class: 'ed-badge', text: 'wyprzedane' }) : null]),
					h('button', { type: 'button', class: 'ed-btn sm', text: 'Zmień', onclick: function () { openPicker({ mode: 'pick', owner: r.owner, idx: r.idx, role: r.role, like: r.pid }); } }),
					h('button', { type: 'button', class: 'ed-x', 'aria-label': 'Usuń ' + r.name + ' z tego dnia', html: ICON.x, onclick: function () { removeRow(r); } })
				]));
			});
			box.appendChild(h('button', { type: 'button', class: 'ed-add', html: ICON.plus + '<span>Dodaj danie</span>', onclick: function () {
				var last = rows.filter(function (r) { return !r.empty && r.owner === S.set; }).pop();
				openPicker({ mode: 'pick', owner: S.set, idx: -1, role: '', like: last ? last.pid : 0 });
			} }));
			w.appendChild(box);
			var src = S.owners[S.set] ? S.owners[S.set].src : 'rule';
			w.appendChild(h('p', { class: 'ed-note', text: src === 'day' ? 'Ten dzień jest ustawiony osobno – zastępuje regułę zestawu (dni tygodnia).' : (src === 'date' ? 'Ten dzień ma termin z konkretną datą z panelu. Zapis zastąpi go jednym terminem „tylko ten dzień”.' : 'Dania z reguły zestawu (dni tygodnia). Zapis zmieni tylko ten dzień – reguła zostaje.') }));
			w.appendChild(h('button', { type: 'button', class: 'ed-btn', style: 'width:100%;flex:none;margin:0 0 18px', html: ICON.copy + '<span>Kopiuj z innego dnia</span>', onclick: function () { S.sheet = { mode: 'copy' }; pushNav(); render(); } }));

			// Sam zestaw
			var sp = d.product;
			if (sp) {
				var soldDay = !!(sp.soldout.always || sp.soldout.dates.indexOf(S.date) >= 0);
				w.appendChild(h('h2', { class: 'ed-h', text: 'Sam zestaw' }));
				w.appendChild(h('div', { class: 'ed-box' }, [
					h('label', { class: 'ed-sw' }, [
						h('span', {}, [h('b', { text: 'Wyprzedane w tym dniu' }), h('small', { text: sp.soldout.always ? 'wyprzedane do odwołania – zmień w „Edytuj zestaw”' : d.label })]),
						h('input', { type: 'checkbox', checked: soldDay, disabled: !!sp.soldout.always, onchange: function (e) { setSoldDay(sp, e.target.checked); } })
					]),
					h('button', { type: 'button', class: 'ed-btn', style: 'flex:none', text: 'Edytuj zestaw – nazwa, cena, zdjęcie zastępcze', onclick: function () {
						if (isDirtyDay() && !window.confirm('Masz niezapisane zmiany dań. Porzucić je?')) { return; }
						openProduct(sp.id, 'set');
					} })
				]));
			}
		}
		body.appendChild(w);
		return h('div', { class: 'ed-wrap', style: 'max-width:none' }, [
			head(headKids),
			h('div', { style: 'flex:1;min-height:0;display:flex;flex-direction:column' }, [body]),
			d ? h('div', { class: 'ed-foot' }, [h('div', { class: 'ed-wrap' }, [
				h('button', { type: 'button', class: 'ed-btn pri', disabled: !isDirtyDay(), text: isDirtyDay() ? 'Zapisz ' + d.label : 'Bez zmian', onclick: saveDay })
			])]) : null
		]);
	}

	function setSoldDay(sp, on) {
		var dates = sp.soldout.dates.filter(function (x) { return x !== S.date; });
		if (on) { dates.push(S.date); }
		api('save', { id: sp.id, data: { soldout: { always: 0, dates: dates } } }).then(function (r) {
			putRow(r.row);
			toast(on ? 'Zestaw wyprzedany na ' + S.day.label + '.' : 'Zestaw znów dostępny na ' + S.day.label + '.');
			loadDay();
		}).catch(function (e) { toast(e.message, true); loadDay(); });
	}

	function saveDay(e, confirmed) {
		var btn = e && e.currentTarget;
		var payload = {};
		Object.keys(S.dirty).forEach(function (o) {
			payload[o] = S.owners[o].items.map(function (it) { return { product_id: it.product_id, type: it.type, photo: it.photo ? 1 : 0 }; });
		});
		if (btn) { btn.disabled = true; }
		api('day_save', { set: S.set, date: S.date, owners: payload, confirm: confirmed ? 1 : 0 }).then(function (d) {
			if (d.confirm) {
				if (window.confirm(d.confirm)) { saveDay(null, true); } else if (btn) { btn.disabled = false; }
				return;
			}
			toast('Zapisano ' + S.day.label + '.');
			loadDay();
		}).catch(function (er) { if (btn) { btn.disabled = false; } toast(er.message, true); });
	}

	/* ---------- Okno od dołu: wybór dania / nowe danie / kopiowanie dnia ---------- */
	function openPicker(o) {
		S.sheet = { mode: o.mode, owner: o.owner, idx: o.idx, role: o.role || '', like: o.like || 0, q: '', list: null, nf: { name: '', short: '', allergens: [], cat: 0, file: null } };
		if (o.mode === 'pick' && !S.sheet.like && S.owners && S.owners[o.owner]) {
			// danie-wzór dla nowego dania: ostatnie danie tej grupy (ta sama rola – te same grupy modyfikacji)
			var it = S.owners[o.owner].items.filter(function (x) { return !S.owners[x.product_id]; }).pop();
			S.sheet.like = it ? it.product_id : 0;
		}
		pushNav();
		render();
		if (o.mode === 'pick') { loadDishes(''); }
	}
	var dishT = null;
	function loadDishes(q) {
		clearTimeout(dishT);
		dishT = setTimeout(function () {
			api('dishes', { q: q }).then(function (d) {
				if (!S.sheet || S.sheet.q !== q) { return; }
				S.sheet.list = d.dishes;
				var holder = root.querySelector('.ed-dishlist');
				if (holder) { fillDishes(holder); }
			}).catch(function (e) { toast(e.message, true); });
		}, q ? 300 : 0);
	}
	function fillDishes(holder) {
		holder.textContent = '';
		var L = S.sheet.list;
		if (!L) { holder.appendChild(h('p', { style: 'color:#6E645C', text: 'Wczytuję…' })); return; }
		holder.appendChild(h('small', { style: 'display:block;font-size:12px;color:#6E645C;text-transform:uppercase;letter-spacing:.06em;padding:8px 0 4px', text: S.sheet.q ? 'Wyniki' : 'Ostatnio w zestawach' }));
		if (!L.length) { holder.appendChild(h('p', { style: 'color:#6E645C', text: S.sheet.q ? 'Nic nie znaleziono – dodaj nowe danie niżej.' : 'Brak dań w zestawach – wyszukaj albo dodaj nowe.' })); }
		L.forEach(function (dsh) {
			holder.appendChild(h('button', { type: 'button', class: 'ed-row', onclick: function () { pickDish(dsh); } }, [
				th(dsh.thumb),
				h('span', { class: 'ed-rt' }, [h('b', { text: dsh.name }), h('span', { text: [dsh.role, dsh.last].filter(Boolean).join(' · ') })]),
				h('span', { class: 'ed-btn sm pri', style: 'pointer-events:none', text: 'Wybierz' })
			]));
		});
	}
	function pickDish(dsh) {
		var sh = S.sheet, own = S.owners[sh.owner];
		S.info[dsh.id] = { id: dsh.id, name: dsh.name, thumb: dsh.thumb, role: dsh.role, is_set: false, sold: false };
		if (sh.idx >= 0 && own.items[sh.idx]) {
			own.items[sh.idx] = { product_id: dsh.id, type: own.items[sh.idx].type, photo: own.items[sh.idx].photo };
		} else {
			own.items.push({ product_id: dsh.id, type: 'main', photo: 0 });
		}
		S.dirty[sh.owner] = 1;
		S.sheet = null;
		history.back(); // zdejmuje wpis okna z historii (popstate → render)
	}
	function createDish(btn) {
		var nf = S.sheet.nf, sh = S.sheet;
		if (!nf.name.trim()) { toast('Podaj nazwę dania.', true); return; }
		if (!nf.cat && !sh.like) { toast('Wybierz kategorię – od niej zależą terminy dostawy i widoczność w sklepie.', true); return; }
		btn.disabled = true;
		var like = sh.like;
		api('new_dish', { name: nf.name, short: nf.short, like: like, allergens: nf.allergens, cat: nf.cat }).then(function (d) {
			putRow(d.row);
			var done = function () {
				toast('Dodano „' + d.row.name + '”.');
				if (sh.mode === 'pick') { pickDish({ id: d.id, name: d.row.name, thumb: d.row.thumb, role: d.info ? d.info.role : '' }); }
				else { S.sheet = null; openProduct(d.id, 'list', true); } // wpis historii okna służy karcie produktu
			};
			if (nf.file) {
				return shrink(nf.file).then(function (b) { return api('photo', { id: d.id }, b); }).then(function (p) { putRow(p.row); d.row = p.row; done(); }).catch(function (e) { toast('Danie dodane, ale zdjęcie nie: ' + e.message, true); done(); });
			}
			done();
		}).catch(function (e) { btn.disabled = false; toast(e.message, true); });
	}

	function renderSheet() {
		var sh = S.sheet;
		var close = function () { history.back(); };
		var title = sh.mode === 'copy' ? 'Kopiuj dania z dnia…' : (sh.mode === 'new' ? 'Nowe danie' : (sh.role || 'Danie') + ' · ' + (S.day ? S.day.label : ''));
		var inner = h('div', { style: 'flex:1;overflow-y:auto;padding:8px 16px 24px' });
		if (sh.mode === 'copy') {
			S.boot.days.forEach(function (o) {
				if (o.date === S.date) { return; }
				inner.appendChild(h('button', { type: 'button', class: 'ed-row', style: 'min-height:52px', onclick: function () { copyFrom(o); } }, [h('span', { class: 'ed-rt' }, [h('b', { text: o.label })])]));
			});
			inner.appendChild(h('p', { style: 'color:#6E645C;font-size:13px', text: 'Dania wybranego dnia zastąpią dania ' + (S.day ? S.day.label : '') + ' (przed zapisem możesz je jeszcze zmienić).' }));
		} else {
			if (sh.mode === 'pick') {
				inner.appendChild(h('label', { class: 'ed-search', style: 'margin:4px 0 4px' }, [
					h('span', { html: ICON.search }),
					h('input', { type: 'search', placeholder: 'Szukaj dania', 'aria-label': 'Szukaj dania', value: sh.q, oninput: function (e) { sh.q = e.target.value; sh.list = null; fillDishes(root.querySelector('.ed-dishlist')); loadDishes(sh.q.trim()); } })
				]));
				var holder = h('div', { class: 'ed-dishlist' });
				inner.appendChild(holder);
				fillDishes(holder);
			}
			inner.appendChild(newDishForm(sh));
		}
		return h('div', { class: 'ed-sheet', onclick: function (e) { if (e.target === e.currentTarget) { close(); } } }, [
			h('div', { role: 'dialog', 'aria-modal': 'true', 'aria-label': title }, [
				h('div', { style: 'flex:none;display:flex;align-items:center;gap:8px;padding:10px 12px 10px 18px;border-bottom:1px solid #E8E0D5' }, [
					h('b', { style: 'flex:1;font-family:\'Playfair Display\',Georgia,serif;font-size:19px', text: title }),
					icoBtn(ICON.x, 'Zamknij', close)
				]),
				inner
			])
		]);
	}

	function newDishForm(sh) {
		var nf = sh.nf;
		var likeName = sh.like && S.info[sh.like] ? S.info[sh.like].name : '';
		var phLabel = h('span', { text: nf.file ? 'Zdjęcie wybrane' : 'Zdjęcie' });
		var photo = h('label', { class: 'ed-btn', style: 'flex:none;width:84px;min-height:84px;flex-direction:column;gap:4px;font-size:12px;border-style:dashed;cursor:pointer;position:relative' }, [
			h('input', { type: 'file', accept: 'image/*', capture: 'environment', style: 'position:absolute;width:1px;height:1px;opacity:0', onchange: function (e) { nf.file = e.target.files && e.target.files[0] ? e.target.files[0] : null; phLabel.textContent = nf.file ? 'Zdjęcie wybrane' : 'Zdjęcie'; } }),
			h('span', { html: ICON.cam }), phLabel
		]);
		var kids = [
			h('b', { style: 'font-size:16px', text: sh.mode === 'new' ? 'Dane nowego dania' : 'Nowe danie' }),
			h('div', { style: 'display:flex;gap:12px;align-items:stretch' }, [
				photo,
				h('label', { class: 'ed-field', style: 'flex:1;margin:0;min-width:0' }, [h('span', { text: 'Nazwa' }), h('input', { type: 'text', class: 'ed-in', placeholder: 'np. Gulasz z kaszą', value: nf.name, oninput: function (e) { nf.name = e.target.value; } })])
			]),
			h('label', { class: 'ed-field', style: 'margin:0' }, [h('span', { text: 'Krótki opis' }), h('textarea', { class: 'ed-in', rows: 2, placeholder: 'Skład, dodatki…', value: nf.short, oninput: function (e) { nf.short = e.target.value; } })])
		];
		if (!sh.like) {
			kids.push(h('label', { class: 'ed-field', style: 'margin:0' }, [h('span', { text: 'Kategoria' }), h('select', { class: 'ed-in', onchange: function (e) { nf.cat = parseInt(e.target.value, 10) || 0; } }, [h('option', { value: '0', text: '— wybierz —' })].concat((S.boot.cats || []).map(function (c) { return h('option', { value: String(c.id), selected: nf.cat === c.id ? 'selected' : null, text: c.name }); })))]));
		}
		if ((S.boot.allergens || []).length) {
			kids.push(h('div', { class: 'ed-field', style: 'margin:0' }, [h('span', { text: 'Alergeny' }), h('div', { class: 'ed-alg' }, S.boot.allergens.map(function (a) {
				var on = nf.allergens.indexOf(a.id) >= 0;
				return h('button', { type: 'button', class: on ? 'on' : '', 'aria-pressed': on ? 'true' : 'false', text: a.name, onclick: function (e) {
					var i = nf.allergens.indexOf(a.id);
					if (i >= 0) { nf.allergens.splice(i, 1); e.currentTarget.className = ''; e.currentTarget.setAttribute('aria-pressed', 'false'); }
					else { nf.allergens.push(a.id); e.currentTarget.className = 'on'; e.currentTarget.setAttribute('aria-pressed', 'true'); }
				} });
			}))]));
		}
		kids.push(h('small', { style: 'color:#5C524A;line-height:1.4', text: likeName ? 'Kategoria, cena, rola, grupy modyfikacji i opakowanie – jak „' + likeName + '”. Dla klienta: tylko w zestawie, jeśli „' + likeName + '” też.' : 'Rola i modyfikacje – ustaw później w panelu, jeśli potrzebne.' }));
		kids.push(h('button', { type: 'button', class: 'ed-btn pri', style: 'flex:none', text: sh.mode === 'pick' ? 'Dodaj i wybierz na ' + (S.day ? S.day.label : '') : 'Utwórz danie', onclick: function (e) { createDish(e.currentTarget); } }));
		return h('div', { class: 'ed-box', style: 'margin-top:18px' }, kids);
	}

	function copyFrom(o) {
		api('day', { set: S.set, date: o.date }).then(function (d) {
			Object.keys(d.owners).forEach(function (oid) {
				if (!S.owners[oid]) { S.owners[oid] = { name: d.owners[oid].name, items: [], src: 'rule' }; }
				S.owners[oid].items = d.owners[oid].items.map(function (it) { return { product_id: it.product_id, type: it.type, photo: it.photo }; });
				S.dirty[oid] = 1;
			});
			Object.keys(d.info || {}).forEach(function (k) { S.info[k] = d.info[k]; });
			S.sheet = null;
			history.back();
			toast('Skopiowano z ' + o.label + ' – sprawdź i zapisz.');
		}).catch(function (e) { toast(e.message, true); });
	}

	/* ---------- Start ---------- */
	api('boot', {}).then(function (d) {
		S.boot = d;
		render();
	}).catch(function (e) {
		root.textContent = '';
		root.appendChild(h('p', { class: 'ed-note warn', style: 'margin:30px 16px', text: e.message }));
	});
	window.addEventListener('beforeunload', function (e) {
		if ((S.form && S.form.dirty) || isDirtyDay()) { e.preventDefault(); e.returnValue = ''; }
	});
})();
