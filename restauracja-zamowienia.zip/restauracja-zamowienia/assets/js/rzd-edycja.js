/* Restauracja – Edycja menu z telefonu (moduł 22; opisy – edytor sekcji, moduł 24). Konfiguracja: window.rzdEd. */
(function () {
	'use strict';
	var C = window.rzdEd;
	var root = document.getElementById('rzd-ed');
	if (!C || !root) { return; }
	// Pełny ekran nad motywem (jak Kuchnia): kontener prosto w <body>.
	if (root.parentNode !== document.body) { document.body.appendChild(root); }
	document.documentElement.style.overflow = 'hidden';

	var ICON = {
		back: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 6l-6 6 6 6"/></svg>',
		search: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="#6E645C" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>',
		cam: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/></svg>',
		gal: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="4" y="5" width="16" height="14" rx="2"/><path d="M4 16l5-5 4 4 3-3 4 4"/></svg>',
		plus: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>',
		x: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>',
		out: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5M21 12H9"/></svg>',
		copy: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/></svg>'
	};

	/* ---------- Narzędzia ---------- */
	function h(tag, a, kids) {
		var e = document.createElement(tag);
		if (a) {
			Object.keys(a).forEach(function (k) {
				var v = a[k];
				if (v === null || v === undefined || v === false) { return; }
				if (k === 'class') { e.className = v; }
				else if (k === 'text') { e.textContent = v; }
				else if (k === 'html') { e.innerHTML = v; } // tylko stałe ikonki z ICON
				else if (k === 'value') { e.value = v; }
				else if (k === 'checked') { e.checked = !!v; }
				else if (k.slice(0, 2) === 'on') { e.addEventListener(k.slice(2), v); }
				else { e.setAttribute(k, v === true ? '' : v); }
			});
		}
		(kids || []).forEach(function (c) {
			if (c === null || c === undefined || c === false) { return; }
			e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
		});
		return e;
	}
	function th(url, cls) {
		var s = h('span', { class: cls || 'ed-th', 'aria-hidden': 'true' });
		if (url) { s.style.backgroundImage = 'url("' + String(url).replace(/"/g, '%22') + '")'; }
		return s;
	}
	function icoBtn(icon, label, fn) { return h('button', { type: 'button', class: 'ed-ico', 'aria-label': label, html: icon, onclick: fn }); }

	var toastT = null;
	function toast(msg, err) {
		var old = root.querySelector('.ed-toast');
		if (old) { old.remove(); }
		var t = h('div', { class: 'ed-toast' + (err ? ' err' : ''), role: 'status', text: msg });
		root.appendChild(t);
		clearTimeout(toastT);
		toastT = setTimeout(function () { t.remove(); }, err ? 5000 : 2600);
	}

	function api(action, data, file) {
		var fd = new FormData();
		fd.append('action', 'rzd_ed_' + action);
		fd.append('n', C.nonce);
		Object.keys(data || {}).forEach(function (k) {
			var v = data[k];
			fd.append(k, (v !== null && typeof v === 'object') ? JSON.stringify(v) : String(v));
		});
		if (file) { fd.append('file', file, 'zdjecie.jpg'); }
		return fetch(C.ajax, { method: 'POST', credentials: 'same-origin', body: fd })
			.then(function (r) {
				return r.json().catch(function () { return { success: false, data: { msg: 'Błąd serwera (' + r.status + ').' } }; });
			})
			.then(function (j) {
				if (!j || !j.success) { throw new Error((j && j.data && j.data.msg) || 'Nie udało się.'); }
				return j.data;
			});
	}

	// Zdjęcie z telefonu (4–8 MB) → JPG do 1600 px (~300 KB) jeszcze w przeglądarce.
	function shrink(file) {
		return new Promise(function (res) {
			if (!file || !/^image\//.test(file.type || 'image/')) { res(file); return; }
			var url = URL.createObjectURL(file);
			var img = new Image();
			img.onload = function () {
				var w = img.naturalWidth, hh = img.naturalHeight, k = Math.min(1, 1600 / Math.max(w, hh));
				var c = document.createElement('canvas');
				c.width = Math.round(w * k);
				c.height = Math.round(hh * k);
				var ctx = c.getContext('2d');
				ctx.fillStyle = '#fff';
				ctx.fillRect(0, 0, c.width, c.height);
				ctx.drawImage(img, 0, 0, c.width, c.height);
				URL.revokeObjectURL(url);
				if (c.toBlob) { c.toBlob(function (b) { res(b || file); }, 'image/jpeg', 0.82); } else { res(file); }
			};
			img.onerror = function () { URL.revokeObjectURL(url); res(file); };
			img.src = url;
		});
	}

	/* ---------- Stan ---------- */
	var S = {
		boot: null, tab: 'list', screen: 'list', cat: 0, q: '',
		prod: null, form: null, back: 'list',
		set: 0, date: '', day: null, owners: null, info: {}, dirty: {},
		sheet: null
	};
	function rowById(id) { return (S.boot.rows || []).filter(function (r) { return r.id === id; })[0]; }
	function putRow(row) {
		var i = S.boot.rows.findIndex(function (r) { return r.id === row.id; });
		if (i >= 0) { S.boot.rows[i] = row; } else { S.boot.rows.push(row); S.boot.rows.sort(function (a, b) { return a.name.localeCompare(b.name, 'pl'); }); }
	}
	function dayLabel(d) { var x = (S.boot.days || []).filter(function (o) { return o.date === d; })[0]; return x ? x.label : d; }
	function isDirtyDay() { return Object.keys(S.dirty).length > 0; }

	// Przycisk „Wstecz” telefonu: zamyka okno albo kartę produktu.
	function pushNav() { try { history.pushState({ rzdEd: 1 }, ''); } catch (e) { /* ignore */ } }
	window.addEventListener('popstate', function () {
		if (S.de) { // edytor opisu (i jego okno „Kopiuj z…”)
			if (S.de.copy) { S.de.copy = null; deRender(); return; }
			deClose(true);
			return;
		}
		if (S.sheet) { S.sheet = null; render(); return; }
		if (S.screen === 'product') { leaveProduct(true); return; }
		render();
	});

	/* ---------- Szkielet ekranu ---------- */
	function head(kids) { return h('div', { class: 'ed-head' }, [h('div', { class: 'ed-wrap', style: 'gap:12px' }, kids)]); }
	function tabs() {
		return h('div', { class: 'ed-tabs', role: 'tablist' }, [
			h('button', { type: 'button', class: S.tab === 'list' ? 'on' : '', role: 'tab', 'aria-selected': S.tab === 'list' ? 'true' : 'false', text: 'Produkty', onclick: function () { switchTab('list'); } }),
			h('button', { type: 'button', class: S.tab === 'set' ? 'on' : '', role: 'tab', 'aria-selected': S.tab === 'set' ? 'true' : 'false', text: 'Zestaw dnia', onclick: function () { switchTab('set'); } })
		]);
	}
	function topBar(title, sub) {
		return h('div', { class: 'ed-top' }, [
			h('h1', { text: title }),
			sub ? h('small', { text: sub }) : null,
			h('a', { class: 'ed-ico', href: C.logout, 'aria-label': 'Wyloguj', title: 'Wyloguj (' + (C.user || '') + ')', html: ICON.out })
		]);
	}
	function switchTab(t) {
		if (t === S.tab) { return; }
		if (S.tab === 'set' && isDirtyDay() && !window.confirm('Masz niezapisane zmiany w zestawie. Porzucić je?')) { return; }
		S.tab = t;
		S.screen = t;
		if (t === 'set') { S.dirty = {}; openSetTab(); return; }
		render();
	}

	// ekran jest przebudowywany po każdej zmianie – zapamiętujemy przewinięcie,
	// żeby po kliknięciu (alergen, wyprzedane, wybór dania) zostać w tym samym miejscu,
	// a po powrocie z karty produktu – tam, gdzie się było na liście.
	var scrollMem = {}, lastKey = '';
	// dzień NIE wchodzi do klucza – zmiana dnia zostawia ekran na tej samej wysokości.
	function viewKey() { return S.screen + '|' + (S.screen === 'product' && S.prod ? S.prod.id : '') + '|' + (S.screen === 'set' ? S.set : ''); }
	// Zaznaczony kafelek paska przewijanego w bok (dzień, kategoria) zawsze w zasięgu wzroku.
	function keepInView(strip) {
		var on = strip && strip.querySelector('.on');
		if (!on) { return; }
		var r = on.getBoundingClientRect(), rr = strip.getBoundingClientRect();
		if (r.left < rr.left) { strip.scrollLeft -= (rr.left - r.left) + 16; }
		else if (r.right > rr.right) { strip.scrollLeft += (r.right - rr.right) + 16; }
	}
	function render() {
		var ob = root.querySelector('.ed-body');
		if (lastKey && ob) { scrollMem[lastKey] = ob.scrollTop; }
		var oc = root.querySelector('.ed-chips'), od = root.querySelector('.ed-days'), os = root.querySelector('.ed-sheet-in');
		var chipsL = oc ? oc.scrollLeft : 0, daysL = od ? od.scrollLeft : 0, sheetT = os ? os.scrollTop : 0;
		var deEl = S.de && S.de.el && S.de.el.parentNode === root ? S.de.el : null; // okno opisu zostaje
		root.textContent = '';
		var main;
		if (S.screen === 'product') { main = renderProduct(); }
		else if (S.screen === 'set') { main = renderSet(); }
		else { main = renderList(); }
		root.appendChild(main);
		if (S.sheet) { root.appendChild(renderSheet()); }
		if (deEl) { root.appendChild(deEl); }
		lastKey = viewKey();
		var nb = root.querySelector('.ed-body'), nc = root.querySelector('.ed-chips'), nd = root.querySelector('.ed-days'), ns = root.querySelector('.ed-sheet-in');
		if (nb && scrollMem[lastKey]) { nb.scrollTop = scrollMem[lastKey]; }
		if (nc && chipsL) { nc.scrollLeft = chipsL; }
		if (nd && daysL) { nd.scrollLeft = daysL; }
		keepInView(nc);
		keepInView(nd);
		if (ns && sheetT && os) { ns.scrollTop = sheetT; }
	}

	/* ---------- Lista produktów ---------- */
	function filteredRows() {
		var q = S.q.trim().toLowerCase();
		return S.boot.rows.filter(function (r) {
			if (S.cat === -1 && !r.is_set) { return false; }
			if (S.cat > 0 && r.cats.indexOf(S.cat) < 0) { return false; }
			return !q || r.name.toLowerCase().indexOf(q) >= 0;
		});
	}
	function listBody(body) {
		body.textContent = '';
		var rows = filteredRows();
		if (!rows.length) { body.appendChild(h('p', { class: 'ed-note', text: 'Brak produktów dla tego filtra.' })); return; }
		rows.forEach(function (r) {
			var badges = [];
			if (r.sold) { badges.push(h('span', { class: 'ed-badge', text: 'Wyprzedane ' + r.sold })); }
			if (r.hidden) { badges.push(h('span', { class: 'ed-badge gray', text: 'Prywatny' })); }
			body.appendChild(h('button', { type: 'button', class: 'ed-row', onclick: function () { openProduct(r.id, 'list'); } }, [
				th(r.thumb),
				h('span', { class: 'ed-rt' }, [h('b', { text: r.name }), h('span', { text: r.is_set ? 'Zestaw' : catNames(r.cats) })].concat(badges)),
				h('span', { class: 'ed-pr' + (r.price === 'w zestawie' ? ' mut' : ''), text: r.price || '' })
			]));
		});
	}
	function catNames(ids) {
		return (S.boot.cats || []).filter(function (c) { return ids.indexOf(c.id) >= 0; }).map(function (c) { return c.name; }).join(', ');
	}
	function renderList() {
		var body = h('div', { class: 'ed-body' });
		var chips = [{ id: 0, name: 'Wszystkie' }];
		if ((S.boot.sets || []).length) { chips.push({ id: -1, name: 'Zestawy' }); }
		chips = chips.concat(S.boot.cats || []);
		var frag = h('div', { class: 'ed-wrap' }, [
			head([
				topBar('Menu', ''),
				tabs(),
				h('label', { class: 'ed-search' }, [
					h('span', { html: ICON.search }),
					h('input', { type: 'search', placeholder: 'Szukaj produktu', 'aria-label': 'Szukaj produktu', value: S.q, oninput: function (e) { S.q = e.target.value; listBody(body); } })
				]),
				h('div', { class: 'ed-chips' }, chips.map(function (c) {
					return h('button', { type: 'button', class: 'ed-chip' + (S.cat === c.id ? ' on' : ''), text: c.name, onclick: function () { S.cat = c.id; render(); } });
				}))
			]),
			h('div', { style: 'flex:1;min-height:0;display:flex' }, [h('div', { class: 'ed-wrap' }, [body])]),
			h('div', { class: 'ed-foot' }, [h('div', { class: 'ed-wrap' }, [
				h('button', { type: 'button', class: 'ed-btn pri', html: ICON.plus + '<span>Nowe danie</span>', onclick: function () { openPicker({ mode: 'new' }); } })
			])])
		]);
		listBody(body);
		return frag;
	}

	/* ---------- Karta produktu ---------- */
	function openProduct(id, back, noPush) {
		S.back = back || S.tab;
		api('get', { id: id }).then(function (d) {
			S.prod = d;
			var so = d.soldout || { always: 0, dates: [] };
			var mode = 'off', sdate = S.boot.today;
			if (so.always) { mode = 'always'; }
			else if (so.dates.length === 1 && so.dates[0] === S.boot.today) { mode = 'today'; }
			else if (so.dates.length) { mode = 'date'; sdate = so.dates[0]; }
			S.form = { name: d.name, price: d.price, allergens: d.allergens.slice(), sold: mode, sdate: sdate, soldTouched: false, dirty: false,
				// skład (ID dodatków) i grupy modyfikacji (operacje: zostaw istniejącą / wstaw kopię wzoru)
				sklad: (d.sklad || []).slice(), skladTouched: false,
				mods: (d.mods || []).map(function (m) { return { k: 'own', i: m.i, header: m.header, count: m.count, preset: m.preset }; }), modsTouched: false, presetSel: '' };
			var ob = root.querySelector('.ed-body');
			if (lastKey && ob) { scrollMem[lastKey] = ob.scrollTop; } // pozycja listy / zestawu na powrót
			S.screen = 'product';
			delete scrollMem[viewKey()]; // świeżo otwarta karta – od góry
			lastKey = '';
			if (!noPush) { pushNav(); }
			render();
		}).catch(function (e) { toast(e.message, true); });
	}
	function leaveProduct(fromPop) {
		if (S.form && S.form.dirty && !window.confirm('Masz niezapisane zmiany. Porzucić je?')) {
			if (fromPop) { pushNav(); }
			return;
		}
		S.screen = S.back === 'set' ? 'set' : 'list';
		S.tab = S.screen;
		S.prod = null;
		S.form = null;
		if (S.screen === 'set') { loadDay(); } else { render(); }
	}
	function touch() { if (S.form) { S.form.dirty = true; } }

	function photoBox(p, label) {
		var box = h('div', { class: 'ed-photo' });
		if (p.img) { box.style.backgroundImage = 'url("' + p.img.replace(/"/g, '%22') + '")'; } else { box.appendChild(h('span', { class: 'ed-empty', text: label })); }
		var mk = function (capture, icon, text) {
			var inp = h('input', { type: 'file', accept: 'image/*', capture: capture ? 'environment' : null, onchange: function (e) { var f = e.target.files && e.target.files[0]; if (f) { uploadPhoto(p.id, f, box); } e.target.value = ''; } });
			return h('label', {}, [inp, h('span', { html: icon }), text]);
		};
		box.appendChild(mk(true, ICON.cam, 'Zrób zdjęcie'));
		box.appendChild(mk(false, ICON.gal, 'Z galerii'));
		return box;
	}
	function uploadPhoto(id, file, box) {
		toast('Wysyłam zdjęcie…');
		shrink(file).then(function (b) { return api('photo', { id: id }, b); }).then(function (d) {
			if (box && d.img) {
				box.style.backgroundImage = 'url("' + d.img.replace(/"/g, '%22') + '")';
				var em = box.querySelector('.ed-empty');
				if (em) { em.remove(); }
			}
			if (S.prod && S.prod.id === id) { S.prod.img = d.img; }
			if (d.row) { putRow(d.row); }
			toast('Zdjęcie zapisane.');
		}).catch(function (e) { toast(e.message, true); });
	}

	function soldBox(f) {
		var seg = function (k, t) {
			return h('button', { type: 'button', class: f.sold === k ? 'on' : '', text: t, onclick: function () { f.sold = k; f.soldTouched = true; touch(); render(); } });
		};
		return h('div', { class: 'ed-box' }, [
			h('label', { class: 'ed-sw' }, [
				h('span', {}, [h('b', { text: 'Wyprzedane' }), h('small', { text: 'Klient nie zamówi na wybrany dzień dostawy' })]),
				h('input', { type: 'checkbox', checked: f.sold !== 'off', onchange: function (e) { f.sold = e.target.checked ? 'today' : 'off'; f.soldTouched = true; touch(); render(); } })
			]),
			f.sold !== 'off' ? h('div', { class: 'ed-seg' }, [seg('today', 'Dziś'), seg('date', 'Wybrany dzień'), seg('always', 'Do odwołania')]) : null,
			f.sold === 'date' ? h('input', { type: 'date', class: 'ed-in', min: S.boot.today, value: f.sdate, 'aria-label': 'Dzień dostawy', onchange: function (e) { f.sdate = e.target.value; f.soldTouched = true; touch(); } }) : null,
			(!f.soldTouched && f.sold === 'date' && S.prod.soldout.dates.length > 1) ? h('small', { style: 'color:#6E645C', text: 'Wyprzedane w dniach: ' + S.prod.soldout.dates.map(dayLabel).join(', ') + '. Zmiana ustawi jeden wybór.' }) : null
		]);
	}

	function renderProduct() {
		var p = S.prod, f = S.form;
		var body = h('div', { class: 'ed-body', style: 'padding-top:4px' });
		var w = h('div', { class: 'ed-wrap' });
		w.appendChild(photoBox(p, p.is_set ? 'zdjęcie zastępcze zestawu' : 'brak zdjęcia'));
		if (p.is_set) { w.appendChild(h('p', { class: 'ed-note', text: 'Klienci widzą zdjęcie dań z danego dnia (dzielone przy dwóch daniach). To zdjęcie pokazuje się, gdy na dany dzień nie ma dania ze zdjęciem.' })); }
		w.appendChild(h('label', { class: 'ed-field' }, [h('span', { text: 'Nazwa' }), h('input', { type: 'text', class: 'ed-in', value: f.name, oninput: function (e) { f.name = e.target.value; touch(); } })]));
		if (p.only) {
			w.appendChild(h('div', { class: 'ed-field' }, [h('span', { text: 'Cena' }), h('div', { class: 'ed-note', style: 'margin:0', text: 'Danie tylko w zestawie – cenę ma zestaw (zakładka „Zestaw dnia” → Edytuj zestaw).' })]));
		} else if (p.price_edit) {
			w.appendChild(h('label', { class: 'ed-field' }, [
				h('span', {}, ['Cena ', h('em', { text: '(brutto – tyle płaci klient)' })]),
				h('input', { type: 'text', inputmode: 'decimal', class: 'ed-in', style: 'font-family:Oswald,sans-serif;font-size:18px', value: f.price, placeholder: '0,00', oninput: function (e) { f.price = e.target.value; touch(); } }),
				p.sale ? h('small', { style: 'color:#7A3606', text: 'Produkt ma cenę promocyjną – klient płaci promocyjną. Promocję zmienisz w panelu.' }) : null
			]));
		} else {
			w.appendChild(h('div', { class: 'ed-note', text: 'Cena tego produktu jest w wariantach – zmienisz ją w panelu.' }));
		}
		w.appendChild(soldBox(f));
		if (!p.is_set && (S.boot.allergens || []).length) {
			w.appendChild(h('div', { class: 'ed-field' }, [
				h('span', { text: 'Alergeny' }),
				h('div', { class: 'ed-alg' }, S.boot.allergens.map(function (a) {
					var on = f.allergens.indexOf(a.id) >= 0;
					return h('button', { type: 'button', class: on ? 'on' : '', 'aria-pressed': on ? 'true' : 'false', text: a.name, onclick: function () {
						var i = f.allergens.indexOf(a.id);
						if (i >= 0) { f.allergens.splice(i, 1); } else { f.allergens.push(a.id); }
						touch();
						render();
					} });
				}))
			]));
		}
		if (!p.is_set) {
			w.appendChild(skladBox(f));
			w.appendChild(modsBox(f));
		}
		// opisy w osobnym oknie edytora sekcji (zapis od razu, niezależnie od reszty karty)
		w.appendChild(descBox('short'));
		w.appendChild(descBox('long'));
		body.appendChild(w);

		return h('div', { class: 'ed-wrap', style: 'max-width:none' }, [
			h('div', { class: 'ed-head' }, [h('div', { class: 'ed-wrap' }, [h('div', { class: 'ed-top' }, [
				icoBtn(ICON.back, 'Wróć', function () { history.back(); }),
				h('h1', { style: 'font-size:20px', text: p.is_set ? 'Edytuj zestaw' : 'Edytuj produkt' })
			])])]),
			h('div', { style: 'flex:1;min-height:0;display:flex;flex-direction:column' }, [body]),
			h('div', { class: 'ed-foot' }, [h('div', { class: 'ed-wrap' }, [
				h('button', { type: 'button', class: 'ed-btn', text: 'Anuluj', onclick: function () { history.back(); } }),
				h('button', { type: 'button', class: 'ed-btn pri', text: 'Zapisz zmiany', onclick: saveProduct })
			])])
		]);
	}

	/* ---------- Skład i Modyfikacje (tylko wybór z tego, co istnieje) ---------- */
	function ingById(id) {
		var l = S.boot.ingredients || [];
		for (var i = 0; i < l.length; i++) { if (l[i].id === id) { return l[i]; } }
		return null;
	}
	function presetById(id) {
		var l = S.boot.presets || [];
		for (var i = 0; i < l.length; i++) { if (l[i].id === id) { return l[i]; } }
		return null;
	}
	function fold(t) { return String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/ł/g, 'l'); }
	function miniBtn(text, label, fn, dis) { return h('button', { type: 'button', class: 'ed-mini', text: text, 'aria-label': label, title: label, disabled: dis ? true : null, onclick: fn }); }

	function skladBox(f) {
		var rows = h('ul', { class: 'ed-rows' });
		f.sklad.forEach(function (id, idx) {
			var ing = ingById(id);
			rows.appendChild(h('li', {}, [
				h('span', { class: 'ed-r-main' }, [h('b', { text: ing ? ing.name : 'Dodatek #' + id }), ing && ing.type ? h('small', { text: ing.type }) : null]),
				miniBtn('↑', 'Wyżej', function () { var a = f.sklad; a.splice(idx - 1, 0, a.splice(idx, 1)[0]); f.skladTouched = true; touch(); render(); }, idx === 0),
				miniBtn('↓', 'Niżej', function () { var a = f.sklad; a.splice(idx + 1, 0, a.splice(idx, 1)[0]); f.skladTouched = true; touch(); render(); }, idx === f.sklad.length - 1),
				miniBtn('✕', 'Usuń ze składu', function () { f.sklad.splice(idx, 1); f.skladTouched = true; touch(); render(); })
			]));
		});
		var res = h('div', { class: 'ed-found' });
		var inp = h('input', { type: 'search', class: 'ed-in', placeholder: 'Szukaj dodatku, np. ziem…', 'aria-label': 'Szukaj dodatku', autocomplete: 'off' });
		var show = function () {
			var q = fold(inp.value.trim());
			res.textContent = '';
			if (!q) { return; }
			var hits = (S.boot.ingredients || []).filter(function (g) { return f.sklad.indexOf(g.id) < 0 && fold(g.name).indexOf(q) >= 0; }).slice(0, 8);
			if (!hits.length) { res.appendChild(h('p', { class: 'ed-note', style: 'margin:0', text: 'Brak takiego dodatku w katalogu (nowe dodaje się w panelu: Dodatki).' })); return; }
			hits.forEach(function (g) {
				res.appendChild(h('button', { type: 'button', class: 'ed-hit' }, ['+ ', h('b', { text: g.name }), g.type ? h('small', { text: ' · ' + g.type }) : null]));
				res.lastChild.addEventListener('click', function () { f.sklad.push(g.id); f.skladTouched = true; touch(); render(); });
			});
		};
		inp.addEventListener('input', show);
		return h('div', { class: 'ed-box' }, [
			h('div', {}, [h('b', { text: 'Skład' }), h('small', { class: 'ed-sub', text: 'Pod nazwą dania na liście i w Kuchni (skreślenia „BEZ …”, zamiany w zestawie).' })]),
			f.sklad.length ? rows : h('p', { class: 'ed-note', style: 'margin:0', text: 'Danie nie ma jeszcze składu.' }),
			inp, res
		]);
	}

	function presetUsed(f, id) {
		return f.mods.some(function (m) { return (m.k === 'own' && m.preset === id) || (m.k === 'preset' && m.id === id); });
	}
	function modsBox(f) {
		var rows = h('ul', { class: 'ed-rows' });
		f.mods.forEach(function (m, idx) {
			var pr = m.k === 'preset' ? presetById(m.id) : (m.preset ? presetById(m.preset) : null);
			var title = m.k === 'preset' ? (pr ? pr.title : 'Wzór #' + m.id) : (m.header || '(grupa bez nagłówka)');
			var sub = m.k === 'preset'
				? 'nowe – ' + (pr ? pr.groups + (pr.groups === 1 ? ' grupa' : ' grupy') : '') + ' ze wzoru, po zapisie'
				: (m.count + (m.count === 1 ? ' modyfikacja' : ' modyfikacje') + (m.preset ? ' · ze wzoru: ' + (pr ? pr.title : '#' + m.preset) : ''));
			rows.appendChild(h('li', { class: m.k === 'preset' ? 'is-new' : '' }, [
				h('span', { class: 'ed-r-main' }, [h('b', { text: title }), h('small', { text: sub })]),
				miniBtn('✕', 'Usuń grupę', function () { f.mods.splice(idx, 1); f.modsTouched = true; touch(); render(); })
			]));
		});
		var list = S.boot.presets || [];
		var sel = h('select', { class: 'ed-in', 'aria-label': 'Wzór modyfikacji', onchange: function (e) { f.presetSel = e.target.value; } }, [h('option', { value: '', text: list.length ? '— wybierz wzór —' : '— brak wzorów —' })].concat(list.map(function (pr) {
			return h('option', { value: String(pr.id), text: pr.title + (presetUsed(f, pr.id) ? ' ✓ już dodany' : '') });
		})));
		sel.value = f.presetSel || '';
		var add = h('button', { type: 'button', class: 'ed-btn', text: '+ Dodaj wzór', disabled: list.length ? null : true, onclick: function () {
			var id = parseInt(f.presetSel, 10);
			if (!id) { toast('Najpierw wybierz wzór z listy.', true); return; }
			if (presetUsed(f, id) && !window.confirm('Ten wzór jest już w daniu. Na pewno dodać go drugi raz?')) { return; }
			f.mods.push({ k: 'preset', id: id });
			f.presetSel = '';
			f.modsTouched = true;
			touch();
			render();
		} });
		return h('div', { class: 'ed-box' }, [
			h('div', {}, [h('b', { text: 'Modyfikacje' }), h('small', { class: 'ed-sub', text: 'Grupy wyboru dla klienta (np. dodatek, sosy). Wzór wstawia się jako kopia; szczegóły grup zmienisz w panelu.' })]),
			f.mods.length ? rows : h('p', { class: 'ed-note', style: 'margin:0', text: 'Danie nie ma modyfikacji.' }),
			h('div', { class: 'ed-addrow' }, [sel, add])
		]);
	}

	function saveProduct(e) {
		var p = S.prod, f = S.form, btn = e && e.currentTarget;
		var data = { name: f.name };
		if (p.price_edit && !p.only) { data.price = f.price; }
		if (!p.is_set) { data.allergens = f.allergens; }
		if (!p.is_set && f.skladTouched) { data.sklad = f.sklad; }
		if (!p.is_set && f.modsTouched) {
			data.mods = f.mods.map(function (m) { return m.k === 'own' ? { k: 'own', i: m.i } : { k: 'preset', id: m.id }; });
			data.mods_sig = p.mods_sig;
		}
		if (f.soldTouched) {
			if (f.sold === 'date' && !f.sdate) { toast('Wybierz dzień, w którym produkt jest wyprzedany.', true); return; }
			data.soldout = f.sold === 'always' ? { always: 1, dates: [] } : { always: 0, dates: f.sold === 'today' ? [S.boot.today] : (f.sold === 'date' ? [f.sdate] : []) };
		}
		if (btn) { btn.disabled = true; }
		api('save', { id: p.id, data: data }).then(function (d) {
			putRow(d.row);
			if (S.back === 'set' && S.boot.sets) {
				S.boot.sets.forEach(function (s) { if (s.id === d.row.id) { s.name = d.row.name; s.price = d.row.price; } });
			}
			S.form.dirty = false;
			toast('Zapisano.');
			history.back();
		}).catch(function (er) { if (btn) { btn.disabled = false; } toast(er.message, true); });
	}

	/* ---------- Zestaw dnia ---------- */
	function openSetTab() {
		if (!(S.boot.sets || []).length) { S.day = null; render(); return; }
		if (!S.set) { S.set = S.boot.sets[0].id; }
		if (!S.date) { S.date = S.boot.today; }
		loadDay();
	}
	function loadDay() {
		S.screen = 'set';
		S.tab = 'set';
		api('day', { set: S.set, date: S.date }).then(function (d) {
			S.day = d;
			S.owners = JSON.parse(JSON.stringify(d.owners));
			S.info = d.info || {};
			S.dirty = {};
			render();
		}).catch(function (e) { toast(e.message, true); });
	}
	function chooseSet(id) {
		if (id === S.set) { return true; }
		if (isDirtyDay() && !window.confirm('Masz niezapisane zmiany. Porzucić je?')) { return false; }
		S.set = id;
		loadDay();
		return true;
	}
	function chooseDay(d) {
		if (d === S.date) { return; }
		if (isDirtyDay() && !window.confirm('Masz niezapisane zmiany. Porzucić je?')) { return; }
		S.date = d;
		loadDay();
	}

	// Dania do pokazania: rozwijamy zestawy zagnieżdżone (danie zapisze się w ICH harmonogramie).
	function flat(ownerId, roleIn, depth) {
		var out = [];
		var own = S.owners[ownerId];
		if (!own) { return out; }
		own.items.forEach(function (it, idx) {
			var inf = S.info[it.product_id] || { name: '#' + it.product_id, thumb: '', role: '' };
			var role = roleIn || inf.role || (it.type === 'addon' ? 'Dodatek' : 'Danie');
			if (S.owners[it.product_id] && depth < 4) {
				var sub = flat(it.product_id, inf.role || roleIn, depth + 1);
				if (sub.length) { out = out.concat(sub); }
				else { out.push({ empty: true, owner: it.product_id, idx: -1, role: inf.role || role, name: inf.name }); }
			} else {
				out.push({ owner: ownerId, idx: idx, pid: it.product_id, role: role, name: inf.name, thumb: inf.thumb, sold: inf.sold, addon: it.type === 'addon' });
			}
		});
		return out;
	}
	function removeRow(r) {
		S.owners[r.owner].items.splice(r.idx, 1);
		S.dirty[r.owner] = 1;
		render();
	}

	function renderSet() {
		var body = h('div', { class: 'ed-body' });
		var w = h('div', { class: 'ed-wrap' });
		var d = S.day;
		// na stałe u góry tylko tytuł i zakładki – wybór zestawu i dni przewijają się z resztą
		// (przy kilku zestawach nagłówek zajmował cały ekran telefonu i lista nie dawała się przewinąć).
		var headKids = [topBar('Menu', ''), tabs()];
		if ((S.boot.sets || []).length) {
			w.appendChild(h('label', { class: 'ed-field', style: 'margin:12px 0 10px' }, [
				h('span', { text: 'Zestaw' }),
				h('select', { class: 'ed-in ed-setsel', onchange: function (e) { var v = parseInt(e.target.value, 10); if (!chooseSet(v)) { e.target.value = String(S.set); } } },
					S.boot.sets.map(function (st) { return h('option', { value: String(st.id), selected: st.id === S.set ? 'selected' : null, text: st.name + (st.price ? ' – ' + st.price : '') }); }))
			]));
			w.appendChild(h('div', { class: 'ed-days', style: 'margin-bottom:4px' }, S.boot.days.map(function (o) {
				var parts = o.label.split(' ');
				var mark = o.date === S.boot.today ? 'dziś' : '';
				return h('button', { type: 'button', class: o.date === S.date ? 'on' : '', 'aria-label': o.label, onclick: function () { chooseDay(o.date); } }, [
					h('small', { text: parts[0] }), h('b', { text: (parts[1] || '').split('.')[0] }), h('small', { text: mark })
				]);
			})));
		}
		if (!d) {
			w.appendChild(h('p', { class: 'ed-note', text: (S.boot.sets || []).length ? 'Wczytuję…' : 'Nie ma jeszcze żadnego zestawu (produktu z harmonogramem dań).' }));
		} else {
			var rows = flat(S.set, '', 0);
			w.appendChild(h('div', { class: 'ed-prev' }, [
				th(d.preview, 'ed-th'),
				h('div', { style: 'min-width:0' }, [h('small', { text: 'Klient zobaczy · ' + d.label + (isDirtyDay() ? ' (po zapisie)' : '') }), h('b', { text: isDirtyDay() ? rows.filter(function (r) { return !r.empty && !r.addon; }).map(function (r) { return r.name; }).join(' + ') : (d.title || '—') })])
			]));
			if (d.orders && d.orders.count) {
				w.appendChild(h('p', { class: 'ed-note warn', text: 'Na ' + d.label + ' są już złożone zamówienia z tym zestawem: ' + d.orders.count + '. Mają zapisany skład' + (d.orders.sklady.length ? ' (' + d.orders.sklady.join(' / ') + ')' : '') + ' – zmiana dania ich nie poprawi.' }));
			}
			if (!d.has_dish && !isDirtyDay()) {
				w.appendChild(h('p', { class: 'ed-note warn', text: 'Na ten dzień zestaw nie ma dania – klienci nie mogą go zamówić.' }));
			}
			var box = h('div', { class: 'ed-box', style: 'gap:0;padding:4px 14px' });
			rows.forEach(function (r) {
				if (r.empty) {
					box.appendChild(h('div', { class: 'ed-dish' }, [
						th('', 'ed-th'),
						h('span', { class: 'ed-rt' }, [h('span', { text: r.role || r.name }), h('b', { style: 'color:#7A3606', text: 'brak dania (' + r.name + ')' })]),
						h('button', { type: 'button', class: 'ed-btn sm', text: 'Wybierz', onclick: function () { openPicker({ mode: 'pick', owner: r.owner, idx: -1, role: r.role }); } })
					]));
					return;
				}
				box.appendChild(h('div', { class: 'ed-dish' }, [
					th(r.thumb, 'ed-th'),
					h('span', { class: 'ed-rt' }, [h('span', { text: r.role }), h('b', { text: r.name }), r.sold ? h('span', { class: 'ed-badge', text: 'wyprzedane' }) : null]),
					h('button', { type: 'button', class: 'ed-btn sm', text: 'Zmień', onclick: function () { openPicker({ mode: 'pick', owner: r.owner, idx: r.idx, role: r.role, like: r.pid }); } }),
					h('button', { type: 'button', class: 'ed-x', 'aria-label': 'Usuń ' + r.name + ' z tego dnia', html: ICON.x, onclick: function () { removeRow(r); } })
				]));
			});
			box.appendChild(h('button', { type: 'button', class: 'ed-add', html: ICON.plus + '<span>Dodaj danie</span>', onclick: function () {
				var last = rows.filter(function (r) { return !r.empty && r.owner === S.set; }).pop();
				openPicker({ mode: 'pick', owner: S.set, idx: -1, role: '', like: last ? last.pid : 0 });
			} }));
			w.appendChild(box);
			var src = S.owners[S.set] ? S.owners[S.set].src : 'rule';
			w.appendChild(h('p', { class: 'ed-note', text: src === 'day' ? 'Ten dzień jest ustawiony osobno – zastępuje regułę zestawu (dni tygodnia).' : (src === 'date' ? 'Ten dzień ma termin z konkretną datą z panelu. Zapis zastąpi go jednym terminem „tylko ten dzień”.' : 'Dania z reguły zestawu (dni tygodnia). Zapis zmieni tylko ten dzień – reguła zostaje.') }));
			w.appendChild(h('button', { type: 'button', class: 'ed-btn', style: 'width:100%;flex:none;margin:0 0 18px', html: ICON.copy + '<span>Kopiuj z innego dnia</span>', onclick: function () { S.sheet = { mode: 'copy' }; pushNav(); render(); } }));

			// Sam zestaw
			var sp = d.product;
			if (sp) {
				var soldDay = !!(sp.soldout.always || sp.soldout.dates.indexOf(S.date) >= 0);
				w.appendChild(h('h2', { class: 'ed-h', text: 'Sam zestaw' }));
				w.appendChild(h('div', { class: 'ed-box' }, [
					h('label', { class: 'ed-sw' }, [
						h('span', {}, [h('b', { text: 'Wyprzedane w tym dniu' }), h('small', { text: sp.soldout.always ? 'wyprzedane do odwołania – zmień w „Edytuj zestaw”' : d.label })]),
						h('input', { type: 'checkbox', checked: soldDay, disabled: !!sp.soldout.always, onchange: function (e) { setSoldDay(sp, e.target.checked); } })
					]),
					h('button', { type: 'button', class: 'ed-btn', style: 'flex:none;flex-direction:column;gap:0;padding:6px 12px', onclick: function () {
						if (isDirtyDay() && !window.confirm('Masz niezapisane zmiany dań. Porzucić je?')) { return; }
						openProduct(sp.id, 'set');
					} }, [h('b', { text: 'Edytuj zestaw' }), h('small', { style: 'font-size:12px;color:#6E645C', text: 'nazwa, cena, zdjęcie zastępcze' })])
				]));
			}
		}
		body.appendChild(w);
		return h('div', { class: 'ed-wrap', style: 'max-width:none' }, [
			head(headKids),
			h('div', { style: 'flex:1;min-height:0;display:flex;flex-direction:column' }, [body]),
			d ? h('div', { class: 'ed-foot' }, [h('div', { class: 'ed-wrap' }, [
				h('button', { type: 'button', class: 'ed-btn pri', disabled: !isDirtyDay(), text: isDirtyDay() ? 'Zapisz ' + d.label : 'Bez zmian', onclick: saveDay })
			])]) : null
		]);
	}

	function setSoldDay(sp, on) {
		var dates = sp.soldout.dates.filter(function (x) { return x !== S.date; });
		if (on) { dates.push(S.date); }
		api('save', { id: sp.id, data: { soldout: { always: 0, dates: dates } } }).then(function (r) {
			putRow(r.row);
			toast(on ? 'Zestaw wyprzedany na ' + S.day.label + '.' : 'Zestaw znów dostępny na ' + S.day.label + '.');
			loadDay();
		}).catch(function (e) { toast(e.message, true); loadDay(); });
	}

	function saveDay(e, confirmed) {
		var btn = e && e.currentTarget;
		var payload = {};
		Object.keys(S.dirty).forEach(function (o) {
			payload[o] = S.owners[o].items.map(function (it) { return { product_id: it.product_id, type: it.type, photo: it.photo ? 1 : 0 }; });
		});
		if (btn) { btn.disabled = true; }
		api('day_save', { set: S.set, date: S.date, owners: payload, confirm: confirmed ? 1 : 0 }).then(function (d) {
			if (d.confirm) {
				if (window.confirm(d.confirm)) { saveDay(null, true); } else if (btn) { btn.disabled = false; }
				return;
			}
			toast('Zapisano ' + S.day.label + '.');
			loadDay();
		}).catch(function (er) { if (btn) { btn.disabled = false; } toast(er.message, true); });
	}

	/* ---------- Okno od dołu: wybór dania / nowe danie / kopiowanie dnia ---------- */
	function openPicker(o) {
		S.sheet = { mode: o.mode, owner: o.owner, idx: o.idx, role: o.role || '', like: o.like || 0, q: '', list: null, nf: { name: '', short: '', allergens: [], cat: 0, file: null } };
		if (o.mode === 'pick' && !S.sheet.like && S.owners && S.owners[o.owner]) {
			// danie-wzór dla nowego dania: ostatnie danie tej grupy (ta sama rola – te same grupy modyfikacji)
			var it = S.owners[o.owner].items.filter(function (x) { return !S.owners[x.product_id]; }).pop();
			S.sheet.like = it ? it.product_id : 0;
		}
		pushNav();
		render();
		if (o.mode === 'pick') { loadDishes(''); }
	}
	var dishT = null;
	function loadDishes(q) {
		clearTimeout(dishT);
		dishT = setTimeout(function () {
			api('dishes', { q: q }).then(function (d) {
				if (!S.sheet || S.sheet.q !== q) { return; }
				S.sheet.list = d.dishes;
				var holder = root.querySelector('.ed-dishlist');
				if (holder) { fillDishes(holder); }
			}).catch(function (e) { toast(e.message, true); });
		}, q ? 300 : 0);
	}
	function fillDishes(holder) {
		holder.textContent = '';
		var L = S.sheet.list;
		if (!L) { holder.appendChild(h('p', { style: 'color:#6E645C', text: 'Wczytuję…' })); return; }
		holder.appendChild(h('small', { style: 'display:block;font-size:12px;color:#6E645C;text-transform:uppercase;letter-spacing:.06em;padding:8px 0 4px', text: S.sheet.q ? 'Wyniki' : 'Ostatnio w zestawach' }));
		if (!L.length) { holder.appendChild(h('p', { style: 'color:#6E645C', text: S.sheet.q ? 'Nic nie znaleziono – dodaj nowe danie niżej.' : 'Brak dań w zestawach – wyszukaj albo dodaj nowe.' })); }
		L.forEach(function (dsh) {
			holder.appendChild(h('button', { type: 'button', class: 'ed-row', onclick: function () { pickDish(dsh); } }, [
				th(dsh.thumb),
				h('span', { class: 'ed-rt' }, [h('b', { text: dsh.name }), h('span', { text: [dsh.role, dsh.last].filter(Boolean).join(' · ') })]),
				h('span', { class: 'ed-btn sm pri', style: 'pointer-events:none', text: 'Wybierz' })
			]));
		});
	}
	function pickDish(dsh) {
		var sh = S.sheet, own = S.owners[sh.owner];
		S.info[dsh.id] = { id: dsh.id, name: dsh.name, thumb: dsh.thumb, role: dsh.role, is_set: false, sold: false };
		if (sh.idx >= 0 && own.items[sh.idx]) {
			own.items[sh.idx] = { product_id: dsh.id, type: own.items[sh.idx].type, photo: own.items[sh.idx].photo };
		} else {
			own.items.push({ product_id: dsh.id, type: 'main', photo: 0 });
		}
		S.dirty[sh.owner] = 1;
		S.sheet = null;
		history.back(); // zdejmuje wpis okna z historii (popstate → render)
	}
	function createDish(btn) {
		var nf = S.sheet.nf, sh = S.sheet;
		if (!nf.name.trim()) { toast('Podaj nazwę dania.', true); return; }
		if (!nf.cat && !sh.like) { toast('Wybierz kategorię – od niej zależą terminy dostawy i widoczność w sklepie.', true); return; }
		btn.disabled = true;
		var like = sh.like;
		api('new_dish', { name: nf.name, short: nf.short, like: like, allergens: nf.allergens, cat: nf.cat }).then(function (d) {
			putRow(d.row);
			var done = function () {
				toast('Dodano „' + d.row.name + '”.');
				if (sh.mode === 'pick') { pickDish({ id: d.id, name: d.row.name, thumb: d.row.thumb, role: d.info ? d.info.role : '' }); }
				else { S.sheet = null; openProduct(d.id, 'list', true); } // wpis historii okna służy karcie produktu
			};
			if (nf.file) {
				return shrink(nf.file).then(function (b) { return api('photo', { id: d.id }, b); }).then(function (p) { putRow(p.row); d.row = p.row; done(); }).catch(function (e) { toast('Danie dodane, ale zdjęcie nie: ' + e.message, true); done(); });
			}
			done();
		}).catch(function (e) { btn.disabled = false; toast(e.message, true); });
	}

	function renderSheet() {
		var sh = S.sheet;
		var close = function () { history.back(); };
		var title = sh.mode === 'copy' ? 'Kopiuj dania z dnia…' : (sh.mode === 'new' ? 'Nowe danie' : (sh.role || 'Danie') + ' · ' + (S.day ? S.day.label : ''));
		var inner = h('div', { class: 'ed-sheet-in', style: 'flex:1;overflow-y:auto;padding:8px 16px 24px' });
		if (sh.mode === 'copy') {
			S.boot.days.forEach(function (o) {
				if (o.date === S.date) { return; }
				inner.appendChild(h('button', { type: 'button', class: 'ed-row', style: 'min-height:52px', onclick: function () { copyFrom(o); } }, [h('span', { class: 'ed-rt' }, [h('b', { text: o.label })])]));
			});
			inner.appendChild(h('p', { style: 'color:#6E645C;font-size:13px', text: 'Dania wybranego dnia zastąpią dania ' + (S.day ? S.day.label : '') + ' (przed zapisem możesz je jeszcze zmienić).' }));
		} else {
			if (sh.mode === 'pick') {
				inner.appendChild(h('label', { class: 'ed-search', style: 'margin:4px 0 4px' }, [
					h('span', { html: ICON.search }),
					h('input', { type: 'search', placeholder: 'Szukaj dania', 'aria-label': 'Szukaj dania', value: sh.q, oninput: function (e) { sh.q = e.target.value; sh.list = null; fillDishes(root.querySelector('.ed-dishlist')); loadDishes(sh.q.trim()); } })
				]));
				var holder = h('div', { class: 'ed-dishlist' });
				inner.appendChild(holder);
				fillDishes(holder);
			}
			inner.appendChild(newDishForm(sh));
		}
		return h('div', { class: 'ed-sheet', onclick: function (e) { if (e.target === e.currentTarget) { close(); } } }, [
			h('div', { role: 'dialog', 'aria-modal': 'true', 'aria-label': title }, [
				h('div', { style: 'flex:none;display:flex;align-items:center;gap:8px;padding:10px 12px 10px 18px;border-bottom:1px solid #E8E0D5' }, [
					h('b', { style: 'flex:1;font-family:\'Playfair Display\',Georgia,serif;font-size:19px', text: title }),
					icoBtn(ICON.x, 'Zamknij', close)
				]),
				inner
			])
		]);
	}

	function newDishForm(sh) {
		var nf = sh.nf;
		var likeName = sh.like && S.info[sh.like] ? S.info[sh.like].name : '';
		var phLabel = h('span', { text: nf.file ? 'Zdjęcie wybrane' : 'Zdjęcie' });
		var photo = h('label', { class: 'ed-btn', style: 'flex:none;width:84px;min-height:84px;flex-direction:column;gap:4px;font-size:12px;border-style:dashed;cursor:pointer;position:relative' }, [
			h('input', { type: 'file', accept: 'image/*', capture: 'environment', style: 'position:absolute;width:1px;height:1px;opacity:0', onchange: function (e) { nf.file = e.target.files && e.target.files[0] ? e.target.files[0] : null; phLabel.textContent = nf.file ? 'Zdjęcie wybrane' : 'Zdjęcie'; } }),
			h('span', { html: ICON.cam }), phLabel
		]);
		var kids = [
			h('b', { style: 'font-size:16px', text: sh.mode === 'new' ? 'Dane nowego dania' : 'Nowe danie' }),
			h('div', { style: 'display:flex;gap:12px;align-items:stretch' }, [
				photo,
				h('label', { class: 'ed-field', style: 'flex:1;margin:0;min-width:0' }, [h('span', { text: 'Nazwa' }), h('input', { type: 'text', class: 'ed-in', placeholder: 'np. Gulasz z kaszą', value: nf.name, oninput: function (e) { nf.name = e.target.value; } })])
			]),
			h('label', { class: 'ed-field', style: 'margin:0' }, [h('span', { text: 'Krótki opis' }), h('textarea', { class: 'ed-in', rows: 2, placeholder: 'Skład, dodatki…', value: nf.short, oninput: function (e) { nf.short = e.target.value; } })])
		];
		if (!sh.like) {
			kids.push(h('label', { class: 'ed-field', style: 'margin:0' }, [h('span', { text: 'Kategoria' }), h('select', { class: 'ed-in', onchange: function (e) { nf.cat = parseInt(e.target.value, 10) || 0; } }, [h('option', { value: '0', text: '— wybierz —' })].concat((S.boot.cats || []).map(function (c) { return h('option', { value: String(c.id), selected: nf.cat === c.id ? 'selected' : null, text: c.name }); })))]));
		}
		if ((S.boot.allergens || []).length) {
			kids.push(h('div', { class: 'ed-field', style: 'margin:0' }, [h('span', { text: 'Alergeny' }), h('div', { class: 'ed-alg' }, S.boot.allergens.map(function (a) {
				var on = nf.allergens.indexOf(a.id) >= 0;
				return h('button', { type: 'button', class: on ? 'on' : '', 'aria-pressed': on ? 'true' : 'false', text: a.name, onclick: function (e) {
					var i = nf.allergens.indexOf(a.id);
					if (i >= 0) { nf.allergens.splice(i, 1); e.currentTarget.className = ''; e.currentTarget.setAttribute('aria-pressed', 'false'); }
					else { nf.allergens.push(a.id); e.currentTarget.className = 'on'; e.currentTarget.setAttribute('aria-pressed', 'true'); }
				} });
			}))]));
		}
		kids.push(h('small', { style: 'color:#5C524A;line-height:1.4', text: likeName ? 'Kategoria, cena, rola, grupy modyfikacji i opakowanie – jak „' + likeName + '”. Dla klienta: tylko w zestawie, jeśli „' + likeName + '” też.' : 'Rola i modyfikacje – ustaw później w panelu, jeśli potrzebne.' }));
		kids.push(h('button', { type: 'button', class: 'ed-btn pri', style: 'flex:none', text: sh.mode === 'pick' ? 'Dodaj i wybierz na ' + (S.day ? S.day.label : '') : 'Utwórz danie', onclick: function (e) { createDish(e.currentTarget); } }));
		return h('div', { class: 'ed-box', style: 'margin-top:18px' }, kids);
	}

	function copyFrom(o) {
		api('day', { set: S.set, date: o.date }).then(function (d) {
			Object.keys(d.owners).forEach(function (oid) {
				if (!S.owners[oid]) { S.owners[oid] = { name: d.owners[oid].name, items: [], src: 'rule' }; }
				S.owners[oid].items = d.owners[oid].items.map(function (it) { return { product_id: it.product_id, type: it.type, photo: it.photo }; });
				S.dirty[oid] = 1;
			});
			Object.keys(d.info || {}).forEach(function (k) { S.info[k] = d.info[k]; });
			S.sheet = null;
			history.back();
			toast('Skopiowano z ' + o.label + ' – sprawdź i zapisz.');
		}).catch(function (e) { toast(e.message, true); });
	}

	/* ---------- Opisy – edytor sekcji (serwer: moduł 24) ---------- */
	var DE_LV = [{ v: 2, t: 'Duży' }, { v: 3, t: 'Średni' }, { v: 4, t: 'Mały' }, { v: 0, t: 'Bez nagłówka' }];
	var EMO = [
		['Dania', '🍲 🥣 🍝 🍛 🍜 🥗 🥘 🍖 🍗 🥩 🥓 🍔 🍟 🍕 🌭 🥪 🌮 🌯 🥙 🧆 🥟 🍣 🍤 🍳 🥚 🧀 🥞 🧇 🥐 🥖 🍞 🥨 🥯 🫓 🍚 🍙 🥠'],
		['Słodkie', '🍰 🎂 🧁 🥧 🍪 🍩 🍫 🍬 🍮 🍦 🍨 🍧 🍯 🥛'],
		['Warzywa i owoce', '🥦 🥕 🌽 🥔 🍅 🥒 🥬 🧅 🧄 🌶️ 🫑 🍄 🫘 🥜 🌰 🫛 🥑 🍆 🍎 🍐 🍋 🍊 🍓 🫐 🍒 🍇 🍌 🍑 🥝 🍍 🥥'],
		['Napoje', '☕ 🍵 🧋 🥤 🧃 🧉 🍺 🍷 🥂 🍹 💧 🧊'],
		['Znaki', '✅ ✔️ ❌ ⭐ 🌟 ✨ 🔥 ❤️ 💚 🧡 👍 💪 🎉 🎁 🆕 ⚠️ ❗ ❓ ℹ️ ➕ ➖ ▪️ • → ★ ☆ ✓ ✗ ½ °C'],
		['Kuchnia i dostawa', '🍽️ 🥄 🍴 🔪 🥢 👨‍🍳 👩‍🍳 ♨️ ⏱️ 🕒 📅 🚚 🛵 📦 🏠 🛍️ 💳 📞 🌿 🍃 🌱 🌾 🐟 🐄 🐖 🐔 🦐 ❄️ ☀️ 🌧️']
	];
	var EMO_KEY = 'rzd_ed_emo';
	function emoRecent() { try { var a = JSON.parse(localStorage.getItem(EMO_KEY) || '[]'); return Array.isArray(a) ? a.slice(0, 24) : []; } catch (e) { return []; } }
	function emoRemember(ch) {
		try { var a = emoRecent().filter(function (x) { return x !== ch; }); a.unshift(ch); localStorage.setItem(EMO_KEY, JSON.stringify(a.slice(0, 24))); } catch (e) { /* tryb prywatny – bez „Ostatnich” */ }
	}
	function plural(n, a, b, c) { if (n === 1) { return a; } var d = n % 10, dd = n % 100; return (d >= 2 && d <= 4 && (dd < 12 || dd > 14)) ? b : c; }
	function esc(t) { return String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
	function strip(x) { return String(x || '').replace(/<[^>]*>/g, '').replace(/&nbsp;|\s/g, ''); }
	function fmtDate(s) { var m = /^(\d{4})-(\d{2})-(\d{2}) (\d{2}:\d{2})/.exec(s || ''); return m ? m[3] + '.' + m[2] + '.' + m[1] + ', ' + m[4] : (s || ''); }
	function descDoc(kind) { return (kind === 'short' ? S.prod.short_doc : S.prod.desc_doc) || { ok: true, sections: [], sig: '', raw: '', text: '' }; }
	function descName(kind) { return kind === 'short' ? 'opis krótki' : 'opis długi'; }
	function newSec() { return { t: '', lv: 3, cols: 0, html: '' }; }

	/* Czyszczenie HTML (wklejanie, podgląd) – te same zasady co rzd_desc_clean() na serwerze,
	   który i tak czyści wszystko jeszcze raz przy zapisie. */
	var C_DROP = /^(SCRIPT|STYLE|IFRAME|OBJECT|EMBED|SVG|MATH|TEMPLATE|NOSCRIPT|HEAD|TITLE|META|LINK|IMG|PICTURE|VIDEO|AUDIO|SOURCE|CANVAS|INPUT|BUTTON|SELECT|TEXTAREA|FORM)$/;
	var C_BLOCK = /^(P|DIV|SECTION|ARTICLE|HEADER|FOOTER|ASIDE|MAIN|NAV|BLOCKQUOTE|PRE|FIGURE|FIGCAPTION|ADDRESS|H[1-6]|UL|OL|LI|HR|TABLE|THEAD|TBODY|TFOOT|TR|TD|TH|DL|DT|DD)$/;
	function cTxt(s) { return esc(String(s).replace(/[\r\n\t]+/g, ' ')); }
	function cHasBlock(el) { for (var c = el.firstChild; c; c = c.nextSibling) { if (c.nodeType === 1 && (C_BLOCK.test(c.nodeName) || cHasBlock(c))) { return true; } } return false; }
	function cTrim(s) { return String(s).replace(/^(\s|&nbsp;|<br>)+|(\s|&nbsp;|<br>)+$/g, ''); }
	function cOne(c) { var sp = c.ownerDocument.createElement('span'); sp.appendChild(c.cloneNode(true)); return sp; }
	function cInline(n) {
		var o = '';
		for (var c = n.firstChild; c; c = c.nextSibling) {
			if (c.nodeType === 3) { o += cTxt(c.nodeValue); continue; }
			if (c.nodeType !== 1) { continue; }
			var t = c.nodeName;
			if (C_DROP.test(t)) { continue; }
			if (/^(B|STRONG|EM|I)$/.test(t)) {
				var x = cInline(c), tg = /^(B|STRONG)$/.test(t) ? 'strong' : 'em';
				if (x.replace(/<br>/g, '').trim()) { o += '<' + tg + '>' + x + '</' + tg + '>'; }
			} else if (t === 'BR' || t === 'HR') { o += '<br>'; }
			else if (t === 'LI') { o += cInline(c) + '<br>'; }
			else if (C_BLOCK.test(t)) { var y = cInline(c); if (y.trim()) { o += y + '<br>'; } }
			else { o += cInline(c); }
		}
		return o;
	}
	function cParas(s) {
		return String(s).split(/(?:<br>\s*){2,}/).map(cTrim).filter(function (x) { return strip(x); }).map(function (x) { return '<p>' + x + '</p>'; }).join('');
	}
	function cList(el) {
		var o = '';
		for (var c = el.firstChild; c; c = c.nextSibling) {
			if (c.nodeType === 3) { if (c.nodeValue.trim()) { o += '<li>' + cTxt(c.nodeValue.trim()) + '</li>'; } continue; }
			if (c.nodeType !== 1) { continue; }
			var t = c.nodeName;
			if (t === 'UL' || t === 'OL') { var x = cList(c), tl = t.toLowerCase(); if (x) { o += '<li><' + tl + '>' + x + '</' + tl + '></li>'; } continue; }
			var y = t === 'LI' ? cLi(c) : cTrim(cInline(cOne(c)));
			if (y.replace(/<\/?(?!ul\b|ol\b|li\b)[a-z]+[^>]*>/gi, '').trim()) { o += '<li>' + y + '</li>'; }
		}
		return o;
	}
	function cLi(li) {
		var o = '', buf = '';
		for (var c = li.firstChild; c; c = c.nextSibling) {
			if (c.nodeType === 1 && (c.nodeName === 'UL' || c.nodeName === 'OL')) {
				o += cTrim(buf); buf = '';
				var x = cList(c), tl = c.nodeName.toLowerCase();
				if (x) { o += '<' + tl + '>' + x + '</' + tl + '>'; }
				continue;
			}
			buf += cInline(cOne(c));
		}
		return o + cTrim(buf);
	}
	function cBlock(n) {
		var o = '', buf = '';
		var flush = function () { o += cParas(buf); buf = ''; };
		for (var c = n.firstChild; c; c = c.nextSibling) {
			if (c.nodeType === 3) { buf += cTxt(c.nodeValue); continue; }
			if (c.nodeType !== 1) { continue; }
			var t = c.nodeName;
			if (C_DROP.test(t)) { continue; }
			if (t === 'UL' || t === 'OL') { flush(); var x = cList(c), tl = t.toLowerCase(); if (x) { o += '<' + tl + '>' + x + '</' + tl + '>'; } }
			else if (t === 'LI') { flush(); var l = cLi(c); if (l.trim()) { o += '<ul><li>' + l + '</li></ul>'; } }
			else if (t === 'HR') { flush(); o += '<hr>'; }
			else if (t === 'BR') { buf += '<br>'; }
			else if (C_BLOCK.test(t)) {
				flush();
				if (cHasBlock(c)) { o += cBlock(c); }
				else {
					var y = cTrim(cInline(c));
					if (/^H[1-6]$/.test(t)) { if (strip(y)) { o += '<p><strong>' + y + '</strong></p>'; } } else { o += cParas(y); }
				}
			} else { buf += cInline(cOne(c)); }
		}
		flush();
		return o;
	}
	function deClean(html) {
		if (!String(html || '').trim()) { return ''; }
		var doc = new DOMParser().parseFromString('<!doctype html><body>' + html, 'text/html');
		return cBlock(doc.body);
	}
	function txtToHtml(t) {
		return String(t || '').replace(/\r\n?/g, '\n').split(/\n{2,}/).map(function (p) { return p.trim() ? '<p>' + esc(p.trim()).replace(/\n/g, '<br>') + '</p>' : ''; }).join('');
	}
	function deBuild() {
		var D = S.de, out = '';
		D.sections.forEach(function (s) {
			var t = String(s.t || '').trim(), lv = s.lv;
			if (D.kind === 'short' && lv === 2) { lv = 3; }
			if (!t) { lv = 0; }
			var body = deClean(s.html || '');
			if (!lv && !body) { return; }
			out += '<section class="rzd-op-s' + (s.cols ? ' rzd-op-2k' : '') + '">' + (lv ? '<h' + lv + ' class="rzd-op-h">' + esc(t) + '</h' + lv + '>' : '') + '<div class="rzd-op-t">' + body + '</div></section>';
		});
		return out ? '<div class="rzd-opis">' + out + '</div>' : '';
	}
	// Podgląd w ramce bez skryptów (sandbox) z CSS sklepu – opis z panelu nie wykona żadnego kodu.
	function previewFrame(html) {
		var f = h('iframe', { class: 'ed-pv', sandbox: 'allow-same-origin', title: 'Podgląd opisu' });
		f.srcdoc = '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
			+ (C.opisCss ? '<link rel="stylesheet" href="' + String(C.opisCss).replace(/"/g, '%22') + '">' : '')
			+ '<style>html,body{margin:0;background:#fff}body{padding:12px 14px;font-size:16px;color:#333;font-family:Lato,"Segoe UI",sans-serif;overflow-wrap:anywhere}img{max-width:100%;height:auto}</style></head><body>'
			+ (html || '') + '</body></html>';
		var fit = function () { try { var d = f.contentDocument; if (d && d.documentElement) { f.style.height = Math.max(60, d.documentElement.scrollHeight) + 'px'; } } catch (e) { /* ignore */ } };
		f.addEventListener('load', function () { fit(); setTimeout(fit, 400); });
		return f;
	}

	// Karta produktu: podsumowanie opisu + przycisk otwierający edytor.
	function descBox(kind) {
		var doc = descDoc(kind), empty = doc.ok && !doc.sections.length, sum;
		if (!doc.ok) {
			sum = [h('span', { class: 'ed-badge gray', style: 'display:inline-block;margin:0 6px 4px 0', text: 'własne formatowanie' }), doc.text || ''];
		} else if (empty) {
			sum = ['Brak opisu.'];
		} else {
			var heads = doc.sections.map(function (x) { return x.lv && x.t ? x.t : null; }).filter(Boolean);
			sum = [h('b', { text: doc.sections.length + ' ' + plural(doc.sections.length, 'sekcja', 'sekcje', 'sekcji') + (heads.length ? ': ' + heads.join(' · ') : '') }), h('br'), doc.text || ''];
		}
		return h('div', { class: 'ed-box' }, [
			h('div', {}, [h('b', { text: kind === 'short' ? 'Krótki opis' : 'Pełny opis' }), h('small', { class: 'ed-sub', text: kind === 'short' ? 'Na liście, pod nazwą dania.' : 'Na stronie produktu i w „Pełny opis” na liście.' })]),
			h('div', { class: 'ed-dsum' }, sum),
			h('button', { type: 'button', class: 'ed-btn', style: 'flex:none', text: (empty ? 'Dodaj ' : 'Edytuj ') + descName(kind), onclick: function () { deOpen(kind); } })
		]);
	}

	function deOpen(kind) {
		var doc = descDoc(kind);
		S.de = { kind: kind, sig: doc.sig, locked: !doc.ok, force: false, sections: JSON.parse(JSON.stringify(doc.sections || [])), dirty: false, preview: false, emo: null, emoCat: 0, copy: null, bkOpen: '', el: null, last: null };
		if (!S.de.locked && !S.de.sections.length) { S.de.sections.push(newSec()); }
		try { document.execCommand('defaultParagraphSeparator', false, 'p'); } catch (e) { /* starsze przeglądarki */ }
		pushNav();
		deRender();
	}
	function deClose(fromPop) {
		var D = S.de;
		if (!D) { return; }
		if (D.dirty && !window.confirm('Masz niezapisane zmiany w opisie. Porzucić je?')) {
			if (fromPop) { pushNav(); }
			return;
		}
		if (D.el && D.el.parentNode) { D.el.parentNode.removeChild(D.el); }
		S.de = null;
		deRange = null;
		render();
	}
	function deSync() {
		var D = S.de;
		if (!D || !D.el) { return; }
		Array.prototype.forEach.call(D.el.querySelectorAll('.ed-rich'), function (r) {
			var i = parseInt(r.getAttribute('data-i'), 10);
			if (D.sections[i]) { D.sections[i].html = r.innerHTML; }
		});
	}
	function deTouch() { if (S.de) { S.de.dirty = true; } }

	// Zaznaczenie w polu treści – zapamiętane, bo przyciski paska i okno emotek je „zabierają”.
	var deRange = null;
	document.addEventListener('selectionchange', function () {
		if (!S.de) { return; }
		var sel = window.getSelection();
		if (!sel || !sel.rangeCount) { return; }
		var n = sel.anchorNode, el = n && (n.nodeType === 1 ? n : n.parentNode);
		var r = el && el.closest ? el.closest('.ed-rich') : null;
		if (r) { deRange = { el: r, range: sel.getRangeAt(0).cloneRange() }; }
	});
	function deEndRange(rich) {
		var r = document.createRange(), n = rich;
		while (n.lastChild && n.lastChild.nodeType === 1 && /^(P|LI|UL|OL|STRONG|EM|B|I)$/.test(n.lastChild.nodeName)) { n = n.lastChild; }
		r.selectNodeContents(n);
		r.collapse(false);
		return r;
	}
	function deFocus(rich) {
		var sel = window.getSelection();
		// Kursor już w tym polu (przycisk paska nie zabrał fokusu) – nie ruszamy zaznaczenia,
		// inaczej przeglądarka gubi stan „pisz pogrubione / już nie” ustawiony przyciskiem.
		if (document.activeElement === rich && sel && sel.rangeCount && rich.contains(sel.getRangeAt(0).startContainer)) { return; }
		rich.focus();
		var r = (deRange && deRange.el === rich && rich.contains(deRange.range.startContainer)) ? deRange.range : deEndRange(rich);
		sel.removeAllRanges();
		sel.addRange(r);
	}
	function deCmd(rich, cmd) {
		deFocus(rich);
		try { document.execCommand('styleWithCSS', false, false); } catch (e) { /* ignore */ }
		document.execCommand(cmd, false); // bez 3. argumentu – inaczej Chrome dopisuje linii id="null"
		rich.dispatchEvent(new Event('input'));
	}
	// Emotka do treści bez otwierania klawiatury telefonu (bez focus).
	function deInsertText(rich, txt) {
		var r = (deRange && deRange.el === rich && rich.contains(deRange.range.startContainer)) ? deRange.range : deEndRange(rich);
		r.deleteContents();
		var tn = document.createTextNode(txt);
		r.insertNode(tn);
		r.setStartAfter(tn);
		r.collapse(true);
		deRange = { el: rich, range: r.cloneRange() };
		rich.dispatchEvent(new Event('input'));
	}
	function dePaste(e) {
		var cd = e.clipboardData || window.clipboardData;
		if (!cd) { return; }
		e.preventDefault();
		var html = cd.getData('text/html'), txt = cd.getData('text/plain');
		var out = html ? deClean(html) : txtToHtml(txt);
		if (out) { document.execCommand('insertHTML', false, out); }
	}
	function deMove(i, d) {
		var D = S.de, a = D.sections;
		deSync();
		a.splice(i + d, 0, a.splice(i, 1)[0]);
		deTouch();
		deRender();
	}
	function tbBtn(html, label, fn) {
		return h('button', { type: 'button', html: html, 'aria-label': label, title: label, onmousedown: function (e) { e.preventDefault(); }, onclick: fn });
	}

	function deRender() {
		var D = S.de;
		if (!D) { return; }
		var ob = D.el && D.el.querySelector('.ed-de-body'), st = ob ? ob.scrollTop : 0;
		var el = h('div', { class: 'ed-de', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Edycja: ' + descName(D.kind) });
		el.appendChild(h('div', { class: 'ed-head' }, [h('div', { class: 'ed-wrap' }, [h('div', { class: 'ed-top' }, [
			icoBtn(ICON.back, 'Wróć', function () { history.back(); }),
			h('h1', { style: 'font-size:20px', text: D.kind === 'short' ? 'Krótki opis' : 'Pełny opis' }),
			!D.locked ? h('button', { type: 'button', class: 'ed-btn sm', text: D.preview ? 'Edycja' : 'Podgląd', onclick: function () { deSync(); D.preview = !D.preview; D.emo = null; deRender(); } }) : null
		])])]));
		var body = h('div', { class: 'ed-body ed-de-body' }), w = h('div', { class: 'ed-wrap' });
		body.appendChild(w);
		if (D.locked) { deLockedView(w); }
		else if (D.preview) {
			var html = deBuild();
			w.appendChild(h('p', { class: 'ed-note', style: 'margin-top:12px', text: 'Tak opis zobaczy klient (szerokość zależy od ekranu; ' + (D.kind === 'short' ? 'na liście' : 'na stronie produktu') + ' może dojść styl motywu).' }));
			w.appendChild(html ? previewFrame(html) : h('p', { class: 'ed-note', text: 'Opis jest pusty.' }));
		} else { deEditView(w); }
		if (!D.preview) { deBackupsView(w); }
		el.appendChild(h('div', { style: 'flex:1;min-height:0;display:flex;flex-direction:column' }, [body]));
		el.appendChild(h('div', { class: 'ed-foot' }, [h('div', { class: 'ed-wrap' }, D.locked
			? [h('button', { type: 'button', class: 'ed-btn', text: 'Zamknij', onclick: function () { history.back(); } })]
			: [h('button', { type: 'button', class: 'ed-btn', text: 'Anuluj', onclick: function () { history.back(); } }),
				h('button', { type: 'button', class: 'ed-btn pri', text: 'Zapisz opis', onclick: deSave })])]));
		if (D.emo !== null && !D.preview && !D.locked) { el.appendChild(emoPanel()); }
		if (D.copy) { el.appendChild(deCopySheet()); }
		if (D.el && D.el.parentNode) { D.el.parentNode.replaceChild(el, D.el); } else { root.appendChild(el); }
		D.el = el;
		body.scrollTop = st;
	}

	function deLockedView(w) {
		var D = S.de, doc = descDoc(D.kind);
		w.appendChild(h('p', { class: 'ed-note warn', style: 'margin-top:12px', text: 'Tego opisu nie da się odczytać w edytorze – ma własne style albo elementy, których edytor nie obsługuje. Możesz go zostawić (w sklepie nic się nie zmieni) albo utworzyć nowy opis. Obecny zostanie wtedy zachowany jako kopia „Oryginał” – do przywrócenia.' }));
		w.appendChild(h('small', { class: 'ed-sub', style: 'margin:0 0 6px', text: 'Obecny opis:' }));
		w.appendChild(previewFrame(doc.raw));
		w.appendChild(h('div', { style: 'display:flex;flex-direction:column;gap:10px;margin:16px 0 18px' }, [
			h('button', { type: 'button', class: 'ed-btn pri', style: 'flex:none', text: 'Utwórz nowy opis', onclick: function () {
				if (!window.confirm('Utworzyć nowy opis w edytorze? Po zapisie zastąpi obecny (obecny zostanie w kopii „Oryginał”).')) { return; }
				D.locked = false; D.force = true; D.sections = [newSec()]; deTouch(); deRender();
			} }),
			h('button', { type: 'button', class: 'ed-btn', style: 'flex:none', html: ICON.copy + '<span>Nowy opis – kopia z innego produktu</span>', onclick: deOpenCopy }),
			S.prod.edit_url ? h('a', { class: 'ed-btn', style: 'flex:none', href: S.prod.edit_url, text: 'Otwórz w panelu' }) : null
		]));
	}

	function deEditView(w) {
		var D = S.de, lvs = D.kind === 'short' ? DE_LV.filter(function (o) { return o.v !== 2; }) : DE_LV;
		if (D.force) { w.appendChild(h('p', { class: 'ed-note', style: 'margin-top:12px', text: 'Nowy opis zastąpi obecny po zapisie. Obecny trafi do kopii „Oryginał”.' })); }
		D.sections.forEach(function (s, i) {
			var seg = h('div', { class: 'ed-seg', style: 'grid-template-columns:repeat(' + lvs.length + ',1fr)' }, lvs.map(function (o) {
				return h('button', { type: 'button', class: s.lv === o.v ? 'on' : '', 'aria-pressed': s.lv === o.v ? 'true' : 'false', text: o.t, onclick: function () { deSync(); s.lv = o.v; deTouch(); deRender(); } });
			}));
			var head = s.lv ? h('input', { type: 'text', class: 'ed-in ed-sec-h ed-h' + (D.kind === 'short' && s.lv === 2 ? 3 : s.lv), value: s.t, maxlength: '200', placeholder: 'Nazwa sekcji, np. O produkcie', 'aria-label': 'Nagłówek sekcji ' + (i + 1),
				oninput: function (e) { s.t = e.target.value; deTouch(); }, onfocus: function (e) { D.last = { type: 'h', i: i, el: e.target }; } }) : null;
			var rich = h('div', { class: 'ed-rich' + (s.cols ? ' k2' : ''), contenteditable: 'true', role: 'textbox', 'aria-multiline': 'true', 'aria-label': 'Treść sekcji ' + (i + 1), 'data-ph': 'Treść – wpisz albo wklej tekst', 'data-i': String(i) });
			rich.innerHTML = s.html || ''; // treść już oczyszczona (serwer / deClean)
			rich.addEventListener('input', function () { s.html = rich.innerHTML; deTouch(); });
			rich.addEventListener('focus', function () { D.last = { type: 'r', i: i, el: rich }; });
			rich.addEventListener('paste', dePaste);
			var tb = h('div', { class: 'ed-tb' }, [
				tbBtn('<b>B</b>', 'Pogrubienie', function () { deCmd(rich, 'bold'); }),
				tbBtn('<i>I</i>', 'Kursywa', function () { deCmd(rich, 'italic'); }),
				tbBtn('<span aria-hidden="true">•&#8202;≡</span>', 'Lista punktowana', function () { deCmd(rich, 'insertUnorderedList'); }),
				tbBtn('<span aria-hidden="true">1.≡</span>', 'Lista numerowana', function () { deCmd(rich, 'insertOrderedList'); }),
				tbBtn('<span aria-hidden="true">―</span>', 'Linia pozioma', function () { deCmd(rich, 'insertHorizontalRule'); }),
				tbBtn('<span aria-hidden="true">😀</span>', 'Emotki', function () { deToggleEmo(i); })
			]);
			w.appendChild(h('div', { class: 'ed-box ed-sec' }, [
				h('div', { class: 'ed-sec-ctl' }, [
					h('b', { style: 'flex:1', text: 'Sekcja ' + (i + 1) }),
					miniBtn('↑', 'Sekcja wyżej', function () { deMove(i, -1); }, i === 0),
					miniBtn('↓', 'Sekcja niżej', function () { deMove(i, 1); }, i === D.sections.length - 1),
					miniBtn('✕', 'Usuń sekcję', function () {
						deSync();
						if ((String(s.t || '').trim() || strip(s.html)) && !window.confirm('Usunąć sekcję' + (s.t ? ' „' + s.t + '”' : '') + ' razem z treścią?')) { return; }
						D.sections.splice(i, 1); deTouch(); deRender();
					})
				]),
				h('div', { class: 'ed-field', style: 'margin:0' }, [h('span', { text: 'Nagłówek' }), seg]),
				head, tb, rich,
				h('label', { class: 'ed-sw', style: 'min-height:36px' }, [
					h('small', { style: 'font-size:14px;color:#4A4039', text: 'Listy w dwóch kolumnach (na telefonie klienta – w jednej)' }),
					h('input', { type: 'checkbox', checked: !!s.cols, onchange: function (e) { deSync(); s.cols = e.target.checked ? 1 : 0; deTouch(); deRender(); } })
				])
			]));
		});
		w.appendChild(h('button', { type: 'button', class: 'ed-add', html: ICON.plus + '<span>Dodaj sekcję</span>', onclick: function () {
			deSync();
			D.sections.push(newSec());
			deTouch();
			deRender();
			var secs = D.el.querySelectorAll('.ed-sec'), last = secs[secs.length - 1];
			if (last) { last.scrollIntoView({ block: 'start' }); var inp = last.querySelector('.ed-sec-h'); if (inp) { inp.focus(); } }
		} }));
		w.appendChild(h('button', { type: 'button', class: 'ed-btn', style: 'width:100%;flex:none;margin:6px 0 18px', html: ICON.copy + '<span>Kopiuj z innego produktu</span>', onclick: deOpenCopy }));
	}

	/* Emotki – własne okienko (na komputerze nie ma ich pod ręką). */
	function deToggleEmo(i) {
		var D = S.de, old = D.el.querySelector('.ed-emo');
		if (old) { old.parentNode.removeChild(old); if (D.emo === i) { D.emo = null; return; } }
		D.emo = i;
		D.el.appendChild(emoPanel());
	}
	function emoPanel() {
		var D = S.de;
		var cats = EMO.map(function (c) { return [c[0], c[1].split(' ')]; });
		var rec = emoRecent();
		if (rec.length) { cats.unshift(['Ostatnie', rec]); }
		if (D.emoCat >= cats.length) { D.emoCat = 0; }
		var grid = h('div', { class: 'ed-emo-grid' });
		var fill = function () {
			grid.textContent = '';
			cats[D.emoCat][1].forEach(function (ch) {
				grid.appendChild(h('button', { type: 'button', text: ch, 'aria-label': ch, onmousedown: function (e) { e.preventDefault(); }, onclick: function () { deEmoInsert(ch); } }));
			});
		};
		var tabsEl = h('div', { class: 'ed-emo-tabs' }, cats.map(function (c, ci) {
			return h('button', { type: 'button', class: ci === D.emoCat ? 'on' : '', text: c[0], onmousedown: function (e) { e.preventDefault(); }, onclick: function () {
				D.emoCat = ci;
				Array.prototype.forEach.call(tabsEl.children, function (b, bi) { b.className = bi === ci ? 'on' : ''; });
				fill();
			} });
		}));
		fill();
		return h('div', { class: 'ed-emo', role: 'dialog', 'aria-label': 'Emotki' }, [
			h('div', { class: 'ed-emo-top' }, [h('b', { text: 'Emotki – dotknij, żeby wstawić (sekcja ' + (D.emo + 1) + ')' }), icoBtn(ICON.x, 'Zamknij emotki', function () { deToggleEmo(D.emo); })]),
			tabsEl, grid
		]);
	}
	function deEmoInsert(ch) {
		var D = S.de, i = D.emo, L = D.last;
		if (i === null || !D.sections[i]) { return; }
		emoRemember(ch);
		if (L && L.type === 'h' && L.i === i && L.el && document.body.contains(L.el)) { // ostatnio w nagłówku tej sekcji
			var inp = L.el, a = inp.selectionStart !== null ? inp.selectionStart : inp.value.length, b = inp.selectionEnd !== null ? inp.selectionEnd : a;
			inp.value = inp.value.slice(0, a) + ch + inp.value.slice(b);
			try { inp.setSelectionRange(a + ch.length, a + ch.length); } catch (e) { /* ignore */ }
			D.sections[i].t = inp.value;
			deTouch();
			return;
		}
		var rich = D.el.querySelector('.ed-rich[data-i="' + i + '"]');
		if (rich) { deInsertText(rich, ch); }
	}

	/* Kopiuj z innego produktu */
	function deOpenCopy() {
		var D = S.de;
		deSync();
		D.copy = { list: null, q: '' };
		pushNav();
		deRender();
		api('desc_list', { kind: D.kind, id: S.prod.id }).then(function (d) {
			if (S.de && S.de.copy) { S.de.copy.list = d.list; deFillCopy(); }
		}).catch(function (e) { toast(e.message, true); });
	}
	function deCopySheet() {
		var D = S.de, c = D.copy, holder = h('div', { class: 'ed-copylist' });
		var inner = h('div', { class: 'ed-sheet-in', style: 'flex:1;overflow-y:auto;padding:8px 16px 24px' }, [
			h('label', { class: 'ed-search', style: 'margin:4px 0 8px' }, [h('span', { html: ICON.search }), h('input', { type: 'search', placeholder: 'Szukaj produktu', 'aria-label': 'Szukaj produktu', value: c.q, oninput: function (e) { c.q = e.target.value; deFillCopy(holder); } })]),
			holder
		]);
		deFillCopy(holder);
		var title = 'Kopiuj ' + descName(D.kind) + ' z…';
		return h('div', { class: 'ed-sheet', onclick: function (e) { if (e.target === e.currentTarget) { history.back(); } } }, [
			h('div', { role: 'dialog', 'aria-modal': 'true', 'aria-label': title }, [
				h('div', { style: 'flex:none;display:flex;align-items:center;gap:8px;padding:10px 12px 10px 18px;border-bottom:1px solid #E8E0D5' }, [
					h('b', { style: 'flex:1;font-family:\'Playfair Display\',Georgia,serif;font-size:19px', text: title }),
					icoBtn(ICON.x, 'Zamknij', function () { history.back(); })
				]),
				inner
			])
		]);
	}
	function deFillCopy(holder) {
		holder = holder || (S.de && S.de.el && S.de.el.querySelector('.ed-copylist'));
		if (!holder || !S.de || !S.de.copy) { return; }
		var c = S.de.copy;
		holder.textContent = '';
		if (!c.list) { holder.appendChild(h('p', { style: 'color:#6E645C', text: 'Wczytuję…' })); return; }
		var q = fold(c.q.trim());
		var L = c.list.filter(function (x) { return !q || fold(x.name).indexOf(q) >= 0; });
		if (!L.length) { holder.appendChild(h('p', { class: 'ed-note', text: c.list.length ? 'Nic nie znaleziono.' : 'Żaden inny produkt nie ma jeszcze takiego opisu, który edytor potrafi odczytać.' })); return; }
		L.forEach(function (x) {
			holder.appendChild(h('button', { type: 'button', class: 'ed-row', onclick: function () { dePickCopy(x); } }, [
				th(x.thumb),
				h('span', { class: 'ed-rt' }, [h('b', { text: x.name }), h('span', { text: x.n + ' ' + plural(x.n, 'sekcja', 'sekcje', 'sekcji') })]),
				h('span', { class: 'ed-btn sm pri', style: 'pointer-events:none', text: 'Kopiuj' })
			]));
		});
	}
	function dePickCopy(x) {
		var D = S.de;
		var has = !D.locked && D.sections.some(function (s) { return String(s.t || '').trim() || strip(s.html); });
		if (D.locked && !window.confirm('Utworzyć nowy opis na podstawie „' + x.name + '”? Po zapisie zastąpi obecny (obecny zostanie w kopii „Oryginał”).')) { return; }
		if (has && !window.confirm('Zastąpić obecne sekcje opisem z „' + x.name + '”?')) { return; }
		api('desc_get', { id: x.id, kind: D.kind }).then(function (d) {
			if (S.de !== D) { return; }
			if (D.locked) { D.locked = false; D.force = true; }
			D.sections = d.sections.length ? d.sections : [newSec()];
			D.preview = false;
			deTouch();
			history.back(); // zamyka okno wyboru (popstate → deRender)
			toast('Skopiowano z „' + x.name + '” – przerób i zapisz.');
		}).catch(function (e) { toast(e.message, true); });
	}

	/* Kopie opisu: oryginał (sprzed edytora) i poprzednia wersja */
	function deBackupsView(w) {
		var D = S.de, bk = (S.prod.backups || {})[D.kind === 'short' ? 'short' : 'long'] || {};
		var keys = ['orig', 'prev'].filter(function (k) { return bk[k]; });
		if (!keys.length) { return; }
		var box = h('div', { class: 'ed-box', style: 'margin-top:6px' }, [h('div', {}, [h('b', { text: 'Kopie opisu' }), h('small', { class: 'ed-sub', text: 'Przywrócenie zmienia opis w sklepie od razu; obecny trafia wtedy do „Poprzednia wersja”.' })])]);
		keys.forEach(function (k) {
			var e = bk[k], open = D.bkOpen === k;
			box.appendChild(h('div', { class: 'ed-bk' }, [
				h('div', {}, [h('b', { text: k === 'orig' ? 'Oryginał (sprzed edytora)' : 'Poprzednia wersja' }), h('small', { class: 'ed-sub', text: fmtDate(e.date) + (e.user ? ' · ' + e.user : '') })]),
				h('div', { class: 'ed-bk-row' }, [
					h('button', { type: 'button', class: 'ed-btn sm', text: open ? 'Ukryj podgląd' : 'Podgląd', onclick: function () { deSync(); D.bkOpen = open ? '' : k; deRender(); } }),
					h('button', { type: 'button', class: 'ed-btn sm', text: 'Przywróć', onclick: function () { deBackup(k, 'restore'); } }),
					h('button', { type: 'button', class: 'ed-btn sm', text: 'Usuń', onclick: function () { deBackup(k, 'delete'); } })
				]),
				open ? previewFrame(e.html) : null
			]));
		});
		w.appendChild(box);
	}
	function deApplyProduct(pd) {
		if (!pd || !S.prod) { return; }
		S.prod.short_doc = pd.short_doc;
		S.prod.desc_doc = pd.desc_doc;
		S.prod.backups = pd.backups;
	}
	function deBackup(which, op) {
		var D = S.de;
		if (op === 'restore') {
			if (D.dirty && !window.confirm('Niezapisane zmiany w edytorze przepadną. Kontynuować?')) { return; }
			if (!window.confirm('Przywrócić tę kopię? Opis w sklepie zmieni się od razu, a obecny trafi do „Poprzednia wersja”.')) { return; }
		} else if (!window.confirm('Usunąć tę kopię na stałe?')) { return; }
		api('desc_backup', { id: S.prod.id, kind: D.kind, which: which, op: op }).then(function (d) {
			if (S.de !== D) { return; }
			putRow(d.row);
			deApplyProduct(d.product);
			if (op === 'restore') {
				var doc = descDoc(D.kind);
				D.sig = doc.sig; D.locked = !doc.ok; D.force = false; D.preview = false; D.dirty = false; D.emo = null;
				D.sections = JSON.parse(JSON.stringify(doc.sections || []));
				if (!D.locked && !D.sections.length) { D.sections.push(newSec()); }
				toast('Przywrócono opis.');
			} else {
				toast('Kopia usunięta.');
			}
			D.bkOpen = '';
			deRender();
		}).catch(function (e) { toast(e.message, true); });
	}

	function deSave(e) {
		var D = S.de, btn = e && e.currentTarget;
		deSync();
		if (!deBuild() && !window.confirm('Opis będzie pusty – klient go nie zobaczy. Zapisać?')) { return; }
		var data = {};
		data[D.kind === 'short' ? 'short_doc' : 'desc_doc'] = {
			sections: D.sections.map(function (s) { return { t: String(s.t || ''), lv: s.lv, cols: s.cols ? 1 : 0, html: deClean(s.html || '') }; }),
			sig: D.sig,
			force: D.force ? 1 : 0
		};
		if (btn) { btn.disabled = true; }
		api('save', { id: S.prod.id, data: data }).then(function (d) {
			putRow(d.row);
			deApplyProduct(d.product);
			D.dirty = false;
			toast('Opis zapisany.');
			history.back(); // popstate → deClose → karta produktu z nowym podsumowaniem
		}).catch(function (er) { if (btn) { btn.disabled = false; } toast(er.message, true); });
	}

	/* ---------- Start ---------- */
	api('boot', {}).then(function (d) {
		S.boot = d;
		render();
	}).catch(function (e) {
		root.textContent = '';
		root.appendChild(h('p', { class: 'ed-note warn', style: 'margin:30px 16px', text: e.message }));
	});
	window.addEventListener('beforeunload', function (e) {
		if ((S.form && S.form.dirty) || isDirtyDay() || (S.de && S.de.dirty)) { e.preventDefault(); e.returnValue = ''; }
	});
})();
