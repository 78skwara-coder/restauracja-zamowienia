/* Restauracja – Panel restauracji: Terminy, zakładki Grupy / Godziny w dniach tygodnia / Okna dostaw (2.45.0). */
(function () {
	'use strict';
	var K = window.rzdPanelKit;
	if (!K) { return; }
	var h = K.h, S = K.S;
	var DAY_SHORT = { Mon: 'Pn', Tue: 'Wt', Wed: 'Śr', Thu: 'Cz', Fri: 'Pt', Sat: 'So', Sun: 'Nd', All: 'Wszystkie' };

	function copy(o) { return JSON.parse(JSON.stringify(o)); }
	function after(x) { S.data.terms = x; S.termEdit = null; S.dirty = false; K.closeSheet(); K.toast(x.message || 'Zapisano.'); K.refreshWarnings(); K.render(); }
	function fail(b) { return function (e) { K.busy(b, false); K.toast(e.message, true); }; }
	function dayBtns(days, picked, onchange) {
		return h('div', { class: 'rp-days', role: 'group' }, Object.keys(days).map(function (k) {
			var on = picked.indexOf(k) > -1;
			var b = h('button', { type: 'button', class: 'rp-day' + (on ? ' on' : ''), 'aria-pressed': on ? 'true' : 'false', text: days[k] });
			b.addEventListener('click', function () {
				var at = picked.indexOf(k);
				if (at > -1) { picked.splice(at, 1); } else { picked.push(k); }
				b.classList.toggle('on', at < 0); b.setAttribute('aria-pressed', at < 0 ? 'true' : 'false');
				if (onchange) { onchange(); }
			});
			return b;
		}));
	}
	function hm(m) { m = Math.max(0, m); return ('0' + Math.floor(m / 60)).slice(-2) + ':' + ('0' + (m % 60)).slice(-2); }
	function mins(t) { var p = /^(\d{2}):(\d{2})$/.exec(t || ''); return p ? (+p[1]) * 60 + (+p[2]) : -1; }

	/* ============================================================
	 * GRUPY – kalendarz kategorii
	 * ============================================================ */
	function groupSummary(c, d) {
		if (!c.conf) { return 'brak kalendarza'; }
		var g = c.g, bits = [];
		bits.push(d.winOn ? 'okna dostaw' : (g.times.length ? g.times.join(', ') : 'BRAK GODZIN WYJAZDU'));
		if (g.days.length < 7) { bits.push(g.days.map(function (k) { return d.days[k] || k; }).join(' ')); }
		if (g.cutoff || g.cutoff_days) { bits.push('cutoff ' + (g.cutoff || 'koniec dnia') + (g.cutoff_days ? ', ' + g.cutoff_days + ' dn. wcześniej' : '')); }
		if (g.lead) { bits.push(g.lead + ' min przed wyjazdem'); }
		if (g.valid_from || g.valid_to) { bits.push('ważny ' + (g.valid_from || '…') + ' – ' + (g.valid_to || '…')); }
		return bits.join(' · ');
	}
	function tabGroups(main, d) {
		var warns = [];
		if (d.noGroup && d.noGroup.length) { warns.push({ level: 'warning', text: 'Produkty bez kalendarza (' + d.noGroup.length + ') – klient ich nie zamówi: ' + d.noGroup.slice(0, 12).join(', ') + (d.noGroup.length > 12 ? ' …' : '') + '. Włącz kalendarz ich kategorii.' }); }
		if (!d.townsOk && d.enabled) { warns.push({ level: 'warning', text: 'Dostawa wg miejscowości nie działa (pusta lista miejscowości albo metoda nie jest włączona w WooCommerce) – punkty okien liczą każde zamówienie jako 1.' }); }
		var w = K.warnBox(warns);
		if (w) { main.appendChild(w); }
		main.appendChild(h('p', { class: 'rp-muted', text: 'Kalendarz mają tylko kategorie z listy poniżej, które go włączyły. Produkt musi należeć do co najmniej jednej z nich (podkategoria dziedziczy kalendarz nadrzędnej). Produkt w kilku grupach musi spełniać kalendarze wszystkich.' }));
		var byParent = {};
		d.cats.forEach(function (c) { (byParent[c.parent] = byParent[c.parent] || []).push(c); });
		var list = h('div', { class: 'rp-list' });
		(function walk(pid, depth) {
			(byParent[pid] || []).forEach(function (c) {
				list.appendChild(h('button', { type: 'button', class: 'rp-row' + (c.conf ? '' : ' off'), onclick: function () { groupEdit(c, d); } }, [
					h('span', { class: 'rp-row-main' }, [
						h('strong', { text: (depth ? '— '.repeat(depth) : '') + c.name }),
						h('small', { text: groupSummary(c, d) })
					]),
					h('span', { class: 'rp-pill' + (c.conf ? ' ok' : ''), text: c.conf ? 'kalendarz' : 'brak' })
				]));
				walk(c.id, depth + 1);
			});
		})(0, 0);
		main.appendChild(list);
	}
	function groupEdit(c, d) {
		var g = copy(c.g);
		var times = g.times.slice();
		var tl = h('div', { class: 'rp-chips' });
		function drawTimes() {
			tl.textContent = '';
			times.sort().forEach(function (t, i) {
				tl.appendChild(h('span', { class: 'rp-chip on rp-chip-x' }, [t, h('button', { type: 'button', 'aria-label': 'Usuń ' + t, text: '✕', onclick: function () { times.splice(i, 1); drawTimes(); } })]));
			});
			if (!times.length) { tl.appendChild(h('span', { class: 'rp-muted', text: d.winOn ? 'Brak (w trybie okien nieużywane).' : 'Brak godzin – produktów z tej grupy nie da się zamówić.' })); }
		}
		drawTimes();
		var tIn = h('input', { type: 'time', class: 'rp-in rp-in-s', 'aria-label': 'Nowa godzina wyjazdu' });
		var addT = K.btn('Dodaj', function () { if (tIn.value && times.indexOf(tIn.value) < 0) { times.push(tIn.value); drawTimes(); } tIn.value = ''; tIn.focus(); });
		tIn.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); addT.click(); } });
		var cut = h('input', { type: 'time', class: 'rp-in rp-in-s', value: g.cutoff });
		var cutD = h('input', { type: 'number', class: 'rp-in rp-in-s', min: '0', max: '60', value: g.cutoff_days });
		var lead = h('input', { type: 'number', class: 'rp-in rp-in-s', min: '0', max: '1440', value: g.lead });
		var hor = h('input', { type: 'number', class: 'rp-in rp-in-s', min: '0', max: '60', value: g.horizon });
		var vf = h('input', { type: 'date', class: 'rp-in', value: g.valid_from });
		var vt = h('input', { type: 'date', class: 'rp-in', value: g.valid_to });
		var days = g.days.slice();
		var body = h('div', { class: 'rp-form' }, [
			h('div', { class: 'rp-field' }, [h('span', { class: 'rp-label', text: 'Godziny wyjazdu' }), d.winOn ? h('small', { class: 'rp-hint', text: 'Działa tryb okien dostaw – godziny grupy wynikają z okien w jej zakresie (zakładka „Godziny w dniach tygodnia”). Te godziny zostają na wypadek powrotu do starego trybu.' }) : null, tl, h('div', { class: 'rp-inline' }, [tIn, addT])]),
			h('div', { class: 'rp-field' }, [h('span', { class: 'rp-label', text: 'Dni dostaw' }), dayBtns(d.days, days), h('small', { class: 'rp-hint', text: 'Nic nie zaznaczone = brak dostaw tej grupy.' })]),
			h('div', { class: 'rp-grid2' }, [
				K.field('Cutoff dzienny – do godziny', cut, 'Puste przy 0 dniach = bez cutoffu dziennego; puste przy 1+ dniach = do końca tamtego dnia.'),
				K.field('… ile dni przed dostawą', cutD, '0 = w dniu dostawy, 1 = na jutro zamawia się do tej godziny dziś. Liczą się tylko dni dostaw tej grupy.')
			]),
			h('div', { class: 'rp-grid2' }, [
				K.field('Min. czas do wyjazdu (min)', lead, 'Cutoff każdego terminu: wyjazd minus tyle minut. Po nim termin znika z wyboru, a Kuchnia widzi go jako zamknięty.'),
				K.field('Ile dni do przodu', hor, '0 = tylko dziś, maks. 60.')
			]),
			h('div', { class: 'rp-grid2' }, [K.field('Kalendarz ważny od', vf, 'Np. oferta sezonowa. Puste = bez ograniczeń.'), K.field('do', vt)]),
			c.conf && c.g.blocked.length ? h('p', { class: 'rp-muted', text: 'Dni bez dostaw tej grupy (' + c.g.blocked.length + ') – w zakładce „Dni wolne i limit”.' }) : null
		]);
		var save = K.btn(c.conf ? 'Zapisz' : 'Włącz kalendarz', function () {
			if (!days.length && !window.confirm('Nie zaznaczono żadnego dnia dostaw – produkty tej grupy nie będą do zamówienia. Zapisać?')) { return; }
			K.busy(save, true);
			K.api('term_group_save', { term: c.id, g: { times: times, cutoff: cut.value, cutoff_days: cutD.value, lead: lead.value, days: days, horizon: hor.value, valid_from: vf.value, valid_to: vt.value, blocked: c.g.blocked } }).then(after, fail(save));
		}, 'rp-btn-pri');
		var foot = [save];
		if (c.conf) {
			foot.unshift(K.btn('Usuń kalendarz', function () {
				if (!window.confirm('Usunąć kalendarz kategorii „' + c.name + '”? Jej produkty przestaną być do zamówienia (chyba że należą też do innej grupy).')) { return; }
				K.api('term_group_delete', { term: c.id }).then(after, function (e) { K.toast(e.message, true); });
			}, 'rp-btn-del'));
		}
		K.openSheet('Kalendarz: ' + c.name, body, foot);
	}

	/* ============================================================
	 * GODZINY W DNIACH TYGODNIA (matryca od–do)
	 * ============================================================ */
	function editState(d) {
		if (!S.termEdit) {
			var rows = {};
			d.cats.forEach(function (c) { if (c.conf) { rows[c.id] = copy(c.window || {}); } });
			S.termEdit = { global: copy(d.globalWindow || {}), rows: rows, off: (d.offDays || []).slice(), winOn: !!d.winOn, defs: copy(d.winDefs || []), wdays: copy(d.winDays || {}) };
		}
		return S.termEdit;
	}
	function tabHours(main, d) {
		var e = editState(d);
		var cols = ['All'].concat(Object.keys(d.days));
		main.appendChild(h('p', { class: 'rp-muted', text: 'Od której i do której godziny grupa dowozi w danym dniu tygodnia (dzień dostawy). Klient widzi tylko godziny wyjazdu mieszczące się w przedziale (obie granice włącznie). Puste = bez ograniczenia z tej strony. „Wszystkie grupy” dotyczy każdej grupy, „Wszystkie” – każdego dnia; gdy wypełnionych jest kilka komórek, obowiązuje najwęższy przedział.' }));
		if (d.winOn) { main.appendChild(h('p', { class: 'rp-muted', text: 'Tryb okien dostaw: grupa dostaje okna, które zaczynają się nie wcześniej niż „od” i kończą nie później niż „do”. Dni bez dostaw – w zakładce „Okna dostaw”.' })); }
		if (!d.winOn) {
			var offSel = e.off;
			main.appendChild(h('section', { class: 'rp-card' }, [
				h('h2', { text: 'Dostawy wyłączone (wszystkie grupy)' }),
				h('p', { class: 'rp-muted', text: 'Dni tygodnia, w które w ogóle nie dowozimy. Już złożone zamówienia zostają. Pojedyncze daty (święta) – w zakładce „Dni wolne i limit”.' }),
				dayBtns(d.days, offSel, K.dirty)
			]));
		}
		var rows = [{ key: 'global', name: 'Wszystkie grupy', days: Object.keys(d.days), win: e.global }];
		d.cats.forEach(function (c) { if (c.conf) { rows.push({ key: String(c.id), name: c.name, days: c.g.days, win: e.rows[c.id] }); } });
		rows.forEach(function (r) {
			var grid = h('div', { class: 'rp-mx' });
			cols.forEach(function (dk) {
				var cell = r.win[dk] || { from: '', to: '' };
				var offDay = dk !== 'All' && r.days.indexOf(dk) < 0;
				function put() {
					var f = fi.value, t = ti.value;
					if (f || t) { r.win[dk] = { from: f, to: t }; } else { delete r.win[dk]; }
					wrap.classList.toggle('bad', !!(f && t && f > t));
					K.dirty();
				}
				var fi = h('input', { type: 'time', class: 'rp-in', value: cell.from || '', 'aria-label': r.name + ' – ' + (DAY_SHORT[dk] || dk) + ' od', oninput: put });
				var ti = h('input', { type: 'time', class: 'rp-in', value: cell.to || '', 'aria-label': r.name + ' – ' + (DAY_SHORT[dk] || dk) + ' do', oninput: put });
				var wrap = h('div', { class: 'rp-mx-c' + (offDay ? ' off' : '') + (dk === 'All' ? ' all' : '') + (cell.from && cell.to && cell.from > cell.to ? ' bad' : ''), title: offDay ? 'Grupa nie dowozi w ten dzień' : null }, [h('span', { class: 'rp-mx-d', text: DAY_SHORT[dk] || dk }), fi, ti]);
				grid.appendChild(wrap);
			});
			main.appendChild(h('section', { class: 'rp-card' }, [h('h2', { text: r.name }), grid]));
		});
		if (rows.length < 2) { main.appendChild(h('p', { class: 'rp-muted', text: 'Wiersze grup pojawią się po włączeniu kalendarza kategorii (zakładka „Grupy”).' })); }
		main.appendChild(K.saveBar(function (b) {
			K.busy(b, true);
			K.api('term_matrix_save', { global: e.global, rows: e.rows, off: e.off }).then(after, fail(b));
		}, 'Zapisz godziny'));
	}

	/* ============================================================
	 * OKNA DOSTAW
	 * ============================================================ */
	var tmp = 0;
	function dayLine(e, dow) {
		var day = e.wdays[dow] || { on: false, start: '', seq: [] };
		var by = {};
		e.defs.forEach(function (w) { by[w.id] = w; });
		var cur = mins(day.start), out = [], pts = 0, cut = false;
		if (!day.on || cur < 0) { return { list: out, pts: 0, cut: false }; }
		(day.seq || []).forEach(function (id) {
			var w = by[id];
			if (!w) { return; }
			var len = Math.max(5, parseInt(w.len, 10) || 60);
			if (cur + len > 1440) { cut = true; return; }
			out.push({ name: w.name || 'okno', start: hm(cur), end: hm(cur + len), cap: parseInt(w.cap, 10) || 0 });
			pts += parseInt(w.cap, 10) || 0;
			cur += len;
		});
		return { list: out, pts: pts, cut: cut };
	}
	function tabWindows(main, d) {
		var e = editState(d);
		var on = h('input', { type: 'checkbox', class: 'rp-switch-in', checked: e.winOn, onchange: function () { e.winOn = on.checked; K.dirty(); } });
		main.appendChild(h('section', { class: 'rp-card' }, [
			h('label', { class: 'rp-switch' }, [on, h('span', { class: 'rp-switch-ui', 'aria-hidden': 'true' }), h('span', { text: 'Używaj okien dostaw' })]),
			h('p', { class: 'rp-muted', text: 'Okno = odcinek pracy kuriera o danej długości i pojemności w punktach (punkty zamówienia – przy miejscowości). Okna są wspólne dla wszystkich grup; w każdym dniu idą jedno po drugim od godziny startu, bez przerw. Klient widzi przedział okna (np. 11:00–12:00). Wyłączone albo bez okien = godziny wyjazdu z kalendarzy grup.' }),
			e.winOn && !e.defs.length ? h('div', { class: 'rp-warn' }, [h('span', { text: 'Tryb okien jest włączony, ale katalog jest pusty – dopóki nie dodasz okien, sklep działa po staremu.' })]) : null
		]));
		// katalog
		var cat = h('section', { class: 'rp-card' }, [h('h2', { text: 'Katalog okien' })]);
		var tbl = h('div', { class: 'rp-wins' });
		e.defs.forEach(function (w, i) {
			var step = h('small', { class: 'rp-muted' });
			function upd() { var l = parseInt(w.len, 10) || 0, c = parseInt(w.cap, 10) || 0; step.textContent = l && c ? 'krok w Planowaniu ' + (Math.round(l / c * 10) / 10) + ' min' : ''; }
			upd();
			tbl.appendChild(h('div', { class: 'rp-win' }, [
				K.field('Nazwa', h('input', { type: 'text', class: 'rp-in', value: w.name, placeholder: 'np. Godzina', oninput: function (ev) { w.name = ev.target.value; K.dirty(); }, onchange: function () { K.render(); } })), // nowa nazwa – też w listach dni
				K.field('Długość (min)', h('input', { type: 'number', class: 'rp-in', min: '5', max: '600', step: '5', value: w.len, oninput: function (ev) { w.len = ev.target.value; upd(); K.dirty(); } })),
				K.field('Pojemność (pkt)', h('input', { type: 'number', class: 'rp-in', min: '1', max: '99', value: w.cap, oninput: function (ev) { w.cap = ev.target.value; upd(); K.dirty(); } })),
				step,
				h('button', { type: 'button', class: 'rp-ico', 'aria-label': 'Usuń okno ' + w.name, html: K.ICON.x, onclick: function () {
					var used = Object.keys(e.wdays).some(function (k) { return (e.wdays[k].seq || []).indexOf(w.id) > -1; });
					if (used && !window.confirm('Okno „' + w.name + '” jest ułożone w dniach tygodnia – zniknie też stamtąd. Usunąć?')) { return; }
					e.defs.splice(i, 1);
					Object.keys(e.wdays).forEach(function (k) { e.wdays[k].seq = (e.wdays[k].seq || []).filter(function (x) { return x !== w.id; }); });
					K.dirty(); K.render();
				} })
			]));
		});
		cat.appendChild(tbl);
		cat.appendChild(K.btn('+ Okno', function () { e.defs.push({ id: 'new' + (++tmp), name: '', len: 60, cap: 6 }); K.dirty(); K.render(); }));
		main.appendChild(cat);
		// dni tygodnia
		var dz = h('section', { class: 'rp-card' }, [h('h2', { text: 'Okna w dniach tygodnia' })]);
		if (!e.defs.length) { dz.appendChild(h('p', { class: 'rp-muted', text: 'Najpierw dodaj okna do katalogu.' })); }
		Object.keys(d.days).forEach(function (dow) {
			var day = e.wdays[dow] = e.wdays[dow] || { on: false, start: '', seq: [] };
			day.seq = day.seq || [];
			var line = dayLine(e, dow);
			var info = !day.on ? 'brak dostaw' : (!day.start ? 'brak godziny startu – brak dostaw' : (!line.list.length ? 'brak okien – brak dostaw' : line.list[0].start + '–' + line.list[line.list.length - 1].end + ' · ' + line.list.length + ' okn. · ' + line.pts + ' pkt' + (line.cut ? ' · część okien za północą – pominięte' : '')));
			var cb = h('input', { type: 'checkbox', checked: day.on, onchange: function () { day.on = cb.checked; K.dirty(); K.render(); } });
			var st = h('input', { type: 'time', class: 'rp-in rp-in-s', value: day.start, 'aria-label': d.days[dow] + ' – start', onchange: function () { day.start = st.value; K.dirty(); K.render(); } });
			var chips = h('div', { class: 'rp-chips rp-seq' });
			var by = {};
			e.defs.forEach(function (w) { by[w.id] = w; });
			day.seq.forEach(function (id, i) {
				if (!by[id]) { return; }
				chips.appendChild(h('span', { class: 'rp-chip on rp-chip-x' }, [(i + 1) + '. ' + (by[id].name || 'okno'), h('button', { type: 'button', 'aria-label': 'Usuń z dnia', text: '✕', onclick: function () { day.seq.splice(i, 1); K.dirty(); K.render(); } })]));
			});
			var add = e.defs.length ? h('select', { class: 'rp-in rp-in-s', 'aria-label': d.days[dow] + ' – dodaj okno', onchange: function () { if (add.value) { day.seq.push(add.value); K.dirty(); K.render(); } } }, [h('option', { value: '', text: '+ dodaj okno' })].concat(e.defs.map(function (w) { return h('option', { value: w.id, text: w.name || 'okno' }); }))) : null;
			dz.appendChild(h('div', { class: 'rp-wday' + (day.on ? '' : ' off') }, [
				h('label', { class: 'rp-check rp-wday-h' }, [cb, h('strong', { text: d.days[dow] })]),
				h('div', { class: 'rp-inline' }, [h('span', { class: 'rp-muted', text: 'start' }), st]),
				chips, add,
				h('small', { class: 'rp-wday-i' + (day.on && line.list.length ? '' : ' warn'), text: info, title: line.list.map(function (w) { return w.start + '–' + w.end + ' ' + w.name + ' (' + w.cap + ' pkt)'; }).join('\n') })
			]));
		});
		main.appendChild(dz);
		main.appendChild(K.saveBar(function (b) {
			var bad = e.defs.filter(function (w) { return !String(w.name || '').trim(); });
			if (bad.length) { K.toast('Podaj nazwę każdego okna.', true); return; }
			K.busy(b, true);
			K.api('term_windows_save', { on: e.winOn ? '1' : '0', defs: e.defs, wdays: e.wdays }).then(after, fail(b));
		}, 'Zapisz okna dostaw'));
	}

	K.termTabs.grupy = tabGroups;
	K.termTabs.godziny = tabHours;
	K.termTabs.okna = tabWindows;
})();
