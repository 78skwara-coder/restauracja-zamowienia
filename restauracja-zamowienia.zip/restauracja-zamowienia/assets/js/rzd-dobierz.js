/* Restauracja – Zamówienia i Dostawy: karty „Dobierz do zamówienia” (moduł 32, 2.42.0).
 * „Sprawdź zamówienie” – karty buduje rzd-modyfikacje.js przez window.rzdUpsellCards (dane z przeglądu);
 * koszyk – karty w HTML z serwera, tu tylko obsługa przycisków.
 * Dodanie: window.rzdAddProduct (brama, moduł 08) – termin i okno modyfikacji jak przy „Dodaj do koszyka”.
 * „Nie, dziękuję” – chowa karty do końca wizyty (sessionStorage, karta przeglądarki). */
(function () {
	var KEY = 'rzd_up_no';
	function dismissed() { try { return sessionStorage.getItem(KEY) === '1'; } catch (e) { return false; } }
	function dismiss() {
		try { sessionStorage.setItem(KEY, '1'); } catch (e) { /* tryb prywatny – schowa się tylko teraz */ }
		document.querySelectorAll('.rzd-up').forEach(function (x) { x.parentNode.removeChild(x); });
	}
	function el(tag, cls, text) {
		var x = document.createElement(tag);
		if (cls) { x.className = cls; }
		if (text !== undefined) { x.textContent = text; }
		return x;
	}

	// Obsługa jednej sekcji kart (z przeglądu albo z koszyka). onAdded – po udanym dodaniu.
	function bind(box, onAdded) {
		var no = box.querySelector('.rzd-up-no');
		if (no) { no.addEventListener('click', dismiss); }
		box.querySelectorAll('.rzd-up-card').forEach(function (card) {
			var btn = card.querySelector('.rzd-up-add');
			var last = 0;
			btn.addEventListener('click', function () {
				if (btn.disabled || Date.now() - last < 800 || !window.rzdAddProduct) { return; }
				last = Date.now();
				var err = card.querySelector('.rzd-up-err');
				if (err) { err.parentNode.removeChild(err); }
				window.rzdAddProduct(card.getAttribute('data-id'), {
					qty: 1,
					fields: [['rzd_upsell', card.getAttribute('data-src') || '']],
					onStart: function () { btn.disabled = true; btn.textContent = 'Dodaję…'; }
				}).then(function (r) {
					if (r && r.ok) {
						card.classList.add('rzd-up-done');
						btn.textContent = '✓ Dodano';
						setTimeout(function () { if (onAdded) { onAdded(); } }, 700);
						return;
					}
					btn.disabled = false; btn.textContent = '+ Dodaj';
					card.appendChild(el('span', 'rzd-up-err', (r && r.msg) || 'Nie udało się dodać.'));
				});
			});
		});
	}

	// Karty w „Sprawdź zamówienie”: d = { title, no, items: [ {id, name, price_html, img, src, tag} ] }
	window.rzdUpsellCards = function (d, place, onAdded) {
		if (!d || !d.items || !d.items.length || dismissed()) { return null; }
		var box = el('div', 'rzd-up rzd-up-at-' + place);
		var head = el('div', 'rzd-up-head');
		head.appendChild(el('p', 'rzd-up-title', d.title || ''));
		if (d.no) { var no = el('button', 'rzd-up-no', d.no); no.type = 'button'; head.appendChild(no); }
		box.appendChild(head);
		var row = el('div', 'rzd-up-row');
		d.items.forEach(function (c) {
			var card = el('div', 'rzd-up-card');
			card.setAttribute('data-id', c.id); card.setAttribute('data-src', c.src || '');
			if (c.img) { var im = el('img', 'rzd-up-img'); im.src = c.img; im.alt = ''; im.loading = 'lazy'; card.appendChild(im); } else { card.appendChild(el('span', 'rzd-up-img rzd-up-noimg')); }
			if (c.tag) { card.appendChild(el('span', 'rzd-up-tag', c.tag)); }
			card.appendChild(el('span', 'rzd-up-name', c.name));
			var pr = el('span', 'rzd-up-price'); pr.innerHTML = c.price_html || ''; card.appendChild(pr);
			var b = el('button', 'rzd-up-add', '+ Dodaj'); b.type = 'button'; b.setAttribute('aria-label', 'Dodaj: ' + c.name);
			card.appendChild(b);
			row.appendChild(card);
		});
		box.appendChild(row);
		bind(box, onAdded);
		return box;
	};

	// Koszyk: karty z serwera. Po dodaniu – przeładowanie (WooCommerce przelicza tabelę koszyka po stronie serwera).
	function initCart() {
		document.querySelectorAll('.rzd-up[data-place="cart"]').forEach(function (box) {
			if (box.__rzdUp) { return; }
			box.__rzdUp = true;
			if (dismissed()) { box.parentNode.removeChild(box); return; }
			bind(box, function () { if (window.rzdKeepScroll) { window.rzdKeepScroll(); } window.location.reload(); });
		});
	}
	if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', initCart); } else { initCart(); }
	// WooCommerce podmienia formularz koszyka po „Zaktualizuj koszyk” – nowe karty
	if (window.jQuery) { window.jQuery(document.body).on('updated_wc_div updated_cart_totals', initCart); }
})();
