/* Restauracja – Zamówienia i Dostawy: panel kelnera [rzd_sala] (moduł 33, 2.43.0).
 * Widoki: sala (kafle stolików w strefach) → rachunek stolika (rundy, „do wysłania”, menu, płatność).
 * Pozycje „do wysłania” trzymane na tym urządzeniu (localStorage na stolik) do „Wyślij do kuchni”. */
(function () {
	var root = document.getElementById('rzd-sala');
	if (!root || !window.rzdSala) { return; }
	var C = window.rzdSala;
	var S = { view: 'tables', zone: '', state: null, table: null, order: null, menu: null, sheet: null, busy: false, cat: 0, q: '' };
	var pollT = null;

	/* ---------- pomocnicze ---------- */
	function h(tag, a, kids) {
		var e = document.createElement(tag);
		a = a || {};
		Object.keys(a).forEach(function (k) {
			var v = a[k];
			if (v === null || v === undefined || v === false) { return; }
			if (k === 'class') { e.className = v; } else if (k === 'text') { e.textContent = v; } else if (k === 'html') { e.innerHTML = v; } else if (k.slice(0, 2) === 'on') { e.addEventListener(k.slice(2), v); } else { e.setAttribute(k, v === true ? '' : v); }
		});
		(kids || []).forEach(function (c) { if (c) { e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); } });
		return e;
	}
	function api(action, data) {
		var fd = new FormData();
		fd.append('action', 'rzd_sala_' + action);
		fd.append('n', C.nonce);
		Object.keys(data || {}).forEach(function (k) { fd.append(k, typeof data[k] === 'object' ? JSON.stringify(data[k]) : String(data[k])); });
		return fetch(C.ajax, { method: 'POST', credentials: 'same-origin', body: fd })
			.then(function (r) { return r.json().catch(function () { return { ok: false, msg: 'Błąd serwera (' + r.status + ').' }; }); })
			.then(function (d) {
				if (d && d.code === 'nonce') { window.location.reload(); }
				if (!d || !d.ok) { throw new Error((d && d.msg) || 'Nie udało się – spróbuj ponownie.'); }
				return d;
			});
	}
	var toastT = null;
	function toast(msg, err) {
		var old = document.querySelector('.sl-toast');
		if (old) { old.remove(); }
		var t = h('div', { class: 'sl-toast' + (err ? ' err' : ''), role: err ? 'alert' : 'status', text: msg });
		root.appendChild(t);
		clearTimeout(toastT);
		toastT = setTimeout(function () { t.remove(); }, err ? 5000 : 2200);
	}
	function mins(ts) { return Math.max(0, Math.floor((Date.now() / 1000 - ts) / 60)); }
	function hhmm(ts) { var d = new Date(ts * 1000); return ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2); }
	function money(v) { return (Math.round(v * 100) / 100).toFixed(2).replace('.', ',') + ' ' + (C.cur || 'zł'); }
	function zoneName(id) { var z = (S.state && S.state.zones || []).filter(function (x) { return x.id === id; })[0]; return z ? z.name : ''; }

	/* ---------- pozycje do wysłania (na tym urządzeniu) ---------- */
	function pkey(t) { return 'rzd_sala_p_' + t; }
	function pending(t) { try { var a = JSON.parse(localStorage.getItem(pkey(t || S.table)) || '[]'); return Array.isArray(a) ? a : []; } catch (e) { return S['p_' + (t || S.table)] || []; } }
	function setPending(a, t) { S['p_' + (t || S.table)] = a; try { localStorage.setItem(pkey(t || S.table), JSON.stringify(a)); } catch (e) { /* tryb prywatny – tylko w pamięci */ } }
	function pendingSum(a) { return a.reduce(function (s, x) { return s + x.price * x.qty; }, 0); }

	/* ---------- odświeżanie ---------- */
	function poll() {
		clearTimeout(pollT);
		pollT = setTimeout(function () {
			if (document.hidden || S.busy || S.sheet === 'pay') { poll(); return; }
			(S.view === 'tables' ? loadState() : loadBill(true)).then(poll, poll);
		}, 10000);
	}
	document.addEventListener('visibilitychange', function () { if (!document.hidden) { (S.view === 'tables' ? loadState() : loadBill(true)).catch(function () {}); } });

	function loadState() {
		return api('state').then(function (d) { S.state = d; if (S.view === 'tables') { render(); } }).catch(function (e) { toast(e.message, true); });
	}
	function loadBill(quiet) {
		return api('bill', { table: S.table }).then(function (d) { S.order = d.order; if (S.view === 'bill' && (!quiet || !S.sheet)) { render(); } }).catch(function (e) { if (!quiet) { toast(e.message, true); } });
	}
	function loadMenu() {
		if (S.menu && Date.now() - S.menuAt < 300000) { return Promise.resolve(S.menu); }
		return api('menu').then(function (d) { S.menu = d.cats; S.menuAt = Date.now(); return S.menu; });
	}

	/* ---------- widok: sala ---------- */
	function header(title, back, right) {
		return h('div', { class: 'sl-head' }, [
			back ? h('button', { type: 'button', class: 'sl-ico', 'aria-label': 'Wróć do sali', text: '←', onclick: back }) : brandLink(),
			h('h1', { text: title }),
			right || null
		]);
	}
	function brandLink() {
		var b = C.brand;
		if (!b) { return null; }
		return h('a', { class: 'sl-brand', href: b.url, title: b.label + ' – ' + b.name, 'aria-label': b.label }, [b.logo ? h('img', { src: b.logo, alt: '' }) : h('span', { text: b.name })]);
	}
	function menuBtn() {
		return h('details', { class: 'sl-more' }, [
			h('summary', { 'aria-label': 'Więcej', text: '⋯' }),
			h('div', { class: 'sl-more-box' }, [
				h('div', { class: 'sl-more-u', text: C.user || '' }),
				C.kitchen ? h('a', { href: C.kitchen, text: 'Kuchnia' }) : null,
				C.panel ? h('a', { href: C.panel, text: 'Panel restauracji' }) : null,
				C.brand ? h('a', { href: C.brand.url, text: C.brand.label }) : null,
				h('a', { href: C.logout, text: 'Wyloguj' })
			])
		]);
	}
	function renderTables() {
		var st = S.state || { zones: [], tables: [] };
		var wrap = h('div', { class: 'sl-screen' });
		wrap.appendChild(header('Sala', null, menuBtn()));
		if (st.zones.length > 1) {
			var chips = h('div', { class: 'sl-chips', role: 'tablist' });
			[{ id: '', name: 'Wszystkie' }].concat(st.zones).forEach(function (z) {
				chips.appendChild(h('button', { type: 'button', role: 'tab', class: 'sl-chip' + (S.zone === z.id ? ' on' : ''), 'aria-selected': S.zone === z.id ? 'true' : 'false', text: z.name, onclick: function () { S.zone = z.id; render(); } }));
			});
			wrap.appendChild(chips);
		}
		var body = h('div', { class: 'sl-body' });
		st.zones.forEach(function (z) {
			if (S.zone && S.zone !== z.id) { return; }
			var ts = st.tables.filter(function (t) { return t.zone === z.id; });
			if (!ts.length) { return; }
			if (st.zones.length > 1) { body.appendChild(h('h2', { class: 'sl-zone', text: z.name })); }
			var grid = h('div', { class: 'sl-grid' });
			ts.forEach(function (t) {
				var o = t.order, p = pending(t.id).length;
				var cls = 'sl-tile' + (o ? ' busy' : ' free') + (o && o.ready ? ' ready' : '') + (p ? ' has-pending' : '');
				var info = [];
				if (o) {
					info.push(h('span', { class: 'sl-t-sum', html: o.total_html }));
					info.push(h('span', { class: 'sl-t-time', text: mins(o.opened) + ' min' }));
				} else {
					info.push(h('span', { class: 'sl-t-seats', text: t.seats + ' os.' }));
				}
				var badges = [];
				if (o && o.ready) { badges.push(h('span', { class: 'sl-badge ok', text: 'Do wydania' })); }
				if (o && o.cooking) { badges.push(h('span', { class: 'sl-badge', text: 'W kuchni' })); }
				if (p) { badges.push(h('span', { class: 'sl-badge warn', text: 'Niewysłane: ' + p })); }
				grid.appendChild(h('button', { type: 'button', class: cls, 'data-table': t.id, 'aria-label': 'Stolik ' + t.name + (o ? ', zajęty' : ', wolny'), onclick: function () { openTable(t.id); } }, [
					h('span', { class: 'sl-t-name', text: t.name }), h('span', { class: 'sl-t-info' }, info), badges.length ? h('span', { class: 'sl-t-badges' }, badges) : null
				]));
			});
			body.appendChild(grid);
		});
		wrap.appendChild(body);
		return wrap;
	}

	/* ---------- widok: rachunek ---------- */
	function openTable(id) {
		S.table = id; S.view = 'bill'; S.order = null; S.sheet = null;
		try { history.pushState({ sala: id }, ''); } catch (e) { /* ignore */ }
		render();
		loadBill();
		loadMenu().catch(function () {});
	}
	function backToTables() {
		S.view = 'tables'; S.table = null; S.sheet = null;
		render();
		loadState();
	}
	window.addEventListener('popstate', function () {
		if (S.sheet) { S.sheet = null; render(); return; } // „Wstecz” telefonu zamyka okno menu / rachunku
		if (S.view === 'bill') { backToTables(); }
	});
	function tableName() {
		var t = S.state && S.state.tables.filter(function (x) { return x.id === S.table; })[0];
		return t ? t.name : (S.order ? S.order.table_name : '');
	}
	var ST = { new: ['W kuchni', ''], ready: ['Gotowe – do wydania', 'ok'], served: ['Wydane', 'done'] };
	function renderBill() {
		var wrap = h('div', { class: 'sl-screen' });
		var o = S.order, p = pending();
		var total = (o ? o.total : 0) + pendingSum(p);
		wrap.appendChild(header('Stolik ' + tableName(), function () { history.back(); }, h('span', { class: 'sl-head-sum', text: money(total) })));
		var body = h('div', { class: 'sl-body sl-bill' });
		// do wysłania
		if (p.length) {
			var box = h('section', { class: 'sl-pend' }, [h('h2', { text: 'Do wysłania' })]);
			p.forEach(function (it, i) {
				box.appendChild(h('div', { class: 'sl-line' }, [
					h('div', { class: 'sl-l-main' }, [
						h('div', { class: 'sl-l-name', text: it.name }),
						it.picked ? h('div', { class: 'sl-l-sub', text: it.picked }) : null,
						it.note ? h('div', { class: 'sl-l-sub sl-note', text: 'Uwagi: ' + it.note }) : null
					]),
					h('div', { class: 'sl-qty' }, [
						h('button', { type: 'button', 'aria-label': 'Mniej: ' + it.name, text: '−', onclick: function () { var a = pending(); if (a[i].qty > 1) { a[i].qty--; } else { a.splice(i, 1); } setPending(a); render(); } }),
						h('span', { text: String(it.qty) }),
						h('button', { type: 'button', 'aria-label': 'Więcej: ' + it.name, text: '+', onclick: function () { var a = pending(); a[i].qty = Math.min(99, a[i].qty + 1); setPending(a); render(); } })
					]),
					h('button', { type: 'button', class: 'sl-ico sm', 'aria-label': 'Uwagi do: ' + it.name, text: '✎', onclick: function () { askNote(i); } })
				]));
			});
			box.appendChild(h('button', { type: 'button', class: 'sl-btn pri wide', text: 'Wyślij do kuchni (' + p.reduce(function (s, x) { return s + x.qty; }, 0) + ')', onclick: send }));
			body.appendChild(box);
		}
		// wysłane rundy
		if (o && o.rounds.length) {
			o.rounds.slice().reverse().forEach(function (r) {
				var s = ST[r.status] || ST.served;
				var sec = h('section', { class: 'sl-round st-' + r.status }, [
					h('div', { class: 'sl-r-head' }, [
						h('b', { text: 'Runda ' + r.n }),
						h('span', { class: 'sl-r-meta', text: (r.sent ? hhmm(r.sent) : '') + (r.by ? ' · ' + r.by : '') }),
						h('span', { class: 'sl-badge ' + s[1], text: s[0] })
					])
				]);
				r.items.forEach(function (it) {
					sec.appendChild(h('div', { class: 'sl-line' }, [
						h('div', { class: 'sl-l-main' }, [h('div', { class: 'sl-l-name', text: it.qty + '× ' + it.name })].concat(it.lines.map(function (l) { return h('div', { class: 'sl-l-sub', text: l }); }))),
						h('span', { class: 'sl-l-price', html: it.total_html }),
						h('button', { type: 'button', class: 'sl-ico sm', 'aria-label': 'Usuń z rachunku: ' + it.name, text: '✕', onclick: function () { askVoid(it); } })
					]));
				});
				if (r.status === 'ready') { sec.appendChild(h('button', { type: 'button', class: 'sl-btn ok wide', text: 'Wydane na stół', onclick: function () { served(r.n); } })); }
				body.appendChild(sec);
			});
		} else if (!p.length) {
			body.appendChild(h('p', { class: 'sl-empty', text: 'Stolik wolny – dodaj pierwsze pozycje („+ Dodaj”), potem „Wyślij do kuchni”.' }));
		}
		wrap.appendChild(body);
		wrap.appendChild(h('div', { class: 'sl-foot' }, [
			h('button', { type: 'button', class: 'sl-btn', text: '+ Dodaj', onclick: function () { openSheet('menu'); } }),
			h('button', { type: 'button', class: 'sl-btn pri', text: 'Rachunek', disabled: !o, onclick: function () { if (pending().length) { toast('Najpierw wyślij albo usuń pozycje „Do wysłania”.', true); return; } openSheet('pay'); } })
		]));
		if (S.sheet === 'menu') { wrap.appendChild(menuSheet()); }
		if (S.sheet === 'pay') { wrap.appendChild(paySheet()); }
		return wrap;
	}
	function openSheet(k) {
		S.sheet = k;
		try { history.pushState({ sala: S.table, sheet: k }, ''); } catch (e) { /* ignore */ }
		render();
		if (k === 'menu') {
			loadMenu().then(function () { if (S.sheet === 'menu') { render(); var q = root.querySelector('.sl-search'); if (q && window.matchMedia('(min-width:768px)').matches) { q.focus(); } } }).catch(function (e) { toast(e.message, true); });
		}
	}
	function closeSheet() { if (S.sheet) { history.back(); } }

	/* ---------- menu ---------- */
	function fold(t) { return String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/ł/g, 'l'); }
	function menuSheet() {
		var sh = h('div', { class: 'sl-sheet', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Dodaj do rachunku' });
		var top = h('div', { class: 'sl-sh-top' }, [h('b', { text: 'Dodaj – stolik ' + tableName() }), h('button', { type: 'button', class: 'sl-btn sm', text: 'Gotowe', onclick: closeSheet })]);
		sh.appendChild(top);
		if (!S.menu) { sh.appendChild(h('p', { class: 'sl-empty', text: 'Wczytuję menu…' })); return sh; }
		var list = h('div', { class: 'sl-menu' });
		var search = h('input', { type: 'search', class: 'sl-search', placeholder: 'Szukaj w menu…', value: S.q, 'aria-label': 'Szukaj w menu', oninput: function (e) { S.q = e.target.value; fill(); } });
		var chips = h('div', { class: 'sl-chips' });
		S.menu.forEach(function (c, ci) {
			chips.appendChild(h('button', { type: 'button', class: 'sl-chip' + (S.cat === ci && !S.q ? ' on' : ''), text: c.name, onclick: function () { S.cat = ci; S.q = ''; search.value = ''; fill(); chips.querySelectorAll('.sl-chip').forEach(function (b, bi) { b.classList.toggle('on', bi === ci); }); } }));
		});
		sh.appendChild(search);
		sh.appendChild(chips);
		sh.appendChild(list);
		function fill() {
			list.innerHTML = '';
			var q = fold(S.q.trim()), items = [];
			if (q) { S.menu.forEach(function (c) { c.items.forEach(function (it) { if (fold(it.name).indexOf(q) >= 0) { items.push(it); } }); }); } else if (S.menu[S.cat]) { items = S.menu[S.cat].items; }
			if (!items.length) { list.appendChild(h('p', { class: 'sl-empty', text: q ? 'Nic nie pasuje.' : 'Pusto.' })); return; }
			items.forEach(function (it) {
				list.appendChild(h('button', { type: 'button', class: 'sl-mi', onclick: function () { addItem(it); } }, [
					h('span', { class: 'sl-mi-t' }, [h('span', { class: 'sl-mi-n', text: it.name }), it.sklad ? h('span', { class: 'sl-mi-s', text: it.sklad }) : null]),
					h('span', { class: 'sl-mi-p', text: it.price_html }),
					h('span', { class: 'sl-mi-add', 'aria-hidden': 'true', text: '+' })
				]));
			});
		}
		fill();
		return sh;
	}
	// pola okna modyfikacji (rzd_mod[i][val]) → { i: { val } }
	function fieldsToRaw(fields) {
		var raw = {};
		(fields || []).forEach(function (f) {
			var m = /^rzd_mod\[([^\]]+)\]\[([^\]]+)\]$/.exec(f[0]);
			if (m) { raw[m[1]] = raw[m[1]] || {}; raw[m[1]][m[2]] = f[1]; }
		});
		return raw;
	}
	function addItem(it) {
		var push = function (raw, picked) {
			var a = pending();
			// ten sam produkt bez wyborów i uwag – zwiększ ilość
			var same = !raw && a.filter(function (x) { return x.pid === it.id && !x.raw && !x.note; })[0];
			if (same) { same.qty = Math.min(99, same.qty + 1); } else { a.push({ pid: it.id, name: it.name, price: it.price, qty: 1, raw: raw || null, picked: picked || '', note: '' }); }
			setPending(a);
			toast('Dodano: ' + it.name);
			render();
		};
		if (it.mods && window.rzdRunAddSteps) {
			var ctx = { pid: it.id, fields: [], sala: true };
			window.rzdRunAddSteps(ctx, function () {
				var pk = document.querySelector('#rzd-mods .rzd-picked');
				var raw = fieldsToRaw(ctx.fields);
				push(Object.keys(raw).length ? raw : null, pk ? pk.textContent.replace(/\s+/g, ' ').trim() : '');
			});
			return;
		}
		push(null, '');
	}

	/* ---------- akcje ---------- */
	function lock(btn) { S.busy = true; if (btn) { btn.disabled = true; } }
	function unlock(btn) { S.busy = false; if (btn) { btn.disabled = false; } }
	function send(e) {
		var btn = e && e.currentTarget, a = pending();
		if (!a.length || S.busy) { return; }
		lock(btn);
		api('send', { table: S.table, items: a.map(function (x) { return { pid: x.pid, qty: x.qty, raw: x.raw || {}, note: x.note || '' }; }) })
			.then(function (d) { setPending([]); S.order = d.order; S.busy = false; render(); toast('Wysłane do kuchni.'); })
			.catch(function (err) { unlock(btn); toast(err.message, true); });
	}
	function served(n) {
		if (S.busy) { return; }
		lock();
		api('served', { order: S.order.id, round: n }).then(function (d) { S.order = d.order; S.busy = false; render(); }).catch(function (err) { unlock(); toast(err.message, true); if (/zamknięty/.test(err.message)) { backToTables(); } });
	}
	function dialog(title, label, value, okText, cb) {
		var inp = h('input', { type: 'text', class: 'sl-in', value: value || '', maxlength: '140', 'aria-label': label, placeholder: label });
		var dl = h('div', { class: 'sl-dlg-bg' }, [h('div', { class: 'sl-dlg', role: 'dialog', 'aria-modal': 'true', 'aria-label': title }, [
			h('b', { text: title }), inp,
			h('div', { class: 'sl-dlg-act' }, [
				h('button', { type: 'button', class: 'sl-btn', text: 'Anuluj', onclick: function () { dl.remove(); } }),
				h('button', { type: 'button', class: 'sl-btn pri', text: okText, onclick: function () { dl.remove(); cb(inp.value.trim()); } })
			])
		])]);
		inp.addEventListener('keydown', function (e) { if (e.key === 'Enter') { dl.remove(); cb(inp.value.trim()); } if (e.key === 'Escape') { dl.remove(); } });
		root.appendChild(dl);
		inp.focus();
	}
	function askNote(i) {
		var a = pending();
		dialog('Uwagi: ' + a[i].name, 'np. bez cebuli, sos osobno', a[i].note, 'Zapisz', function (v) { var b = pending(); if (b[i]) { b[i].note = v; setPending(b); render(); } });
	}
	function askVoid(it) {
		dialog('Usunąć z rachunku: ' + it.qty + '× ' + it.name + '?', 'Powód (np. pomyłka, klient zrezygnował)', '', 'Usuń', function (why) {
			lock();
			api('void', { order: S.order.id, item: it.id, why: why }).then(function (d) { S.order = d.order; S.busy = false; render(); toast('Usunięto: ' + it.name); }).catch(function (err) { unlock(); toast(err.message, true); });
		});
	}

	/* ---------- rachunek ---------- */
	function paySheet() {
		var o = S.order;
		var sh = h('div', { class: 'sl-sheet sl-pay', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Rachunek' });
		sh.appendChild(h('div', { class: 'sl-sh-top' }, [h('b', { text: 'Rachunek – stolik ' + tableName() }), h('button', { type: 'button', class: 'sl-btn sm', text: 'Wróć', onclick: closeSheet })]));
		var list = h('div', { class: 'sl-pay-list' });
		o.rounds.forEach(function (r) { r.items.forEach(function (it) { list.appendChild(h('div', { class: 'sl-pay-row' }, [h('span', { text: it.qty + '× ' + it.name }), h('span', { html: it.total_html })])); }); });
		sh.appendChild(list);
		sh.appendChild(h('div', { class: 'sl-pay-total' }, [h('span', { text: 'Do zapłaty' }), h('b', { text: o.total_html })]));
		sh.appendChild(h('p', { class: 'sl-hint', text: 'Paragon fiskalny – na kasie restauracji.' }));
		var method = S.payMethod || 'cash';
		var cashBox = h('div', { class: 'sl-cash' });
		var given = h('input', { type: 'text', inputmode: 'decimal', class: 'sl-in', placeholder: 'Otrzymano (opcjonalnie)', 'aria-label': 'Otrzymana kwota', value: S.given || '', oninput: function (e) { S.given = e.target.value; calc(); } });
		var change = h('div', { class: 'sl-change' });
		function num(v) { v = String(v || '').replace(/\s|zł/g, '').replace(',', '.'); return v === '' || isNaN(+v) ? null : +v; }
		function calc() {
			var g = num(S.given);
			change.textContent = g === null ? '' : (g + 0.001 < o.total ? 'Za mało o ' + money(o.total - g) : 'Reszta: ' + money(g - o.total));
			change.classList.toggle('err', g !== null && g + 0.001 < o.total);
		}
		var quick = h('div', { class: 'sl-quick' });
		[o.total, 20, 50, 100, 200].forEach(function (v, i) {
			if (i > 0 && v < o.total) { return; }
			quick.appendChild(h('button', { type: 'button', class: 'sl-chip', text: i === 0 ? 'Odliczone' : money(v).replace(',00', ''), onclick: function () { S.given = String(v).replace('.', ','); given.value = S.given; calc(); } }));
		});
		cashBox.appendChild(given); cashBox.appendChild(quick); cashBox.appendChild(change);
		var mWrap = h('div', { class: 'sl-methods', role: 'radiogroup', 'aria-label': 'Płatność' });
		[['cash', 'Gotówka'], ['card', 'Karta']].forEach(function (m) {
			mWrap.appendChild(h('button', { type: 'button', role: 'radio', 'aria-checked': method === m[0] ? 'true' : 'false', class: 'sl-method' + (method === m[0] ? ' on' : ''), text: m[1], onclick: function () { S.payMethod = m[0]; render(); } }));
		});
		sh.appendChild(mWrap);
		if (method === 'cash') { sh.appendChild(cashBox); calc(); }
		var ready = o.rounds.filter(function (r) { return r.status !== 'served'; }).length;
		if (ready) { sh.appendChild(h('p', { class: 'sl-hint warn', text: 'Uwaga: ' + ready + ' runda(y) jeszcze nie wydane na stół.' })); }
		sh.appendChild(h('button', { type: 'button', class: 'sl-btn pri wide big', text: 'Zamknij rachunek – ' + (method === 'cash' ? 'gotówka' : 'karta'), onclick: function (e) { pay(e.currentTarget, method); } }));
		return sh;
	}
	function pay(btn, method) {
		if (S.busy) { return; }
		lock(btn);
		api('pay', { order: S.order.id, method: method, given: method === 'cash' ? (S.given || '') : '' }).then(function (d) {
			S.busy = false; S.given = ''; S.payMethod = 'cash'; S.sheet = null; S.order = null;
			var t = tableName();
			var done = h('div', { class: 'sl-dlg-bg' }, [h('div', { class: 'sl-dlg sl-done', role: 'alertdialog', 'aria-label': 'Rachunek zamknięty' }, [
				h('div', { class: 'sl-done-ok', text: '✓' }),
				h('b', { text: 'Stolik ' + t + ' – rachunek zamknięty' }),
				d.change_html ? h('div', { class: 'sl-done-change', text: 'Reszta: ' + d.change_html }) : null,
				h('button', { type: 'button', class: 'sl-btn pri wide', text: 'Wróć do sali', onclick: function () { done.remove(); history.go(-2); setTimeout(function () { if (S.view !== 'tables') { backToTables(); } }, 300); } })
			])]);
			root.appendChild(done);
		}).catch(function (err) { unlock(btn); toast(err.message, true); });
	}

	/* ---------- render ---------- */
	function render() {
		var sc = root.querySelector('.sl-body'), keep = sc ? sc.scrollTop : 0, msc = root.querySelector('.sl-menu'), mkeep = msc ? msc.scrollTop : 0;
		var view = S.view === 'tables' ? renderTables() : renderBill();
		var extras = Array.prototype.slice.call(root.querySelectorAll('.sl-dlg-bg, .sl-toast'));
		root.innerHTML = '';
		root.appendChild(view);
		extras.forEach(function (x) { root.appendChild(x); });
		var nb = root.querySelector('.sl-body'); if (nb) { nb.scrollTop = keep; }
		var nm = root.querySelector('.sl-menu'); if (nm) { nm.scrollTop = mkeep; }
	}

	document.documentElement.classList.add('rzd-sala-on');
	try { history.replaceState({ sala: '' }, ''); } catch (e) { /* ignore */ }
	loadState().then(poll, poll);
})();
