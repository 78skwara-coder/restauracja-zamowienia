/* Restauracja – Zamówienia i Dostawy: bilety z sali – zakładka „Sala” w Kuchni (moduł 33, 2.43.0).
 * Działa, gdy na ekranie jest #rzd-kds (zakładki Kuchni podmieniają treść – sprawdzane co sekundę).
 * Odświeżanie co 8 s, krótki dźwięk przy nowym bilecie. */
(function () {
	var cfg = window.rzdKuchniaCfg || {};
	if (!cfg.wcAjax) { return; }
	var data = null, seen = null, loading = false, last = 0, busy = false;
	function url(a) { return cfg.wcAjax.replace('__ACTION__', a); }
	function nonce() { var n = document.querySelector('.kuchnia-wrap .kuchnia-n'); return n ? n.getAttribute('data-n') : ''; }
	function box() { return document.getElementById('rzd-kds'); }
	function post(action, body) {
		var b = new URLSearchParams(body || {});
		b.append('_n', nonce());
		return fetch(url(action), { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: b.toString() })
			.then(function (r) { return r.json(); });
	}
	function el(tag, cls, text) { var x = document.createElement(tag); if (cls) { x.className = cls; } if (text !== undefined) { x.textContent = text; } return x; }
	function ago(ts) { var s = Math.max(0, Math.floor(Date.now() / 1000 - ts)); return Math.floor(s / 60) + ':' + ('0' + (s % 60)).slice(-2); }
	function beep() {
		try {
			var A = window.AudioContext || window.webkitAudioContext; if (!A) { return; }
			var c = new A(), o = c.createOscillator(), g = c.createGain();
			o.type = 'sine'; o.frequency.value = 880; g.gain.value = 0.15;
			o.connect(g); g.connect(c.destination); o.start(); o.stop(c.currentTime + 0.25);
			setTimeout(function () { try { c.close(); } catch (e) { /* ignore */ } }, 600);
		} catch (e) { /* bez dźwięku */ }
	}
	function itemsEl(list) {
		var ul = el('ul', 'kds-items');
		list.forEach(function (it) {
			var li = el('li');
			li.appendChild(el('span', 'kds-q', it.qty + '×'));
			var t = el('span', 'kds-n', it.name);
			li.appendChild(t);
			it.lines.forEach(function (l) {
				var d = el('div', 'kds-l' + (l.k === 'Uwagi' ? ' kds-note' : '') + (/^Bez/.test(l.k) ? ' kds-bez' : ''));
				d.textContent = l.k + ': ' + l.v;
				li.appendChild(d);
			});
			ul.appendChild(li);
		});
		return ul;
	}
	function render() {
		var b = box();
		if (!b || !data) { return; }
		b.innerHTML = '';
		var todo = data.filter(function (t) { return t.status === 'new'; }), done = data.filter(function (t) { return t.status === 'ready'; });
		if (!todo.length) { b.appendChild(el('p', 'kds-empty', 'Brak biletów z sali do przygotowania.')); }
		var grid = el('div', 'kds-grid');
		todo.forEach(function (t) {
			var mins = (Date.now() / 1000 - t.sent) / 60;
			var c = el('div', 'kds-ticket' + (mins >= 20 ? ' late2' : (mins >= 10 ? ' late1' : '')));
			c.setAttribute('data-order', t.order); c.setAttribute('data-round', t.n);
			var hd = el('div', 'kds-head');
			hd.appendChild(el('b', 'kds-table', 'Stolik ' + t.table));
			hd.appendChild(el('span', 'kds-round', t.n > 1 ? 'dobranie ' + t.n : 'runda 1'));
			var tm = el('span', 'kds-time', ago(t.sent)); tm.setAttribute('data-sent', t.sent);
			hd.appendChild(tm);
			c.appendChild(hd);
			if (t.by) { c.appendChild(el('div', 'kds-by', 'Kelner: ' + t.by)); }
			if (t.top.length) { c.appendChild(itemsEl(t.top)); }
			if (t.low.length) { if (t.top.length) { c.appendChild(el('hr', 'kds-cut')); } var lw = itemsEl(t.low); lw.classList.add('kds-low'); c.appendChild(lw); }
			var btn = el('button', 'kds-ready', 'Gotowe'); btn.type = 'button';
			btn.addEventListener('click', function () { act(btn, t, false); });
			c.appendChild(btn);
			grid.appendChild(c);
		});
		b.appendChild(grid);
		if (done.length) {
			var strip = el('div', 'kds-done');
			strip.appendChild(el('b', '', 'Gotowe – czeka na kelnera:'));
			done.forEach(function (t) {
				var chip = el('span', 'kds-chip', 'Stolik ' + t.table + (t.n > 1 ? ' (dobranie ' + t.n + ')' : ''));
				var u = el('button', 'kds-undo', 'Cofnij'); u.type = 'button';
				u.addEventListener('click', function () { act(u, t, true); });
				chip.appendChild(u);
				strip.appendChild(chip);
			});
			b.appendChild(strip);
		}
	}
	function act(btn, t, undo) {
		if (busy) { return; }
		busy = true; btn.disabled = true;
		post('kuchnia_sala_ready', { order: t.order, round: t.n, undo: undo ? 1 : '' }).then(function (d) {
			busy = false;
			if (d && d.ok) { data = d.tickets; render(); } else { btn.disabled = false; window.alert((d && d.message) || 'Nie udało się.'); load(); }
		}).catch(function () { busy = false; btn.disabled = false; });
	}
	function load() {
		if (loading || !box()) { return; }
		loading = true; last = Date.now();
		post('kuchnia_sala').then(function (d) {
			loading = false;
			if (!d || !d.ok) { return; }
			var ids = d.tickets.filter(function (t) { return t.status === 'new'; }).map(function (t) { return t.order + ':' + t.n; });
			if (seen && ids.some(function (k) { return seen.indexOf(k) < 0; })) { beep(); }
			seen = ids;
			data = d.tickets;
			render();
		}).catch(function () { loading = false; });
	}
	setInterval(function () {
		var b = box();
		if (!b) { return; }
		if (!b.querySelector('.kds-grid, .kds-done') && data) { render(); } // treść zakładki właśnie podmieniona
		if (Date.now() - last > 8000 && !busy && !document.hidden) { load(); }
		b.querySelectorAll('.kds-time[data-sent]').forEach(function (x) { x.textContent = ago(+x.getAttribute('data-sent')); });
	}, 1000);
	load();
})();
