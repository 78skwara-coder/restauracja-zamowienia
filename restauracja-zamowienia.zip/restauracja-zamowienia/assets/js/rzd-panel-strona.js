/* Restauracja – Panel restauracji: sekcja Menu strony (2.45.0) – edytor nawigacji strony.
 * Płaska lista z poziomami (depth, jak moduł 31). Przeciąganie za ☰ myszą albo palcem (pozycja razem z podmenu,
 * przesunięcie w prawo/lewo = poziom), klawiatura na ☰: ↑ ↓ przesuwa, ← → poziom; na telefonie też przyciski
 * w oknie pozycji. Zapis jednym przyciskiem – do zapisu nic nie zmienia się na stronie. */
(function () {
	'use strict';
	var K = window.rzdPanelKit;
	if (!K) { return; }
	var h = K.h, S = K.S, STEP = 28;
	function copy(o) { return JSON.parse(JSON.stringify(o)); }

	function W() { return S.work.nav; }
	function max() { return (S.data.nav && +S.data.nav.max) || 2; }
	function normalize(items) {
		items.forEach(function (it, k) {
			var m = k === 0 ? 0 : Math.min(max(), items[k - 1].depth + 1);
			it.depth = Math.max(0, Math.min(+it.depth || 0, m));
		});
	}
	function blockEnd(items, i) { var j = i; while (j + 1 < items.length && items[j + 1].depth > items[i].depth) { j++; } return j; }
	function changed() {
		normalize(W().rows);
		var dirty = JSON.stringify(state()) !== W().initial;
		S.dirty = dirty;
		var bar = K.root.querySelector('.rp-savebar');
		if (bar) { bar.classList.toggle('on', dirty); }
		var u = K.root.querySelector('.rp-nav-undo');
		if (u) { u.disabled = !dirty; }
	}
	function state() { var w = W(); return { rows: w.rows, name: w.name, locs: w.locs }; }

	function badges(it) {
		var b = [];
		if (it.cta) { b.push('przycisk'); }
		if (it.vis_user === 'in') { b.push('tylko zalogowani'); }
		if (it.vis_user === 'out') { b.push('tylko goście'); }
		if (it.vis_dev === 'mobile') { b.push('tylko telefon'); }
		if (it.vis_dev === 'desktop') { b.push('tylko komputer'); }
		if (it.blank) { b.push('nowa karta'); }
		return b;
	}

	/* ---------- przesuwanie (klawiatura, przyciski) ---------- */
	function move(i, how) {
		var items = W().rows, j = blockEnd(items, i), blk, k, at = i;
		if (how === 'up' && i > 0) {
			blk = items.splice(i, j - i + 1);
			k = i - 1; while (k > 0 && items[k].depth > blk[0].depth) { k--; }
			items.splice.apply(items, [k, 0].concat(blk)); at = k;
		} else if (how === 'down' && j + 1 < items.length) {
			blk = items.splice(i, j - i + 1);
			k = blockEnd(items, i) + 1;
			items.splice.apply(items, [k, 0].concat(blk)); at = k;
		} else if (how === 'in' && i > 0 && items[i].depth < Math.min(max(), items[i - 1].depth + 1)) {
			for (k = i; k <= j; k++) { items[k].depth = Math.min(max(), items[k].depth + 1); }
		} else if (how === 'out' && items[i].depth > 0) {
			for (k = i; k <= j; k++) { items[k].depth = Math.max(0, items[k].depth - 1); }
		} else { return i; }
		changed();
		return at;
	}

	/* ---------- przeciąganie (mysz i dotyk, Pointer Events) ---------- */
	function startDrag(e, i, list) {
		if (e.button !== undefined && e.button !== 0) { return; }
		e.preventDefault();
		var items = W().rows, j = blockEnd(items, i), d0 = items[i].depth;
		var rows = Array.prototype.slice.call(list.children);
		var block = rows.slice(i, j + 1), others = rows.filter(function (r, k) { return k < i || k > j; });
		var main = K.root.querySelector('.rp-main');
		var sx = e.clientX, ins = i, delta = 0;
		block.forEach(function (r) { r.classList.add('drag'); });
		function placeAt(n) {
			var before = others[n] || null;
			block.forEach(function (r) { list.insertBefore(r, before); });
		}
		function onMove(ev) {
			var y = ev.clientY, n = 0;
			others.forEach(function (r) { var b = r.getBoundingClientRect(); if (b.top + b.height / 2 < y) { n++; } });
			if (n !== ins) { ins = n; placeAt(n); }
			// poziom: przesunięcie w poziomie, nie głębiej niż poprzednia pozycja + 1
			var prev = ins > 0 ? items[+others[ins - 1].getAttribute('data-i')].depth : -1;
			var want = d0 + Math.round((ev.clientX - sx) / STEP);
			var nd = Math.max(0, Math.min(want, prev + 1, max()));
			delta = nd - d0;
			block.forEach(function (r) { r.style.marginLeft = Math.max(0, Math.min(max(), items[+r.getAttribute('data-i')].depth + delta)) * STEP + 'px'; });
			if (main) { // przewijanie przy krawędzi
				var mb = main.getBoundingClientRect();
				if (y < mb.top + 50) { main.scrollTop -= 12; } else if (y > mb.bottom - 50) { main.scrollTop += 12; }
			}
		}
		function onUp() {
			window.removeEventListener('pointermove', onMove);
			window.removeEventListener('pointerup', onUp);
			window.removeEventListener('pointercancel', onUp);
			var order = Array.prototype.slice.call(list.children).map(function (r) { return +r.getAttribute('data-i'); });
			var moved = {}; for (var k = i; k <= j; k++) { moved[k] = 1; }
			W().rows = order.map(function (k) {
				var it = items[k];
				if (moved[k]) { it.depth = Math.max(0, Math.min(max(), it.depth + delta)); }
				return it;
			});
			changed();
			drawList(order.indexOf(i));
		}
		window.addEventListener('pointermove', onMove);
		window.addEventListener('pointerup', onUp);
		window.addEventListener('pointercancel', onUp);
	}

	/* ---------- lista ---------- */
	function drawList(focusIdx) {
		var list = K.root.querySelector('.rp-navl');
		if (!list) { return; }
		var items = W().rows;
		list.textContent = '';
		items.forEach(function (it, i) {
			var isBlock = it.type === 'block';
			var handle = h('span', { class: 'rp-navl-h', tabindex: '0', role: 'button', 'aria-label': 'Przesuń: ' + it.label + ' (przeciągnij albo strzałki)', title: 'Przeciągnij albo użyj strzałek', text: '☰' });
			handle.addEventListener('pointerdown', function (e) { startDrag(e, i, list); });
			handle.addEventListener('keydown', function (e) {
				var map = { ArrowUp: 'up', ArrowDown: 'down', ArrowRight: 'in', ArrowLeft: 'out' };
				if (!map[e.key]) { return; }
				e.preventDefault();
				drawList(move(i, map[e.key]));
			});
			var b = badges(it);
			list.appendChild(h('li', { class: 'rp-navl-i' + (isBlock ? ' blk' : ''), 'data-i': String(i), style: 'margin-left:' + (it.depth * STEP) + 'px' }, [
				handle,
				h('button', { type: 'button', class: 'rp-navl-b', onclick: function () { isBlock ? K.toast('To blok motywu („' + it.label + '”) – zmienisz go w edytorze witryny; tu możesz go przesunąć albo usunąć.') : editItem(i); }, 'aria-label': (isBlock ? '' : 'Ustawienia: ') + it.label }, [
					h('strong', { text: it.label || '(bez nazwy)' }),
					h('small', null, [h('span', { text: (it.desc || (it.type === 'custom' ? 'Link' : '')) + (it.depth ? ' · podmenu' : '') })].concat(b.map(function (x) { return h('span', { class: 'rp-pill', text: x }); })))
				]),
				h('button', { type: 'button', class: 'rp-ico', 'aria-label': 'Usuń z menu: ' + it.label, html: K.ICON.x, onclick: function () { del(i); } })
			]));
		});
		var empty = K.root.querySelector('.rp-navl-empty');
		if (empty) { empty.hidden = items.length > 0; }
		if (focusIdx !== undefined && focusIdx > -1 && list.children[focusIdx]) { list.children[focusIdx].querySelector('.rp-navl-h').focus(); }
	}
	function del(i) {
		var items = W().rows, j = blockEnd(items, i), n = j - i;
		if (n > 0 && !window.confirm('Usunąć „' + items[i].label + '” razem z podmenu (' + n + ')?')) { return; }
		items.splice(i, j - i + 1); changed(); drawList();
	}
	function add(it) {
		it = Object.assign({ id: '', depth: 0, blank: 0, cta: 0, vis_user: '', vis_dev: '', classes: '', raw: '' }, it);
		W().rows.push(it); changed(); drawList();
		var list = K.root.querySelector('.rp-navl'), li = list && list.lastChild;
		if (li) { li.classList.add('new'); li.scrollIntoView({ block: 'nearest' }); setTimeout(function () { li.classList.remove('new'); }, 1400); }
		K.toast('Dodano „' + it.label + '” na koniec menu – zapisz, żeby było na stronie.');
	}

	function editItem(i) {
		var it = W().rows[i], custom = it.type === 'custom';
		var label = h('input', { type: 'text', class: 'rp-in', value: it.label, maxlength: '120' });
		var url = custom ? h('input', { type: 'text', class: 'rp-in', value: it.url, placeholder: 'np. facebook.com/… albo /strona/ albo #sekcja albo tel:600100200' }) : null;
		var blank = h('input', { type: 'checkbox', checked: !!+it.blank });
		var cta = h('input', { type: 'checkbox', checked: !!+it.cta });
		var vu = h('select', { class: 'rp-in' }, [['', 'wszyscy'], ['in', 'tylko zalogowani'], ['out', 'tylko goście (niezalogowani)']].map(function (o) { return h('option', { value: o[0], selected: it.vis_user === o[0], text: o[1] }); }));
		var vd = h('select', { class: 'rp-in' }, [['', 'telefon i komputer'], ['mobile', 'tylko telefon'], ['desktop', 'tylko komputer']].map(function (o) { return h('option', { value: o[0], selected: it.vis_dev === o[0], text: o[1] }); }));
		var cls = h('input', { type: 'text', class: 'rp-in', value: it.classes });
		function apply() {
			it.label = label.value.trim() || it.label;
			if (url) { it.url = url.value.trim(); }
			it.blank = blank.checked ? 1 : 0; it.cta = cta.checked ? 1 : 0; it.vis_user = vu.value; it.vis_dev = vd.value; it.classes = cls.value.trim();
		}
		function mv(how) { apply(); var at = move(i, how); K.closeSheet(); drawList(at); }
		var body = h('div', { class: 'rp-form' }, [
			K.field('Nazwa w menu', label),
			url ? K.field('Adres', url, 'Bez https:// dopisze się samo; tel: i mailto: działają.') : h('p', { class: 'rp-muted' }, ['Prowadzi do: ', it.url ? h('a', { href: it.url, target: '_blank', rel: 'noopener', text: it.url }) : '–', it.desc ? ' (' + it.desc + ')' : '']),
			h('label', { class: 'rp-check' }, [blank, h('span', { text: 'Otwieraj w nowej karcie' })]),
			h('label', { class: 'rp-check' }, [cta, h('span', { text: 'Wyróżnij jako przycisk (kolor akcentu)' })]),
			h('div', { class: 'rp-grid2' }, [K.field('Kto widzi', vu), K.field('Na jakim ekranie', vd)]),
			K.field('Klasy CSS (dla zaawansowanych)', cls),
			h('div', { class: 'rp-field' }, [h('span', { class: 'rp-label', text: 'Przesuń' }), h('div', { class: 'rp-inline' }, [
				K.btn('↑ Wyżej', function () { mv('up'); }), K.btn('↓ Niżej', function () { mv('down'); }),
				K.btn('→ Do podmenu', function () { mv('in'); }), K.btn('← Poziom wyżej', function () { mv('out'); })
			])])
		]);
		K.openSheet(it.label || 'Pozycja menu', body, [
			K.btn('Usuń z menu', function () { K.closeSheet(); del(i); }, 'rp-btn-del'),
			K.btn('Gotowe', function () { apply(); changed(); K.closeSheet(); drawList(i); }, 'rp-btn-pri')
		]);
	}

	/* ---------- panel „Dodaj” ---------- */
	var seq = 0;
	function addPanel(d) {
		var res = h('div', { class: 'rp-navs', 'aria-live': 'polite' });
		var q = h('input', { type: 'search', class: 'rp-in', placeholder: 'szukaj… (puste = strony i kategorie)', 'aria-label': 'Szukaj stron, kategorii, produktów' });
		var t = null;
		function search() {
			var my = ++seq;
			res.textContent = 'szukam…';
			K.api('nav_search', { s: q.value.trim() }).then(function (x) {
				if (my !== seq) { return; }
				res.textContent = '';
				if (!x.groups.length) { res.appendChild(h('p', { class: 'rp-muted', text: 'Nic nie znaleziono.' })); }
				x.groups.forEach(function (g) {
					res.appendChild(h('h4', { text: g.group }));
					res.appendChild(h('div', { class: 'rp-navs-l' }, g.items.map(function (it) { return h('button', { type: 'button', class: 'rp-btn rp-btn-s', text: '+ ' + it.label, onclick: function () { add(copy(it)); } }); })));
				});
			}).catch(function (e) { res.textContent = e.message; });
		}
		q.addEventListener('input', function () { clearTimeout(t); t = setTimeout(search, 300); });
		setTimeout(search, 0);
		var cl = h('input', { type: 'text', class: 'rp-in', placeholder: 'napis, np. Facebook', 'aria-label': 'Napis linku' });
		var cu = h('input', { type: 'text', class: 'rp-in', placeholder: 'adres, np. facebook.com/… albo /strona/ albo #sekcja', 'aria-label': 'Adres linku' });
		var tel = h('input', { type: 'tel', class: 'rp-in', placeholder: 'numer, np. 600 100 200', 'aria-label': 'Numer telefonu' });
		return h('section', { class: 'rp-card rp-nav-add' }, [
			h('h2', { text: 'Dodaj do menu' }),
			h('h3', { class: 'rp-h3', text: 'Gotowe pozycje' }),
			h('div', { class: 'rp-navs-l' }, d.quick.map(function (qi) { return h('button', { type: 'button', class: 'rp-btn rp-btn-s', title: qi.hint, text: '+ ' + qi.item.label, onclick: function () { add(copy(qi.item)); } }); })),
			h('h3', { class: 'rp-h3', text: 'Strony, kategorie, produkty' }), q, res,
			h('h3', { class: 'rp-h3', text: 'Własny link' }), cl, cu,
			K.btn('+ Dodaj link', function () {
				var l = cl.value.trim(), u = cu.value.trim();
				if (!l && !u) { cl.focus(); return; }
				add({ type: 'custom', object: 'custom', object_id: 0, label: l || u, url: u, desc: 'Link' }); cl.value = ''; cu.value = '';
			}),
			h('h3', { class: 'rp-h3', text: 'Zadzwoń' }), tel,
			K.btn('+ Dodaj „Zadzwoń”', function () {
				var n = tel.value.replace(/[^0-9+]/g, '');
				if (n.length < 7) { tel.focus(); K.toast('Wpisz numer telefonu.', true); return; }
				add({ type: 'custom', object: 'custom', object_id: 0, label: 'Zadzwoń', url: 'tel:' + n, desc: 'Link' }); tel.value = '';
			}),
			h('small', { class: 'rp-hint', text: 'Na telefonie „Zadzwoń” otwiera wybieranie numeru.' })
		]);
	}

	/* ---------- sekcja ---------- */
	function setData(x) {
		S.data.nav = x;
		var locs = x.locations.filter(function (l) { return l.on; }).map(function (l) { return l.slug; });
		S.work.nav = { rows: copy(x.rows), name: x.name, locs: locs, cur: x.cur };
		S.work.nav.initial = JSON.stringify(state());
		S.dirty = false;
	}
	function loadMenu(id) {
		if (S.dirty && !window.confirm('Masz niezapisane zmiany w menu. Przejść bez zapisu?')) { K.render(); return; }
		K.api('nav', { menu: id }).then(function (x) { setData(x); K.render(); }).catch(function (e) { K.toast(e.message, true); });
	}
	function act(action, data, b) {
		K.busy(b, true);
		return K.api(action, data).then(function (x) { setData(x); K.toast(x.message); K.render(); }, function (e) { K.busy(b, false); K.toast(e.message, true); });
	}

	function secNav(main) {
		var d = S.data.nav;
		if (!d) {
			K.loading(main, 'Menu strony');
			K.api('nav', {}).then(function (x) { setData(x); K.render(); }).catch(function (e) { main.textContent = ''; K.failBox(main, e, K.render); });
			return;
		}
		if (!S.work.nav) { setData(d); }
		var w = W();
		main.appendChild(K.pageHead('Menu strony', 'Motyw ' + d.theme + ' – ' + (d.block ? 'motyw blokowy: edytujesz nawigacje bloku Nawigacja (te same co w edytorze witryny).' : 'motyw klasyczny: te same menu co w Wygląd → Menu; położenie (nagłówek, stopka…) wybierasz pod menu.') + ' Zmiany trafiają na stronę dopiero po „Zapisz menu”.', h('a', { class: 'rp-btn', href: d.home, target: '_blank', rel: 'noopener', text: 'Zobacz stronę ↗' })));
		var nm = h('input', { type: 'text', class: 'rp-in', placeholder: 'nazwa nowego menu', 'aria-label': 'Nazwa nowego menu' });
		var bar = [];
		if (d.menus.length) {
			var sel = h('select', { class: 'rp-in', 'aria-label': 'Menu do edycji', onchange: function () { loadMenu(+sel.value); } }, d.menus.map(function (m) { return h('option', { value: String(m.id), selected: m.id === d.cur, text: m.name }); }));
			bar.push(h('div', { class: 'rp-field rp-nav-pick' }, [h('span', { class: 'rp-label', text: 'Menu' }), sel]));
			bar.push(K.btn('Kopiuj', function (e) { act('nav_new', { copy: d.cur, name: '' }, e.currentTarget); }));
			bar.push(K.btn('Usuń', function (e) { if (window.confirm('Usunąć menu „' + d.name + '”?')) { act('nav_delete', { menu: d.cur }, e.currentTarget); } }, 'rp-btn-del'));
		}
		bar.push(h('div', { class: 'rp-inline rp-nav-new' }, [nm, K.btn('+ Nowe menu', function (e) { act('nav_new', { name: nm.value.trim(), copy: 0 }, e.currentTarget); })]));
		main.appendChild(h('div', { class: 'rp-card rp-nav-bar' }, bar));
		if (!d.menus.length) { main.appendChild(h('div', { class: 'rp-empty' }, [h('p', { text: 'Nie ma jeszcze żadnego menu – utwórz pierwsze powyżej.' })])); return; }

		var name = h('input', { type: 'text', class: 'rp-in', value: w.name, 'aria-label': 'Nazwa menu', oninput: function () { w.name = name.value; changed(); } });
		var tree = h('section', { class: 'rp-card rp-nav-tree' }, [
			K.field('Nazwa menu', name),
			h('p', { class: 'rp-hint', text: 'Przeciągnij za ☰ (myszą albo palcem); przesunięcie w prawo = podmenu. Klawiatura: na ☰ strzałki ↑ ↓ przesuwają, ← → zmieniają poziom. Kliknij pozycję – nazwa, adres, kto widzi, przesuwanie.' }),
			h('ul', { class: 'rp-navl' }),
			h('p', { class: 'rp-navl-empty rp-muted', text: 'Menu jest puste – dodaj pozycje.', hidden: true })
		]);
		if (!d.block && d.locations.length) {
			tree.appendChild(h('fieldset', { class: 'rp-field rp-fs' }, [h('legend', { class: 'rp-label', text: 'Gdzie pokazać to menu (położenia motywu)' })].concat(d.locations.map(function (l) {
				var c = h('input', { type: 'checkbox', checked: w.locs.indexOf(l.slug) > -1, onchange: function () {
					var at = w.locs.indexOf(l.slug);
					if (c.checked && at < 0) { w.locs.push(l.slug); } else if (!c.checked && at > -1) { w.locs.splice(at, 1); }
					changed();
				} });
				return h('label', { class: 'rp-check' }, [c, h('span', null, [l.label, l.hint ? h('small', { class: 'rp-hint', text: ' – ' + l.hint }) : null, l.other ? h('small', { class: 'rp-hint', text: ' (teraz: ' + l.other + ')' }) : null])]);
			})).concat(d.astra ? [h('small', { class: 'rp-hint', text: d.astra })] : [])));
		} else if (d.block && d.header) {
			tree.appendChild(d.header.ref === d.cur ? h('p', { class: 'rp-fnote', text: '✓ To menu jest w nagłówku strony.' }) : (d.header.tpl ? h('div', { class: 'rp-inline' }, [h('span', { class: 'rp-muted', text: 'To menu nie jest w nagłówku strony.' }), K.btn('Pokaż to menu w nagłówku', function (e) {
				if (S.dirty) { K.toast('Najpierw zapisz zmiany w menu.', true); return; }
				if (window.confirm('Nagłówek strony będzie pokazywał menu „' + d.name + '”. Kontynuować?')) { act('nav_header', { menu: d.cur }, e.currentTarget); }
			})]) : null));
		}
		tree.appendChild(h('div', { class: 'rp-actions' }, [K.btn('Cofnij zmiany', function () {
			if (!window.confirm('Cofnąć wszystkie niezapisane zmiany?')) { return; }
			setData(d); K.render();
		}, 'rp-nav-undo', { disabled: !S.dirty })]));
		main.appendChild(h('div', { class: 'rp-nav-cols' }, [tree, addPanel(d)]));
		main.appendChild(K.saveBar(function (b) {
			K.busy(b, true);
			var data = { menu: d.cur, rows: w.rows, name: w.name };
			if (!d.block) { data.locations = w.locs; }
			K.api('nav_save', data).then(function (x) { setData(x); K.toast(x.message); K.render(); }, function (e) { K.busy(b, false); K.toast(e.message, true); });
		}, 'Zapisz menu'));
		drawList();
	}

	K.sections.strona = secNav;
})();
