/* Restauracja – Panel restauracji: sekcja Zespół (2.45.0) – zakładki Konta (pracownicy: zakładanie, rola,
 * hasło, wyłączenie, usunięcie), Uprawnienia (rola × uprawnienie, dni wstecz w Kuchni, własne role)
 * i Kurier – awaryjny PIN. Zależność: uprawnienia „wymaga Panelu WP” zaznaczają Panel WP (jak konfigurator). */
(function () {
	'use strict';
	var K = window.rzdPanelKit;
	if (!K) { return; }
	var h = K.h, S = K.S;
	var TABS = [['konta', 'Konta'], ['uprawnienia', 'Uprawnienia'], ['kurier', 'PIN kuriera']];
	function copy(o) { return JSON.parse(JSON.stringify(o)); }
	function done(x) { S.data.team = x; S.work.roles = null; S.dirty = false; K.toast(x.message, !!x.warn); K.render(); return x; }
	function fail(b) { return function (e) { K.busy(b, false); K.toast(e.message, true); }; }

	function secTeam(main) {
		var d = S.data.team;
		if (!d) {
			K.loading(main, 'Zespół');
			K.load('team', 'team').then(K.render).catch(function (e) { main.textContent = ''; K.failBox(main, e, K.render); });
			return;
		}
		var tab = TABS.some(function (t) { return t[0] === S.tab; }) ? S.tab : 'konta';
		main.appendChild(K.pageHead('Zespół', 'Konta pracowników i to, co każda rola widzi i może zrobić.'));
		main.appendChild(K.tabsEl(TABS, tab));
		if (tab === 'uprawnienia') { perms(main, d); } else if (tab === 'kurier') { pin(main, d); } else { users(main, d); }
	}

	/* ---------- Konta ---------- */
	function users(main, d) {
		main.appendChild(h('div', { class: 'rp-inline rp-mb' }, [
			d.canCreate ? K.btn('+ Nowe konto', function () { userEdit(null, d); }, 'rp-btn-pri') : null,
			h('small', { class: 'rp-muted', text: 'Każdy pracownik ma własne konto (logowanie na telefonie zapamiętane). Klienci sklepu nie są tu pokazywani.' })
		]));
		var l = h('div', { class: 'rp-list' });
		if (!d.users.length) { l.appendChild(h('p', { class: 'rp-empty-s', text: 'Brak kont pracowników.' })); }
		d.users.forEach(function (u) {
			l.appendChild(h('button', { type: 'button', class: 'rp-row' + (u.disabled ? ' off' : ''), disabled: u.canEdit ? null : true, onclick: function () { userEdit(u, d); } }, [
				h('span', { class: 'rp-row-main' }, [
					h('strong', { text: u.name + (u.self ? ' (Ty)' : '') }),
					h('small', { text: u.login + (u.email ? ' · ' + u.email : '') + (u.last ? ' · ostatnio: ' + u.last : ' · jeszcze się nie logował(a)') })
				]),
				h('span', { class: 'rp-pill' + (u.disabled ? '' : ' ok'), text: u.disabled ? 'wyłączone · ' + u.roleName : u.roleName })
			]));
		});
		main.appendChild(l);
		main.appendChild(h('p', { class: 'rp-muted', text: 'Wyłączone konto nie może się zalogować (jest wylogowywane ze wszystkich urządzeń), ale zostaje – do ponownego włączenia. Konta Administratora zmienia tylko Administrator.' }));
	}

	function userEdit(u, d) {
		var isNew = !u;
		u = u || { id: 0, login: '', name: '', email: '', role: '' };
		var login = h('input', { type: 'text', class: 'rp-in', value: u.login, autocomplete: 'off', autocapitalize: 'none', spellcheck: 'false', disabled: isNew ? null : true, placeholder: 'np. ania.kuchnia' });
		var name = h('input', { type: 'text', class: 'rp-in', value: u.name, placeholder: 'np. Ania (kuchnia)' });
		var email = h('input', { type: 'email', class: 'rp-in', value: u.email, autocomplete: 'off', placeholder: 'opcjonalnie' });
		var role = h('select', { class: 'rp-in', disabled: u.self ? true : null }, [isNew ? h('option', { value: '', text: '– wybierz rolę –' }) : null].concat(Object.keys(d.assign).map(function (k) { return h('option', { value: k, selected: u.role === k, text: d.assign[k] }); })));
		var pass = h('input', { type: 'text', class: 'rp-in', value: '', autocomplete: 'new-password', placeholder: isNew ? 'puste = wygeneruję' : 'puste = bez zmiany', spellcheck: 'false' });
		var err = h('p', { class: 'rp-err', role: 'alert', hidden: true });
		var body = h('div', { class: 'rp-form' }, [
			K.field('Login', login, isNew ? 'Do logowania. Bez polskich znaków i spacji. Później się nie zmienia.' : null),
			K.field('Imię / nazwa widoczna', name),
			K.field('E-mail', email, 'Potrzebny do „Nie pamiętam hasła”. Może zostać pusty (np. kurier bez maila).'),
			K.field('Rola', role, u.self ? 'Roli własnego konta nie zmienisz.' : 'Co rola może – zakładka Uprawnienia.'),
			K.field(isNew ? 'Hasło' : 'Nowe hasło', pass, 'Co najmniej 8 znaków. Przekaż je pracownikowi osobiście, nie przez SMS na grupie.'),
			err
		]);
		var foot = [];
		if (!isNew && !u.self) {
			foot.push(K.btn(u.disabled ? 'Włącz konto' : 'Wyłącz konto', function (e) {
				if (!u.disabled && !window.confirm('Wyłączyć konto „' + u.name + '”? Zostanie wylogowane ze wszystkich urządzeń.')) { return; }
				K.busy(e.currentTarget, true);
				K.api('user_toggle', { id: u.id, enable: u.disabled ? '1' : '0' }).then(function (x) { K.closeSheet(); done(x); }, fail(e.currentTarget));
			}, u.disabled ? '' : 'rp-btn-del'));
			if (u.canDel) {
				foot.push(K.btn('Usuń', function (e) {
					if (!window.confirm('Usunąć konto „' + u.name + '” na zawsze? (Lepiej „Wyłącz konto” – da się cofnąć.)')) { return; }
					K.busy(e.currentTarget, true);
					K.api('user_delete', { id: u.id }).then(function (x) { K.closeSheet(); done(x); }, fail(e.currentTarget));
				}, 'rp-btn-link'));
			}
			if (u.email) {
				foot.push(K.btn('Wyślij link do hasła', function (e) {
					K.busy(e.currentTarget, true);
					K.api('user_reset', { id: u.id }).then(function (x) { K.closeSheet(); done(x); }, fail(e.currentTarget));
				}, 'rp-btn-link'));
			}
		}
		foot.push(K.btn(isNew ? 'Załóż konto' : 'Zapisz', function (e) {
			err.hidden = true;
			if (pass.value && pass.value.length < 8) { err.textContent = 'Hasło musi mieć co najmniej 8 znaków.'; err.hidden = false; return; }
			var data = { name: name.value.trim(), email: email.value.trim(), pass: pass.value };
			if (!u.self) { data.role = role.value; }
			if (isNew) { data.login = login.value.trim(); }
			K.busy(e.currentTarget, true);
			K.api('user_save', { id: u.id, user: data }).then(function (x) {
				K.closeSheet(); done(x);
				if (x.newPass) {
					K.openSheet('Konto założone', h('div', { class: 'rp-form' }, [
						h('p', { text: 'Login: ' + data.login }),
						h('p', null, ['Hasło: ', h('strong', { class: 'rp-code rp-pass', text: x.newPass })]),
						h('p', { class: 'rp-muted', text: 'Zapisz albo przekaż teraz – później hasła już nie zobaczysz (można ustawić nowe). Logowanie: ' + d.login })
					]), [K.btn('Gotowe', K.closeSheet, 'rp-btn-pri')]);
				}
			}, function (er) { K.busy(e.currentTarget, false); err.textContent = er.message; err.hidden = false; });
		}, 'rp-btn-pri'));
		K.openSheet(isNew ? 'Nowe konto' : u.name, body, foot);
	}

	/* ---------- Uprawnienia ---------- */
	function perms(main, d) {
		if (!S.work.roles) { S.work.roles = copy(d.roles); }
		var roles = S.work.roles, cat = d.catalog;
		var note = h('p', { class: 'rp-fnote warn', hidden: true, role: 'status' });
		function needs(r, k) {
			var p = cat.filter(function (c) { return c.key === k; })[0];
			var at = r.perms.indexOf(k), msg = '';
			if (at < 0) {
				r.perms.push(k);
				if (p.needsShop && r.perms.indexOf('shop') < 0) { r.perms.push('shop'); msg = 'Zaznaczono też „Panel WP” – „' + p.name + '” bez niego nie działa.'; }
			} else {
				if (k === 'shop' && r.slug === 'shop_manager') { K.toast('Manager zawsze ma „Panel WP” (to rola kierownika sklepu WooCommerce).', true); return; }
				r.perms.splice(at, 1);
				if (k === 'shop') {
					var off = cat.filter(function (c) { return c.needsShop && r.perms.indexOf(c.key) > -1; });
					r.perms = r.perms.filter(function (x) { return !off.some(function (c) { return c.key === x; }); });
					if (off.length) { msg = 'Bez „Panelu WP” odznaczono też: ' + off.map(function (c) { return c.name; }).join(', ') + '.'; }
				}
			}
			var m = K.root.querySelector('.rp-main'), wr = K.root.querySelector('.rp-pm-wrap');
			var top = m ? m.scrollTop : 0, left = wr ? wr.scrollLeft : 0;
			K.dirty(); K.render();
			m = K.root.querySelector('.rp-main'); wr = K.root.querySelector('.rp-pm-wrap');
			if (m) { m.scrollTop = top; } if (wr) { wr.scrollLeft = left; }
			if (msg) { K.toast(msg); }
		}
		main.appendChild(h('p', { class: 'rp-muted', text: 'Zaznacz uprawnienie w kolumnie roli i zapisz – zmiana działa od razu dla wszystkich kont z tą rolą. Administrator ma zawsze wszystko. „Dni wstecz w Kuchni” – ile dni w przeszłość można otworzyć w Historii i kalendarzyku Kuchni (puste = bez limitu).' }));
		main.appendChild(note);
		// tabela: wiersze = uprawnienia, kolumny = role (na telefonie przewijana w bok)
		var head = h('tr', null, [h('th', { scope: 'col', class: 'rp-pm-perm', text: 'Uprawnienie' }), h('th', { scope: 'col', class: 'rp-pm-role rp-pm-adm' }, [h('span', { text: 'Administrator' }), h('small', { text: d.admins + ' os.' })])].concat(roles.map(function (r) {
			var inp = h('input', { type: 'text', class: 'rp-in rp-pm-name', value: r.name, maxlength: '40', 'aria-label': 'Nazwa roli', oninput: function () { r.name = inp.value; K.dirty(); } });
			return h('th', { scope: 'col', class: 'rp-pm-role' }, [inp, h('small', { text: r.users + ' os.' + (r.builtin ? '' : ' · własna') })]);
		})));
		var rows = cat.map(function (c) {
			return h('tr', null, [
				h('th', { scope: 'row', class: 'rp-pm-perm' }, [h('strong', { text: c.name }), h('small', { text: c.desc + (c.needsShop ? ' Wymaga „Panelu WP”.' : '') })]),
				h('td', { class: 'rp-pm-adm' }, [h('input', { type: 'checkbox', checked: true, disabled: true, 'aria-label': 'Administrator – ' + c.name })])
			].concat(roles.map(function (r) {
				var locked = r.slug === 'shop_manager' && c.key === 'shop';
				return h('td', null, [h('input', { type: 'checkbox', checked: r.perms.indexOf(c.key) > -1, disabled: locked ? true : null, 'aria-label': r.name + ' – ' + c.name, onchange: function () { needs(r, c.key); } })]);
			})));
		});
		rows.push(h('tr', { class: 'rp-pm-hd' }, [h('th', { scope: 'row', class: 'rp-pm-perm' }, [h('strong', { text: 'Dni wstecz w Kuchni' }), h('small', { text: 'Historia i kalendarzyk zakładek; puste = bez limitu (max ' + d.histMax + ').' })]), h('td', { class: 'rp-pm-adm', text: '–' })].concat(roles.map(function (r) {
			var n = h('input', { type: 'number', class: 'rp-in rp-pm-n', min: '0', max: String(d.histMax), placeholder: 'bez', value: r.histDays === '' ? '' : String(r.histDays), 'aria-label': r.name + ' – dni wstecz w Kuchni', oninput: function () { r.histDays = n.value; K.dirty(); } });
			return h('td', null, [n]);
		}))));
		rows.push(h('tr', { class: 'rp-pm-del' }, [h('th', { scope: 'row', class: 'rp-pm-perm' }), h('td', { class: 'rp-pm-adm' })].concat(roles.map(function (r) {
			if (r.builtin) { return h('td'); }
			return h('td', null, [K.btn('Usuń rolę', function (e) {
				if (r.users) { K.toast('Rola „' + r.name + '” ma konta (' + r.users + ') – najpierw zmień im rolę w zakładce Konta.', true); return; }
				if (S.dirty) { K.toast('Najpierw zapisz zmiany w tabeli.', true); return; }
				if (!window.confirm('Usunąć rolę „' + r.name + '”?')) { return; }
				K.busy(e.currentTarget, true);
				K.api('role_delete', { slug: r.slug }).then(done, fail(e.currentTarget));
			}, 'rp-btn-link rp-btn-del')]);
		}))));
		main.appendChild(h('div', { class: 'rp-tablewrap rp-pm-wrap', tabindex: '0', role: 'region', 'aria-label': 'Tabela uprawnień' }, [h('table', { class: 'rp-pm' }, [h('thead', null, [head]), h('tbody', null, rows)])]));
		var nn = h('input', { type: 'text', class: 'rp-in', maxlength: '40', placeholder: 'np. Kelner albo Pomoc kuchenna', 'aria-label': 'Nazwa nowej roli' });
		var base = h('select', { class: 'rp-in', 'aria-label': 'Uprawnienia na start' }, [h('option', { value: '', text: '– bez uprawnień –' })].concat(roles.map(function (r) { return h('option', { value: r.slug, text: 'jak „' + r.name + '”' }); })));
		main.appendChild(h('section', { class: 'rp-card rp-form' }, [h('h2', { text: 'Dodaj rolę' }),
			h('div', { class: 'rp-grid2' }, [K.field('Nazwa', nn), K.field('Uprawnienia na start', base)]),
			h('div', { class: 'rp-actions' }, [K.btn('+ Dodaj rolę', function (e) {
				if (S.dirty) { K.toast('Najpierw zapisz zmiany w tabeli.', true); return; }
				if (!nn.value.trim()) { nn.focus(); K.toast('Podaj nazwę roli.', true); return; }
				K.busy(e.currentTarget, true);
				K.api('role_add', { name: nn.value.trim(), base: base.value }).then(done, fail(e.currentTarget));
			})])
		]));
		main.appendChild(K.saveBar(function (b) {
			var out = {};
			roles.forEach(function (r) { out[r.slug] = { name: r.name, perms: r.perms, hist_days: r.histDays === '' ? '' : String(r.histDays) }; });
			K.busy(b, true);
			K.api('team_roles', { roles: out }).then(function (x) { done(x); K.refreshWarnings(); }, fail(b));
		}, 'Zapisz uprawnienia'));
	}

	/* ---------- PIN kuriera ---------- */
	function pin(main, d) {
		var on = h('input', { type: 'checkbox', class: 'rp-switch-in', checked: d.pin.on });
		var code = h('input', { type: 'text', class: 'rp-in rp-in-s', value: d.pin.pin, autocomplete: 'off', spellcheck: 'false', 'aria-label': 'PIN' });
		main.appendChild(h('section', { class: 'rp-card rp-form' }, [
			h('p', { text: 'Kurier loguje się własnym kontem (rola z uprawnieniem „Kurier”, logowanie na 30 dni). PIN jest tylko na zastępstwo – np. kurier na jeden dzień bez konta.' }),
			h('p', { class: 'rp-muted', text: 'Każdy z PIN-em może oznaczać zamówienia jako „Dostarczone” i widzi adresy klientów, a w zamówieniu zapisze się tylko „kurier (PIN awaryjny)”. Po 5 błędnych próbach wejście jest blokowane na 15 minut. Wyłącz PIN, gdy zastępstwo się skończy.' }),
			h('label', { class: 'rp-switch' }, [on, h('span', { class: 'rp-switch-ui' }), h('span', { text: 'Awaryjny PIN kuriera' + (d.pin.on && d.pin.since ? ' (włączony od ' + d.pin.since + ')' : '') })]),
			K.field('PIN (co najmniej 4 znaki: litery, cyfry)', code),
			h('div', { class: 'rp-actions' }, [K.btn('Zapisz', function (e) {
				K.busy(e.currentTarget, true);
				K.api('pin_save', { on: on.checked ? '1' : '0', pin: code.value.trim() }).then(done, fail(e.currentTarget));
			}, 'rp-btn-pri')])
		]));
	}

	K.sections.zespol = secTeam;
})();
