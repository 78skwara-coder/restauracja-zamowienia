/* Restauracja – Zamówienia i Dostawy: rzd-koszyk-powrot.js (z 07-koszyk.php) */
(function () {
	if (document.querySelector('.kc-back-to-shop')) { return; } // już jest (stary koszyk przez PHP)
	var target = document.querySelector(
		'.wp-block-woocommerce-cart, .wc-block-cart, .woocommerce-cart-form, ' +
		'.wc-empty-cart-message, .cart-empty, .wp-block-woocommerce-empty-cart-block'
	);
	if (!target || !target.parentNode) { return; }
	var p = document.createElement('p');
	p.className = 'kc-back-to-shop';
	var a = document.createElement('a');
	a.className = 'button wc-backward';
	a.href = rzdKcBack.url;
	a.textContent = rzdKcBack.text;
	p.appendChild(a);
	target.parentNode.insertBefore(p, target);
})();

/**
 * Usunięcie samego napisu "Nowości"/"Nowe w sklepie" nad pustym koszykiem.
 * CSS ukrywa siatkę produktów (jej klasy znamy), ale nagłówek nad nią to
 * osobny element z tekstem, którego CSS "po klasie" nie złapie. Dodatkowo,
 * jeśli to blokowy koszyk (React), taki nagłówek może pojawić się w DOM
 * dopiero PO wczytaniu strony (dociągnięty przez skrypt koszyka) – dlatego
 * pilnujemy zmian na stronie przez chwilę, zamiast sprawdzić tylko raz.
 */
(function () {
	var re = /nowo[śs]ci|nowe w sklepie|mo[żz]e ci[ęe] zainteresowa|polecane produkty|may be interested|you might like/i;
	var emptyTxt = rzdKcBack.emptyTxt;
	function sweep(root) {
		(root || document).querySelectorAll('.wc-block-cart__empty-cart__title').forEach(function (el) {
			if (el.textContent !== emptyTxt) { el.textContent = emptyTxt; }
		});
		(root || document).querySelectorAll('h1, h2, h3, h4, h5, .wp-block-heading').forEach(function (el) {
			if (el.getAttribute('data-kc-hidden') === '1') { return; }
			if (re.test(el.textContent || '')) {
				el.setAttribute('data-kc-hidden', '1');
				el.style.display = 'none';
				var sib = el.nextElementSibling;
				if (sib) { sib.style.display = 'none'; }
			}
		});
	}
	sweep();
	if (window.MutationObserver) {
		var mo = new MutationObserver(function () { sweep(); });
		mo.observe(document.body, { childList: true, subtree: true });
		setTimeout(function () { mo.disconnect(); }, 8000);
	}
})();
