/* Restauracja – Zamówienia i Dostawy: okienko terminu dostawy, konflikt terminu, krok bramy „termin” (2.26.13: plik zamiast kodu w stronie) */
// dcData – ustawiane przez WordPress przed tym plikiem (wp_add_inline_script)
	(function () {
		var modal = document.getElementById('dc-modal');
		if (!modal) { return; }
		var q = function (s) { return modal.querySelector(s); };
		var elTitle = q('.dc-title'), elMsg = q('.dc-msg'), elDate = q('.dc-date'),
			elTimes = q('.dc-times'), elOk = q('.dc-ok'), elCancel = q('.dc-cancel'),
			elTown = q('.dc-town'); // tylko gdy działa matryca miejscowości (moduł 20)
		var st = { dates: [], time: '', pid: 0, done: null, prefer: '' }; // prefer: dzień z harmonogramu (2.26.1)

		function withParam(url, k, v) { return url + (url.indexOf('?') > -1 ? '&' : '?') + k + '=' + encodeURIComponent(v); }
		function dcCleanReload() {
			var u = new URL(window.location.href);
			['add-to-cart', 'quantity', 'added-to-cart', 'remove_item'].forEach(function (k) { u.searchParams.delete(k); });
			if (window.rzdKeepScroll) { window.rzdKeepScroll(); } // 2.27.2: po przeładowaniu – to samo miejsce na stronie
			window.location.href = u.toString();
		}
		function msg(t, isErr) { elMsg.textContent = t || ''; elMsg.className = 'dc-msg' + (isErr ? ' dc-err' : ''); }
		function closeModal() { modal.hidden = true; st.done = null; st.prefer = ''; }

		function paintBars(label) {
			var bars = document.querySelectorAll('.dc-bar');
			for (var i = 0; i < bars.length; i++) {
				var bar = bars[i];
				bar.className = 'dc-bar';
				bar.innerHTML = '';
				var span = document.createElement('span');
				span.appendChild(document.createTextNode('Dostawa: '));
				var strong = document.createElement('strong');
				strong.className = 'dc-bar-label';
				strong.textContent = label;
				span.appendChild(strong);
				var btn = document.createElement('button');
				btn.type = 'button'; btn.className = 'dc-change'; btn.textContent = 'Zmień termin';
				bar.appendChild(span); bar.appendChild(btn);
			}
		}

		function windowLabel(t) {
			// To samo, co dc_time_window_label() w PHP – godzina wyjazdu + 1h,
			// bo klient wybiera przedział, nie dokładną minutę wyjazdu.
			var m = /^([01]\d|2[0-3]):([0-5]\d)$/.exec(t);
			if (!m) { return t; }
			var end = (parseInt(m[1], 10) + 1) % 24;
			return t + '–' + (end < 10 ? '0' : '') + end + ':' + m[2];
		}

		function renderTimes() {
			elTimes.innerHTML = '';
			var d = null, i;
			for (i = 0; i < st.dates.length; i++) { if (st.dates[i].date === elDate.value) { d = st.dates[i]; } }
			if (!d) { elOk.disabled = true; return; }
			var cur = dcData.slot;
			if (st.time && d.times.indexOf(st.time) === -1) { st.time = ''; }
			if (!st.time) {
				st.time = (cur && cur.date === d.date && d.times.indexOf(cur.time) > -1) ? cur.time : d.times[0];
			}
			d.times.forEach(function (t) {
				var b = document.createElement('button');
				b.type = 'button';
				b.textContent = (d.labels && d.labels[t]) ? d.labels[t] : windowLabel(t);
				b.className = 'dc-time' + (t === st.time ? ' dc-on' : '');
				b.addEventListener('click', function () { st.time = t; renderTimes(); });
				elTimes.appendChild(b);
			});
			elOk.disabled = false;
		}

		function openModal(pid, done, title, prefer) {
			st.pid = pid || 0; st.done = done; st.prefer = prefer || '';
			elTitle.textContent = title || 'Wybierz termin dostawy';
			if (elTown && !elTown.value) { elTown.value = dcData.town || ''; }
			modal.hidden = false;
			loadSlots();
			if (elTown && !elTown.value) { elTown.focus(); }
		}

		function loadSlots() {
			st.time = ''; st.dates = [];
			elDate.innerHTML = ''; elTimes.innerHTML = ''; elOk.disabled = true;
			msg('Wczytuję dostępne terminy…');
			var url = withParam(dcData.slotsUrl, 'product_id', st.pid);
			if (elTown) { url = withParam(url, 'town', elTown.value); }
			fetch(url, { credentials: 'same-origin' })
				.then(function (r) { return r.json(); })
				.then(function (d) {
					if (!d || !d.ok || !d.dates || !d.dates.length) {
						// Puste pole miejscowości to podpowiedź, nie błąd – bez czerwieni.
						var hint = d && d.need_town && elTown && !elTown.value.trim();
						msg((d && d.message) || 'Brak dostępnych terminów.', !hint);
						return;
					}
					st.dates = d.dates;
					d.dates.forEach(function (x) {
						var o = document.createElement('option');
						o.value = x.date; o.textContent = x.label;
						elDate.appendChild(o);
					});
					var cur = dcData.slot, preferOk = false;
					if (cur) {
						for (var i = 0; i < d.dates.length; i++) { if (d.dates[i].date === cur.date) { elDate.value = cur.date; } }
					}
					if (st.prefer) { // „Dodaj na ten dzień” z harmonogramu – ten dzień ma pierwszeństwo
						for (var j = 0; j < d.dates.length; j++) { if (d.dates[j].date === st.prefer) { elDate.value = st.prefer; preferOk = true; } }
					}
					msg(d.mode === 'all'
						? 'Wybierz datę i godzinę dostawy. Produkty, których nie da się dostarczyć w tym terminie, zostaną oznaczone na liście.'
						: 'Najwcześniejszy możliwy termin jest zaznaczony. Całe zamówienie zostanie dostarczone o wybranej godzinie.');
					if (st.prefer && preferOk) {
						msg('Wybierz godzinę dostawy. Całe zamówienie zostanie dostarczone w tym terminie.');
					} else if (st.prefer) {
						msg('Na wybrany dzień nie ma wolnego terminu dostawy' + (elTown && elTown.value ? ' do miejscowości ' + elTown.value : '') +
							(dcData.slot ? ' razem z produktami z Twojego koszyka' : '') + '. Wybierz inny dzień – skład zestawu zmieni się razem z datą.', true);
					}
					renderTimes();
				})
				.catch(function () { msg('Nie udało się pobrać terminów. Spróbuj ponownie.', true); });
		}

		elDate.addEventListener('change', function () { st.time = ''; renderTimes(); });
		if (elTown) {
			// Po wybraniu z listy – terminy tylko dla tej miejscowości.
			elTown.addEventListener('change', loadSlots);
		}
		elCancel.addEventListener('click', closeModal);
		// 2.26.1: harmonogram zestawu (moduł 05) otwiera okienko z wybranym dniem.
		window.dcOpenTerm = function (pid, done, title, prefer) { openModal(pid, done, title, prefer); };
		document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !modal.hidden) { closeModal(); } });

		elOk.addEventListener('click', function () {
			elOk.disabled = true;
			msg('Zapisuję…');
			var body = 'date=' + encodeURIComponent(elDate.value) + '&time=' + encodeURIComponent(st.time) + '&product_id=' + encodeURIComponent(st.pid) +
				(elTown ? '&town=' + encodeURIComponent(elTown.value) : '');
			fetch(dcData.setUrl, {
				method: 'POST', credentials: 'same-origin',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: body
			})
				.then(function (r) { return r.json(); })
				.then(function (r) {
					if (!r || !r.ok) { msg((r && r.message) || 'Nie udało się zapisać terminu.', true); elOk.disabled = false; return; }
					dcData.slot = r.slot;
					if (r.town) { dcData.town = r.town; if (elTown) { elTown.value = r.town; } }
					paintBars(r.label);
					var done = st.done;
					closeModal();
					if (done) { done(); }
				})
				.catch(function () { msg('Nie udało się zapisać terminu. Spróbuj ponownie.', true); elOk.disabled = false; });
		});

		// Krok bramy dodawania do koszyka (snippet 8): termin dostawy + zgodność produktu
		var elConf = document.getElementById('dc-conflict');
		var confState = { pid: 0, next: null };

		function goToList() {
			if (!dcData.listUrl) { return; }
			try {
				var u = new URL(dcData.listUrl, window.location.href);
				if (u.pathname.replace(/\/$/, '') !== window.location.pathname.replace(/\/$/, '')) { window.location.href = u.href; }
			} catch (err) {}
		}

		// Brak wspólnego terminu z koszykiem (2.25.3): zmiana daty nic nie da.
		var TITLE_CHANGE = 'Zmień datę, by dodać do koszyka', TITLE_APART = 'Tych produktów nie dowieziemy razem';
		function groupsTxt(arr) { return (arr.length > 1 ? 'grup ' : 'grupy ') + arr.join(', '); }
		function noCommonText(d) {
			var pg = d.product_groups || [], cg = d.cart_groups || [];
			var why = (pg.length && cg.length)
				? '„' + d.product + '” należy do ' + groupsTxt(pg) + ', a w koszyku masz produkty z ' + groupsTxt(cg) + '. Te grupy dowozimy w innych godzinach'
				: '„' + d.product + '” nie ma wspólnego terminu dostawy z produktami z Twojego koszyka';
			return why + ', a jedno zamówienie to jedna dostawa. Złóż osobne zamówienie na ten produkt, gdy skończysz obecne.';
		}

		function showConflict(d, ctx, next) {
			var apart = !!d.no_common;
			elConf.querySelector('.dc-conf-title').textContent = apart ? TITLE_APART : TITLE_CHANGE;
			elConf.querySelector('.dc-act-change').hidden = apart;
			elConf.querySelector('.dc-act-cart').hidden = !apart;
			elConf.querySelector('.dc-conflict-msg').textContent = buildConflictText(d);
			confState.pid = ctx.pid;
			confState.next = next;
			elConf.hidden = false;
		}

		elConf.querySelector('.dc-conf-change').addEventListener('click', function () {
			elConf.hidden = true;
			openModal(confState.pid, confState.next, 'Zmień termin dostawy');
		});
		elConf.querySelector('.dc-conf-cart').addEventListener('click', function () {
			elConf.hidden = true;
			if (dcData.cartUrl) { window.location.href = dcData.cartUrl; }
		});
		elConf.querySelector('.dc-conf-other').addEventListener('click', function () {
			elConf.hidden = true;
			goToList();
		});
		document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !elConf.hidden) { elConf.hidden = true; } });

		// Ikonka "i" (więcej) na liście – ta sama treść co przy próbie dodania
		// do koszyka, tylko czysto informacyjnie (jeden przycisk OK), bez
		// żadnej akcji zmiany terminu wprost stąd.
		var elInfo = document.getElementById('dc-info-popup');
		function buildConflictText(d) {
			if (d.no_common) { return noCommonText(d); }
			var alt = '';
			if (d.alt) { alt = d.alt_same_day ? 'o ' + d.alt : 'najwcześniej ' + d.alt; }
			return 'Produkt „' + d.product + '” nie może zostać dodany do koszyka, ponieważ ' +
				(d.has_cart ? 'w koszyku znajduje się produkt z dostawą ' : 'wybrany termin dostawy to ') + d.cart_label +
				(alt ? ', a wybrany produkt można dostarczyć ' + alt + '.' : ', a wybrany produkt nie jest teraz dostępny w żadnym terminie dostawy.');
		}
		document.addEventListener('click', function (e) {
			var icon = e.target.closest ? e.target.closest('.rl2-info-icon, .rl2-info-icon-label') : null;
			if (!icon) { return; }
			var pid = icon.getAttribute('data-product');
			if (!pid) { return; }
			fetch(withParam(dcData.checkUrl, 'product_id', pid), { credentials: 'same-origin' })
				.then(function (r) { return r.json(); })
				.then(function (d) {
					if (!d || d.ok) { return; }
					elInfo.querySelector('.dc-title').textContent = d.no_common ? TITLE_APART : TITLE_CHANGE;
					elInfo.querySelector('.dc-info-msg').textContent = buildConflictText(d);
					elInfo.hidden = false;
				});
		});
		elInfo.querySelector('.dc-info-close').addEventListener('click', function () { elInfo.hidden = true; });
		document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !elInfo.hidden) { elInfo.hidden = true; } });

		window.kcAddSteps = window.kcAddSteps || [];
		window.kcAddSteps.push({
			order: 10,
			run: function (ctx, next) {
				if (!dcData.slot) { openModal(ctx.pid, next); return; }
				fetch(withParam(dcData.checkUrl, 'product_id', ctx.pid), { credentials: 'same-origin' })
					.then(function (r) { return r.json(); })
					.then(function (d) {
						if (!d || d.ok) { next(); return; }
						showConflict(d, ctx, next);
					})
					.catch(function () { next(); }); // błąd sieci – serwer i tak zwaliduje termin
			}
		});

		// Zmiana terminu (pasek) i przycisk [wybierz_date_dostawy]
		document.addEventListener('click', function (e) {
			var c = e.target && e.target.closest ? e.target.closest('.dc-change, .dc-open-picker') : null;
			if (!c) { return; }
			e.preventDefault();
			var title = c.classList.contains('dc-open-picker') ? 'Wybierz datę dostawy' : 'Zmień termin dostawy';
			openModal(0, dcCleanReload, title);
		});
	})();
