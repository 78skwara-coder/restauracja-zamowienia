/* Restauracja – Panel restauracji [rzd_panel] (moduł 34, 2.44.0). Konfiguracja: window.rzdPanel. */
(function () {
	'use strict';
	var C = window.rzdPanel;
	var root = document.getElementById('rzd-panel');
	if (!C || !root) { return; }

	var DAYS_SHORT = ['Pn', 'Wt', 'Śr', 'Cz', 'Pt', 'So', 'Nd'];
	var MONTHS = ['styczeń', 'luty', 'marzec', 'kwiecień', 'maj', 'czerwiec', 'lipiec', 'sierpień', 'wrzesień', 'październik', 'listopad', 'grudzień'];
	var ICON = {
		menu: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h16"/></svg>',
		out: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5M21 12H9"/></svg>',
		back: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 6l-6 6 6 6"/></svg>',
		x: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg>',
		left: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 6l-6 6 6 6"/></svg>',
		right: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg>',
		shop: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 9l1.5-5h13L20 9"/><path d="M4 9h16v2a3 3 0 0 1-6 0 3 3 0 0 1-4 0 3 3 0 0 1-6 0z"/><path d="M5 13v7h14v-7"/></svg>'
	};

	/* ---------- narzędzia ---------- */
	function h(tag, a, kids) {
		var e = document.createElement(tag);
		if (a) {
			Object.keys(a).forEach(function (k) {
				var v = a[k];
				if (v === null || v === undefined || v === false) { return; }
				if (k === 'class') { e.className = v; }
				else if (k === 'text') { e.textContent = v; }
				else if (k === 'html') { e.innerHTML = v; } // tylko stałe ikonki z ICON albo HTML z serwera (escapowany tam)
				else if (k === 'value') { e.value = v; }
				else if (k === 'checked') { e.checked = !!v; }
				else if (k === 'selected') { e.selected = !!v; }
				else if (k.slice(0, 2) === 'on') { e.addEventListener(k.slice(2), v); }
				else { e.setAttribute(k, v === true ? '' : v); }
			});
		}
		(kids || []).forEach(function (c) {
			if (c === null || c === undefined || c === false) { return; }
			e.appendChild(typeof c === 'string' || typeof c === 'number' ? document.createTextNode(String(c)) : c);
		});
		return e;
	}
	function api(action, data) {
		var fd = new FormData();
		fd.append('action', 'rzd_panel');
		fd.append('do', action);
		fd.append('_n', C.nonce);
		Object.keys(data || {}).forEach(function (k) {
			var v = data[k];
			if (window.Blob && v instanceof window.Blob) { fd.append(k, v); return; } // plik (obrazek)
			fd.append(k, (v !== null && typeof v === 'object') ? JSON.stringify(v) : (v === true ? '1' : (v === false ? '0' : String(v === undefined || v === null ? '' : v))));
		});
		return fetch(C.ajax, { method: 'POST', body: fd, credentials: 'same-origin' }).then(function (r) {
			return r.json().catch(function () { return { ok: false, message: 'Błąd serwera (' + r.status + ').' }; });
		}, function () {
			return { ok: false, message: 'Brak połączenia – sprawdź internet.' };
		}).then(function (d) {
			if (!d || !d.ok) { throw new Error((d && d.message) || 'Nie udało się.'); }
			return d;
		});
	}
	var toastT = null;
	function toast(msg, err) {
		var old = document.querySelector('.rp-toast');
		if (old) { old.remove(); }
		var t = h('div', { class: 'rp-toast' + (err ? ' err' : ''), role: err ? 'alert' : 'status', text: msg });
		document.body.appendChild(t);
		clearTimeout(toastT);
		toastT = setTimeout(function () { t.remove(); }, err ? 6000 : 2800);
	}
	function money(v) {
		if (v === '' || v === null || v === undefined) { return '–'; }
		var n = parseFloat(v);
		return (Math.round(n) === n ? String(n) : n.toFixed(2).replace('.', ',')) + ' zł';
	}
	function ymd(d) { return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2); }
	function parseYmd(s) { var p = String(s).split('-'); return new Date(+p[0], +p[1] - 1, +p[2]); }
	function dateLabel(s) {
		var d = parseYmd(s);
		return ['niedz.', 'pon.', 'wt.', 'śr.', 'czw.', 'pt.', 'sob.'][d.getDay()] + ' ' + d.getDate() + '.' + ('0' + (d.getMonth() + 1)).slice(-2) + '.' + d.getFullYear();
	}
	function field(label, input, hint) {
		return h('label', { class: 'rp-field' }, [h('span', { class: 'rp-label', text: label }), input, hint ? h('small', { class: 'rp-hint', text: hint }) : null]);
	}
	function btn(text, fn, cls, attrs) {
		var a = { type: 'button', class: 'rp-btn' + (cls ? ' ' + cls : ''), text: text, onclick: fn };
		Object.keys(attrs || {}).forEach(function (k) { a[k] = attrs[k]; });
		return h('button', a);
	}
	function busy(b, on) { if (b) { b.disabled = !!on; b.classList.toggle('is-busy', !!on); } }
	function warnBox(list, onGo) {
		if (!list || !list.length) { return null; }
		return h('div', { class: 'rp-warns' }, list.map(function (w) {
			return h('div', { class: 'rp-warn ' + (w.level === 'error' ? 'err' : 'warn'), role: 'note' }, [
				h('span', { text: w.text }),
				onGo && w.section ? btn('Przejdź', function () { onGo(w.section); }, 'rp-btn-link') : null
			]);
		}));
	}

	/* ---------- okno (arkusz) ---------- */
	var sheetEl = null;
	function closeSheet() { if (sheetEl) { sheetEl.remove(); sheetEl = null; document.removeEventListener('keydown', sheetKey); } }
	function sheetKey(e) { if (e.key === 'Escape') { closeSheet(); } }
	function openSheet(title, body, foot) {
		closeSheet();
		var box = h('div', { class: 'rp-sheet', role: 'dialog', 'aria-modal': 'true', 'aria-label': title }, [
			h('div', { class: 'rp-sheet-head' }, [h('h2', { text: title }), h('button', { type: 'button', class: 'rp-ico', 'aria-label': 'Zamknij', html: ICON.x, onclick: closeSheet })]),
			h('div', { class: 'rp-sheet-body' }, [body]),
			foot ? h('div', { class: 'rp-sheet-foot' }, foot) : null
		]);
		sheetEl = h('div', { class: 'rp-shade', onclick: function (e) { if (e.target === sheetEl) { closeSheet(); } } }, [box]);
		document.body.appendChild(sheetEl);
		document.addEventListener('keydown', sheetKey);
		var f = box.querySelector('input:not([type=checkbox]):not([type=radio]),select,textarea');
		if (f) { setTimeout(function () { f.focus(); }, 30); }
		return box;
	}

	/* ---------- stan, adres, szkielet ---------- */
	var S = { boot: null, sec: 'start', dirty: false, data: {}, msg: null, mobileNav: false, work: {} };
	var params = new URLSearchParams(location.search);
	S.sec = params.get('sekcja') || 'start';
	S.msgFilter = { form: params.get('form') || '', status: '', s: '', page: 1 };
	S.tab = params.get('tab') || '';
	S.urlId = parseInt(params.get('id') || params.get('zestaw') || '0', 10) || 0; // pozycja z adresu (przekierowanie z kokpitu)

	function can(sec) { return S.boot && S.boot.sections.some(function (s) { return s.key === sec; }); }
	function go(sec, push) {
		if (!can(sec)) { sec = 'start'; }
		if (S.dirty && sec !== S.sec && !window.confirm('Masz niezapisane zmiany. Wyjść bez zapisu?')) { return; }
		S.dirty = false;
		S.termEdit = null; S.edit = null; S.preset = null; S.zset = null; S.zedit = null; // robocze kopie (po wyjściu bez zapisu – od nowa)
		S.work = {}; // robocze kopie sekcji 2.45.0 (Sklep, Wygląd, Menu strony, Formularze, Zespół)
		if (sec !== S.sec || push !== false) { S.tab = ''; S.urlId = 0; }
		S.sec = sec;
		S.msg = null;
		S.mobileNav = false;
		if (push !== false) {
			var u = new URL(C.base, location.href);
			if (sec !== 'start') { u.searchParams.set('sekcja', sec); }
			if (sec === 'wiadomosci' && S.msgFilter.form) { u.searchParams.set('form', S.msgFilter.form); }
			history.pushState({ sec: sec }, '', u.toString());
		}
		render();
		var m = root.querySelector('.rp-main');
		if (m) { m.scrollTop = 0; }
	}
	window.addEventListener('popstate', function () {
		var p = new URLSearchParams(location.search);
		S.dirty = false;
		go(p.get('sekcja') || 'start', false);
		S.tab = p.get('tab') || '';
		render();
	});
	/** Zakładka w sekcji (adres ?sekcja=…&tab=…). */
	function setTab(k) {
		if (k === S.tab) { return; }
		if (S.dirty && !window.confirm('Masz niezapisane zmiany. Przejść bez zapisu?')) { return; }
		S.dirty = false;
		S.termEdit = null; S.edit = null; S.preset = null; S.work = {};
		S.tab = k;
		var u = new URL(C.base, location.href);
		u.searchParams.set('sekcja', S.sec);
		u.searchParams.set('tab', k);
		history.pushState({ sec: S.sec, tab: k }, '', u.toString());
		render();
		var m = root.querySelector('.rp-main');
		if (m) { m.scrollTop = 0; }
	}
	function tabsEl(list, cur) {
		var el = h('div', { class: 'rp-tabs', role: 'tablist' }, list.map(function (t) {
			return h('button', { type: 'button', role: 'tab', class: 'rp-tab' + (cur === t[0] ? ' on' : ''), 'aria-selected': cur === t[0] ? 'true' : 'false', text: t[1], onclick: function () { setTab(t[0]); } });
		}));
		setTimeout(function () { // na telefonie zakładki przewijają się w bok – pokaż wybraną
			var on = el.querySelector('.rp-tab.on');
			if (on && el.scrollWidth > el.clientWidth) { el.scrollLeft = on.offsetLeft - (el.clientWidth - on.offsetWidth) / 2; }
		}, 0);
		return el;
	}
	window.addEventListener('beforeunload', function (e) { if (S.dirty) { e.preventDefault(); e.returnValue = ''; } });

	function brandEl() {
		var b = S.boot.brand;
		return h('a', { class: 'rp-brand', href: b.url, title: b.label + ' – ' + b.name, 'aria-label': b.label }, [
			b.logo ? h('img', { src: b.logo, alt: '' }) : h('span', { class: 'rp-brand-txt', text: b.name })
		]);
	}
	function render() {
		root.textContent = '';
		var nav = h('nav', { class: 'rp-nav' + (S.mobileNav ? ' open' : ''), 'aria-label': 'Sekcje panelu' }, S.boot.sections.map(function (s) {
			var badge = s.key === 'wiadomosci' && S.boot.newMsgs > 0 ? h('span', { class: 'rp-badge', text: String(S.boot.newMsgs), 'aria-label': S.boot.newMsgs + ' nowych' }) : null;
			return h('a', { href: s.key === 'start' ? C.base : C.base + (C.base.indexOf('?') > -1 ? '&' : '?') + 'sekcja=' + s.key, class: 'rp-nav-a' + (S.sec === s.key ? ' on' : ''), 'aria-current': S.sec === s.key ? 'page' : null, onclick: function (e) { e.preventDefault(); go(s.key); } }, [h('span', { text: s.name }), badge]);
		}));
		var head = h('header', { class: 'rp-head' }, [
			h('button', { type: 'button', class: 'rp-ico rp-burger', 'aria-label': 'Sekcje', 'aria-expanded': S.mobileNav ? 'true' : 'false', html: ICON.menu, onclick: function () { S.mobileNav = !S.mobileNav; render(); } }),
			brandEl(),
			h('div', { class: 'rp-head-t' }, [h('strong', { text: 'Panel restauracji' }), h('small', { text: S.boot.user })]),
			h('a', { class: 'rp-ico rp-shop', href: S.boot.shop, title: 'Sklep', 'aria-label': 'Sklep', html: ICON.shop }),
			h('a', { class: 'rp-ico', href: C.logout, title: 'Wyloguj', 'aria-label': 'Wyloguj', html: ICON.out })
		]);
		var main = h('main', { class: 'rp-main' });
		root.appendChild(head);
		root.appendChild(h('div', { class: 'rp-body' }, [nav, main]));
		var fn = SECTIONS[S.sec] || SECTIONS.start;
		fn(main);
	}
	function pageHead(title, sub, right) {
		return h('div', { class: 'rp-ph' }, [h('div', { class: 'rp-ph-t' }, [h('h1', { text: title }), sub ? h('p', { text: sub }) : null]), right || null]);
	}
	function loading(main, title) {
		main.appendChild(pageHead(title));
		main.appendChild(h('p', { class: 'rp-load', text: 'Wczytuję…' }));
	}
	function failBox(main, e, retry) {
		main.appendChild(h('div', { class: 'rp-warn err' }, [h('span', { text: e.message }), btn('Spróbuj ponownie', retry, 'rp-btn-link')]));
	}
	function load(key, action, data) {
		return api(action, data).then(function (d) { S.data[key] = d; return d; });
	}

	/* ============================================================
	 * START
	 * ============================================================ */
	function secStart(main) {
		var b = S.boot;
		main.appendChild(pageHead('Dzień dobry' + (b.user ? ', ' + b.user.split(' ')[0] : ''), 'Wszystkie ustawienia restauracji w jednym miejscu.'));
		var w = warnBox(b.warnings, go);
		if (w) { main.appendChild(h('h2', { class: 'rp-h2', text: 'Do sprawdzenia' })); main.appendChild(w); }
		if (b.newMsgs > 0 && can('wiadomosci')) {
			main.appendChild(h('button', { type: 'button', class: 'rp-note', onclick: function () { go('wiadomosci'); } }, [h('strong', { text: b.newMsgs === 1 ? '1 nowa wiadomość' : b.newMsgs + ' nowe wiadomości' }), h('span', { text: 'z formularzy kontaktowych – otwórz' })]));
		}
		if (b.tiles.length) {
			main.appendChild(h('h2', { class: 'rp-h2', text: 'Ekrany' }));
			main.appendChild(h('div', { class: 'rp-tiles' }, b.tiles.map(function (t) {
				return h('a', { class: 'rp-tile rp-tile-' + t.key, href: t.url }, [h('strong', { text: t.name }), h('span', { text: t.desc })]);
			})));
		}
		var set = b.sections.filter(function (s) { return s.key !== 'start'; });
		if (set.length) {
			main.appendChild(h('h2', { class: 'rp-h2', text: 'Ustawienia' }));
			main.appendChild(h('div', { class: 'rp-tiles rp-tiles-s' }, set.map(function (s) {
				return h('button', { type: 'button', class: 'rp-tile', onclick: function () { go(s.key); } }, [h('strong', { text: s.name })]);
			})));
		}
		if (b.canBrand) { main.appendChild(brandCard()); }
	}
	function brandCard() {
		var cfg = S.boot.brandCfg;
		var sel = cfg.link;
		var url = h('input', { type: 'url', class: 'rp-in', value: cfg.url || '', placeholder: 'https://…', 'aria-label': 'Adres' });
		var urlWrap = h('div', { class: 'rp-brand-url', hidden: sel !== 'custom' ? true : null }, [url]);
		var radios = Object.keys(S.boot.brandOpts).map(function (k) {
			return h('label', { class: 'rp-radio' }, [h('input', { type: 'radio', name: 'rp-brand', value: k, checked: k === sel, onchange: function () { sel = k; urlWrap.hidden = k !== 'custom'; } }), h('span', { text: S.boot.brandOpts[k] })]);
		});
		var save = btn('Zapisz', function () {
			busy(save, true);
			api('brand_save', { link: sel, url: url.value }).then(function (d) {
				S.boot.brand = d.brand; S.boot.brandCfg = d.brandCfg; toast('Zapisano.'); render();
			}).catch(function (e) { toast(e.message, true); busy(save, false); });
		}, 'rp-btn-pri');
		return h('section', { class: 'rp-card' }, [
			h('h2', { text: 'Logo w lewym górnym rogu prowadzi do' }),
			h('p', { class: 'rp-muted', text: 'Dotyczy panelu i ekranów obsługi (Kuchnia, Kurier, Edycja menu, Sala) – z każdego miejsca jednym kliknięciem wejdziesz do sklepu. Logo bierze się z motywu strony (Wygląd → Dostosuj → Tożsamość witryny).' }),
			h('div', { class: 'rp-radios' }, radios),
			urlWrap,
			h('div', { class: 'rp-actions' }, [save])
		]);
	}

	/* ============================================================
	 * MIEJSCOWOŚCI
	 * ============================================================ */
	function secTowns(main) {
		var d = S.data.towns;
		if (!d) {
			loading(main, 'Miejscowości');
			load('towns', 'towns').then(render).catch(function (e) { main.textContent = ''; failBox(main, e, render); });
			return;
		}
		main.appendChild(pageHead('Miejscowości', 'Dowozimy tylko do miejscowości z tej listy. Kwoty brutto; progi liczone od wartości produktów przed rabatem.', btn('+ Dodaj miejscowość', function () { townEdit(-1); }, 'rp-btn-pri')));
		var w = warnBox(d.warnings);
		if (w) { main.appendChild(w); }
		if (d.wcShip && !d.method) {
			main.appendChild(h('p', { class: 'rp-muted' }, ['Metodę „Dostawa wg miejscowości” dodajesz w ', h('a', { href: d.wcShip, text: 'WooCommerce → Ustawienia → Wysyłka' }), '.']));
		}
		if (!d.rows.length) {
			main.appendChild(h('div', { class: 'rp-empty' }, [h('p', { text: 'Nie ma jeszcze żadnej miejscowości.' }), btn('+ Dodaj pierwszą', function () { townEdit(-1); }, 'rp-btn-pri')]));
		} else {
			var list = h('div', { class: 'rp-towns' });
			list.appendChild(h('div', { class: 'rp-town rp-town-h', 'aria-hidden': 'true' }, ['Miejscowość', 'Dostawa', 'Darmowa od', 'Minimum', 'Punkty', 'Kiedy'].map(function (t) { return h('span', { text: t }); })));
			d.rows.forEach(function (r, i) {
				list.appendChild(h('button', { type: 'button', class: 'rp-town', onclick: function () { townEdit(i); } }, [
					h('strong', { class: 'rp-town-n', text: r.name }),
					h('span', { 'data-l': 'Dostawa', text: parseFloat(r.cost || 0) > 0 ? money(r.cost) : 'gratis' }),
					h('span', { 'data-l': 'Darmowa od', text: money(r.free_from) }),
					h('span', { 'data-l': 'Minimum', text: money(r.min_order) }),
					h('span', { 'data-l': 'Punkty', text: String(r.points || 1) }),
					h('span', { 'data-l': 'Kiedy', text: townWhen(r, d.days) }),
					r.aliases ? h('small', { class: 'rp-town-a', text: 'Też: ' + r.aliases }) : null
				]));
			});
			main.appendChild(list);
		}
		main.appendChild(h('details', { class: 'rp-card rp-preview' }, [h('summary', { text: 'Tak widzi klient (cennik dostaw na stronie)' }), h('div', { class: 'rp-prev-box', html: d.preview || '<p>Brak miejscowości.</p>' })]));
		main.appendChild(h('p', { class: 'rp-muted', text: 'Punkty = ile miejsca w oknie dostawy zajmuje zamówienie do tej miejscowości (działa w trybie okien dostaw). Godziny dotyczą godziny wyjazdu; puste = bez ograniczeń. Dni: brak zaznaczenia = codziennie.' }));
	}
	function townWhen(r, days) {
		var parts = [];
		if (r.days && r.days.length && r.days.length < 7) { parts.push(r.days.map(function (k) { return days[k] || k; }).join(', ')); }
		if (r.from || r.to) { parts.push((r.from || '…') + '–' + (r.to || '…')); }
		return parts.length ? parts.join(' · ') : 'codziennie';
	}
	function townEdit(i) {
		var d = S.data.towns;
		var r = i >= 0 ? d.rows[i] : { name: '', cost: '', free_from: '', min_order: '', points: 1, days: [], from: '', to: '', aliases: '' };
		var f = {
			name: h('input', { type: 'text', class: 'rp-in', value: r.name, maxlength: '60', required: true, autocomplete: 'off' }),
			cost: h('input', { type: 'text', inputmode: 'decimal', class: 'rp-in', value: r.cost, placeholder: '0 = gratis' }),
			free: h('input', { type: 'text', inputmode: 'decimal', class: 'rp-in', value: r.free_from, placeholder: 'brak progu' }),
			min: h('input', { type: 'text', inputmode: 'decimal', class: 'rp-in', value: r.min_order, placeholder: 'brak minimum' }),
			points: h('input', { type: 'number', class: 'rp-in', value: r.points || 1, min: '1', max: '99' }),
			from: h('input', { type: 'time', class: 'rp-in', value: r.from || '' }),
			to: h('input', { type: 'time', class: 'rp-in', value: r.to || '' }),
			aliases: h('input', { type: 'text', class: 'rp-in', value: r.aliases || '', placeholder: 'np. Lipowa W., Lipowa-Wieś' })
		};
		var picked = (r.days || []).slice();
		var dayBox = h('div', { class: 'rp-days', role: 'group', 'aria-label': 'Dni dostaw' }, Object.keys(d.days).map(function (k) {
			var b = h('button', { type: 'button', class: 'rp-day' + (picked.indexOf(k) > -1 ? ' on' : ''), 'aria-pressed': picked.indexOf(k) > -1 ? 'true' : 'false', text: d.days[k] });
			b.addEventListener('click', function () {
				var at = picked.indexOf(k);
				if (at > -1) { picked.splice(at, 1); } else { picked.push(k); }
				b.classList.toggle('on', at < 0); b.setAttribute('aria-pressed', at < 0 ? 'true' : 'false');
			});
			return b;
		}));
		var err = h('p', { class: 'rp-err', role: 'alert', hidden: true });
		var body = h('div', { class: 'rp-form' }, [
			field('Nazwa miejscowości', f.name),
			h('div', { class: 'rp-grid3' }, [field('Koszt dostawy (zł)', f.cost), field('Darmowa od (zł)', f.free), field('Minimalne zamówienie (zł)', f.min)]),
			h('div', { class: 'rp-field' }, [h('span', { class: 'rp-label', text: 'Dni dostaw' }), dayBox, h('small', { class: 'rp-hint', text: 'Nic nie zaznaczone = codziennie.' })]),
			h('div', { class: 'rp-grid3' }, [field('Wyjazd od', f.from), field('Wyjazd do', f.to), field('Punkty', f.points, 'Miejsce w oknie dostawy.')]),
			field('Inne nazwy', f.aliases, 'Pisownie, które klient może wpisać – po przecinku.'),
			err
		]);
		var save = btn(i >= 0 ? 'Zapisz' : 'Dodaj', function () {
			var name = f.name.value.trim();
			var dup = d.rows.some(function (x, j) { return j !== i && x.name.toLowerCase() === name.toLowerCase(); });
			if (!name) { err.textContent = 'Podaj nazwę miejscowości.'; err.hidden = false; f.name.focus(); return; }
			if (dup) { err.textContent = 'Ta miejscowość już jest na liście.'; err.hidden = false; f.name.focus(); return; }
			var free = f.free.value.replace(',', '.').trim();
			var min = f.min.value.replace(',', '.').trim();
			if (free !== '' && min !== '' && parseFloat(free) < parseFloat(min) && !window.confirm('„Darmowa od” jest niższa niż minimum – każde przyjęte zamówienie będzie miało darmową dostawę. Zapisać mimo to?')) { return; }
			var row = { name: name, cost: f.cost.value, free_from: f.free.value, min_order: f.min.value, points: f.points.value, days: picked, from: f.from.value, to: f.to.value, aliases: f.aliases.value };
			var rows = d.rows.slice();
			if (i >= 0) { rows[i] = row; } else { rows.push(row); }
			saveTowns(rows, save);
		}, 'rp-btn-pri');
		var foot = [save];
		if (i >= 0) {
			foot.unshift(btn('Usuń', function () {
				if (!window.confirm('Usunąć „' + r.name + '”? Klienci z tej miejscowości nie złożą zamówienia z dostawą.')) { return; }
				var rows = d.rows.slice(); rows.splice(i, 1); saveTowns(rows, null);
			}, 'rp-btn-del'));
		}
		openSheet(i >= 0 ? r.name : 'Nowa miejscowość', body, foot);
	}
	function saveTowns(rows, b) {
		busy(b, true);
		api('towns_save', { rows: rows }).then(function (d) {
			S.data.towns = d; closeSheet(); toast(d.message || 'Zapisano.'); refreshWarnings(); render();
		}).catch(function (e) { busy(b, false); toast(e.message, true); });
	}
	function refreshWarnings() {
		api('boot').then(function (d) { S.boot = d; }).catch(function () {});
	}

	/* ============================================================
	 * TERMINY
	 * ============================================================ */
	var TERM_TABS = [['dni', 'Dni wolne i limit'], ['grupy', 'Grupy'], ['godziny', 'Godziny w dniach tygodnia'], ['okna', 'Okna dostaw']];
	function secTerms(main) {
		var d = S.data.terms;
		if (!d) {
			loading(main, 'Terminy');
			load('terms', 'terms').then(function (x) { S.termScope = S.termScope || 'all'; var t = parseYmd(x.today); S.termMonth = S.termMonth || new Date(t.getFullYear(), t.getMonth(), 1); render(); }).catch(function (e) { main.textContent = ''; failBox(main, e, render); });
			return;
		}
		var tab = S.tab || 'dni';
		main.appendChild(pageHead('Terminy', 'Kiedy dowozimy: dni wolne, kalendarze grup (kategorii), godziny w dniach tygodnia i okna dostaw.'));
		main.appendChild(tabsEl(TERM_TABS, tab));
		if (tab !== 'dni' && KIT.termTabs[tab]) { KIT.termTabs[tab](main, d); return; }
		// ustawienia ogólne
		var en = h('input', { type: 'checkbox', class: 'rp-switch-in', checked: d.enabled });
		var max = h('input', { type: 'number', class: 'rp-in rp-in-s', value: d.max, min: '1', max: '999' });
		var save = btn('Zapisz', function () { saveTerms({ enabled: en.checked, max: max.value }, save); }, 'rp-btn-pri');
		main.appendChild(h('section', { class: 'rp-card' }, [
			h('label', { class: 'rp-switch' }, [en, h('span', { class: 'rp-switch-ui', 'aria-hidden': 'true' }), h('span', { text: 'Wybór terminu dostawy w sklepie' })]),
			h('p', { class: 'rp-muted', text: d.enabled ? 'Włączony – klient wybiera dzień i godzinę przy pierwszym dodaniu do koszyka.' : 'Wyłączony – sklep nie pyta o termin.' }),
			field('Maksymalnie zamówień na jedno okno dostawy', max, d.windows ? 'Teraz nieużywane – działa tryb okien dostaw, pojemność (w punktach) bierze się z okna.' : 'Pełne okno znika z wyboru dla kolejnych klientów. Dotyczy jednej godziny wyjazdu we wszystkich grupach razem.'),
			h('div', { class: 'rp-actions' }, [save])
		]));
		// kalendarz dni bez dostaw
		var scopes = [{ id: 'all', name: 'Wszystkie grupy' }].concat(d.groups.map(function (g) { return { id: String(g.id), name: g.name }; }));
		var cal = h('section', { class: 'rp-card' }, [
			h('h2', { text: 'Dni bez dostaw' }),
			h('p', { class: 'rp-muted', text: 'Kliknij dzień, żeby oznaczyć go jako wolny (albo przywrócić). Zapisuje się od razu. Liczba na dniu = zamówienia czekające na dostawę.' }),
			scopes.length > 1 ? h('div', { class: 'rp-chips', role: 'tablist', 'aria-label': 'Dla kogo' }, scopes.map(function (s) {
				return h('button', { type: 'button', role: 'tab', class: 'rp-chip' + (S.termScope === s.id ? ' on' : ''), 'aria-selected': S.termScope === s.id ? 'true' : 'false', text: s.name, onclick: function () { S.termScope = s.id; render(); } });
			})) : null,
			calendar(d)
		]);
		main.appendChild(cal);
		main.appendChild(upcomingOff(d));
		if (d.offDays && d.offDays.length && !d.windows) {
			main.appendChild(h('p', { class: 'rp-muted', text: 'Stałe dni tygodnia bez dostaw (wszystkie grupy): ' + d.offDays.map(function (k) { return { Mon: 'pon.', Tue: 'wt.', Wed: 'śr.', Thu: 'czw.', Fri: 'pt.', Sat: 'sob.', Sun: 'niedz.' }[k] || k; }).join(', ') + ' – zmienisz w zakładce „Godziny w dniach tygodnia”.' }));
		}
		if (d.offDays && d.offDays.length && d.windows) {
			main.appendChild(h('p', { class: 'rp-muted', text: 'Dni tygodnia bez dostaw w trybie okien ustawiasz w zakładce „Okna dostaw” (znacznik Dostawa).' }));
		}
	}
	function blockedFor(d, scope) {
		if (scope === 'all') { return d.blocked; }
		var g = d.groups.filter(function (x) { return String(x.id) === scope; })[0];
		return g ? g.blocked : [];
	}
	function calendar(d) {
		var m = S.termMonth;
		var first = new Date(m.getFullYear(), m.getMonth(), 1);
		var start = (first.getDay() + 6) % 7; // poniedziałek = 0
		var days = new Date(m.getFullYear(), m.getMonth() + 1, 0).getDate();
		var blocked = blockedFor(d, S.termScope);
		var grid = h('div', { class: 'rp-cal-grid', role: 'grid' });
		DAYS_SHORT.forEach(function (n) { grid.appendChild(h('span', { class: 'rp-cal-dn', text: n, role: 'columnheader' })); });
		for (var i = 0; i < start; i++) { grid.appendChild(h('span', { class: 'rp-cal-pad' })); }
		for (var day = 1; day <= days; day++) {
			(function (day) {
				var key = ymd(new Date(m.getFullYear(), m.getMonth(), day));
				var past = key < d.today;
				var off = blocked.indexOf(key) > -1;
				var offAll = S.termScope !== 'all' && d.blocked.indexOf(key) > -1;
				var n = d.orders[key] || 0;
				grid.appendChild(h('button', {
					type: 'button', role: 'gridcell',
					class: 'rp-cal-d' + (off ? ' off' : '') + (offAll ? ' off-all' : '') + (past ? ' past' : '') + (key === d.today ? ' today' : ''),
					disabled: past ? true : null,
					'aria-pressed': off ? 'true' : 'false',
					'aria-label': dateLabel(key) + (off ? ', bez dostaw' : '') + (offAll ? ', bez dostaw dla wszystkich' : '') + (n ? ', zamówień: ' + n : ''),
					onclick: function () { toggleOff(key); }
				}, [h('span', { class: 'rp-cal-n', text: String(day) }), n ? h('span', { class: 'rp-cal-o', text: String(n) }) : null, off || offAll ? h('span', { class: 'rp-cal-x', text: 'wolne' }) : null]));
			})(day);
		}
		var label = MONTHS[m.getMonth()] + ' ' + m.getFullYear();
		var today = parseYmd(d.today);
		var minM = new Date(today.getFullYear(), today.getMonth(), 1);
		return h('div', { class: 'rp-cal' }, [
			h('div', { class: 'rp-cal-head' }, [
				h('button', { type: 'button', class: 'rp-ico', 'aria-label': 'Poprzedni miesiąc', html: ICON.left, disabled: m <= minM ? true : null, onclick: function () { S.termMonth = new Date(m.getFullYear(), m.getMonth() - 1, 1); render(); } }),
				h('strong', { text: label, 'aria-live': 'polite' }),
				h('button', { type: 'button', class: 'rp-ico', 'aria-label': 'Następny miesiąc', html: ICON.right, onclick: function () { S.termMonth = new Date(m.getFullYear(), m.getMonth() + 1, 1); render(); } })
			]),
			grid
		]);
	}
	function toggleOff(key) {
		var d = S.data.terms;
		var list = blockedFor(d, S.termScope).slice();
		var at = list.indexOf(key);
		var n = d.orders[key] || 0;
		if (at < 0) {
			if (S.termScope !== 'all' && d.blocked.indexOf(key) > -1) { toast('Ten dzień jest już wolny dla wszystkich grup.'); return; }
			if (n && !window.confirm('Na ' + dateLabel(key) + ' są już złożone zamówienia (' + n + '). Oznaczenie dnia jako wolnego ich nie przesunie – nowe terminy trzeba ustalić w Kuchni (Zamówienia → „Nowy termin”). Oznaczyć mimo to?')) { return; }
			list.push(key); list.sort();
		} else {
			list.splice(at, 1);
		}
		var payload = {};
		if (S.termScope === 'all') { payload.blocked = list; } else { var g = {}; g[S.termScope] = list; payload.groups = g; }
		saveTerms(payload, null);
	}
	function upcomingOff(d) {
		var rows = [];
		d.blocked.forEach(function (k) { if (k >= d.today) { rows.push({ date: k, who: 'Wszystkie grupy', scope: 'all' }); } });
		d.groups.forEach(function (g) { g.blocked.forEach(function (k) { if (k >= d.today) { rows.push({ date: k, who: g.name, scope: String(g.id) }); } }); });
		rows.sort(function (a, b) { return a.date < b.date ? -1 : (a.date > b.date ? 1 : 0); });
		var box = h('section', { class: 'rp-card' }, [h('h2', { text: 'Najbliższe dni bez dostaw' })]);
		if (!rows.length) { box.appendChild(h('p', { class: 'rp-muted', text: 'Brak – dowozimy we wszystkie dni z harmonogramu.' })); return box; }
		box.appendChild(h('ul', { class: 'rp-offlist' }, rows.slice(0, 30).map(function (r) {
			return h('li', null, [h('strong', { text: dateLabel(r.date) }), h('span', { text: r.who }), h('button', { type: 'button', class: 'rp-btn rp-btn-link', text: 'Przywróć', 'aria-label': 'Przywróć dostawy ' + dateLabel(r.date) + ' – ' + r.who, onclick: function () {
				var p = {};
				if (r.scope === 'all') { p.blocked = d.blocked.filter(function (x) { return x !== r.date; }); }
				else { var g = d.groups.filter(function (x) { return String(x.id) === r.scope; })[0]; var o = {}; o[r.scope] = g.blocked.filter(function (x) { return x !== r.date; }); p.groups = o; }
				saveTerms(p, null);
			} })]);
		})));
		return box;
	}
	function saveTerms(part, b) {
		var d = S.data.terms;
		var data = {
			enabled: part.enabled !== undefined ? part.enabled : d.enabled,
			max: part.max !== undefined ? part.max : d.max,
			blocked: part.blocked || d.blocked,
			groups: part.groups || {}
		};
		busy(b, true);
		api('terms_save', data).then(function (x) {
			S.data.terms = x; S.termEdit = null; toast(x.message || 'Zapisano.'); refreshWarnings(); render();
		}).catch(function (e) { busy(b, false); toast(e.message, true); });
	}

	/* ============================================================
	 * SALA
	 * ============================================================ */
	var tmpId = 0;
	function secSala(main) {
		var d = S.data.sala;
		if (!d) {
			loading(main, 'Sala');
			load('sala', 'sala').then(function (x) { S.sala = salaCopy(x); render(); }).catch(function (e) { main.textContent = ''; failBox(main, e, render); });
			return;
		}
		var w = S.sala;
		main.appendChild(pageHead('Sala', 'Strefy, stoliki i to, co sprzedajesz na miejscu.', d.page ? h('a', { class: 'rp-btn', href: d.page, target: '_blank', rel: 'noopener', text: 'Otwórz panel kelnera' }) : btn('Utwórz stronę panelu kelnera', function (e) {
			busy(e.currentTarget, true);
			api('sala_page').then(function (x) { S.data.sala = x; S.sala.page = x.page; toast(x.message); render(); }).catch(function (er) { toast(er.message, true); render(); });
		}, 'rp-btn-pri')));
		// strefy
		var zonesBox = h('section', { class: 'rp-card' }, [h('h2', { text: 'Strefy' }), h('p', { class: 'rp-muted', text: 'Np. Sala, Ogródek, Piętro – kelner widzi stoliki pogrupowane w strefach.' })]);
		var zl = h('div', { class: 'rp-zones' });
		w.zones.forEach(function (z, zi) {
			var inp = h('input', { type: 'text', class: 'rp-in', value: z.name, maxlength: '40', 'aria-label': 'Nazwa strefy', oninput: function () { z.name = inp.value; dirty(); } });
			var cnt = w.tables.filter(function (t) { return t.zone === z.id; }).length;
			zl.appendChild(h('div', { class: 'rp-zone' }, [inp, h('small', { class: 'rp-muted', text: cnt + ' stol.' }), w.zones.length > 1 ? h('button', { type: 'button', class: 'rp-ico', 'aria-label': 'Usuń strefę ' + z.name, html: ICON.x, onclick: function () {
				if (cnt && !window.confirm('W strefie „' + z.name + '” są stoliki (' + cnt + '). Po usunięciu przejdą do strefy „' + w.zones[zi === 0 ? 1 : 0].name + '”. Usunąć?')) { return; }
				var to = w.zones[zi === 0 ? 1 : 0].id;
				w.tables.forEach(function (t) { if (t.zone === z.id) { t.zone = to; } });
				w.zones.splice(zi, 1); dirty(); render();
			} }) : null]));
		});
		zonesBox.appendChild(zl);
		zonesBox.appendChild(btn('+ Strefa', function () { w.zones.push({ id: 'new' + (++tmpId), name: '' }); dirty(); render(); var ins = root.querySelectorAll('.rp-zone input'); if (ins.length) { ins[ins.length - 1].focus(); } }));
		main.appendChild(zonesBox);
		// stoliki
		var tb = h('section', { class: 'rp-card' }, [h('h2', { text: 'Stoliki' })]);
		w.zones.forEach(function (z) {
			var ts = w.tables.filter(function (t) { return t.zone === z.id; });
			tb.appendChild(h('h3', { class: 'rp-h3', text: (z.name || 'Nowa strefa') + ' (' + ts.length + ')' }));
			var g = h('div', { class: 'rp-tables' });
			ts.forEach(function (t) {
				g.appendChild(h('button', { type: 'button', class: 'rp-table' + (t.active ? '' : ' off') + (t.busy ? ' busy' : ''), onclick: function () { tableEdit(t); } }, [
					h('strong', { text: t.name }), h('span', { text: t.seats + ' miejsc' }), !t.active ? h('em', { text: 'nieaktywny' }) : null, t.busy ? h('em', { text: 'otwarty rachunek' }) : null
				]));
			});
			if (!ts.length) { g.appendChild(h('p', { class: 'rp-muted', text: 'Brak stolików.' })); }
			tb.appendChild(g);
		});
		tb.appendChild(h('div', { class: 'rp-actions' }, [btn('+ Stolik', function () { tableEdit(null); }), btn('Dodaj kilka naraz', bulkTables)]));
		main.appendChild(tb);
		// kategorie
		var cb = h('section', { class: 'rp-card' }, [h('h2', { text: 'Kategorie: gdzie sprzedawane' }), h('p', { class: 'rp-muted', text: '„Tylko na miejscu” – np. kawa, herbata: sklep internetowy ich nie pokazuje, kelner tak. „Tylko dostawa / na wynos” – kelner ich nie widzi. „Pod kreską” – na bilecie kuchni w dolnej sekcji (napoje).' })]);
		var cl = h('div', { class: 'rp-cats' });
		w.cats.forEach(function (c) {
			var sel = h('select', { class: 'rp-in', 'aria-label': 'Gdzie sprzedawane: ' + c.name, onchange: function () { c.sell = sel.value; dirty(); } }, Object.keys(d.scopes).map(function (k) { return h('option', { value: k, selected: c.sell === k, text: d.scopes[k] }); }));
			var low = h('input', { type: 'checkbox', checked: c.low, onchange: function () { c.low = low.checked; dirty(); } });
			cl.appendChild(h('div', { class: 'rp-cat' }, [h('strong', { text: c.name }), sel, h('label', { class: 'rp-check' }, [low, h('span', { text: 'pod kreską' })])]));
		});
		cb.appendChild(cl);
		main.appendChild(cb);
		main.appendChild(saveBar(function (b) {
			var empty = w.zones.some(function (z) { return !z.name.trim(); });
			if (empty) { toast('Podaj nazwę każdej strefy.', true); return; }
			var cats = {};
			w.cats.forEach(function (c) { cats[c.id] = { sell: c.sell, low: c.low ? 1 : 0 }; });
			busy(b, true);
			api('sala_save', { zones: w.zones, tables: w.tables.map(function (t) { return { id: t.id, name: t.name, seats: t.seats, zone: t.zone, active: t.active ? 1 : 0 }; }), cats: cats }).then(function (x) {
				S.data.sala = x; S.sala = salaCopy(x); S.dirty = false; toast(x.message, !!(x.kept && x.kept.length)); render();
			}).catch(function (e) { busy(b, false); toast(e.message, true); });
		}, 'Zapisz salę'));
	}
	function salaCopy(x) { return JSON.parse(JSON.stringify({ zones: x.zones, tables: x.tables, cats: x.cats, page: x.page })); }
	function dirty() { S.dirty = true; var bar = root.querySelector('.rp-savebar'); if (bar) { bar.classList.add('on'); } }
	function saveBar(fn, label) {
		var b = btn(label || 'Zapisz zmiany', function () { fn(b); }, 'rp-btn-pri');
		return h('div', { class: 'rp-savebar' + (S.dirty ? ' on' : '') }, [h('span', { text: 'Niezapisane zmiany' }), b]);
	}
	function tableEdit(t) {
		var w = S.sala;
		var isNew = !t;
		var cur = t || { id: '', name: '', seats: 4, zone: w.zones[0].id, active: 1 };
		var name = h('input', { type: 'text', class: 'rp-in', value: cur.name, maxlength: '30', placeholder: 'np. 12 albo Okno 2' });
		var seats = h('input', { type: 'number', class: 'rp-in', value: cur.seats, min: '1', max: '99' });
		var zone = h('select', { class: 'rp-in' }, w.zones.map(function (z) { return h('option', { value: z.id, selected: z.id === cur.zone, text: z.name || 'Nowa strefa' }); }));
		var act = h('input', { type: 'checkbox', checked: !!cur.active });
		var err = h('p', { class: 'rp-err', role: 'alert', hidden: true });
		var body = h('div', { class: 'rp-form' }, [
			field('Nazwa / numer', name), h('div', { class: 'rp-grid2' }, [field('Miejsc', seats), field('Strefa', zone)]),
			h('label', { class: 'rp-check' }, [act, h('span', { text: 'Aktywny (widoczny dla kelnera)' })]),
			cur.busy ? h('p', { class: 'rp-muted', text: 'Stolik ma otwarty rachunek – nie można go usunąć, dopóki kelner go nie zamknie.' }) : null,
			err
		]);
		var ok = btn(isNew ? 'Dodaj' : 'Gotowe', function () {
			var nm = name.value.trim();
			if (!nm) { err.textContent = 'Podaj nazwę lub numer stolika.'; err.hidden = false; name.focus(); return; }
			var dup = w.tables.some(function (x) { return x !== t && x.name.toLowerCase() === nm.toLowerCase(); });
			if (dup && !window.confirm('Stolik „' + nm + '” już jest. Dodać drugi o tej samej nazwie?')) { return; }
			cur.name = nm; cur.seats = Math.max(1, Math.min(99, parseInt(seats.value, 10) || 4)); cur.zone = zone.value; cur.active = act.checked ? 1 : 0;
			if (isNew) { w.tables.push(cur); }
			closeSheet(); dirty(); render();
		}, 'rp-btn-pri');
		var foot = [ok];
		if (!isNew && !cur.busy) {
			foot.unshift(btn('Usuń', function () { w.tables.splice(w.tables.indexOf(t), 1); closeSheet(); dirty(); render(); }, 'rp-btn-del'));
		}
		openSheet(isNew ? 'Nowy stolik' : 'Stolik ' + cur.name, body, foot);
	}
	function bulkTables() {
		var w = S.sala;
		var n = h('input', { type: 'number', class: 'rp-in', value: 4, min: '1', max: '60' });
		var seats = h('input', { type: 'number', class: 'rp-in', value: 4, min: '1', max: '99' });
		var zone = h('select', { class: 'rp-in' }, w.zones.map(function (z) { return h('option', { value: z.id, text: z.name || 'Nowa strefa' }); }));
		var nums = w.tables.map(function (t) { return /^\d+$/.test(t.name) ? parseInt(t.name, 10) : 0; });
		var last = nums.length ? Math.max.apply(null, nums) : 0;
		var body = h('div', { class: 'rp-form' }, [h('div', { class: 'rp-grid3' }, [field('Ile stolików', n), field('Miejsc przy każdym', seats), field('Strefa', zone)]), h('p', { class: 'rp-muted', text: 'Numeracja dalej od ostatniego numeru (' + (last + 1) + ', ' + (last + 2) + ', …).' })]);
		openSheet('Dodaj kilka stolików', body, [btn('Dodaj', function () {
			var k = Math.max(1, Math.min(60, parseInt(n.value, 10) || 1));
			for (var i = 1; i <= k; i++) { w.tables.push({ id: '', name: String(last + i), seats: Math.max(1, parseInt(seats.value, 10) || 4), zone: zone.value, active: 1 }); }
			closeSheet(); dirty(); render();
		}, 'rp-btn-pri')]);
	}

	/* ============================================================
	 * WIADOMOŚCI
	 * ============================================================ */
	function secMsgs(main) {
		if (S.msg) { msgView(main); return; }
		var d = S.data.msgs;
		var f = S.msgFilter;
		if (!d || d.key !== JSON.stringify(f)) {
			loading(main, 'Wiadomości');
			api('msgs', f).then(function (x) { x.key = JSON.stringify(f); S.data.msgs = x; S.msgStatuses = x.statuses; S.boot.newMsgs = x.newMsgs; S.sel = {}; render(); }).catch(function (e) { main.textContent = ''; failBox(main, e, render); });
			return;
		}
		var csv = C.post + '?action=rzd_kf_csv&_wpnonce=' + encodeURIComponent(C.csvNonce) + (f.form ? '&form=' + encodeURIComponent(f.form) : '') + (f.status ? '&status=' + encodeURIComponent(f.status) : '') + (f.s ? '&s=' + encodeURIComponent(f.s) : '');
		main.appendChild(pageHead('Wiadomości', d.total + ' ' + (d.total === 1 ? 'wiadomość' : 'wiadomości') + (d.newMsgs ? ' · nowe: ' + d.newMsgs : ''), h('a', { class: 'rp-btn', href: csv, text: 'Eksport CSV' })));
		// filtry
		var q = h('input', { type: 'search', class: 'rp-in', value: f.s, placeholder: 'Szukaj: nazwisko, e-mail, treść', 'aria-label': 'Szukaj' });
		var form = h('select', { class: 'rp-in', 'aria-label': 'Formularz', onchange: function () { f.form = form.value; f.page = 1; render(); } }, [h('option', { value: '', text: 'Wszystkie formularze' })].concat(d.forms.map(function (x) { return h('option', { value: x.id, selected: f.form === x.id, text: x.title }); })));
		var st = [['', 'Wszystkie']].concat(Object.keys(d.statuses).map(function (k) { return [k, d.statuses[k]]; }));
		main.appendChild(h('div', { class: 'rp-filters' }, [
			h('div', { class: 'rp-chips' }, st.map(function (s) { return h('button', { type: 'button', class: 'rp-chip' + (f.status === s[0] ? ' on' : ''), 'aria-pressed': f.status === s[0] ? 'true' : 'false', text: s[1], onclick: function () { f.status = s[0]; f.page = 1; render(); } }); })),
			h('form', { class: 'rp-search', onsubmit: function (e) { e.preventDefault(); f.s = q.value.trim(); f.page = 1; render(); } }, [q, h('button', { type: 'submit', class: 'rp-btn', text: 'Szukaj' })]),
			form
		]));
		if (!d.items.length) { main.appendChild(h('div', { class: 'rp-empty' }, [h('p', { text: f.s || f.status || f.form ? 'Brak wiadomości dla tych filtrów.' : 'Brak wiadomości.' })])); return; }
		var sel = S.sel = S.sel || {};
		var bulk = h('div', { class: 'rp-bulk', hidden: !Object.keys(sel).length ? true : null }, [
			h('span', { class: 'rp-bulk-n' }),
			btn('Odpowiedziane', function () { msgsSet('answered'); }), btn('Przeczytane', function () { msgsSet('read'); }), btn('Nowe', function () { msgsSet('new'); }),
			btn('Usuń', function () { if (window.confirm('Usunąć zaznaczone wiadomości?')) { msgsDelete(Object.keys(sel)); } }, 'rp-btn-del')
		]);
		function upd() { var n = Object.keys(sel).length; bulk.hidden = !n; bulk.querySelector('.rp-bulk-n').textContent = 'Zaznaczone: ' + n; }
		var list = h('ul', { class: 'rp-msgs' }, d.items.map(function (m) {
			var cb = h('input', { type: 'checkbox', checked: !!sel[m.id], 'aria-label': 'Zaznacz wiadomość od ' + (m.name || m.email), onchange: function () { if (cb.checked) { sel[m.id] = 1; } else { delete sel[m.id]; } upd(); } });
			return h('li', { class: 'rp-msg' + (m.status === 'new' ? ' new' : '') }, [
				h('label', { class: 'rp-msg-cb' }, [cb]),
				h('button', { type: 'button', class: 'rp-msg-b', onclick: function () { openMsg(m.id); } }, [
					h('span', { class: 'rp-msg-top' }, [h('strong', { text: m.name || m.email || 'bez nazwiska' }), h('small', { text: m.date })]),
					h('span', { class: 'rp-msg-form', text: m.form + ' · ' + (d.statuses[m.status] || m.status) + (m.fail ? ' · mail nie wyszedł' : '') }),
					h('span', { class: 'rp-msg-short', text: m.short })
				])
			]);
		}));
		main.appendChild(bulk);
		main.appendChild(list);
		upd();
		if (d.pages > 1) {
			main.appendChild(h('div', { class: 'rp-pager' }, [
				btn('← Nowsze', function () { f.page--; render(); }, '', { disabled: d.page <= 1 ? true : null }),
				h('span', { text: 'Strona ' + d.page + ' z ' + d.pages }),
				btn('Starsze →', function () { f.page++; render(); }, '', { disabled: d.page >= d.pages ? true : null })
			]));
		}
		if (d.keep) { main.appendChild(h('p', { class: 'rp-muted', text: 'Wiadomości starsze niż ' + d.keep + ' mies. usuwają się automatycznie.' })); }
	}
	function openMsg(id) {
		api('msg', { id: id }).then(function (x) { S.msg = x.item; S.boot.newMsgs = x.newMsgs; S.data.msgs = null; render(); }).catch(function (e) { toast(e.message, true); });
	}
	function msgView(main) {
		var m = S.msg;
		var st = S.msgStatuses || { new: 'nowa', read: 'przeczytana', answered: 'odpowiedziana' };
		main.appendChild(h('button', { type: 'button', class: 'rp-back', onclick: function () { S.msg = null; render(); } }, [h('span', { html: ICON.back }), 'Wszystkie wiadomości']));
		main.appendChild(pageHead(m.form, m.date + ' · ' + (st[m.status] || m.status)));
		if (m.fail) { main.appendChild(h('div', { class: 'rp-warn err' }, [h('span', { text: 'Mail z tą wiadomością nie dotarł do restauracji (szczegóły: Stan i poczta w kokpicie).' })])); }
		var dl = h('dl', { class: 'rp-dl' });
		m.fields.forEach(function (f) {
			var v = f.value;
			var dd;
			if (!v) { dd = h('dd', { class: 'rp-muted', text: '–' }); }
			else if (f.type === 'email') { dd = h('dd', null, [h('a', { href: 'mailto:' + v, text: v })]); }
			else if (f.type === 'tel') { dd = h('dd', null, [h('a', { href: 'tel:' + v.replace(/[^0-9+]/g, ''), text: v })]); }
			else { dd = h('dd', { class: 'rp-pre', text: v }); }
			dl.appendChild(h('dt', { text: f.label }));
			dl.appendChild(dd);
		});
		main.appendChild(h('section', { class: 'rp-card' }, [dl, m.page ? h('p', { class: 'rp-muted' }, ['Wysłano ze strony: ', h('a', { href: m.page.url, target: '_blank', rel: 'noopener', text: m.page.title })]) : null]));
		var acts = [];
		if (m.email) { acts.push(h('a', { class: 'rp-btn rp-btn-pri', href: 'mailto:' + m.email + '?subject=' + encodeURIComponent('Re: ' + m.form), text: 'Odpowiedz e-mailem' })); }
		if (m.tel) { acts.push(h('a', { class: 'rp-btn', href: 'tel:' + m.tel.replace(/[^0-9+]/g, ''), text: 'Zadzwoń' })); }
		acts.push(btn(m.status === 'answered' ? 'Oznacz jako nową' : 'Oznacz jako odpowiedzianą', function () {
			var to = m.status === 'answered' ? 'new' : 'answered';
			api('msgs_set', { ids: [m.id], status: to }).then(function (x) { m.status = to; S.boot.newMsgs = x.newMsgs; toast('Zapisano.'); render(); }).catch(function (e) { toast(e.message, true); });
		}));
		acts.push(btn('Usuń', function () { if (window.confirm('Usunąć wiadomość?')) { msgsDelete([m.id]); } }, 'rp-btn-del'));
		main.appendChild(h('div', { class: 'rp-actions' }, acts));
	}
	function msgsSet(status) {
		var ids = Object.keys(S.sel || {});
		api('msgs_set', { ids: ids, status: status }).then(function (x) { S.boot.newMsgs = x.newMsgs; S.data.msgs = null; S.sel = {}; toast('Oznaczono: ' + x.done + '.'); render(); }).catch(function (e) { toast(e.message, true); });
	}
	function msgsDelete(ids) {
		api('msgs_delete', { ids: ids }).then(function (x) { S.boot.newMsgs = x.newMsgs; S.data.msgs = null; S.msg = null; S.sel = {}; toast('Usunięto: ' + x.done + '.'); render(); }).catch(function (e) { toast(e.message, true); });
	}

	/* ============================================================
	 * RAPORTY
	 * ============================================================ */
	function secReports(main) {
		var today = S.boot.today || ymd(new Date());
		var r = S.rep = S.rep || { date_from: today, date_to: today, time_from: '', time_to: '', mode: 'detail', only_confirmed: true };
		main.appendChild(pageHead('Raporty', 'Zamówienia wg terminu dostawy – podgląd na ekranie albo plik CSV (Excel).'));
		var df = h('input', { type: 'date', class: 'rp-in', value: r.date_from });
		var dt = h('input', { type: 'date', class: 'rp-in', value: r.date_to });
		var tf = h('input', { type: 'time', class: 'rp-in', value: r.time_from });
		var tt = h('input', { type: 'time', class: 'rp-in', value: r.time_to });
		var conf = h('input', { type: 'checkbox', checked: r.only_confirmed });
		var modes = [['detail', 'Szczegółowo wg terminu', 'data, godzina, produkt, klient'], ['summary', 'Podsumowanie produktów', 'suma ilości z całego zakresu – do zakupów i przygotowania']];
		var radios = modes.map(function (m) {
			return h('label', { class: 'rp-radio rp-radio-b' }, [h('input', { type: 'radio', name: 'rp-mode', value: m[0], checked: r.mode === m[0], onchange: function () { r.mode = m[0]; } }), h('span', null, [h('strong', { text: m[1] }), h('small', { text: m[2] })])]);
		});
		function read() { r.date_from = df.value; r.date_to = dt.value; r.time_from = tf.value; r.time_to = tt.value; r.only_confirmed = conf.checked; }
		var prev = btn('Podgląd na ekranie', function () {
			read();
			if (!r.date_from || !r.date_to) { toast('Wybierz zakres dat.', true); return; }
			busy(prev, true);
			api('report', { date_from: r.date_from, date_to: r.date_to, time_from: r.time_from, time_to: r.time_to, mode: r.mode, only_confirmed: r.only_confirmed ? '1' : '0' }).then(function (x) { S.repData = x; render(); }).catch(function (e) { busy(prev, false); toast(e.message, true); });
		});
		var csv = btn('Pobierz CSV', function () {
			read();
			if (!r.date_from || !r.date_to) { toast('Wybierz zakres dat.', true); return; }
			var fm = h('form', { method: 'post', action: C.post, hidden: true });
			[['action', 'rr_export'], ['_wpnonce', C.rrNonce], ['date_from', r.date_from], ['date_to', r.date_to], ['time_from', r.time_from], ['time_to', r.time_to], ['mode', r.mode]].concat(r.only_confirmed ? [['only_confirmed', '1']] : []).forEach(function (p) { fm.appendChild(h('input', { type: 'hidden', name: p[0], value: p[1] })); });
			document.body.appendChild(fm); fm.submit(); setTimeout(function () { fm.remove(); }, 1000);
		}, 'rp-btn-pri');
		main.appendChild(h('section', { class: 'rp-card rp-form' }, [
			h('div', { class: 'rp-grid2' }, [field('Data dostawy od', df), field('do', dt)]),
			h('div', { class: 'rp-grid2' }, [field('Godzina od', tf, 'Puste = cały dzień.'), field('do', tt)]),
			h('div', { class: 'rp-field' }, [h('span', { class: 'rp-label', text: 'Rodzaj raportu' }), h('div', { class: 'rp-radios rp-radios-b' }, radios)]),
			h('label', { class: 'rp-check' }, [conf, h('span', { text: 'Tylko przyjęte do realizacji lub zrealizowane (bez anulowanych, nieopłaconych, zwrotów)' })]),
			h('div', { class: 'rp-actions' }, [prev, csv])
		]));
		var x = S.repData;
		if (x) {
			main.appendChild(h('h2', { class: 'rp-h2', text: 'Podgląd (' + x.rows.length + ')' }));
			if (!x.rows.length) { main.appendChild(h('p', { class: 'rp-muted', text: 'Brak zamówień w wybranym zakresie.' })); return; }
			main.appendChild(h('div', { class: 'rp-tablewrap', tabindex: '0', role: 'region', 'aria-label': 'Podgląd raportu' }, [h('table', { class: 'rp-table-r' }, [
				h('thead', null, [h('tr', null, x.head.map(function (c) { return h('th', { scope: 'col', text: c }); }))]),
				h('tbody', null, x.rows.map(function (row) { return h('tr', null, row.map(function (c) { return h('td', { text: String(c) }); })); }))
			])]));
		}
	}

	var SECTIONS = { start: secStart, miejscowosci: secTowns, terminy: secTerms, sala: secSala, wiadomosci: secMsgs, raporty: secReports };

	/* Wspólne narzędzia dla kolejnych plików panelu (rzd-panel-menu.js, -terminy.js, -zestawy.js): rejestrują
	 * sekcje w KIT.sections, zakładki Terminów w KIT.termTabs. Start panelu czeka na DOMContentLoaded,
	 * więc wszystkie pliki (defer) są już wczytane. */
	var KIT = window.rzdPanelKit = {
		C: C, S: S, h: h, api: api, toast: toast, field: field, btn: btn, busy: busy, warnBox: warnBox,
		openSheet: openSheet, closeSheet: closeSheet, pageHead: pageHead, loading: loading, failBox: failBox, load: load,
		render: render, go: go, setTab: setTab, tabsEl: tabsEl, money: money, dateLabel: dateLabel, ymd: ymd, parseYmd: parseYmd,
		dirty: dirty, saveBar: saveBar, refreshWarnings: refreshWarnings, ICON: ICON, root: root,
		sections: SECTIONS, termTabs: {}
	};

	/* ---------- start ---------- */
	function boot() { api('boot').then(function (d) {
		S.boot = d;
		if (!can(S.sec)) { S.sec = 'start'; }
		render();
	}).catch(function (e) {
		root.textContent = '';
		root.appendChild(h('div', { class: 'rp-warn err rp-fatal' }, [h('span', { text: e.message }), btn('Odśwież', function () { location.reload(); }, 'rp-btn-link')]));
	}); }
	if (document.readyState === 'complete') { boot(); } else { document.addEventListener('DOMContentLoaded', boot); }
})();
