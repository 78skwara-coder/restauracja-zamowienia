/* Restauracja – Panel restauracji: formularz ze schematu (2.45.0) – używają go Sklep (Koszyk, Pasek dostawy,
 * Dobierz, Formularz zamówienia) i Zespół. Schemat przychodzi z serwera (moduł 34, 08-sklep.php):
 * [ { title, hint?, if?, fields: [ { t, k, l, hint, o, min, max, step, u, ph, if, ifv, adv, warn, items } ] } ].
 * Wartości – robocza kopia (obiekt), zmieniana w miejscu; onChange() po każdej zmianie.
 * Widoczność (if: pole zaznaczone, ifv: [pole, wartość | '!wartość']) – bez przerysowania (fokus zostaje).
 * Dodaje do KIT: sform, pickFrom (wybór z listy z wyszukiwaniem), pickImage (biblioteka + wgranie). */
(function () {
	'use strict';
	var K = window.rzdPanelKit;
	if (!K) { return; }
	var h = K.h;
	var uid = 0;

	function on(v) { return !!v && v !== '0'; }
	function visible(f, vals) {
		if (f['if'] && !on(vals[f['if']])) { return false; }
		if (f.ifv) {
			var want = String(f.ifv[1]), cur = String(vals[f.ifv[0]] === undefined ? '' : vals[f.ifv[0]]);
			if (want.charAt(0) === '!' ? cur === want.slice(1) : cur !== want) { return false; }
		}
		return true;
	}

	/* ---------- wybór z listy (produkty itp.) ---------- */
	function pickFrom(title, list, onPick, opts) {
		opts = opts || {};
		var q = h('input', { type: 'search', class: 'rp-in', placeholder: opts.ph || 'Szukaj', 'aria-label': opts.ph || 'Szukaj' });
		var ul = h('div', { class: 'rp-list rp-pick' });
		function draw() {
			ul.textContent = '';
			var n = q.value.trim().toLowerCase();
			var rows = list.filter(function (p) { return !n || String(p.name).toLowerCase().indexOf(n) > -1 || String(p.cats || p.sub || '').toLowerCase().indexOf(n) > -1; }).slice(0, 80);
			if (!rows.length) { ul.appendChild(h('p', { class: 'rp-empty-s', text: 'Nic nie pasuje.' })); }
			rows.forEach(function (p) {
				ul.appendChild(h('button', { type: 'button', class: 'rp-row', onclick: function () { K.closeSheet(); onPick(p); } }, [h('span', { class: 'rp-row-main' }, [h('strong', { text: p.name }), (p.cats || p.sub) ? h('small', { text: p.cats || p.sub }) : null])]));
			});
		}
		q.addEventListener('input', draw);
		draw();
		K.openSheet(title, h('div', { class: 'rp-form' }, [q, ul]));
	}

	/* ---------- obrazek: biblioteka mediów i wgranie ---------- */
	function pickImage(onPick) {
		var grid = h('div', { class: 'rp-media' }, [h('p', { class: 'rp-load', text: 'Wczytuję…' })]);
		var q = h('input', { type: 'search', class: 'rp-in', placeholder: 'Szukaj w bibliotece', 'aria-label': 'Szukaj obrazka' });
		var file = h('input', { type: 'file', accept: 'image/jpeg,image/png,image/webp,image/gif', class: 'rp-file', 'aria-label': 'Wgraj obrazek z urządzenia' });
		var up = h('label', { class: 'rp-btn rp-btn-pri', hidden: true }, ['Wgraj z urządzenia', file]);
		file.addEventListener('change', function () {
			if (!file.files[0]) { return; }
			K.toast('Wgrywam…');
			K.api('media_upload', { file: file.files[0] }).then(function (x) { K.closeSheet(); K.toast(x.message); onPick(x.item); }).catch(function (e) { K.toast(e.message, true); });
		});
		var t = null;
		function load() {
			K.api('media_list', { s: q.value.trim() }).then(function (x) {
				up.hidden = !x.canUpload;
				grid.textContent = '';
				if (!x.items.length) { grid.appendChild(h('p', { class: 'rp-empty-s', text: q.value ? 'Nic nie znaleziono.' : 'Biblioteka jest pusta – wgraj obrazek.' })); }
				x.items.forEach(function (it) {
					grid.appendChild(h('button', { type: 'button', class: 'rp-media-i', title: it.title, 'aria-label': 'Wybierz: ' + (it.title || 'obrazek'), onclick: function () { K.closeSheet(); onPick(it); } }, [h('img', { src: it.url, alt: '', loading: 'lazy' })]));
				});
			}).catch(function (e) { grid.textContent = ''; grid.appendChild(h('p', { class: 'rp-err', text: e.message })); });
		}
		q.addEventListener('input', function () { clearTimeout(t); t = setTimeout(load, 300); });
		K.openSheet('Wybierz obrazek', h('div', { class: 'rp-form' }, [h('div', { class: 'rp-inline' }, [up]), q, grid]));
		load();
	}

	/* ---------- pola ---------- */
	function sform(cfg) {
		var vals = cfg.values, imgs = cfg.imgs || {};
		var conds = []; // [ element, warunek ]
		function changed() { refresh(); if (cfg.onChange) { cfg.onChange(); } }
		function refresh() { conds.forEach(function (c) { c[0].hidden = !visible(c[1], vals); }); }
		function wrap(f, el) {
			if (f['if'] || f.ifv) { conds.push([el, f]); }
			return el;
		}
		function hint(f) { return f.hint ? h('small', { class: 'rp-hint', text: f.hint }) : null; }

		function field(f) {
			var k = f.k, id = 'rpf-' + (++uid);
			switch (f.t) {
				case 'note':
					return wrap(f, h('p', { class: 'rp-fnote' + (f.warn ? ' warn' : ''), text: f.l }));
				case 'status':
					return wrap(f, h('ul', { class: 'rp-status' }, (f.items || []).map(function (it) {
						return h('li', { class: it.ok ? 'ok' : 'bad' }, [
							h('span', { class: 'rp-status-i', 'aria-hidden': 'true', text: it.ok ? '✓' : '!' }),
							h('span', { class: 'rp-status-t' }, [h('strong', { text: it.label + ': ' }), it.url ? h('a', { href: it.url, target: '_blank', rel: 'noopener', text: it.text }) : h('span', { text: it.text })]),
							!it.ok && it.fix ? h('a', { class: 'rp-btn rp-btn-link', href: it.fix, target: '_blank', rel: 'noopener', text: it.fixText || 'Ustaw' }) : (!it.ok && it.fixText ? h('small', { class: 'rp-hint', text: it.fixText }) : null)
						]);
					})));
				case 'check':
					var cb = h('input', { type: 'checkbox', id: id, checked: on(vals[k]), onchange: function () { vals[k] = cb.checked ? 1 : 0; changed(); } });
					return wrap(f, h('div', { class: 'rp-field rp-field-c' }, [h('label', { class: 'rp-check', for: id }, [cb, h('span', { text: f.l })]), hint(f)]));
				case 'checks':
					vals[k] = vals[k] && typeof vals[k] === 'object' ? vals[k] : {};
					return wrap(f, h('fieldset', { class: 'rp-field rp-fs' }, [h('legend', { class: 'rp-label', text: f.l })].concat(Object.keys(f.o).map(function (ok) {
						var c = h('input', { type: 'checkbox', checked: on(vals[k][ok]), onchange: function () { vals[k][ok] = c.checked ? 1 : 0; changed(); } });
						return h('label', { class: 'rp-check' }, [c, h('span', { text: f.o[ok] })]);
					})).concat([hint(f)])));
				case 'radio':
					var nm = 'rpr-' + id;
					return wrap(f, h('fieldset', { class: 'rp-field rp-fs' }, [h('legend', { class: 'rp-label', text: f.l }), h('div', { class: 'rp-radios rp-radios-v' }, Object.keys(f.o).map(function (ok) {
						return h('label', { class: 'rp-radio' }, [h('input', { type: 'radio', name: nm, value: ok, checked: String(vals[k]) === ok, onchange: function () { vals[k] = ok; changed(); } }), h('span', { text: f.o[ok] })]);
					})), hint(f)]));
				case 'select':
					var sel = h('select', { class: 'rp-in', id: id, onchange: function () { vals[k] = sel.value; changed(); } }, Object.keys(f.o).map(function (ok) {
						return h('option', { value: ok, selected: String(vals[k]) === ok, text: f.o[ok] });
					}));
					return wrap(f, h('div', { class: 'rp-field' }, [h('label', { class: 'rp-label', for: id, text: f.l }), sel, hint(f)]));
				case 'textarea':
					var ta = h('textarea', { class: 'rp-in', id: id, rows: f.rows || 4, placeholder: f.ph || null, oninput: function () { vals[k] = ta.value; changed(); } });
					ta.value = vals[k] === undefined || vals[k] === null ? '' : String(vals[k]);
					return wrap(f, h('div', { class: 'rp-field' }, [h('label', { class: 'rp-label', for: id, text: f.l }), ta, hint(f)]));
				case 'number':
					var nu = h('input', { type: 'number', class: 'rp-in rp-in-s', id: id, value: vals[k] === undefined || vals[k] === null ? '' : String(vals[k]), min: f.min === undefined ? null : String(f.min), max: f.max === undefined ? null : String(f.max), step: f.step ? String(f.step) : null, inputmode: 'decimal', oninput: function () { vals[k] = nu.value; changed(); } });
					return wrap(f, h('div', { class: 'rp-field' }, [h('label', { class: 'rp-label', for: id, text: f.l }), h('span', { class: 'rp-unit' }, [nu, f.u ? h('span', { text: f.u }) : null]), hint(f)]));
				case 'color':
					var co = h('input', { type: 'color', class: 'rp-color', id: id, value: /^#[0-9a-f]{6}$/i.test(vals[k] || '') ? vals[k] : (f.def || '#c08a2e'), oninput: function () { vals[k] = co.value; changed(); } });
					return wrap(f, h('div', { class: 'rp-field' }, [h('label', { class: 'rp-label', for: id, text: f.l }), co, hint(f)]));
				case 'image':
					return wrap(f, imageField(f));
				case 'products':
					return wrap(f, productsField(f));
				case 'cats':
					vals[k] = (vals[k] || []).map(Number);
					return wrap(f, h('fieldset', { class: 'rp-field rp-fs' }, [h('legend', { class: 'rp-label', text: f.l }), h('div', { class: 'rp-scrollbox' }, (cfg.cats || []).map(function (c) {
						var x = h('input', { type: 'checkbox', checked: vals[k].indexOf(c.id) > -1, onchange: function () {
							var at = vals[k].indexOf(c.id);
							if (x.checked && at < 0) { vals[k].push(c.id); } else if (!x.checked && at > -1) { vals[k].splice(at, 1); }
							changed();
						} });
						return h('label', { class: 'rp-check' }, [x, h('span', { text: c.name })]);
					})), hint(f)]));
				case 'srcorder':
					return wrap(f, srcOrder(f));
				case 'hours':
					return wrap(f, hoursField(f));
				default: // text, url, email, tel
					var inp = h('input', { type: f.t === 'url' ? 'url' : (f.t === 'email' ? 'email' : 'text'), class: 'rp-in', id: id, placeholder: f.ph || null, maxlength: f.max ? String(f.max) : null, oninput: function () { vals[k] = inp.value; changed(); } });
					inp.value = vals[k] === undefined || vals[k] === null ? '' : String(vals[k]);
					return wrap(f, h('div', { class: 'rp-field' }, [h('label', { class: 'rp-label', for: id, text: f.l }), inp, hint(f)]));
			}
		}

		function imageField(f) {
			var k = f.k, box = h('div', { class: 'rp-field' });
			function draw() {
				box.textContent = '';
				var id = parseInt(vals[k], 10) || 0, url = id ? imgs[id] : '';
				box.appendChild(h('span', { class: 'rp-label', text: f.l }));
				box.appendChild(h('div', { class: 'rp-inline rp-imgf' }, [
					url ? h('img', { src: url, alt: '', class: 'rp-imgf-i' }) : h('span', { class: 'rp-icon-none', text: id ? 'obrazek' : 'brak' }),
					K.btn(id ? 'Zmień' : 'Wybierz obrazek', function () { pickImage(function (it) { imgs[it.id] = it.url; vals[k] = it.id; draw(); changed(); }); }),
					id ? K.btn('Usuń', function () { vals[k] = 0; draw(); changed(); }, 'rp-btn-link') : null
				]));
				if (f.hint) { box.appendChild(hint(f)); }
			}
			draw();
			return box;
		}

		function productsField(f) {
			var k = f.k, box = h('div', { class: 'rp-field' });
			var byId = {};
			(cfg.products || []).forEach(function (p) { byId[p.id] = p; });
			vals[k] = (vals[k] || []).map(Number);
			function draw() {
				box.textContent = '';
				box.appendChild(h('span', { class: 'rp-label', text: f.l }));
				var list = vals[k];
				var ul = h('ol', { class: 'rp-plist' }, list.map(function (pid, i) {
					var p = byId[pid];
					return h('li', null, [
						h('span', { class: 'rp-plist-n', text: p ? p.name : 'produkt #' + pid + ' (ukryty albo usunięty)' }),
						h('button', { type: 'button', class: 'rp-ico', 'aria-label': 'Wyżej', text: '↑', disabled: i === 0 ? true : null, onclick: function () { list.splice(i - 1, 0, list.splice(i, 1)[0]); draw(); changed(); } }),
						h('button', { type: 'button', class: 'rp-ico', 'aria-label': 'Usuń ' + (p ? p.name : ''), html: K.ICON.x, onclick: function () { list.splice(i, 1); draw(); changed(); } })
					]);
				}));
				if (list.length) { box.appendChild(ul); } else { box.appendChild(h('p', { class: 'rp-muted', text: 'Brak – dodaj produkty.' })); }
				box.appendChild(h('div', null, [K.btn('+ Dodaj produkt', function () {
					pickFrom('Dodaj produkt', (cfg.products || []).filter(function (p) { return list.indexOf(p.id) < 0; }), function (p) { list.push(p.id); draw(); changed(); }, { ph: 'Szukaj produktu' });
				})]));
				if (f.hint) { box.appendChild(hint(f)); }
			}
			draw();
			return box;
		}

		function srcOrder(f) {
			var box = h('fieldset', { class: 'rp-field rp-fs' });
			vals.src = vals.src && typeof vals.src === 'object' ? vals.src : {};
			vals.order = vals.order && vals.order.length ? vals.order : Object.keys(f.o);
			function draw() {
				box.textContent = '';
				box.appendChild(h('legend', { class: 'rp-label', text: f.l }));
				box.appendChild(h('ol', { class: 'rp-plist' }, vals.order.map(function (sk, i) {
					var c = h('input', { type: 'checkbox', checked: on(vals.src[sk]), onchange: function () { vals.src[sk] = c.checked ? 1 : 0; changed(); } });
					return h('li', null, [
						h('label', { class: 'rp-check rp-plist-n' }, [c, h('span', { text: f.o[sk] })]),
						h('button', { type: 'button', class: 'rp-ico', 'aria-label': 'Wyżej: ' + f.o[sk], text: '↑', disabled: i === 0 ? true : null, onclick: function () { vals.order.splice(i - 1, 0, vals.order.splice(i, 1)[0]); draw(); changed(); } }),
						h('button', { type: 'button', class: 'rp-ico', 'aria-label': 'Niżej: ' + f.o[sk], text: '↓', disabled: i === vals.order.length - 1 ? true : null, onclick: function () { vals.order.splice(i + 1, 0, vals.order.splice(i, 1)[0]); draw(); changed(); } })
					]);
				})));
				if (f.hint) { box.appendChild(hint(f)); }
			}
			draw();
			return box;
		}

		// godziny w dniach tygodnia: { Mon: { c: 0|1 (zamknięte), from, to } … } (2.46.0, SEO)
		function hoursField(f) {
			var k = f.k, box = h('fieldset', { class: 'rp-field rp-fs' });
			var DAYS = [['Mon', 'Poniedziałek'], ['Tue', 'Wtorek'], ['Wed', 'Środa'], ['Thu', 'Czwartek'], ['Fri', 'Piątek'], ['Sat', 'Sobota'], ['Sun', 'Niedziela']];
			vals[k] = vals[k] && typeof vals[k] === 'object' ? vals[k] : {};
			function draw() {
				box.textContent = '';
				box.appendChild(h('legend', { class: 'rp-label', text: f.l }));
				var g = h('div', { class: 'rp-hours' });
				DAYS.forEach(function (d) {
					var r = vals[k][d[0]] = vals[k][d[0]] || { c: 0, from: '', to: '' };
					var fr = h('input', { type: 'time', class: 'rp-in', value: r.from || '', 'aria-label': d[1] + ' – od', disabled: +r.c ? true : null, oninput: function () { r.from = fr.value; changed(); } });
					var to = h('input', { type: 'time', class: 'rp-in', value: r.to || '', 'aria-label': d[1] + ' – do', disabled: +r.c ? true : null, oninput: function () { r.to = to.value; changed(); } });
					var cl = h('input', { type: 'checkbox', checked: !!+r.c, onchange: function () { r.c = cl.checked ? 1 : 0; fr.disabled = to.disabled = cl.checked; changed(); } });
					g.appendChild(h('div', { class: 'rp-hours-r' }, [h('strong', { text: d[1] }), fr, h('span', { text: '–', 'aria-hidden': 'true' }), to, h('label', { class: 'rp-check' }, [cl, h('span', { text: 'zamknięte' })])]));
				});
				box.appendChild(g);
				var acts = [];
				if (f.suggest) {
					acts.push(K.btn('Podpowiedz z godzin dostaw', function () {
						if (!window.confirm('Wpisać godziny z okien dostaw (pierwsze – ostatnie okno dnia)? Obecne godziny zostaną zastąpione.')) { return; }
						vals[k] = JSON.parse(JSON.stringify(f.suggest)); draw(); changed();
					}));
				}
				acts.push(K.btn('Jak w poniedziałek – wszystkie dni', function () {
					var m = vals[k].Mon; DAYS.forEach(function (d) { vals[k][d[0]] = { c: m.c, from: m.from, to: m.to }; }); draw(); changed();
				}, 'rp-btn-link'));
				box.appendChild(h('div', { class: 'rp-inline' }, acts));
				if (f.hint) { box.appendChild(hint(f)); }
			}
			draw();
			return box;
		}

		var out = h('div', { class: 'rp-sform' });
		(cfg.schema || []).forEach(function (sec) {
			var main = [], adv = [];
			var advIf = null;
			sec.fields.forEach(function (f) { if (f.adv) { advIf = advIf || f; } (f.adv ? adv : main).push(field(f)); });
			var kids = [sec.title ? h('h2', { text: sec.title }) : null, sec.hint ? h('p', { class: 'rp-muted', text: sec.hint }) : null].concat(main);
			if (adv.length) { // „Zaawansowane” znika razem z polami (warunek pierwszego z nich)
				var det = h('details', { class: 'rp-adv' }, [h('summary', { text: 'Zaawansowane' })].concat(adv));
				kids.push(advIf['if'] || advIf.ifv ? wrap({ 'if': advIf['if'], ifv: advIf.ifv }, det) : det);
			}
			out.appendChild(wrap(sec, h('section', { class: 'rp-card rp-form' }, kids)));
		});
		refresh();
		return out;
	}

	K.sform = sform;
	K.pickFrom = pickFrom;
	K.pickImage = pickImage;
})();
