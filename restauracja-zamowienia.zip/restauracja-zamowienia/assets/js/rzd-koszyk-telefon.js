/* Restauracja – Zamówienia i Dostawy: rzd-koszyk-telefon.js (z 07-koszyk.php) */
(function () {
	var wrap = document.querySelector('.kc-mobile-wrap');
	if (!wrap) { return; }
	var logoSel = rzdKcMobile.logo;
	var menuSel = rzdKcMobile.menu;

	function q(root, sel) { try { return root.querySelector(sel); } catch (e) { return null; } }
	function placed() { wrap.className += ' kc-placed'; }

	var roots = document.querySelectorAll('header, .site-header, #masthead, #header, .header');
	var logo = null, menu = null, i;
	for (i = 0; i < roots.length; i++) {
		if (!logo) { logo = q(roots[i], logoSel); }
		if (!menu) { menu = q(roots[i], menuSel); }
	}
	if (!logo) { logo = q(document, logoSel); }
	if (!menu) { menu = q(document, menuSel); }

	// 1) Logo i przycisk menu: wstawiamy koszyk POMIĘDZY nimi
	if (logo && menu) {
		var anc = logo;
		while (anc && !anc.contains(menu)) { anc = anc.parentNode; }
		if (anc && anc !== logo) {
			var lc = logo; while (lc.parentNode !== anc) { lc = lc.parentNode; }
			var mc = menu; while (mc.parentNode !== anc) { mc = mc.parentNode; }
			if (lc !== mc) {
				var menuAfterLogo = !!(lc.compareDocumentPosition(mc) & Node.DOCUMENT_POSITION_FOLLOWING);
				anc.insertBefore(wrap, menuAfterLogo ? lc.nextSibling : mc.nextSibling);
				placed();
				return;
			}
		}
	}
	// 2) Tylko logo: koszyk zaraz za logo
	if (logo && logo.parentNode) {
		logo.parentNode.insertBefore(wrap, logo.nextSibling);
		placed();
		return;
	}
	// 3) Ostatecznie: na końcu nagłówka
	if (roots.length) { roots[0].appendChild(wrap); placed(); }
})();
