/* Restauracja – Zamówienia i Dostawy: brama dodawania do koszyka (kroki: termin, modyfikacje) (2.26.13: przeniesione z kodu strony do pliku – przeglądarka trzyma go w pamięci podręcznej) */
window.kcAddSteps = window.kcAddSteps || [];
	(function () {
		function runSteps(ctx, done) {
			var steps = (window.kcAddSteps || []).slice().sort(function (a, b) { return a.order - b.order; });
			var i = 0;
			(function next() {
				if (i >= steps.length) { done(); return; }
				var s = steps[i++];
				s.run(ctx, next);
			})();
		}

		// Formularze "Dodaj do koszyka" (lista zamówień, karta produktu)
		document.addEventListener('submit', function (e) {
			var form = e.target;
			if (!form || form.__kcGo || !window.kcAddSteps || !window.kcAddSteps.length) { return; }
			var btn = (e.submitter && e.submitter.name === 'add-to-cart') ? e.submitter : form.querySelector('[name="add-to-cart"]');
			if (!btn) { return; }
			var pid = parseInt(btn.value, 10);
			if (!pid) { return; }
			e.preventDefault();

			var ctx = { pid: pid, form: form, fields: [] };
			runSteps(ctx, function () {
				var old = form.querySelectorAll('input[data-kc-field]');
				for (var i = 0; i < old.length; i++) { old[i].parentNode.removeChild(old[i]); }
				if (!form.querySelector('input[type="hidden"][name="add-to-cart"]')) {
					var h = document.createElement('input');
					h.type = 'hidden'; h.name = 'add-to-cart'; h.value = pid;
					h.setAttribute('data-kc-field', '1');
					form.appendChild(h);
				}
				ctx.fields.forEach(function (f) {
					var x = document.createElement('input');
					x.type = 'hidden'; x.name = f[0]; x.value = f[1];
					x.setAttribute('data-kc-field', '1');
					form.appendChild(x);
				});
				form.__kcGo = true;
				HTMLFormElement.prototype.submit.call(form);
				form.__kcGo = false;
			});
		}, true);

		// Przyciski AJAX "Dodaj do koszyka" (pętle produktów motywu)
		document.addEventListener('click', function (e) {
			var a = e.target && e.target.closest ? e.target.closest('.add_to_cart_button.ajax_add_to_cart') : null;
			if (!a || a.__kcGo || !window.kcAddSteps || !window.kcAddSteps.length) { return; }
			var pid = parseInt(a.getAttribute('data-product_id'), 10);
			if (!pid) { return; }
			e.preventDefault();
			e.stopImmediatePropagation();

			var ctx = { pid: pid, link: a, fields: [] };
			runSteps(ctx, function () {
				a.__kcFields = ctx.fields; // 2.26.17: dołączane do zapytania w „adding_to_cart” (niżej)
				a.__kcGo = true;
				a.click();
				a.__kcGo = false;
			});
		}, true);

		// 2.26.17 POPRAWKA: przyciski AJAX motywu (sklep, kategorie, „Zamów razem”) wysyłały
		// do koszyka tylko id produktu – wybrane modyfikacje (pola z kroków bramy) przepadały.
		// WooCommerce przed wysłaniem woła „adding_to_cart” z obiektem danych – dokładamy pola.
		if (window.jQuery) {
			window.jQuery(document.body).on('adding_to_cart', function (e, $btn, data) {
				var el = $btn && $btn[0];
				if (!el || !el.__kcFields || !data) { return; }
				el.__kcFields.forEach(function (f) { data[f[0]] = f[1]; });
				el.__kcFields = null;
			});
			// 2.26.20: po dodaniu przyciskiem AJAX (sklep, kategorie) napis „W koszyku”
			// zamiast „Dodaj do koszyka” – ptaszek ✓ zostaje (klasa „added” z WooCommerce).
			// Przycisk działa dalej: kolejny klik dodaje następną sztukę.
			window.jQuery(document.body).on('added_to_cart', function (e, fragments, hash, $btn) {
				var el = $btn && $btn[0];
				if (!el || !el.classList || !el.classList.contains('add_to_cart_button')) { return; }
				var lbl = el.querySelector('span') || el; // motywy blokowe mają napis w <span>
				lbl.textContent = 'W koszyku';
			});
		}
	})();
