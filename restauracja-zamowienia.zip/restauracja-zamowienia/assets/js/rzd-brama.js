/* Restauracja – Zamówienia i Dostawy: brama dodawania do koszyka (kroki: termin, modyfikacje) */
window.kcAddSteps = window.kcAddSteps || [];
// po „Dodaj do koszyka” (zwykły formularz = nowe wczytanie strony) i po „Zmień termin”
// strona wracała na samą górę – klient tracił miejsce na długiej liście. Zapamiętujemy
// przewinięcie tuż przed wysłaniem/przeładowaniem i przywracamy je na tej samej stronie.
window.rzdKeepScroll = function () {
	try {
		sessionStorage.setItem('rzd_scroll', JSON.stringify({ p: window.location.pathname, y: window.pageYOffset || document.documentElement.scrollTop || 0, t: Date.now() }));
	} catch (e) { /* tryb prywatny */ }
};
(function () {
	var s = null;
	try { s = JSON.parse(sessionStorage.getItem('rzd_scroll') || 'null'); sessionStorage.removeItem('rzd_scroll'); } catch (e) { return; }
	if (!s || !s.y || s.p !== window.location.pathname || Date.now() - s.t > 120000) { return; }
	var nav = (window.performance && performance.getEntriesByType) ? performance.getEntriesByType('navigation')[0] : null;
	if (nav && nav.type === 'back_forward') { return; } // „Wstecz” – przeglądarka sama pamięta miejsce
	var moved = false;
	['wheel', 'touchstart', 'keydown'].forEach(function (ev) { window.addEventListener(ev, function () { moved = true; }, { passive: true, once: true }); });
	function hasError() { return !!document.querySelector('.woocommerce-error, .wc-block-components-notice-banner.is-error'); }
	function go() { if (!moved && !hasError()) { window.scrollTo(0, s.y); } }
	if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', go); } else { go(); }
	window.addEventListener('load', function () { if (Math.abs((window.pageYOffset || 0) - s.y) > 30) { go(); } }); // po doczytaniu zdjęć
})();
	(function () {
		function runSteps(ctx, done) {
			var steps = (window.kcAddSteps || []).slice().sort(function (a, b) { return a.order - b.order; });
			var i = 0;
			(function next() {
				if (i >= steps.length) { done(); return; }
				var s = steps[i++];
				s.run(ctx, next);
			})();
		}
		window.rzdRunAddSteps = runSteps;

		/*
		 * Dodanie produktu W TLE (2.42.0 – karty „Dobierz do zamówienia”, moduł 32): te same kroki co
		 * „Dodaj do koszyka” (termin / zgodność z terminem koszyka, okno modyfikacji), potem zapytanie
		 * WooCommerce add_to_cart bez przeładowania. Licznik i mini-koszyk – wc_fragment_refresh (bez
		 * zdarzenia added_to_cart: okienko „Dodano do koszyka” nie wyskakuje nad przeglądem zamówienia).
		 * opts: { qty, fields: [[nazwa, wartość]], onStart() – kroki przeszły, wysyłam }.
		 * Zwraca Promise → { ok, msg }. Anulowane okno (termin / modyfikacje) – Promise się nie rozstrzyga.
		 */
		window.rzdAddProduct = function (pid, opts) {
			opts = opts || {};
			return new Promise(function (resolve) {
				var ctx = { pid: parseInt(pid, 10), fields: [], background: true };
				runSteps(ctx, function () {
					if (opts.onStart) { opts.onStart(); }
					var body = new URLSearchParams();
					body.append('product_id', ctx.pid);
					body.append('quantity', opts.qty || 1);
					ctx.fields.concat(opts.fields || []).forEach(function (f) { body.append(f[0], f[1]); });
					var cfg = window.rzdBrama || {};
					fetch(cfg.add || '/?wc-ajax=add_to_cart', { method: 'POST', credentials: 'same-origin', body: body })
						.then(function (r) { return r.json(); })
						.then(function (d) {
							if (!d || d.error) { resolve({ ok: false, msg: cfg.err || 'Nie udało się dodać – spróbuj ponownie.' }); return; }
							if (window.jQuery) { window.jQuery(document.body).trigger('wc_fragment_refresh'); }
							resolve({ ok: true });
						})
						.catch(function () { resolve({ ok: false, msg: 'Nie udało się – sprawdź połączenie.' }); });
				});
			});
		};

		// Formularze "Dodaj do koszyka" (lista zamówień, karta produktu)
		document.addEventListener('submit', function (e) {
			var form = e.target;
			// każdy formularz dodawania do koszyka (też bez kroków bramy) – zapamiętaj miejsce
			if (form && form.querySelector && form.querySelector('[name="add-to-cart"]') && window.rzdKeepScroll) { window.rzdKeepScroll(); }
			if (!form || form.__kcGo || !window.kcAddSteps || !window.kcAddSteps.length) { return; }
			var btn = (e.submitter && e.submitter.name === 'add-to-cart') ? e.submitter : form.querySelector('[name="add-to-cart"]');
			if (!btn) { return; }
			var pid = parseInt(btn.value, 10);
			if (!pid) { return; }
			e.preventDefault();

			var ctx = { pid: pid, form: form, fields: [] };
			runSteps(ctx, function () {
				var old = form.querySelectorAll('input[data-kc-field]');
				for (var i = 0; i < old.length; i++) { old[i].parentNode.removeChild(old[i]); }
				if (!form.querySelector('input[type="hidden"][name="add-to-cart"]')) {
					var h = document.createElement('input');
					h.type = 'hidden'; h.name = 'add-to-cart'; h.value = pid;
					h.setAttribute('data-kc-field', '1');
					form.appendChild(h);
				}
				ctx.fields.forEach(function (f) {
					var x = document.createElement('input');
					x.type = 'hidden'; x.name = f[0]; x.value = f[1];
					x.setAttribute('data-kc-field', '1');
					form.appendChild(x);
				});
				form.__kcGo = true;
				if (window.rzdKeepScroll) { window.rzdKeepScroll(); } // kroki mogły trwać (okienka) – aktualne miejsce
				HTMLFormElement.prototype.submit.call(form);
				form.__kcGo = false;
			});
		}, true);

		// Przyciski AJAX "Dodaj do koszyka" (pętle produktów motywu)
		document.addEventListener('click', function (e) {
			var a = e.target && e.target.closest ? e.target.closest('.add_to_cart_button.ajax_add_to_cart') : null;
			if (!a || a.__kcGo || !window.kcAddSteps || !window.kcAddSteps.length) { return; }
			var pid = parseInt(a.getAttribute('data-product_id'), 10);
			if (!pid) { return; }
			e.preventDefault();
			e.stopImmediatePropagation();

			var ctx = { pid: pid, link: a, fields: [] };
			runSteps(ctx, function () {
				a.__kcFields = ctx.fields; // dołączane do zapytania w „adding_to_cart” (niżej)
				a.__kcGo = true;
				a.click();
				a.__kcGo = false;
			});
		}, true);

		// POPRAWKA: przyciski AJAX motywu (sklep, kategorie, „Zamów razem”) wysyłały
		// do koszyka tylko id produktu – wybrane modyfikacje (pola z kroków bramy) przepadały.
		// WooCommerce przed wysłaniem woła „adding_to_cart” z obiektem danych – dokładamy pola.
		if (window.jQuery) {
			window.jQuery(document.body).on('adding_to_cart', function (e, $btn, data) {
				var el = $btn && $btn[0];
				if (!el || !el.__kcFields || !data) { return; }
				el.__kcFields.forEach(function (f) { data[f[0]] = f[1]; });
				el.__kcFields = null;
			});
			// po dodaniu przyciskiem AJAX (sklep, kategorie) napis „W koszyku”
			// zamiast „Dodaj do koszyka” – ptaszek ✓ zostaje (klasa „added” z WooCommerce).
			// Przycisk działa dalej: kolejny klik dodaje następną sztukę.
			window.jQuery(document.body).on('added_to_cart', function (e, fragments, hash, $btn) {
				var el = $btn && $btn[0];
				if (!el || !el.classList || !el.classList.contains('add_to_cart_button')) { return; }
				var lbl = el.querySelector('span') || el; // motywy blokowe mają napis w <span>
				lbl.textContent = 'W koszyku';
			});
		}
	})();
