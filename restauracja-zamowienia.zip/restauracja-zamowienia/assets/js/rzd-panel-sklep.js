/* Restauracja – Panel restauracji: sekcje Sklep i Wygląd (2.45.0).
 * Sklep: zakładki Koszyk, Pasek dostawy, Dobierz do zamówienia, Formularz zamówienia – formularz ze schematu
 * (rzd-panel-formy.js), zapis jednym przyciskiem. Wygląd: „Wygląd listy” – Komputer / Telefon, sekcje
 * rozwijane, podgląd NA ŻYWO (niezapisane wartości → serwer → <iframe> o szerokości urządzenia). */
(function () {
	'use strict';
	var K = window.rzdPanelKit;
	if (!K) { return; }
	var h = K.h, S = K.S;
	function copy(o) { return JSON.parse(JSON.stringify(o)); }

	/* ============================================================
	 * SKLEP
	 * ============================================================ */
	var SHOP_TABS = [['koszyk', 'Koszyk'], ['pasek', 'Pasek dostawy'], ['dobierz', 'Dobierz do zamówienia'], ['formularz', 'Formularz zamówienia']];

	function previewFrame(doc, title, cls) {
		var f = h('iframe', { class: 'rp-pframe' + (cls ? ' ' + cls : ''), title: title });
		f.srcdoc = doc;
		return f;
	}

	function secShop(main) {
		var tab = SHOP_TABS.some(function (t) { return t[0] === S.tab; }) ? S.tab : 'koszyk';
		var key = 'shop_' + tab, d = S.data[key];
		if (!d) {
			K.loading(main, 'Sklep');
			K.load(key, 'shop', { tab: tab }).then(K.render).catch(function (e) { main.textContent = ''; K.failBox(main, e, K.render); });
			return;
		}
		if (!S.work.shop || S.work.shopTab !== tab) { S.work.shop = copy(d.values); S.work.shopTab = tab; }
		var vals = S.work.shop;
		main.appendChild(K.pageHead('Sklep'));
		main.appendChild(K.tabsEl(SHOP_TABS, tab));
		if (d.intro) { main.appendChild(h('p', { class: 'rp-muted rp-intro', text: d.intro })); }
		main.appendChild(K.sform({ schema: d.schema, values: vals, imgs: d.imgs, products: d.products, cats: d.cats, onChange: K.dirty }));
		if (d.preview) {
			main.appendChild(h('section', { class: 'rp-card' }, [h('h2', { text: 'Podgląd zapisanych ustawień' }), previewFrame(d.preview, 'Podgląd koszyka', 'rp-pframe-s')]));
		}
		if (d.links && d.links.length) {
			main.appendChild(h('p', { class: 'rp-muted' }, d.links.map(function (l, i) { return h('span', null, [i ? ' · ' : '', h('a', { href: l[1], target: '_blank', rel: 'noopener', text: l[0] + ' ↗' })]); })));
		}
		main.appendChild(K.saveBar(function (b) {
			K.busy(b, true);
			K.api('shop_save', { tab: tab, values: vals }).then(function (x) {
				S.data[key] = x; S.work.shop = null; S.dirty = false; K.toast(x.message); K.render(); K.refreshWarnings();
			}, function (e) { K.busy(b, false); K.toast(e.message, true); });
		}));
	}

	/* ============================================================
	 * WYGLĄD (Wygląd listy)
	 * ============================================================ */
	var prevT = null, prevSeq = 0;

	function styleVal(vals, k, view) {
		if (view === 'mobile' && vals['m_' + k] !== undefined) { return vals['m_' + k]; }
		return vals[k];
	}

	function styleField(f, vals, view, sec) {
		var pre = view === 'mobile' ? 'm_' : '';
		if (f.t === 'note') { return h('p', { class: 'rp-fnote', text: f.l }); }
		if (f.t === 'sub') { return h('h3', { class: 'rp-h3', text: f.l }); }
		var k = pre + f.k, v = styleVal(vals, f.k, view);
		function set(x) { vals[k] = x; changed(); }
		var id = 'rps-' + k;
		switch (f.t) {
			case 'check':
				var cb = h('input', { type: 'checkbox', id: id, checked: !!+v, onchange: function () { set(cb.checked ? 1 : 0); } });
				return h('label', { class: 'rp-check', for: id }, [cb, h('span', { text: f.l })]);
			case 'color':
				var col = h('input', { type: 'color', class: 'rp-color', id: id, value: /^#[0-9a-f]{6}$/i.test(v || '') ? v : '#000000', oninput: function () { set(col.value); if (tog && !tog.checked) { tog.checked = true; vals[k + '_on'] = 1; } } });
				var tog = null;
				if (f.toggle) {
					var onv = view === 'mobile' && vals['m_' + f.k + '_on'] !== undefined ? vals['m_' + f.k + '_on'] : vals[f.k + '_on'];
					tog = h('input', { type: 'checkbox', checked: !!+onv, 'aria-label': f.l + ' – własny kolor', onchange: function () { vals[k + '_on'] = tog.checked ? 1 : 0; changed(); } });
					return h('div', { class: 'rp-field rp-sfield' }, [h('span', { class: 'rp-label', text: f.l }), h('span', { class: 'rp-inline' }, [h('label', { class: 'rp-check' }, [tog, h('span', { text: 'własny kolor' })]), col]), h('small', { class: 'rp-hint', text: 'bez zaznaczenia – kolor z motywu' })]);
				}
				return h('div', { class: 'rp-field rp-sfield' }, [h('label', { class: 'rp-label', for: id, text: f.l }), col]);
			case 'number':
				var nu = h('input', { type: 'number', class: 'rp-in rp-in-s', id: id, value: v === undefined || v === null ? '' : String(v), step: f.step ? String(f.step) : '1', inputmode: 'decimal', oninput: function () { set(nu.value); } });
				return h('div', { class: 'rp-field rp-sfield' }, [h('label', { class: 'rp-label', for: id, text: f.l }), h('span', { class: 'rp-unit' }, [nu, h('span', { text: f.u || 'px' })])]);
			case 'select':
			case 'weight':
				var sel = h('select', { class: 'rp-in', id: id, onchange: function () { set(sel.value); } }, Object.keys(f.o).map(function (o) { return h('option', { value: o, selected: String(v) === o, text: f.o[o] }); }));
				return h('div', { class: 'rp-field rp-sfield' }, [h('label', { class: 'rp-label', for: id, text: f.l }), sel]);
			default: // text, title
				var inp = h('input', { type: 'text', class: 'rp-in', id: id, oninput: function () { set(inp.value); } });
				inp.value = v === undefined || v === null ? '' : String(v);
				return h('div', { class: 'rp-field rp-sfield' }, [h('label', { class: 'rp-label', for: id, text: f.l }), inp]);
		}
	}

	function changed() {
		K.dirty();
		clearTimeout(prevT);
		prevT = setTimeout(livePreview, 450);
	}

	function livePreview() {
		var my = ++prevSeq, w = S.work.style;
		if (!w) { return; }
		var st = K.root.querySelector('.rp-pv-state');
		if (st) { st.textContent = 'odświeżam…'; }
		K.api('style_preview', { values: w }).then(function (x) {
			if (my !== prevSeq) { return; } // nowsza zmiana w drodze
			S.work.styleDoc = x.preview;
			setFrame(x.preview);
			if (st) { st.textContent = 'na żywo – jeszcze niezapisane'; }
		}).catch(function (e) { if (st) { st.textContent = e.message; } });
	}

	function setFrame(doc) {
		var f = K.root.querySelector('.rp-pv iframe');
		if (!f) { return; }
		var y = 0;
		try { y = f.contentWindow.scrollY || 0; } catch (e) { y = 0; }
		f.onload = function () { try { f.contentWindow.scrollTo(0, y); } catch (e) {} fit(); };
		f.srcdoc = doc;
	}

	// komputer: ramka 1000 px pomniejszona do szerokości kolumny; telefon: 390 px 1:1
	function fit() {
		var box = K.root.querySelector('.rp-pv-frame');
		var f = box && box.querySelector('iframe');
		if (!f) { return; }
		var w = +f.getAttribute('data-w'), avail = box.clientWidth;
		var sc = Math.min(1, avail / w);
		f.style.width = w + 'px';
		f.style.transform = 'scale(' + sc + ')';
		var hgt = window.innerWidth > 1100 ? Math.max(420, window.innerHeight - 220) : Math.max(200, Math.round(window.innerHeight * 0.34)); // wąski ekran: podgląd przyklejony nad formularzem
		f.style.height = Math.round(hgt / sc) + 'px';
		box.style.height = hgt + 'px';
	}
	window.addEventListener('resize', function () { if (S.sec === 'wyglad') { fit(); } });

	function secStyle(main) {
		var d = S.data.style;
		if (!d) {
			K.loading(main, 'Wygląd');
			K.load('style', 'style').then(K.render).catch(function (e) { main.textContent = ''; K.failBox(main, e, K.render); });
			return;
		}
		if (!S.work.style) { S.work.style = copy(d.values); S.work.styleDoc = d.preview; }
		var vals = S.work.style;
		var view = S.work.styleView || 'desktop';
		S.work.styleOpen = S.work.styleOpen || {};
		main.classList.add('rp-main-wide');
		main.appendChild(K.pageHead('Wygląd', 'Lista dań ([lista_zamowien]), strony sklepu i okienka dla klienta. Komputer = ekran od ' + d.bp + ' px, telefon = węższy. Telefon bierze ustawienia z komputera, chyba że w sekcji zaznaczysz „Na telefonie inaczej”. Podgląd zmienia się od razu – na stronie dopiero po zapisie.'));
		var views = h('div', { class: 'rp-chips', role: 'tablist', 'aria-label': 'Urządzenie' }, [['desktop', 'Komputer (i ustawienia wspólne)'], ['mobile', 'Telefon']].map(function (t) {
			return h('button', { type: 'button', role: 'tab', class: 'rp-chip' + (view === t[0] ? ' on' : ''), 'aria-selected': view === t[0] ? 'true' : 'false', text: t[1], onclick: function () { S.work.styleView = t[0]; K.render(); } });
		}));
		var form = h('div', { class: 'rp-st-form' });
		main.appendChild(views); // nad podglądem i formularzem (na telefonie podgląd jest u góry)
		d.sections.forEach(function (sec) {
			var fields = sec.fields;
			var body = [];
			if (view === 'mobile') {
				if (!sec.mobile) { return; }
				var own = fields.filter(function (f) { return !f.shared; });
				var mon = !!+vals['m_on_' + sec.id];
				var t = h('input', { type: 'checkbox', checked: mon, onchange: function () {
					vals['m_on_' + sec.id] = t.checked ? 1 : 0;
					if (t.checked) { // start od wartości komputera
						own.forEach(function (f) { if (f.k && vals['m_' + f.k] === undefined) { vals['m_' + f.k] = vals[f.k]; if (f.toggle) { vals['m_' + f.k + '_on'] = vals[f.k + '_on']; } } });
					}
					S.work.styleOpen[sec.id] = true;
					changed(); K.render();
				} });
				body.push(h('label', { class: 'rp-check rp-mon' }, [t, h('span', { text: 'Na telefonie inaczej niż na komputerze' })]));
				if (mon) {
					own.forEach(function (f) { body.push(styleField(f, vals, 'mobile', sec)); });
					if (own.length < fields.length) { body.push(h('p', { class: 'rp-fnote', text: 'Pozostałe pola tej sekcji są wspólne – zmienisz je w widoku Komputer.' })); }
				} else {
					body.push(h('p', { class: 'rp-muted', text: 'Telefon wygląda tu jak komputer.' }));
				}
			} else {
				fields.forEach(function (f) { body.push(styleField(f, vals, 'desktop', sec)); });
			}
			var det = h('details', { class: 'rp-card rp-st-sec', open: S.work.styleOpen[sec.id] ? true : null }, [
				h('summary', null, [h('span', { text: sec.title }), view === 'mobile' && +vals['m_on_' + sec.id] ? h('span', { class: 'rp-pill ok', text: 'inaczej' }) : null])
			].concat([h('div', { class: 'rp-st-body' }, body)]));
			det.addEventListener('toggle', function () { S.work.styleOpen[sec.id] = det.open; });
			form.appendChild(det);
		});
		var w = view === 'mobile' ? 390 : 1000;
		var frame = h('iframe', { title: 'Podgląd – ' + (view === 'mobile' ? 'telefon' : 'komputer'), 'data-w': String(w) });
		frame.srcdoc = S.work.styleDoc || d.preview;
		frame.addEventListener('load', fit);
		var pv = h('aside', { class: 'rp-pv' + (view === 'mobile' ? ' rp-pv-m' : '') + (S.work.pvMin ? ' rp-pv-min' : '') }, [
			h('div', { class: 'rp-pv-head' }, [h('strong', { text: 'Podgląd – ' + (view === 'mobile' ? 'telefon 390 px' : 'komputer 1000 px') }), h('small', { class: 'rp-pv-state rp-muted', text: S.dirty ? 'na żywo – jeszcze niezapisane' : 'zapisane ustawienia' }),
				// wąski ekran: podgląd przyklejony u góry – można go zwinąć
				h('button', { type: 'button', class: 'rp-btn rp-btn-link rp-pv-tog', 'aria-expanded': S.work.pvMin ? 'false' : 'true', text: S.work.pvMin ? 'pokaż' : 'zwiń', onclick: function (e) { S.work.pvMin = !S.work.pvMin; pv.classList.toggle('rp-pv-min', S.work.pvMin); e.currentTarget.textContent = S.work.pvMin ? 'pokaż' : 'zwiń'; e.currentTarget.setAttribute('aria-expanded', S.work.pvMin ? 'false' : 'true'); fit(); } })]),
			h('div', { class: 'rp-pv-frame' }, [frame])
		]);
		main.appendChild(h('div', { class: 'rp-st' }, [form, pv]));
		main.appendChild(K.saveBar(function (b) {
			K.busy(b, true);
			K.api('style_save', { values: vals }).then(function (x) {
				S.data.style = x; S.work.style = null; S.work.styleDoc = null; S.dirty = false; K.toast(x.message); K.render();
			}, function (e) { K.busy(b, false); K.toast(e.message, true); });
		}, 'Zapisz wygląd'));
		setTimeout(fit, 0);
	}

	K.sections.sklep = secShop;
	K.sections.wyglad = secStyle;
})();
