/* Restauracja – Panel restauracji: sekcja „Post dnia” (2.48.0, moduł 38-posty). Zakładki: Nowy post (zestaw + dzień →
 * dania, zdjęcia, dopisek → Gemini → podgląd jak na Facebooku → zatwierdzenie: zaplanuj / opublikuj teraz), Plan tygodnia
 * (posty na najbliższe dni naraz), Historia, Ustawienia (Gemini, wskazówki, sekcje posta, Facebook, automat).
 * Tekst zawsze przez textContent / value. */
(function () {
	'use strict';
	var K = window.rzdPanelKit;
	if (!K) { return; }
	var h = K.h, S = K.S;
	var TABS = [['nowy', 'Nowy post'], ['tydzien', 'Plan tygodnia'], ['historia', 'Historia'], ['ustawienia', 'Ustawienia']];
	var MEDIA = { list: 'posts_media_list', upload: 'posts_media_upload' };
	var urlPost = parseInt(new URLSearchParams(location.search).get('post') || '0', 10) || 0;
	function copy(o) { return JSON.parse(JSON.stringify(o)); }
	function fail(b) { return function (e) { K.busy(b, false); K.toast(e.message, true); }; }
	function pad(n) { return ('0' + n).slice(-2); }
	function tsToLocal(ts) { var d = new Date(ts * 1000); return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + 'T' + pad(d.getHours()) + ':' + pad(d.getMinutes()); }
	function localToTs(v) { var d = new Date(v); return isNaN(d.getTime()) ? 0 : Math.round(d.getTime() / 1000); }
	function whenLabel(ts) { var d = new Date(ts * 1000); return ['niedz.', 'pon.', 'wt.', 'śr.', 'czw.', 'pt.', 'sob.'][d.getDay()] + ' ' + d.getDate() + '.' + pad(d.getMonth() + 1) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes()); }
	function badge(p, d) {
		var st = p ? p.status : '';
		var txt = !p ? 'brak posta' : (d.statuses[st] || st) + (st === 'scheduled' && p.when ? ' · ' + whenLabel(p.when) : '');
		return h('span', { class: 'rp-pstat rp-pstat-' + (st || 'none'), text: txt });
	}
	function mainPost(list) { // najważniejszy post dnia: opublikowany > zaplanowany > szkic > błąd
		var order = { published: 0, scheduled: 1, draft: 2, error: 3 };
		return (list || []).slice().sort(function (a, b) { return (order[a.status] - order[b.status]) || (b.id - a.id); })[0] || null;
	}
	function reload() { S.data.posts = null; K.render(); }
	// Licznik na przycisku podczas pracy AI (modele potrafią odpowiadać kilkadziesiąt sekund) – widać, że coś się dzieje.
	function aiBusy(b, label) {
		var t0 = Date.now(), base = label || 'AI pisze';
		K.busy(b, true);
		b.dataset.txt = b.dataset.txt || b.textContent;
		b.textContent = base + '… 0 s';
		var iv = setInterval(function () {
			var s = Math.round((Date.now() - t0) / 1000);
			b.textContent = base + '… ' + s + ' s' + (s >= 45 ? ' (Gemini odpowiada długo)' : '');
		}, 1000);
		return function () { clearInterval(iv); if (b.dataset.txt) { b.textContent = b.dataset.txt; } K.busy(b, false); };
	}

	function secPosts(main) {
		var d = S.data.posts;
		if (!d) {
			K.loading(main, 'Post dnia');
			K.load('posts', 'posts').then(K.render).catch(function (e) { main.textContent = ''; K.failBox(main, e, K.render); });
			return;
		}
		var tab = TABS.some(function (t) { return t[0] === S.tab; }) ? S.tab : (urlPost ? 'nowy' : 'nowy');
		main.appendChild(K.pageHead('Post dnia', 'Posty na Facebooka – o zestawie dnia, o produkcie albo na dowolny temat: AI pisze tekst według Twoich wskazówek, Ty sprawdzasz i zatwierdzasz – Facebook publikuje o wybranej godzinie (zestaw: domyślnie dzień wcześniej o ' + d.pubTime + ').'));
		main.appendChild(K.tabsEl(TABS, tab));
		if (!d.ready && tab !== 'ustawienia') {
			main.appendChild(h('div', { class: 'rp-warn warn', role: 'note' }, [h('span', { text: 'Najpierw uzupełnij ustawienia: ' + [!d.hasKey ? 'klucz Gemini' : '', !d.values.model ? 'model AI' : '', !d.hasToken ? 'token strony Facebooka' : '', !d.values.fb_page ? 'ID strony' : ''].filter(Boolean).join(', ') + '.' }), K.btn('Ustawienia', function () { K.setTab('ustawienia'); }, 'rp-btn-link')]));
		}
		if (tab === 'tydzien') { week(main, d); }
		else if (tab === 'historia') { history(main, d); }
		else if (tab === 'ustawienia') { settings(main, d); }
		else { editor(main, d); }
	}

	/* ============================================================
	 * NOWY POST
	 * ============================================================ */
	function editor(main, d) {
		var W = S.work.post;
		if (!W) {
			W = S.work.post = { kind: 'set', day: d.days[1] ? d.days[1].day : d.days[0].day, set: d.sets[0] ? d.sets[0].id : 0, product: 0, topic: '', extra: '', dd: null, post: null, photos: [], text: '', when: 0, place: +d.values.place_def, loading: false };
			var open = S.postOpen || urlPost;
			S.postOpen = 0; urlPost = 0;
			var found = open ? d.history.filter(function (p) { return p.id === open; })[0] : null;
			if (found) {
				W.post = found; W.kind = found.kind || 'set'; W.day = found.day || W.day; W.set = found.set || W.set; W.product = found.product || 0; W.topic = found.topic || '';
				W.photos = copy(found.photos); W.text = found.text; W.when = found.when; W.extra = found.extra || ''; W.place = +found.place;
				if (W.kind === 'topic') { W.dd = { kind: 'topic' }; }
			}
		}
		function reset(o) { // nowy, pusty post (zmiana rodzaju, dnia, zestawu, produktu)
			if (S.dirty && !window.confirm('Masz niezapisane zmiany w poście. Przejść mimo to?')) { K.render(); return; }
			S.dirty = false;
			S.work.post = Object.assign({ kind: W.kind, day: W.day, set: W.set, product: 0, topic: '', extra: '', dd: null, post: null, photos: [], text: '', when: 0, place: +d.values.place_def }, o);
			if (S.work.post.kind === 'topic') { S.work.post.dd = { kind: 'topic' }; S.work.post.when = d.nextPub; }
			K.render();
		}

		// rodzaj posta
		var kinds = h('div', { class: 'rp-pkinds', role: 'radiogroup', 'aria-label': 'Rodzaj posta' }, Object.keys(d.kinds).map(function (k) {
			return h('button', { type: 'button', role: 'radio', 'aria-checked': W.kind === k ? 'true' : 'false', class: 'rp-pkind' + (W.kind === k ? ' on' : ''), text: d.kinds[k], onclick: function () { if (W.kind !== k) { reset({ kind: k }); } } });
		}));
		main.appendChild(h('section', { class: 'rp-card' }, [h('h2', { text: 'Rodzaj posta' }), kinds]));

		if (W.kind === 'set') {
			if (!d.sets.length) { main.appendChild(h('p', { class: 'rp-muted', text: 'Nie ma żadnego zestawu – post o zestawie powstaje z zestawu i jego dań na wybrany dzień.' })); return; }
			if (!W.dd && !W.loading) {
				W.loading = true;
				K.api('posts_day', { day: W.day, set: W.set }).then(function (x) {
					W.loading = false; W.dd = x;
					if (!W.post) {
						var ex = mainPost(x.posts);
						if (ex) { W.post = ex; W.photos = copy(ex.photos); W.text = ex.text; W.when = ex.when; W.extra = ex.extra || ''; W.place = +ex.place; }
						else { W.photos = copy(x.photos); W.when = x.when; }
					}
					K.render();
				}, function (e) { W.loading = false; K.toast(e.message, true); });
			}
			var card = h('section', { class: 'rp-card' }, [h('h2', { text: 'Zestaw i dzień' })]);
			var daySel = h('select', { class: 'rp-in', 'aria-label': 'Dzień', onchange: function () { reset({ day: daySel.value }); } }, d.days.map(function (x) { return h('option', { value: x.day, text: x.label, selected: x.day === W.day ? true : null }); }));
			var setSel = h('select', { class: 'rp-in', 'aria-label': 'Zestaw', onchange: function () { reset({ set: parseInt(setSel.value, 10) }); } }, d.sets.map(function (x) { return h('option', { value: String(x.id), text: x.name, selected: x.id === W.set ? true : null }); }));
			card.appendChild(h('div', { class: 'rp-row2' }, [K.field('Dzień obiadu (post publikujemy dzień wcześniej)', daySel), K.field('Zestaw', setSel)]));
			if (!W.dd) { card.appendChild(h('p', { class: 'rp-load', text: 'Wczytuję dania…' })); main.appendChild(card); return; }
			var dd = W.dd;
			if (dd.missing && dd.missing.length) {
				card.appendChild(h('p', { class: 'rp-fnote warn', text: '⚠ Bez dania na ten dzień: ' + dd.missing.join(', ') + ' – uzupełnij w Zestawach (do AI idą tylko zaplanowane dania).' }));
			}
			if (!dd.dishes.length) {
				card.appendChild(h('p', { class: 'rp-fnote warn', text: 'Zestaw nie ma dań na ten dzień – uzupełnij harmonogram (Panel → Zestawy albo Edycja menu).' }));
				main.appendChild(card);
				return;
			}
			card.appendChild(h('ul', { class: 'rp-pdishes' }, dd.dishes.map(function (x) { return h('li', null, [h('strong', { text: x.name }), x.role ? h('span', { class: 'rp-muted', text: ' · ' + x.role }) : null]); })));
			var other = dd.posts.filter(function (p) { return !W.post || p.id !== W.post.id; });
			if (other.length) {
				card.appendChild(h('p', { class: 'rp-fnote' }, ['Na ten dzień są też inne posty: ', other.map(function (p) { return (d.statuses[p.status] || p.status) + ' #' + p.id; }).join(', '), ' – zobacz Historię.']));
			}
			main.appendChild(card);
		} else if (W.kind === 'product') {
			var pc = h('section', { class: 'rp-card' }, [h('h2', { text: 'Produkt' })]);
			var q = h('input', { type: 'search', class: 'rp-in', placeholder: 'Szukaj dania…', 'aria-label': 'Szukaj produktu', value: W.q || '', oninput: function () { W.q = q.value; fill(); } });
			var sel = h('select', { class: 'rp-in', 'aria-label': 'Produkt', onchange: function () { var id = parseInt(sel.value, 10) || 0; if (id !== W.product) { reset({ product: id, q: W.q }); } } });
			function fill() {
				var t = (W.q || '').toLowerCase();
				sel.textContent = '';
				sel.appendChild(h('option', { value: '0', text: '— wybierz produkt —' }));
				d.products.filter(function (x) { return !t || (x.name + ' ' + x.cat).toLowerCase().indexOf(t) > -1 || x.id === W.product; }).forEach(function (x) {
					sel.appendChild(h('option', { value: String(x.id), text: x.name + (x.cat ? ' · ' + x.cat : ''), selected: x.id === W.product ? true : null }));
				});
			}
			fill();
			pc.appendChild(h('div', { class: 'rp-row2' }, [K.field('Szukaj', q), K.field('Danie / produkt', sel)]));
			if (!W.product) { pc.appendChild(h('p', { class: 'rp-muted', text: 'Wybierz produkt – do AI pójdzie jego nazwa, kategoria i opis z karty, a jego zdjęcia podpowiedzą się do posta.' })); main.appendChild(pc); return; }
			if (!W.dd && !W.loading) {
				W.loading = true;
				K.api('posts_product', { product: W.product }).then(function (x) {
					W.loading = false; W.dd = x;
					if (!W.post) { W.photos = copy(x.photos); W.when = d.nextPub; }
					K.render();
				}, function (e) { W.loading = false; K.toast(e.message, true); });
			}
			if (!W.dd) { pc.appendChild(h('p', { class: 'rp-load', text: 'Wczytuję produkt…' })); main.appendChild(pc); return; }
			if (W.dd.desc) { pc.appendChild(h('p', { class: 'rp-muted', text: W.dd.desc.slice(0, 240) + (W.dd.desc.length > 240 ? '…' : '') })); }
			main.appendChild(pc);
		} else {
			var tc = h('section', { class: 'rp-card' }, [h('h2', { text: 'O czym post' })]);
			var locked0 = W.post && (W.post.status === 'scheduled' || W.post.status === 'published');
			var topic = h('textarea', { class: 'rp-in', rows: '4', maxlength: '1500', 'aria-label': 'Temat posta', readonly: locked0 ? true : null, placeholder: 'np. „Od poniedziałku dowozimy też do Ujścia”, „Catering na Wigilię – zapisy do 15 grudnia”, „Szukamy kucharza na zmianę poranną”', oninput: function () { W.topic = topic.value; } });
			topic.value = W.topic;
			tc.appendChild(K.field('Temat – AI napisze post według Twoich wskazówek i sekcji', topic));
			main.appendChild(tc);
		}

		// zdjęcia
		var phCard = h('section', { class: 'rp-card' }, [h('h2', { text: 'Zdjęcia do posta' }), h('p', { class: 'rp-muted', text: 'Idą do posta w tej kolejności (pierwsze – największe na Facebooku). ' + (W.kind === 'topic' ? 'Dodaj z biblioteki albo prosto z telefonu.' : 'Podpowiadamy zdjęcia ' + (W.kind === 'set' ? 'dań z zestawu.' : 'produktu.')) })]);
		var locked = W.post && (W.post.status === 'scheduled' || W.post.status === 'published');
		var grid = h('div', { class: 'rp-pphotos' });
		W.photos.forEach(function (ph, i) {
			grid.appendChild(h('div', { class: 'rp-pphoto' }, [
				h('img', { src: ph.url, alt: '' }),
				locked ? null : h('div', { class: 'rp-pphoto-act' }, [
					i ? h('button', { type: 'button', class: 'rp-ico', 'aria-label': 'Wcześniej', text: '←', onclick: function () { W.photos.splice(i - 1, 0, W.photos.splice(i, 1)[0]); K.dirty(); K.render(); } }) : null,
					h('button', { type: 'button', class: 'rp-ico', 'aria-label': 'Usuń zdjęcie', html: K.ICON.x, onclick: function () { W.photos.splice(i, 1); K.dirty(); K.render(); } })
				])
			]));
		});
		if (!locked && W.photos.length < 10) {
			grid.appendChild(h('button', { type: 'button', class: 'rp-pphoto rp-pphoto-add', text: '+ Dodaj zdjęcie', onclick: function () { K.pickImage(function (it) { W.photos.push({ id: it.id, url: it.url }); K.dirty(); K.render(); }, MEDIA); } }));
		}
		if (!W.photos.length && locked) { grid.appendChild(h('p', { class: 'rp-muted', text: 'Bez zdjęć.' })); }
		phCard.appendChild(grid);
		main.appendChild(phCard);

		// AI
		var aiCard = h('section', { class: 'rp-card' }, [h('h2', { text: 'Tekst (AI)' })]);
		var extra = h('textarea', { class: 'rp-in', rows: '2', maxlength: '500', placeholder: 'Opcjonalnie: np. „jutro ma padać”, „nowość w karcie”, „ostatni dzień przed świętami”', oninput: function () { W.extra = extra.value; } });
		extra.value = W.extra;
		aiCard.appendChild(K.field('Dopisek dla AI', extra));
		if (!locked) {
			aiCard.appendChild(h('div', { class: 'rp-inline' }, [K.btn(W.post ? 'Wygeneruj ponownie' : 'Generuj post', function (e) {
				if (W.kind === 'topic' && !String(W.topic || '').trim()) { K.toast('Napisz, o czym ma być post.', true); return; }
				if (W.post && S.dirty && !window.confirm('Nowy tekst zastąpi Twoje poprawki. Generować?')) { return; }
				var b = e.currentTarget; var done = aiBusy(b);
				K.api('posts_generate', { kind: W.kind, day: W.day, set: W.set, product: W.product, topic: W.topic, extra: W.extra, place: W.place ? 1 : 0, photos: W.photos.map(function (p) { return { id: p.id }; }), post: W.post ? W.post.id : 0 }).then(function (x) {
					done(); W.post = x.post; W.text = x.post.text; W.photos = copy(x.post.photos); W.when = x.post.when; S.dirty = false; S.data.posts = null; K.toast(x.message); refreshKeep();
				}, function (er) { done(); K.toast(er.message, true); });
			}, 'rp-btn-pri')]));
		}
		main.appendChild(aiCard);
		if (W.post) { preview(main, d, W, locked); }
	}

	function refreshKeep() { // dane sekcji od nowa (Plan, Historia), edytor zostaje
		K.load('posts', 'posts').then(K.render, K.render);
	}

	function preview(main, d, W, locked) {
		var p = W.post;
		var box = h('section', { class: 'rp-card' }, [h('h2', { text: 'Podgląd i zatwierdzenie' }), badge(p, d)]);
		if (p.err) { box.appendChild(h('p', { class: 'rp-fnote warn', text: (p.status === 'draft' || p.status === 'error' ? 'Ostatni błąd: ' : 'Uwaga: ') + p.err })); }
		var ta = h('textarea', { class: 'rp-in rp-ptext', rows: '16', 'aria-label': 'Tekst posta', readonly: locked ? true : null, oninput: function () { W.text = ta.value; fbText.textContent = ta.value; K.dirty(); } });
		ta.value = W.text;
		var fbText = h('div', { class: 'rp-fb-text', text: W.text });
		var n = W.photos.length;
		var fbPh = h('div', { class: 'rp-fb-photos rp-fb-n' + Math.min(n, 5) }, W.photos.slice(0, 5).map(function (ph, i) {
			return h('div', { class: 'rp-fb-ph' }, [h('img', { src: ph.url, alt: '' }), i === 4 && n > 5 ? h('span', { class: 'rp-fb-more', text: '+' + (n - 5) }) : null]);
		}));
		var fb = h('div', { class: 'rp-fb', 'aria-label': 'Podgląd posta na Facebooku' }, [
			h('div', { class: 'rp-fb-head' }, [h('span', { class: 'rp-fb-av', text: 'f' }), h('div', null, [h('strong', { text: 'Twoja strona' }), h('small', { text: (p.when ? whenLabel(p.when) + ' · ' : '') + (W.place ? '📍 ' : '') + '🌍' })])]),
			fbText, n ? fbPh : null
		]);
		box.appendChild(h('div', { class: 'rp-pprev' }, [h('div', { class: 'rp-pprev-ed' }, [K.field('Tekst posta – możesz poprawić', ta, locked ? null : 'Sekcje oddzielone pustą linią, jak w ustawieniach.')]), fb]));
		if (locked) {
			var acts = [];
			if (p.fbUrl || p.fb) { acts.push(h('a', { class: 'rp-btn', href: p.fbUrl || ('https://www.facebook.com/' + p.fb), target: '_blank', rel: 'noopener', text: 'Zobacz na Facebooku ↗' })); }
			if (p.status === 'scheduled') {
				acts.push(K.btn('Cofnij planowanie', function (e) {
					if (!window.confirm('Usunąć zaplanowany post z Facebooka? Wróci do szkiców.')) { return; }
					var b = e.currentTarget; K.busy(b, true);
					K.api('posts_unschedule', { post: p.id }).then(function (x) { W.post = x.post; K.toast(x.message); S.data.posts = null; refreshKeep(); }, fail(b));
				}, 'rp-btn-link'));
			}
			box.appendChild(h('div', { class: 'rp-inline' }, acts));
			main.appendChild(box);
			return;
		}
		var when = h('input', { type: 'datetime-local', class: 'rp-in rp-in-m', value: W.when ? tsToLocal(W.when) : '', 'aria-label': 'Kiedy opublikować', onchange: function () { W.when = localToTs(when.value); } });
		box.appendChild(K.field('Publikacja na Facebooku', when, (W.kind === 'set' ? 'Domyślnie dzień wcześniej o ' : 'Domyślnie najbliższa ') + d.pubTime + '. Facebook planuje od 10 minut do 30 dni naprzód.'));
		var pl = h('input', { type: 'checkbox', checked: W.place ? true : null, onchange: function () { W.place = pl.checked ? 1 : 0; K.dirty(); } });
		box.appendChild(h('label', { class: 'rp-check' }, [pl, h('span', { text: '📍 Oznacz lokalizację' + (d.values.place ? ' (ID ' + d.values.place + ')' : ' (Wasza strona – musi mieć adres)') })]));
		function body() { return { post: p.id, text: W.text, place: W.place ? 1 : 0, photos: W.photos.map(function (x) { return { id: x.id }; }) }; }
		box.appendChild(h('div', { class: 'rp-inline rp-pacts' }, [
			K.btn('✓ Zatwierdź i zaplanuj', function (e) {
				if (!W.when) { K.toast('Wybierz datę i godzinę publikacji.', true); return; }
				var b = e.currentTarget; K.busy(b, true);
				var q = body(); q.mode = 'schedule'; q.when = W.when;
				K.api('posts_publish', q).then(function (x) { W.post = x.post; S.dirty = false; K.toast(x.message); S.data.posts = null; refreshKeep(); }, fail(b));
			}, 'rp-btn-pri'),
			K.btn('Opublikuj teraz', function (e) {
				if (!window.confirm('Opublikować post na Facebooku teraz?')) { return; }
				var b = e.currentTarget; K.busy(b, true);
				var q = body(); q.mode = 'now';
				K.api('posts_publish', q).then(function (x) { W.post = x.post; S.dirty = false; K.toast(x.message); S.data.posts = null; refreshKeep(); }, fail(b));
			}),
			K.btn('Zapisz szkic', function (e) {
				var b = e.currentTarget; K.busy(b, true);
				K.api('posts_save', body()).then(function (x) { W.post = x.post; S.dirty = false; K.busy(b, false); K.toast(x.message); S.data.posts = null; refreshKeep(); }, fail(b));
			}),
			K.btn('Usuń szkic', function (e) {
				if (!window.confirm('Usunąć ten szkic?')) { return; }
				var b = e.currentTarget; K.busy(b, true);
				K.api('posts_delete', { post: p.id }).then(function (x) { S.data.posts = x; S.work.post = null; S.dirty = false; K.toast(x.message); K.render(); }, fail(b));
			}, 'rp-btn-link')
		]));
		main.appendChild(box);
	}

	/* ============================================================
	 * PLAN TYGODNIA
	 * ============================================================ */
	function week(main, d) {
		var card = h('section', { class: 'rp-card' }, [h('h2', { text: 'Najbliższe dni z zestawem' }), h('p', { class: 'rp-muted', text: 'Gdy w weekend ułożysz zestawy na cały tydzień: „Generuj brakujące”, przejrzyj posty (Otwórz), potem „Zatwierdź i zaplanuj szkice” – każdy wyjdzie dzień wcześniej o ' + d.pubTime + '. Dni bez posta automat przygotuje o ' + d.genTime + ' dzień wcześniej jako szkic do zatwierdzenia.' })]);
		if (!d.week.length) { card.appendChild(h('p', { class: 'rp-muted', text: 'W najbliższych 7 dniach żaden zestaw nie ma dań.' })); main.appendChild(card); return; }
		var list = h('div', { class: 'rp-pweek' });
		var missing = [], drafts = [];
		d.week.forEach(function (w) {
			var p = mainPost(w.posts);
			if (!p || p.status === 'error') { missing.push(w); }
			if (p && p.status === 'draft') { drafts.push({ w: w, p: p }); }
			list.appendChild(h('div', { class: 'rp-pweek-r' }, [
				h('div', null, [h('strong', { text: w.label }), h('div', { class: 'rp-muted', text: w.setName + ': ' + w.dishes.join(', ') }), w.missing && w.missing.length ? h('div', { class: 'rp-fnote warn', text: '⚠ bez dania: ' + w.missing.join(', ') }) : null]),
				badge(p && p.status !== 'error' ? p : null, d),
				h('div', { class: 'rp-inline' }, [
					p && p.status !== 'error' ? K.btn('Otwórz', function () { S.postOpen = p.id; K.setTab('nowy'); }) : K.btn('Generuj', function (e) { gen([w], e.currentTarget); })
				])
			]));
		});
		card.appendChild(list);
		function gen(items, b) {
			if (!d.ready) { K.toast('Najpierw uzupełnij ustawienia.', true); return; }
			K.busy(b, true);
			var i = 0;
			(function next() {
				if (i >= items.length) { K.busy(b, false); K.toast('Gotowe – przejrzyj szkice.'); reload(); return; }
				var w = items[i++];
				K.toast('AI pisze post na ' + w.label + ' (' + i + '/' + items.length + ')…');
				K.api('posts_generate', { day: w.day, set: w.set, src: 'week' }).then(next, function (e) { K.busy(b, false); K.toast(w.label + ': ' + e.message, true); reload(); });
			})();
		}
		var acts = [];
		if (missing.length) { acts.push(K.btn('Generuj brakujące (' + missing.length + ')', function (e) { gen(missing, e.currentTarget); }, 'rp-btn-pri')); }
		if (drafts.length) {
			acts.push(K.btn('Zatwierdź i zaplanuj szkice (' + drafts.length + ')', function (e) {
				if (!window.confirm('Zaplanować ' + drafts.length + ' szkic(e) na Facebooku – każdy dzień wcześniej o ' + d.pubTime + '? Najpierw przejrzyj je (Otwórz).')) { return; }
				var b = e.currentTarget; K.busy(b, true);
				var i = 0, okN = 0, errs = [];
				(function next() {
					if (i >= drafts.length) { K.busy(b, false); K.toast('Zaplanowano: ' + okN + (errs.length ? '. Błędy: ' + errs.join('; ') : '.'), !!errs.length); reload(); return; }
					var x = drafts[i++];
					K.api('posts_publish', { post: x.p.id, mode: 'schedule', when: x.p.when || x.w.when }).then(function () { okN++; next(); }, function (er) { errs.push(x.w.label + ': ' + er.message); next(); });
				})();
			}));
		}
		if (acts.length) { card.appendChild(h('div', { class: 'rp-inline' }, acts)); }
		main.appendChild(card);
	}

	/* ============================================================
	 * HISTORIA
	 * ============================================================ */
	function history(main, d) {
		var card = h('section', { class: 'rp-card' }, [h('h2', { text: 'Historia postów' })]);
		if (!d.history.length) { card.appendChild(h('p', { class: 'rp-muted', text: 'Jeszcze nie ma postów.' })); main.appendChild(card); return; }
		var src = { manual: 'ręcznie', week: 'plan tygodnia', auto: 'automat' };
		card.appendChild(h('div', { class: 'rp-phist' }, d.history.map(function (p) {
			return h('div', { class: 'rp-phist-r' }, [
				p.photos && p.photos[0] ? h('img', { src: p.photos[0].url, alt: '' }) : h('span', { class: 'rp-phist-noimg' }),
				h('div', { class: 'rp-phist-t' }, [
					h('div', null, [h('strong', { text: p.dayLabel || p.day }), ' ', badge(p, d)]),
					h('div', { class: 'rp-muted', text: (d.kinds[p.kind] || '') + ' · ' + (src[p.src] || p.src || '') + (p.by ? ' · ' + p.by : '') }),
					h('p', { class: 'rp-phist-x', text: (p.text || '').slice(0, 160) + ((p.text || '').length > 160 ? '…' : '') }),
					p.err ? h('p', { class: 'rp-fnote warn', text: p.err }) : null
				]),
				h('div', { class: 'rp-inline' }, [
					p.fbUrl ? h('a', { class: 'rp-btn', href: p.fbUrl, target: '_blank', rel: 'noopener', text: 'Facebook ↗' }) : null,
					p.status !== 'error' ? K.btn('Otwórz', function () { S.postOpen = p.id; K.setTab('nowy'); }) : null
				])
			]);
		})));
		main.appendChild(card);
	}

	/* ============================================================
	 * USTAWIENIA
	 * ============================================================ */
	function settings(main, d) {
		if (!S.work.pset) { S.work.pset = copy(d.values); }
		var v = S.work.pset;
		function inp(k, attrs) {
			var a = Object.assign({ class: 'rp-in', value: v[k] == null ? '' : String(v[k]), oninput: function (e) { v[k] = e.target.value; K.dirty(); } }, attrs || {});
			return h('input', a);
		}
		// Gemini
		var g = h('section', { class: 'rp-card' }, [h('h2', { text: 'AI – Gemini' })]);
		g.appendChild(K.field('Klucz API Gemini', inp('gemini_key', { type: 'password', autocomplete: 'off', placeholder: d.keyConst ? 'ustawiony w wp-config.php' : (d.hasKey ? '•••••• zapisany – wpisz nowy, żeby zmienić („-” usuwa)' : 'wklej klucz z Google AI Studio') }), 'Klucz z aistudio.google.com → Get API key. Zapisany w bazie zaszyfrowany.'));
		var model = h('select', { class: 'rp-in', 'aria-label': 'Model AI', onchange: function () { v.model = model.value; K.dirty(); } }, [h('option', { value: v.model || '', text: v.model || '— wybierz (Pobierz listę) —' })]);
		g.appendChild(K.field('Model', h('div', { class: 'rp-inline' }, [model, K.btn('Pobierz listę modeli', function (e) {
			var b = e.currentTarget; K.busy(b, true);
			K.api('posts_models', { key: v.gemini_key || '' }).then(function (x) {
				K.busy(b, false);
				model.textContent = '';
				x.models.forEach(function (m) { model.appendChild(h('option', { value: m.id, text: m.name + ' (' + m.id + ')', selected: m.id === v.model ? true : null })); });
				if (!v.model && x.models[0]) { var pref = x.models.filter(function (m) { return /flash/i.test(m.id) && !/lite|preview|exp/i.test(m.id); })[0] || x.models[0]; v.model = pref.id; model.value = pref.id; K.dirty(); }
				K.toast('Modele: ' + x.models.length + '.');
			}, fail(b));
		})]), 'Lista z Google – modele szybko się zmieniają. „Flash” wystarczy do postów (szybki i tani).'));
		var ai = h('input', { type: 'checkbox', checked: +v.ai_images ? true : null, onchange: function () { v.ai_images = ai.checked ? 1 : 0; K.dirty(); } });
		g.appendChild(h('label', { class: 'rp-check' }, [ai, h('span', { text: 'AI widzi zdjęcia (wolniej i drożej; zwykle wystarczą nazwy i opisy dań)' })]));
		var instr = h('textarea', { class: 'rp-in', rows: '10', oninput: function () { v.instructions = instr.value; K.dirty(); } });
		instr.value = v.instructions;
		g.appendChild(K.field('Zasady wspólne (styl, zasady)', instr, 'Idą do AI przy KAŻDYM poście – zestaw, produkt i dowolny temat. Każda linia to jedna zasada. Co dotyczy tylko obiadu dnia, wpisz niżej w „O czym jest post” → Zestaw dnia.'));
		if (d.instrWarn) { g.appendChild(h('div', { class: 'rp-warn' }, [h('span', { text: d.instrWarn })])); }
		v.about = v.about || {};
		g.appendChild(h('h3', { text: 'O czym jest post' }));
		g.appendChild(h('p', { class: 'rp-muted', text: 'Do AI idzie tylko opis rodzaju, który tworzysz – dzięki temu post o rogalach nie dostaje poleceń o obiedzie dnia.' }));
		Object.keys(d.kinds).forEach(function (k) {
			var ta = h('textarea', { class: 'rp-in', rows: '2', 'aria-label': 'O czym jest post – ' + d.kinds[k], oninput: function () { v.about[k] = ta.value; K.dirty(); } });
			ta.value = v.about[k] || '';
			g.appendChild(K.field(d.kinds[k], ta));
		});
		main.appendChild(g);

		// Sekcje
		var sc = h('section', { class: 'rp-card' }, [h('h2', { text: 'Sekcje posta' }), h('p', { class: 'rp-muted', text: 'W tej kolejności. „Odstęp nad / pod” – puste linie między sekcjami; między dwiema sekcjami liczy się większa z wartości (np. pod Wstępem 1, nad Menu 2 → 2 puste linie), 0 – następna sekcja od nowej linii. „Pisze AI” – Gemini pisze sekcję; w polu pod spodem możesz dać mu wskazówki tylko do tej sekcji. „Stały tekst” – doklejany bez AI (możesz użyć {zestaw}, {dzien}, {dania}). Odznaczona sekcja nie idzie do AI i nie pojawia się w poście. „W postach” – w jakich rodzajach postów jest sekcja (np. Menu tylko w zestawie).' })]);
		v.sections.forEach(function (sec, i) {
			var name = h('input', { class: 'rp-in rp-in-m', value: sec.n, 'aria-label': 'Nazwa sekcji', oninput: function () { sec.n = name.value; K.dirty(); layout(); } });
			var mode = h('select', { class: 'rp-in rp-in-m', 'aria-label': 'Kto pisze', onchange: function () { sec.m = mode.value; K.dirty(); K.render(); } }, [h('option', { value: 'ai', text: 'Pisze AI', selected: sec.m === 'ai' ? true : null }), h('option', { value: 'static', text: 'Stały tekst', selected: sec.m === 'static' ? true : null })]);
			var on = h('input', { type: 'checkbox', 'aria-label': 'Sekcja ' + sec.n + ' aktywna', checked: +sec.on !== 0 ? true : null, onchange: function () { sec.on = on.checked ? 1 : 0; K.dirty(); row.classList.toggle('rp-psec-off', !on.checked); } });
			var row = h('div', { class: 'rp-psec' + (+sec.on === 0 ? ' rp-psec-off' : '') }, [
				h('div', { class: 'rp-inline' }, [h('strong', { text: (i + 1) + '.' }), h('label', { class: 'rp-check rp-psec-on', title: 'Aktywna' }, [on, h('span', { text: 'Aktywna' })]), name, mode,
					i ? h('button', { type: 'button', class: 'rp-ico', 'aria-label': 'Wyżej', text: '↑', onclick: function () { v.sections.splice(i - 1, 0, v.sections.splice(i, 1)[0]); K.dirty(); K.render(); } }) : null,
					h('button', { type: 'button', class: 'rp-ico', 'aria-label': 'Usuń sekcję ' + sec.n, html: K.ICON.x, onclick: function () { v.sections.splice(i, 1); K.dirty(); K.render(); } })])
			]);
			sec.ty = sec.ty || Object.keys(d.kinds);
			row.appendChild(h('div', { class: 'rp-inline rp-psec-ty' }, [h('span', { class: 'rp-muted', text: 'W postach:' })].concat(Object.keys(d.kinds).map(function (k) {
				var c = h('input', { type: 'checkbox', 'aria-label': sec.n + ' – ' + d.kinds[k], checked: sec.ty.indexOf(k) > -1 ? true : null, onchange: function () { sec.ty = Object.keys(d.kinds).filter(function (x) { return x === k ? c.checked : sec.ty.indexOf(x) > -1; }); K.dirty(); } });
				var lb = h('label', { class: 'rp-check' }, [c, h('span', { text: d.kinds[k] })]);
				c.addEventListener('change', layout);
				return lb;
			}))));
			function gapSel(key, label, def) {
				var cur = sec[key] == null ? def : +sec[key];
				var sel = h('select', { class: 'rp-in rp-in-s', 'aria-label': label + ' – ' + sec.n, onchange: function () { sec[key] = +sel.value; K.dirty(); layout(); } }, [0, 1, 2, 3].map(function (n) {
					return h('option', { value: String(n), text: n === 0 ? '0' : n + (n === 1 ? ' linia' : ' linie'), selected: n === cur ? true : null });
				}));
				return h('label', { class: 'rp-check' }, [h('span', { class: 'rp-muted', text: label + ':' }), sel]);
			}
			row.appendChild(h('div', { class: 'rp-inline rp-psec-ty' }, [gapSel('sb', 'Odstęp nad', 0), gapSel('sa', 'Odstęp pod', 1)]));
			on.addEventListener('change', layout);
			if (sec.m === 'static') {
				var t = h('textarea', { class: 'rp-in', rows: '3', 'aria-label': 'Tekst sekcji ' + sec.n, oninput: function () { sec.t = t.value; K.dirty(); } });
				t.value = sec.t || '';
				row.appendChild(t);
				row.appendChild(h('p', { class: 'rp-muted rp-psec-help', text: 'Stały tekst – trafia do posta dokładnie tak, jak go wpiszesz.' }));
			} else {
				var hn = h('textarea', { class: 'rp-in', rows: '2', 'aria-label': 'Wskazówki dla AI – ' + sec.n, placeholder: 'np. krótko, maks. 8 słów, z emotką', oninput: function () { sec.h = hn.value; K.dirty(); } });
				hn.value = sec.h || '';
				row.appendChild(hn);
				row.appendChild(h('p', { class: 'rp-muted rp-psec-help', text: 'Wskazówki dla AI tylko do tej sekcji. Puste – AI pisze samo według ogólnych wskazówek.' }));
			}
			sc.appendChild(row);
		});
		sc.appendChild(K.btn('+ Sekcja', function () { v.sections.push({ k: '', n: 'Nowa sekcja', m: 'ai', t: '', h: '', on: 1, ty: Object.keys(d.kinds), sb: 0, sa: 1 }); K.dirty(); K.render(); }, 'rp-btn-link'));
		// Układ posta – podgląd odstępów (nazwy sekcji zamiast treści), ta sama reguła co rzd_posts_assemble()
		var lk = h('select', { class: 'rp-in rp-in-m', 'aria-label': 'Rodzaj posta w podglądzie układu', onchange: layout }, Object.keys(d.kinds).map(function (k) { return h('option', { value: k, text: d.kinds[k] }); }));
		var lbox = h('div', { class: 'rp-fb-text rp-psec-layout', 'aria-label': 'Układ posta' });
		sc.appendChild(h('h3', { text: 'Układ posta' }));
		sc.appendChild(h('div', { class: 'rp-inline' }, [h('span', { class: 'rp-muted', text: 'Rodzaj:' }), lk]));
		sc.appendChild(lbox);
		function layout() {
			var out = '', prev = null;
			v.sections.forEach(function (x) {
				if (+x.on === 0 || (x.ty || []).indexOf(lk.value) < 0) { return; }
				if (prev) { var g = Math.max(prev.sa == null ? 1 : +prev.sa, x.sb == null ? 0 : +x.sb); out += '\n' + (g ? new Array(g + 1).join('\n') : ''); }
				out += '[' + x.n + ']';
				prev = x;
			});
			lbox.textContent = out;
		}
		layout();
		main.appendChild(sc);

		// Facebook
		var fb = h('section', { class: 'rp-card' }, [h('h2', { text: 'Facebook' })]);
		fb.appendChild(K.field('ID strony', inp('fb_page', { inputmode: 'numeric', placeholder: 'np. 102345678901234' }), 'Strona → Informacje → Przejrzystość strony, albo z narzędzia Graph API Explorer.'));
		fb.appendChild(K.field('Token strony (długoterminowy)', inp('fb_token', { type: 'password', autocomplete: 'off', placeholder: d.tokConst ? 'ustawiony w wp-config.php' : (d.hasToken ? '•••••• zapisany – wpisz nowy, żeby zmienić („-” usuwa)' : 'wklej token strony') }), 'Token strony z uprawnieniami pages_manage_posts, pages_read_engagement, pages_show_list (aplikacja Meta for Developers). Możesz wkleić też token swojego konta – „Sprawdź połączenie” sam pobierze z niego token strony (z długoterminowego – bez wygasania). Zapisany zaszyfrowany.'));
		fb.appendChild(K.field('Lokalizacja do oznaczania (ID strony)', inp('place', { inputmode: 'numeric', placeholder: 'puste = Wasza strona (musi mieć adres)' }), 'Post dostaje „📍 w miejscu …”. Puste – lokalizacją jest Wasza strona; wpisz ID innej strony-miejsca, jeśli adres jest gdzie indziej. Gdy Facebook nie przyjmie lokalizacji, post wyjdzie bez niej.'));
		var pd = h('input', { type: 'checkbox', checked: +v.place_def ? true : null, onchange: function () { v.place_def = pd.checked ? 1 : 0; K.dirty(); } });
		fb.appendChild(h('label', { class: 'rp-check' }, [pd, h('span', { text: 'Nowe posty z lokalizacją (można odznaczyć przy poście)' })]));
		fb.appendChild(h('div', { class: 'rp-inline' }, [K.btn('Sprawdź połączenie', function (e) {
			if (S.dirty) { K.toast('Najpierw zapisz ustawienia.', true); return; }
			var b = e.currentTarget; K.busy(b, true);
			K.api('posts_fb_check', {}).then(function (x) { K.busy(b, false); K.toast(x.message); }, fail(b));
		})]));
		main.appendChild(fb);

		// Automat
		var au = h('section', { class: 'rp-card' }, [h('h2', { text: 'Godziny i automat' })]);
		au.appendChild(h('div', { class: 'rp-row2' }, [
			K.field('Szkic gotowy o', inp('gen_time', { type: 'time', class: 'rp-in rp-in-s' }), 'Automat przygotuje szkic na jutro, gdy go jeszcze nie ma.'),
			K.field('Publikacja o', inp('pub_time', { type: 'time', class: 'rp-in rp-in-s' }), 'Domyślna godzina publikacji (dzień przed obiadem). Zawsze po zatwierdzeniu.')
		]));
		var auto = h('input', { type: 'checkbox', checked: +v.auto ? true : null, onchange: function () { v.auto = auto.checked ? 1 : 0; K.dirty(); } });
		au.appendChild(h('label', { class: 'rp-check' }, [auto, h('span', { text: 'Automat: codziennie o godzinie szkicu przygotuj post na jutro (gdy go nie ma) i wyślij mail „zatwierdź”' })]));
		var diag = h('section', { class: 'rp-card' }, [h('h2', { text: 'Sprawdzenie AI' })]);
		var last = h('p', { class: 'rp-muted', text: d.lastCall ? 'Ostatnie zapytanie do Gemini: ' + d.lastCall : 'Jeszcze nie było zapytania do Gemini.' });
		diag.appendChild(last);
		diag.appendChild(h('div', { class: 'rp-inline' }, [K.btn('Test AI', function (e) {
			if (S.dirty) { K.toast('Najpierw zapisz ustawienia.', true); return; }
			var b = e.currentTarget; var done = aiBusy(b, 'Pytam Gemini');
			K.api('posts_ai_test', {}).then(function (x) { done(); K.toast(x.message); last.textContent = 'Ostatnie zapytanie do Gemini: ' + x.lastCall; }, function (er) { done(); K.toast(er.message, true); K.api('posts', {}).then(function (y) { last.textContent = y.lastCall ? 'Ostatnie zapytanie do Gemini: ' + y.lastCall : last.textContent; }); });
		})]));
		au.appendChild(K.field('Mail o szkicu do', inp('mail_to', { type: 'text', placeholder: 'puste = e-mail administratora; kilka – po przecinku' })));
		main.appendChild(au);
		main.appendChild(diag);

		main.appendChild(K.saveBar(function (b) {
			K.busy(b, true);
			K.api('posts_settings_save', { values: v }).then(function (x) { S.data.posts = x; S.work.pset = null; S.dirty = false; K.toast(x.message); K.render(); }, fail(b));
		}, 'Zapisz ustawienia postów'));
	}

	K.sections.posty = secPosts;
})();
