/* Restauracja – kod do wklejenia na dowolną stronę (2.59.0, moduł 42-api-strony). Użycie:
 *   <div data-rzd="zestaw" data-id="123"></div>   (albo data-rzd="zestawy" / "godziny" / "menu")
 *   <script src="https://SKLEP/wp-content/plugins/restauracja-zamowienia/assets/js/rzd-strona.js" defer></script>
 * Atrybuty jak w shortcodach: data-dzien, data-zdjecie, data-sklad, data-cena, data-przycisk, data-grupy,
 * data-kategoria, data-opis, data-alergeny, data-spis.
 * Adres sklepu – z adresu tego skryptu (albo data-sklep="https://…" przy elemencie). HTML przygotowuje sklep
 * (REST rzd/v1 ?html=1 – te same funkcje co shortcody), a styl dokłada się sam (rzd-strona.css). */
(function () {
	'use strict';
	var me = document.currentScript;
	var base = me && me.src ? me.src.split('/wp-content/')[0] : '';
	var cssDone = false;
	var ATTR = ['dzien', 'zdjecie', 'sklad', 'cena', 'przycisk', 'grupy', 'kategoria', 'opis', 'alergeny', 'spis'];
	function css(url) {
		if (cssDone || !url || document.querySelector('link[data-rzd-css]')) { cssDone = true; return; }
		var l = document.createElement('link');
		l.rel = 'stylesheet'; l.href = url; l.setAttribute('data-rzd-css', '1');
		document.head.appendChild(l); cssDone = true;
	}
	function one(el) {
		var kind = el.getAttribute('data-rzd');
		var route = kind === 'menu' ? '/rzd/v1/menu' : kind === 'godziny' ? '/rzd/v1/godziny' : (kind === 'zestawy' ? '/rzd/v1/zestawy' : (el.getAttribute('data-id') ? '/rzd/v1/zestaw/' + parseInt(el.getAttribute('data-id'), 10) : '/rzd/v1/zestawy'));
		var shop = (el.getAttribute('data-sklep') || base).replace(/\/+$/, '');
		var q = ['rest_route=' + encodeURIComponent(route), 'html=1'];
		ATTR.forEach(function (a) { var v = el.getAttribute('data-' + a); if (v !== null) { q.push(a + '=' + encodeURIComponent(v)); } });
		el.setAttribute('aria-busy', 'true');
		fetch(shop + '/?' + q.join('&'), { credentials: 'omit' }).then(function (r) { return r.ok ? r.json() : Promise.reject(r.status); }).then(function (d) {
			css(d.css);
			var html = d.html || '';
			// [rzd_zestaw] bez id – pierwszy z listy
			if (kind === 'zestaw' && !el.getAttribute('data-id') && d.sets) {
				var t = document.createElement('div'); t.innerHTML = html;
				var first = t.querySelector('.rzd-s-set'); html = first ? first.outerHTML : '';
			}
			el.innerHTML = html; // HTML przygotowany i oczyszczony po stronie sklepu
			el.removeAttribute('aria-busy');
		}).catch(function () { el.removeAttribute('aria-busy'); });
	}
	function run() { Array.prototype.forEach.call(document.querySelectorAll('[data-rzd]:not([data-rzd-done])'), function (el) { el.setAttribute('data-rzd-done', '1'); one(el); }); }
	if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', run); } else { run(); }
	window.rzdStrona = { odswiez: function () { Array.prototype.forEach.call(document.querySelectorAll('[data-rzd-done]'), function (el) { el.removeAttribute('data-rzd-done'); }); run(); } };
})();
