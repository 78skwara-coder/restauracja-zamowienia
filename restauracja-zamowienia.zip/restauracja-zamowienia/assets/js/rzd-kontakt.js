/* Restauracja – Zamówienia i Dostawy: formularze kontaktowe [rzd_kontakt] (moduł 30).
 * Wysyłka bez przeładowania (fetch → admin-ajax.php, akcja rzd_kf_send); bez JavaScriptu formularz wysyła się zwykle.
 * Etykiety w polu: klasa is-filled (gdy przeglądarka nie zna :has). */
(function () {
	'use strict';
	var cfg = window.rzdKf || {};

	function filled(field) {
		var c = field.querySelector('.rzd-kf-input');
		if (c) { field.classList.toggle('is-filled', c.value !== ''); }
	}
	function setErr(field, msg) {
		var e = field.querySelector('.rzd-kf-err'), inp = field.querySelectorAll('.rzd-kf-input, .rzd-kf-box');
		field.classList.toggle('rzd-kf-has-err', !!msg);
		if (e) { e.textContent = msg || ''; e.hidden = !msg; }
		Array.prototype.forEach.call(inp, function (i) {
			if (msg) { i.setAttribute('aria-invalid', 'true'); } else { i.removeAttribute('aria-invalid'); }
			var d = (i.getAttribute('aria-describedby') || '').split(' ').filter(Boolean), id = e ? e.id : '';
			if (id && msg && d.indexOf(id) === -1) { d.push(id); }
			if (id && !msg) { d = d.filter(function (x) { return x !== id; }); }
			if (d.length) { i.setAttribute('aria-describedby', d.join(' ')); } else { i.removeAttribute('aria-describedby'); }
		});
	}
	function resetCaptcha(box) {
		try {
			if (box.querySelector('.cf-turnstile') && window.turnstile) { window.turnstile.reset(box.querySelector('.cf-turnstile')); }
			if (box.querySelector('.h-captcha') && window.hcaptcha) { window.hcaptcha.reset(); }
		} catch (e) { /* captcha sama się odświeży */ }
	}

	function init(box) {
		var form = box.querySelector('form.rzd-kf-form');
		if (!form || form.getAttribute('data-ready')) { return; }
		form.setAttribute('data-ready', '1');
		Array.prototype.forEach.call(box.querySelectorAll('.rzd-kf-field'), function (f) {
			filled(f);
			f.addEventListener('input', function () { filled(f); if (f.classList.contains('rzd-kf-has-err')) { setErr(f, ''); } });
			f.addEventListener('change', function () { filled(f); if (f.classList.contains('rzd-kf-has-err')) { setErr(f, ''); } });
		});
		if (!window.fetch || !window.FormData || form.getAttribute('onsubmit')) { return; } // podgląd w panelu / stara przeglądarka
		form.addEventListener('submit', function (ev) {
			ev.preventDefault();
			var btn = form.querySelector('.rzd-kf-btn'), alert = form.querySelector('.rzd-kf-alert'), label = btn.textContent;
			btn.disabled = true; btn.textContent = cfg.sending || '…';
			var data = new FormData(form);
			data.append('action', 'rzd_kf_send');
			fetch(cfg.ajax, { method: 'POST', body: data, credentials: 'same-origin' })
				.then(function (r) { return r.json(); })
				.then(function (res) {
					var d = res && res.data ? res.data : {};
					Array.prototype.forEach.call(box.querySelectorAll('.rzd-kf-field[data-key]'), function (f) { setErr(f, ''); });
					if (res && res.success) {
						if (d.redirect) { window.location.href = d.redirect; return; }
						var ok = document.createElement('div');
						ok.className = 'rzd-kf-success'; ok.setAttribute('role', 'status'); ok.tabIndex = -1;
						ok.textContent = d.message || '';
						form.parentNode.replaceChild(ok, form);
						ok.focus();
						return;
					}
					var errs = d.errors || {}, first = null;
					Object.keys(errs).forEach(function (k) {
						if (k === '_form') { return; }
						var f = box.querySelector('.rzd-kf-field[data-key="' + k + '"]');
						if (f) { setErr(f, errs[k]); if (!first) { first = f; } }
					});
					alert.textContent = errs._form || d.message || 'Popraw zaznaczone pola.';
					alert.hidden = false;
					resetCaptcha(box);
					var focus = first ? first.querySelector('input, select, textarea') : alert;
					if (focus) { if (!first) { alert.tabIndex = -1; } focus.focus(); }
				})
				.catch(function () {
					alert.textContent = cfg.error || 'Błąd'; alert.hidden = false;
				})
				.then(function () { btn.disabled = false; btn.textContent = label; });
		});
	}

	function all() { Array.prototype.forEach.call(document.querySelectorAll('.rzd-kf'), init); }
	if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', all); } else { all(); }
	window.rzdKfInit = all; // podgląd w panelu wywołuje po odświeżeniu
})();
