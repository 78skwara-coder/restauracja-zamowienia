/* Restauracja – Zamówienia i Dostawy: rzd-kalendarz-okna.js (z 06-delivery-calendar.php) */
(function () {
	var body = document.getElementById('dc-win-body');
	if (!body) { return; }
	var next = body.querySelectorAll('tr').length + 1000;
	document.getElementById('dc-win-add').addEventListener('click', function () {
		body.insertAdjacentHTML('beforeend', document.getElementById('dc-win-tpl').innerHTML.replace(/__i__/g, String(next++)));
	});
	body.addEventListener('click', function (e) {
		if (e.target.classList.contains('dc-win-del')) {
			if (!e.target.closest('tr').querySelector('input[type=hidden]').value || confirm('Usunąć okno? Zniknie też z dni tygodnia.')) { e.target.closest('tr').remove(); }
		}
	});
	body.addEventListener('input', function (e) {
		var tr = e.target.closest('tr'); if (!tr) { return; }
		var len = parseInt(tr.querySelector('.dc-win-len').value, 10) || 0, cap = parseInt(tr.querySelector('.dc-win-cap').value, 10) || 0;
		tr.querySelector('.dc-win-step').textContent = (len && cap) ? (Math.round(len / cap * 10) / 10) + ' min' : '–';
	});
})();
