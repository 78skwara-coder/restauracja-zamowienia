/* Restauracja – Zamówienia i Dostawy: rzd-zestawy-strona.js (z 11-zestawy-menu.php) */
jQuery(function ($) {
	var nextSlot = rzdZestawNext;
	var $slots = $('#rwz-slots');

	$(document).on('click', '.rwz-add-slot-btn', function (e) {
		e.preventDefault();
		$slots.prepend($('#rwz-slot-template').html().split('__SLOT__').join(nextSlot)); // nowy termin na górze
		nextSlot++;
		$(document.body).trigger('wc-enhanced-select-init');
		$('html, body').animate({ scrollTop: Math.max(0, $slots.offset().top - 110) }, 150);
	});
	$slots.on('click', '.rwz-add-item', function (e) {
		e.preventDefault();
		var $slot = $(this).closest('.rwz-slot');
		var slotIdx = $slot.attr('data-slot');
		var itemIdx = parseInt($slot.attr('data-next-item'), 10) || 0;
		var tpl = $('#rwz-item-template').html().split('__SLOT__').join(slotIdx).split('__ITEM__').join(itemIdx);
		$slot.find('.rwz-items').first().append(tpl);
		$slot.attr('data-next-item', itemIdx + 1);
		$(document.body).trigger('wc-enhanced-select-init');
	});
	$slots.on('click', '.rwz-remove-item', function (e) { e.preventDefault(); $(this).closest('.rwz-item').remove(); });
	$slots.on('click', '.rwz-remove-slot', function (e) { e.preventDefault(); $(this).closest('.rwz-slot').remove(); });
});
