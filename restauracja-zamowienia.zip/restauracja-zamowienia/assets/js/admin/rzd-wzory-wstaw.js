/* Restauracja – Zamówienia i Dostawy: rzd-wzory-wstaw.js (z 18-wzory-modyfikacji.php) */
jQuery(function ($) {
	$('#rzd-add-preset').on('click', function (e) {
		e.preventDefault();
		var id = $('#rzd-preset-select').val();
		var $tpl = $('#rzd-preset-tpl-' + id);
		if (!$tpl.length) { return; }
		var $sections = $('#rzd-sections');
		var n = parseInt($sections.attr('data-next'), 10) || 0;
		var count = parseInt($tpl.attr('data-count'), 10) || 0;
		var html = $tpl.html();
		// od najwyższego numeru w dół – żeby __P1__ nie złapało kawałka __P10__
		for (var k = count - 1; k >= 0; k--) {
			html = html.split('__P' + k + '__').join(n + k);
		}
		var $added = $($.parseHTML(html)).filter('.rzd-section');
		$sections.append($added);
		$sections.attr('data-next', n + count);
		$added.css('outline', '3px solid #72aee6');
		setTimeout(function () { $added.css('outline', ''); }, 1500);
		if ($added.length && $added[0].scrollIntoView) { $added[0].scrollIntoView({ behavior: 'smooth', block: 'center' }); }
	});
});
