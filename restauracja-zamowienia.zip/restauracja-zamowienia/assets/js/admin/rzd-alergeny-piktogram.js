/* Restauracja – Zamówienia i Dostawy: rzd-alergeny-piktogram.js (z 01-alergeny.php) */
jQuery(function ($) {
	$(document).on('click', '.rest-icon-pick', function (e) {
		e.preventDefault();
		var wrap = $(this).closest('.rest-icon-field');
		var frame = wp.media({ title: 'Wybierz piktogram', button: { text: 'Użyj' }, multiple: false, library: { type: 'image' } });
		frame.on('select', function () {
			var a = frame.state().get('selection').first().toJSON();
			var url = (a.sizes && a.sizes.thumbnail) ? a.sizes.thumbnail.url : a.url;
			wrap.find('input[type=hidden]').val(a.id);
			wrap.find('.rest-icon-preview').html('<img src="' + url + '" style="width:40px;height:40px;object-fit:contain">');
		});
		frame.open();
	});
	$(document).on('click', '.rest-icon-remove', function (e) {
		e.preventDefault();
		var wrap = $(this).closest('.rest-icon-field');
		wrap.find('input[type=hidden]').val('');
		wrap.find('.rest-icon-preview').empty();
	});
	// po dodaniu alergenu (AJAX) wyczyść pole piktogramu
	$(document).ajaxComplete(function (e, xhr, s) {
		if (s.data && s.data.indexOf('action=add-tag') > -1) {
			$('.rest-icon-field input[type=hidden]').val('');
			$('.rest-icon-preview').empty();
		}
	});
});
