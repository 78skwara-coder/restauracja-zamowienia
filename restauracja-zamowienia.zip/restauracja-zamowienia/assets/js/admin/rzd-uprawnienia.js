/* Restauracja – Zamówienia i Dostawy: rzd-uprawnienia.js (z 26-uprawnienia.php) */
(function () {
	var t = document.querySelector('.rzd-perm-table'), note = document.getElementById('rzd-perm-dep');
	if (!t) { return; }
	t.addEventListener('change', function (e) {
		var c = e.target;
		if (!c.classList || !c.classList.contains('rzd-pc')) { return; }
		var row = c.closest('tr'), shop = row.querySelector('.rzd-pc[data-k="shop"]'), msg = '';
		if (c.checked && c.getAttribute('data-needs-shop') === '1' && shop && !shop.checked) {
			shop.checked = true;
			msg = 'Zaznaczono też „Panel WP” – to uprawnienie działa tylko w kokpicie WordPressa.';
		}
		if (c === shop && !c.checked) {
			var off = [];
			row.querySelectorAll('.rzd-pc[data-needs-shop="1"]').forEach(function (x) { if (x.checked) { x.checked = false; off.push(x.getAttribute('aria-label').split(' – ').pop()); } });
			if (off.length) { msg = 'Bez „Panelu WP” odznaczono też: ' + off.join(', ') + '.'; }
		}
		note.hidden = !msg;
		note.textContent = msg;
	});
})();
