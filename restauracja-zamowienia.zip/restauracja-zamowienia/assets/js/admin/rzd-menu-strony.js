/* Restauracja – Zamówienia i Dostawy: rzd-menu-strony.js (z 31-menu-strony/03-panel.php)
 * Edytor menu: płaska lista z poziomami (depth). Przeciąganie (jQuery UI + dotyk) – pozycja przenosi się razem z podmenu,
 * przesunięcie w prawo/lewo zmienia poziom. Klawiatura na ☰: ↑ ↓ przesuwa, ← → poziom. Zapis = JSON w ukrytym polu. */
(function ($) {
	'use strict';
	var C = window.rzdNav || {}, MAX = +C.max || 2, STEP = 28;
	var $list = $('#rzd-nav-list'), $tree = $('#rzd-nav-tree');
	if (!$list.length) { return; }
	var items = [];
	try { items = JSON.parse($tree.val() || '[]'); } catch (e) { items = []; }
	var initial = JSON.stringify(items), open = {}, dirty = false;
	var esc = function (s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;'); }; // też w atrybutach

	function normalize() {
		items.forEach(function (it, k) {
			var max = k === 0 ? 0 : Math.min(MAX, items[k - 1].depth + 1);
			it.depth = Math.max(0, Math.min(+it.depth || 0, max));
		});
	}
	function blockEnd(i) { var j = i; while (j + 1 < items.length && items[j + 1].depth > items[i].depth) { j++; } return j; }
	function changed() {
		normalize();
		var now = JSON.stringify(items);
		$tree.val(now);
		dirty = now !== initial;
		$('#rzd-nav-undo').prop('disabled', !dirty);
		$('#rzd-nav-state').text(dirty ? '● niezapisane zmiany' : '');
		$('#rzd-nav-empty').prop('hidden', items.length > 0);
	}
	function badges(it) {
		var b = [];
		if (it.cta) { b.push('przycisk'); }
		if (it.vis_user === 'in') { b.push('tylko zalogowani'); }
		if (it.vis_user === 'out') { b.push('tylko goście'); }
		if (it.vis_dev === 'mobile') { b.push('tylko telefon'); }
		if (it.vis_dev === 'desktop') { b.push('tylko komputer'); }
		if (it.blank) { b.push('nowa karta'); }
		return b.map(function (x) { return '<span class="rzd-nav-badge">' + esc(x) + '</span>'; }).join('');
	}
	function rowHtml(it, i) {
		var isBlock = it.type === 'block', custom = it.type === 'custom';
		var h = '<li class="rzd-nav-item' + (isBlock ? ' rzd-nav-isblock' : '') + '" data-i="' + i + '" style="margin-left:' + (it.depth * STEP) + 'px">' +
			'<div class="rzd-nav-row">' +
			'<span class="rzd-nav-handle" tabindex="0" role="button" aria-label="Przesuń: ' + esc(it.label) + ' (strzałki)" title="Przeciągnij albo użyj strzałek">☰</span>' +
			(isBlock ? '<span class="rzd-nav-blocklabel">' + esc(it.label) + '</span>' : '<input type="text" class="rzd-nav-label" value="' + esc(it.label) + '" aria-label="Nazwa pozycji">') +
			'<span class="rzd-nav-desc">' + esc(it.desc || (custom ? 'Link' : '')) + (it.depth ? ' · podmenu' : '') + ' ' + badges(it) + '</span>' +
			(isBlock ? '' : '<button type="button" class="button-link rzd-nav-gear" aria-expanded="' + (open[i] ? 'true' : 'false') + '" title="Ustawienia pozycji" aria-label="Ustawienia pozycji">⚙</button>') +
			'<button type="button" class="button-link button-link-delete rzd-nav-del" title="Usuń z menu" aria-label="Usuń z menu">✕</button>' +
			'</div>';
		if (open[i] && !isBlock) {
			h += '<div class="rzd-nav-details">' +
				(custom ? '<label>Adres<input type="text" data-k="url" value="' + esc(it.url) + '"></label>'
					: '<p class="rzd-nav-url">Prowadzi do: ' + (it.url ? '<a href="' + esc(it.url) + '" target="_blank" rel="noopener">' + esc(it.url) + '</a>' : '–') + '</p>') +
				'<label class="rzd-nav-chk"><input type="checkbox" data-k="blank"' + (it.blank ? ' checked' : '') + '> otwieraj w nowej karcie</label>' +
				'<label class="rzd-nav-chk"><input type="checkbox" data-k="cta"' + (it.cta ? ' checked' : '') + '> wyróżnij jako przycisk (kolor akcentu)</label>' +
				'<label>Kto widzi<select data-k="vis_user"><option value="">wszyscy</option><option value="in"' + (it.vis_user === 'in' ? ' selected' : '') + '>tylko zalogowani</option><option value="out"' + (it.vis_user === 'out' ? ' selected' : '') + '>tylko goście (niezalogowani)</option></select></label>' +
				'<label>Na jakim ekranie<select data-k="vis_dev"><option value="">telefon i komputer</option><option value="mobile"' + (it.vis_dev === 'mobile' ? ' selected' : '') + '>tylko telefon</option><option value="desktop"' + (it.vis_dev === 'desktop' ? ' selected' : '') + '>tylko komputer</option></select></label>' +
				'<label>Klasy CSS (dla zaawansowanych)<input type="text" data-k="classes" value="' + esc(it.classes) + '"></label>' +
				'</div>';
		}
		return h + '</li>';
	}
	function render(focusIdx, focusSel) {
		$list.html(items.map(rowHtml).join(''));
		changed();
		if (focusIdx != null && focusIdx >= 0) { $list.children().eq(focusIdx).find(focusSel || '.rzd-nav-handle').trigger('focus'); }
	}

	// --- przeciąganie: pozycja razem z podmenu, poziom z przesunięcia w poziomie ---
	var dragKids = $(), dragFrom = 0, dropDepth = null;
	$list.sortable({
		handle: '.rzd-nav-handle', items: '> li', placeholder: 'rzd-nav-ph', tolerance: 'pointer', distance: 4,
		start: function (e, ui) {
			var i = +ui.item.data('i'), j = blockEnd(i);
			dragFrom = items[i].depth; dropDepth = null;
			dragKids = $list.children('li').filter(function () { var k = +$(this).data('i'); return k > i && k <= j; });
			dragKids.hide();
			ui.placeholder.css('margin-left', ui.item.css('margin-left')).height(ui.item.outerHeight());
		},
		sort: function (e, ui) {
			var d = Math.max(0, Math.min(MAX, dragFrom + Math.round((ui.position.left - ui.originalPosition.left) / STEP)));
			var $prev = ui.placeholder.prevAll('li:visible').not(ui.item).first();
			var maxD = $prev.length ? items[+$prev.data('i')].depth + 1 : 0;
			dropDepth = Math.min(d, maxD, MAX);
			ui.placeholder.css('margin-left', dropDepth * STEP + 'px');
		},
		stop: function (e, ui) {
			dragKids.insertAfter(ui.item).show();
			var i = +ui.item.data('i'), delta = (dropDepth == null ? dragFrom : dropDepth) - dragFrom;
			var moved = [i].concat(dragKids.map(function () { return +$(this).data('i'); }).get());
			moved.forEach(function (k) { items[k].depth = Math.max(0, Math.min(MAX, items[k].depth + delta)); });
			var order = $list.children('li').map(function () { return +$(this).data('i'); }).get(), o2 = {};
			items = order.map(function (k, n) { if (open[k]) { o2[n] = 1; } return items[k]; });
			open = o2; dragKids = $();
			render(order.indexOf(i));
		}
	});

	// --- klawiatura ---
	$list.on('keydown', '.rzd-nav-handle', function (e) {
		var i = +$(this).closest('li').data('i'), j = blockEnd(i), blk, k;
		if (e.key === 'ArrowUp' && i > 0) {
			blk = items.splice(i, j - i + 1);
			k = i - 1; while (k > 0 && items[k].depth > blk[0].depth) { k--; }
			items.splice.apply(items, [k, 0].concat(blk)); open = {}; render(k); e.preventDefault();
		} else if (e.key === 'ArrowDown' && j + 1 < items.length) {
			blk = items.splice(i, j - i + 1);
			k = blockEnd(i) + 1;
			items.splice.apply(items, [k, 0].concat(blk)); open = {}; render(k); e.preventDefault();
		} else if (e.key === 'ArrowRight' && i > 0 && items[i].depth < Math.min(MAX, items[i - 1].depth + 1)) {
			for (k = i; k <= j; k++) { items[k].depth = Math.min(MAX, items[k].depth + 1); }
			render(i); e.preventDefault();
		} else if (e.key === 'ArrowLeft' && items[i].depth > 0) {
			for (k = i; k <= j; k++) { items[k].depth = Math.max(0, items[k].depth - 1); }
			render(i); e.preventDefault();
		}
	});

	// --- edycja ---
	$list.on('input', '.rzd-nav-label', function () { items[+$(this).closest('li').data('i')].label = this.value; changed(); });
	$list.on('click', '.rzd-nav-gear', function () { var i = +$(this).closest('li').data('i'); open[i] = !open[i]; render(i, '.rzd-nav-gear'); });
	$list.on('click', '.rzd-nav-del', function () {
		var i = +$(this).closest('li').data('i'), j = blockEnd(i), n = j - i;
		if (n > 0 && !window.confirm('Usunąć „' + items[i].label + '” razem z podmenu (' + n + ')?')) { return; }
		items.splice(i, j - i + 1); open = {}; render(Math.min(i, items.length - 1));
	});
	$list.on('input change', '[data-k]', function () {
		var $e = $(this), i = +$e.closest('li').data('i'), k = $e.data('k');
		items[i][k] = $e.is(':checkbox') ? ($e.is(':checked') ? 1 : 0) : $e.val();
		if ($e.is('select, :checkbox')) { render(i, '[data-k="' + k + '"]'); } else { changed(); }
	});

	// --- dodawanie ---
	function add(it) {
		it = $.extend({ id: '', depth: 0, blank: 0, cta: 0, vis_user: '', vis_dev: '', classes: '' }, it);
		items.push(it); render(items.length - 1);
		var $li = $list.children().last(); $li.addClass('rzd-nav-new'); setTimeout(function () { $li.removeClass('rzd-nav-new'); }, 1200);
		$('#rzd-nav-state').text('Dodano „' + it.label + '” na koniec menu ● niezapisane zmiany');
	}
	$(document).on('click', '.rzd-nav-addbtn', function () { add($(this).data('item')); });
	$('#rzd-nav-cl-add').on('click', function () {
		var l = $.trim($('#rzd-nav-cl-label').val()), u = $.trim($('#rzd-nav-cl-url').val());
		if (!l && !u) { $('#rzd-nav-cl-label').trigger('focus'); return; }
		add({ type: 'custom', object: 'custom', object_id: 0, label: l || u, url: u, desc: 'Link' });
		$('#rzd-nav-cl-label, #rzd-nav-cl-url').val('');
	});
	$('#rzd-nav-tel-add').on('click', function () {
		var t = $.trim($('#rzd-nav-tel').val()).replace(/[^0-9+]/g, '');
		if (t.length < 7) { $('#rzd-nav-tel').trigger('focus'); return; }
		add({ type: 'custom', object: 'custom', object_id: 0, label: 'Zadzwoń', url: 'tel:' + t, desc: 'Link' });
		$('#rzd-nav-tel').val('');
	});
	var timer = null, $res = $('#rzd-nav-results'), seq = 0;
	function search() {
		var my = ++seq; // odpowiedź na starsze zapytanie (wolniejsza) nie nadpisze nowszej
		$res.html('<p class="description">szukam…</p>');
		$.post(C.ajax, { action: 'rzd_nav_search', _ajax_nonce: C.nonce, q: $('#rzd-nav-q').val() }).done(function (r) {
			if (my !== seq) { return; }
			if (!r || !r.success) { $res.html('<p class="description">Błąd – odśwież stronę.</p>'); return; }
			if (!r.data.length) { $res.html('<p class="description">Nic nie znaleziono.</p>'); return; }
			$res.html(r.data.map(function (g) {
				return '<h4>' + esc(g.group) + '</h4><ul>' + g.items.map(function (it) {
					return '<li><button type="button" class="button-link rzd-nav-addbtn" data-item="' + esc(JSON.stringify(it)) + '">+ ' + esc(it.label) + '</button></li>';
				}).join('') + '</ul>';
			}).join(''));
		});
	}
	$('#rzd-nav-q').on('input', function () { clearTimeout(timer); timer = setTimeout(search, 300); });

	// --- zapis / cofnięcie ---
	$('#rzd-nav-undo').on('click', function () {
		if (!window.confirm('Cofnąć wszystkie niezapisane zmiany?')) { return; }
		items = JSON.parse(initial); open = {}; render();
	});
	$('#rzd-nav-form').on('submit', function () { $tree.val(JSON.stringify(items)); dirty = false; });
	$('#rzd-nav-form input[name=menu_name], #rzd-nav-form input[name="locations[]"]').on('input change', function () { dirty = true; $('#rzd-nav-state').text('● niezapisane zmiany'); });
	$(window).on('beforeunload', function (e) { if (dirty) { e.preventDefault(); e.returnValue = ''; return ''; } });

	render(); search();
})(jQuery);
