/* Restauracja – Zamówienia i Dostawy: rzd-zestaw-produkt.js (z 04-zestaw-dnia.php) */
jQuery(function ($) {
	var nextSlot = rzdZestawNext;
	var $slots = $('#rwz-slots');

	$('#rwz-add-slot').on('click', function (e) {
		e.preventDefault();
		var tpl = $('#rwz-slot-template').html().split('__SLOT__').join(nextSlot);
		$slots.prepend(tpl); // nowy termin na górze
		nextSlot++;
	});

	$slots.on('click', '.rwz-add-item', function (e) {
		e.preventDefault();
		var $slot = $(this).closest('.rwz-slot');
		var slotIdx = $slot.attr('data-slot');
		var itemIdx = parseInt($slot.attr('data-next-item'), 10) || 0;
		var tpl = $('#rwz-item-template').html()
			.split('__SLOT__').join(slotIdx)
			.split('__ITEM__').join(itemIdx);
		$slot.find('.rwz-items').first().append(tpl);
		$slot.attr('data-next-item', itemIdx + 1);
		// zainicjuj select2 na nowo dodanym polu wyszukiwania produktu
		$(document.body).trigger('wc-enhanced-select-init');
	});

	$slots.on('click', '.rwz-remove-item', function (e) {
		e.preventDefault();
		$(this).closest('.rwz-item').remove();
	});

	$slots.on('click', '.rwz-remove-slot', function (e) {
		e.preventDefault();
		$(this).closest('.rwz-slot').remove();
	});
});
