/* Restauracja – Zamówienia i Dostawy: rzd-wyglad-panel.js (z 15-wyglad-listy.php) */
(function () {
	var wrap = document.querySelector('.rzd-style-wrap');
	var input = wrap.querySelector('input[name="rzd_view"]');

	function fit(frame) {
		var box = frame.parentNode, w = +frame.getAttribute('data-w');
		var avail = box.clientWidth || w, k = Math.min(1, avail / w);
		frame.style.width = w + 'px';
		var doc = frame.contentDocument;
		var h = doc && doc.documentElement ? doc.documentElement.scrollHeight : 900;
		frame.style.height = h + 'px';
		frame.style.transform = k < 1 ? 'scale(' + k + ')' : '';
		box.style.height = Math.ceil(h * k) + 'px';
	}
	function show(view) {
		wrap.setAttribute('data-view', view);
		input.value = view;
		wrap.querySelectorAll('.nav-tab').forEach(function (t) { t.classList.toggle('nav-tab-active', t.getAttribute('data-view') === view); });
		wrap.querySelectorAll('.rzd-pane, .rzd-prev').forEach(function (el) { el.hidden = el.getAttribute('data-view') !== view; });
		wrap.querySelectorAll('.rzd-prev:not([hidden]) iframe').forEach(fit);
	}
	wrap.querySelectorAll('.nav-tab').forEach(function (t) {
		t.addEventListener('click', function () { show(t.getAttribute('data-view')); });
	});
	wrap.querySelectorAll('iframe').forEach(function (f) {
		f.addEventListener('load', function () { if (!f.closest('.rzd-prev').hidden) { fit(f); } });
	});
	window.addEventListener('resize', function () { wrap.querySelectorAll('.rzd-prev:not([hidden]) iframe').forEach(fit); });

	// Sekcja telefonu bez „inaczej”: pola wyszarzone i wyłączone (nie idą
	// w zapisie – zapisane wcześniej wartości telefonu zostają na później).
	wrap.querySelectorAll('.rzd-mob-section').forEach(function (sec) {
		var cb = sec.querySelector('.rzd-mob-on');
		function sync() {
			sec.classList.toggle('rzd-mob-off', !cb.checked);
			sec.querySelectorAll('.rzd-mob-fields input, .rzd-mob-fields select').forEach(function (i) { i.disabled = !cb.checked; });
		}
		cb.addEventListener('change', sync);
		sync();
	});

	show(wrap.getAttribute('data-view'));
})();
