/* Restauracja – Zamówienia i Dostawy: rzd-poczta.js (z 27-poczta/04-panel.php)
 * – sposób wysyłki pokazuje tylko potrzebne pola (SMTP / klucz API / sekret / domena / region) i podpisuje je jak u dostawcy;
 * – wybór dostawcy SMTP uzupełnia serwer, port, szyfrowanie i stały login. */
(function () {
	var conns = document.querySelectorAll('table.rzd-mail-conn');
	Array.prototype.forEach.call(conns, function (tbl) {
		var type = tbl.querySelector('.rzd-mail-type'), tHint = tbl.querySelector('.rzd-mail-type-hint');
		var preset = tbl.querySelector('.rzd-mail-preset'), pHint = tbl.querySelector('.rzd-mail-preset-hint');
		var host = tbl.querySelector('.rzd-mail-host'), port = tbl.querySelector('.rzd-mail-port'),
			enc = tbl.querySelector('.rzd-mail-enc'), user = tbl.querySelector('.rzd-mail-user');
		var labels = { key: 'Klucz API', secret: 'Sekret' };

		function sync() {
			var o = type && type.options[type.selectedIndex], t = type ? type.value : '';
			var fields = o ? (o.getAttribute('data-fields') || '').split(',') : [];
			Array.prototype.forEach.call(tbl.querySelectorAll('tr[data-rzd-field]'), function (tr) {
				var f = tr.getAttribute('data-rzd-field'), only = tr.getAttribute('data-rzd-type');
				tr.style.display = (fields.indexOf(f) !== -1 && (!only || only === t)) ? '' : 'none';
			});
			['key', 'secret'].forEach(function (f) {
				var l = tbl.querySelector('[data-rzd-label="' + f + '"]');
				if (l && o) { l.textContent = o.getAttribute('data-' + f) || labels[f]; }
			});
			if (tHint) { tHint.textContent = o ? (o.getAttribute('data-hint') || '') : ''; }
		}
		if (type) { type.addEventListener('change', sync); sync(); }

		if (preset) {
			preset.addEventListener('change', function () {
				var o = preset.options[preset.selectedIndex];
				if (!o) { return; }
				if (host && !host.readOnly) { host.value = o.getAttribute('data-host') || ''; }
				if (port && !port.readOnly && o.getAttribute('data-port')) { port.value = o.getAttribute('data-port'); }
				if (enc && o.getAttribute('data-enc')) { enc.value = o.getAttribute('data-enc'); }
				if (user && !user.readOnly && o.getAttribute('data-user')) { user.value = o.getAttribute('data-user'); }
				if (pHint) { pHint.textContent = o.getAttribute('data-hint') || ''; }
				if (host && !host.value) { host.focus(); }
			});
		}
	});
})();
