/* Restauracja – Zamówienia i Dostawy: rzd-miejscowosci.js (z 20-miejscowosci.php) */
(function () {
	var body = document.getElementById('rzd-towns-body');
	var next = body.querySelectorAll('tr').length + 1000;
	document.getElementById('rzd-town-add').addEventListener('click', function () {
		var html = document.getElementById('rzd-town-tpl').innerHTML.replace(/__i__/g, String(next++));
		body.insertAdjacentHTML('beforeend', html);
	});
	body.addEventListener('click', function (e) {
		if (e.target.classList.contains('rzd-town-del')) { e.target.closest('tr').remove(); }
	});
})();
