/* Restauracja – Zamówienia i Dostawy: rzd-sklad.js (z 10-modyfikacje.php) */
jQuery(function ($) {
	// Skład: dodawanie/usuwanie wierszy
	var $skladRows = $('#rzd-sklad-rows');
	$('#rzd-add-sklad').on('click', function (e) {
		e.preventDefault();
		var i = parseInt($skladRows.attr('data-next'), 10) || 0;
		$skladRows.append($('#rzd-sklad-template').html().split('__I__').join(i));
		$skladRows.attr('data-next', i + 1);
	});
	$skladRows.on('click', '.rzd-remove-sklad', function (e) { e.preventDefault(); $(this).closest('.rzd-sklad-row').remove(); });
});
