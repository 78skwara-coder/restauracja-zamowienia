/* Restauracja – Zamówienia i Dostawy: rzd-koszyk-ustawienia.js (z 07-koszyk.php) */
jQuery(function ($) {
	$('#kc-image-field').on('click', '.kc-pick', function (e) {
		e.preventDefault();
		var wrap = $('#kc-image-field');
		var frame = wp.media({ title: 'Wybierz obrazek koszyka', button: { text: 'Użyj' }, multiple: false, library: { type: 'image' } });
		frame.on('select', function () {
			var a = frame.state().get('selection').first().toJSON();
			var url = (a.sizes && a.sizes.thumbnail) ? a.sizes.thumbnail.url : a.url;
			wrap.find('input[type=hidden]').val(a.id);
			wrap.find('.kc-image-preview').html('<img src="' + url + '" style="width:48px;height:48px;object-fit:contain">');
		});
		frame.open();
	});
	// ikonka pustego koszyka
	$('#kc-empty-icon-field').on('click', '.kc-empty-pick', function (e) {
		e.preventDefault();
		var wrap = $('#kc-empty-icon-field');
		var fr = wp.media({ title: 'Ikonka pustego koszyka', button: { text: 'Użyj' }, multiple: false, library: { type: 'image' } });
		fr.on('select', function () {
			var a = fr.state().get('selection').first().toJSON();
			var url = (a.sizes && a.sizes.thumbnail) ? a.sizes.thumbnail.url : a.url;
			wrap.find('input[name=kc_empty_icon_id]').val(a.id);
			wrap.find('.kc-empty-preview').html('<img src="' + url + '" style="width:64px;height:64px;object-fit:contain">');
			wrap.find('input[name=kc_empty_icon][value=image]').prop('checked', true);
		});
		fr.open();
	});
	$('#kc-empty-icon-field').on('click', '.kc-empty-remove', function (e) {
		e.preventDefault();
		$('#kc-empty-icon-field input[name=kc_empty_icon_id]').val('');
		$('#kc-empty-icon-field .kc-empty-preview').empty();
		$('#kc-empty-icon-field input[name=kc_empty_icon][value=default]').prop('checked', true);
	});
	$('#kc-image-field').on('click', '.kc-remove', function (e) {
		e.preventDefault();
		$('#kc-image-field input[type=hidden]').val('');
		$('#kc-image-field .kc-image-preview').empty();
	});
});
