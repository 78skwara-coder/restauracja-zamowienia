/* Restauracja – Zamówienia i Dostawy: rzd-kontakt-admin.js (z 30-kontakt/04-panel.php)
 * Kreator formularza: lista pól (dodaj, edytuj, przeciągnij, usuń) zapisywana jako JSON w ukrytym polu,
 * znaczniki do maili, wybór pola „Odpowiedz do”, podgląd na żywo (AJAX rzd_kf_preview), przyciski „Kopiuj”. */
(function ($) {
	'use strict';
	var A = window.rzdKfAdmin || {};

	// „Kopiuj” shortcode (lista i kreator)
	$(document).on('click', '.rzd-kf-copy', function () {
		var b = $(this), t = b.data('copy'), done = function () { b.text('Skopiowano ✓'); setTimeout(function () { b.text('Kopiuj'); }, 1500); };
		if (navigator.clipboard && window.isSecureContext) { navigator.clipboard.writeText(t).then(done); return; }
		var i = b.prev('input')[0]; if (i) { i.select(); try { document.execCommand('copy'); done(); } catch (e) { /* zaznaczone – Ctrl+C */ } }
	});

	var $form = $('#rzd-kfe-form');
	if (!$form.length) { return; }
	var $json = $('#rzd-kfe-json'), $list = $('#rzd-kfb-list');
	var fields = [];
	try { fields = JSON.parse($json.val() || '[]'); } catch (e) { fields = []; }
	var open = {};
	var hasOpts = function (t) { return (A.options || []).indexOf(t) !== -1; };
	var slug = function (s) {
		var map = { 'ą': 'a', 'ć': 'c', 'ę': 'e', 'ł': 'l', 'ń': 'n', 'ó': 'o', 'ś': 's', 'ź': 'z', 'ż': 'z' };
		s = String(s || '').toLowerCase().replace(/[ąćęłńóśźż]/g, function (c) { return map[c]; });
		s = s.normalize ? s.normalize('NFD').replace(/[̀-ͯ]/g, '') : s;
		return s.replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 40);
	};
	var esc = function (s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;'); }; // też w atrybutach (value="…")

	function sync() { $json.val(JSON.stringify(fields)); tags(); replyOptions(); preview(); }

	function itemHtml(f, i) {
		var t = f.type, types = A.types || {}, sel = '';
		Object.keys(types).forEach(function (k) { sel += '<option value="' + k + '"' + (k === t ? ' selected' : '') + '>' + esc(types[k]) + '</option>'; });
		var lbl = t === 'consent' ? $('<div>').html(f.label).text() : f.label;
		var h = '<li class="rzd-kfb-item" data-i="' + i + '">' +
			'<div class="rzd-kfb-head"><span class="rzd-kfb-handle" title="Przeciągnij">☰</span>' +
			'<span class="rzd-kfb-title">' + (esc(lbl) || '<em>(bez etykiety)</em>') + ' <span class="rzd-kfb-type">· ' + esc(types[t] || t) + (t !== 'heading' ? ' · {' + esc(f.key) + '}' : '') + '</span></span>' +
			(f.required ? '<span class="rzd-kfb-badge">wymagane</span>' : '') +
			'<button type="button" class="button-link rzd-kfb-up" title="W górę" aria-label="W górę">▲</button>' +
			'<button type="button" class="button-link rzd-kfb-down" title="W dół" aria-label="W dół">▼</button>' +
			'<button type="button" class="button-link rzd-kfb-dup" title="Duplikuj" aria-label="Duplikuj">⧉</button>' +
			'<button type="button" class="button-link button-link-delete rzd-kfb-del" title="Usuń" aria-label="Usuń">✕</button></div>';
		if (open[i]) {
			h += '<div class="rzd-kfb-body">' +
				'<label class="rzd-kfb-wide">' + (t === 'consent' ? 'Treść zgody (można dodać link: &lt;a href="…"&gt;…&lt;/a&gt;)' : (t === 'heading' ? 'Tekst nagłówka' : 'Etykieta')) + '<input type="text" data-k="label" value="' + esc(f.label) + '"></label>' +
				'<label>Typ<select data-k="type">' + sel + '</select></label>' +
				(t !== 'heading' ? '<label>Klucz (do maili: {klucz})<input type="text" data-k="key" value="' + esc(f.key) + '"></label>' : '') +
				(t !== 'heading' ? '<label><input type="checkbox" data-k="required"' + (f.required ? ' checked' : '') + '> wymagane</label>' : '') +
				(['heading', 'textarea', 'consent'].indexOf(t) === -1 ? '<label>Szerokość<select data-k="width"><option value="full"' + (f.width !== 'half' ? ' selected' : '') + '>cała linia</option><option value="half"' + (f.width === 'half' ? ' selected' : '') + '>pół linii (na komputerze)</option></select></label>' : '') +
				(['text', 'textarea', 'email', 'tel', 'number', 'select'].indexOf(t) !== -1 ? '<label>Podpowiedź w polu' + (t === 'select' ? ' (pierwsza pozycja listy)' : '') + '<input type="text" data-k="placeholder" value="' + esc(f.placeholder) + '"></label>' : '') +
				'<label class="rzd-kfb-wide">' + (t === 'heading' ? 'Tekst pod nagłówkiem' : 'Tekst pomocy pod polem') + '<textarea rows="2" data-k="help">' + esc(f.help) + '</textarea></label>' +
				(hasOpts(t) ? '<label class="rzd-kfb-wide">Opcje do wyboru – każda w osobnej linii<textarea rows="4" data-k="options">' + esc(f.options) + '</textarea></label>' : '') +
				(t === 'number' ? '<label>Najmniej<input type="text" data-k="min" value="' + esc(f.min) + '"></label><label>Najwięcej<input type="text" data-k="max" value="' + esc(f.max) + '"></label>' : '') +
				(t === 'date' ? '<label><input type="checkbox" data-k="future"' + (f.future ? ' checked' : '') + '> tylko dziś i przyszłe daty</label>' : '') +
				'</div>';
		}
		return h + '</li>';
	}
	function render() {
		$list.html(fields.map(itemHtml).join(''));
		if ($.fn.sortable) {
			$list.sortable({
				handle: '.rzd-kfb-handle', placeholder: 'rzd-kfb-placeholder', axis: 'y',
				update: function () {
					var order = $list.children().map(function () { return +$(this).data('i'); }).get(), o2 = {};
					fields = order.map(function (i, n) { if (open[i]) { o2[n] = 1; } return fields[i]; });
					open = o2; render(); sync();
				}
			});
		}
	}

	$list.on('click', '.rzd-kfb-head', function (e) {
		if ($(e.target).closest('button, .rzd-kfb-handle').length) { return; }
		var i = +$(this).closest('li').data('i'); open[i] = !open[i]; render();
		if (open[i]) { $list.find('li[data-i="' + i + '"] [data-k="label"]').trigger('focus'); }
	});
	$list.on('click', '.rzd-kfb-up, .rzd-kfb-down', function () {
		var i = +$(this).closest('li').data('i'), j = $(this).hasClass('rzd-kfb-up') ? i - 1 : i + 1;
		if (j < 0 || j >= fields.length) { return; }
		var t = fields[i]; fields[i] = fields[j]; fields[j] = t;
		var oi = open[i]; open[i] = open[j]; open[j] = oi; render(); sync();
	});
	$list.on('click', '.rzd-kfb-dup', function () {
		var i = +$(this).closest('li').data('i'), c = $.extend({}, fields[i]);
		c.key = c.key + '_2'; c._auto = false; fields.splice(i + 1, 0, c); open = {}; open[i + 1] = 1; render(); sync();
	});
	$list.on('click', '.rzd-kfb-del', function () {
		var i = +$(this).closest('li').data('i');
		if (!window.confirm('Usunąć pole „' + $('<div>').html(fields[i].label).text() + '”?')) { return; }
		fields.splice(i, 1); open = {}; render(); sync();
	});
	$list.on('input change', '[data-k]', function () {
		var $el = $(this), i = +$el.closest('li').data('i'), k = $el.data('k'), f = fields[i];
		var v = $el.is(':checkbox') ? ($el.is(':checked') ? 1 : 0) : $el.val();
		f[k] = v;
		if (k === 'key') { f._auto = false; }
		if (k === 'label' && f._auto) { f.key = slug($('<div>').html(v).text()) || f.key; $el.closest('li').find('[data-k="key"]').val(f.key); }
		var $t = $el.closest('li').find('.rzd-kfb-title');
		if (k === 'label' || k === 'key') { $t.html((esc($('<div>').html(f.label).text()) || '<em>(bez etykiety)</em>') + ' <span class="rzd-kfb-type">· ' + esc((A.types || {})[f.type]) + (f.type !== 'heading' ? ' · {' + esc(f.key) + '}' : '') + '</span>'); }
		if (k === 'type' || k === 'required') { render(); $list.find('li[data-i="' + i + '"] [data-k="' + k + '"]').trigger('focus'); }
		sync();
	});
	$('#rzd-kfb-add').on('click', function () {
		var t = $('#rzd-kfb-type').val(), n = fields.length + 1, label = t === 'heading' ? 'Nagłówek' : ((A.types || {})[t] || 'Pole');
		if (t === 'consent') { label = 'Wyrażam zgodę na …'; }
		var f = { key: slug(label) + '_' + n, label: label, type: t, required: 0, placeholder: '', help: '', width: 'full', options: hasOpts(t) ? 'Opcja 1\nOpcja 2' : '', min: '', max: '', future: 0, _auto: true };
		fields.push(f); open = {}; open[fields.length - 1] = 1; render(); sync();
		$list.find('li:last [data-k="label"]').trigger('focus').trigger('select');
	});

	// znaczniki do maili
	var lastTpl = $('#rzd-kfe-body')[0];
	$form.on('focus', 'textarea[name=body], input[name=subject], input[name=ar_subject], textarea[name=ar_body]', function () { lastTpl = this; });
	function tags() {
		var t = ['{wszystkie_pola}', '{formularz}', '{sklep}', '{strona}', '{data}'];
		fields.forEach(function (f) { if (f.type !== 'heading' && f.key) { t.push('{' + f.key + '}'); } });
		$('#rzd-kfe-tags').html(t.map(function (x) { return '<code tabindex="0" role="button">' + esc(x) + '</code>'; }).join(''));
	}
	$('#rzd-kfe-tags').on('click keydown', 'code', function (e) {
		if (e.type === 'keydown' && e.key !== 'Enter') { return; }
		var el = lastTpl, txt = $(this).text();
		if (!el) { return; }
		var s = el.selectionStart || el.value.length, en = el.selectionEnd || s;
		el.value = el.value.slice(0, s) + txt + el.value.slice(en); el.focus(); el.selectionStart = el.selectionEnd = s + txt.length;
	});
	function replyOptions() {
		var $r = $('#rzd-kfe-reply'), cur = $r.val() || $r.data('value') || '', h = '';
		var em = fields.filter(function (f) { return f.type === 'email'; });
		if (!em.length) { h = '<option value="">(brak pola e-mail w formularzu)</option>'; }
		em.forEach(function (f) { h += '<option value="' + esc(f.key) + '"' + (f.key === cur ? ' selected' : '') + '>' + esc(f.label) + '</option>'; });
		$r.html(h);
	}
	$('#rzd-kfe-ar').on('change', function () { $('#rzd-kfe-ar-box').toggle(this.checked); }).trigger('change');

	// „własny kolor” – bez zaznaczenia pole koloru nie jest wysyłane (= kolor z Wyglądu listy)
	$form.on('change', '.rzd-kfe-own', function () { $('#' + $(this).data('for')).prop('disabled', !this.checked); preview(); });

	// podgląd na żywo
	var timer = null, $prev = $('#rzd-kf-preview'), $ps = $('#rzd-kfe-pstate');
	function preview() {
		clearTimeout(timer);
		timer = setTimeout(function () {
			var data = $form.serializeArray().filter(function (x) { return x.name !== 'action' && x.name !== '_wpnonce'; });
			data.push({ name: 'action', value: 'rzd_kf_preview' }, { name: '_ajax_nonce', value: A.nonce });
			$ps.text('odświeżanie…');
			$.post(A.ajax, $.param(data)).done(function (r) {
				if (r && r.success) { $prev.html(r.data.html); $ps.text(''); if (window.rzdKfInit) { window.rzdKfInit(); } }
				else { $ps.text(r && r.data ? r.data.message : 'błąd podglądu'); }
			}).fail(function () { $ps.text('błąd podglądu'); });
		}, 350);
	}
	$form.on('input change', 'input:not([data-k]), select:not([data-k]), textarea:not([data-k])', function () {
		if (this.id === 'rzd-kfe-json') { return; }
		preview();
	});
	$('.rzd-kfe-pw').on('click', 'button', function () { var w = $(this).data('w'); $prev.css('max-width', w ? w + 'px' : ''); });

	// zapis: puste etykiety – ostrzeżenie (serwer i tak je pominie)
	$form.on('submit', function () {
		$json.val(JSON.stringify(fields));
		var empty = fields.filter(function (f) { return !$('<div>').html(f.label).text().trim(); }).length;
		return !empty || window.confirm('Pola bez etykiety (' + empty + ') nie zostaną zapisane. Zapisać?');
	});

	fields.forEach(function (f) { f._auto = false; });
	render(); tags(); replyOptions();
})(jQuery);
