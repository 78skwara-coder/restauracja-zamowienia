/* Restauracja – Zamówienia i Dostawy: rzd-modyfikacje-edytor.js (z 10-modyfikacje.php) */
jQuery(function ($) {
	var $sections = $('#rzd-sections');

	function toggleFields($g) {
		var type = $g.find('.rzd-type').first().val();
		$g.find('.rzd-only-radio').toggle(type === 'radio');
		$g.find('.rzd-only-addon').toggle(type === 'tap' || type === 'stepper');
		$g.find('.rzd-only-stepper-range').toggle(type === 'stepper');
		$g.find('.rzd-only-text').toggle(type === 'text');
		$g.find('.rzd-only-clone').toggle(type === 'clone');
	}

	$('#rzd-add-section').on('click', function (e) {
		e.preventDefault();
		var n = parseInt($sections.attr('data-next'), 10) || 0;
		$sections.append($('#rzd-section-template').html().split('__S__').join(n));
		$sections.attr('data-next', n + 1);
	});
	$sections.on('click', '.rzd-remove-section', function (e) { e.preventDefault(); $(this).closest('.rzd-section').remove(); });
	// kopia grupy razem z bieżącymi (także niezapisanymi) wartościami pól.
	// Nowa grupa dostaje kolejny wolny numer z data-next – podmieniamy go
	// w nazwach pól (rzd_section[S]…) i w data-section / data-group.
	$sections.on('click', '.rzd-copy-section', function (e) {
		e.preventDefault();
		var $src = $(this).closest('.rzd-section');
		var n = parseInt($sections.attr('data-next'), 10) || 0;
		var $copy = $src.clone(false);
		var $from = $src.find('input, select, textarea');
		$copy.find('input, select, textarea').each(function (i) {
			var $f = $(this), $o = $from.eq(i);
			if ($f.is(':checkbox, :radio')) { $f.prop('checked', $o.prop('checked')); } else { $f.val($o.val()); }
			var nm = $f.attr('name');
			if (nm) { $f.attr('name', nm.replace(/^rzd_section\[[^\]]*\]/, 'rzd_section[' + n + ']')); }
		});
		$copy.attr('data-section', n);
		$copy.find('.rzd-group').each(function () {
			var g = $(this).attr('data-group') || '';
			$(this).attr('data-group', g.replace(/^[^\]]*/, String(n)));
		});
		$copy.find('input[name$="[preset]"]').remove(); // kopia to już własna grupa, nie „ze wzoru”
		var $head = $copy.find('input[name$="[header]"]').first();
		if ($head.length && $head.val()) { $head.val($head.val() + ' (kopia)'); }
		$src.after($copy);
		$sections.attr('data-next', n + 1);
		$copy.css('outline', '3px solid #72aee6');
		setTimeout(function () { $copy.css('outline', ''); }, 1500);
		if ($copy[0].scrollIntoView) { $copy[0].scrollIntoView({ behavior: 'smooth', block: 'center' }); }
	});

	$sections.on('click', '.rzd-add-item', function (e) {
		e.preventDefault();
		var $sec = $(this).closest('.rzd-section');
		var si = $sec.attr('data-section');
		var mi = parseInt($sec.attr('data-next-item'), 10) || 0;
		var tpl = $('#rzd-item-template').html().split('__S__').join(si).split('__M__').join(mi);
		$sec.find('.rzd-items').first().append(tpl);
		$sec.attr('data-next-item', mi + 1);
	});
	$sections.on('change', '.rzd-type', function () { toggleFields($(this).closest('.rzd-group')); });
	$sections.on('click', '.rzd-remove-group', function (e) { e.preventDefault(); $(this).closest('.rzd-group').remove(); });

	$sections.on('click', '.rzd-add-opt', function (e) {
		e.preventDefault();
		var $g = $(this).closest('.rzd-group');
		var gi = $g.attr('data-group');
		var oi = parseInt($g.attr('data-next-opt'), 10) || 0;
		var tpl = $('#rzd-opt-template').html().split('__S____M__').join(gi).split('__I__').join(oi);
		$g.find('.rzd-opts').first().append(tpl);
		$g.attr('data-next-opt', oi + 1);
	});
	$sections.on('click', '.rzd-remove-opt', function (e) { e.preventDefault(); $(this).closest('.rzd-opt').remove(); });
});
