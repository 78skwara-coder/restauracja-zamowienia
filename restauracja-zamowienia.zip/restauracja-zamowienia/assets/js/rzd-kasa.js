/* Restauracja – Zamówienia i Dostawy: rzd-kasa.js (z 29-formularz-zamowienia.php)
   Nowy wygląd kasy: nagłówki sekcji, faktura (pokaż/ukryj pola), uwagi zwinięte, pasek „Twoje zamówienie” na telefonie.
   Bez skryptu formularz działa normalnie (tylko bez nagłówków i zwijania). */
(function ($) {
	'use strict';
	var cfg = window.rzdCo || {};
	var form = document.querySelector('form.checkout');
	if (!form) { return; }

	function h(text, num, sep) {
		var el = document.createElement('h3');
		el.className = 'rzd-co-h' + (sep ? ' rzd-co-h-sep' : '');
		if (num) {
			var n = document.createElement('span'); n.className = 'rzd-co-n'; n.textContent = num; el.appendChild(n);
		}
		el.appendChild(document.createTextNode(text));
		return el;
	}
	// Nagłówek w danych klienta = wiersz formularza z data-priority: skrypt adresu WooCommerce sortuje
	// wiersze wg priorytetu, więc nagłówek zostaje nad swoją sekcją niezależnie od kolejności wczytania.
	function hrow(text, num, sep, prio, after) {
		var wrap = form.querySelector('.woocommerce-billing-fields__field-wrapper');
		if (!wrap || wrap.querySelector('[data-rzd-h="' + prio + '"]')) { return; }
		var row = document.createElement('div');
		row.className = 'form-row form-row-wide rzd-co-hrow';
		row.setAttribute('data-priority', prio);
		row.setAttribute('data-rzd-h', prio);
		row.appendChild(h(text, num, sep));
		var t = form.querySelector(after);
		if (t && t.parentNode === wrap) { wrap.insertBefore(row, t); } else { wrap.insertBefore(row, wrap.firstChild); }
	}

	// 1. nagłówki sekcji w danych klienta
	hrow('Twoje dane', '1', false, 1, '#billing_first_name_field');
	hrow('Adres dostawy', '2', true, 45, '#billing_address_1_field');

	// 2. faktura – pola firmy i NIP tylko po zaznaczeniu
	var inv = document.getElementById('billing_rzd_invoice');
	function invSync() { form.classList.toggle('rzd-co-inv-on', !!(inv && inv.checked)); }
	if (inv) { inv.addEventListener('change', invSync); invSync(); }

	// 3. uwagi do zamówienia – zwinięte pod linkiem (rozwinięte, gdy już coś wpisano)
	var notesBox = form.querySelector('.woocommerce-additional-fields');
	var notes = document.getElementById('order_comments');
	if (notesBox && notes && cfg.notes === 'collapsed' && !notes.value) {
		notesBox.classList.add('rzd-co-notes-closed');
		var a = document.createElement('a');
		a.href = '#order_comments'; a.className = 'rzd-co-notes-link'; a.textContent = '+ Dodaj uwagi do zamówienia (np. kod do bramy, piętro)';
		a.addEventListener('click', function (e) {
			e.preventDefault(); notesBox.classList.remove('rzd-co-notes-closed'); a.remove(); notes.focus();
		});
		notesBox.insertBefore(a, notesBox.firstChild);
	}

	// 4. podsumowanie i płatność: nagłówki + opakowanie (na komputerze przyklejone obok formularza)
	var review = document.getElementById('order_review');
	var heading = document.getElementById('order_review_heading');
	if (review && !review.parentNode.classList.contains('rzd-co-sumwrap')) {
		var wrap = document.createElement('div');
		wrap.className = 'rzd-co-sumwrap';
		review.parentNode.insertBefore(wrap, review);
		if (heading) { wrap.appendChild(heading); }
		wrap.appendChild(review);
	}
	function decorate() {
		if (!review) { return; }
		var table = review.querySelector('.woocommerce-checkout-review-order-table');
		if (table && !(table.previousElementSibling && table.previousElementSibling.classList.contains('rzd-co-h'))) {
			review.insertBefore(h('Twoje zamówienie', '3'), table);
		}
		var pay = review.querySelector('#payment');
		if (pay && !(pay.previousElementSibling && pay.previousElementSibling.classList.contains('rzd-co-h'))) {
			pay.parentNode.insertBefore(h('Płatność', '4', true), pay);
		}
		sumbar();
	}

	// 5. telefon: pasek „Twoje zamówienie · kwota” na górze formularza → przewija do podsumowania
	var bar = null;
	function sumbar() {
		var total = review && review.querySelector('.order-total .amount');
		if (!total) { return; }
		if (!bar) {
			bar = document.createElement('a');
			bar.className = 'rzd-co-sumbar'; bar.href = '#order_review';
			bar.addEventListener('click', function (e) {
				e.preventDefault(); review.scrollIntoView({ behavior: 'smooth', block: 'start' });
			});
			var cd = document.getElementById('customer_details');
			if (cd) { cd.parentNode.insertBefore(bar, cd); }
		}
		var n = review.querySelectorAll('tr.cart_item').length;
		bar.innerHTML = '';
		var l = document.createElement('span'); l.textContent = 'Twoje zamówienie' + (n ? ' (' + n + ' poz.)' : '') + ' · ';
		var s = document.createElement('strong'); s.textContent = total.textContent.trim();
		l.appendChild(s);
		var g = document.createElement('span'); g.className = 'rzd-co-sumbar-go'; g.textContent = 'Pokaż ↓';
		bar.appendChild(l); bar.appendChild(g);
	}

	decorate();
	if ($) { $(document.body).on('updated_checkout', decorate); }
})(window.jQuery);
