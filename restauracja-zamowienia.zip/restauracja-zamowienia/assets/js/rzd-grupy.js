/* Restauracja – edytor JEDNEJ grupy modyfikacji (2.45.0). Wspólny dla Panelu restauracji (Menu → Wzory)
 * i Edycji menu (karta dania). Sam rysuje swoje okno (style: rzd-grupy.css), nie zależy od strony.
 *   window.rzdGroupEditor.open({ group, dict: {addons, roles, types, places}, title, onSave(group), onDelete })
 * Grupa: { header, description, place: before|cart, preset?, items: [ modyfikacja ] }, modyfikacja:
 *   tap / stepper: { type, addon_id, role [, min, max] } · radio: { type, options: [{addon_id, role}] }
 *   text: { type, name, price, placeholder } · clone: { type, max }
 * Zapis i tak czyści serwer (rzd_sanitize_sections) – tu tylko wygoda i podpowiedzi. */
(function () {
	'use strict';
	if (window.rzdGroupEditor) { return; }

	function h(tag, a, kids) {
		var e = document.createElement(tag);
		Object.keys(a || {}).forEach(function (k) {
			var v = a[k];
			if (v === null || v === undefined || v === false) { return; }
			if (k === 'class') { e.className = v; }
			else if (k === 'text') { e.textContent = v; }
			else if (k === 'value') { e.value = v; }
			else if (k === 'checked' || k === 'selected' || k === 'disabled') { e[k] = !!v; }
			else if (k.slice(0, 2) === 'on') { e.addEventListener(k.slice(2), v); }
			else { e.setAttribute(k, v === true ? '' : v); }
		});
		(kids || []).forEach(function (c) {
			if (c === null || c === undefined || c === false) { return; }
			e.appendChild(typeof c === 'string' || typeof c === 'number' ? document.createTextNode(String(c)) : c);
		});
		return e;
	}
	function zl(n) { n = parseFloat(n) || 0; return (Math.round(n * 100) / 100).toString().replace('.', ',') + ' zł'; }
	function copy(o) { return JSON.parse(JSON.stringify(o)); }

	var box = null;
	function close() { if (box) { box.remove(); box = null; document.removeEventListener('keydown', onKey, true); document.documentElement.classList.remove('rzg-lock'); } }
	function onKey(e) { if (e.key === 'Escape') { e.stopPropagation(); if (window.confirm('Zamknąć bez zapisu zmian w grupie?')) { close(); } } }

	function open(opt) {
		close();
		var dict = opt.dict || {};
		var addons = dict.addons || [];
		var byId = {};
		addons.forEach(function (a) { byId[a.id] = a; });
		var g = copy(opt.group || { header: '', description: '', place: 'before', items: [] });
		g.items = g.items || [];
		if (!g.place) { g.place = 'before'; }

		function addonLabel(a) {
			var p = Math.abs(a.price - a.minus) < 0.001 ? zl(a.price) : '+' + zl(a.price) + ' / −' + zl(a.minus);
			return a.name + (a.type ? ' [' + a.type + ']' : '') + ' – ' + p + (a.mandatory ? ' · obowiązkowy' : '');
		}
		function addonSelect(val, onch) {
			var types = {};
			addons.forEach(function (a) { (types[a.type || ''] = types[a.type || ''] || []).push(a); });
			var kids = [h('option', { value: '', text: '— wybierz dodatek —' })];
			Object.keys(types).sort().forEach(function (t) {
				var opts = types[t].map(function (a) { return h('option', { value: String(a.id), selected: String(val) === String(a.id), text: addonLabel(a) }); });
				kids.push(t ? h('optgroup', { label: t }, opts) : h('optgroup', { label: 'Bez typu' }, opts));
			});
			if (val && !byId[val]) { kids.push(h('option', { value: String(val), selected: true, text: 'Dodatek usunięty (#' + val + ') – wybierz inny' })); }
			var s = h('select', { class: 'rzg-in', 'aria-label': 'Dodatek', onchange: function () { onch(s.value ? parseInt(s.value, 10) : 0); } }, kids);
			return s;
		}
		function roleSelect(val, onch) {
			var s = h('select', { class: 'rzg-in', 'aria-label': 'Rola', onchange: function () { onch(s.value); } }, Object.keys(dict.roles || {}).map(function (k) { return h('option', { value: k, selected: val === k, text: dict.roles[k] }); }));
			return s;
		}
		function field(label, input, hint) {
			return h('label', { class: 'rzg-f' }, [h('span', { class: 'rzg-l', text: label }), input, hint ? h('small', { class: 'rzg-hint', text: hint }) : null]);
		}
		function num(val, attrs, onch) {
			var a = { type: 'number', class: 'rzg-in rzg-in-s', value: val === undefined || val === null ? '' : String(val), oninput: function () { onch(i.value); } };
			Object.keys(attrs || {}).forEach(function (k) { a[k] = attrs[k]; });
			var i = h('input', a);
			return i;
		}

		var body = h('div', { class: 'rzg-body' });
		var err = h('p', { class: 'rzg-err', role: 'alert', hidden: true });

		function itemCard(it, idx) {
			var t = it.type || 'tap';
			var kids = [];
			var typeSel = h('select', { class: 'rzg-in', 'aria-label': 'Sposób wyświetlania', onchange: function () {
				var nt = typeSel.value;
				var keep = it.addon_id || (it.options && it.options[0] && it.options[0].addon_id) || 0;
				var role = it.role || 'dodaje';
				var n = { type: nt };
				if (nt === 'tap' || nt === 'stepper') { n.addon_id = keep; n.role = role; if (nt === 'stepper') { n.min = 0; n.max = 10; } }
				else if (nt === 'radio') { n.options = keep ? [{ addon_id: keep, role: 'neutralna' }] : []; }
				else if (nt === 'text') { n.name = ''; n.price = 0; n.placeholder = ''; }
				else if (nt === 'clone') { n.max = 3; }
				g.items[idx] = n; draw();
			} }, Object.keys(dict.types || {}).map(function (k) { return h('option', { value: k, selected: t === k, text: dict.types[k] }); }));
			kids.push(field('Sposób wyświetlania', typeSel));
			if (t === 'tap' || t === 'stepper') {
				kids.push(h('div', { class: 'rzg-row' }, [
					field('Dodatek', addonSelect(it.addon_id, function (v) { it.addon_id = v; })),
					field('Rola', roleSelect(it.role || 'dodaje', function (v) { it.role = v; }))
				]));
				if (t === 'stepper') {
					kids.push(h('div', { class: 'rzg-row rzg-row-s' }, [
						field('Ilość od', num(it.min !== undefined ? it.min : 0, { min: '0', max: '99' }, function (v) { it.min = parseInt(v, 10) || 0; })),
						field('do', num(it.max !== undefined ? it.max : 10, { min: '0', max: '99' }, function (v) { it.max = parseInt(v, 10) || 0; }))
					]));
				}
			} else if (t === 'radio') {
				it.options = it.options || [];
				var ol = h('div', { class: 'rzg-opts' });
				it.options.forEach(function (o, oi) {
					ol.appendChild(h('div', { class: 'rzg-opt' }, [
						addonSelect(o.addon_id, function (v) { o.addon_id = v; }),
						roleSelect(o.role || 'neutralna', function (v) { o.role = v; }),
						h('button', { type: 'button', class: 'rzg-ico', 'aria-label': 'Usuń opcję', text: '✕', onclick: function () { it.options.splice(oi, 1); draw(); } })
					]));
				});
				kids.push(h('div', { class: 'rzg-f' }, [h('span', { class: 'rzg-l', text: 'Opcje do wyboru (klient wybiera jedną)' }), ol,
					h('button', { type: 'button', class: 'rzg-btn rzg-btn-s', text: '+ Opcja', onclick: function () { it.options.push({ addon_id: 0, role: 'neutralna' }); draw(); } }),
					h('small', { class: 'rzg-hint', text: 'Np. Ziemniaki / Frytki (neutralna) i „Bez dodatku” (odejmuje). Wybór zastępuje w składzie dodatek tego samego typu.' })]));
			} else if (t === 'text') {
				kids.push(h('div', { class: 'rzg-row' }, [
					field('Nazwa (widzi klient)', h('input', { type: 'text', class: 'rzg-in', value: it.name || '', placeholder: 'np. Napis na torcie', oninput: function (e) { it.name = e.target.value; } })),
					field('Cena (zł)', h('input', { type: 'text', inputmode: 'decimal', class: 'rzg-in rzg-in-s', value: it.price ? String(it.price).replace('.', ',') : '', placeholder: '0', oninput: function (e) { it.price = parseFloat(e.target.value.replace(',', '.')) || 0; } }), 'Gdy klient coś wpisze.')
				]));
				kids.push(field('Podpowiedź w polu', h('input', { type: 'text', class: 'rzg-in', value: it.placeholder || '', oninput: function (e) { it.placeholder = e.target.value; } })));
			} else if (t === 'clone') {
				kids.push(field('Najwięcej dokładek jednego dodatku', num(it.max || 3, { min: '1', max: '20' }, function (v) { it.max = parseInt(v, 10) || 1; }), 'Licznik + / − przy każdym dodatku ze składu dania; cena = „wartość przy dodaniu” dodatku (0 zł = bez dokładki).'));
			}
			return h('div', { class: 'rzg-item' }, [
				h('div', { class: 'rzg-item-h' }, [
					h('strong', { text: 'Modyfikacja ' + (idx + 1) }),
					h('span', { class: 'rzg-sp' }),
					h('button', { type: 'button', class: 'rzg-ico', 'aria-label': 'W górę', text: '↑', disabled: idx === 0, onclick: function () { g.items.splice(idx - 1, 0, g.items.splice(idx, 1)[0]); draw(); } }),
					h('button', { type: 'button', class: 'rzg-ico', 'aria-label': 'W dół', text: '↓', disabled: idx === g.items.length - 1, onclick: function () { g.items.splice(idx + 1, 0, g.items.splice(idx, 1)[0]); draw(); } }),
					h('button', { type: 'button', class: 'rzg-ico rzg-del', 'aria-label': 'Usuń modyfikację', text: '✕', onclick: function () { g.items.splice(idx, 1); draw(); } })
				])
			].concat(kids));
		}

		var top = null;
		function draw() {
			var sc = body.scrollTop;
			body.textContent = '';
			if (!top) {
				top = h('div', { class: 'rzg-top' }, [
					field('Nagłówek grupy (widzi klient)', h('input', { type: 'text', class: 'rzg-in', value: g.header || '', placeholder: 'np. Wybierz dodatek', oninput: function (e) { g.header = e.target.value; } })),
					field('Opis (mniejszą czcionką, opcjonalnie)', h('textarea', { class: 'rzg-in', rows: '2', oninput: function (e) { g.description = e.target.value; } }, [g.description || ''])),
					field('Gdzie klient wybiera', h('select', { class: 'rzg-in', onchange: function (e) { g.place = e.target.value; } }, Object.keys(dict.places || {}).map(function (k) { return h('option', { value: k, selected: g.place === k, text: dict.places[k] }); })), '„W przeglądzie zamówienia” = przycisk „Dodatki płatne” po „Przejdź do koszyka”. Pojedynczy wybór i obowiązkowe i tak pokażą się przed dodaniem.'),
					g.preset ? h('p', { class: 'rzg-hint', text: 'Grupa pochodzi ze wzoru – zmiana dotyczy tylko tego miejsca (wzór i inne dania bez zmian).' }) : null
				]);
			}
			body.appendChild(top);
			body.appendChild(h('h3', { class: 'rzg-h3', text: 'Modyfikacje (' + g.items.length + ')' }));
			if (!g.items.length) { body.appendChild(h('p', { class: 'rzg-hint', text: 'Brak – dodaj pierwszą. Grupa bez modyfikacji nie zapisze się.' })); }
			g.items.forEach(function (it, i) { body.appendChild(itemCard(it, i)); });
			body.appendChild(h('button', { type: 'button', class: 'rzg-btn', text: '+ Modyfikacja', onclick: function () { g.items.push({ type: 'tap', addon_id: 0, role: 'dodaje' }); draw(); body.scrollTop = body.scrollHeight; } }));
			body.appendChild(err);
			body.scrollTop = sc;
		}

		function check() {
			var bad = [];
			g.items.forEach(function (it, i) {
				var n = i + 1;
				if ((it.type === 'tap' || it.type === 'stepper') && !byId[it.addon_id]) { bad.push('modyfikacja ' + n + ': wybierz dodatek'); }
				if (it.type === 'radio' && !(it.options || []).some(function (o) { return byId[o.addon_id]; })) { bad.push('modyfikacja ' + n + ': dodaj choć jedną opcję z dodatkiem'); }
				if (it.type === 'text' && !(it.name || '').trim()) { bad.push('modyfikacja ' + n + ': podaj nazwę pola'); }
			});
			if (!g.items.length) { bad.push('grupa nie ma żadnej modyfikacji'); }
			return bad;
		}

		var save = h('button', { type: 'button', class: 'rzg-btn rzg-pri', text: 'Gotowe', onclick: function () {
			var bad = check();
			if (bad.length) { err.textContent = 'Popraw: ' + bad.join('; ') + '.'; err.hidden = false; err.scrollIntoView({ block: 'nearest' }); return; }
			(g.items || []).forEach(function (it) { if (it.type === 'radio') { it.options = it.options.filter(function (o) { return byId[o.addon_id]; }); } });
			var out = copy(g);
			close();
			opt.onSave(out);
		} });
		var foot = [
			opt.onDelete ? h('button', { type: 'button', class: 'rzg-btn rzg-danger', text: 'Usuń grupę', onclick: function () { if (window.confirm('Usunąć tę grupę?')) { close(); opt.onDelete(); } } }) : null,
			h('span', { class: 'rzg-sp' }),
			h('button', { type: 'button', class: 'rzg-btn', text: 'Anuluj', onclick: close }),
			save
		];
		var dlg = h('div', { class: 'rzg-dlg', role: 'dialog', 'aria-modal': 'true', 'aria-label': opt.title || 'Grupa modyfikacji' }, [
			h('div', { class: 'rzg-head' }, [h('h2', { text: opt.title || 'Grupa modyfikacji' }), h('button', { type: 'button', class: 'rzg-ico', 'aria-label': 'Zamknij', text: '✕', onclick: function () { if (window.confirm('Zamknąć bez zapisu zmian w grupie?')) { close(); } } })]),
			body,
			h('div', { class: 'rzg-foot' }, foot)
		]);
		box = h('div', { class: 'rzg-shade' }, [dlg]);
		document.body.appendChild(box);
		document.documentElement.classList.add('rzg-lock');
		document.addEventListener('keydown', onKey, true);
		draw();
		var f = dlg.querySelector('input');
		if (f) { setTimeout(function () { f.focus(); }, 30); }
	}

	/** Krótki opis grupy do list: „3 modyfikacje · Frytki, Ziemniaki…”. */
	function summary(g, dict) {
		var by = {};
		((dict && dict.addons) || []).forEach(function (a) { by[a.id] = a.name; });
		var names = [];
		(g.items || []).forEach(function (it) {
			if (it.addon_id && by[it.addon_id]) { names.push(by[it.addon_id]); }
			(it.options || []).forEach(function (o) { if (by[o.addon_id]) { names.push(by[o.addon_id]); } });
			if (it.type === 'text' && it.name) { names.push(it.name); }
			if (it.type === 'clone') { names.push('dokładki ze składu'); }
		});
		var n = (g.items || []).length;
		return n + ' ' + (n === 1 ? 'modyfikacja' : (n > 1 && n < 5 ? 'modyfikacje' : 'modyfikacji')) + (names.length ? ' · ' + names.slice(0, 5).join(', ') + (names.length > 5 ? '…' : '') : '');
	}

	window.rzdGroupEditor = { open: open, close: close, summary: summary };
})();
