/* Restauracja – Panel restauracji: sekcja Zestawy (2.45.0) – harmonogram zestawu: terminy (dni tygodnia, zakres
 * dat, konkretna data z „zastępuje”, godziny) i dania. W bazie najstarszy termin pierwszy; na ekranie najnowszy u góry. */
(function () {
	'use strict';
	var K = window.rzdPanelKit;
	if (!K) { return; }
	var h = K.h, S = K.S;

	function copy(o) { return JSON.parse(JSON.stringify(o)); }

	function secSets(main) {
		var d = S.data.sets;
		if (!d) {
			K.loading(main, 'Zestawy');
			K.load('sets', 'sets').then(function () {
				if (S.urlId) { var id = S.urlId; S.urlId = 0; openSet(id); return; }
				K.render();
			}).catch(function (e) { main.textContent = ''; K.failBox(main, e, K.render); });
			return;
		}
		if (S.zset) { setView(main, d); return; }
		main.appendChild(K.pageHead('Zestawy', 'Harmonogram zestawów: w jakie dni i godziny jakie dania wchodzą w zestaw. Układanie zestawu na konkretny dzień jest też w Edycji menu (zakładka Zestawy).', K.btn('+ Zestaw z produktu', function () {
			pickProduct('Który produkt ma być zestawem?', d.products.filter(function (p) { return !d.sets.some(function (s) { return s.id === p.id; }); }), function (p) { openSet(p.id); });
		}, 'rp-btn-pri')));
		var l = h('div', { class: 'rp-list' });
		if (!d.sets.length) { l.appendChild(h('p', { class: 'rp-empty-s', text: 'Nie ma jeszcze żadnego zestawu. Zestawem staje się produkt, któremu ułożysz terminy z daniami.' })); }
		d.sets.forEach(function (s) {
			l.appendChild(h('button', { type: 'button', class: 'rp-row', onclick: function () { openSet(s.id); } }, [
				h('span', { class: 'rp-row-main' }, [h('strong', { text: s.name + (s.hidden ? ' (ukryty w sklepie)' : '') }), h('small', { text: 'Terminów: ' + s.slots })]),
				h('span', { class: 'rp-pill' + (s.now ? ' ok' : ''), text: s.now ? 'aktywny teraz' : 'nieaktywny teraz' })
			]));
		});
		main.appendChild(l);
		main.appendChild(h('p', { class: 'rp-muted', text: 'Teraz: ' + d.now + '.' }));
	}
	function openSet(id) {
		K.api('set_get', { id: id }).then(function (x) { S.zset = x.set; S.zedit = copy(x.set.slots); S.dirty = false; K.render(); var m = K.root.querySelector('.rp-main'); if (m) { m.scrollTop = 0; } }).catch(function (e) { K.toast(e.message, true); });
	}
	function pickProduct(title, list, onPick) {
		var q = h('input', { type: 'search', class: 'rp-in', placeholder: 'Szukaj produktu', 'aria-label': 'Szukaj produktu' });
		var ul = h('div', { class: 'rp-list rp-pick' });
		function draw() {
			ul.textContent = '';
			var n = q.value.trim().toLowerCase();
			var rows = list.filter(function (p) { return !n || p.name.toLowerCase().indexOf(n) > -1 || (p.cats || '').toLowerCase().indexOf(n) > -1; }).slice(0, 60);
			if (!rows.length) { ul.appendChild(h('p', { class: 'rp-empty-s', text: 'Nic nie pasuje.' })); }
			rows.forEach(function (p) {
				ul.appendChild(h('button', { type: 'button', class: 'rp-row', onclick: function () { K.closeSheet(); onPick(p); } }, [h('span', { class: 'rp-row-main' }, [h('strong', { text: p.name + (p.hidden ? ' (ukryty)' : '') }), p.cats ? h('small', { text: p.cats }) : null])]));
			});
		}
		q.addEventListener('input', draw);
		draw();
		K.openSheet(title, h('div', { class: 'rp-form' }, [q, ul]));
	}

	function slotSummary(sl, days) {
		var bits = [];
		if (sl.date) { bits.push(K.dateLabel(sl.date) + (sl.override ? ' (zastępuje)' : ' (dokłada)')); }
		else {
			bits.push(sl.days.length ? sl.days.map(function (k) { return days[k] || k; }).join(', ') : 'codziennie');
			if (sl.date_from || sl.date_to) { bits.push((sl.date_from || '…') + ' – ' + (sl.date_to || '…')); }
		}
		if (sl.from || sl.to) { bits.push((sl.from || '…') + '–' + (sl.to || '…')); }
		return bits.join(' · ');
	}
	function setView(main, d) {
		var z = S.zset, slots = S.zedit;
		main.appendChild(h('button', { type: 'button', class: 'rp-back', onclick: function () {
			if (S.dirty && !window.confirm('Masz niezapisane zmiany w zestawie. Wyjść bez zapisu?')) { return; }
			S.dirty = false; S.zset = null; S.zedit = null; K.render();
		} }, [h('span', { html: K.ICON.back }), 'Wszystkie zestawy']));
		main.appendChild(K.pageHead(z.name, 'Najnowszy termin jest u góry. Termin z konkretną datą jest nadrzędny wobec dni tygodnia; bez „zastępuje” jego dania DOKŁADAJĄ SIĘ do dań z dni tygodnia.', K.btn('+ Termin', function () {
			slots.push({ days: [], date: '', date_from: '', date_to: '', from: '', to: '', override: false, items: [], now: false, isNew: true });
			K.dirty(); K.render();
		}, 'rp-btn-pri')));
		if (!slots.length) { main.appendChild(h('div', { class: 'rp-empty' }, [h('p', { text: 'Brak terminów – dodaj pierwszy. Produkt bez terminów nie jest zestawem.' })])); }
		for (var i = slots.length - 1; i >= 0; i--) { main.appendChild(slotCard(slots, i, d)); }
		if (z.edit) { main.appendChild(h('p', { class: 'rp-muted' }, ['To samo w edycji produktu (zakładka „Zestaw”): ', h('a', { href: z.edit, text: 'otwórz w WooCommerce' }), '.'])); }
		main.appendChild(K.saveBar(function (b) {
			var empty = slots.filter(function (s) { return !s.items.length; }).length;
			if (empty && !window.confirm('Terminy bez dań (' + empty + ') nie dają żadnego dania. Zapisać mimo to?')) { return; }
			var bad = slots.filter(function (s) { return s.from && s.to && s.from > s.to; }).length;
			if (bad) { K.toast('W ' + bad + ' terminach godzina „od” jest późniejsza niż „do”.', true); return; }
			K.busy(b, true);
			K.api('set_save', { id: z.id, slots: slots.map(function (s) {
				return { days: s.days, date: s.date, date_from: s.date_from, date_to: s.date_to, from: s.from, to: s.to, override: s.date && s.override ? 1 : 0, items: s.items.map(function (it) { return { product_id: it.product_id, type: it.type, photo: it.photo ? 1 : 0 }; }) };
			}) }).then(function (x) {
				S.data.sets = { sets: x.sets, products: x.products, days: x.days, now: x.now };
				S.zset = x.set; S.zedit = copy(x.set.slots); S.dirty = false; K.toast(x.message); K.render();
			}, function (e) { K.busy(b, false); K.toast(e.message, true); });
		}, 'Zapisz zestaw'));
	}
	function slotCard(slots, i, d) {
		var sl = slots[i];
		var days = d.days;
		function ch() { K.dirty(); }
		var dayBox = h('div', { class: 'rp-days' }, Object.keys(days).map(function (k) {
			var on = sl.days.indexOf(k) > -1;
			return h('button', { type: 'button', class: 'rp-day' + (on ? ' on' : ''), 'aria-pressed': on ? 'true' : 'false', text: days[k], onclick: function (e) {
				var at = sl.days.indexOf(k);
				if (at > -1) { sl.days.splice(at, 1); } else { sl.days.push(k); }
				e.currentTarget.classList.toggle('on', at < 0); e.currentTarget.setAttribute('aria-pressed', at < 0 ? 'true' : 'false'); ch();
			} });
		}));
		function inp(type, key, label) { return h('input', { type: type, class: 'rp-in', value: sl[key] || '', 'aria-label': label, onchange: function (e) { sl[key] = e.target.value; ch(); if (key === 'date') { K.render(); } } }); }
		var ov = h('input', { type: 'checkbox', checked: sl.override, disabled: sl.date ? null : true, onchange: function () { sl.override = ov.checked; ch(); } });
		var items = h('div', { class: 'rp-zitems' });
		sl.items.forEach(function (it, j) {
			var type = h('select', { class: 'rp-in', 'aria-label': 'Rodzaj: ' + it.name, onchange: function () { it.type = type.value; ch(); } }, [
				h('option', { value: 'main', selected: it.type === 'main', text: 'Danie główne' }),
				h('option', { value: 'addon', selected: it.type === 'addon', text: 'Dodatek opcjonalny' })
			]);
			var ph = h('input', { type: 'checkbox', checked: it.photo, onchange: function () { sl.items.forEach(function (x) { x.photo = false; }); it.photo = ph.checked; ch(); K.render(); } });
			items.appendChild(h('div', { class: 'rp-zitem' }, [
				h('strong', { text: it.name }),
				type,
				h('label', { class: 'rp-check', title: 'Zdjęcie tego dania będzie zdjęciem zestawu na liście' }, [ph, h('span', { text: 'zdjęcie' })]),
				h('span', { class: 'rp-zitem-b' }, [
					h('button', { type: 'button', class: 'rp-ico', 'aria-label': 'W górę', text: '↑', disabled: j === 0 ? true : null, onclick: function () { sl.items.splice(j - 1, 0, sl.items.splice(j, 1)[0]); ch(); K.render(); } }),
					h('button', { type: 'button', class: 'rp-ico', 'aria-label': 'Usuń ' + it.name, html: K.ICON.x, onclick: function () { sl.items.splice(j, 1); ch(); K.render(); } })
				])
			]));
		});
		var num = slots.length - i;
		return h('section', { class: 'rp-card rp-zslot' + (sl.isNew ? ' new' : '') }, [
			h('div', { class: 'rp-zslot-h' }, [
				h('div', null, [h('h2', { text: 'Termin ' + num }), h('small', { class: 'rp-muted', text: slotSummary(sl, days) })]),
				sl.isNew ? h('span', { class: 'rp-pill', text: 'nowy' }) : h('span', { class: 'rp-pill' + (sl.now ? ' ok' : ''), text: sl.now ? 'aktywny teraz' : 'nieaktywny teraz' })
			]),
			h('div', { class: 'rp-field' }, [h('span', { class: 'rp-label', text: 'Dni tygodnia' }), dayBox, h('small', { class: 'rp-hint', text: 'Nic nie zaznaczone = codziennie (chyba że ustawisz konkretną datę).' })]),
			h('div', { class: 'rp-grid2' }, [K.field('Zakres dat: od', inp('date', 'date_from', 'Zakres od'), 'Oba dni włącznie; działa razem z dniami tygodnia.'), K.field('do', inp('date', 'date_to', 'Zakres do'))]),
			h('div', { class: 'rp-grid2' }, [
				K.field('Albo konkretna data', inp('date', 'date', 'Konkretna data'), 'Nadrzędna wobec dni tygodnia.'),
				h('label', { class: 'rp-check rp-check-top' }, [ov, h('span', { text: 'Zastępuje inne terminy w tym dniu (bez zaznaczenia dania się dokładają)' })])
			]),
			h('div', { class: 'rp-grid2' }, [K.field('Godziny: od', inp('time', 'from', 'Godzina od'), 'Puste = cały dzień.'), K.field('do', inp('time', 'to', 'Godzina do'))]),
			h('div', { class: 'rp-field' }, [h('span', { class: 'rp-label', text: 'Dania (' + sl.items.length + ')' }), items,
				K.btn('+ Dodaj danie', function () {
					pickProduct('Dodaj danie do terminu', d.products.filter(function (p) { return p.id !== S.zset.id; }), function (p) {
						sl.items.push({ product_id: p.id, name: p.name, type: 'main', photo: false }); ch(); K.render();
					});
				})
			]),
			h('div', { class: 'rp-actions' }, [
				K.btn('Duplikuj termin', function () { var c = copy(sl); c.isNew = true; c.now = false; slots.push(c); ch(); K.render(); K.toast('Kopia terminu jest na górze.'); }),
				K.btn('Usuń termin', function () { if (!window.confirm('Usunąć termin ' + num + ' (' + slotSummary(sl, days) + ')?')) { return; } slots.splice(i, 1); ch(); K.render(); }, 'rp-btn-del')
			])
		]);
	}

	K.sections.zestawy = secSets;
})();
