/* Restauracja – Panel restauracji: sekcja SEO (2.46.0). Zakładki: Wizytówka (dane restauracji, godziny,
 * kod dla osobnej strony głównej), Udostępnianie (Open Graph z podglądem karty Facebooka), Indeksowanie
 * (co jest ukryte przed Google, mapa witryny, kody weryfikacji), Do poprawy (lista z naprawami).
 * Pola – formularz ze schematu (rzd-panel-formy.js); dane i działanie – moduł 35-seo. */
(function () {
	'use strict';
	var K = window.rzdPanelKit;
	if (!K) { return; }
	var h = K.h, S = K.S;
	var TABS = [['wizytowka', 'Wizytówka'], ['udostepnianie', 'Udostępnianie'], ['indeksowanie', 'Indeksowanie'], ['poprawki', 'Do poprawy']];
	function copy(o) { return JSON.parse(JSON.stringify(o)); }
	function done(x) { S.data.seo = x; S.work.seo = null; S.dirty = false; K.toast(x.message); K.render(); K.refreshWarnings(); }
	function fail(b) { return function (e) { K.busy(b, false); K.toast(e.message, true); }; }
	function ext(url, text) { return h('a', { href: url, target: '_blank', rel: 'noopener', text: text + ' ↗' }); }

	function secSeo(main) {
		var d = S.data.seo;
		if (!d) {
			K.loading(main, 'SEO');
			K.load('seo', 'seo').then(K.render).catch(function (e) { main.textContent = ''; K.failBox(main, e, K.render); });
			return;
		}
		if (!S.work.seo) { S.work.seo = copy(d.values); }
		var vals = S.work.seo;
		var tab = TABS.some(function (t) { return t[0] === S.tab; }) ? S.tab : 'wizytowka';
		var bad = d.audit.filter(function (a) { return a.level === 'error' || a.level === 'warning'; }).length;
		main.appendChild(K.pageHead('SEO', 'Jak sklep widzą Google i Facebook: wizytówka restauracji, menu dla wyszukiwarki, udostępnianie linków, co ukryć przed wyszukiwarką.'));
		main.appendChild(K.tabsEl(TABS.map(function (t) { return t[0] === 'poprawki' && bad ? [t[0], t[1] + ' (' + bad + ')'] : t; }), tab));
		if (!d.public && tab !== 'poprawki') { main.appendChild(publicBox(d)); }
		if (d.plugin && tab !== 'poprawki') { main.appendChild(h('p', { class: 'rp-fnote warn', text: 'Działa wtyczka ' + d.plugin + ' – ona ustawia tytuły, opisy, udostępnianie, kody weryfikacji i mapę witryny. Tu zostają: wizytówka restauracji, menu dla Google, ukrycie stron obsługi i lista „do poprawy”.' })); }
		if (tab === 'udostepnianie') { share(main, d, vals); }
		else if (tab === 'indeksowanie') { index(main, d, vals); }
		else if (tab === 'poprawki') { audit(main, d); return; }
		else { card(main, d, vals); }
		main.appendChild(K.saveBar(function (b) {
			K.busy(b, true);
			K.api('seo_save', { values: vals }).then(done, fail(b));
		}, 'Zapisz SEO'));
	}

	function publicBox(d) {
		return h('div', { class: 'rp-warn err', role: 'alert' }, [
			h('span', { text: 'Strona jest ukryta przed wyszukiwarkami (WordPress: „Proś wyszukiwarki o nieindeksowanie”). Google nie pokaże sklepu, dopóki to jest włączone.' }),
			K.btn('Odkryj stronę', function (e) {
				if (!window.confirm('Pozwolić wyszukiwarkom indeksować stronę? (Na stronie testowej zwykle tego NIE chcesz.)')) { return; }
				K.busy(e.currentTarget, true);
				K.api('seo_public', {}).then(done, fail(e.currentTarget));
			}, 'rp-btn-link')
		]);
	}

	/* ---------- Wizytówka ---------- */
	function card(main, d, vals) {
		main.appendChild(K.sform({ schema: d.card, values: vals, imgs: d.imgs, onChange: function () { K.dirty(); } }));
		if (d.values.mode === 'separate' && d.snippet) {
			var ta = h('textarea', { class: 'rp-in rp-code rp-snippet', rows: '12', readonly: true, spellcheck: 'false', 'aria-label': 'Kod wizytówki dla strony głównej' });
			ta.value = d.snippet;
			var state = d.stale ? h('p', { class: 'rp-fnote warn', text: 'Dane zmieniły się od ostatniego kopiowania – skopiuj kod ponownie i podmień go na stronie głównej.' })
				: (d.copied ? h('p', { class: 'rp-fnote', text: '✓ Kod skopiowany. Gdy zmienisz godziny, adres albo miejscowości, panel przypomni o ponownym skopiowaniu.' })
					: h('p', { class: 'rp-fnote warn', text: 'Kod jeszcze nie był kopiowany.' }));
			main.appendChild(h('section', { class: 'rp-card rp-form' }, [
				h('h2', { text: 'Kod dla strony głównej' }),
				h('p', { class: 'rp-muted', text: 'Wklej ten kod w HTML strony głównej (' + d.values.main_url + '), w sekcji <head> – przed </head>. To pełna wizytówka restauracji dla Google, z przyciskiem „Zamów online” prowadzącym do tego sklepu i menu z listy dań. Kod pokazuje ZAPISANE dane.' }),
				state, ta,
				h('div', { class: 'rp-actions' }, [
					K.btn('Kopiuj kod', function (e) {
						if (S.dirty) { K.toast('Najpierw zapisz zmiany – kod pokazuje zapisane dane.', true); return; }
						var b = e.currentTarget;
						var ok = function () { K.busy(b, true); K.api('seo_copied', {}).then(done, fail(b)); };
						if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(d.snippet).then(ok, function () { ta.select(); K.toast('Zaznaczyłem kod – skopiuj Ctrl+C.', true); }); }
						else { ta.select(); try { document.execCommand('copy'); ok(); } catch (er) { K.toast('Zaznaczyłem kod – skopiuj Ctrl+C.', true); } }
					}, 'rp-btn-pri'),
					d.tests.main ? ext(d.tests.main, 'Sprawdź stronę główną w Google') : null
				])
			]));
		}
		main.appendChild(h('p', { class: 'rp-muted' }, [ext(d.tests.google, 'Test wyników rozszerzonych Google – ta strona'), d.tests.menu ? ' · ' : '', d.tests.menu ? ext(d.tests.menu, 'lista dań (menu)') : '']));
	}

	/* ---------- Udostępnianie ---------- */
	function share(main, d, vals) {
		var pv = h('div', { class: 'rp-ogcard' });
		function draw() {
			pv.textContent = '';
			var img = (vals.og_image_id && (d.imgs[vals.og_image_id] || (vals.og_image_id === d.values.og_image_id ? d.og.imgL : ''))) || d.og.logo;
			pv.appendChild(img ? h('div', { class: 'rp-ogcard-img', style: 'background-image:url("' + String(img).replace(/["\\]/g, '') + '")' }) : h('div', { class: 'rp-ogcard-img none', text: 'brak obrazka' }));
			pv.appendChild(h('div', { class: 'rp-ogcard-t' }, [h('small', { text: (d.og.host || '').toUpperCase() }), h('strong', { text: d.og.title }), h('span', { text: vals.og_desc || '' })]));
		}
		main.appendChild(K.sform({ schema: d.share, values: vals, imgs: d.imgs, onChange: function () { K.dirty(); draw(); } }));
		draw();
		main.appendChild(h('section', { class: 'rp-card' }, [
			h('h2', { text: 'Tak mniej więcej wygląda link na Facebooku' }), pv,
			h('p', { class: 'rp-muted' }, ['Danie pokazuje swoje zdjęcie, nazwę i cenę; zestaw – zdjęcie dzisiejszego dania. Facebook pamięta stary obrazek – po zmianie odśwież go w ', ext(d.tests.fb, 'debugerze Facebooka'), ' („Pobierz ponownie”).'])
		]));
	}

	/* ---------- Indeksowanie ---------- */
	function index(main, d, vals) {
		main.appendChild(h('section', { class: 'rp-card' }, [
			h('h2', { text: 'Co widzi Google' }),
			h('ul', { class: 'rp-status' }, d.index.map(function (it) {
				return h('li', { class: it.ok ? 'ok' : 'bad' }, [h('span', { class: 'rp-status-i', 'aria-hidden': 'true', text: it.ok ? '✓' : '!' }), h('span', { class: 'rp-status-t' }, [h('strong', { text: it.label + ': ' }), it.url ? h('a', { href: it.url, target: '_blank', rel: 'noopener', text: it.text }) : h('span', { text: it.text })])]);
			})),
			h('p', { class: 'rp-muted', text: 'Strony obsługi (Kuchnia, Panel, Edycja menu, Sala, Kurier) dostają „noindex” w kodzie strony i w nagłówku odpowiedzi – działa też przy innych wtyczkach SEO. Dania z kategorii „Nie wyświetlaj w sklepie” i „tylko na miejscu” nie trafiają do Google ani do mapy witryny.' })
		]));
		main.appendChild(K.sform({ schema: d.verify, values: vals, onChange: function () { K.dirty(); } }));
	}

	/* ---------- Do poprawy ---------- */
	function audit(main, d) {
		var l = h('div', { class: 'rp-audit' });
		d.audit.forEach(function (a) {
			var kids = [h('div', { class: 'rp-audit-h' }, [h('span', { class: 'rp-audit-i', 'aria-hidden': 'true', text: { error: '!', warning: '!', info: 'i', ok: '✓' }[a.level] }), h('span', { text: a.text })])];
			if (a.items && a.items.length) {
				kids.push(h('ul', { class: 'rp-audit-l' }, a.items.map(function (it) { return h('li', null, [it.url ? h('a', { href: it.url, target: '_blank', rel: 'noopener', text: it.name }) : h('span', { text: it.name })]); }).concat(a.count > a.items.length ? [h('li', { class: 'rp-muted', text: '… i ' + (a.count - a.items.length) + ' więcej' })] : [])));
			}
			if (a.fix) {
				kids.push(h('div', { class: 'rp-actions' }, [K.btn(a.fix.label, function (e) {
					if (a.fix.type === 'tab') { K.setTab(a.fix.tab); return; }
					if (a.fix.type === 'action') {
						if (a.fix.action === 'seo_public' && !window.confirm('Pozwolić wyszukiwarkom indeksować stronę? (Na stronie testowej zwykle tego NIE chcesz.)')) { return; }
						K.busy(e.currentTarget, true);
						K.api(a.fix.action, {}).then(done, fail(e.currentTarget));
					}
				}, a.level === 'error' ? 'rp-btn-pri' : '')]));
			}
			l.appendChild(h('section', { class: 'rp-card rp-audit-c ' + a.level }, kids));
		});
		main.appendChild(l);
		main.appendChild(h('p', { class: 'rp-muted' }, ['Oficjalne testy: ', ext(d.tests.google, 'Google – wyniki rozszerzone'), ' · ', ext(d.tests.fb, 'Facebook – podgląd linku'), '. Linki z dań otwierają Edycję menu na tym daniu.']));
	}

	K.sections.seo = secSeo;
})();
