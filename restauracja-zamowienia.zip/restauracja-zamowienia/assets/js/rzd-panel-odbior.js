/* Restauracja – Panel restauracji: Terminy → Odbiór osobisty (2.47.0). Formularz ze schematu (rzd-panel-formy.js),
 * zapis akcją pickup_save (moduł 36, rzd_pickup_save). */
(function () {
	'use strict';
	var K = window.rzdPanelKit;
	if (!K) { return; }
	var h = K.h, S = K.S;
	function copy(o) { return JSON.parse(JSON.stringify(o)); }

	K.termTabs.odbior = function (main) {
		var d = S.data.pickup;
		if (!d) {
			main.appendChild(h('p', { class: 'rp-load', text: 'Wczytuję…' }));
			K.load('pickup', 'pickup').then(K.render).catch(function (e) { main.textContent = ''; K.failBox(main, e, K.render); });
			return;
		}
		if (!S.work.pickup) { S.work.pickup = copy(d.values); }
		var vals = S.work.pickup;
		main.appendChild(K.sform({ schema: d.schema, values: vals, onChange: K.dirty }));
		main.appendChild(K.saveBar(function (b) {
			K.busy(b, true);
			K.api('pickup_save', { values: vals }).then(function (x) {
				S.data.pickup = x; S.work.pickup = null; S.dirty = false; K.toast(x.message); K.render(); K.refreshWarnings();
			}, function (e) { K.busy(b, false); K.toast(e.message, true); });
		}, 'Zapisz odbiór osobisty'));
	};
})();
