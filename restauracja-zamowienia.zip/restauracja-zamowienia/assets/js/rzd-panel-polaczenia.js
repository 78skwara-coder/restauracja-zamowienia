/* Restauracja – Panel restauracji: sekcja „Połączenia API” (2.51.0, moduł 39-api). Gemini (klucz, model, Test AI,
 * ostatnie zapytanie) i Facebook (ID strony, token, Sprawdź połączenie) – wspólne dla Post dnia i Opisów AI;
 * kafelki pozostałych integracji. Klucze nie wracają do przeglądarki. Tekst zawsze przez textContent / value. */
(function () {
	'use strict';
	var K = window.rzdPanelKit;
	if (!K) { return; }
	var h = K.h, S = K.S;
	function copy(o) { return JSON.parse(JSON.stringify(o)); }
	function fail(b) { return function (e) { K.busy(b, false); K.toast(e.message, true); }; }
	function stat(on, txt) { return h('span', { class: 'rp-pstat rp-pstat-' + (on ? 'published' : 'none'), text: txt }); }

	function secApi(main) {
		var d = S.data.api;
		if (!d) {
			K.loading(main, 'Połączenia API');
			K.load('api', 'api').then(K.render).catch(function (e) { main.textContent = ''; K.failBox(main, e, K.render); });
			return;
		}
		if (!S.work.api) { S.work.api = copy(d.values); }
		var v = S.work.api;
		function inp(k, attrs) {
			return h('input', Object.assign({ class: 'rp-in', value: v[k] == null ? '' : String(v[k]), oninput: function (e) { v[k] = e.target.value; K.dirty(); } }, attrs || {}));
		}
		main.appendChild(K.pageHead('Połączenia API', 'Klucze i połączenia z zewnętrznymi usługami w jednym miejscu. Korzystają z nich Post dnia (AI + Facebook) i Opisy AI w Edycji menu.'));

		// AI – trzech dostawców (2.53.0); jedno „Generuj” = jedno zapytanie do wybranego
		var HELP = {
			gemini: ['Klucz z aistudio.google.com → Get API key (jest darmowy próg).', '„Flash” wystarczy do postów i opisów (szybki i tani).'],
			claude: ['Klucz z console.anthropic.com → API Keys. Konto API jest osobne od abonamentu Claude – płatność za użycie (doładowanie od 5 USD).', 'Do postów i opisów wystarczy najmniejszy model (Haiku) – szybki i najtańszy.'],
			openai: ['Klucz z platform.openai.com → API keys. Konto API jest osobne od ChatGPT Plus – przedpłata (od 5 USD, kredyty ważne rok).', 'Do postów i opisów wystarczy model „mini” albo „nano”.']
		};
		var last = h('p', { class: 'rp-muted', text: d.lastCall ? 'Ostatnie zapytanie do AI: ' + d.lastCall : 'Jeszcze nie było zapytania do AI.' });
		d.providers.forEach(function (pv) {
			var card = h('section', { class: 'rp-card' }, [h('h2', null, ['AI – ' + pv.n + ' ', stat(pv.ready, pv.ready ? 'połączone' : (pv.hasKey && !pv.hasModel ? 'klucz zapisany, brak modelu' : 'nie ustawione'))])]);
			card.appendChild(K.field('Klucz API', inp(pv.keyField, { type: 'password', autocomplete: 'new-password', 'aria-label': 'Klucz API – ' + pv.n, placeholder: pv.keyConst ? 'ustawiony w wp-config.php' : (pv.hasKey ? '•••••• zapisany – wpisz nowy, żeby zmienić („-” usuwa)' : 'wklej klucz API') }), HELP[pv.k][0] + ' Zapisany w bazie zaszyfrowany.'));
			var mk = pv.modelField;
			var model = h('select', { class: 'rp-in', 'aria-label': 'Model AI – ' + pv.n, onchange: function () { v[mk] = model.value; K.dirty(); } }, [h('option', { value: v[mk] || '', text: v[mk] || '— wybierz (Pobierz listę) —' })]);
			card.appendChild(K.field('Model', h('div', { class: 'rp-inline' }, [model, K.btn('Pobierz listę modeli', function (e) {
				var b = e.currentTarget; K.busy(b, true);
				K.api('api_models', { provider: pv.k, key: v[pv.keyField] || '' }).then(function (x) {
					K.busy(b, false);
					model.textContent = '';
					x.models.forEach(function (m) { model.appendChild(h('option', { value: m.id, text: m.name === m.id ? m.id : m.name + ' (' + m.id + ')', selected: m.id === v[mk] ? true : null })); });
					if (!v[mk] && x.models[0]) {
						var re = pv.k === 'gemini' ? /flash/i : (pv.k === 'claude' ? /haiku/i : /mini/i);
						var pref = x.models.filter(function (m) { return re.test(m.id) && !/lite|preview|exp|nano/i.test(m.id); })[0] || x.models[0];
						v[mk] = pref.id; model.value = pref.id; K.dirty();
					}
					K.toast('Modele: ' + x.models.length + '.');
				}, fail(b));
			})]), HELP[pv.k][1]));
			card.appendChild(h('div', { class: 'rp-inline' }, [K.btn('Test AI', function (e) {
				if (S.dirty) { K.toast('Najpierw zapisz połączenia.', true); return; }
				var b = e.currentTarget; K.busy(b, true);
				K.api('api_ai_test', { provider: pv.k }).then(function (x) { K.busy(b, false); K.toast(x.message); last.textContent = 'Ostatnie zapytanie do AI: ' + x.lastCall; }, function (er) {
					K.busy(b, false); K.toast(er.message, true);
					K.api('api', {}).then(function (y) { last.textContent = y.lastCall ? 'Ostatnie zapytanie do AI: ' + y.lastCall : last.textContent; });
				});
			})]));
			main.appendChild(card);
		});
		var dc = h('section', { class: 'rp-card' }, [h('h2', { text: 'Domyślny dostawca AI' })]);
		var ready = d.providers.filter(function (x) { return x.ready; });
		var dsel = h('select', { class: 'rp-in rp-in-m', 'aria-label': 'Domyślny dostawca AI', disabled: ready.length ? null : true, onchange: function () { v.ai_default = dsel.value; K.dirty(); } }, d.providers.map(function (x) {
			return h('option', { value: x.k, text: x.n + (x.ready ? '' : ' (brak klucza / modelu)'), disabled: x.ready ? null : true, selected: x.k === d.aiDefault ? true : null });
		}));
		dc.appendChild(K.field('Zaznaczony przy „Generuj” w Post dnia i Opisach AI', dsel, ready.length ? 'Przy każdym generowaniu możesz wybrać innego – tylko spośród połączonych. Jedno „Generuj” to jedno zapytanie do jednego dostawcy.' : 'Najpierw połącz choć jednego dostawcę (klucz + model, zapisz).'));
		dc.appendChild(last);
		main.appendChild(dc);

		// Facebook
		var fb = h('section', { class: 'rp-card' }, [h('h2', null, ['Facebook – strona ', stat(d.status.fb, d.status.fb ? 'połączone' : 'nie ustawione')])]);
		fb.appendChild(K.field('ID strony', inp('fb_page', { inputmode: 'numeric', placeholder: 'np. 102345678901234' }), 'Strona → Informacje → Przejrzystość strony, albo z narzędzia Graph API Explorer.'));
		fb.appendChild(K.field('Token strony (długoterminowy)', inp('fb_token', { type: 'password', autocomplete: 'new-password', placeholder: d.tokConst ? 'ustawiony w wp-config.php' : (d.hasToken ? '•••••• zapisany – wpisz nowy, żeby zmienić („-” usuwa)' : 'wklej token strony') }), 'Token strony z uprawnieniami pages_manage_posts, pages_read_engagement, pages_show_list (aplikacja Meta for Developers). Możesz wkleić też token swojego konta – „Sprawdź połączenie” sam pobierze z niego token strony (z długoterminowego – bez wygasania). Zapisany zaszyfrowany.'));
		fb.appendChild(h('div', { class: 'rp-inline' }, [K.btn('Sprawdź połączenie', function (e) {
			if (S.dirty) { K.toast('Najpierw zapisz połączenia.', true); return; }
			var b = e.currentTarget; K.busy(b, true);
			K.api('api_fb_check', {}).then(function (x) { K.busy(b, false); K.toast(x.message); S.data.api = null; S.data.posts = null; K.render(); }, fail(b));
		})]));
		main.appendChild(fb);

		// (2.55.0) Instagram – konto profesjonalne połączone ze stroną; ten sam token strony
		var ig = h('section', { class: 'rp-card' }, [h('h2', null, ['Instagram ', stat(d.status.ig, d.status.ig ? '@' + (d.status.ig_user || '') : 'nie połączone')])]);
		ig.appendChild(h('p', { class: 'rp-muted', text: 'Posty z Post dnia mogą wychodzić też na Instagram – ten sam tekst i zdjęcia (docięte do 4:5 – 1,91:1), o tej samej godzinie. Warunki: konto profesjonalne (firmowe / twórcy) połączone z Waszą stroną na Facebooku oraz token strony z uprawnieniami instagram_basic i instagram_content_publish (dopisz je w aplikacji Meta i wygeneruj token jeszcze raz). Osobnego klucza nie ma.' }));
		ig.appendChild(h('div', { class: 'rp-inline' }, [K.btn('Sprawdź Instagram', function (e) {
			if (S.dirty) { K.toast('Najpierw zapisz połączenia.', true); return; }
			var b = e.currentTarget; K.busy(b, true);
			K.api('api_ig_check', {}).then(function (x) { K.busy(b, false); K.toast(x.message); S.data.api = x; S.data.posts = null; K.render(); }, fail(b));
		})]));
		main.appendChild(ig);

		// Pozostałe integracje
		var ot = h('section', { class: 'rp-card' }, [h('h2', { text: 'Inne integracje' })]);
		(d.others || []).forEach(function (o) {
			ot.appendChild(h('div', { class: 'rp-phist-r rp-api-other' }, [
				h('span', { class: 'rp-phist-noimg' }),
				h('div', null, [h('strong', { text: o.n }), ' ', o.on === null ? null : stat(o.on, o.on ? 'włączone' : 'wyłączone'), h('div', { class: 'rp-muted', text: o.d }), h('div', { class: 'rp-muted', text: o.note })]),
				o.url ? h('a', { class: 'rp-btn', href: o.url, text: 'Otwórz' }) : h('span')
			]));
		});
		ot.appendChild(h('p', { class: 'rp-muted', text: 'W przyszłości tutaj: SMS.' }));
		main.appendChild(ot);

		main.appendChild(K.saveBar(function (b) {
			K.busy(b, true);
			K.api('api_save', { values: v }).then(function (x) { S.data.api = x; S.data.posts = null; S.work.api = null; S.dirty = false; K.toast(x.message); K.render(); }, fail(b));
		}, 'Zapisz połączenia'));
	}

	K.sections.polaczenia = secApi;
})();
