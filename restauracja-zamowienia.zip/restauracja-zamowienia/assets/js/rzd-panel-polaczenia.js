/* Restauracja – Panel restauracji: sekcja „Połączenia API” (2.51.0, moduł 39-api). Gemini (klucz, model, Test AI,
 * ostatnie zapytanie) i Facebook (ID strony, token, Sprawdź połączenie) – wspólne dla Post dnia i Opisów AI;
 * kafelki pozostałych integracji. Klucze nie wracają do przeglądarki. Tekst zawsze przez textContent / value. */
(function () {
	'use strict';
	var K = window.rzdPanelKit;
	if (!K) { return; }
	var h = K.h, S = K.S;
	function copy(o) { return JSON.parse(JSON.stringify(o)); }
	function fail(b) { return function (e) { K.busy(b, false); K.toast(e.message, true); }; }
	function stat(on, txt) { return h('span', { class: 'rp-pstat rp-pstat-' + (on ? 'published' : 'none'), text: txt }); }

	function secApi(main) {
		var d = S.data.api;
		if (!d) {
			K.loading(main, 'Połączenia API');
			K.load('api', 'api').then(K.render).catch(function (e) { main.textContent = ''; K.failBox(main, e, K.render); });
			return;
		}
		if (!S.work.api) { S.work.api = copy(d.values); }
		var v = S.work.api;
		function inp(k, attrs) {
			return h('input', Object.assign({ class: 'rp-in', value: v[k] == null ? '' : String(v[k]), oninput: function (e) { v[k] = e.target.value; K.dirty(); } }, attrs || {}));
		}
		main.appendChild(K.pageHead('Połączenia API', 'Klucze i połączenia z zewnętrznymi usługami w jednym miejscu. Korzystają z nich Post dnia (AI + Facebook) i Opisy AI w Edycji menu.'));

		// Gemini
		var g = h('section', { class: 'rp-card' }, [h('h2', null, ['AI – Google Gemini ', stat(d.status.ai, d.status.ai ? 'połączone' : 'nie ustawione')])]);
		g.appendChild(K.field('Klucz API Gemini', inp('gemini_key', { type: 'password', autocomplete: 'off', placeholder: d.keyConst ? 'ustawiony w wp-config.php' : (d.hasKey ? '•••••• zapisany – wpisz nowy, żeby zmienić („-” usuwa)' : 'wklej klucz z Google AI Studio') }), 'Klucz z aistudio.google.com → Get API key. Zapisany w bazie zaszyfrowany.'));
		var model = h('select', { class: 'rp-in', 'aria-label': 'Model AI', onchange: function () { v.model = model.value; K.dirty(); } }, [h('option', { value: v.model || '', text: v.model || '— wybierz (Pobierz listę) —' })]);
		g.appendChild(K.field('Model', h('div', { class: 'rp-inline' }, [model, K.btn('Pobierz listę modeli', function (e) {
			var b = e.currentTarget; K.busy(b, true);
			K.api('api_models', { key: v.gemini_key || '' }).then(function (x) {
				K.busy(b, false);
				model.textContent = '';
				x.models.forEach(function (m) { model.appendChild(h('option', { value: m.id, text: m.name + ' (' + m.id + ')', selected: m.id === v.model ? true : null })); });
				if (!v.model && x.models[0]) { var pref = x.models.filter(function (m) { return /flash/i.test(m.id) && !/lite|preview|exp/i.test(m.id); })[0] || x.models[0]; v.model = pref.id; model.value = pref.id; K.dirty(); }
				K.toast('Modele: ' + x.models.length + '.');
			}, fail(b));
		})]), 'Lista z Google – modele szybko się zmieniają. „Flash” wystarczy do postów i opisów (szybki i tani).'));
		var last = h('p', { class: 'rp-muted', text: d.lastCall ? 'Ostatnie zapytanie do Gemini: ' + d.lastCall : 'Jeszcze nie było zapytania do Gemini.' });
		g.appendChild(last);
		g.appendChild(h('div', { class: 'rp-inline' }, [K.btn('Test AI', function (e) {
			if (S.dirty) { K.toast('Najpierw zapisz połączenia.', true); return; }
			var b = e.currentTarget; K.busy(b, true);
			K.api('api_ai_test', {}).then(function (x) { K.busy(b, false); K.toast(x.message); last.textContent = 'Ostatnie zapytanie do Gemini: ' + x.lastCall; }, function (er) {
				K.busy(b, false); K.toast(er.message, true);
				K.api('api', {}).then(function (y) { last.textContent = y.lastCall ? 'Ostatnie zapytanie do Gemini: ' + y.lastCall : last.textContent; });
			});
		})]));
		main.appendChild(g);

		// Facebook
		var fb = h('section', { class: 'rp-card' }, [h('h2', null, ['Facebook – strona ', stat(d.status.fb, d.status.fb ? 'połączone' : 'nie ustawione')])]);
		fb.appendChild(K.field('ID strony', inp('fb_page', { inputmode: 'numeric', placeholder: 'np. 102345678901234' }), 'Strona → Informacje → Przejrzystość strony, albo z narzędzia Graph API Explorer.'));
		fb.appendChild(K.field('Token strony (długoterminowy)', inp('fb_token', { type: 'password', autocomplete: 'off', placeholder: d.tokConst ? 'ustawiony w wp-config.php' : (d.hasToken ? '•••••• zapisany – wpisz nowy, żeby zmienić („-” usuwa)' : 'wklej token strony') }), 'Token strony z uprawnieniami pages_manage_posts, pages_read_engagement, pages_show_list (aplikacja Meta for Developers). Możesz wkleić też token swojego konta – „Sprawdź połączenie” sam pobierze z niego token strony (z długoterminowego – bez wygasania). Zapisany zaszyfrowany.'));
		fb.appendChild(h('div', { class: 'rp-inline' }, [K.btn('Sprawdź połączenie', function (e) {
			if (S.dirty) { K.toast('Najpierw zapisz połączenia.', true); return; }
			var b = e.currentTarget; K.busy(b, true);
			K.api('api_fb_check', {}).then(function (x) { K.busy(b, false); K.toast(x.message); S.data.api = null; S.data.posts = null; K.render(); }, fail(b));
		})]));
		main.appendChild(fb);

		// Pozostałe integracje
		var ot = h('section', { class: 'rp-card' }, [h('h2', { text: 'Inne integracje' })]);
		(d.others || []).forEach(function (o) {
			ot.appendChild(h('div', { class: 'rp-phist-r rp-api-other' }, [
				h('span', { class: 'rp-phist-noimg' }),
				h('div', null, [h('strong', { text: o.n }), ' ', o.on === null ? null : stat(o.on, o.on ? 'włączone' : 'wyłączone'), h('div', { class: 'rp-muted', text: o.d }), h('div', { class: 'rp-muted', text: o.note })]),
				o.url ? h('a', { class: 'rp-btn', href: o.url, text: 'Otwórz' }) : h('span')
			]));
		});
		ot.appendChild(h('p', { class: 'rp-muted', text: 'W przyszłości tutaj: Instagram, SMS.' }));
		main.appendChild(ot);

		main.appendChild(K.saveBar(function (b) {
			K.busy(b, true);
			K.api('api_save', { values: v }).then(function (x) { S.data.api = x; S.data.posts = null; S.work.api = null; S.dirty = false; K.toast(x.message); K.render(); }, fail(b));
		}, 'Zapisz połączenia'));
	}

	K.sections.polaczenia = secApi;
})();
