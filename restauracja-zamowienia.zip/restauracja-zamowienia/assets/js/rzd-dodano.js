/* Restauracja – Zamówienia i Dostawy: rzd-dodano.js (z 07-koszyk.php) */
(function () {
	var modal = document.getElementById('kc-added');
	if (!modal) { return; }
	var list = modal.querySelector('.kc-added-list');

	function show(d) {
		if (!d) { return; }
		list.innerHTML = '';
		var main = document.createElement('div');
		main.className = 'kc-added-main';
		main.textContent = d.name + ' × ' + d.qty;
		list.appendChild(main);
		if (d.bar && d.bar.text) { // pasek dostawy (moduł 32) – jedna linijka
			var bar = document.createElement('div');
			bar.className = 'kc-added-bar rzd-dbar-' + d.bar.state;
			bar.textContent = d.bar.text;
			list.appendChild(bar);
		}
		modal.hidden = false;
	}

	function parse(el) {
		try { return JSON.parse(el.getAttribute('data-json')); } catch (e) { return null; }
	}

	// po przeładowaniu strony (dodanie z formularza)
	var holder = document.querySelector('.kc-added-data');
	if (holder) { show(parse(holder)); }

	// po dodaniu przez AJAX (przyciski w pętlach motywu)
	if (window.jQuery) {
		window.jQuery(document.body).on('added_to_cart', function (e, fragments) {
			var html = fragments && fragments['div.kc-added-data'];
			if (!html) { return; }
			var t = document.createElement('div');
			t.innerHTML = html;
			if (t.firstChild) { show(parse(t.firstChild)); }
		});
	}

	modal.querySelector('.kc-added-continue').addEventListener('click', function () {
		modal.hidden = true;
		// "Kontynuuj zakupy" wraca do listy produktów (jeśli jesteśmy gdzie indziej)
		if (kcAddedCfg.listUrl) {
			try {
				var u = new URL(kcAddedCfg.listUrl, window.location.href);
				if (u.pathname.replace(/\/$/, '') !== window.location.pathname.replace(/\/$/, '')) { window.location.href = u.href; }
			} catch (err) {}
		}
	});
	document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !modal.hidden) { modal.hidden = true; } });
})();
