/* Restauracja – Zamówienia i Dostawy: lista – ilość − / +, filtr kategorii (2.26.13: przeniesione z kodu strony do pliku – przeglądarka trzyma go w pamięci podręcznej) */
document.addEventListener('click', function (e) {
		var btn = e.target.closest ? e.target.closest('.rl2-qty-btn') : null;
		if (!btn) { return; }
		var input = btn.parentNode.querySelector('input[type=number]');
		if (!input) { return; }
		var min = parseInt(input.getAttribute('min'), 10) || 1;
		var val = parseInt(input.value, 10) || min;
		val = btn.classList.contains('rl2-qty-plus') ? val + 1 : Math.max(min, val - 1);
		input.value = val;
		input.dispatchEvent(new Event('change', { bubbles: true }));
	});

	// Powrót "wstecz" ze strony produktu → przewiń z powrotem do TEGO produktu
	// na liście, zamiast zostawiać klienta na samej górze. Zapamiętujemy, w
	// który produkt kliknięto (dowolny link z wiersza prowadzący na jego
	// stronę – zdjęcie, nazwa albo "Wybierz"), i przy KAŻDYM wejściu na listę
	// sprawdzamy, czy coś jest zapisane – jeśli tak, przewijamy i od razu
	// kasujemy zapis, żeby nie przewijało ponownie przy zwykłej wizycie.
	document.addEventListener('click', function (e) {
		var link = e.target.closest ? e.target.closest('.rl2-row a.rl-thumb, .rl2-row a.rl-name, .rl2-row a.rl-choose') : null;
		if (!link) { return; }
		var row = link.closest('.rl2-row');
		if (row && row.id) {
			try { sessionStorage.setItem('rzd_last_product', row.id); } catch (err) {}
		}
	});
	(function () {
		var lastId;
		try {
			lastId = sessionStorage.getItem('rzd_last_product');
			sessionStorage.removeItem('rzd_last_product');
		} catch (err) { return; }
		if (!lastId) { return; }
		var el = document.getElementById(lastId);
		if (!el) { return; }
		window.requestAnimationFrame(function () {
			window.requestAnimationFrame(function () { el.scrollIntoView( { block: 'center' } ); });
		});
	})();
	// Każdy filtr działa TYLKO w obrębie swojego własnego kontenera ".rl"
	// (jedno wywołanie shortcode'u), więc kilka list na jednej stronie się nie miesza.
	document.addEventListener('click', function (e) {
		var fbtn = e.target.closest ? e.target.closest('.rl-cat-filter-btn') : null;
		if (!fbtn) { return; }
		var wrap = fbtn.closest('.rl');
		if (!wrap) { return; }
		wrap.querySelectorAll('.rl-cat-filter-btn').forEach(function (b) { b.classList.remove('is-active'); });
		fbtn.classList.add('is-active');
		var cat = fbtn.getAttribute('data-catf');
		wrap.querySelectorAll('.rl2-row').forEach(function (row) {
			if ('all' === cat) { row.style.display = ''; return; }
			var cats = (row.getAttribute('data-catf') || '').split(',');
			row.style.display = cats.indexOf(cat) > -1 ? '' : 'none';
		});
	});

/* 2.27.6: „Pełny opis” – treść pobierana przy pierwszym rozwinięciu ramki
   (lista nie niesie opisów wszystkich dań). Gdy się nie uda – link do
   strony produktu, a przy kolejnym rozwinięciu następna próba. */
document.addEventListener('toggle', function (e) {
	var d = e.target;
	if (!d || !d.matches || !d.matches('details.rl-more[data-rzd-more]') || !d.open) { return; }
	var url = d.getAttribute('data-rzd-more');
	var body = d.querySelector('.rl-more-body');
	if (!url || !body || d.getAttribute('data-rzd-state') === 'ok' || d.getAttribute('data-rzd-state') === 'busy') { return; }
	d.setAttribute('data-rzd-state', 'busy');
	body.innerHTML = '<p class="rl-more-load">Wczytywanie…</p>';
	var fail = function () {
		d.setAttribute('data-rzd-state', 'err');
		var link = d.getAttribute('data-rzd-link');
		body.innerHTML = '<p>Nie udało się wczytać opisu.' + (link ? ' <a href="' + link.replace(/"/g, '&quot;') + '">Zobacz na stronie produktu</a>' : '') + '</p>';
	};
	fetch(url, { credentials: 'same-origin' }).then(function (r) {
		return r.ok ? r.json() : null;
	}).then(function (j) {
		if (j && j.success && j.data && typeof j.data.html === 'string') {
			body.innerHTML = j.data.html;
			d.setAttribute('data-rzd-state', 'ok');
		} else {
			fail();
		}
	}).catch(fail);
}, true);
