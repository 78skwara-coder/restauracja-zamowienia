/* Restauracja – Panel restauracji: sekcja „SMS” (2.58.0, moduł 41-sms). Zakładki: Powiadomienia (4 rodzaje SMS-ów
 * o zamówieniu – włącz, treść ze zmiennymi, licznik części, test), Marketing (zgoda w kasie, kampanie, historia),
 * Zgody (lista, szukaj, wycofaj, CSV), Dziennik (90 dni, numery zamaskowane). Tekst zawsze przez textContent / value. */
(function () {
	'use strict';
	var K = window.rzdPanelKit;
	if (!K) { return; }
	var h = K.h, S = K.S;
	var TABS = [['powiadomienia', 'Powiadomienia'], ['marketing', 'Marketing'], ['zgody', 'Zgody'], ['dziennik', 'Dziennik']];
	var KINDS = { order: 'Zamówienie przyjęte', way: 'Kurier w drodze', ready: 'Gotowe do odbioru', staff: 'Nowe zamówienie (obsługa)', mkt: 'Kampania', test: 'Test' };
	var STAT = { sent: ['wysłany', 'published'], test: ['test – niewysłany', 'scheduled'], error: ['błąd', 'error'] };
	var CST = { plan: ['zaplanowana', 'scheduled'], run: ['w trakcie', 'draft'], done: ['zakończona', 'published'], cancel: ['zatrzymana', 'error'] };
	function copy(o) { return JSON.parse(JSON.stringify(o)); }
	function fail(b) { return function (e) { K.busy(b, false); K.toast(e.message, true); }; }
	function pill(st, map) { var x = map[st] || [st, 'draft']; return h('span', { class: 'rp-pstat rp-pstat-' + x[1], text: x[0] }); }

	/* ---------- licznik części (jak na serwerze: GSM-7 160/153, z polskimi literami 70/67) ---------- */
	var GSM = '@£$¥èéùìòÇ\nØø\rÅåΔ_ΦΓΛΩΠΨΣΘΞÆæßÉ !"#¤%&\'()*+,-./0123456789:;<=>?¡ABCDEFGHIJKLMNOPQRSTUVWXYZÄÖÑÜ§¿abcdefghijklmnopqrstuvwxyzäöñüà';
	var EXT = '^{}\\[~]|€';
	var PL = { 'ą': 'a', 'ć': 'c', 'ę': 'e', 'ł': 'l', 'ń': 'n', 'ó': 'o', 'ś': 's', 'ź': 'z', 'ż': 'z', 'Ą': 'A', 'Ć': 'C', 'Ę': 'E', 'Ł': 'L', 'Ń': 'N', 'Ó': 'O', 'Ś': 'S', 'Ź': 'Z', 'Ż': 'Z', '„': '"', '”': '"', '“': '"', '‘': "'", '’': "'", '–': '-', '—': '-', '…': '...', ' ': ' ' };
	function plain(t) { return String(t).replace(/[ąćęłńóśźżĄĆĘŁŃÓŚŹŻ„”“‘’–—… ]/g, function (c) { return PL[c]; }).normalize('NFD').replace(/[̀-ͯ]/g, ''); }
	function render(t, vars) { return String(t).replace(/\{([a-z_]+)\}/g, function (m, k) { return vars[k] != null ? String(vars[k]) : ''; }).replace(/\s{2,}/g, ' ').trim(); }
	function parts(t) {
		var len = 0, uni = false, ch = Array.from(t);
		for (var i = 0; i < ch.length; i++) {
			if (EXT.indexOf(ch[i]) > -1) { len += 2; } else if (GSM.indexOf(ch[i]) > -1) { len += 1; } else { uni = true; break; }
		}
		if (uni) { len = ch.length; return [len <= 70 ? 1 : Math.ceil(len / 67), len, true]; }
		return [len <= 160 ? 1 : Math.ceil(len / 153), len, false];
	}
	function counter(text, vars, set) {
		var t = render(text, vars);
		if (+set.normalize) { t = plain(t); }
		var p = parts(t);
		var over = p[0] > +set.max_parts;
		return h('p', { class: 'rp-muted' + (over ? ' rp-err' : ''), text: p[1] + ' znaków · ' + p[0] + (p[0] === 1 ? ' SMS' : ' SMS-y') + (p[2] ? ' (są znaki spoza alfabetu SMS – limit 70 na część)' : '') + (over ? ' – ponad limit ' + set.max_parts + ', taki SMS nie wyjdzie' : '') + ' · przykład: „' + t + '”' });
	}
	// klikalne zmienne – wstawiają {zmienna} w miejscu kursora
	function varChips(vars, ta, after) {
		return h('div', { class: 'rp-chips rp-kftags' }, Object.keys(vars).map(function (k) {
			return h('button', { type: 'button', class: 'rp-chip rp-chip-s', title: vars[k], text: '{' + k + '}', onclick: function () {
				var s = ta.selectionStart == null ? ta.value.length : ta.selectionStart, e = ta.selectionEnd == null ? s : ta.selectionEnd;
				ta.value = ta.value.slice(0, s) + '{' + k + '}' + ta.value.slice(e);
				ta.focus(); ta.selectionStart = ta.selectionEnd = s + k.length + 2;
				after();
			} });
		}));
	}
	function testRow(kind, getText, label) {
		var num = h('input', { class: 'rp-in rp-in-m', type: 'tel', inputmode: 'tel', placeholder: 'numer do testu', 'aria-label': 'Numer do testu – ' + label, value: S.smsTestNum || '', oninput: function () { S.smsTestNum = num.value; } });
		return h('div', { class: 'rp-inline rp-sms-test' }, [num, K.btn('Wyślij test', function (e) {
			var b = e.currentTarget; K.busy(b, true);
			K.api('sms_test', { to: num.value, kind: kind, text: getText() }).then(function (x) { K.busy(b, false); K.toast(x.message); }, fail(b));
		})]);
	}

	function secSms(main) {
		var d = S.data.sms;
		if (!d) {
			K.loading(main, 'SMS');
			K.load('sms', 'sms').then(K.render).catch(function (e) { main.textContent = ''; K.failBox(main, e, K.render); });
			return;
		}
		var tab = TABS.some(function (t) { return t[0] === S.tab; }) ? S.tab : 'powiadomienia';
		main.appendChild(K.pageHead('SMS', 'SMS-y do klientów i obsługi przez SMSAPI: powiadomienia o zamówieniach, zgody na SMS-y marketingowe i kampanie. Nazwy i telefony w treściach to zmienne – wstawiają się same.'));
		main.appendChild(K.tabsEl(TABS, tab));
		if (!d.ready) {
			main.appendChild(h('div', { class: 'rp-warn warn', role: 'note' }, [h('span', { text: 'SMSAPI nie jest połączone – SMS-y nie wychodzą. Wklej token w Połączeniach API.' }), d.canApi ? K.btn('Połączenia API', function () { K.go('polaczenia'); }, 'rp-btn-link') : null]));
		} else if (d.testMode) {
			main.appendChild(h('div', { class: 'rp-warn warn', role: 'note' }, [h('span', { text: 'Tryb testowy SMSAPI jest włączony – SMS-y trafiają do dziennika, ale nie wychodzą do ludzi.' }), d.canApi ? K.btn('Połączenia API', function () { K.go('polaczenia'); }, 'rp-btn-link') : null]));
		}
		if (!S.work.sms) { S.work.sms = copy(d.settings); }
		if (tab === 'marketing') { marketing(main, d); }
		else if (tab === 'zgody') { consents(main, d); }
		else if (tab === 'dziennik') { logTab(main, d); }
		else { notices(main, d); }
	}

	function saveBar(main) {
		var v = S.work.sms;
		main.appendChild(K.saveBar(function (b) {
			K.busy(b, true);
			K.api('sms_save', { values: v }).then(function (x) { S.data.sms = x; S.work.sms = null; S.dirty = false; K.toast(x.message); K.render(); }, fail(b));
		}, 'Zapisz ustawienia SMS'));
	}

	/* ---------- Powiadomienia ---------- */
	function notices(main, d) {
		var v = S.work.sms;
		var gc = h('section', { class: 'rp-card' }, [h('h2', { text: 'Wspólne' })]);
		var nm = h('input', { class: 'rp-in', value: v.name, maxlength: '40', placeholder: d.shopName, oninput: function () { v.name = nm.value; K.dirty(); redraw(); } });
		var ph = h('input', { class: 'rp-in', value: v.phone, maxlength: '20', type: 'tel', placeholder: 'np. 600 100 200', oninput: function () { v.phone = ph.value; K.dirty(); redraw(); } });
		gc.appendChild(h('div', { class: 'rp-row2' }, [K.field('{restauracja} – nazwa w SMS-ach', nm, 'Puste = nazwa sklepu („' + d.shopName + '”). Krótko – każdy znak liczy się do długości SMS-a.'), K.field('{telefon_restauracji}', ph, 'Numer, pod który klient może zadzwonić.')]));
		var nz = h('input', { type: 'checkbox', checked: +v.normalize ? true : null, onchange: function () { v.normalize = nz.checked ? 1 : 0; K.dirty(); redraw(); } });
		gc.appendChild(h('label', { class: 'rp-check' }, [nz, h('span', { text: 'Zamieniaj polskie litery (ą → a…) – SMS mieści wtedy 160 znaków zamiast 70, czyli jest tańszy' })]));
		var mp = h('select', { class: 'rp-in rp-in-s', 'aria-label': 'Limit części SMS', onchange: function () { v.max_parts = +mp.value; K.dirty(); redraw(); } }, [1, 2, 3, 4, 6].map(function (n) { return h('option', { value: String(n), text: String(n), selected: +v.max_parts === n ? true : null }); }));
		gc.appendChild(K.field('Najwięcej części w jednym SMS-ie', mp, 'Dłuższy SMS dzieli się na części, a każda kosztuje jak osobny SMS. Dłuższego nie wyślemy (trafi do dziennika jako błąd).'));
		main.appendChild(gc);

		var sample = Object.assign({}, d.sample, { restauracja: v.name || d.shopName, telefon_restauracji: v.phone });
		var counters = [];
		function redraw() { sample.restauracja = v.name || d.shopName; sample.telefon_restauracji = v.phone; counters.forEach(function (f) { f(); }); }

		Object.keys(d.events).forEach(function (k) {
			var ev = d.events[k], e = v.events[k];
			var card = h('section', { class: 'rp-card' + (+e.on ? '' : ' rp-psec-off') });
			var on = h('input', { type: 'checkbox', checked: +e.on ? true : null, 'aria-label': 'Wysyłaj SMS „' + ev[0] + '”', onchange: function () { e.on = on.checked ? 1 : 0; card.classList.toggle('rp-psec-off', !on.checked); K.dirty(); } });
			card.appendChild(h('h2', null, [h('label', { class: 'rp-check' }, [on, h('span', { text: ev[0] })])]));
			card.appendChild(h('p', { class: 'rp-muted', text: 'Do: ' + ev[1] + ' · kiedy: ' + ev[2] + '. Zamówienia z sali – bez SMS-ów. Każdy SMS do zamówienia wychodzi tylko raz.' }));
			var ta = h('textarea', { class: 'rp-in', rows: '3', 'aria-label': 'Treść SMS – ' + ev[0], oninput: function () { e.text = ta.value; K.dirty(); cnt(); } });
			ta.value = e.text;
			var cbox = h('div');
			function cnt() { cbox.textContent = ''; cbox.appendChild(counter(e.text, sample, v)); }
			counters.push(cnt); cnt();
			card.appendChild(K.field('Treść', ta));
			card.appendChild(varChips(d.orderVars, ta, function () { e.text = ta.value; K.dirty(); cnt(); }));
			card.appendChild(cbox);
			if (k === 'staff') {
				var to = h('input', { class: 'rp-in', value: e.to || '', placeholder: 'np. 600100200, 501 222 333', oninput: function () { e.to = to.value; K.dirty(); } });
				card.appendChild(K.field('Numery obsługi', to, 'Kilka numerów – po przecinku. Każdy numer to osobny SMS.'));
				var td = h('input', { type: 'checkbox', checked: +e.today ? true : null, onchange: function () { e.today = td.checked ? 1 : 0; K.dirty(); } });
				card.appendChild(h('label', { class: 'rp-check' }, [td, h('span', { text: 'Tylko zamówienia na dziś (zamówienia na kolejne dni – bez SMS-a)' })]));
			}
			card.appendChild(h('div', { class: 'rp-inline' }, [K.btn('Przywróć treść startową', function () { e.text = d.defaults[k]; ta.value = e.text; K.dirty(); cnt(); }, 'rp-btn-link')]));
			card.appendChild(testRow(k, function () { return ta.value; }, ev[0]));
			main.appendChild(card);
		});
		saveBar(main);
	}

	/* ---------- Marketing ---------- */
	function marketing(main, d) {
		var v = S.work.sms, m = v.mkt;
		var cc = h('section', { class: 'rp-card' }, [h('h2', { text: 'Zgoda w zamówieniu' })]);
		var on = h('input', { type: 'checkbox', checked: +m.on ? true : null, onchange: function () { m.on = on.checked ? 1 : 0; K.dirty(); } });
		cc.appendChild(h('label', { class: 'rp-check' }, [on, h('span', { text: 'Pokaż w formularzu zamówienia pole zgody na SMS-y marketingowe (nieobowiązkowe, domyślnie odznaczone)' })]));
		var ct = h('textarea', { class: 'rp-in', rows: '2', 'aria-label': 'Treść zgody', oninput: function () { m.consent = ct.value; K.dirty(); } });
		ct.value = m.consent;
		cc.appendChild(K.field('Treść zgody przy polu', ct, 'Zapisujemy ją razem ze zgodą (dowód: data, zamówienie, IP i dokładnie ta treść). Zmienne: {restauracja}, {telefon_restauracji}.'));
		cc.appendChild(K.btn('Przywróć treść startową', function () { m.consent = d.defaults.consent; ct.value = m.consent; K.dirty(); }, 'rp-btn-link'));
		var oo = h('input', { class: 'rp-in', value: m.optout, maxlength: '80', oninput: function () { m.optout = oo.value; K.dirty(); } });
		cc.appendChild(K.field('Dopisek na końcu każdego SMS-a marketingowego', oo, 'Musi zawierać {link_rezygnacji} – osobisty link, po kliknięciu numer wypisuje się sam. SMS-y o zamówieniach dalej przychodzą.'));
		var qf = h('input', { class: 'rp-in rp-in-s', type: 'time', value: m.quiet_from, 'aria-label': 'Wysyłka od', oninput: function () { m.quiet_from = qf.value; K.dirty(); } });
		var qt = h('input', { class: 'rp-in rp-in-s', type: 'time', value: m.quiet_to, 'aria-label': 'Wysyłka do', oninput: function () { m.quiet_to = qt.value; K.dirty(); } });
		var pr = h('input', { class: 'rp-in rp-in-s', type: 'text', inputmode: 'decimal', value: String(m.price).replace('.', ','), 'aria-label': 'Cena 1 SMS-a', oninput: function () { m.price = pr.value; K.dirty(); } });
		cc.appendChild(h('div', { class: 'rp-row2' }, [K.field('Kampanie wychodzą tylko w godzinach', h('div', { class: 'rp-inline' }, [qf, h('span', { text: '–' }), qt]), 'Poza nimi wysyłka czeka do najbliższej dozwolonej godziny.'), K.field('Cena 1 SMS-a (punkty SMSAPI)', pr, 'Tylko do szacowania kosztu kampanii – wpisz stawkę ze swojego cennika SMSAPI.')]));
		main.appendChild(cc);
		saveBar(main);

		// nowa kampania (niezależnie od zapisu ustawień)
		var c = S.smsCamp || (S.smsCamp = { text: '', at: '' });
		var kc = h('section', { class: 'rp-card' }, [h('h2', { text: 'Nowa kampania' }), h('p', { class: 'rp-muted', text: 'Odbiorcy: ' + d.consents + ' ' + (d.consents === 1 ? 'osoba' : 'osób') + ' z aktywną zgodą. Dopisek z linkiem rezygnacji dodajemy sami na końcu.' })]);
		var ta = h('textarea', { class: 'rp-in', rows: '4', 'aria-label': 'Treść kampanii', placeholder: 'np. {restauracja}: w piątek pierogi -20%! Zamów: ' + location.host, oninput: function () { c.text = ta.value; later(); } });
		ta.value = c.text;
		var info = h('div');
		var pv = null, tmr = null;
		function later() { clearTimeout(tmr); tmr = setTimeout(prev, 500); }
		function prev() {
			if (!c.text.trim()) { info.textContent = ''; pv = null; return; }
			K.api('sms_campaign_preview', { text: c.text }).then(function (x) {
				pv = x; info.textContent = '';
				info.appendChild(h('p', { class: 'rp-muted' + (x.tooLong ? ' rp-err' : ''), text: x.len + ' znaków · ' + x.parts + ' SMS na osobę' + (x.tooLong ? ' – ponad limit ' + x.maxParts + '!' : '') + ' · razem ok. ' + x.sms + ' SMS · szacunkowo ' + String(x.cost).replace('.', ',') + ' pkt (przy ' + String(x.price).replace('.', ',') + ' pkt za SMS)' }));
				info.appendChild(h('p', { class: 'rp-muted', text: 'Przykład: „' + x.sample + '”' }));
			}).catch(function () {});
		}
		if (c.text) { prev(); }
		kc.appendChild(K.field('Treść', ta));
		kc.appendChild(varChips(d.mktVars, ta, function () { c.text = ta.value; later(); }));
		kc.appendChild(info);
		var at = h('input', { class: 'rp-in rp-in-m', type: 'datetime-local', value: c.at, 'aria-label': 'Wyślij o', oninput: function () { c.at = at.value; } });
		kc.appendChild(K.field('Wyślij o (puste = od razu)', at, 'Godzina strony. Wysyłka partiami po 25 – przy kilkuset osobach trwa kilka minut.'));
		kc.appendChild(testRow('mkt', function () { return ta.value; }, 'kampania'));
		kc.appendChild(h('div', { class: 'rp-inline' }, [K.btn('Wyślij kampanię', function (e) {
			if (!c.text.trim()) { K.toast('Wpisz treść kampanii.', true); return; }
			var who = pv ? pv.recipients + ' osób, ok. ' + pv.sms + ' SMS, ok. ' + String(pv.cost).replace('.', ',') + ' pkt' : d.consents + ' osób';
			if (!window.confirm((c.at ? 'Zaplanować' : 'Wysłać teraz') + ' kampanię do ' + who + '?' + (d.testMode ? '\n\nTryb testowy – SMS-y nie wyjdą naprawdę.' : ''))) { return; }
			var b = e.currentTarget; K.busy(b, true);
			K.api('sms_campaign_send', { text: c.text, at: c.at }).then(function (x) { K.busy(b, false); S.smsCamp = null; S.data.sms.camps = x.camps; K.toast(x.message); K.render(); }, fail(b));
		}, 'rp-btn-pri')]));
		main.appendChild(kc);

		// historia kampanii
		var hc = h('section', { class: 'rp-card' }, [h('h2', { text: 'Historia kampanii' })]);
		if (!d.camps.length) { hc.appendChild(h('p', { class: 'rp-muted', text: 'Jeszcze nie było kampanii.' })); }
		d.camps.forEach(function (x) {
			hc.appendChild(h('div', { class: 'rp-sms-camp' }, [
				h('div', null, [pill(x.status, CST), ' ', h('strong', { text: x.send_label }), h('div', { class: 'rp-muted', text: 'Wysłane ' + x.sent + ' z ' + x.total + (x.failed ? ', błędy: ' + x.failed + (x.err ? ' (' + x.err + ')' : '') : '') + (x.by ? ' · ' + x.by : '') + ' · utworzona ' + x.at_label }), h('div', { text: x.text })]),
				x.status === 'plan' || x.status === 'run' ? K.btn('Zatrzymaj', function (e) {
					if (!window.confirm('Zatrzymać kampanię? Wysłanych SMS-ów nie da się cofnąć.')) { return; }
					var b = e.currentTarget; K.busy(b, true);
					K.api('sms_campaign_cancel', { id: x.id }).then(function (y) { S.data.sms.camps = y.camps; K.toast(y.message); K.render(); }, fail(b));
				}, 'rp-btn-del') : h('span')
			]));
		});
		hc.appendChild(K.btn('Odśwież', function (e) {
			var b = e.currentTarget; K.busy(b, true);
			K.api('sms_log', { kind: 'none' }).then(function (y) { S.data.sms.camps = y.camps; K.render(); }, fail(b));
		}, 'rp-btn-link'));
		main.appendChild(hc);
	}

	/* ---------- Zgody ---------- */
	function consents(main, d) {
		var z = S.smsCons || (S.smsCons = { q: '', all: false, rows: null, total: 0, active: d.consents });
		var card = h('section', { class: 'rp-card' }, [h('h2', { text: 'Zgody na SMS-y marketingowe' })]);
		var q = h('input', { class: 'rp-in', type: 'search', value: z.q, placeholder: 'szukaj: imię albo cyfry numeru', 'aria-label': 'Szukaj zgody' });
		var all = h('input', { type: 'checkbox', checked: z.all ? true : null, onchange: function () { z.all = all.checked; get(0); } });
		var list = h('div');
		var more = h('div');
		function get(off) {
			z.q = q.value.trim();
			K.api('sms_consents', { q: z.q, all: z.all ? 1 : 0, offset: off }).then(function (x) {
				z.rows = off ? z.rows.concat(x.rows) : x.rows; z.total = x.total; z.active = x.active; draw();
			}, function (e) { K.toast(e.message, true); });
		}
		function draw() {
			list.textContent = ''; more.textContent = '';
			head.textContent = 'Aktywnych zgód: ' + z.active + (z.q || z.all ? ' · pasuje: ' + z.total : '');
			if (!z.rows.length) { list.appendChild(h('p', { class: 'rp-muted', text: z.q ? 'Nic nie pasuje.' : 'Nikt jeszcze nie wyraził zgody. Zgody zbiera pole w formularzu zamówienia (Marketing → „Zgoda w zamówieniu”).' })); return; }
			list.appendChild(h('div', { class: 'rp-tablewrap' }, [h('table', { class: 'rp-table-r' }, [
				h('thead', null, [h('tr', null, ['Numer', 'Imię', 'Zgoda', 'Źródło', 'Zamówienie', ''].map(function (t) { return h('th', { text: t }); }))]),
				h('tbody', null, z.rows.map(function (r) {
					return h('tr', null, [h('td', { text: r.phone }), h('td', { text: r.name }), h('td', { text: r.at }), h('td', { text: r.source }), h('td', { text: r.order ? '#' + r.order : '' }),
						h('td', null, [r.withdrawn ? h('span', { class: 'rp-pstat rp-pstat-error', text: 'wycofana ' + r.withdrawn }) : K.btn('Wycofaj', function (e) {
							if (!window.confirm('Wycofać zgodę numeru ' + r.phone + '? Nie dostanie już SMS-ów marketingowych.')) { return; }
							var b = e.currentTarget; K.busy(b, true);
							K.api('sms_consent_withdraw', { id: r.id }).then(function (x) { K.toast(x.message); S.data.sms.consents = x.active; get(0); }, fail(b));
						}, 'rp-btn-del rp-btn-s')])]);
				}))
			])]));
			if (z.rows.length < z.total) { more.appendChild(K.btn('Pokaż więcej', function () { get(z.rows.length); }, 'rp-btn-link')); }
		}
		var head = h('p', { class: 'rp-muted' });
		card.appendChild(h('div', { class: 'rp-inline' }, [h('form', { class: 'rp-search', onsubmit: function (e) { e.preventDefault(); get(0); } }, [q, h('button', { type: 'submit', class: 'rp-btn', text: 'Szukaj' })]),
			h('label', { class: 'rp-check' }, [all, h('span', { text: 'Pokaż też wycofane' })]),
			K.btn('Pobierz CSV', function (e) {
				var b = e.currentTarget; K.busy(b, true);
				K.api('sms_consent_csv', {}).then(function (x) {
					K.busy(b, false);
					var a = h('a', { href: URL.createObjectURL(new Blob([x.csv], { type: 'text/csv;charset=utf-8' })), download: x.file });
					document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
				}, fail(b));
			})]));
		card.appendChild(head);
		card.appendChild(list);
		card.appendChild(more);
		card.appendChild(h('p', { class: 'rp-muted', text: 'CSV zawiera pełne numery, datę, numer zamówienia, IP i treść zaznaczonej zgody – to dowód zgody. Przechowuj go bezpiecznie.' }));
		main.appendChild(card);
		if (z.rows) { draw(); } else { get(0); }
	}

	/* ---------- Dziennik ---------- */
	function logTab(main) {
		var g = S.smsLog || (S.smsLog = { kind: '', rows: null });
		var card = h('section', { class: 'rp-card' }, [h('h2', { text: 'Dziennik wysyłek' }), h('p', { class: 'rp-muted', text: 'Ostatnie 90 dni (starsze wpisy usuwają się same). Numery zamaskowane.' })]);
		var sel = h('select', { class: 'rp-in rp-in-m', 'aria-label': 'Rodzaj SMS-a', onchange: function () { g.kind = sel.value; get(0); } }, [h('option', { value: '', text: 'Wszystkie' })].concat(Object.keys(KINDS).map(function (k) { return h('option', { value: k, text: KINDS[k], selected: g.kind === k ? true : null }); })));
		var list = h('div'), more = h('div');
		function get(off) {
			K.api('sms_log', { kind: g.kind, offset: off }).then(function (x) { g.rows = off ? g.rows.concat(x.rows) : x.rows; g.more = x.rows.length === 100; draw(); }, function (e) { K.toast(e.message, true); });
		}
		function draw() {
			list.textContent = ''; more.textContent = '';
			if (!g.rows.length) { list.appendChild(h('p', { class: 'rp-muted', text: 'Brak wpisów.' })); return; }
			list.appendChild(h('div', { class: 'rp-tablewrap' }, [h('table', { class: 'rp-table-r' }, [
				h('thead', null, [h('tr', null, ['Kiedy', 'Rodzaj', 'Numer', 'Zam. / kamp.', 'Części', 'Stan', 'Treść / błąd'].map(function (t) { return h('th', { text: t }); }))]),
				h('tbody', null, g.rows.map(function (r) {
					return h('tr', null, [h('td', { text: r.at }), h('td', { text: KINDS[r.kind] || r.kind }), h('td', { text: r.phone }), h('td', { text: r.ref ? (r.kind === 'mkt' ? 'kampania' : '#' + r.ref) : '' }), h('td', { text: String(r.parts || '') }),
						h('td', null, [pill(r.status, STAT)]), h('td', { style: 'white-space:normal;min-width:260px', text: r.err ? r.err : r.text })]);
				}))
			])]));
			if (g.more) { more.appendChild(K.btn('Pokaż starsze', function () { get(g.rows.length); }, 'rp-btn-link')); }
		}
		card.appendChild(h('div', { class: 'rp-inline' }, [sel, K.btn('Odśwież', function () { get(0); }, 'rp-btn-link')]));
		card.appendChild(list); card.appendChild(more);
		main.appendChild(card);
		if (g.rows) { draw(); } else { get(0); }
	}

	K.sections.sms = secSms;
})();
