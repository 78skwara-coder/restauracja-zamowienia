/* Restauracja – Panel restauracji: sekcja „Opisy AI” (2.52.0, moduł 40-opisy-ai). Zasady wspólne + kreator pól
 * formularza opisu dania: każde pole ma instrukcję, jak AI ma potraktować wpisane w nie wartości. Wprowadzający
 * wypełnia pola przy daniu (Edycja menu → „Opis z AI”). Tekst zawsze przez textContent / value. */
(function () {
	'use strict';
	var K = window.rzdPanelKit;
	if (!K) { return; }
	var h = K.h, S = K.S;
	function copy(o) { return JSON.parse(JSON.stringify(o)); }
	function fail(b) { return function (e) { K.busy(b, false); K.toast(e.message, true); }; }

	function secOpisy(main) {
		var d = S.data.aidesc;
		if (!d) {
			K.loading(main, 'Opisy AI');
			K.load('aidesc', 'aidesc').then(K.render).catch(function (e) { main.textContent = ''; K.failBox(main, e, K.render); });
			return;
		}
		if (!S.work.aidesc) { S.work.aidesc = { rules: d.rules, fields: copy(d.fields), photo: d.photo, web_max: d.web_max }; }
		var v = S.work.aidesc;
		main.appendChild(K.pageHead('Opisy AI', 'Formularz, który wypełnia się przy daniu (Edycja menu → „Opis z AI”). Przy każdym polu piszesz, jak AI ma potraktować wpisane w nie słowa – po „Generuj” AI układa z nich opis krótki i pełny do zatwierdzenia.'));
		if (!d.ready) {
			main.appendChild(h('div', { class: 'rp-warn warn', role: 'note' }, [h('span', { text: 'AI nie jest połączone – bez tego „Opis z AI” przy daniu się nie pojawi.' }), d.canApi ? K.btn('Połączenia API', function () { K.go('polaczenia'); }, 'rp-btn-link') : null]));
		}

		var rc = h('section', { class: 'rp-card' }, [h('h2', { text: 'Zasady wspólne opisów' })]);
		var rules = h('textarea', { class: 'rp-in', rows: '6', 'aria-label': 'Zasady wspólne opisów', oninput: function () { v.rules = rules.value; K.dirty(); } });
		rules.value = v.rules;
		rc.appendChild(K.field('Idą do AI przy każdym opisie', rules, 'Styl, długość, czego nie robić. Każda linia to jedna zasada. Instrukcja pola ma pierwszeństwo.'));
		rc.appendChild(K.btn('Przywróć zasady startowe', function () { v.rules = d.defRules; rules.value = d.defRules; K.dirty(); }, 'rp-btn-link'));
		main.appendChild(rc);

		// (2.54.0) tryb „AI ze zdjęcia” – zasady i wyszukiwanie w internecie
		var pc = h('section', { class: 'rp-card' }, [h('h2', { text: 'Opis ze zdjęcia' }), h('p', { class: 'rp-muted', text: 'Przy daniu można wybrać „AI ze zdjęcia”: AI patrzy na zdjęcie główne dania i pisze opis w tych samych sekcjach co z formularza. Pola formularza są wtedy nieobowiązkowe, a wprowadzający może dopisać „Dodatkowe wskazówki”.' })]);
		var ph = h('textarea', { class: 'rp-in', rows: '4', 'aria-label': 'Zasady opisu ze zdjęcia', oninput: function () { v.photo = ph.value; K.dirty(); } });
		ph.value = v.photo || '';
		pc.appendChild(K.field('Zasady opisu ze zdjęcia', ph, 'Dokładane do zasad wspólnych tylko w trybie „AI ze zdjęcia”. Zostaw zasadę o składnikach – AI nie może zgadywać składu ze zdjęcia (alergeny!).'));
		pc.appendChild(K.btn('Przywróć zasady startowe', function () { v.photo = d.defPhoto; ph.value = d.defPhoto; K.dirty(); }, 'rp-btn-link'));
		var wm = h('select', { class: 'rp-in rp-in-m', 'aria-label': 'Wyszukiwanie w internecie', onchange: function () { v.web_max = parseInt(wm.value, 10) || 0; K.dirty(); } }, [[0, 'Wyłączone'], [1, 'Do 1 wyszukiwania na opis'], [2, 'Do 2 wyszukiwań na opis'], [3, 'Do 3 wyszukiwań na opis'], [5, 'Do 5 wyszukiwań na opis']].map(function (x) {
			return h('option', { value: String(x[0]), text: x[1], selected: +v.web_max === x[0] ? true : null });
		}));
		pc.appendChild(K.field('Szukaj w internecie (przełącznik przy daniu)', wm, 'AI sprawdza, jak to danie się zwykle przygotowuje, i używa tego do opisu (technika, charakter dania) – składników restauracji nie dopisuje. Koszt: Gemini – w darmowym limicie Google; Claude i ChatGPT – ok. 4 gr za wyszukiwanie plus tekst wyników. Przy daniu przełącznik jest domyślnie wyłączony.'));
		main.appendChild(pc);

		var fc = h('section', { class: 'rp-card' }, [h('h2', { text: 'Pola formularza' }), h('p', { class: 'rp-muted', text: 'W tej kolejności pola widzi wprowadzający i w tej kolejności części trafiają do opisu pełnego. „Nagłówek w opisie” – tytuł tej części w opisie pełnym (puste = bez nagłówka). Wartości wpisane przy daniach zostają przy zmianie nazwy pola.' })]);
		v.fields.forEach(function (f, i) {
			function upd(k, val) { f[k] = val; K.dirty(); }
			var nm = h('input', { class: 'rp-in rp-in-m', value: f.n, 'aria-label': 'Nazwa pola', oninput: function () { upd('n', nm.value); } });
			var tp = h('select', { class: 'rp-in rp-in-s', 'aria-label': 'Rodzaj pola – ' + f.n, onchange: function () { upd('t', tp.value); } }, [h('option', { value: 'line', text: 'krótki tekst', selected: f.t === 'line' ? true : null }), h('option', { value: 'text', text: 'dłuższy tekst', selected: f.t === 'text' ? true : null })]);
			var to = h('select', { class: 'rp-in rp-in-m', 'aria-label': 'Do którego opisu – ' + f.n, onchange: function () { upd('to', to.value); } }, Object.keys(d.targets).map(function (k) { return h('option', { value: k, text: 'Trafia do: ' + d.targets[k], selected: f.to === k ? true : null }); }));
			var on = h('input', { type: 'checkbox', 'aria-label': 'Pole ' + f.n + ' aktywne', checked: +f.on ? true : null, onchange: function () { upd('on', on.checked ? 1 : 0); row.classList.toggle('rp-psec-off', !on.checked); } });
			var rq = h('input', { type: 'checkbox', 'aria-label': 'Pole ' + f.n + ' wymagane', checked: +f.req ? true : null, onchange: function () { upd('req', rq.checked ? 1 : 0); } });
			var ph = h('input', { class: 'rp-in', value: f.ph || '', placeholder: 'np. świeży, czerwony, słodki', 'aria-label': 'Podpowiedź w polu – ' + f.n, oninput: function () { upd('ph', ph.value); } });
			var hi = h('textarea', { class: 'rp-in', rows: '2', 'aria-label': 'Instrukcja dla AI – ' + f.n, placeholder: 'np. każde słowo to osobny podpunkt listy, z dużej litery', oninput: function () { upd('h', hi.value); } });
			hi.value = f.h || '';
			var hd = h('input', { class: 'rp-in rp-in-m', value: f.head || '', placeholder: 'bez nagłówka', 'aria-label': 'Nagłówek w opisie – ' + f.n, oninput: function () { upd('head', hd.value); } });
			var lv = h('select', { class: 'rp-in rp-in-s', 'aria-label': 'Wielkość nagłówka – ' + f.n, onchange: function () { upd('lv', +lv.value); } }, [[2, 'duży'], [3, 'średni'], [4, 'mały']].map(function (x) { return h('option', { value: String(x[0]), text: x[1], selected: +f.lv === x[0] ? true : null }); }));
			var row = h('div', { class: 'rp-psec' + (+f.on === 0 ? ' rp-psec-off' : '') }, [
				h('div', { class: 'rp-inline' }, [h('strong', { text: (i + 1) + '.' }), h('label', { class: 'rp-check rp-psec-on' }, [on, h('span', { text: 'Aktywne' })]), nm, tp,
					i ? h('button', { type: 'button', class: 'rp-ico', 'aria-label': 'Wyżej', text: '↑', onclick: function () { v.fields.splice(i - 1, 0, v.fields.splice(i, 1)[0]); K.dirty(); K.render(); } }) : null,
					h('button', { type: 'button', class: 'rp-ico', 'aria-label': 'Usuń pole ' + f.n, html: K.ICON.x, onclick: function () { if (window.confirm('Usunąć pole „' + f.n + '”? Wpisane przy daniach wartości przestaną być używane.')) { v.fields.splice(i, 1); K.dirty(); K.render(); } } })]),
				h('div', { class: 'rp-inline rp-psec-ty' }, [to, h('label', { class: 'rp-check' }, [rq, h('span', { text: 'Wymagane' })])]),
				K.field('Instrukcja dla AI – jak potraktować wpisane wartości', hi),
				h('div', { class: 'rp-row2' }, [K.field('Podpowiedź w polu', ph), K.field('Nagłówek w opisie pełnym', h('div', { class: 'rp-inline' }, [hd, lv]))])
			]);
			fc.appendChild(row);
		});
		fc.appendChild(K.btn('+ Pole', function () { v.fields.push({ k: '', n: 'Nowe pole', t: 'line', ph: '', h: '', head: '', lv: 3, to: 'long', req: 0, on: 1 }); K.dirty(); K.render(); }, 'rp-btn-link'));
		main.appendChild(fc);

		// podgląd formularza, jaki zobaczy wprowadzający
		var pv = h('section', { class: 'rp-card' }, [h('h2', { text: 'Tak zobaczy to wprowadzający' })]);
		v.fields.filter(function (f) { return +f.on; }).forEach(function (f) {
			var el = f.t === 'text' ? h('textarea', { class: 'rp-in', rows: '2', placeholder: f.ph || '', disabled: true }) : h('input', { class: 'rp-in', placeholder: f.ph || '', disabled: true });
			pv.appendChild(K.field(f.n + (+f.req ? ' *' : ''), el));
		});
		pv.appendChild(h('p', { class: 'rp-muted', text: '…potem „✨ Generuj” → podgląd opisu krótkiego i pełnego → „Zatwierdź”.' }));
		main.appendChild(pv);

		main.appendChild(K.saveBar(function (b) {
			K.busy(b, true);
			K.api('aidesc_save', { values: v }).then(function (x) { S.data.aidesc = x; S.work.aidesc = null; S.dirty = false; K.toast(x.message); K.render(); }, fail(b));
		}, 'Zapisz opisy AI'));
	}

	K.sections.opisy = secOpisy;
})();
