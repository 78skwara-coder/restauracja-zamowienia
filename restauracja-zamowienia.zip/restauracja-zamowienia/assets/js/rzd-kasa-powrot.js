/* Restauracja – Zamówienia i Dostawy: rzd-kasa-powrot.js (z 07-koszyk.php) */
(function () {
	if (document.querySelector('.kc-back-to-shop')) { return; } // już jest (klasyczna kasa przez PHP)
	var target = document.querySelector(
		'.wp-block-woocommerce-checkout, .wc-block-checkout, form.woocommerce-checkout, .woocommerce-checkout'
	);
	if (!target || !target.parentNode) { return; }
	var p = document.createElement('p');
	p.className = 'kc-back-to-shop';
	var a = document.createElement('a');
	a.className = 'button wc-backward';
	a.href = rzdKcBack.url;
	a.textContent = rzdKcBack.text;
	p.appendChild(a);
	target.parentNode.insertBefore(p, target);
})();
