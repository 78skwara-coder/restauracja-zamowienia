/* Restauracja – Zamówienia i Dostawy: Kuchnia / Kurier – ekran obsługi */
(function () {
	var cfg = window.rzdKuchniaCfg || {};
	var kioskBtn = null, refreshBtn = null; // przypisywane w bindToolbar() (po podmianie treści powstają na nowo)
	var wrapEl = document.querySelector('.kuchnia-wrap');
	var KUCHNIA_MODE = cfg.mode; // 'kuchnia' albo 'kurier' (bez dźwięku i sygnału nowych zamówień)
	var KIOSK_KEY = 'kuchnia_kiosk';
	var REFRESH_KEY = 'kuchnia_autorefresh';
	var isFront = !!cfg.front;

	// Strona publiczna: panel przenosimy na sam wierzch dokumentu (<body>), żeby
	// nakładka na cały ekran nie zależała od kontenerów motywu (transform,
	// overflow itp. potrafią rozwalić position:fixed) – i żeby przy druku
	// wystarczyło schować rodzeństwo panelu.
	if (isFront && wrapEl) {
		document.body.appendChild(wrapEl);
		document.body.classList.add('kuchnia-front-body');
	}

	// ---- Pełny ekran = prawdziwy tryb pełnoekranowy przeglądarki ----
	// Wcześniej przycisk tylko chował elementy panelu WordPressa, więc na
	// stronie publicznej nie robił nic. Uwaga: przeładowanie strony (np. przez
	// auto-odświeżanie) kończy tryb pełnoekranowy – przeglądarka nie pozwala
	// wejść w niego z powrotem bez kliknięcia użytkownika.
	var rootEl = document.documentElement;
	function fsSupported() { return !!(rootEl.requestFullscreen || rootEl.webkitRequestFullscreen); }
	function inFs() { return !!(document.fullscreenElement || document.webkitFullscreenElement); }
	function enterFs() {
		var r = rootEl.requestFullscreen || rootEl.webkitRequestFullscreen;
		if (r) { var pr = r.call(rootEl); if (pr && pr.catch) { pr.catch(function () {}); } }
	}
	function exitFs() {
		var x = document.exitFullscreen || document.webkitExitFullscreen;
		if (x) { var pr = x.call(document); if (pr && pr.catch) { pr.catch(function () {}); } }
	}

	var kiosk = !isFront && localStorage.getItem(KIOSK_KEY) === '1'; // ukrywanie menu WP – tylko w panelu
	function updateKioskLabel() {
		if (!kioskBtn) { return; }
		var on = isFront ? inFs() : (kiosk || inFs());
		kioskBtn.classList.toggle('is-on', on);
		kioskBtn.textContent = on ? 'Wyjdź z pełnego ekranu' : 'Pełny ekran';
	}
	function applyKiosk(on) {
		document.body.classList.toggle('kuchnia-kiosk', on);
		updateKioskLabel();
	}
	document.addEventListener('fullscreenchange', updateKioskLabel);
	document.addEventListener('webkitfullscreenchange', updateKioskLabel);

	// ---- Wydruk: chowamy wszystko, co nie jest panelem (menu, logo, stopka motywu) ----
	// Idziemy w górę od panelu do <body> i każdemu "rodzeństwu" po drodze dajemy
	// klasę kuchnia-print-hide (display:none w druku) – bez znajomości selektorów motywu.
	function markForPrint() {
		var el = wrapEl;
		while (el && el !== document.body && el.parentNode) {
			var par = el.parentNode;
			par.classList.add('kuchnia-print-anc'); // zdejmij szerokość/marginesy kontenerów motywu
			Array.prototype.forEach.call(par.children, function (sib) {
				var tn = sib.tagName;
				if (sib === el || tn === 'SCRIPT' || tn === 'STYLE' || tn === 'LINK' || tn === 'META' || tn === 'NOSCRIPT') { return; }
				sib.classList.add('kuchnia-print-hide');
			});
			el = par;
		}
	}
	function unmarkAfterPrint() {
		Array.prototype.forEach.call(document.querySelectorAll('.kuchnia-print-hide, .kuchnia-print-anc'), function (n) { n.classList.remove('kuchnia-print-hide', 'kuchnia-print-anc'); });
	}
	window.addEventListener('beforeprint', markForPrint);
	window.addEventListener('afterprint', unmarkAfterPrint);
	if (window.matchMedia) { // Safari nie zawsze wysyła beforeprint/afterprint
		var mq = window.matchMedia('print');
		var onMq = function (e) { if (e.matches) { markForPrint(); } else { unmarkAfterPrint(); } };
		if (mq.addEventListener) { mq.addEventListener('change', onMq); } else if (mq.addListener) { mq.addListener(onMq); }
	}

	var refreshOn = localStorage.getItem(REFRESH_KEY) !== '0';
	var timer = null;
	function applyRefresh(on) {
		if (timer) { clearTimeout(timer); timer = null; }
		if (on) { timer = setTimeout(softReload, 60000); }
		if (!refreshBtn) { return; }
		refreshBtn.classList.toggle('is-on', on);
		refreshBtn.textContent = 'Auto-odświeżanie: ' + (on ? 'włączone' : 'wyłączone');
	}

	// Przyciski paska (Pełny ekran, Auto-odświeżanie) – wiązane od nowa po każdej podmianie treści.
	var settingsOpen = false; // panel "⚙ Ustawienia" zostaje otwarty po podmianie treści
	// Liczniki "cutoff za… / wyjazd za…" liczymy od czasu serwera (zegar tabletu bywa przestawiony).
	var clockOffset = 0;
	function syncClock() {
		var n = wrapEl ? wrapEl.querySelector('.kuchnia-next[data-now]') : null;
		if (n) { clockOffset = parseInt(n.getAttribute('data-now'), 10) - Date.now() / 1000; }
	}
	function bindToolbar() {
		syncClock();
		var setBtn = wrapEl ? wrapEl.querySelector('#kuchnia-settings-toggle') : null;
		var setPanel = wrapEl ? wrapEl.querySelector('#kuchnia-settings') : null;
		if (setBtn && setPanel) {
			setPanel.classList.toggle('is-open', settingsOpen);
			setBtn.classList.toggle('is-on', settingsOpen);
			setBtn.addEventListener('click', function () {
				settingsOpen = !settingsOpen;
				setPanel.classList.toggle('is-open', settingsOpen);
				setBtn.classList.toggle('is-on', settingsOpen);
			});
		}
		updateAlertLabels();
		kioskBtn = wrapEl ? wrapEl.querySelector('#kuchnia-kiosk-toggle') : null;
		refreshBtn = wrapEl ? wrapEl.querySelector('#kuchnia-refresh-toggle') : null;
		if (!kioskBtn || !refreshBtn) { return; }
		if (isFront && !fsSupported()) {
			kioskBtn.style.display = 'none'; // np. iPhone – przeglądarka nie udostępnia pełnego ekranu dla stron
		}
		applyKiosk(kiosk);
		kioskBtn.addEventListener('click', function () {
			var turnOn = isFront ? !inFs() : !kiosk;
			if (!isFront) {
				kiosk = turnOn;
				localStorage.setItem(KIOSK_KEY, kiosk ? '1' : '0');
				applyKiosk(kiosk);
			}
			if (turnOn) { enterFs(); } else if (inFs()) { exitFs(); }
		});
		applyRefresh(refreshOn);
		refreshBtn.addEventListener('click', function () {
			refreshOn = !refreshOn;
			localStorage.setItem(REFRESH_KEY, refreshOn ? '1' : '0');
			applyRefresh(refreshOn);
		});
	}

	// Popup potwierdzający zmianę statusu – klik "OK" odświeża stronę,
	// żeby nowy status był widoczny wszędzie (nie tylko tam, gdzie kliknięto).
	var popupRoot = document.getElementById('kuchnia-popup-root');
	function showStatusPopup(message, reloadAfter) {
		popupRoot.innerHTML = '';
		var backdrop = document.createElement('div');
		backdrop.className = 'kuchnia-popup-backdrop';
		var box = document.createElement('div');
		box.className = 'kuchnia-popup';
		var p = document.createElement('p');
		p.textContent = message;
		var ok = document.createElement('button');
		ok.type = 'button';
		ok.textContent = 'OK';
		ok.addEventListener('click', function () {
			popupRoot.innerHTML = '';
			if (reloadAfter) { softReload(); }
		});
		box.appendChild(p);
		box.appendChild(ok);
		backdrop.appendChild(box);
		popupRoot.appendChild(backdrop);
		ok.focus();
	}

	// Popup z pytaniem tak/nie – zamiast natywnego window.confirm()
	// przeglądarki, żeby wyglądało spójnie z resztą dashboardu.
	function showConfirmPopup(message, confirmLabel, onConfirm) {
		popupRoot.innerHTML = '';
		var backdrop = document.createElement('div');
		backdrop.className = 'kuchnia-popup-backdrop';
		var box = document.createElement('div');
		box.className = 'kuchnia-popup';
		var p = document.createElement('p');
		p.textContent = message;
		var row = document.createElement('div');
		row.style.display = 'flex';
		row.style.gap = '10px';
		var cancel = document.createElement('button');
		cancel.type = 'button';
		cancel.textContent = 'Nie';
		cancel.style.background = '#fff';
		cancel.style.color = '#222';
		var yes = document.createElement('button');
		yes.type = 'button';
		yes.textContent = confirmLabel || 'Tak';
		yes.style.background = '#b32d2e';
		yes.style.borderColor = '#b32d2e';
		cancel.addEventListener('click', function () { popupRoot.innerHTML = ''; });
		yes.addEventListener('click', function () { popupRoot.innerHTML = ''; onConfirm(); });
		row.appendChild(cancel);
		row.appendChild(yes);
		box.appendChild(p);
		box.appendChild(row);
		backdrop.appendChild(box);
		popupRoot.appendChild(backdrop);
		yes.focus();
	}

	// Właściwy adres endpointu WooCommerce AJAX (nie admin-ajax.php!) –
	// WC_AJAX::get_endpoint() sam dokłada poprawny znak zapytania.
	// Wcześniejsza, ręcznie sklejana wersja adresu psuła WSZYSTKIE
	// przyciski w tym module (404 połykane po cichu przez fetch).
	var wcAjaxTpl = cfg.wcAjax || '';
	// nonce akcji (moduł 25) – brany z treści ekranu (.kuchnia-n), która
	// odświeża się przy każdym miękkim przeładowaniu; wygasły → przeładowanie.
	function nonce() { var n = document.querySelector('.kuchnia-wrap .kuchnia-n'); return n ? (n.getAttribute('data-n') || '') : ''; }
	function post(action, body, cb, onError) {
		var url = wcAjaxTpl.replace('__ACTION__', action);
		body = (body ? body + '&' : '') + '_n=' + encodeURIComponent(nonce());
		fetch(url, {
			method: 'POST', credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: body
		})
			.then(function (r) { return r.json(); })
			.then(function (r) {
				if (r && r.code === 'nonce') { showStatusPopup(r.message || 'Sesja ekranu wygasła – odświeżam stronę.'); softReload(); return; }
				if (r && r.ok === false) { (onError || showStatusPopup)(r.message || 'Nie udało się wykonać akcji.'); return; }
				(cb || function () {})(r);
			})
			.catch(function () { (onError || showStatusPopup)('Błąd połączenia – spróbuj ponownie.'); });
	}

	// Planowanie: zapis kolejności/godziny po zmianie pola
	document.addEventListener('change', function (e) {
		var input = e.target;
		if (!(input.matches && input.matches('.kuchnia-plan-input, .kuchnia-plan-time'))) { return; }
		var tr = input.closest('tr');
		var orderId = tr.getAttribute('data-order');
		var seq = tr.querySelector('.kuchnia-plan-input').value;
		var ptime = tr.querySelector('.kuchnia-plan-time').value;
		// Lista godzin (tryb okien) zależy od wyborów innych zamówień – po zapisie
		// odświeżamy treść, żeby zajęte sloty zniknęły z pozostałych list.
		var isSelect = input.tagName === 'SELECT';
		post('kuchnia_set_planning', 'order_id=' + encodeURIComponent(orderId) + '&sequence=' + encodeURIComponent(seq) + '&planned_time=' + encodeURIComponent(ptime), function () {
			if (isSelect) { softReload(); }
		}, function (msg) { showStatusPopup(msg, true); });
	});

	// Planowanie: "Zaplanowane" – sprawdza duplikaty kolejności/godzin na
	// serwerze (świeże dane, nie to co akurat jest w polach na ekranie) i,
	// jeśli nie ma błędów, zamraża plan do edycji.
	// Przyciski wiązane wprost (istnieją tylko w niektórych zakładkach) – po podmianie treści wiążemy je od nowa.
	function bindActionButtons() {
	var planConfirmBtn = document.getElementById('kuchnia-plan-confirm');
	if (planConfirmBtn) {
		planConfirmBtn.addEventListener('click', function () {
			planConfirmBtn.disabled = true;
			post('kuchnia_confirm_planning', 'date=' + encodeURIComponent(planConfirmBtn.getAttribute('data-date')) + '&time=' + encodeURIComponent(planConfirmBtn.getAttribute('data-time')), function (r) {
				var sent = r && r.sent ? r.sent : 0;
				showStatusPopup('Plan zapisany – pola są teraz zablokowane do edycji.' + (sent ? ' Wysłano klientom maile z godziną dostawy: ' + sent + '.' : ''), true);
			}, function (msg) { planConfirmBtn.disabled = false; showStatusPopup(msg); });
		});
	}

	// Planowanie: "Edytuj" – odblokowuje plan z powrotem do edycji.
	var planEditBtn = document.getElementById('kuchnia-plan-edit');
	if (planEditBtn) {
		planEditBtn.addEventListener('click', function () {
			planEditBtn.disabled = true;
			post('kuchnia_unlock_planning', 'date=' + encodeURIComponent(planEditBtn.getAttribute('data-date')) + '&time=' + encodeURIComponent(planEditBtn.getAttribute('data-time')), function () {
				softReload();
			}, function (msg) { planEditBtn.disabled = false; showStatusPopup(msg); });
		});
	}

	// Kuchnia: "Oznacz cały termin jako Przygotowane"
	var prepAllBtn = document.getElementById('kuchnia-mark-preparing');
	if (prepAllBtn) {
		prepAllBtn.addEventListener('click', function () {
			prepAllBtn.disabled = true;
			post('kuchnia_bulk_status', 'date=' + encodeURIComponent(prepAllBtn.getAttribute('data-date')) + '&time=' + encodeURIComponent(prepAllBtn.getAttribute('data-time')) + '&status=gotowe', function (r) {
				showStatusPopup('Nadano status: ' + (r && r.label ? r.label : 'Przygotowane'), true);
			});
		});
	}

	}
	bindActionButtons();

	// ---- Nowe zamówienie: dźwięk, pogrubienie, opcjonalnie okno ----
	// Ustawienia "Okno z powiadomieniem" i "Powtarzaj dźwięk" są zapisane na tym
	// urządzeniu (to sprawa tabletu w kuchni, nie całego sklepu).
	var ALERT_POPUP_KEY = 'kuchnia_alert_popup';
	var ALERT_REPEAT_KEY = 'kuchnia_alert_repeat';
	function alertPopupOn() { return localStorage.getItem(ALERT_POPUP_KEY) === '1'; }
	function alertRepeatOn() { return localStorage.getItem(ALERT_REPEAT_KEY) === '1'; }
	function updateAlertLabels() {
		var pb = wrapEl ? wrapEl.querySelector('#kuchnia-alert-popup-toggle') : null;
		var rb = wrapEl ? wrapEl.querySelector('#kuchnia-alert-repeat-toggle') : null;
		if (pb) { pb.textContent = 'Okno z powiadomieniem: ' + (alertPopupOn() ? 'tak' : 'nie'); pb.classList.toggle('is-on', alertPopupOn()); }
		if (rb) { rb.textContent = 'Powtarzaj dźwięk: ' + (alertRepeatOn() ? 'tak' : 'nie'); rb.classList.toggle('is-on', alertRepeatOn()); rb.disabled = !alertPopupOn(); }
	}
	document.addEventListener('click', function (e) {
		var t = e.target;
		if (!t || !t.id) { return; }
		if (t.id === 'kuchnia-alert-popup-toggle') { localStorage.setItem(ALERT_POPUP_KEY, alertPopupOn() ? '0' : '1'); updateAlertLabels(); }
		else if (t.id === 'kuchnia-alert-repeat-toggle') { localStorage.setItem(ALERT_REPEAT_KEY, alertRepeatOn() ? '0' : '1'); updateAlertLabels(); }
		else if (t.id === 'kuchnia-sound-test') { beep(); }
	});

	// Dźwięk z przeglądarki (bez pliku). Przeglądarka pozwala grać dopiero po
	// pierwszym dotknięciu/kliknięciu strony – wtedy "odblokowujemy" dźwięk.
	var audioCtx = null;
	function ensureAudio() {
		try {
			if (!audioCtx) {
				var AC = window.AudioContext || window.webkitAudioContext;
				if (!AC) { return null; }
				audioCtx = new AC();
			}
			if (audioCtx.state === 'suspended') { audioCtx.resume(); }
		} catch (err) { return null; }
		return audioCtx;
	}
	function beep() {
		var ctx = ensureAudio();
		if (!ctx) { return; }
		var t0 = ctx.currentTime;
		[[880, 0], [1175, 0.2], [880, 0.4]].forEach(function (n) {
			var o = ctx.createOscillator(), g = ctx.createGain();
			o.type = 'sine';
			o.frequency.value = n[0];
			g.gain.setValueAtTime(0.0001, t0 + n[1]);
			g.gain.exponentialRampToValueAtTime(0.6, t0 + n[1] + 0.02);
			g.gain.exponentialRampToValueAtTime(0.0001, t0 + n[1] + 0.18);
			o.connect(g); g.connect(ctx.destination);
			o.start(t0 + n[1]); o.stop(t0 + n[1] + 0.2);
		});
	}

	// Blokada wygaszania ekranu, dopóki dashboard jest otwarty (Wake Lock API;
	// wymaga https; po powrocie do karty trzeba ją wziąć od nowa).
	var wakeLock = null;
	function requestWake() {
		if (wakeLock || !('wakeLock' in navigator) || document.visibilityState !== 'visible') { return; }
		navigator.wakeLock.request('screen').then(function (l) {
			wakeLock = l;
			l.addEventListener('release', function () { wakeLock = null; });
		}).catch(function () {});
	}
	if (KUCHNIA_MODE !== 'kurier') {
		requestWake();
		document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'visible') { requestWake(); } });
	}
	['pointerdown', 'touchstart', 'keydown'].forEach(function (ev) {
		document.addEventListener(ev, function () { if (KUCHNIA_MODE !== 'kurier') { ensureAudio(); requestWake(); } }, true);
	});

	// Okno "Nowe zamówienie" – zbiera kolejne, dopóki nikt nie kliknie OK;
	// przy "Powtarzaj dźwięk" gra co 5 s aż do OK.
	var pendingNew = [], repeatTimer = null;
	function fmtDate(d) { return (d && d.length === 10) ? d.slice(8, 10) + '.' + d.slice(5, 7) : ''; }
	function showNewOrderPopup() {
		popupRoot.innerHTML = '';
		var backdrop = document.createElement('div');
		backdrop.className = 'kuchnia-popup-backdrop';
		var box = document.createElement('div');
		box.className = 'kuchnia-popup';
		var p = document.createElement('p');
		p.style.whiteSpace = 'pre-line';
		p.textContent = pendingNew.map(function (o) {
			return 'Nowe zamówienie #' + o.number + (o.date ? ' · dostawa ' + fmtDate(o.date) + (o.time ? ' ' + o.time : '') : '');
		}).join('\n');
		var ok = document.createElement('button');
		ok.type = 'button';
		ok.textContent = 'OK';
		ok.addEventListener('click', function () {
			popupRoot.innerHTML = '';
			pendingNew = [];
			if (repeatTimer) { clearInterval(repeatTimer); repeatTimer = null; }
		});
		box.appendChild(p);
		box.appendChild(ok);
		backdrop.appendChild(box);
		popupRoot.appendChild(backdrop);
	}
	function onNewOrders(fresh) {
		beep();
		softReload(); // pokazuje nowe zamówienie (pogrubione) bez czekania na odświeżanie
		if (!alertPopupOn()) { return; }
		pendingNew = pendingNew.concat(fresh);
		showNewOrderPopup();
		if (alertRepeatOn() && !repeatTimer) { repeatTimer = setInterval(beep, 5000); }
	}

	// Co 20 s pytamy serwer o ostatnio zmienione zamówienia (moduł 13). Przy
	// starcie zapamiętujemy czas serwera – alarm tylko dla opłaconych później.
	var seenIds = {}, alertSince = null;
	function pollNew() {
		post('kuchnia_new_orders', '', function (r) {
			var list = (r && r.orders) ? r.orders : [];
			if (alertSince === null) { alertSince = r && r.now ? r.now : 0; }
			var fresh = list.filter(function (o) { return !seenIds[o.id] && o.ts >= alertSince; });
			list.forEach(function (o) { seenIds[o.id] = 1; });
			if (fresh.length) { onNewOrders(fresh.reverse()); }
		}, function () {}); // błąd połączenia – po cichu, spróbujemy za 20 s
	}
	if (KUCHNIA_MODE !== 'kurier') {
		pollNew();
		setInterval(pollNew, 20000);
	}

	// ---- Taśma w Zamówieniach: odliczanie i przejście po wyjeździe ----
	var cdReloading = false;
	function fmtLeft(sec) {
		if (sec >= 3600) { var h = Math.floor(sec / 3600); return h + ' h ' + Math.floor((sec % 3600) / 60) + ' min'; }
		if (sec >= 600) { return Math.floor(sec / 60) + ' min'; }
		var m = Math.floor(sec / 60), ss = Math.floor(sec % 60);
		return m + ':' + (ss < 10 ? '0' : '') + ss;
	}
	function tickCountdowns() {
		if (!wrapEl) { return; }
		var els = wrapEl.querySelectorAll('.kuchnia-cd');
		var now = Date.now() / 1000 + clockOffset;
		for (var i = 0; i < els.length; i++) {
			var el = els[i];
			var left = parseInt(el.getAttribute('data-ts'), 10) - now;
			if (left <= 0) {
				// Czas minął – odświeżamy: wyjazd znika z góry, wchodzi następny.
				if (el.getAttribute('data-reload') && !cdReloading) {
					cdReloading = true;
					setTimeout(function () { cdReloading = false; }, 8000);
					softReload();
				}
				continue;
			}
			var kind = el.getAttribute('data-kind');
			if (kind === 'silent') { continue; }
			el.textContent = (kind === 'cutoff' ? 'cutoff za ' : 'wyjazd za ') + fmtLeft(left);
			el.classList.toggle('is-soon', left < 600);
		}
	}
	setInterval(tickCountdowns, 1000);

	// ---- "Nowy termin" dla zamówienia do przeplanowania ----
	document.addEventListener('click', function (e) {
		var btn = e.target.closest ? e.target.closest('.kuchnia-resched-btn') : null;
		if (!btn) { return; }
		var orderId = btn.getAttribute('data-order');
		btn.disabled = true;
		post('kuchnia_resched_slots', 'order_id=' + encodeURIComponent(orderId), function (r) {
			btn.disabled = false;
			if (!r.dates || !r.dates.length) { showStatusPopup(r.message || 'Brak dostępnych terminów.'); return; }
			var chosen = { date: r.dates[0].date, time: '' };
			popupRoot.innerHTML = '';
			var backdrop = document.createElement('div');
			backdrop.className = 'kuchnia-popup-backdrop';
			var box = document.createElement('div');
			box.className = 'kuchnia-popup';
			var h = document.createElement('p');
			h.innerHTML = '<strong></strong>';
			h.firstChild.textContent = 'Nowy termin – zamówienie #' + r.number;
			var sel = document.createElement('select');
			sel.className = 'kuchnia-rs-dates';
			r.dates.forEach(function (d) { var o = document.createElement('option'); o.value = d.date; o.textContent = d.label; sel.appendChild(o); });
			var times = document.createElement('div');
			times.className = 'kuchnia-rs-times';
			var notify = document.createElement('label');
			notify.innerHTML = '<input type="checkbox" checked> Powiadom klienta mailem';
			var save = document.createElement('button');
			save.type = 'button'; save.textContent = 'Zapisz nowy termin'; save.disabled = true;
			var cancel = document.createElement('button');
			cancel.type = 'button'; cancel.textContent = 'Anuluj';
			cancel.addEventListener('click', function () { popupRoot.innerHTML = ''; });
			function paintTimes() {
				times.innerHTML = '';
				var d = null;
				r.dates.forEach(function (x) { if (x.date === sel.value) { d = x; } });
				chosen.date = sel.value;
				if (!d || d.times.indexOf(chosen.time) === -1) { chosen.time = ''; }
				(d ? d.times : []).forEach(function (t) {
					var b = document.createElement('button');
					b.type = 'button'; b.textContent = (d.labels && d.labels[t]) ? d.labels[t] : t;
					if (t === chosen.time) { b.className = 'is-on'; }
					b.addEventListener('click', function () { chosen.time = t; paintTimes(); });
					times.appendChild(b);
				});
				save.disabled = !chosen.time;
			}
			sel.addEventListener('change', paintTimes);
			save.addEventListener('click', function () {
				save.disabled = true;
				var body = 'order_id=' + encodeURIComponent(orderId) + '&date=' + encodeURIComponent(chosen.date) + '&time=' + encodeURIComponent(chosen.time) + '&notify=' + (notify.querySelector('input').checked ? '1' : '');
				post('kuchnia_reschedule', body, function (x) {
					showStatusPopup('Nowy termin: ' + x.label + '.' + (x.mailed ? ' Wysłano mail do klienta.' : ''), true);
				}, function (msg) { save.disabled = false; showStatusPopup(msg); });
			});
			box.appendChild(h); box.appendChild(sel); box.appendChild(times); box.appendChild(notify);
			var acts = document.createElement('div');
			acts.style.cssText = 'display:flex;gap:8px;justify-content:flex-end;margin-top:12px;';
			acts.appendChild(cancel); acts.appendChild(save);
			box.appendChild(acts);
			backdrop.appendChild(box);
			popupRoot.appendChild(backdrop);
			paintTimes();
		}, function (msg) { btn.disabled = false; showStatusPopup(msg); });
	});

	// ---- Nawigacja BEZ przeładowania strony ----
	// Przeładowanie strony kończy tryb pełnoekranowy przeglądarki (i nie da się do niego wrócić
	// bez kliknięcia). Dlatego zakładki, godziny, data i odświeżanie pobierają nową treść w tle
	// i podmieniają zawartość panelu w miejscu – pełny ekran zostaje.
	// Adres bez daty i godziny – tylko do paska adresu (patrz niżej).
	var TODAY = cfg.today;
	var curUrl = window.location.href;
	function cleanUrl(url) {
		try {
			var u = new URL(url, window.location.href);
			u.searchParams.delete('date');
			u.searchParams.delete('time');
			return u.toString();
		} catch (err) { return url; }
	}
	function softGo(url, push) {
		if (!wrapEl) { window.location.href = url; return; }
		var scroller = isFront ? wrapEl : (document.scrollingElement || document.documentElement);
		var keep = scroller.scrollTop;
		fetch(url, { credentials: 'same-origin' })
			.then(function (r) { return r.text(); })
			.then(function (html) {
				var doc = new DOMParser().parseFromString(html, 'text/html');
				var fresh = doc.querySelector('.kuchnia-wrap');
				if (!fresh) { window.location.href = url; return; } // np. wygasła sesja/PIN – pełne wczytanie pokaże ekran logowania
				wrapEl.innerHTML = fresh.innerHTML;
				curUrl = url;
				if (push) { history.pushState({ kuchnia: 1, url: url }, '', cleanUrl(url)); }
				bindToolbar();
				bindActionButtons();
				scroller.scrollTop = push ? 0 : keep;
			})
			.catch(function () { window.location.href = url; });
	}
	function softReload() { softGo(curUrl, false); }
	bindToolbar();
	// przy każdym otwarciu ekranu – bieżąca data, nie ostatnio wybrana.
	// Wybrany dzień i godzina żyją tylko w tej karcie (curUrl + history.state),
	// pasek adresu ich nie pokazuje – przywrócona karta, zakładka czy skrót
	// na ekranie telefonu otwierają dziś. Stary adres z datą (sprzed 2.26.20)
	// też przestawia się na dziś, chyba że to „Wstecz” w przeglądarce.
	(function () {
		var u = new URL(curUrl), d = u.searchParams.get('date');
		var nav = (window.performance && performance.getEntriesByType) ? performance.getEntriesByType('navigation')[0] : null;
		var back = nav && nav.type === 'back_forward';
		if (d && d !== TODAY && !back) {
			curUrl = cleanUrl(curUrl);
			history.replaceState({ kuchnia: 1, url: curUrl }, '', curUrl);
			softGo(curUrl, false);
			return;
		}
		history.replaceState({ kuchnia: 1, url: curUrl }, '', cleanUrl(curUrl));
	})();
	document.addEventListener('click', function (e) {
		var a = e.target.closest ? e.target.closest('.kuchnia-wrap a.kuchnia-tab, .kuchnia-wrap a.kuchnia-slot') : null;
		if (!a || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) { return; }
		e.preventDefault();
		softGo(a.href, true);
	});
	document.addEventListener('submit', function (e) {
		var f = e.target;
		if (!f || !f.closest || !f.closest('.kuchnia-top, .kuchnia-head')) { return; }
		e.preventDefault();
		var qs = new URLSearchParams(new FormData(f)).toString();
		softGo(f.action + (f.action.indexOf('?') > -1 ? '&' : '?') + qs, true);
	});
	window.addEventListener('popstate', function (e) {
		softGo((e.state && e.state.url) ? e.state.url : window.location.href, false);
	});

	// Zamówienia: "Dni wstecz" i "Auto przygotowanie" – wspólne ustawienia na serwerze (moduł 13).
	document.addEventListener('change', function (e) {
		var input = e.target;
		if (!input || input.id !== 'kuchnia-days-back') { return; }
		var max = parseInt(input.getAttribute('max'), 10) || 365;
		var n = Math.max(0, Math.min(max, parseInt(input.value, 10) || 0));
		var go = function () {
			var u = new URL(curUrl, window.location.href);
			u.searchParams.set('days', String(n));
			softGo(u.toString(), false);
		};
		// z „Ustawieniami wtyczki” – zapis jako domyślny dla wszystkich (jak dotąd); inni – tylko ten ekran
		if (input.getAttribute('data-save') === '1') { post('kuchnia_save_settings', 'days_back=' + n, go); } else { go(); }
	});
	document.addEventListener('click', function (e) {
		var btn = e.target.closest ? e.target.closest('#kuchnia-autoprep-toggle') : null;
		if (!btn) { return; }
		btn.disabled = true;
		var turnOn = btn.getAttribute('data-on') !== '1';
		post('kuchnia_save_settings', 'auto_prep=' + (turnOn ? '1' : '0'), function () { softReload(); }, function (msg) { btn.disabled = false; showStatusPopup(msg); });
	});

	// ---- Po kliknięciu statusu: pasek „Oznaczono … · Cofnij” (2.39.0) ----
	// Zamiast okienka z OK: ekran od razu się odświeża, a pasek na dole przez kilka sekund
	// pozwala cofnąć pomyłkę TEJ SAMEJ osobie (serwer sprawdza konto i czas). Bez konta
	// (awaryjny PIN kuriera) – jak dotąd okienko.
	var undoTimer = null;
	function hideUndo() {
		clearTimeout(undoTimer);
		var old = document.getElementById('kuchnia-undo');
		if (old) { old.parentNode.removeChild(old); }
	}
	function statusDone(orderId, r, fallback) {
		var label = (r && r.label) ? r.label : fallback;
		if (!r || !r.undo) { showStatusPopup('Nadano status: ' + label, true); return; }
		softReload();
		hideUndo();
		var bar = document.createElement('div');
		bar.id = 'kuchnia-undo';
		bar.className = 'kuchnia-undo';
		bar.setAttribute('role', 'status');
		var txt = document.createElement('span');
		txt.textContent = 'Oznaczono' + (r.number ? ' #' + r.number : '') + ': ' + label;
		var btn = document.createElement('button');
		btn.type = 'button';
		btn.textContent = 'Cofnij';
		btn.addEventListener('click', function () {
			btn.disabled = true;
			post('kuchnia_undo_status', 'order_id=' + encodeURIComponent(orderId), function (x) {
				hideUndo();
				showStatusPopup('Cofnięto – status: ' + (x && x.label ? x.label : ''), true);
			}, function (msg) { hideUndo(); showStatusPopup(msg, true); });
		});
		var close = document.createElement('button');
		close.type = 'button';
		close.className = 'kuchnia-undo-x';
		close.setAttribute('aria-label', 'Zamknij');
		close.textContent = '×';
		close.addEventListener('click', hideUndo);
		bar.appendChild(txt); bar.appendChild(btn); bar.appendChild(close);
		document.body.appendChild(bar); // poza treścią ekranu – zostaje przy odświeżeniu w tle
		undoTimer = setTimeout(hideUndo, r.undo * 1000);
	}

	// ---- Korekta statusu (✎ przy statusie, uprawnienie „Korekta statusu”, 2.39.0) ----
	document.addEventListener('click', function (e) {
		var badge = e.target.closest ? e.target.closest('.kuchnia-status-edit') : null;
		if (!badge) { return; }
		e.preventDefault();
		var orderId = badge.getAttribute('data-order');
		var cur = badge.getAttribute('data-status');
		var statuses = cfg.statuses || {};
		popupRoot.innerHTML = '';
		var backdrop = document.createElement('div');
		backdrop.className = 'kuchnia-popup-backdrop';
		var box = document.createElement('div');
		box.className = 'kuchnia-popup kuchnia-fix';
		var h = document.createElement('p');
		h.innerHTML = '<strong></strong>';
		h.firstChild.textContent = 'Popraw status – zamówienie #' + (badge.getAttribute('data-nr') || orderId);
		var list = document.createElement('div');
		list.className = 'kuchnia-fix-list';
		var chosen = '';
		var save = document.createElement('button');
		save.type = 'button'; save.textContent = 'Zmień status'; save.disabled = true;
		var hint = document.createElement('p');
		hint.className = 'kuchnia-fix-hint';
		Object.keys(statuses).forEach(function (k) {
			var b = document.createElement('button');
			b.type = 'button';
			b.className = 'kuchnia-status-badge kuchnia-status-' + k + (k === cur ? ' is-current' : '');
			b.textContent = statuses[k] + (k === cur ? ' (teraz)' : '');
			b.disabled = (k === cur);
			b.addEventListener('click', function () {
				chosen = k;
				Array.prototype.forEach.call(list.children, function (x) { x.classList.toggle('is-on', x === b); });
				save.disabled = false;
				hint.textContent = (k === 'wydane') ? 'Zamówienie zniknie z ekranu kuriera (zapisze się godzina dostarczenia).'
					: (cur === 'wydane') ? 'Zamówienie wróci na ekran kuriera.' : '';
			});
			list.appendChild(b);
		});
		var reason = document.createElement('input');
		reason.type = 'text'; reason.maxLength = 200;
		reason.className = 'kuchnia-fix-reason';
		reason.placeholder = 'Powód (opcjonalnie), np. kliknięte za wcześnie';
		var cancel = document.createElement('button');
		cancel.type = 'button'; cancel.textContent = 'Anuluj'; cancel.className = 'kuchnia-fix-cancel';
		cancel.addEventListener('click', function () { popupRoot.innerHTML = ''; });
		save.addEventListener('click', function () {
			if (!chosen) { return; }
			save.disabled = true;
			post('kuchnia_correct_status', 'order_id=' + encodeURIComponent(orderId) + '&status=' + encodeURIComponent(chosen) + '&reason=' + encodeURIComponent(reason.value), function (x) {
				popupRoot.innerHTML = '';
				softReload();
			}, function (msg) { save.disabled = false; showStatusPopup(msg, true); });
		});
		var acts = document.createElement('div');
		acts.className = 'kuchnia-fix-acts';
		acts.appendChild(cancel); acts.appendChild(save);
		box.appendChild(h); box.appendChild(list); box.appendChild(hint); box.appendChild(reason); box.appendChild(acts);
		backdrop.appendChild(box);
		backdrop.addEventListener('click', function (ev) { if (ev.target === backdrop) { popupRoot.innerHTML = ''; } });
		popupRoot.appendChild(backdrop);
	});

	// Pakowanie: "Przygotowane" dla jednego zamówienia (szary przy Auto przygotowaniu = opcjonalny).
	document.addEventListener('click', function (e) {
		var btn = e.target.closest ? e.target.closest('.kuchnia-prep-btn') : null;
		if (!btn) { return; }
		btn.disabled = true;
		post('kuchnia_set_status', 'order_id=' + encodeURIComponent(btn.getAttribute('data-order')) + '&status=gotowe', function (r) {
			statusDone(btn.getAttribute('data-order'), r, 'Przygotowane');
		}, function (msg) { btn.disabled = false; showStatusPopup(msg); });
	});

	// Pakowanie: "Spakowane"
	document.addEventListener('click', function (e) {
		var btn = e.target.closest ? e.target.closest('.kuchnia-pack-btn') : null;
		if (!btn) { return; }
		btn.disabled = true;
		post('kuchnia_set_status', 'order_id=' + encodeURIComponent(btn.getAttribute('data-order')) + '&status=w-dostawie', function (r) {
			statusDone(btn.getAttribute('data-order'), r, 'Spakowane');
		}, function (msg) { btn.disabled = false; showStatusPopup(msg); });
	});

	// Kurier: "Dostarczone"
	document.addEventListener('click', function (e) {
		var btn = e.target.closest ? e.target.closest('.kuchnia-deliver-btn') : null;
		if (!btn) { return; }
		btn.disabled = true;
		post('kuchnia_set_status', 'order_id=' + encodeURIComponent(btn.getAttribute('data-order')) + '&status=wydane', function (r) {
			statusDone(btn.getAttribute('data-order'), r, 'Dostarczone');
		}, function (msg) { btn.disabled = false; showStatusPopup(msg); });
	});

	// Kurier / Planowanie: „Otwórz trasę” (2.46.1). Przystanki = wiersze tabeli z adresem, bez dostarczonych,
	// w kolejności z Planowania (w Planowaniu – z bieżących pól, zapis idzie w tle bez przeładowania).
	// Start bez „origin” = miejsce, w którym kurier jest. Google: najwyżej 9 punktów pośrednich + cel = 10 na link.
	var ROUTE_MAX = 10;
	function routeStops(table) {
		var rows = [].slice.call(table.querySelectorAll('tbody tr[data-addr]'));
		var plan = rows.some(function (tr) { return !!tr.querySelector('.kuchnia-plan-input'); });
		if (plan) {
			rows = rows.map(function (tr, i) {
				var inp = tr.querySelector('.kuchnia-plan-input');
				var v = inp ? parseInt(inp.value, 10) : NaN;
				return { tr: tr, k: (v > 0 ? v : 999999 + (parseInt(tr.getAttribute('data-order'), 10) || 0)), i: i };
			}).sort(function (a, b) { return (a.k - b.k) || (a.i - b.i); }).map(function (x) { return x.tr; });
		}
		var out = { stops: [], noAddr: 0 };
		rows.forEach(function (tr) {
			if (tr.getAttribute('data-done') === '1') { return; }
			var a = (tr.getAttribute('data-addr') || '').trim();
			if (!a) { out.noAddr++; return; }
			out.stops.push(a);
		});
		return out;
	}
	function routeUrl(stops) {
		var dest = stops[stops.length - 1];
		var way = stops.slice(0, -1);
		return 'https://www.google.com/maps/dir/?api=1&travelmode=driving&destination=' + encodeURIComponent(dest) +
			(way.length ? '&waypoints=' + way.map(encodeURIComponent).join('%7C') : '');
	}
	function routeParts(stops) {
		var parts = [];
		for (var i = 0; i < stops.length; i += ROUTE_MAX) {
			parts.push({ from: i + 1, to: Math.min(i + ROUTE_MAX, stops.length), url: routeUrl(stops.slice(i, i + ROUTE_MAX)) });
		}
		return parts;
	}
	window.rzdRouteParts = routeParts; // testy
	document.addEventListener('click', function (e) {
		var btn = e.target.closest ? e.target.closest('.rzd-route-btn') : null;
		if (!btn) { return; }
		var table = document.getElementById(btn.getAttribute('data-table'));
		var r = table ? routeStops(table) : { stops: [], noAddr: 0 };
		var skip = r.noAddr ? ' Pominięte bez adresu: ' + r.noAddr + '.' : '';
		if (!r.stops.length) {
			e.preventDefault();
			showStatusPopup('Brak przystanków do trasy – wszystko dostarczone albo zamówienia bez adresu.' + skip);
			return;
		}
		var parts = routeParts(r.stops);
		if (parts.length === 1 && !r.noAddr) {
			btn.href = parts[0].url; // zwykły link – na telefonie otwiera aplikację Mapy Google
			return;
		}
		e.preventDefault();
		popupRoot.innerHTML = '';
		var backdrop = document.createElement('div');
		backdrop.className = 'kuchnia-popup-backdrop';
		var box = document.createElement('div');
		box.className = 'kuchnia-popup rzd-route-pop';
		var p = document.createElement('p');
		p.textContent = (parts.length > 1 ? 'Przystanków: ' + r.stops.length + ' – Mapy Google mieszczą ' + ROUTE_MAX + ' na raz. Otwórz kolejne części po drodze.' : 'Przystanków: ' + r.stops.length + '.') + skip;
		box.appendChild(p);
		parts.forEach(function (pt) {
			var a = document.createElement('a');
			a.className = 'kuchnia-btn kuchnia-btn-primary rzd-route-part';
			a.href = pt.url; a.target = '_blank'; a.rel = 'noopener';
			a.textContent = parts.length > 1 ? '🗺️ Trasa ' + pt.from + '–' + pt.to : '🗺️ Otwórz trasę';
			box.appendChild(a);
		});
		var ok = document.createElement('button');
		ok.type = 'button';
		ok.textContent = 'Zamknij';
		ok.addEventListener('click', function () { popupRoot.innerHTML = ''; });
		box.appendChild(ok);
		backdrop.appendChild(box);
		backdrop.addEventListener('click', function (ev) { if (ev.target === backdrop) { popupRoot.innerHTML = ''; } });
		popupRoot.appendChild(backdrop);
	});

	// Pakowanie: „Odebrane” – odbiór osobisty (2.47.0), klient odebrał zamówienie w lokalu
	document.addEventListener('click', function (e) {
		var btn = e.target.closest ? e.target.closest('.kuchnia-pickup-btn') : null;
		if (!btn) { return; }
		btn.disabled = true;
		post('kuchnia_set_status', 'order_id=' + encodeURIComponent(btn.getAttribute('data-order')) + '&status=wydane', function (r) {
			statusDone(btn.getAttribute('data-order'), r, 'Odebrane');
		}, function (msg) { btn.disabled = false; showStatusPopup(msg); });
	});

	// Zamówienia: "Anuluj" z potwierdzeniem (popup, nie natywny confirm())
	document.addEventListener('click', function (e) {
		var btn = e.target.closest ? e.target.closest('.kuchnia-cancel-btn') : null;
		if (!btn) { return; }
		showConfirmPopup(
			'Na pewno anulować to zamówienie? Tej operacji nie można cofnąć – jeśli klient już zapłacił, zwrot trzeba obsłużyć osobno, zgodnie z polityką zwrotów.',
			'Tak, anuluj',
			function () {
				btn.disabled = true;
				post('kuchnia_cancel_order', 'order_id=' + encodeURIComponent(btn.getAttribute('data-order')), function () {
					showStatusPopup('Zamówienie zostało anulowane.', true);
				}, function (msg) { btn.disabled = false; showStatusPopup(msg); });
			}
		);
	});

	// Pakowanie: rozwijanie szczegółów spakowanego zamówienia
	document.addEventListener('click', function (e) {
		var box = e.target.closest ? e.target.closest('.kuchnia-packed-box') : null;
		if (!box || e.target.closest('.kuchnia-status-edit, .kuchnia-pickup-btn')) { return; }
		var target = document.getElementById(box.getAttribute('data-toggle'));
		if (target) { target.classList.toggle('is-open'); }
	});
})();

/* Dashboard sprzedaży – dymek nad słupkiem (najechanie myszą albo
   dotknięcie). Delegacja na dokumencie, bo treść zakładki podmienia się bez
   przeładowania strony. Tekst przez textContent. */
(function () {
	function show(hit) {
		var wrap = hit.closest('.rd-chart-wrap');
		var tip = wrap ? wrap.querySelector('.rd-tip') : null;
		if (!tip) { return; }
		var on = wrap.querySelector('.rd-hit.is-on');
		if (on && on !== hit) { on.classList.remove('is-on'); }
		hit.classList.add('is-on');
		tip.textContent = hit.getAttribute('data-tip') || '';
		tip.hidden = false;
		var wr = wrap.getBoundingClientRect(), hr = hit.getBoundingClientRect();
		var x = hr.left + hr.width / 2 - wr.left;
		var half = tip.offsetWidth / 2;
		x = Math.max(half, Math.min(wr.width - half, x));
		tip.style.left = x + 'px';
		tip.style.top = (-tip.offsetHeight - 6) + 'px';
	}
	function hide(wrap) {
		var tip = wrap && wrap.querySelector('.rd-tip');
		if (tip) { tip.hidden = true; }
		var on = wrap && wrap.querySelector('.rd-hit.is-on');
		if (on) { on.classList.remove('is-on'); }
	}
	document.addEventListener('mouseover', function (e) {
		var hit = e.target.closest ? e.target.closest('.rd-hit') : null;
		if (hit) { show(hit); }
	});
	document.addEventListener('mouseout', function (e) {
		var hit = e.target.closest ? e.target.closest('.rd-hit') : null;
		var to = e.relatedTarget && e.relatedTarget.closest ? e.relatedTarget.closest('.rd-hit') : null;
		if (hit && !to) { hide(hit.closest('.rd-chart-wrap')); }
	});
	document.addEventListener('click', function (e) {
		var hit = e.target.closest ? e.target.closest('.rd-hit') : null;
		if (hit) { show(hit); return; }
		document.querySelectorAll('.rd-chart-wrap').forEach(hide);
	});
})();
