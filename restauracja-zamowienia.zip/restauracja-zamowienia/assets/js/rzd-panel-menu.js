/* Restauracja – Panel restauracji: sekcja Menu (2.45.0) – Dodatki, Typy, Opakowania, Etykiety na zestawie, Wzory modyfikacji. */
(function () {
	'use strict';
	var K = window.rzdPanelKit;
	if (!K) { return; }
	var h = K.h, S = K.S;
	var TABS = [['dodatki', 'Dodatki'], ['typy', 'Typy dodatków'], ['opakowania', 'Opakowania'], ['etykiety', 'Etykiety na zestawie'], ['wzory', 'Wzory modyfikacji']];

	function copy(o) { return JSON.parse(JSON.stringify(o)); }
	function zl(v) { var n = parseFloat(v) || 0; return (Math.round(n * 100) / 100).toString().replace('.', ',') + ' zł'; }
	function num(v) { return v === '' || v === null || v === undefined ? '' : String(v).replace('.', ','); }
	function done(x) { S.data.menu = x; S.edit = null; S.dirty = false; K.closeSheet(); if (x.message) { K.toast(x.message); } K.render(); return x; }
	function fail(b) { return function (e) { K.busy(b, false); K.toast(e.message, true); }; }
	function save(action, data, b) { K.busy(b, true); return K.api(action, data).then(done, fail(b)); }
	function usedList(list, empty) {
		if (!list || !list.length) { return h('p', { class: 'rp-muted', text: empty }); }
		return h('ul', { class: 'rp-used' }, list.slice(0, 40).map(function (t) { return h('li', { text: t }); }).concat(list.length > 40 ? [h('li', { text: '… i ' + (list.length - 40) + ' więcej' })] : []));
	}
	function iconBox(item, action) {
		var d = S.data.menu;
		var img = item.icon ? h('img', { src: item.icon, alt: '', class: 'rp-icon-img' }) : h('span', { class: 'rp-icon-none', text: 'brak' });
		var file = h('input', { type: 'file', accept: 'image/jpeg,image/png,image/webp,image/gif', class: 'rp-file', 'aria-label': 'Wybierz obrazek' });
		file.addEventListener('change', function () {
			if (!file.files[0]) { return; }
			var fd = { id: item.id, file: file.files[0] };
			K.toast('Wgrywam…');
			upload(action, fd).then(done).then(function (x) { reopen(x); }).catch(function (e) { K.toast(e.message, true); });
		});
		return h('div', { class: 'rp-field' }, [h('span', { class: 'rp-label', text: 'Ikonka' }), h('div', { class: 'rp-inline' }, [
			img,
			d.canUpload ? h('label', { class: 'rp-btn' }, ['Wgraj obrazek', file]) : h('small', { class: 'rp-hint', text: 'To konto nie może wgrywać plików.' }),
			item.icon ? K.btn('Usuń', function () { K.api(action, { id: item.id, remove: '1' }).then(done).then(reopen).catch(function (e) { K.toast(e.message, true); }); }, 'rp-btn-link') : null
		])]);
	}
	var reopenFn = null;
	function reopen(x) { if (reopenFn) { var f = reopenFn; reopenFn = null; f(x); } }
	function upload(action, data) {
		var fd = new FormData();
		fd.append('action', 'rzd_panel'); fd.append('do', action); fd.append('_n', K.C.nonce);
		Object.keys(data).forEach(function (k) { fd.append(k, data[k]); });
		return fetch(K.C.ajax, { method: 'POST', body: fd, credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (x) { if (!x || !x.ok) { throw new Error((x && x.message) || 'Nie udało się.'); } return x; });
	}

	function secMenu(main) {
		var d = S.data.menu;
		if (!d) {
			K.loading(main, 'Menu');
			K.load('menu', 'menu').then(K.render).catch(function (e) { main.textContent = ''; K.failBox(main, e, K.render); });
			return;
		}
		var tab = S.tab || 'dodatki';
		if (tab === 'wzory' && S.preset) { presetView(main, d); return; }
		main.appendChild(K.pageHead('Menu', 'Katalogi, z których składa się menu: dodatki (skład i modyfikacje dań), opakowania, etykiety dań w zestawach i wzory modyfikacji. Kwoty brutto.'));
		main.appendChild(K.tabsEl(TABS, tab));
		({ dodatki: tabAddons, typy: tabTypes, opakowania: tabPacks, etykiety: tabLabels, wzory: tabPresets })[tab](main, d);
		if (S.urlId) { // przekierowanie z kokpitu na konkretną pozycję
			var id = S.urlId; S.urlId = 0;
			var f = tab === 'dodatki' ? d.addons : (tab === 'opakowania' ? d.packs : (tab === 'wzory' ? d.presets : []));
			var it = f.filter(function (x) { return x.id === id; })[0];
			if (it) { if (tab === 'dodatki') { addonEdit(it); } else if (tab === 'opakowania') { packEdit(it); } else { S.preset = copy(it); K.render(); } }
		}
	}

	/* ---------- Dodatki ---------- */
	function tabAddons(main, d) {
		var f = S.addonFilter = S.addonFilter || { q: '', type: '' };
		var q = h('input', { type: 'search', class: 'rp-in', value: f.q, placeholder: 'Szukaj dodatku', 'aria-label': 'Szukaj dodatku', oninput: function () { f.q = q.value; drawList(); } });
		var ts = h('select', { class: 'rp-in', 'aria-label': 'Typ', onchange: function () { f.type = ts.value; drawList(); } }, [h('option', { value: '', text: 'Wszystkie typy' }), h('option', { value: '0', selected: f.type === '0', text: 'Bez typu' })].concat(d.types.map(function (t) { return h('option', { value: String(t.id), selected: f.type === String(t.id), text: t.name }); })));
		main.appendChild(h('div', { class: 'rp-filters' }, [h('div', { class: 'rp-search' }, [q]), ts, K.btn('+ Dodatek', function () { addonEdit(null); }, 'rp-btn-pri')]));
		var list = h('div', { class: 'rp-list' });
		function drawList() {
			list.textContent = '';
			var needle = f.q.trim().toLowerCase();
			var rows = d.addons.filter(function (a) { return (!needle || a.name.toLowerCase().indexOf(needle) > -1) && (f.type === '' || String(a.type) === f.type); });
			if (!rows.length) { list.appendChild(h('p', { class: 'rp-empty-s', text: d.addons.length ? 'Brak dodatków dla tych filtrów.' : 'Nie ma jeszcze dodatków.' })); return; }
			rows.forEach(function (a) {
				var price = (a.minus === '' || Math.abs(a.minus - a.price) < 0.001) ? zl(a.price) : '+' + zl(a.price) + ' / −' + zl(a.minus);
				list.appendChild(h('button', { type: 'button', class: 'rp-row', onclick: function () { addonEdit(a); } }, [
					a.icon ? h('img', { src: a.icon, alt: '', class: 'rp-row-ico' }) : h('span', { class: 'rp-row-ico' }),
					h('span', { class: 'rp-row-main' }, [h('strong', { text: a.name }), h('small', { text: [a.typeName || 'bez typu', price, a.mandatory ? 'obowiązkowy' : '', a.pack ? 'z opakowaniem' : ''].filter(Boolean).join(' · ') })]),
					h('span', { class: 'rp-pill' + (a.used.length ? ' ok' : ''), text: a.used.length ? 'użyty: ' + a.used.length : 'nieużywany' })
				]));
			});
		}
		drawList();
		main.appendChild(list);
		main.appendChild(h('p', { class: 'rp-muted', text: 'Typ mówi, czym dodatek jest w daniu (np. Węglowodany): wybór klienta zastępuje w składzie dodatek tego samego typu, „Bez …” skreśla ten typ, a dodatek z typem w modyfikacji pokazuje nazwę dodatku tego typu ze składu dania.' }));
	}
	function addonEdit(a) {
		var d = S.data.menu;
		var isNew = !a;
		a = a || { id: 0, name: '', type: 0, price: 0, minus: '', mandatory: false, pack: 0, cap: 1, icon: '', used: [] };
		var name = h('input', { type: 'text', class: 'rp-in', value: a.name, maxlength: '80' });
		var type = h('select', { class: 'rp-in' }, [h('option', { value: '0', text: '— bez typu (działa swoją nazwą i ceną) —' })].concat(d.types.map(function (t) { return h('option', { value: String(t.id), selected: a.type === t.id, text: t.name }); })));
		var price = h('input', { type: 'text', inputmode: 'decimal', class: 'rp-in', value: num(a.price) });
		var minus = h('input', { type: 'text', inputmode: 'decimal', class: 'rp-in', value: num(a.minus), placeholder: 'jak przy dodaniu' });
		var mand = h('input', { type: 'checkbox', checked: a.mandatory });
		var pack = h('select', { class: 'rp-in' }, [h('option', { value: '0', text: '— brak —' })].concat(d.packs.map(function (p) { return h('option', { value: String(p.id), selected: a.pack === p.id, text: p.name + ' (' + zl(p.price) + ')' }); })));
		var cap = h('input', { type: 'number', class: 'rp-in rp-in-s', min: '1', max: '99', value: a.cap || 1 });
		var err = h('p', { class: 'rp-err', role: 'alert', hidden: true });
		var body = h('div', { class: 'rp-form' }, [
			K.field('Nazwa', name),
			K.field('Typ', type),
			h('div', { class: 'rp-grid2' }, [
				K.field('Wartość przy dodaniu (zł)', price, 'Dolicza się przy roli „Dodaje” / „Obowiązkowa”; to też cena dokładki w „Powiel skład” (0 = bez dokładki). Może być ujemna.'),
				K.field('Wartość przy odejmowaniu (zł)', minus, 'Przy roli „Odejmuje” / „Dezaktywuje”. Puste = tyle samo co przy dodaniu.')
			]),
			h('label', { class: 'rp-check' }, [mand, h('span', { text: 'Obowiązkowy – klient nie może go zdjąć (np. opakowanie)' })]),
			h('div', { class: 'rp-grid2' }, [K.field('Opakowanie', pack, 'Dolicza się tylko, gdy klient wybierze dodatek z dopłatą.'), K.field('Ile sztuk mieści opakowanie', cap)]),
			isNew ? null : iconBox(a, 'addon_icon'),
			isNew ? null : h('div', { class: 'rp-field' }, [h('span', { class: 'rp-label', text: 'Gdzie używany' }), usedList(a.used, 'Nigdzie – można go usunąć.')]),
			err
		]);
		reopenFn = function (x) { var n = x.addons.filter(function (y) { return y.id === a.id; })[0]; if (n) { addonEdit(n); } };
		var ok = K.btn(isNew ? 'Dodaj' : 'Zapisz', function () {
			if (!name.value.trim()) { err.textContent = 'Podaj nazwę dodatku.'; err.hidden = false; name.focus(); return; }
			var dup = d.addons.some(function (x) { return x.id !== a.id && x.name.toLowerCase() === name.value.trim().toLowerCase() && String(x.type) === type.value; });
			if (dup && !window.confirm('Jest już dodatek „' + name.value.trim() + '” z tym samym typem. Dodać drugi?')) { return; }
			save('addon_save', { item: { id: a.id, name: name.value, type: type.value, price: price.value, price_minus: minus.value, mandatory: mand.checked ? 1 : 0, pack: pack.value, cap: cap.value } }, ok);
		}, 'rp-btn-pri');
		var foot = [ok];
		if (!isNew) {
			foot.unshift(K.btn('Usuń', function () {
				if (a.used.length) { K.toast('Dodatek jest używany (' + a.used.length + ') – najpierw usuń go z dań i wzorów.', true); return; }
				if (!window.confirm('Usunąć dodatek „' + a.name + '”?')) { return; }
				save('addon_delete', { id: a.id }, null);
			}, 'rp-btn-del'));
		}
		K.openSheet(isNew ? 'Nowy dodatek' : a.name, body, foot);
	}

	/* ---------- Typy ---------- */
	function termTab(main, list, what, saveA, delA, hint) {
		main.appendChild(h('p', { class: 'rp-muted', text: hint }));
		main.appendChild(h('div', { class: 'rp-actions' }, [K.btn('+ ' + what, function () { termEdit(null, what, saveA, delA); }, 'rp-btn-pri')]));
		var l = h('div', { class: 'rp-list' });
		if (!list.length) { l.appendChild(h('p', { class: 'rp-empty-s', text: 'Brak.' })); }
		list.forEach(function (t) {
			l.appendChild(h('button', { type: 'button', class: 'rp-row', onclick: function () { termEdit(t, what, saveA, delA); } }, [
				h('span', { class: 'rp-row-main' }, [h('strong', { text: t.name })]),
				h('span', { class: 'rp-pill' + (t.count ? ' ok' : ''), text: t.count ? 'używany: ' + t.count : 'nieużywany' })
			]));
		});
		main.appendChild(l);
	}
	function termEdit(t, what, saveA, delA) {
		var name = h('input', { type: 'text', class: 'rp-in', value: t ? t.name : '', maxlength: '60' });
		var ok = K.btn(t ? 'Zapisz' : 'Dodaj', function () { if (!name.value.trim()) { name.focus(); return; } save(saveA, { id: t ? t.id : 0, name: name.value }, ok); }, 'rp-btn-pri');
		name.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); ok.click(); } });
		var foot = [ok];
		if (t) { foot.unshift(K.btn('Usuń', function () { if (!window.confirm('Usunąć „' + t.name + '”?')) { return; } save(delA, { id: t.id }, null); }, 'rp-btn-del')); }
		K.openSheet(t ? t.name : what, h('div', { class: 'rp-form' }, [K.field('Nazwa', name)]), foot);
	}
	function tabTypes(main, d) {
		termTab(main, d.types, 'Typ', 'type_save', 'type_delete', 'Typy dodatków, np. Mięso, Węglowodany, Surówka. Dodatek ma najwyżej jeden typ; w składzie dania najwyżej jeden dodatek danego typu.');
	}

	/* ---------- Opakowania ---------- */
	function tabPacks(main, d) {
		main.appendChild(h('p', { class: 'rp-muted', text: 'Opakowanie przypinasz do kategorii (Edycja menu → Kategorie – tam też ile sztuk mieści), do dania (edycja produktu) albo do dodatku (zakładka Dodatki). Opłata dolicza się w koszyku brutto i nie liczy się do progów dostawy.' }));
		main.appendChild(h('div', { class: 'rp-actions' }, [K.btn('+ Opakowanie', function () { packEdit(null); }, 'rp-btn-pri')]));
		var l = h('div', { class: 'rp-list' });
		if (!d.packs.length) { l.appendChild(h('p', { class: 'rp-empty-s', text: 'Nie ma jeszcze opakowań.' })); }
		d.packs.forEach(function (p) {
			var n = p.used.cats.length + p.used.products.length + p.used.addons.length;
			l.appendChild(h('button', { type: 'button', class: 'rp-row', onclick: function () { packEdit(p); } }, [
				p.icon ? h('img', { src: p.icon, alt: '', class: 'rp-row-ico' }) : h('span', { class: 'rp-row-ico' }),
				h('span', { class: 'rp-row-main' }, [h('strong', { text: p.name }), h('small', { text: zl(p.price) + (p.used.cats.length ? ' · kategorie: ' + p.used.cats.join(', ') : '') })]),
				h('span', { class: 'rp-pill' + (n ? ' ok' : ''), text: n ? 'przypięte: ' + n : 'nieprzypięte' })
			]));
		});
		main.appendChild(l);
	}
	function packEdit(p) {
		var isNew = !p;
		p = p || { id: 0, name: '', price: 0, icon: '', used: { cats: [], products: [], addons: [] } };
		var name = h('input', { type: 'text', class: 'rp-in', value: p.name, maxlength: '80' });
		var price = h('input', { type: 'text', inputmode: 'decimal', class: 'rp-in rp-in-s', value: num(p.price) });
		var n = p.used.cats.length + p.used.products.length + p.used.addons.length;
		reopenFn = function (x) { var y = x.packs.filter(function (z) { return z.id === p.id; })[0]; if (y) { packEdit(y); } };
		var body = h('div', { class: 'rp-form' }, [
			K.field('Nazwa', name),
			K.field('Cena za sztukę (zł, brutto)', price),
			isNew ? null : iconBox(p, 'pack_icon'),
			isNew ? null : h('div', { class: 'rp-field' }, [h('span', { class: 'rp-label', text: 'Przypięte do' }),
				usedList([].concat(p.used.cats.map(function (x) { return 'Kategoria: ' + x; }), p.used.products.map(function (x) { return 'Danie: ' + x; }), p.used.addons.map(function (x) { return 'Dodatek: ' + x; })), 'Nigdzie – można je usunąć.')])
		]);
		var ok = K.btn(isNew ? 'Dodaj' : 'Zapisz', function () { if (!name.value.trim()) { name.focus(); return; } save('pack_save', { item: { id: p.id, name: name.value, price: price.value } }, ok); }, 'rp-btn-pri');
		var foot = [ok];
		if (!isNew) {
			foot.unshift(K.btn('Usuń', function () {
				if (n) { K.toast('Opakowanie jest przypięte (' + n + ') – najpierw je odepnij.', true); return; }
				if (!window.confirm('Usunąć opakowanie „' + p.name + '”?')) { return; }
				save('pack_delete', { id: p.id }, null);
			}, 'rp-btn-del'));
		}
		K.openSheet(isNew ? 'Nowe opakowanie' : p.name, body, foot);
	}

	/* ---------- Etykiety na zestawie ---------- */
	function tabLabels(main, d) {
		termTab(main, d.labels, 'Etykieta', 'label_save', 'label_delete', 'Etykieta mówi, czym danie jest w zestawie (np. Zupa, Drugie danie). Razem z kolejnością ustala kolejność zdjęć, sklejonej nazwy zestawu i składu – to cecha dania, nie konkretnego zestawu.');
		var e = S.edit = S.edit || { roles: copy(d.roles) };
		var box = h('section', { class: 'rp-card' }, [h('h2', { text: 'Dania w zestawach: etykieta i kolejność' }), h('p', { class: 'rp-muted', text: 'Najmniejsza liczba idzie pierwsza; bez liczby – na końcu. Lista: dania ułożone w zestawach i dania z etykietą.' })]);
		if (!e.roles.length) { box.appendChild(h('p', { class: 'rp-muted', text: 'Żadne danie nie jest jeszcze w zestawie.' })); }
		var tbl = h('div', { class: 'rp-roles' });
		e.roles.forEach(function (r) {
			var sel = h('select', { class: 'rp-in', 'aria-label': 'Etykieta: ' + r.name, onchange: function () { r.label = parseInt(sel.value, 10) || 0; K.dirty(); } }, [h('option', { value: '0', text: '— bez etykiety —' })].concat(d.labels.map(function (l) { return h('option', { value: String(l.id), selected: r.label === l.id, text: l.name }); })));
			var ord = h('input', { type: 'number', class: 'rp-in rp-in-s', min: '0', value: r.order === '' ? '' : String(r.order), placeholder: '–', 'aria-label': 'Kolejność: ' + r.name, oninput: function () { r.order = ord.value; K.dirty(); } });
			tbl.appendChild(h('div', { class: 'rp-role' }, [h('strong', { text: r.name }), sel, ord]));
		});
		box.appendChild(tbl);
		main.appendChild(box);
		if (e.roles.length) {
			main.appendChild(K.saveBar(function (b) { save('roles_save', { rows: e.roles.map(function (r) { return { id: r.id, label: r.label, order: r.order }; }) }, b); }, 'Zapisz etykiety dań'));
		}
	}

	/* ---------- Wzory modyfikacji ---------- */
	function tabPresets(main, d) {
		main.appendChild(h('p', { class: 'rp-muted', text: 'Wzór to gotowe grupy modyfikacji (np. „wybierz dodatek: frytki / ziemniaki / kluski”). Wstawienie do dania robi KOPIĘ – późniejsza zmiana wzoru nie zmienia dań. Wstawiasz je w Edycji menu (karta dania → „+ Dodaj wzór”) albo w edycji produktu.' }));
		main.appendChild(h('div', { class: 'rp-actions' }, [K.btn('+ Wzór', function () { S.preset = { id: 0, title: '', active: true, sections: [], copies: [] }; K.render(); }, 'rp-btn-pri')]));
		var l = h('div', { class: 'rp-list' });
		if (!d.presets.length) { l.appendChild(h('p', { class: 'rp-empty-s', text: 'Nie ma jeszcze wzorów.' })); }
		d.presets.forEach(function (p) {
			var mods = p.sections.reduce(function (n, s) { return n + s.items.length; }, 0);
			l.appendChild(h('button', { type: 'button', class: 'rp-row' + (p.active ? '' : ' off'), onclick: function () { S.preset = copy(p); K.render(); } }, [
				h('span', { class: 'rp-row-main' }, [h('strong', { text: p.title }), h('small', { text: p.sections.length ? 'Grup: ' + p.sections.length + ', modyfikacji: ' + mods + ' · ' + p.sections.map(function (s) { return s.header || '(bez nagłówka)'; }).join(' · ') : 'pusty – nie pojawi się do wstawienia' })]),
				h('span', { class: 'rp-pill' + (p.active ? ' ok' : ''), text: p.active ? 'aktywny' : 'nieaktywny' })
			]));
		});
		main.appendChild(l);
	}
	function presetView(main, d) {
		var p = S.preset;
		main.appendChild(h('button', { type: 'button', class: 'rp-back', onclick: function () {
			if (S.dirty && !window.confirm('Masz niezapisane zmiany we wzorze. Wyjść bez zapisu?')) { return; }
			S.dirty = false; S.preset = null; K.render();
		} }, [h('span', { html: K.ICON.back }), 'Wszystkie wzory']));
		main.appendChild(K.pageHead(p.id ? p.title || 'Wzór' : 'Nowy wzór', p.copies && p.copies.length ? 'Kopie grup tego wzoru są w daniach: ' + p.copies.slice(0, 8).join(', ') + (p.copies.length > 8 ? ' …' : '') + ' (zmiana wzoru ich nie zmienia).' : null));
		var title = h('input', { type: 'text', class: 'rp-in', value: p.title, maxlength: '80', placeholder: 'np. Wybór dodatku do obiadu', oninput: function () { p.title = title.value; K.dirty(); } });
		var act = h('input', { type: 'checkbox', class: 'rp-switch-in', checked: p.active, onchange: function () { p.active = act.checked; K.dirty(); } });
		main.appendChild(h('section', { class: 'rp-card rp-form' }, [
			K.field('Nazwa wzoru (widzisz tylko Ty)', title),
			h('label', { class: 'rp-switch' }, [act, h('span', { class: 'rp-switch-ui', 'aria-hidden': 'true' }), h('span', { text: 'Aktywny – do wstawienia w daniach' })])
		]));
		var gl = h('section', { class: 'rp-card' }, [h('h2', { text: 'Grupy (' + p.sections.length + ')' })]);
		if (!p.sections.length) { gl.appendChild(h('p', { class: 'rp-muted', text: 'Brak grup – dodaj pierwszą.' })); }
		p.sections.forEach(function (g, i) {
			gl.appendChild(h('div', { class: 'rp-grp' }, [
				h('button', { type: 'button', class: 'rp-grp-b', onclick: function () { editGroup(i); } }, [h('strong', { text: g.header || '(grupa bez nagłówka)' }), h('small', { text: window.rzdGroupEditor.summary(g, d.dict) + ' · ' + (g.place === 'cart' ? 'w przeglądzie zamówienia' : 'przed dodaniem') })]),
				h('button', { type: 'button', class: 'rp-ico', 'aria-label': 'W górę', text: '↑', disabled: i === 0 ? true : null, onclick: function () { p.sections.splice(i - 1, 0, p.sections.splice(i, 1)[0]); K.dirty(); K.render(); } }),
				h('button', { type: 'button', class: 'rp-ico', 'aria-label': 'W dół', text: '↓', disabled: i === p.sections.length - 1 ? true : null, onclick: function () { p.sections.splice(i + 1, 0, p.sections.splice(i, 1)[0]); K.dirty(); K.render(); } })
			]));
		});
		gl.appendChild(K.btn('+ Grupa', function () { editGroup(-1); }));
		main.appendChild(gl);
		var acts = [];
		if (p.id) {
			acts.push(K.btn('Duplikuj', function () { if (S.dirty) { K.toast('Najpierw zapisz albo cofnij zmiany.', true); return; } K.api('preset_dup', { id: p.id }).then(function (x) { done(x); var n = x.presets.filter(function (y) { return y.id === x.savedId; })[0]; S.preset = n ? copy(n) : null; K.render(); }).catch(function (e) { K.toast(e.message, true); }); }));
			acts.push(K.btn('Usuń wzór', function () {
				if (!window.confirm('Usunąć wzór „' + p.title + '”?' + (p.copies.length ? ' Dania z jego kopiami (' + p.copies.length + ') zostają bez zmian.' : ''))) { return; }
				K.api('preset_delete', { id: p.id }).then(function (x) { S.preset = null; done(x); }).catch(function (e) { K.toast(e.message, true); });
			}, 'rp-btn-del'));
		}
		main.appendChild(h('div', { class: 'rp-actions' }, acts));
		main.appendChild(K.saveBar(function (b) {
			if (!p.title.trim()) { K.toast('Podaj nazwę wzoru.', true); title.focus(); return; }
			K.busy(b, true);
			K.api('preset_save', { item: { id: p.id, title: p.title, active: p.active ? 1 : 0, sections: p.sections } }).then(function (x) {
				done(x);
				var n = x.presets.filter(function (y) { return y.id === x.savedId; })[0];
				S.preset = n ? copy(n) : null; K.render();
			}, fail(b));
		}, 'Zapisz wzór'));
		if (!p.id && !S.dirty) { setTimeout(function () { title.focus(); }, 30); }
	}
	function editGroup(i) {
		var p = S.preset, d = S.data.menu;
		window.rzdGroupEditor.open({
			title: i < 0 ? 'Nowa grupa' : (p.sections[i].header || 'Grupa'),
			group: i < 0 ? null : p.sections[i],
			dict: d.dict,
			onSave: function (g) { if (i < 0) { p.sections.push(g); } else { p.sections[i] = g; } K.dirty(); K.render(); },
			onDelete: i < 0 ? null : function () { p.sections.splice(i, 1); K.dirty(); K.render(); }
		});
	}

	K.sections.menu = secMenu;
})();
