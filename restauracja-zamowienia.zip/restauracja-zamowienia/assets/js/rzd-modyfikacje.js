/* Restauracja – Zamówienia i Dostawy: okienko modyfikacji produktu, krok bramy „modyfikacje” (2.26.13: plik zamiast kodu w stronie) */
// rzdMods – ustawiane przez WordPress przed tym plikiem (wp_add_inline_script)
	(function () {
		var modal = document.getElementById('rzd-mods');
		if (!modal) { return; }
		var elPicked = modal.querySelector('.rzd-picked');
		var elGroups = modal.querySelector('.rzd-groups'), elTotal = modal.querySelector('.rzd-total'),
			elOk = modal.querySelector('.rzd-ok'), elCancel = modal.querySelector('.rzd-cancel');
		var st = { groups: [], ctx: null, next: null, mode: 'before', preset: {}, cartKey: '', qty: 1, onSaved: null };
		// 2.26.16: tryb „w koszyku” zmienia tytuł i napis przycisku – oryginały do przywrócenia.
		var elTitle = modal.querySelector('h3');
		var origTitle = elTitle ? elTitle.textContent : '', origOk = elOk.textContent;

		function closeModal() { modal.hidden = true; st.next = null; }
		function presetVal(index) {
			var p = st.preset && st.preset[index];
			return (p && p.val !== undefined) ? String(p.val) : null;
		}
		function money(v) { return (v >= 0 ? '+' : '') + v.toFixed(2).replace('.', ',') + ' zł'; }

		// --- Wzajemne blokowanie: ten sam dodatek jako "dodaje" w jednym
		// miejscu i "odejmuje" w innym – aktywacja jednego blokuje drugie.
		function isActive(g) {
			if (g.type === 'radio') {
				return null; // radio liczone per-opcja, patrz niżej
			}
			if (g.type === 'tap') { return g.el.querySelector('.rzd-tap').classList.contains('rzd-on'); }
			if (g.type === 'stepper') { return (parseInt(g.el.querySelector('.rzd-stepper-qty').textContent, 10) || 0) > 0; }
			return false;
		}
		function updateExclusions() {
			// addon_id (rozwiązany konkretny składnik) -> { dodaje: bool, odejmuje: bool, dezaktywuje: bool }
			// Blokowanie działa w obrębie JEDNEGO dania (scope = produkt-źródło): w zestawie "Bez mięsa"
			// z jednego dania nie może wyszarzać "Dodatkowe mięso" z drugiego.
			// W obrębie JEDNEGO produktu typ zawsze rozwiązuje się do tego samego,
			// jednego dodatku (patrz rzd_resolve_addon_name_for_product w PHP), więc grupowanie
			// po addon_id jest tu równoważne grupowaniu po typie.
			var byAddon = {};
			function mark(scope, addonId, role, active) {
				if (!addonId || role === 'neutralna' || role === 'obowiazkowa' || !active) { return; }
				var k = scope + ':' + addonId;
				if (!byAddon[k]) { byAddon[k] = {}; }
				byAddon[k][role] = true;
			}
			st.groups.forEach(function (g) {
				if (g.type === 'radio') {
					var checked = g.el.querySelector('input:checked');
					if (checked) {
						var oi = parseInt(checked.getAttribute('data-oi'), 10);
						var opt = g.options[oi];
						if (opt) { mark(g.scope, opt.addon_id, opt.role, true); }
					}
				} else {
					mark(g.scope, g.addonId, g.role, isActive(g));
				}
			});
			// "Dezaktywuje" blokuje WSZYSTKO inne tego typu (i dodaje, i odejmuje);
			// "dodaje"/"odejmuje" blokują się nawzajem I blokują "dezaktywuje" –
			// tylko jedna "rodzina ról" może być naraz aktywna dla danego typu.
			function blockedFor(scope, addonId, role) {
				var st2 = byAddon[scope + ':' + addonId];
				if (!st2) { return false; }
				if (role === 'dodaje') { return !!(st2.odejmuje || st2.dezaktywuje); }
				if (role === 'odejmuje') { return !!(st2.dodaje || st2.dezaktywuje); }
				if (role === 'dezaktywuje') { return !!(st2.dodaje || st2.odejmuje); }
				return false;
			}
			// zastosuj blokady (dodatki obowiązkowe/locked mają swój stały stan – ich nie ruszamy)
			st.groups.forEach(function (g) {
				if (g.locked) { return; }
				if (g.type === 'radio') {
					g.options.forEach(function (opt, oi) {
						var inp = g.el.querySelectorAll('input')[oi];
						if (!inp) { return; }
						var blocked = blockedFor(g.scope, opt.addon_id, opt.role) && !inp.checked;
						inp.disabled = !!blocked;
						var sq = inp.closest('.rzd-square');
						if (sq) { sq.classList.toggle('rzd-locked', !!blocked); }
					});
				} else if (g.role === 'dodaje' || g.role === 'odejmuje' || g.role === 'dezaktywuje') {
					var active = isActive(g);
					var blocked = blockedFor(g.scope, g.addonId, g.role) && !active;
					if (g.type === 'tap') {
						g.el.querySelector('.rzd-tap').disabled = !!blocked;
					} else if (g.type === 'stepper') {
						g.el.querySelectorAll('.rzd-stepper-btn').forEach(function (b) { b.disabled = !!blocked; });
					}
				}
			});
		}

		// Podsumowanie wyboru w rodzajach – ta sama reguła co rzd_mod_kind() w PHP.
		function modKind(role, price, mandatory) {
			if (role === 'odejmuje' || role === 'dezaktywuje') { return 'bez'; }
			if (role === 'obowiazkowa' || mandatory) { return 'obowiazkowe'; }
			return (price > 0.001) ? 'dodatki' : 'zestaw';
		}
		function paintPicked() {
			if (!elPicked) { return; }
			var labels = { zestaw: 'Wybór w zestawie', dodatki: 'Dodatki (płatne)', obowiazkowe: 'Obowiązkowe', bez: 'Bez' };
			var pick = { zestaw: [], dodatki: [], obowiazkowe: [], bez: [] };
			st.groups.forEach(function (g) {
				if (g.type === 'radio') {
					var c = g.el.querySelector('input:checked');
					if (!c) { return; }
					var o = g.options[parseInt(c.getAttribute('data-oi'), 10)];
					if (o) { pick[modKind(o.role, o.price, o.mandatory)].push(o.label); }
				} else if (g.type === 'tap') {
					if (g.el.querySelector('.rzd-tap').classList.contains('rzd-on')) { pick[modKind(g.role, g.price, g.locked)].push(g.label); }
				} else if (g.type === 'stepper') {
					var q = parseInt(g.el.querySelector('.rzd-stepper-qty').textContent, 10) || 0;
					if (q > 0) { pick[modKind(g.role, g.price, g.locked)].push((q > 1 ? q + '× ' : '') + g.label); }
				}
			});
			elPicked.innerHTML = '';
			Object.keys(labels).forEach(function (k) {
				if (!pick[k].length) { return; }
				var d = document.createElement('div');
				var b = document.createElement('strong');
				b.textContent = labels[k] + ': ';
				d.appendChild(b);
				d.appendChild(document.createTextNode(pick[k].join(', ')));
				elPicked.appendChild(d);
			});
		}

		function recalc() {
			var total = 0;
			st.groups.forEach(function (g) {
				if (g.type === 'radio') {
					var checked = g.el.querySelector('input:checked');
					if (checked) { total += parseFloat(checked.getAttribute('data-price')) || 0; }
				} else if (g.type === 'tap') {
					if (g.el.querySelector('.rzd-tap').classList.contains('rzd-on')) { total += g.price; }
				} else if (g.type === 'text') {
					var inp = g.el.querySelector('input[type=text]');
					if (inp && inp.value.trim() !== '') { total += g.price; }
				} else if (g.type === 'stepper') {
					var qty = parseInt(g.el.querySelector('.rzd-stepper-qty').textContent, 10) || 0;
					total += qty * g.price;
				}
			});
			elTotal.textContent = (Math.abs(total) < 0.001) ? 'bez dopłaty' : money(total);
			paintPicked();
			updateExclusions();

			// Pojedynczy wybór (lista opcji) jest obowiązkowy – bez zaznaczenia żadnej opcji nie da się przejść dalej.
			var missingRequired = st.groups.some(function (g) {
				return g.type === 'radio' && g.options.length && !g.el.querySelector('input:checked');
			});
			elOk.disabled = missingRequired;
		}

		// 2.26.16: „X jest już w daniu – to dodatkowa porcja”
		function addNote(g, box) {
			if (!g.has_note) { return; }
			var n = document.createElement('div');
			n.className = 'rzd-lock-note rzd-has-note';
			n.textContent = g.has_note;
			box.appendChild(n);
		}

		function renderModifier(g, box) {
			if (g.type === 'radio') {
				var row = document.createElement('div');
				row.className = 'rzd-squares';
				g.options.forEach(function (opt, oi) {
					var sq = document.createElement('label');
					sq.className = 'rzd-square';
					var inp = document.createElement('input');
					// 2.26.17: wartość = numer opcji w ustawieniach (opt.oi), nie pozycja na odfiltrowanej liście.
					inp.type = 'radio'; inp.name = 'rzd_r_' + g.index; inp.value = (opt.oi !== undefined) ? opt.oi : oi;
					inp.setAttribute('data-price', opt.price);
					inp.setAttribute('data-oi', oi);
					inp.style.display = 'none';
					if (opt.mandatory && g.options.length === 1) { inp.checked = true; sq.classList.add('rzd-on'); }
					inp.addEventListener('change', function () {
						row.querySelectorAll('.rzd-square').forEach(function (s) { s.classList.remove('rzd-on'); });
						sq.classList.add('rzd-on');
						recalc();
					});
					sq.appendChild(inp);
					if (opt.icon_url) {
						var oicon = document.createElement('img');
						oicon.src = opt.icon_url; oicon.className = 'rzd-square-icon'; oicon.alt = '';
						sq.appendChild(oicon);
						sq.appendChild(document.createElement('br'));
					}
					sq.appendChild(document.createTextNode(opt.label));
					if (opt.price_html) { var sm = document.createElement('small'); sm.textContent = opt.price_html; sq.appendChild(sm); }
					row.appendChild(sq);
				});
				box.appendChild(row);
				st.groups.push({ index: g.index, type: 'radio', options: g.options, scope: g.scope, locked: false, el: box });
				return;
			}

			if (g.type === 'tap') {
				var btn = document.createElement('button');
				btn.type = 'button'; btn.className = 'rzd-tap';
				if (g.icon_url) {
					var ticon = document.createElement('img');
					ticon.src = g.icon_url; ticon.className = 'rzd-tap-icon'; ticon.alt = '';
					btn.appendChild(ticon); btn.appendChild(document.createElement('br'));
				}
				btn.appendChild(document.createTextNode(g.label + (g.price_html ? ' ' + g.price_html : '')));
				if (g.locked) {
					btn.classList.add('rzd-on');
					btn.disabled = true;
					var note = document.createElement('div');
					note.className = 'rzd-lock-note';
					note.textContent = 'Zawsze dołączone';
					box.appendChild(note);
				} else {
					if (presetVal(g.index) === '1') { btn.classList.add('rzd-on'); }
					btn.addEventListener('click', function () { btn.classList.toggle('rzd-on'); recalc(); });
				}
				box.appendChild(btn);
				addNote(g, box);
				st.groups.push({ index: g.index, type: 'tap', scope: g.scope, addonId: g.addon_id, role: g.role, locked: !!g.locked, price: g.price || 0, label: g.label, el: box });
				return;
			}

			if (g.type === 'text') {
				var t = document.createElement('input');
				t.type = 'text'; t.style.width = '100%'; t.placeholder = g.placeholder || '';
				if (presetVal(g.index) !== null) { t.value = presetVal(g.index); }
				t.addEventListener('input', recalc);
				box.appendChild(t);
				st.groups.push({ index: g.index, type: 'text', price: g.price || 0, el: box });
				return;
			}

			// stepper
			var srow = document.createElement('div');
			srow.className = 'rzd-stepper';
			if (g.icon_url) {
				var icon = document.createElement('img');
				icon.src = g.icon_url; icon.className = 'rzd-stepper-icon'; icon.alt = '';
				srow.appendChild(icon);
			}
			var label = document.createElement('span');
			label.className = 'rzd-stepper-label';
			label.textContent = g.label + (g.price_html ? ' ' + g.price_html + '/szt.' : '');
			srow.appendChild(label);

			var ctrl = document.createElement('span');
			ctrl.className = 'rzd-stepper-ctrl';
			var minus = document.createElement('button');
			minus.type = 'button'; minus.className = 'rzd-stepper-btn'; minus.textContent = '-';
			var qtySpan = document.createElement('span');
			qtySpan.className = 'rzd-stepper-qty';
			var start = g.locked ? Math.max(1, g.min || 0) : Math.max(g.min || 0, Math.min(g.max || 10, parseInt(presetVal(g.index), 10) || 0));
			qtySpan.textContent = String(start);
			var plus = document.createElement('button');
			plus.type = 'button'; plus.className = 'rzd-stepper-btn'; plus.textContent = '+';

			function setQty(v) {
				v = Math.max(g.min || 0, Math.min(g.max || 10, v));
				qtySpan.textContent = String(v);
				recalc();
			}
			if (g.locked) {
				minus.disabled = true; plus.disabled = true;
				var note2 = document.createElement('div');
				note2.className = 'rzd-lock-note';
				note2.textContent = 'Zawsze dołączone';
				box.appendChild(note2);
			} else {
				minus.addEventListener('click', function () { setQty((parseInt(qtySpan.textContent, 10) || 0) - 1); });
				plus.addEventListener('click', function () { setQty((parseInt(qtySpan.textContent, 10) || 0) + 1); });
			}
			ctrl.appendChild(minus); ctrl.appendChild(qtySpan); ctrl.appendChild(plus);
			srow.appendChild(ctrl);
			box.appendChild(srow);
			addNote(g, box);
			st.groups.push({ index: g.index, type: 'stepper', scope: g.scope, addonId: g.addon_id, role: g.role, locked: !!g.locked, price: g.price || 0, min: g.min, max: g.max, label: g.label, el: box });
		}

		function render(sections) {
			elGroups.innerHTML = '';
			st.groups = [];
			sections.forEach(function (section) {
				var secBox = document.createElement('div');
				secBox.className = 'rzd-section-block';
				if (section.header) {
					var sh = document.createElement('div');
					sh.className = 'rzd-section-header';
					sh.textContent = section.header;
					secBox.appendChild(sh);
				}
				if (section.description) {
					var sd = document.createElement('div');
					sd.className = 'rzd-section-desc';
					sd.textContent = section.description;
					secBox.appendChild(sd);
				}
				if (section.contains && section.contains.length) {
					var hs = document.createElement('div');
					hs.className = 'rzd-section-desc rzd-has';
					var hb = document.createElement('strong');
					hb.textContent = 'Zawiera już: ';
					hs.appendChild(hb);
					hs.appendChild(document.createTextNode(section.contains.join(', ')));
					secBox.appendChild(hs);
				}
				section.items.forEach(function (g) {
					var box = document.createElement('div');
					box.className = 'rzd-g';
					renderModifier(g, box);
					secBox.appendChild(box);
				});
				elGroups.appendChild(secBox);
			});
			// Koszyk, ilość > 1: zmiana wszystkich sztuk albo jednej (wydzielonej).
			if (st.mode === 'cart' && st.qty > 1) {
				var sp = document.createElement('div');
				sp.className = 'rzd-split';
				sp.innerHTML = '<label><input type="radio" name="rzd_split" value="0" checked> Zmień wszystkie sztuki (' + st.qty + ')</label>'
					+ '<label><input type="radio" name="rzd_split" value="1"> Zmień tylko 1 sztukę (osobna pozycja)</label>';
				elGroups.appendChild(sp);
			}
			recalc();
		}

		// Pola z okna w postaci [nazwa, wartość] – wspólne dla dodawania i koszyka.
		function collectFields() {
			var f = [];
			st.groups.forEach(function (g) {
				if (g.type === 'radio') {
					var checked = g.el.querySelector('input:checked');
					if (checked) { f.push(['rzd_mod[' + g.index + '][val]', checked.value]); }
				} else if (g.type === 'tap') {
					if (g.el.querySelector('.rzd-tap').classList.contains('rzd-on')) { f.push(['rzd_mod[' + g.index + '][val]', '1']); }
				} else if (g.type === 'text') {
					var inp = g.el.querySelector('input[type=text]');
					if (inp && inp.value.trim() !== '') { f.push(['rzd_mod[' + g.index + '][val]', inp.value.trim()]); }
				} else if (g.type === 'stepper') {
					var qty = parseInt(g.el.querySelector('.rzd-stepper-qty').textContent, 10) || 0;
					if (qty !== 0) { f.push(['rzd_mod[' + g.index + '][val]', qty]); }
				}
			});
			return f;
		}

		function setMode(mode, d) {
			st.mode = mode;
			st.preset = (d && d.preset) || {};
			st.qty = (d && d.qty) || 1;
			if (elTitle) { elTitle.textContent = mode === 'cart' ? ('Modyfikuj: ' + ((d && d.title) || 'produkt')) : origTitle; }
			elOk.textContent = mode === 'cart' ? 'Zapisz zmiany' : origOk;
			var old = modal.querySelector('.rzd-err');
			if (old) { old.parentNode.removeChild(old); }
		}

		function saveCart() {
			var body = new URLSearchParams();
			body.append('cart_key', st.cartKey);
			body.append('nonce', rzdMods.nonce || '');
			var sp = modal.querySelector('input[name=rzd_split]:checked');
			body.append('split', sp ? sp.value : '0');
			collectFields().forEach(function (f) { body.append(f[0], f[1]); });
			elOk.disabled = true;
			fetch(rzdMods.save, { method: 'POST', credentials: 'same-origin', body: body })
				.then(function (r) { return r.json(); })
				.then(function (d) {
					if (d && d.ok) {
						if (st.onSaved) { var cb = st.onSaved; st.onSaved = null; elOk.disabled = false; closeModal(); cb(); return; }
						window.location.reload(); return;
					}
					showErr((d && d.msg) || 'Nie udało się zapisać zmian.');
				})
				.catch(function () { showErr('Nie udało się zapisać zmian – sprawdź połączenie.'); });
		}
		function showErr(msg) {
			elOk.disabled = false;
			var e = modal.querySelector('.rzd-err');
			if (!e) {
				e = document.createElement('div');
				e.className = 'rzd-err';
				elOk.closest('.rzd-actions').parentNode.insertBefore(e, elOk.closest('.rzd-actions'));
			}
			e.textContent = msg;
		}

		elOk.addEventListener('click', function () {
			if (st.mode === 'cart') { saveCart(); return; }
			var ctx = st.ctx, next = st.next;
			collectFields().forEach(function (f) { ctx.fields.push(f); });
			closeModal();
			if (next) { next(); }
		});
		elCancel.addEventListener('click', closeModal);
		var elX = modal.querySelector('.rzd-x'); // 2.26.20: ✕ u góry = to samo co Anuluj
		if (elX) { elX.addEventListener('click', closeModal); }
		document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !modal.hidden) { closeModal(); } });

		window.kcAddSteps = window.kcAddSteps || [];
		window.kcAddSteps.push({
			order: 15,
			run: function (ctx, next) {
				if (rzdMods.products.indexOf(ctx.pid) === -1) { next(); return; }
				var url = rzdMods.url + (rzdMods.url.indexOf('?') > -1 ? '&' : '?') + 'product_id=' + encodeURIComponent(ctx.pid);
				fetch(url, { credentials: 'same-origin' })
					.then(function (r) { return r.json(); })
					.then(function (d) {
						if (!d || !d.sections || !d.sections.length) { next(); return; }
						st.ctx = ctx;
						st.next = next;
						setMode('before', d);
						render(d.sections);
						modal.hidden = false;
					})
					.catch(function () { next(); }); // błąd sieci – produkt doda się bez modyfikacji
			}
		});

		// --- 2.26.16: przycisk „Modyfikuj” w koszyku (blokowym i klasycznym).
		// PHP dokłada do danych pozycji ukryty znacznik „rzd-edit” z kluczem pozycji;
		// tu zamieniamy go na przycisk. Koszyk blokowy przerysowuje się sam, więc
		// obserwujemy zmiany i dokładamy przycisk ponownie, gdy zniknie.
		function openCart(key, onSaved) {
			var url = rzdMods.url + (rzdMods.url.indexOf('?') > -1 ? '&' : '?') + 'cart_key=' + encodeURIComponent(key);
			fetch(url, { credentials: 'same-origin' })
				.then(function (r) { return r.json(); })
				.then(function (d) {
					if (!d || !d.ok || !d.sections || !d.sections.length) { if (onSaved) { onSaved(); } else { window.location.reload(); } return; }
					st.cartKey = key;
					st.onSaved = onSaved || null;
					st.ctx = null; st.next = null;
					setMode('cart', d);
					render(d.sections);
					modal.hidden = false;
				})
				.catch(function () {});
		}
		function placeButtons() {
			var marks = document.querySelectorAll('li[class*="product-details__rzd-edit"], dd.variation-rzd-edit');
			Array.prototype.forEach.call(marks, function (m) {
				var valEl = m.querySelector('.wc-block-components-product-details__value') || m;
				var key = (valEl.textContent || '').replace(/^[\s:]+|\s+$/g, '');
				if (!/^[a-f0-9]{32}$/.test(key)) { return; }
				var list = m.parentNode; // ul (blokowy) / dl (klasyczny)
				if (!list || !list.parentNode) { return; }
				var holder = list.parentNode;
				if (holder.querySelector('.rzd-edit-btn[data-key="' + key + '"]')) { return; }
				var b = document.createElement('button');
				b.type = 'button';
				b.className = 'rzd-edit-btn';
				b.setAttribute('data-key', key);
				b.textContent = 'Modyfikuj';
				b.addEventListener('click', function (e) { e.preventDefault(); openCart(key); });
				holder.insertBefore(b, list.nextSibling);
			});
		}
		if (rzdMods.cartBtn && document.body && document.body.classList.contains('woocommerce-cart')) {
			placeButtons();
			var t = null;
			new MutationObserver(function () {
				if (t) { return; }
				t = setTimeout(function () { t = null; placeButtons(); }, 150);
			}).observe(document.body, { childList: true, subtree: true });
		}
	
		// --- 2.26.16: PRZEGLĄD ZAMÓWIENIA – okno po kliknięciu dowolnego linku do koszyka
		// (okienko „Dodano do koszyka”, ikonka w menu, mini-koszyk). Na stronach
		// koszyka i kasy nie działa; pusty koszyk – zwykłe przejście.
		var rv = document.getElementById('rzd-review');
		if (rv && rzdMods.review && rzdMods.cartUrl) {
			var rvList = rv.querySelector('.rzd-rv-list'), rvSum = rv.querySelector('.rzd-rv-sum'), rvGo = rv.querySelector('.rzd-rv-go');
			var rvHref = rzdMods.cartUrl;
			var pathOf = function (u) { try { return new URL(u, window.location.href).pathname.replace(/\/+$/, ''); } catch (e) { return ''; } };
			var cartPath = pathOf(rzdMods.cartUrl);

			var el = function (tag, cls, text) {
				var x = document.createElement(tag);
				if (cls) { x.className = cls; }
				if (text !== undefined) { x.textContent = text; }
				return x;
			};
			var rvUndo = null; // 2.26.20: ostatnio usunięta pozycja { key, name } – pasek „Cofnij”
			var rvClose = function () { rv.hidden = true; rvUndo = null; document.documentElement.style.overflow = ''; };
			// licznik/mini-koszyk motywu (klasyczne fragmenty WooCommerce)
			var rvFragments = function () { if (window.jQuery) { window.jQuery(document.body).trigger('wc_fragment_refresh'); } };
			var rvPost = function (url, key, ok, btn) {
				var body = new URLSearchParams();
				body.append('cart_key', key);
				body.append('nonce', rzdMods.nonce || '');
				if (btn) { btn.disabled = true; }
				fetch(url, { method: 'POST', credentials: 'same-origin', body: body })
					.then(function (r) { return r.json(); })
					.then(function (d) {
						if (d && d.ok) { ok(d); return; }
						if (btn) { btn.disabled = false; }
						window.alert((d && d.msg) || 'Nie udało się – spróbuj ponownie.');
					})
					.catch(function () { if (btn) { btn.disabled = false; } window.alert('Nie udało się – sprawdź połączenie.'); });
			};
			var rvRemove = function (it, btn) {
				rvPost(rzdMods.rvRemove, it.key, function (d) {
					rvFragments();
					// ostatnia pozycja: koszyk pusty – przeładowanie odświeża listę (termin koszyka zwolniony)
					if (d.empty) { rvClose(); window.location.reload(); return; }
					rvUndo = { key: it.key, name: it.qty + ' × ' + it.name };
					rvLoad();
				}, btn);
			};
			var trashSvg = '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6M14 11v6"/></svg>';
			var rvGoCart = function () { window.location.href = rvHref; };

			var rvRender = function (d) {
				// 2.27.2: lista budowana od nowa (po usunięciu / zapisie dodatków) – zostajemy w tym samym miejscu okienka
				var rvPanel = rv.querySelector('.dc-panel'), rvKeep = rvPanel ? rvPanel.scrollTop : 0;
				rvList.innerHTML = '';
				// 2.26.23: kontrola zestawów usunęła coś z koszyka – komunikat nad listą
				(d.notices || []).forEach(function (m) { rvList.appendChild(el('div', 'rzd-rv-notice', m)); });
				if (rvUndo) {
					var un = el('div', 'rzd-rv-undo');
					un.appendChild(el('span', '', 'Usunięto: ' + rvUndo.name));
					var ub = el('button', 'rzd-rv-undo-btn', 'Cofnij');
					ub.type = 'button';
					ub.addEventListener('click', function () {
						var k = rvUndo.key;
						rvPost(rzdMods.rvRestore, k, function () { rvUndo = null; rvFragments(); rvLoad(); }, ub);
					});
					un.appendChild(ub);
					rvList.appendChild(un);
				}
				d.items.forEach(function (it) {
					var box = el('div', 'rzd-rv-item');
					var nm = el('div', 'rzd-rv-name');
					nm.appendChild(el('span', '', it.qty + ' × ' + it.name));
					var pr = el('span', 'rzd-rv-price');
					pr.innerHTML = it.total; // wc_price z serwera
					nm.appendChild(pr);
					var del = el('button', 'rzd-rv-del');
					del.type = 'button';
					del.title = 'Usuń z koszyka';
					del.setAttribute('aria-label', 'Usuń z koszyka: ' + it.name);
					del.innerHTML = trashSvg;
					del.addEventListener('click', function () { rvRemove(it, del); });
					nm.appendChild(del);
					box.appendChild(nm);
					if (it.img) { var im = el('img', 'rzd-rv-img'); im.src = it.img; im.alt = ''; im.loading = 'lazy'; box.appendChild(im); }
					if (it.sklad && it.sklad.length) { box.appendChild(el('div', 'rzd-rv-sklad', 'Skład: ' + it.sklad.join(', '))); }
					if (it.comps && it.comps.length) {
						var ul = el('ul', 'rzd-rv-comps');
						it.comps.forEach(function (c) {
							var li = el('li');
							if (c.img) { var ci = el('img'); ci.src = c.img; ci.alt = ''; ci.loading = 'lazy'; li.appendChild(ci); }
							var tx = el('div');
							tx.appendChild(el('strong', '', c.name));
							if (c.sklad && c.sklad.length) { tx.appendChild(el('div', 'rzd-rv-sklad', c.sklad.join(', '))); }
							li.appendChild(tx);
							ul.appendChild(li);
						});
						box.appendChild(ul);
					}
					if (it.mods && it.mods.length) {
						var md = el('div', 'rzd-rv-mods');
						it.mods.forEach(function (m) {
							var row = el('div');
							row.appendChild(el('strong', '', m.k + ': '));
							row.appendChild(document.createTextNode(m.v));
							md.appendChild(row);
						});
						box.appendChild(md);
					}
					if (it.can_add) {
						var b = el('button', 'rzd-rv-add', 'Dodatki płatne');
						b.type = 'button';
						b.addEventListener('click', function () { openCart(it.key, rvLoad); });
						box.appendChild(b);
					}
					rvList.appendChild(box);
				});
				rvSum.innerHTML = '';
				(d.summary || []).forEach(function (r) {
					var row = el('div');
					row.appendChild(el('span', '', r.label));
					var v = el('span');
					v.innerHTML = r.value;
					row.appendChild(v);
					rvSum.appendChild(row);
				});
				var tot = el('div', 'rzd-rv-total');
				tot.appendChild(el('span', '', 'Razem'));
				var tv = el('span');
				tv.innerHTML = d.total || '';
				tot.appendChild(tv);
				rvSum.appendChild(tot);
				rvSum.appendChild(el('small', '', '+ dostawa – w koszyku, po wyborze adresu'));
				if (rvPanel && rvKeep) { rvPanel.scrollTop = rvKeep; }
			};

			// Wczytanie (też po zapisaniu dodatków – lista i suma odświeżają się bez przeładowania).
			var rvLoad = function () {
				rvGo.disabled = true;
				fetch(rzdMods.review, { credentials: 'same-origin' })
					.then(function (r) { return r.json(); })
					.then(function (d) {
						rvGo.disabled = false;
						if (d && d.notices && d.notices.length) { rvFragments(); } // licznik koszyka w menu
						if (!d || !d.ok || !d.items || !d.items.length) { rvGoCart(); return; }
						rvRender(d);
						if (rv.hidden) {
							rv.hidden = false;
							document.documentElement.style.overflow = 'hidden';
							var pnl = rv.querySelector('.dc-panel');
							if (pnl) { pnl.scrollTop = 0; }
						}
					})
					.catch(function () { rvGoCart(); });
			};

			rv.querySelector('.rzd-rv-x').addEventListener('click', rvClose);
			rvGo.addEventListener('click', rvGoCart);
			document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !rv.hidden && modal.hidden) { rvClose(); } }, true); // capture: przed zamknięciem okna dodatków – Esc zamyka najpierw je

			document.addEventListener('click', function (e) {
				if (e.defaultPrevented || e.button !== 0 || e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) { return; }
				var a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
				if (!a || a.target === '_blank' || rv.contains(a)) { return; }
				var bc = document.body ? document.body.classList : null;
				if (bc && (bc.contains('woocommerce-cart') || bc.contains('woocommerce-checkout'))) { return; }
				if (!cartPath || pathOf(a.href) !== cartPath) { return; }
				e.preventDefault();
				e.stopPropagation();
				rvHref = a.href;
				var added = document.getElementById('kc-added');
				if (added) { added.hidden = true; } // okienko „Dodano do koszyka” – chowamy pod przeglądem
				rvUndo = null;
				rvLoad();
			}, true);
		}
	})();
