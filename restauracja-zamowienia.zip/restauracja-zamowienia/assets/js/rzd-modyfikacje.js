/* Restauracja – Zamówienia i Dostawy: okienko modyfikacji produktu, krok bramy „modyfikacje” (2.26.13: plik zamiast kodu w stronie) */
// rzdMods – ustawiane przez WordPress przed tym plikiem (wp_add_inline_script)
	(function () {
		var modal = document.getElementById('rzd-mods');
		if (!modal) { return; }
		var elPicked = modal.querySelector('.rzd-picked');
		var elGroups = modal.querySelector('.rzd-groups'), elTotal = modal.querySelector('.rzd-total'),
			elOk = modal.querySelector('.rzd-ok'), elCancel = modal.querySelector('.rzd-cancel');
		var st = { groups: [], ctx: null, next: null };

		function closeModal() { modal.hidden = true; st.next = null; }
		function money(v) { return (v >= 0 ? '+' : '') + v.toFixed(2).replace('.', ',') + ' zł'; }

		// --- Wzajemne blokowanie: ten sam dodatek jako "dodaje" w jednym
		// miejscu i "odejmuje" w innym – aktywacja jednego blokuje drugie.
		function isActive(g) {
			if (g.type === 'radio') {
				return null; // radio liczone per-opcja, patrz niżej
			}
			if (g.type === 'tap') { return g.el.querySelector('.rzd-tap').classList.contains('rzd-on'); }
			if (g.type === 'stepper') { return (parseInt(g.el.querySelector('.rzd-stepper-qty').textContent, 10) || 0) > 0; }
			return false;
		}
		function updateExclusions() {
			// addon_id (rozwiązany konkretny składnik) -> { dodaje: bool, odejmuje: bool, dezaktywuje: bool }
			// Blokowanie działa w obrębie JEDNEGO dania (scope = produkt-źródło): w zestawie "Bez mięsa"
			// z jednego dania nie może wyszarzać "Dodatkowe mięso" z drugiego.
			// W obrębie JEDNEGO produktu typ zawsze rozwiązuje się do tego samego,
			// jednego dodatku (patrz rzd_resolve_addon_name_for_product w PHP), więc grupowanie
			// po addon_id jest tu równoważne grupowaniu po typie.
			var byAddon = {};
			function mark(scope, addonId, role, active) {
				if (!addonId || role === 'neutralna' || role === 'obowiazkowa' || !active) { return; }
				var k = scope + ':' + addonId;
				if (!byAddon[k]) { byAddon[k] = {}; }
				byAddon[k][role] = true;
			}
			st.groups.forEach(function (g) {
				if (g.type === 'radio') {
					var checked = g.el.querySelector('input:checked');
					if (checked) {
						var oi = parseInt(checked.getAttribute('data-oi'), 10);
						var opt = g.options[oi];
						if (opt) { mark(g.scope, opt.addon_id, opt.role, true); }
					}
				} else {
					mark(g.scope, g.addonId, g.role, isActive(g));
				}
			});
			// "Dezaktywuje" blokuje WSZYSTKO inne tego typu (i dodaje, i odejmuje);
			// "dodaje"/"odejmuje" blokują się nawzajem I blokują "dezaktywuje" –
			// tylko jedna "rodzina ról" może być naraz aktywna dla danego typu.
			function blockedFor(scope, addonId, role) {
				var st2 = byAddon[scope + ':' + addonId];
				if (!st2) { return false; }
				if (role === 'dodaje') { return !!(st2.odejmuje || st2.dezaktywuje); }
				if (role === 'odejmuje') { return !!(st2.dodaje || st2.dezaktywuje); }
				if (role === 'dezaktywuje') { return !!(st2.dodaje || st2.odejmuje); }
				return false;
			}
			// zastosuj blokady (dodatki obowiązkowe/locked mają swój stały stan – ich nie ruszamy)
			st.groups.forEach(function (g) {
				if (g.locked) { return; }
				if (g.type === 'radio') {
					g.options.forEach(function (opt, oi) {
						var inp = g.el.querySelectorAll('input')[oi];
						if (!inp) { return; }
						var blocked = blockedFor(g.scope, opt.addon_id, opt.role) && !inp.checked;
						inp.disabled = !!blocked;
						var sq = inp.closest('.rzd-square');
						if (sq) { sq.classList.toggle('rzd-locked', !!blocked); }
					});
				} else if (g.role === 'dodaje' || g.role === 'odejmuje' || g.role === 'dezaktywuje') {
					var active = isActive(g);
					var blocked = blockedFor(g.scope, g.addonId, g.role) && !active;
					if (g.type === 'tap') {
						g.el.querySelector('.rzd-tap').disabled = !!blocked;
					} else if (g.type === 'stepper') {
						g.el.querySelectorAll('.rzd-stepper-btn').forEach(function (b) { b.disabled = !!blocked; });
					}
				}
			});
		}

		// Podsumowanie wyboru w rodzajach – ta sama reguła co rzd_mod_kind() w PHP.
		function modKind(role, price, mandatory) {
			if (role === 'odejmuje' || role === 'dezaktywuje') { return 'bez'; }
			if (role === 'obowiazkowa' || mandatory) { return 'obowiazkowe'; }
			return (price > 0.001) ? 'dodatki' : 'zestaw';
		}
		function paintPicked() {
			if (!elPicked) { return; }
			var labels = { zestaw: 'Wybór w zestawie', dodatki: 'Dodatki (płatne)', obowiazkowe: 'Obowiązkowe', bez: 'Bez' };
			var pick = { zestaw: [], dodatki: [], obowiazkowe: [], bez: [] };
			st.groups.forEach(function (g) {
				if (g.type === 'radio') {
					var c = g.el.querySelector('input:checked');
					if (!c) { return; }
					var o = g.options[parseInt(c.getAttribute('data-oi'), 10)];
					if (o) { pick[modKind(o.role, o.price, o.mandatory)].push(o.label); }
				} else if (g.type === 'tap') {
					if (g.el.querySelector('.rzd-tap').classList.contains('rzd-on')) { pick[modKind(g.role, g.price, g.locked)].push(g.label); }
				} else if (g.type === 'stepper') {
					var q = parseInt(g.el.querySelector('.rzd-stepper-qty').textContent, 10) || 0;
					if (q > 0) { pick[modKind(g.role, g.price, g.locked)].push((q > 1 ? q + '× ' : '') + g.label); }
				}
			});
			elPicked.innerHTML = '';
			Object.keys(labels).forEach(function (k) {
				if (!pick[k].length) { return; }
				var d = document.createElement('div');
				var b = document.createElement('strong');
				b.textContent = labels[k] + ': ';
				d.appendChild(b);
				d.appendChild(document.createTextNode(pick[k].join(', ')));
				elPicked.appendChild(d);
			});
		}

		function recalc() {
			var total = 0;
			st.groups.forEach(function (g) {
				if (g.type === 'radio') {
					var checked = g.el.querySelector('input:checked');
					if (checked) { total += parseFloat(checked.getAttribute('data-price')) || 0; }
				} else if (g.type === 'tap') {
					if (g.el.querySelector('.rzd-tap').classList.contains('rzd-on')) { total += g.price; }
				} else if (g.type === 'text') {
					var inp = g.el.querySelector('input[type=text]');
					if (inp && inp.value.trim() !== '') { total += g.price; }
				} else if (g.type === 'stepper') {
					var qty = parseInt(g.el.querySelector('.rzd-stepper-qty').textContent, 10) || 0;
					total += qty * g.price;
				}
			});
			elTotal.textContent = (Math.abs(total) < 0.001) ? 'bez dopłaty' : money(total);
			paintPicked();
			updateExclusions();

			// Pojedynczy wybór (lista opcji) jest obowiązkowy – bez zaznaczenia żadnej opcji nie da się przejść dalej.
			var missingRequired = st.groups.some(function (g) {
				return g.type === 'radio' && g.options.length && !g.el.querySelector('input:checked');
			});
			elOk.disabled = missingRequired;
		}

		function renderModifier(g, box) {
			if (g.type === 'radio') {
				var row = document.createElement('div');
				row.className = 'rzd-squares';
				g.options.forEach(function (opt, oi) {
					var sq = document.createElement('label');
					sq.className = 'rzd-square';
					var inp = document.createElement('input');
					inp.type = 'radio'; inp.name = 'rzd_r_' + g.index; inp.value = oi;
					inp.setAttribute('data-price', opt.price);
					inp.setAttribute('data-oi', oi);
					inp.style.display = 'none';
					if (opt.mandatory && g.options.length === 1) { inp.checked = true; sq.classList.add('rzd-on'); }
					inp.addEventListener('change', function () {
						row.querySelectorAll('.rzd-square').forEach(function (s) { s.classList.remove('rzd-on'); });
						sq.classList.add('rzd-on');
						recalc();
					});
					sq.appendChild(inp);
					if (opt.icon_url) {
						var oicon = document.createElement('img');
						oicon.src = opt.icon_url; oicon.className = 'rzd-square-icon'; oicon.alt = '';
						sq.appendChild(oicon);
						sq.appendChild(document.createElement('br'));
					}
					sq.appendChild(document.createTextNode(opt.label));
					if (opt.price_html) { var sm = document.createElement('small'); sm.textContent = opt.price_html; sq.appendChild(sm); }
					row.appendChild(sq);
				});
				box.appendChild(row);
				st.groups.push({ index: g.index, type: 'radio', options: g.options, scope: g.scope, locked: false, el: box });
				return;
			}

			if (g.type === 'tap') {
				var btn = document.createElement('button');
				btn.type = 'button'; btn.className = 'rzd-tap';
				if (g.icon_url) {
					var ticon = document.createElement('img');
					ticon.src = g.icon_url; ticon.className = 'rzd-tap-icon'; ticon.alt = '';
					btn.appendChild(ticon); btn.appendChild(document.createElement('br'));
				}
				btn.appendChild(document.createTextNode(g.label + (g.price_html ? ' ' + g.price_html : '')));
				if (g.locked) {
					btn.classList.add('rzd-on');
					btn.disabled = true;
					var note = document.createElement('div');
					note.className = 'rzd-lock-note';
					note.textContent = 'Zawsze dołączone';
					box.appendChild(note);
				} else {
					btn.addEventListener('click', function () { btn.classList.toggle('rzd-on'); recalc(); });
				}
				box.appendChild(btn);
				st.groups.push({ index: g.index, type: 'tap', scope: g.scope, addonId: g.addon_id, role: g.role, locked: !!g.locked, price: g.price || 0, label: g.label, el: box });
				return;
			}

			if (g.type === 'text') {
				var t = document.createElement('input');
				t.type = 'text'; t.style.width = '100%'; t.placeholder = g.placeholder || '';
				t.addEventListener('input', recalc);
				box.appendChild(t);
				st.groups.push({ index: g.index, type: 'text', price: g.price || 0, el: box });
				return;
			}

			// stepper
			var srow = document.createElement('div');
			srow.className = 'rzd-stepper';
			if (g.icon_url) {
				var icon = document.createElement('img');
				icon.src = g.icon_url; icon.className = 'rzd-stepper-icon'; icon.alt = '';
				srow.appendChild(icon);
			}
			var label = document.createElement('span');
			label.className = 'rzd-stepper-label';
			label.textContent = g.label + (g.price_html ? ' ' + g.price_html + '/szt.' : '');
			srow.appendChild(label);

			var ctrl = document.createElement('span');
			ctrl.className = 'rzd-stepper-ctrl';
			var minus = document.createElement('button');
			minus.type = 'button'; minus.className = 'rzd-stepper-btn'; minus.textContent = '-';
			var qtySpan = document.createElement('span');
			qtySpan.className = 'rzd-stepper-qty';
			var start = g.locked ? Math.max(1, g.min || 0) : Math.max(g.min || 0, Math.min(g.max || 10, 0));
			qtySpan.textContent = String(start);
			var plus = document.createElement('button');
			plus.type = 'button'; plus.className = 'rzd-stepper-btn'; plus.textContent = '+';

			function setQty(v) {
				v = Math.max(g.min || 0, Math.min(g.max || 10, v));
				qtySpan.textContent = String(v);
				recalc();
			}
			if (g.locked) {
				minus.disabled = true; plus.disabled = true;
				var note2 = document.createElement('div');
				note2.className = 'rzd-lock-note';
				note2.textContent = 'Zawsze dołączone';
				box.appendChild(note2);
			} else {
				minus.addEventListener('click', function () { setQty((parseInt(qtySpan.textContent, 10) || 0) - 1); });
				plus.addEventListener('click', function () { setQty((parseInt(qtySpan.textContent, 10) || 0) + 1); });
			}
			ctrl.appendChild(minus); ctrl.appendChild(qtySpan); ctrl.appendChild(plus);
			srow.appendChild(ctrl);
			box.appendChild(srow);
			st.groups.push({ index: g.index, type: 'stepper', scope: g.scope, addonId: g.addon_id, role: g.role, locked: !!g.locked, price: g.price || 0, min: g.min, max: g.max, label: g.label, el: box });
		}

		function render(sections) {
			elGroups.innerHTML = '';
			st.groups = [];
			sections.forEach(function (section) {
				var secBox = document.createElement('div');
				secBox.className = 'rzd-section-block';
				if (section.header) {
					var sh = document.createElement('div');
					sh.className = 'rzd-section-header';
					sh.textContent = section.header;
					secBox.appendChild(sh);
				}
				if (section.description) {
					var sd = document.createElement('div');
					sd.className = 'rzd-section-desc';
					sd.textContent = section.description;
					secBox.appendChild(sd);
				}
				section.items.forEach(function (g) {
					var box = document.createElement('div');
					box.className = 'rzd-g';
					renderModifier(g, box);
					secBox.appendChild(box);
				});
				elGroups.appendChild(secBox);
			});
			recalc();
		}

		elOk.addEventListener('click', function () {
			var ctx = st.ctx, next = st.next;
			st.groups.forEach(function (g) {
				if (g.type === 'radio') {
					var checked = g.el.querySelector('input:checked');
					if (checked) {
						ctx.fields.push(['rzd_mod[' + g.index + '][val]', checked.value]);
					}
				} else if (g.type === 'tap') {
					if (g.el.querySelector('.rzd-tap').classList.contains('rzd-on')) { ctx.fields.push(['rzd_mod[' + g.index + '][val]', '1']); }
				} else if (g.type === 'text') {
					var inp = g.el.querySelector('input[type=text]');
					if (inp && inp.value.trim() !== '') { ctx.fields.push(['rzd_mod[' + g.index + '][val]', inp.value.trim()]); }
				} else if (g.type === 'stepper') {
					var qty = parseInt(g.el.querySelector('.rzd-stepper-qty').textContent, 10) || 0;
					if (qty !== 0) { ctx.fields.push(['rzd_mod[' + g.index + '][val]', qty]); }
				}
			});
			closeModal();
			if (next) { next(); }
		});
		elCancel.addEventListener('click', closeModal);
		document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !modal.hidden) { closeModal(); } });

		window.kcAddSteps = window.kcAddSteps || [];
		window.kcAddSteps.push({
			order: 15,
			run: function (ctx, next) {
				if (rzdMods.products.indexOf(ctx.pid) === -1) { next(); return; }
				var url = rzdMods.url + (rzdMods.url.indexOf('?') > -1 ? '&' : '?') + 'product_id=' + encodeURIComponent(ctx.pid);
				fetch(url, { credentials: 'same-origin' })
					.then(function (r) { return r.json(); })
					.then(function (d) {
						if (!d || !d.sections || !d.sections.length) { next(); return; }
						st.ctx = ctx;
						st.next = next;
						render(d.sections);
						modal.hidden = false;
					})
					.catch(function () { next(); }); // błąd sieci – produkt doda się bez modyfikacji
			}
		});
	})();
