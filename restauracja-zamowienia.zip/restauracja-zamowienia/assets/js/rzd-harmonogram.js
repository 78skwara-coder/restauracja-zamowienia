/* Restauracja – Zamówienia i Dostawy: okienko harmonogramu zestawu (2.26.13: plik zamiast kodu w stronie) */
(function () {
		var url = (window.rzdHarmonoCfg || {}).url;
		var modal = document.getElementById('rwz-harmono');
		if (!url || !modal) { return; }
		var elTitle = modal.querySelector('.dc-title'), elBody = modal.querySelector('.rwz-hm-body');
		var baseTitle = elTitle.textContent;
		var st = { pid: 0, row: null, req: 0 };

		// 2.26.4: duże zdjęcie po kliknięciu miniatury (nad okienkiem harmonogramu).
		var zoom = document.getElementById('rwz-hm-zoom');
		function zoomOpen(img) {
			var src = img.getAttribute('data-full') || img.currentSrc || img.src;
			if (!zoom || !src) { return; }
			var big = zoom.querySelector('img');
			big.src = src;
			big.alt = img.alt || '';
			zoom.querySelector('figcaption').textContent = img.alt || '';
			zoom.hidden = false;
		}
		function zoomClose() { if (zoom && !zoom.hidden) { zoom.hidden = true; zoom.querySelector('img').removeAttribute('src'); return true; } return false; }

		function close() { zoomClose(); modal.hidden = true; st.req++; }

		function open(pid, row) {
			st.pid = pid; st.row = row;
			var req = ++st.req;
			elTitle.textContent = baseTitle;
			elBody.textContent = 'Wczytuję…';
			modal.hidden = false;
			fetch(url + (url.indexOf('?') > -1 ? '&' : '?') + 'product_id=' + encodeURIComponent(pid), { credentials: 'same-origin' })
				.then(function (r) { return r.text(); })
				.then(function (html) {
					if (req !== st.req) { return; } // okienko zamknięte albo otwarte dla innego zestawu
					elBody.innerHTML = html;
					var list = elBody.querySelector('.rwz-hm-list');
					if (list && list.getAttribute('data-title')) { elTitle.textContent = list.getAttribute('data-title'); }
					// Historia jest nad dzisiejszym dniem – przewiń tak, żeby „dziś” było na górze.
					var today = elBody.querySelector('.rwz-hm-day.is-today') || elBody.querySelector('.rwz-hm-day:not(.is-past)');
					var panel = modal.querySelector('.dc-panel');
					var head = modal.querySelector('.rwz-hm-head');
					if (today && panel && today.previousElementSibling) { panel.scrollTop = Math.max(0, today.offsetTop - panel.offsetTop - (head ? head.offsetHeight : 0) - 12); }
					else if (panel) { panel.scrollTop = 0; }
				})
				.catch(function () { if (req === st.req) { elBody.textContent = 'Nie udało się wczytać harmonogramu.'; } });
		}

		// „Dodaj na ten dzień”: zwykły przycisk „Dodaj do koszyka” tego wiersza
		// (z jego ilością), poprzedzony ustawieniem terminu na wybrany dzień.
		function addForDay(date) {
			var row = st.row;
			var form = row ? (row.querySelector('form.rl-buy:not(.rl-addon)') || row.querySelector('form.cart')) : null; // form.cart = strona produktu
			var btn = form ? form.querySelector('button[name="add-to-cart"], button.single_add_to_cart_button') : null;
			close();
			if (!btn) { return; }
			var go = function () {
				if (form.requestSubmit) { form.requestSubmit(btn); } else { btn.click(); }
			};
			var cur = window.dcData && window.dcData.slot;
			if (cur && cur.date === date) { go(); return; }
			if (typeof window.dcOpenTerm === 'function') {
				window.dcOpenTerm(st.pid, go, cur ? 'Zmień termin dostawy' : 'Wybierz termin dostawy', date);
			} else {
				go();
			}
		}

		document.addEventListener('click', function (e) {
			if (!e.target || !e.target.closest) { return; }
			var sum = e.target.closest('details.rl-harmono > summary');
			if (sum) {
				e.preventDefault(); // nie rozwijaj – otwórz okienko
				var d = sum.parentNode;
				var pid = d.getAttribute('data-product');
				if (pid) { open(pid, d.closest('.rl2-row') || d.closest('.rl-row') || d.closest('div.product')); } // 2.26.7: też strona produktu
				return;
			}
			var th = e.target.closest('#rwz-harmono img.rwz-hm-img');
			if (th) { zoomOpen(th); return; }
			if (e.target.closest('#rwz-hm-zoom')) { zoomClose(); return; } // klik gdziekolwiek zamyka zdjęcie
			var add = e.target.closest('#rwz-harmono .rwz-hm-add');
			if (add) { addForDay(add.getAttribute('data-date')); return; }
			if (e.target.closest('#rwz-harmono .rwz-hm-close') || e.target === modal) { close(); }
		});
		document.addEventListener('keydown', function (e) {
			if (e.key === 'Escape') { if (!zoomClose() && !modal.hidden) { close(); } return; }
			if ((e.key === 'Enter' || e.key === ' ') && e.target && e.target.matches && e.target.matches('#rwz-harmono img.rwz-hm-img')) { e.preventDefault(); zoomOpen(e.target); }
		});
	})();
