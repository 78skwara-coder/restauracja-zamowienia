<?php
/**
 * Moduł 12-kuchnia – panel admina i wersja front-endowa [kuchnia_dashboard].
 * Część modułu (pliki wczytywane po kolei – kolejność jak w dawnym jednym pliku).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 4. PANEL ADMINA – cienki wrapper wokół wspólnego dashboardu
 * ============================================================ */
function rzd_kuchnia_render_page() {
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		return;
	}
	echo '<div class="wrap">';
	if ( function_exists( 'rzd_kitchen_can' ) && ! rzd_kitchen_can() ) {
		echo '<p>To konto nie ma dostępu do żadnej zakładki Kuchni (Panel restauracji → Zespół → Uprawnienia).</p></div>';
		return;
	}
	rzd_kuchnia_render_dashboard( admin_url( 'admin.php?page=rzd-kuchnia' ) );
	rzd_kuchnia_render_access_note();
	echo '</div>';
}

/* dostęp do Kuchni / Kuriera ustawia się w konfiguratorze (moduł 26) – tu tylko podpowiedź. */
function rzd_kuchnia_render_access_note() {
	?>
	<hr style="margin:30px 0;">
	<h2>Kuchnia i Kurier na tablecie / telefonie</h2>
	<p class="description" style="max-width:900px">
		Wstaw shortcode <code>[kuchnia_dashboard]</code> (Kuchnia) albo <code>[kurier_dashboard]</code> (Kurier) na osobnej, niepodlinkowanej stronie.
		Wejście po zalogowaniu na konto pracownika – kto widzi które zakładki, ustawiasz w
		<?php if ( function_exists( 'rzd_roles_admin_can' ) && rzd_roles_admin_can() && function_exists( 'rzd_panel_url' ) ) : ?><a href="<?php echo esc_url( rzd_panel_url( 'zespol', array( 'tab' => 'uprawnienia' ) ) ); ?>">Panel restauracji → Zespół → Uprawnienia</a><?php else : ?>Panel restauracji → Zespół (szef)<?php endif; ?>
		(tam też awaryjny PIN kuriera). Konta obsługi nie mają kokpitu WordPressa; „Zapamiętaj mnie” = 90 dni dla kuchni, 30 dni dla kuriera.
	</p>
	<?php
}

/* ============================================================
 * 5. WERSJA FRONT-ENDOWA: shortcode [kuchnia_dashboard] – tylko zalogowani
 *    (2.30.0: konto z choć jedną zakładką Kuchni – moduły 25/26; PIN kuchni usunięty)
 * ============================================================ */
function rzd_kuchnia_frontend_authed() {
	return function_exists( 'rzd_kitchen_can' ) ? rzd_kitchen_can() : current_user_can( 'manage_woocommerce' );
}

// Strona z tym shortcode'em nie powinna trafiać do wyszukiwarek ani do sitemap.
add_action( 'wp_head', function () {
	global $post;
	if ( $post && has_shortcode( $post->post_content, 'kuchnia_dashboard' ) ) {
		echo '<meta name="robots" content="noindex,nofollow">' . "\n";
	}
} );

add_shortcode( 'kuchnia_dashboard', function () {
	if ( ! is_user_logged_in() ) {
		return rzd_staff_login_html( 'Kuchnia', 'Zaloguj się kontem kuchni. Zostaw zaznaczone „Zapamiętaj mnie” – tablet pozostanie zalogowany.' );
	}
	if ( ! rzd_kuchnia_frontend_authed() ) {
		return rzd_no_access_html( 'Kuchnia' );
	}

	ob_start();
	rzd_kuchnia_render_dashboard( get_permalink() );
	return ob_get_clean();
} );
