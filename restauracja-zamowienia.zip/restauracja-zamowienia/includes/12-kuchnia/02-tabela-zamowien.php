<?php
/**
 * Moduł 12-kuchnia – tabela zamówień (wiersz na zamówienie).
 * Część modułu (pliki wczytywane po kolei – kolejność jak w dawnym jednym pliku).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * KUCHNIA – TABELA ZAMÓWIEŃ (wiersz na zamówienie)
 * Kolumny: Zamówienie | Do przygotowania | Dodatki płatne.
 * Pod każdym daniem jego skład (pole „Skład” produktu, aktualny – nie zamrożony);
 * „Bez” = składnik przekreślony + czerwone „BEZ: …”; „Wybór w zestawie” =
 * zamiana składnika tego samego Typu (~~ziemniaki~~ → frytki) albo dopisany.
 * Danie zestawu: ID z `_rwz_component_ids`, starsze – po nazwie.
 * Wybór przy daniu: `src` w _rzd_addon_usage, starsze – po składzie.
 * ============================================================ */
function rzd_kuchnia_norm( $s ) {
	$s = trim( (string) $s );
	return function_exists( 'mb_strtolower' ) ? mb_strtolower( $s, 'UTF-8' ) : strtolower( $s );
}

// Nazwa → Typ (z katalogu Dodatków; starsze zamówienia – też dawne Składniki) – do zamiany „ziemniaki → frytki”.
function rzd_kuchnia_ing_type_map() {
	static $map = null;
	if ( null !== $map ) {
		return $map;
	}
	$map = array();
	if ( function_exists( 'rzd_get_ingredient' ) ) {
		foreach ( get_posts( array( 'post_type' => 'rzd_ingredient', 'post_status' => 'publish', 'numberposts' => -1, 'fields' => 'ids' ) ) as $iid ) {
			$ing = rzd_get_ingredient( $iid );
			if ( $ing && ! empty( $ing['type_id'] ) ) {
				$map[ rzd_kuchnia_norm( $ing['name'] ) ] = (int) $ing['type_id'];
			}
		}
	}
	foreach ( function_exists( 'rzd_get_all_addons' ) ? rzd_get_all_addons() : array() as $a ) {
		if ( $a && ! empty( $a['type_id'] ) && ! isset( $map[ rzd_kuchnia_norm( $a['name'] ) ] ) ) {
			$map[ rzd_kuchnia_norm( $a['name'] ) ] = (int) $a['type_id'];
		}
	}
	return $map;
}

function rzd_kuchnia_dish_id_by_name( $name ) {
	static $cache = array();
	$k = rzd_kuchnia_norm( $name );
	if ( ! isset( $cache[ $k ] ) ) {
		$ids         = wc_get_products( array( 'name' => $name, 'limit' => 1, 'return' => 'ids', 'status' => array( 'publish', 'private' ) ) );
		$cache[ $k ] = $ids ? (int) $ids[0] : 0;
	}
	return $cache[ $k ];
}

// Dania pozycji: [ ['id' => …, 'name' => …, 'role' => …], … ]; zwykły produkt = jedno „danie”.
function rzd_kuchnia_item_dishes( $item ) {
	$w = (string) $item->get_meta( 'W zestawie' );
	if ( '' === $w ) {
		return array( array( 'id' => (int) $item->get_product_id(), 'name' => $item->get_name(), 'role' => '' ) );
	}
	$stored = $item->get_meta( '_rwz_component_ids' );
	$stored = is_array( $stored ) ? array_map( 'intval', $stored ) : array();
	$out    = array();
	foreach ( array_filter( array_map( 'trim', explode( ',', $w ) ) ) as $name ) {
		$id = 0;
		foreach ( $stored as $sid ) {
			if ( rzd_kuchnia_norm( get_the_title( $sid ) ) === rzd_kuchnia_norm( $name ) ) {
				$id = $sid;
				break;
			}
		}
		if ( ! $id ) {
			$id = rzd_kuchnia_dish_id_by_name( $name );
		}
		$role  = ( $id && function_exists( 'rzd_zestaw_get_set_role' ) ) ? rzd_zestaw_get_set_role( $id ) : array( 'label' => '' );
		$out[] = array( 'id' => $id, 'name' => $name, 'role' => $role['label'] );
	}
	return $out;
}

function rzd_kuchnia_dish_sklad( $dish_id ) {
	$out = array();
	if ( $dish_id && function_exists( 'rzd_get_product_sklad' ) ) {
		foreach ( rzd_get_product_sklad( $dish_id ) as $ing ) {
			$out[] = array( 'name' => $ing['name'], 'type' => (int) $ing['type_id'] );
		}
	}
	return $out;
}

// Czy wybór / „bez” o tej nazwie dotyczy składnika z listy? → indeks składnika albo -1.
function rzd_kuchnia_match_ing( $parts, $name, $by_type, $type = 0 ) {
	$n = rzd_kuchnia_norm( $name );
	foreach ( $parts as $i => $p ) {
		if ( rzd_kuchnia_norm( $p['name'] ) === $n ) {
			return $i;
		}
	}
	if ( $by_type ) {
		$map = rzd_kuchnia_ing_type_map();
		$t   = $type ? (int) $type : ( isset( $map[ $n ] ) ? $map[ $n ] : 0 ); // typ dodatku z zamówienia (addon_id), starsze – po nazwie
		if ( $t ) {
			foreach ( $parts as $i => $p ) {
				if ( $p['type'] === $t ) {
					return $i;
				}
			}
		}
	}
	return -1;
}

/**
 * Rozkłada pozycję zamówienia na dane do wiersza kuchni:
 * [ 'title' => '2× Zestaw dnia' | '', 'dishes' => [ [qty, name, role, parts[], extra_add[], extra_bez[]] ], 'paid' => [], 'mand' => [], 'notes' => [] ].
 */
function rzd_kuchnia_item_kitchen( $item ) {
	$qty    = (int) $item->get_quantity();
	$dishes = rzd_kuchnia_item_dishes( $item );
	$is_set = '' !== (string) $item->get_meta( 'W zestawie' );
	foreach ( $dishes as $k => $d ) {
		$dishes[ $k ]['parts']     = array_map( function ( $p ) { return $p + array( 'state' => '', 'swap' => '' ); }, rzd_kuchnia_dish_sklad( $d['id'] ) );
		$dishes[ $k ]['extra_add'] = array();
		$dishes[ $k ]['extra_bez'] = array();
	}
	$paid = array();
	$mand = array();
	$loose_bez = array();
	foreach ( ( function_exists( 'rzd_item_addon_usage' ) ? rzd_item_addon_usage( $item ) : array() ) as $u ) {
		$kind = function_exists( 'rzd_usage_kind' ) ? rzd_usage_kind( $u ) : 'dodatki';
		$name = isset( $u['name'] ) ? (string) $u['name'] : '';
		if ( '' === $name ) {
			continue;
		}
		$ua    = ( ! empty( $u['addon_id'] ) && function_exists( 'rzd_get_addon' ) ) ? rzd_get_addon( $u['addon_id'] ) : null;
		$utype = $ua ? (int) $ua['type_id'] : 0;
		// Do którego dania? src → pojedyncze danie → danie, w którego składzie jest ten składnik.
		$di  = -1;
		$src = isset( $u['src'] ) ? (int) $u['src'] : 0;
		foreach ( $dishes as $k => $d ) {
			if ( $src && $d['id'] === $src ) {
				$di = $k;
			}
		}
		if ( -1 === $di && 1 === count( $dishes ) ) {
			$di = 0;
		}
		if ( -1 === $di && in_array( $kind, array( 'bez', 'zestaw' ), true ) ) {
			foreach ( $dishes as $k => $d ) {
				if ( -1 !== rzd_kuchnia_match_ing( $d['parts'], $name, true, $utype ) ) {
					$di = $k;
					break;
				}
			}
		}
		$n = (int) ( isset( $u['qty'] ) ? $u['qty'] : 1 ) * max( 1, $qty );
		if ( 'dodatki' === $kind || 'obowiazkowe' === $kind ) {
			$row = array( 'qty' => $n, 'name' => $name, 'to' => ( $is_set && $di >= 0 ) ? $dishes[ $di ]['name'] : '' );
			if ( 'dodatki' === $kind ) {
				$paid[] = $row;
			} else {
				$mand[] = $row;
			}
			continue;
		}
		if ( -1 === $di ) {
			if ( 'bez' === $kind ) {
				$loose_bez[] = $name;
			}
			continue;
		}
		$parts =& $dishes[ $di ]['parts'];
		if ( 'bez' === $kind ) {
			$pi = rzd_kuchnia_match_ing( $parts, $name, true, $utype );
			if ( $pi >= 0 ) {
				$parts[ $pi ]['state'] = 'bez';
			}
			// „Bez dodatku” z typem, którego danie w składzie nie ma (czeka na wybór klienta) – skreślamy TYP
			$dishes[ $di ]['extra_bez'][] = $pi >= 0 ? $parts[ $pi ]['name'] : ( ( $ua && '' !== $ua['type_name'] ) ? $ua['type_name'] : $name );
		} elseif ( 'zestaw' === $kind ) {
			$pi = rzd_kuchnia_match_ing( $parts, $name, false );
			if ( $pi >= 0 ) {
				$parts[ $pi ]['state'] = 'chosen';
			} else {
				$pi = rzd_kuchnia_match_ing( $parts, $name, true, $utype );
				if ( $pi >= 0 && '' === $parts[ $pi ]['state'] ) {
					$parts[ $pi ]['state'] = 'swap';
					$parts[ $pi ]['swap']  = $name;
				} else {
					$dishes[ $di ]['extra_add'][] = $name;
				}
			}
		}
		unset( $parts );
	}
	// Wpisy tekstowe (np. napis na torcie) – wszystko z meta pozycji, co nie jest rodzajem modyfikacji.
	$notes = array();
	$kinds = function_exists( 'rzd_mod_kind_labels' ) ? array_values( rzd_mod_kind_labels() ) : array();
	foreach ( rzd_kuchnia_item_modifier_notes( $item ) as $line ) {
		$key = trim( strtok( $line, ':' ) );
		if ( ! in_array( $key, $kinds, true ) && 0 !== strpos( $key, 'Skład' ) ) { // „Skład” (2.32.1) – Kuchnia rysuje skład sama
			$notes[] = $line;
		}
	}
	if ( $loose_bez ) {
		$notes[] = 'BEZ: ' . implode( ', ', $loose_bez );
	}
	return array(
		'qty'    => $qty,
		'title'  => $is_set ? $item->get_name() : '',
		'dishes' => $dishes,
		'paid'   => $paid,
		'mand'   => $mand,
		'notes'  => $notes,
	);
}

function rzd_kuchnia_dish_html( $d, $qty, $in_set ) {
	$bits = array();
	foreach ( $d['parts'] as $p ) {
		if ( 'bez' === $p['state'] ) {
			$bits[] = '<s>' . esc_html( $p['name'] ) . '</s>';
		} elseif ( 'swap' === $p['state'] ) {
			$bits[] = '<s>' . esc_html( $p['name'] ) . '</s> → <strong>' . esc_html( $p['swap'] ) . '</strong>';
		} elseif ( 'chosen' === $p['state'] ) {
			$bits[] = '<strong>' . esc_html( $p['name'] ) . '</strong>';
		} else {
			$bits[] = esc_html( $p['name'] );
		}
	}
	foreach ( $d['extra_add'] as $x ) {
		$bits[] = '+ <strong>' . esc_html( $x ) . '</strong>';
	}
	$h  = '<div class="kd-dish">';
	$h .= $in_set
		? '<div class="kd-name">' . ( '' !== $d['role'] ? '<span class="kd-role">' . esc_html( $d['role'] ) . ':</span> ' : '' ) . esc_html( $d['name'] ) . '</div>'
		: '<div class="kd-name"><span class="kd-qty">' . (int) $qty . '×</span> ' . esc_html( $d['name'] ) . '</div>';
	if ( $bits || $d['extra_bez'] ) {
		$h .= '<div class="kd-sklad">' . implode( ', ', $bits );
		if ( $d['extra_bez'] ) {
			$h .= ' <span class="kd-bez">BEZ: ' . esc_html( implode( ', ', array_unique( $d['extra_bez'] ) ) ) . '</span>';
		}
		$h .= '</div>';
	}
	return $h . '</div>';
}

// Komórki wiersza zamówienia: [ html „Do przygotowania”, html „Dodatki płatne” ].
function rzd_kuchnia_order_kitchen_cells( $order ) {
	$prep = '';
	$paid = '';
	foreach ( $order->get_items() as $item ) {
		if ( (int) $item->get_quantity() <= 0 ) {
			continue;
		}
		$k = rzd_kuchnia_item_kitchen( $item );
		$prep .= '<div class="kd-item">';
		if ( '' !== $k['title'] ) {
			$prep .= '<div class="kd-name kd-set"><span class="kd-qty">' . (int) $k['qty'] . '×</span> ' . esc_html( $k['title'] ) . '</div>';
		}
		foreach ( $k['dishes'] as $d ) {
			$prep .= rzd_kuchnia_dish_html( $d, $k['qty'], '' !== $k['title'] );
		}
		foreach ( $k['notes'] as $nt ) {
			$prep .= '<div class="kd-note">' . esc_html( $nt ) . '</div>';
		}
		$prep .= '</div>';
		foreach ( $k['paid'] as $p ) {
			$paid .= '<div class="kd-paid">+ <span class="kd-qty">' . (int) $p['qty'] . '×</span> ' . esc_html( $p['name'] ) . ( '' !== $p['to'] ? ' <span class="kd-to">→ ' . esc_html( $p['to'] ) . '</span>' : '' ) . '</div>';
		}
		foreach ( $k['mand'] as $p ) {
			$paid .= '<div class="kd-mand">' . (int) $p['qty'] . '× ' . esc_html( $p['name'] ) . ' (obowiązkowe)</div>';
		}
	}
	return array( $prep, '' !== $paid ? $paid : '<span class="kd-none">—</span>' );
}

// Zestawienie statusów zamówień terminu jako znaczki, np. "2× Przyjęte · 1× Przygotowane".
function rzd_kuchnia_status_summary_html( $orders ) {
	$counts = array();
	$first  = array();
	foreach ( $orders as $o ) {
		$st = $o->get_status();
		$counts[ $st ] = ( isset( $counts[ $st ] ) ? $counts[ $st ] : 0 ) + 1;
		if ( ! isset( $first[ $st ] ) ) {
			$first[ $st ] = $o;
		}
	}
	if ( ! $counts ) {
		return '';
	}
	// Kolejność wg przepływu (Przyjęte → … → Dostarczone), inne statusy na początku.
	$flow = function_exists( 'rzd_kitchen_statuses' ) ? array_keys( rzd_kitchen_statuses() ) : array();
	uksort( $counts, function ( $a, $b ) use ( $flow ) {
		$ia = array_search( $a, $flow, true );
		$ib = array_search( $b, $flow, true );
		return ( false === $ia ? -1 : $ia ) <=> ( false === $ib ? -1 : $ib );
	} );
	$parts = array();
	foreach ( $counts as $st => $n ) {
		$parts[] = (int) $n . '× ' . rzd_kuchnia_status_badge_html( $first[ $st ] );
	}
	return implode( ' ', $parts );
}

// Widok "Kuchnia": suma ilości wg nazwy dania w całym terminie.
// Lista załadunkowa: sumy OSOBNO w każdym rodzaju (frytki "w zestawie" i
// frytki "dodatek płatny" to dwa wiersze). Kolejność: dania, wybór w
// zestawie, dodatki płatne, obowiązkowe, bez; w rodzaju malejąco po ilości.
function rzd_kuchnia_aggregate( $orders ) {
	$out = array();
	foreach ( $orders as $order ) {
		foreach ( rzd_kuchnia_order_lines( $order ) as $l ) {
			$kind = isset( $l['kind'] ) ? $l['kind'] : ( $l['addon'] ? 'dodatki' : 'danie' );
			$key  = $kind . '|' . $l['name'];
			if ( ! isset( $out[ $key ] ) ) {
				$out[ $key ] = array( 'name' => $l['name'], 'qty' => 0, 'addon' => $l['addon'], 'kind' => $kind );
			}
			$out[ $key ]['qty'] += $l['qty'];
		}
	}
	$rank = array( 'danie' => 0, 'zestaw' => 1, 'dodatki' => 2, 'obowiazkowe' => 3, 'opakowanie' => 4, 'bez' => 5 );
	usort( $out, function ( $a, $b ) use ( $rank ) {
		$ra = isset( $rank[ $a['kind'] ] ) ? $rank[ $a['kind'] ] : 9;
		$rb = isset( $rank[ $b['kind'] ] ) ? $rank[ $b['kind'] ] : 9;
		return array( $ra, $b['qty'] ) <=> array( $rb, $a['qty'] );
	} );
	return $out;
}

/**
 * PEŁNY adres dostawy w polskim zapisie: „Kwiatowa 5/12, 64-920 Piła”.
 * Wcześniej brakowało numeru mieszkania/lokalu (address_2 – pole obowiązkowe w kasie)
 * i części brane były z dwóch adresów naraz (ulica z dostawy, miasto z rozliczeń).
 * Teraz cały komplet z jednego adresu: dostawy, a gdy pusty – rozliczeniowego.
 * address_2: sam numer (np. „12”, „3a”) → po ukośniku; „dom” → pomijamy; inny tekst → po przecinku.
 */
function rzd_kuchnia_order_address( $order ) {
	$t  = $order->get_shipping_address_1() ? 'shipping' : 'billing';
	$a1 = trim( (string) $order->{"get_{$t}_address_1"}() );
	$a2 = trim( (string) $order->{"get_{$t}_address_2"}() );
	$pc = trim( (string) $order->{"get_{$t}_postcode"}() );
	$ci = trim( (string) $order->{"get_{$t}_city"}() );
	$street = $a1;
	if ( '' !== $a2 && ! preg_match( '/^(dom|domek|brak|-+|nie dotyczy)\.?$/iu', $a2 ) ) {
		$street .= preg_match( '/^(m\.?\s*|lok\.?\s*)?\d+\s*[a-z]?$/iu', $a2 )
			? '/' . preg_replace( '/^(m\.?\s*|lok\.?\s*)/iu', '', $a2 )
			: ', ' . $a2;
	}
	return trim( implode( ', ', array_filter( array( trim( $street, ' ,' ), trim( $pc . ' ' . $ci ) ) ) ) );
}

// adres do pokazania – pogrubiony, z 📍 i linkiem do mapy Google (Kuchnia, Pakowanie, Kurier).
function rzd_kuchnia_address_html( $order, $note = false ) {
	$addr = rzd_kuchnia_order_address( $order );
	if ( '' === $addr ) {
		return '';
	}
	$h = '<a class="kuchnia-maplink kuchnia-addr" href="' . esc_url( 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( $addr ) ) . '" target="_blank" rel="noopener">📍 ' . esc_html( $addr ) . '</a>';
	if ( $note && $order->get_customer_note() ) {
		$h .= '<div class="kuchnia-addr-note">Uwagi: ' . esc_html( $order->get_customer_note() ) . '</div>';
	}
	return $h;
}

// Statusy uznawane za "spakowane" w widoku Pakowanie/Kurier (Gotowe i dalej).
function rzd_kuchnia_is_packed_status( $status ) {
	return in_array( $status, array( 'gotowe', 'w-dostawie', 'wydane' ), true );
}

function rzd_kuchnia_status_label( $slug ) {
	if ( function_exists( 'rzd_kitchen_statuses' ) ) {
		$all = rzd_kitchen_statuses();
		if ( isset( $all[ $slug ] ) ) {
			return $all[ $slug ];
		}
	}
	$name = wc_get_order_status_name( 'wc-' . $slug );
	return $name ? $name : $slug;
}

// Mały znaczek statusu – używany wszędzie, gdzie pokazujemy pojedyncze
// zamówienie (Pakowanie, Planowanie, Kurier), żeby zawsze było widać, na
// jakim etapie realizacji ono jest, bez przechodzenia do innej zakładki.
/**
 * Płatność zamówienia – zwykły tekst (tabele, CSV).
 * Płatność przy odbiorze (COD) → wprost kwota do pobrania; pozostałe metody
 * pojawiają się w dashboardzie dopiero po opłaceniu (patrz rzd_kuchnia_orders_for_date),
 * więc dla nich wystarczy "Opłacone" + nazwa metody.
 */
function rzd_kuchnia_payment_text( $order ) {
	if ( 'cod' === $order->get_payment_method() ) {
		$amount = html_entity_decode( wp_strip_all_tags( wc_price( $order->get_total() ) ), ENT_QUOTES, 'UTF-8' );
		return 'Przy odbiorze – pobierz ' . trim( $amount );
	}
	$title = $order->get_payment_method_title();
	if ( '' === $title ) {
		$title = $order->get_payment_method();
	}
	return 'Opłacone' . ( '' !== $title ? ' – ' . $title : '' );
}

// Ta sama informacja jako plakietka: COD wyraźnie wyróżnione (kurier ma pobrać gotówkę).
function rzd_kuchnia_payment_html( $order ) {
	$cod = ( 'cod' === $order->get_payment_method() );
	return '<span class="kuchnia-pay ' . ( $cod ? 'kuchnia-pay-cod' : 'kuchnia-pay-paid' ) . '">' . esc_html( rzd_kuchnia_payment_text( $order ) ) . '</span>';
}

function rzd_kuchnia_status_badge_html( $order ) {
	$status = $order->get_status();
	return '<span class="kuchnia-status-badge kuchnia-status-' . esc_attr( $status ) . '">' . esc_html( rzd_kuchnia_status_label( $status ) ) . '</span>';
}

// Czy dany termin (okno dostawy) nadal przyjmuje nowe zamówienia, czy jest
// już zamknięty (cutoff minął – lista dla tego okna jest ostateczna).
function rzd_kuchnia_cutoff_badge_html( $date, $time ) {
	if ( ! $time || '—' === $time || ! function_exists( 'rzd_dc_is_cutoff_passed' ) ) {
		return '';
	}
	$closed = rzd_dc_is_cutoff_passed( $date, $time );
	$label  = $closed ? 'Cutoff dostawy: zamknięty' : 'Cutoff dostawy: otwarty';
	$title  = $closed
		? 'Ten termin jest już zamknięty – nic nowego do niego nie dojdzie, można zaczynać przygotowanie albo pakowanie.'
		: 'Ten termin jeszcze przyjmuje zamówienia – mogą dojść kolejne, zanim zaczniesz przygotowanie.';
	return '<span class="kuchnia-cutoff-badge kuchnia-cutoff-' . ( $closed ? 'closed' : 'open' ) . '" title="' . esc_attr( $title ) . '">' . esc_html( $label ) . '</span>';
}

/**
 * "Zaplanowane" na zakładce Planowanie: po kliknięciu, jeśli nie ma błędów
 * (patrz moduł 13), plan danego terminu (data+godzina) zamraża się – pola
 * przestają być edytowalne, dopóki ktoś nie kliknie "Edytuj". Stan trzymamy
 * jako zwykłą opcję w bazie (jedna flaga na termin), nie w metadanych
 * poszczególnych zamówień – to nie jest atrybut zamówienia, tylko stan
 * całego planu na ten termin.
 */
function rzd_kuchnia_planning_lock_key( $date, $time ) {
	// JEDYNE miejsce, które decyduje, jaki znak zastępuje pustą godzinę –
	// wywołujący kod (moduł 13) przekazuje $time bez własnej podmiany, żeby
	// nie było dwóch różnych kluczy dla tego samego terminu.
	return 'kuchnia_plan_locked_' . $date . '_' . ( $time ? $time : '-' );
}
function rzd_kuchnia_is_planning_locked( $date, $time ) {
	return (bool) get_option( rzd_kuchnia_planning_lock_key( $date, $time ), false );
}

// Sortowanie zamówień wg kolejności z Planowania (moduł 13); bez ustawionej
// kolejności lądują na końcu, w kolejności złożenia.
function rzd_kuchnia_sort_by_sequence( $orders ) {
	usort( $orders, function ( $a, $b ) {
		$sa = (int) $a->get_meta( '_dc_delivery_sequence' );
		$sb = (int) $b->get_meta( '_dc_delivery_sequence' );
		if ( ! $sa ) { $sa = 999999 + $a->get_id(); }
		if ( ! $sb ) { $sb = 999999 + $b->get_id(); }
		return $sa <=> $sb;
	} );
	return $orders;
}

