<?php
/**
 * Moduł 12-kuchnia – strona panelu Kuchni.
 * Część modułu (pliki wczytywane po kolei – kolejność jak w dawnym jednym pliku).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 3. STRONA
 * ============================================================ */
function rzd_kuchnia_url( $base, $date, $time, $view ) {
	return esc_url( add_query_arg( array( 'date' => $date, 'time' => $time, 'view' => $view ), $base ) );
}

/**
 * Wspólna treść dashboardu – używana zarówno przez stronę w panelu admina,
 * jak i przez shortcode na froncie. $base to adres, do którego linki
 * (terminy, zakładki) dopisują parametry date/time/view.
 */
function rzd_kuchnia_render_dashboard( $base, $mode = 'kuchnia' ) {
	$mode  = ( 'kurier' === $mode ) ? 'kurier' : 'kuchnia';
	$date  = isset( $_GET['date'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $_GET['date'] ) ? $_GET['date'] : current_time( 'Y-m-d' );
	// Tryb "kurier" (moduł 19, osobny link i PIN) ma jeden widok i nic więcej.
	// zakładki wg uprawnień (konfigurator – moduły 25/26), w tym „📊 Dashboard”.
	$views = ( 'kurier' === $mode ) ? array( 'kurier' ) : ( function_exists( 'rzd_kitchen_views' ) ? rzd_kitchen_views() : array( 'zamowienia', 'kuchnia', 'pakowanie', 'planowanie', 'historia' ) );
	if ( ! $views ) {
		echo '<p>Brak dostępu do zakładek Kuchni.</p>';
		return;
	}
	$dash = in_array( 'dashboard', $views, true );
	$view  = isset( $_GET['view'] ) && in_array( $_GET['view'], $views, true ) ? $_GET['view'] : $views[0];
	$range = in_array( $view, array( 'zamowienia', 'historia', 'dashboard' ), true ); // widoki bez jednego dnia

	// Zamówienia: wszystko niezrealizowane, bez względu na datę.
	// Historia: od (dziś − "Dni wstecz") do końca przyszłości, z anulowanymi.
	$days_back  = function_exists( 'rzd_kitchen_days_back' ) ? rzd_kitchen_days_back() : 3;
	$auto_prep  = function_exists( 'rzd_kitchen_auto_prep_enabled' ) ? rzd_kitchen_auto_prep_enabled() : true;
	$zam_orders = array();
	if ( 'zamowienia' === $view ) {
		$zam_orders = rzd_kuchnia_orders_open();
	} elseif ( 'historia' === $view ) {
		$from_dt = new DateTime( current_time( 'Y-m-d' ), wp_timezone() );
		$from_dt->modify( '-' . $days_back . ' days' );
		$zam_orders = rzd_kuchnia_orders_from_date( $from_dt->format( 'Y-m-d' ) );
	}

	// Zanim cokolwiek policzymy: zamówienia, którym minął cutoff, same
	// przechodzą na "W przygotowaniu" (o ile włączone "Auto przygotowanie",
	// moduł 13). Sprawdzane przy każdym wejściu na dashboard (brak WP-Cron),
	// więc w praktyce na bieżąco dzięki auto-odświeżaniu co 60 s.
	if ( 'zamowienia' === $view && function_exists( 'rzd_auto_advance_orders' ) ) {
		rzd_auto_advance_orders( $zam_orders );
	} elseif ( 'historia' !== $view && function_exists( 'rzd_auto_advance_past_cutoff' ) ) {
		rzd_auto_advance_past_cutoff( $date );
	}

	// Pozostałe zakładki pracują na jednym dniu (kalendarzyk) i jego terminach.
	$slots_all = rzd_kuchnia_slots_for_date( $date );
	$slots     = ( 'zamowienia' === $view ) ? $slots_all : rzd_kuchnia_slots_for_date_pipeline( $date );

	// Kurier: termin, w którym WSZYSTKO jest już dostarczone, znika z wyboru
	// godzin. Po ostatnim "Dostarczone" ekran sam przechodzi do kolejnego
	// terminu (nieznana już godzina z adresu → pierwsza pozostała).
	if ( 'kurier' === $view ) {
		foreach ( array_keys( $slots ) as $st ) {
			$left = array_filter( rzd_kuchnia_orders_for_slot_pipeline( $date, $st ), function ( $o ) {
				return ! in_array( $o->get_status(), array( 'wydane', 'completed' ), true );
			} );
			if ( ! $left ) {
				unset( $slots[ $st ] );
			}
		}
	}

	$time = isset( $_GET['time'] ) ? sanitize_text_field( $_GET['time'] ) : '';
	if ( '' === $time || ! isset( $slots[ $time ] ) ) {
		$keys = array_keys( $slots );
		$time = $keys ? $keys[0] : '';
	}

	$orders = $time ? ( ( 'zamowienia' === $view ) ? rzd_kuchnia_orders_for_slot( $date, $time ) : rzd_kuchnia_orders_for_slot_pipeline( $date, $time ) ) : array();

	// $base bywa adresem z gotowym query stringiem (np. .../admin.php?page=rzd-kuchnia).
	// Formularz z metodą GET przy wysyłce ZASTĘPUJE query string z action swoim własnym,
	// więc żeby np. "page=rzd-kuchnia" nie zniknęło po zmianie daty, doklejamy istniejące
	// parametry $base jako ukryte pola – działa tak samo w panelu, jak i na stronie front-endowej.
	$base_parts = wp_parse_url( $base );
	$base_path  = ( isset( $base_parts['path'] ) ? $base_parts['path'] : $base );
	if ( isset( $base_parts['host'] ) ) {
		$base_path = ( isset( $base_parts['scheme'] ) ? $base_parts['scheme'] . '://' : '//' ) . $base_parts['host'] . $base_path;
	}
	$base_query = array();
	if ( isset( $base_parts['query'] ) ) {
		parse_str( $base_parts['query'], $base_query );
	}
	$front      = ! is_admin(); // strona publiczna ([kuchnia_dashboard]) vs ekran w panelu WP
	$tab_labels = array( 'zamowienia' => 'Zamówienia', 'kuchnia' => 'Kuchnia', 'pakowanie' => 'Pakowanie', 'planowanie' => 'Planowanie', 'historia' => 'Historia', 'kurier' => 'Kurier', 'dashboard' => 'Dashboard' );
	$date_label = ucfirst( function_exists( 'rzd_dc_date_label' ) ? rzd_dc_date_label( $date ) : $date );
	if ( $range ) { // tu nie ma jednego dnia – pokazujemy dzisiejszą datę
		$today      = current_time( 'Y-m-d' );
		$date_label = 'Dziś: ' . ( function_exists( 'rzd_dc_date_label' ) ? rzd_dc_date_label( $today ) : $today );
	}
	?>
	<div id="kuchnia-popup-root"></div>
	<div class="kuchnia-wrap<?php echo $front ? ' is-front' : ''; ?>">
	<span class="kuchnia-n" data-n="<?php echo esc_attr( function_exists( 'rzd_kitchen_nonce' ) ? rzd_kitchen_nonce() : '' ); ?>" hidden></span><?php // nonce akcji (moduł 25) – odświeżany z treścią ?>
		<?php echo rzd_css_tag( 'assets/css/rzd-kuchnia.css', 'rzd-kuchnia-css' ); // phpcs:ignore ?>

		<?php
		// nagłówek nad kreską – data (wybór dnia) z lewej, etykieta dnia
		// na środku, ⚙ z prawej. Pełny ekran i Drukuj są w panelu pod trybikiem.
		?>
		<div class="kuchnia-head">
			<div class="kuchnia-head-left">
				<?php if ( ! $range ) : ?>
				<form method="get" class="kuchnia-date-form" action="<?php echo esc_url( $base_path ); ?>">
					<?php foreach ( $base_query as $k => $v ) : ?>
						<input type="hidden" name="<?php echo esc_attr( $k ); ?>" value="<?php echo esc_attr( $v ); ?>">
					<?php endforeach; ?>
					<input type="hidden" name="view" value="<?php echo esc_attr( $view ); ?>">
					<input type="date" name="date" value="<?php echo esc_attr( $date ); ?>" onchange="this.form.requestSubmit ? this.form.requestSubmit() : this.form.submit()">
				</form>
				<?php endif; ?>
			</div>
			<div class="kuchnia-date"><span><?php echo esc_html( $date_label ); ?></span></div>
			<div class="kuchnia-head-right">
				<button type="button" class="kuchnia-gear" id="kuchnia-settings-toggle" title="Ustawienia" aria-label="Ustawienia">⚙</button>
			</div>
		</div>
		<div class="kuchnia-print-head"><strong><?php echo esc_html( $date_label ); ?></strong> · <?php echo esc_html( isset( $tab_labels[ $view ] ) ? $tab_labels[ $view ] : '' ); ?><?php echo ( $time && '—' !== $time && ! $range ) ? ' · Wyjazd o godzinie: ' . esc_html( $time ) : ''; ?></div>

		<?php // Panel ustawień: "Auto przygotowanie" – wspólne (serwer), reszta – na tym urządzeniu. ?>
		<div class="kuchnia-settings" id="kuchnia-settings">
			<button type="button" class="kuchnia-btn" id="kuchnia-kiosk-toggle">Pełny ekran</button>
			<button type="button" class="kuchnia-btn" onclick="window.print()">Drukuj</button>
			<button type="button" class="kuchnia-btn" id="kuchnia-refresh-toggle">Auto-odświeżanie: włączone</button>
			<?php if ( 'kuchnia' === $mode ) : ?>
			<?php if ( rzd_can( 'settings' ) ) : // ustawienie wspólne – tylko z uprawnieniem „Ustawienia wtyczki” ?>
			<button type="button" class="kuchnia-btn<?php echo $auto_prep ? ' is-on' : ''; ?>" id="kuchnia-autoprep-toggle" data-on="<?php echo $auto_prep ? '1' : '0'; ?>" title="Po cutoffie zamówienia same przechodzą na „W przygotowaniu” (wspólne dla wszystkich urządzeń)">Auto przygotowanie: <?php echo $auto_prep ? 'włączone' : 'wyłączone'; ?></button>
			<?php endif; ?>
			<button type="button" class="kuchnia-btn" id="kuchnia-alert-popup-toggle" title="Tak: okno z OK przy nowym zamówieniu. Nie: sam dźwięk i pogrubienie.">Okno z powiadomieniem: nie</button>
			<button type="button" class="kuchnia-btn" id="kuchnia-alert-repeat-toggle" title="Dźwięk powtarzany, aż ktoś kliknie OK (tylko z oknem powiadomienia)">Powtarzaj dźwięk: nie</button>
			<button type="button" class="kuchnia-btn" id="kuchnia-sound-test">Test dźwięku</button>
			<span class="kuchnia-mod">Okno, powtarzanie i odświeżanie zapisują się na tym urządzeniu.</span>
			<?php endif; ?>
		</div>

		<div class="kuchnia-top">
			<?php if ( 'zamowienia' === $view ) : ?>
			<?php elseif ( 'historia' === $view ) : ?>
			<?php if ( rzd_can( 'settings' ) ) : // 2.30.0 ?>
			<label class="kuchnia-days-back">Dni wstecz: <input type="number" min="0" max="60" id="kuchnia-days-back" value="<?php echo (int) $days_back; ?>"></label>
			<?php endif; ?>
			<?php endif; ?>
			<?php if ( 'kuchnia' === $mode ) : ?>
			<div class="kuchnia-tabs">
				<?php foreach ( $views as $tv ) : // tylko zakładki z uprawnieniem ?>
					<?php if ( 'dashboard' === $tv ) : ?>
				<a class="kuchnia-tab<?php echo ( 'dashboard' === $view ) ? ' is-active' : ''; ?>" href="<?php echo rzd_kuchnia_url( $base, current_time( 'Y-m-d' ), '', 'dashboard' ); ?>">📊 Dashboard</a>
					<?php else : ?>
				<a class="kuchnia-tab<?php echo ( $tv === $view ) ? ' is-active' : ''; ?>" href="<?php echo rzd_kuchnia_url( $base, $date, $time, $tv ); ?>"><?php echo esc_html( $tab_labels[ $tv ] ); ?></a>
					<?php endif; ?>
				<?php endforeach; ?>
			</div>
			<?php else : ?>
			<div class="kuchnia-tabs"><span class="kuchnia-tab is-active">Kurier</span></div>
			<?php endif; ?>
		</div>


		<?php if ( ! $range ) : ?>
			<?php if ( ! $slots ) : ?>
				<p class="kuchnia-empty"><?php echo 'kurier' === $view ? 'Wszystkie dostawy na ten dzień są dostarczone albo nie ma zamówień.' : 'Brak opłaconych zamówień na ten dzień.'; ?></p>
			<?php else : ?>
				<div class="kuchnia-slots">
					<?php foreach ( $slots as $t => $count ) : ?>
						<a class="kuchnia-slot<?php echo ( $t === $time ) ? ' is-active' : ''; ?>" href="<?php echo rzd_kuchnia_url( $base, $date, $t, $view ); ?>">
							<?php echo esc_html( $t ); ?> · <?php echo (int) $count; ?> <?php echo rzd_kuchnia_cutoff_badge_html( $date, $t ); ?>
						</a>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		<?php endif; ?>

		<?php if ( 'zamowienia' === $view ) : ?>
			<?php
			$groups = rzd_kuchnia_slot_groups( $zam_orders );
			$now_ts = time();
			$today  = current_time( 'Y-m-d' );
			usort( $groups, function ( $a, $b ) {
				return array( $a['date'], $a['cutoff_ts'] ? $a['cutoff_ts'] : PHP_INT_MAX, $a['time'] ) <=> array( $b['date'], $b['cutoff_ts'] ? $b['cutoff_ts'] : PHP_INT_MAX, $b['time'] );
			} );

			// TAŚMA: lista (czeka) → "Najbliższy wyjazd" → wyjazd.
			// Po godzinie wyjazdu: Spakowane w oknie klienta (wyjazd + 1 h) = "W drodze";
			// niespakowane albo po końcu okna bez "Dostarczone" = "Do przeplanowania".
			$upcoming = array();
			$resched  = array(); // sloty (tylko zamówienia do przeplanowania)
			$onroad   = array(); // [ 'time' => …, 'count' => …, 'end' => ts ]
			foreach ( $groups as $sl ) {
				usort( $sl['orders'], function ( $a, $b ) { return $a->get_id() <=> $b->get_id(); } );
				$gone = $sl['depart_ts'] ? ( $sl['depart_ts'] <= $now_ts ) : ( $sl['date'] < $today );
				if ( ! $gone ) {
					$upcoming[] = $sl;
					continue;
				}
				$win_end = $sl['depart_ts'] ? $sl['depart_ts'] + HOUR_IN_SECONDS : 0;
				// Tryb okien: prawdziwy koniec okna zamiast wyjazdu + 1 h.
				if ( $sl['depart_ts'] && function_exists( 'rzd_dc_windows_on' ) && rzd_dc_windows_on() ) {
					$w_obj = rzd_dc_window_at( $sl['date'], $sl['time'] );
					if ( $w_obj ) {
						$win_end = rzd_dc_date_ts( $sl['date'], $w_obj['end'] );
					}
				}
				$road    = array();
				$late    = array();
				foreach ( $sl['orders'] as $o ) {
					if ( 'w-dostawie' === $o->get_status() && $win_end && $now_ts < $win_end ) {
						$road[] = $o;
					} else {
						$late[] = $o;
					}
				}
				if ( $road ) {
					$onroad[] = array( 'time' => $sl['time'], 'count' => count( $road ), 'end' => $win_end );
				}
				if ( $late ) {
					$sl['orders'] = $late;
					$resched[]    = $sl;
				}
			}

			// GÓRA: wszystkie zamknięte terminy przed wyjazdem; gdy brak – najbliższy otwarty cutoff.
			$top = array_values( array_filter( $upcoming, function ( $sl ) { return $sl['closed'] && $sl['depart_ts']; } ) );
			if ( ! $top && $upcoming ) {
				$timed = array_values( array_filter( $upcoming, function ( $sl ) { return (bool) $sl['depart_ts']; } ) );
				if ( $timed ) {
					$next_cut = min( array_map( function ( $sl ) { return $sl['cutoff_ts']; }, $timed ) );
					$top      = array_values( array_filter( $timed, function ( $sl ) use ( $next_cut ) { return $sl['cutoff_ts'] === $next_cut; } ) );
				}
			}
			usort( $top, function ( $a, $b ) { return $a['depart_ts'] <=> $b['depart_ts']; } );
			$top_keys   = array();
			$top_blocks = array(); // cutoff_ts => sloty, w kolejności najbliższego wyjazdu
			foreach ( $top as $sl ) {
				$top_blocks[ $sl['cutoff_ts'] ][] = $sl;
				$top_keys[ $sl['date'] . ' ' . $sl['time'] ] = true;
			}

			// DÓŁ: czekające z poprawnym oknem, BEZ tych z góry (bez dublowania).
			$days = array();
			foreach ( $upcoming as $sl ) {
				if ( ! isset( $top_keys[ $sl['date'] . ' ' . $sl['time'] ] ) ) {
					$days[ $sl['date'] ][ $sl['cutoff_ts'] ][] = $sl;
				}
			}
			$resched_count = 0;
			foreach ( $resched as $sl ) {
				$resched_count += count( $sl['orders'] );
			}
			?>
			<div class="kuchnia-next" data-now="<?php echo (int) $now_ts; ?>">
				<div class="kuchnia-next-title">Najbliższy wyjazd</div>
				<?php if ( ! $top_blocks ) : ?>
					<p class="kuchnia-mod">Brak zamówień czekających na wyjazd.</p>
				<?php else : ?>
					<?php foreach ( $top_blocks as $cut_ts => $cut_slots ) : ?>
						<?php $open = ! $cut_slots[0]['closed']; ?>
						<div class="kuchnia-cutoff-header">Cutoff: <?php echo esc_html( rzd_kuchnia_cutoff_label( $cut_ts ) ); ?> <?php echo rzd_kuchnia_group_badge_html( $cut_slots ); ?>
							<?php if ( $open && $cut_ts > $now_ts ) : ?>
								<span class="kuchnia-cd" data-ts="<?php echo (int) $cut_ts; ?>" data-kind="cutoff" data-reload="1"></span>
							<?php endif; ?>
						</div>
						<?php foreach ( $cut_slots as $sl ) : ?>
							<div class="kuchnia-time-header"><?php echo esc_html( ucfirst( function_exists( 'rzd_dc_date_label' ) ? rzd_dc_date_label( $sl['date'] ) : $sl['date'] ) ); ?> · wyjazd <?php echo esc_html( $sl['time'] ); ?> <span class="kuchnia-count">(<?php echo count( $sl['orders'] ); ?>)</span>
								<span class="kuchnia-cd" data-ts="<?php echo (int) $sl['depart_ts']; ?>" data-kind="depart" data-reload="1"></span>
							</div>
							<?php echo rzd_kuchnia_orders_table_html( $sl['orders'] ); ?>
						<?php endforeach; ?>
					<?php endforeach; ?>
				<?php endif; ?>
			</div>

			<?php if ( $onroad ) : ?>
				<?php
				$road_n   = array_sum( wp_list_pluck( $onroad, 'count' ) );
				$road_t   = implode( ', ', array_unique( wp_list_pluck( $onroad, 'time' ) ) );
				$road_end = min( wp_list_pluck( $onroad, 'end' ) );
				?>
				<div class="kuchnia-onroad">W drodze: <?php echo (int) $road_n; ?> <?php echo 1 === $road_n ? 'zamówienie' : ( ( $road_n % 10 >= 2 && $road_n % 10 <= 4 && ( $road_n % 100 < 10 || $road_n % 100 >= 20 ) ) ? 'zamówienia' : 'zamówień' ); ?> (wyjazd <?php echo esc_html( $road_t ); ?>)
					<span class="kuchnia-cd" data-ts="<?php echo (int) $road_end; ?>" data-kind="silent" data-reload="1" hidden></span>
				</div>
			<?php endif; ?>

			<?php if ( $resched ) : ?>
				<div class="kuchnia-resched">
					<div class="kuchnia-section-header kuchnia-overdue-header">Do przeplanowania – okno minęło, zamówienie niedostarczone <span class="kuchnia-count">(<?php echo (int) $resched_count; ?>)</span></div>
					<p class="kuchnia-mod">Nadaj nowy termin – zamówienie wróci na listę z nowym oknem dostawy.</p>
					<?php foreach ( $resched as $sl ) : ?>
						<div class="kuchnia-time-header"><?php echo esc_html( ucfirst( function_exists( 'rzd_dc_date_label' ) ? rzd_dc_date_label( $sl['date'] ) : $sl['date'] ) ); ?> · wyjazd <?php echo esc_html( $sl['time'] ); ?> <span class="kuchnia-count">(<?php echo count( $sl['orders'] ); ?>)</span></div>
						<?php echo rzd_kuchnia_orders_table_html( $sl['orders'], true, true ); ?>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<hr class="kuchnia-split">

			<?php if ( ! $days ) : ?>
				<p class="kuchnia-empty">Brak kolejnych zamówień czekających na realizację.</p>
			<?php else : ?>
				<?php echo rzd_kuchnia_days_html( $days, true ); // phpcs:ignore ?>
			<?php endif; ?>

		<?php elseif ( 'historia' === $view ) : ?>
			<?php
			// Wszystko (także dostarczone i anulowane), malejąco: najnowsze na górze.
			$groups = rzd_kuchnia_slot_groups( $zam_orders );
			usort( $groups, function ( $a, $b ) {
				return array( $b['date'], $b['cutoff_ts'], $b['time'] ) <=> array( $a['date'], $a['cutoff_ts'], $a['time'] );
			} );
			$days = array();
			foreach ( $groups as $sl ) {
				$days[ $sl['date'] ][ $sl['cutoff_ts'] ][] = $sl;
			}
			?>
			<?php if ( ! $days ) : ?>
				<p class="kuchnia-empty">Brak zamówień w wybranym zakresie.</p>
			<?php else : ?>
				<?php echo rzd_kuchnia_days_html( $days, false ); // phpcs:ignore ?>
			<?php endif; ?>

		<?php elseif ( 'kuchnia' === $view ) : ?>
			<?php
			// Wszystko, co jeszcze NIE jest oznaczone jako Przygotowane – celowo
			// bez względu na to, czy cutoff już minął, żeby kuchnia widziała z
			// wyprzedzeniem, co nadchodzi. Znaczek obok pokazuje, czy lista jest
			// jeszcze otwarta (mogą dojść kolejne zamówienia), czy zamknięta
			// (ostateczna – bezpiecznie można w pełni ruszać z przygotowaniem).
			$do_przygotowania = array_values( array_filter( $orders, function ( $o ) { return ! in_array( $o->get_status(), array( 'gotowe', 'w-dostawie', 'wydane' ), true ); } ) );
			$rows = rzd_kuchnia_aggregate( $do_przygotowania );
			?>
			<p class="kuchnia-mod">Ten termin: <?php echo rzd_kuchnia_cutoff_badge_html( $date, $time ); ?></p>
			<?php if ( $orders ) : ?>
				<p class="kuchnia-mod kuchnia-status-summary">Zamówienia: <?php echo rzd_kuchnia_status_summary_html( $orders ); ?></p>
			<?php endif; ?>
			<?php if ( ! $rows ) : ?>
				<p class="kuchnia-empty">Wszystko z tego terminu jest już przygotowane.</p>
			<?php else : ?>
				<?php
				// wiersz na zamówienie – kolejność wg godziny z Planowania (bez godziny na końcu), potem złożenia.
				$kitchen_orders = $do_przygotowania;
				usort( $kitchen_orders, function ( $a, $b ) {
					$ta = (string) $a->get_meta( '_dc_planned_time' );
					$tb = (string) $b->get_meta( '_dc_planned_time' );
					$ka = array( '' === $ta ? 1 : 0, $ta, $a->get_date_created() ? $a->get_date_created()->getTimestamp() : 0, $a->get_id() );
					$kb = array( '' === $tb ? 1 : 0, $tb, $b->get_date_created() ? $b->get_date_created()->getTimestamp() : 0, $b->get_id() );
					return $ka <=> $kb;
				} );
				?>
				<details class="kuchnia-sums">
					<summary>Razem do zrobienia w tym terminie (<?php echo count( $rows ); ?> poz.)</summary>
				<table class="kuchnia-table">
					<thead><tr><th>Produkt</th><th>Rodzaj</th><th>Ilość</th></tr></thead>
					<tbody>
					<?php $prev_kind = null; ?>
					<?php foreach ( $rows as $r ) : ?>
						<?php if ( $r['kind'] !== $prev_kind ) : $prev_kind = $r['kind']; ?>
							<tr class="kuchnia-kind-row"><td colspan="3"><?php echo esc_html( 'danie' === $r['kind'] ? 'Dania' : ( 'opakowanie' === $r['kind'] ? 'Opakowania' : ( function_exists( 'rzd_kind_label' ) ? rzd_kind_label( $r['kind'] ) : 'Dodatki' ) ) ); ?></td></tr>
						<?php endif; ?>
						<tr class="kuchnia-kind-<?php echo esc_attr( $r['kind'] ); ?>">
							<td data-label="Produkt"><?php echo esc_html( 'bez' === $r['kind'] ? preg_replace( '/^Bez: /', '', $r['name'] ) : $r['name'] ); ?></td>
							<td data-label="Rodzaj"><?php echo esc_html( function_exists( 'rzd_kind_label' ) ? rzd_kind_label( $r['kind'] ) : ( $r['addon'] ? 'Dodatek' : 'Danie' ) ); ?></td>
							<td data-label="Ilość" class="kuchnia-qty"><?php echo (int) $r['qty']; ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				</details>
				<table class="kuchnia-table kuchnia-otable">
					<colgroup><col class="ko-c1"><col class="ko-c2"><col class="ko-c3"></colgroup>
					<thead><tr><th>Zamówienie</th><th>Do przygotowania</th><th>Dodatki płatne</th></tr></thead>
					<tbody>
					<?php foreach ( $kitchen_orders as $order ) : ?>
						<?php list( $ko_prep, $ko_paid ) = rzd_kuchnia_order_kitchen_cells( $order ); $ko_time = (string) $order->get_meta( '_dc_planned_time' ); ?>
						<tr class="<?php echo rzd_kuchnia_is_new_order( $order ) ? 'kuchnia-new' : ''; ?>">
							<td data-label="Zamówienie" class="ko-order">
								<div class="ko-nr">#<?php echo esc_html( $order->get_order_number() ); ?><?php echo '' !== $ko_time ? ' · ' . esc_html( $ko_time ) : ''; ?></div>
								<div><?php echo esc_html( $order->get_formatted_billing_full_name() ); ?></div>
								<div><?php echo rzd_kuchnia_status_badge_html( $order ); // phpcs:ignore ?></div>
								<?php if ( $order->get_customer_note() ) : ?>
									<div class="kd-cnote">Uwagi: <?php echo esc_html( $order->get_customer_note() ); ?></div>
								<?php endif; ?>
							</td>
							<td data-label="Do przygotowania"><?php echo $ko_prep; // phpcs:ignore – zbudowane z esc_html ?></td>
							<td data-label="Dodatki płatne"><?php echo $ko_paid; // phpcs:ignore ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<button type="button" class="kuchnia-btn kuchnia-btn-primary" id="kuchnia-mark-preparing" data-date="<?php echo esc_attr( $date ); ?>" data-time="<?php echo esc_attr( $time ); ?>">Oznacz cały termin jako „Przygotowane"</button>
			<?php endif; ?>

		<?php elseif ( 'pakowanie' === $view ) : ?>
			<?php
			// Do spakowania = wszystko, co jeszcze nie jest spakowane – bez
			// czekania, aż kuchnia oznaczy termin jako Przygotowane.
			// Znaczek statusu przy każdym zamówieniu mówi, na jakim jest etapie.
			$todo   = array_values( array_filter( $orders, function ( $o ) { return ! in_array( $o->get_status(), array( 'w-dostawie', 'wydane' ), true ); } ) );
			$packed = array_values( array_filter( $orders, function ( $o ) { return in_array( $o->get_status(), array( 'w-dostawie', 'wydane' ), true ); } ) );
			?>
			<div class="kuchnia-section-header">Do spakowania (<?php echo count( $todo ); ?>)</div>
			<?php if ( ! $todo ) : ?>
				<p class="kuchnia-empty">Nic do spakowania w tym terminie – wszystko już spakowane.</p>
			<?php else : ?>
				<?php foreach ( $todo as $order ) : ?>
					<div class="kuchnia-card<?php echo rzd_kuchnia_is_new_order( $order ) ? ' kuchnia-new' : ''; ?>">
						<div class="kuchnia-card-main">
							<h3>#<?php echo esc_html( $order->get_order_number() ); ?> — <?php echo esc_html( $order->get_formatted_billing_full_name() ); ?> <?php echo rzd_kuchnia_status_badge_html( $order ); ?></h3>
							<p class="kuchnia-addr-line"><?php echo rzd_kuchnia_address_html( $order ); // phpcs:ignore ?></p>
							<p class="kuchnia-mod"><?php echo rzd_kuchnia_payment_html( $order ); ?></p>
							<ul>
								<?php foreach ( $order->get_items() as $item ) : ?>
									<?php
									$qty  = (int) $item->get_quantity();
									if ( $qty <= 0 ) { continue; }
									$mods = rzd_kuchnia_item_pack_notes( $item );
									?>
									<li>
										<strong><?php echo (int) $qty; ?>×</strong> <?php echo rzd_kuchnia_item_name_html( $item ); // phpcs:ignore ?>
										<?php echo rzd_kuchnia_item_set_html( $item ); ?>
										<?php if ( $mods ) : ?>
											<div class="kuchnia-mod"><?php echo esc_html( implode( ' · ', $mods ) ); ?></div>
										<?php endif; ?>
									</li>
								<?php endforeach; ?>
							</ul>
							<?php $packs = function_exists( 'rzd_order_packaging' ) ? rzd_order_packaging( $order ) : array(); ?>
							<?php if ( $packs ) : ?>
								<p class="kuchnia-packs"><strong>Opakowania:</strong>
									<?php echo esc_html( implode( ', ', array_map( function ( $p ) { return (int) $p['count'] . '× ' . $p['name']; }, $packs ) ) ); ?>
								</p>
							<?php endif; ?>
							<?php if ( $order->get_customer_note() ) : ?>
								<p class="kuchnia-mod"><strong>Uwagi klienta:</strong> <?php echo esc_html( $order->get_customer_note() ); ?></p>
							<?php endif; ?>
						</div>
						<div class="kuchnia-card-btns">
							<?php if ( 'gotowe' === $order->get_status() ) : ?>
								<span class="kuchnia-prep-done">✓ Przygotowane</span>
							<?php else : ?>
								<?php // Przy włączonym "Auto przygotowanie" szary = krok opcjonalny, dalej klikalny. ?>
								<button type="button" class="kuchnia-prep-btn<?php echo $auto_prep ? ' is-muted' : ''; ?>" data-order="<?php echo (int) $order->get_id(); ?>">Przygotowane</button>
							<?php endif; ?>
							<button type="button" class="kuchnia-pack-btn" data-order="<?php echo (int) $order->get_id(); ?>">Spakowane</button>
						</div>
					</div>
				<?php endforeach; ?>
			<?php endif; ?>

			<div class="kuchnia-section-header">Spakowane (<?php echo count( $packed ); ?>)</div>
			<?php if ( ! $packed ) : ?>
				<p class="kuchnia-empty">Jeszcze nic nie jest spakowane.</p>
			<?php else : ?>
				<div>
					<?php foreach ( $packed as $order ) : ?>
						<div class="kuchnia-packed-box" data-toggle="kpd-<?php echo (int) $order->get_id(); ?>">
							#<?php echo esc_html( $order->get_order_number() ); ?> — <?php echo esc_html( $order->get_formatted_billing_full_name() ); ?> <?php echo rzd_kuchnia_status_badge_html( $order ); ?>
						</div>
					<?php endforeach; ?>
				</div>
				<?php foreach ( $packed as $order ) : ?>
					<div class="kuchnia-packed-detail" id="kpd-<?php echo (int) $order->get_id(); ?>">
						<strong>#<?php echo esc_html( $order->get_order_number() ); ?> — <?php echo esc_html( $order->get_formatted_billing_full_name() ); ?></strong>
						<p class="kuchnia-addr-line"><?php echo rzd_kuchnia_address_html( $order ); // phpcs:ignore ?></p>
						<ul style="margin:8px 0 0 20px;">
							<?php foreach ( $order->get_items() as $item ) : ?>
								<?php $qty = (int) $item->get_quantity(); if ( $qty <= 0 ) { continue; } ?>
								<li><strong><?php echo (int) $qty; ?>×</strong> <?php echo rzd_kuchnia_item_name_html( $item ); // phpcs:ignore ?><?php echo rzd_kuchnia_item_set_html( $item ); ?></li>
							<?php endforeach; ?>
						</ul>
					</div>
				<?php endforeach; ?>
			<?php endif; ?>

		<?php elseif ( 'planowanie' === $view ) : ?>
			<?php if ( ! $orders ) : ?>
				<p class="kuchnia-empty">Brak zamówień w tym terminie.</p>
			<?php else : ?>
				<?php
				$locked = rzd_kuchnia_is_planning_locked( $date, $time );
				// Tryb okien: siatka slotów z wszystkich zamówień terminu
				// (także już dostarczonych – ich godziny wciąż są zajęte).
				$all_in_slot = function_exists( 'rzd_dc_plan_grid' ) ? rzd_kuchnia_orders_for_slot( $date, $time ) : array();
				$grid        = function_exists( 'rzd_dc_plan_grid' ) ? rzd_dc_plan_grid( $date, $time, $all_in_slot ) : null;
				?>
				<?php if ( $grid ) : ?>
					<div class="kuchnia-plan-head<?php echo $grid['used'] > $grid['cap'] ? ' is-over' : ''; ?>">
						Okno <strong><?php echo esc_html( $grid['win']['start'] . '–' . $grid['win']['end'] ); ?></strong>
						· Punkty: <strong><?php echo (int) $grid['used']; ?> / <?php echo (int) $grid['cap']; ?></strong>
						· co <?php echo esc_html( str_replace( '.', ',', (string) round( $grid['win']['len'] / max( 1, $grid['cap'] ), 1 ) ) ); ?> min
						<?php echo $grid['used'] > $grid['cap'] ? ' · <strong>przeładowane – ostatnie godziny wypadają po oknie</strong>' : ''; ?>
					</div>
				<?php endif; ?>
				<table class="kuchnia-table<?php echo $locked ? ' kuchnia-plan-locked' : ''; ?>" id="kuchnia-plan-table">
					<thead><tr><th>Nr</th><th>Nazwisko</th><th>Adres</th><th>Telefon</th><th>Płatność</th><th>Status</th><?php echo $grid ? '<th>Pkt</th>' : ''; ?><th>Kolejność</th><th>Godzina dostawy</th></tr></thead>
					<tbody>
					<?php foreach ( $orders as $order ) : ?>
						<?php
						$seq   = (int) $order->get_meta( '_dc_delivery_sequence' );
						$ptime = $order->get_meta( '_dc_planned_time' );
						?>
						<tr data-order="<?php echo (int) $order->get_id(); ?>">
							<td data-label="Nr">#<?php echo esc_html( $order->get_order_number() ); ?></td>
							<td data-label="Nazwisko"><?php echo esc_html( $order->get_formatted_billing_full_name() ); ?></td>
							<td data-label="Adres"><?php echo rzd_kuchnia_address_html( $order ); // phpcs:ignore ?></td>
							<td data-label="Telefon"><?php echo esc_html( $order->get_billing_phone() ); ?></td>
							<td data-label="Płatność"><?php echo rzd_kuchnia_payment_html( $order ); ?></td>
							<td data-label="Status"><?php echo rzd_kuchnia_status_badge_html( $order ); ?></td>
							<?php if ( $grid ) : ?>
								<?php
								$opts = rzd_dc_plan_options( rzd_dc_plan_grid( $date, $time, $all_in_slot, $order->get_id() ), $order );
								?>
								<td data-label="Pkt"><?php echo (int) rzd_dc_order_points( $order ); ?></td>
								<td data-label="Kolejność"><input type="number" min="1" class="kuchnia-plan-input" data-field="sequence" value="<?php echo $seq ? esc_attr( $seq ) : ''; ?>" <?php disabled( $locked ); ?>></td>
								<td data-label="Godzina dostawy">
									<select class="kuchnia-plan-time" data-field="planned_time" <?php disabled( $locked ); ?>>
										<option value="">–</option>
										<?php if ( $ptime && ! isset( $opts[ $ptime ] ) ) : ?>
											<option value="<?php echo esc_attr( $ptime ); ?>" selected><?php echo esc_html( $ptime . ' ⚠ koliduje' ); ?></option>
										<?php endif; ?>
										<?php foreach ( $opts as $t => $lbl ) : ?>
											<option value="<?php echo esc_attr( $t ); ?>" <?php selected( $ptime, $t ); ?>><?php echo esc_html( $lbl ); ?></option>
										<?php endforeach; ?>
									</select>
								</td>
							<?php else : ?>
							<td data-label="Kolejność"><input type="number" min="1" class="kuchnia-plan-input" data-field="sequence" value="<?php echo $seq ? esc_attr( $seq ) : ''; ?>" <?php disabled( $locked ); ?>></td>
							<td data-label="Godzina dostawy"><input type="time" class="kuchnia-plan-time" data-field="planned_time" value="<?php echo esc_attr( $ptime ); ?>" <?php disabled( $locked ); ?>></td>
							<?php endif; ?>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<div id="kuchnia-plan-actions">
					<button type="button" class="kuchnia-btn kuchnia-btn-primary" id="kuchnia-plan-confirm" data-date="<?php echo esc_attr( $date ); ?>" data-time="<?php echo esc_attr( $time ); ?>" style="<?php echo $locked ? 'display:none;' : ''; ?>">Zaplanowane</button>
					<button type="button" class="kuchnia-btn" id="kuchnia-plan-edit" data-date="<?php echo esc_attr( $date ); ?>" data-time="<?php echo esc_attr( $time ); ?>" style="<?php echo $locked ? '' : 'display:none;'; ?>">Edytuj</button>
				</div>
				<p class="kuchnia-mod"><?php echo $locked ? 'Plan zatwierdzony – kliknij „Edytuj", żeby coś zmienić.' : 'Wypełnij pola, a potem kliknij „Zaplanowane".'; ?></p>
			<?php endif; ?>

		<?php elseif ( 'dashboard' === $view ) : ?>
			<?php echo rzd_dash_html( $base ); // phpcs:ignore -- moduł 23, treść już escapowana ?>

		<?php else : // kurier (moduł 19) ?>
			<?php echo function_exists( 'rzd_kurier_view_html' ) ? rzd_kurier_view_html( $orders, $date ) : ''; // phpcs:ignore ?>
		<?php endif; ?>
	</div>

	<script>window.rzdKuchniaCfg = <?php echo wp_json_encode( array(
		'mode'   => $mode, // 'kuchnia' albo 'kurier'
		'front'  => (bool) $front,
		'wcAjax' => class_exists( 'WC_AJAX' ) ? WC_AJAX::get_endpoint( '__ACTION__' ) : '',
		'today'  => current_time( 'Y-m-d' ),
	) ); ?>;</script>
	<script src="<?php echo esc_url( RZD_PLUGIN_URL . 'assets/js/rzd-kuchnia.js?ver=' . rzd_asset_ver( 'assets/js/rzd-kuchnia.js' ) ); ?>"></script>
	<?php
}

