<?php
/**
 * MODUŁ 12: Kuchnia — dashboard zamówień wg terminu dostawy
 *
 * Pięć zakładek (zamówienia opłacone online albo z płatnością przy odbiorze):
 *  - Zamówienia – TAŚMA z niezrealizowanych (bez Dostarczonych): na górze
 *                 "Najbliższy wyjazd" z licznikami (cutoff za… / wyjazd
 *                 za…); po wyjeździe ekran sam się odświeża i wchodzi
 *                 następny termin. Pod nim "W drodze" (Spakowane w oknie
 *                 klienta = wyjazd + 1 h) i "Do przeplanowania" (okno minęło,
 *                 niedostarczone; przycisk "Nowy termin" + mail do klienta).
 *                 Pod grubą kreską czekające z poprawnym oknem, rosnąco,
 *                 BEZ tych z góry. Kolumny: nr, termin, nazwisko, adres,
 *                 wartość, status, Anuluj (nie dla dostarczonych).
 *  - Kuchnia    – lista załadunkowa WYBRANEGO terminu (ile czego zrobić),
 *                 przycisk oznacza cały termin jako "Przygotowane"
 *  - Pakowanie  – karty zamówień terminu; "Przygotowane" i "Spakowane"
 *                 pojedynczo, nie czeka na kuchnię
 *  - Planowanie – kolejność dostawy i konkretna godzina, "Zaplanowane" blokuje
 *  - Historia   – wszystko od (dziś − "Dni wstecz"), z dostarczonymi i
 *                 anulowanymi, malejąco; tylko podgląd
 * Kurier to osobny widok z osobnym PIN-em – moduł 19 (ten sam dashboard
 * w trybie 'kurier').
 *
 * Przełącznik "Auto przygotowanie" (moduł 13): po cutoffie zamówienia
 * same przechodzą na "W przygotowaniu".
 *
 * Responsywny (tablet/telefon/komputer), wydruk A4 poziomo, pełny ekran,
 * auto-odświeżanie co 60 s bez przeładowania strony. Na froncie przez
 * shortcode [kuchnia_dashboard] z bramką PIN (sekcja 5 niżej).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 1. MENU
 * ============================================================ */
add_action( 'admin_menu', function () {
	add_menu_page( 'Kuchnia', 'Kuchnia', 'manage_woocommerce', 'rzd-kuchnia', 'kuchnia_render_page', 'dashicons-carrot', 3 );
} );

// Statusy liczone jako "opłacone" – 'wc-on-hold' świadomie pominięty,
// bo zwykle oznacza oczekiwanie na przelew, a dashboard ma pokazywać
// tylko zamówienia faktycznie opłacone.
function kuchnia_statuses() {
	return rzd_order_statuses_active(); // moduł 00
}

/* ============================================================
 * 2. DANE
 * ============================================================ */
// Zamówienia na dany dzień (wszystkie godziny) – opłacone ONLINE, albo z
// wybraną metodą "płatność przy odbiorze" (te idą do realizacji od razu,
// mimo że pieniądze jeszcze nie wpłynęły – klient płaci na miejscu).
function kuchnia_orders_for_date( $date ) {
	// Ta funkcja jest wywoływana kilka razy na jedno wejście na dashboard
	// (osobno dla "Zamówienia" i osobno dla reszty zakładek) – bez cache'a
	// robiłaby to samo zapytanie do bazy po kilka razy z rzędu.
	static $cache = array();
	if ( isset( $cache[ $date ] ) ) {
		return $cache[ $date ];
	}
	$orders = wc_get_orders( array(
		'limit'      => -1,
		'status'     => kuchnia_statuses(),
		'orderby'    => 'date',
		'order'      => 'ASC',
		'meta_query' => array( // phpcs:ignore
			array( 'key' => '_dc_delivery_date', 'value' => $date, 'compare' => '=' ),
		),
		'return'     => 'objects',
	) );
	$cache[ $date ] = kuchnia_filter_paid( $orders );
	return $cache[ $date ];
}

// Tylko opłacone ONLINE albo z płatnością przy odbiorze (cod). Anulowane
// (Historia) – tylko te, które kiedyś były opłacone: porzucone, nieopłacone
// zamówienia z Przelewy24 WooCommerce też anuluje, a tych kuchnia nie widziała.
function kuchnia_filter_paid( $orders ) {
	return array_values( array_filter( $orders, function ( $o ) {
		if ( 'cancelled' === $o->get_status() ) {
			return (bool) $o->get_date_paid() || 'cod' === $o->get_payment_method();
		}
		if ( $o->is_paid() ) {
			return true;
		}
		return 'cod' === $o->get_payment_method();
	} ) );
}

// Zakładka Historia: wszystko z dostawą od $from (Y-m-d) wzwyż – także
// przyszłość bez limitu i anulowane.
function kuchnia_orders_from_date( $from ) {
	$orders = wc_get_orders( array(
		'limit'      => -1,
		'status'     => array_merge( kuchnia_statuses(), array( 'wc-cancelled' ) ),
		'meta_query' => array( // phpcs:ignore
			array( 'key' => '_dc_delivery_date', 'value' => $from, 'compare' => '>=' ),
		),
		'return'     => 'objects',
	) );
	return kuchnia_filter_paid( $orders );
}

// Zakładka Zamówienia: wszystko NIEZREALIZOWANE (bez Dostarczonych i
// Zrealizowanych), niezależnie od daty – zapomniane z poprzednich dni też.
function kuchnia_orders_open() {
	$open = array_values( array_diff( kuchnia_statuses(), array( 'wc-wydane', 'wc-completed' ) ) );
	$orders = wc_get_orders( array(
		'limit'      => -1,
		'status'     => $open,
		'meta_query' => array( // phpcs:ignore
			array( 'key' => '_dc_delivery_date', 'compare' => 'EXISTS' ),
		),
		'return'     => 'objects',
	) );
	return kuchnia_filter_paid( $orders );
}

// Zamówienie da się anulować z Kuchni tylko, dopóki nie jest dostarczone
// (ta sama reguła pilnowana na serwerze, moduł 13).
function kuchnia_can_cancel( $order ) {
	return ! in_array( $order->get_status(), array( 'wydane', 'completed', 'cancelled' ), true );
}

/**
 * Zamówienia pogrupowane: dzień dostawy → cutoff → godzina wyjazdu.
 * Zwraca listę terminów (slotów), każdy:
 * [ 'date', 'time', 'cutoff_ts', 'depart_ts', 'closed', 'orders' ].
 * Zamówienia bez godziny dostawy mają time '—' i cutoff_ts 0.
 */
function kuchnia_slot_groups( $orders ) {
	$slots = array();
	foreach ( $orders as $o ) {
		$d = (string) $o->get_meta( '_dc_delivery_date' );
		$t = (string) $o->get_meta( '_dc_delivery_time' );
		$t = $t ? $t : '—';
		$k = $d . ' ' . $t;
		if ( ! isset( $slots[ $k ] ) ) {
			$has_time    = ( '—' !== $t );
			$slots[ $k ] = array(
				'date'      => $d,
				'time'      => $t,
				'cutoff_ts' => ( $has_time && function_exists( 'dc_cutoff_ts' ) ) ? dc_cutoff_ts( $d, $t ) : 0,
				'depart_ts' => ( $has_time && function_exists( 'dc_date_ts' ) ) ? dc_date_ts( $d, $t ) : 0,
				'closed'    => ( $has_time && function_exists( 'dc_is_cutoff_passed' ) ) ? dc_is_cutoff_passed( $d, $t ) : true,
				'orders'    => array(),
			);
		}
		$slots[ $k ]['orders'][] = $o;
	}
	foreach ( $slots as &$sl ) {
		// W obrębie terminu: najmłodsze zamówienie na górze.
		usort( $sl['orders'], function ( $a, $b ) {
			return $b->get_id() <=> $a->get_id();
		} );
	}
	unset( $sl );
	return array_values( $slots );
}

// "Nowe" zamówienie = opłacone (albo złożone, gdy płatność przy odbiorze)
// w ciągu ostatnich 10 minut – wyróżnione pogrubieniem, potem jak inne.
function kuchnia_is_new_order( $order ) {
	$d = $order->get_date_paid();
	if ( ! $d ) {
		$d = $order->get_date_created();
	}
	return $d && ( time() - $d->getTimestamp() ) < 10 * MINUTE_IN_SECONDS;
}

// Moment cutoffu jako tekst, np. "30.09 10:30".
function kuchnia_cutoff_label( $ts ) {
	return $ts ? wp_date( 'd.m H:i', $ts ) : '—';
}

// Tabela zamówień: Nr, Termin, Nazwisko, Adres, Wartość, Status, [Anuluj].
// $actions = false → Historia, tylko podgląd.
function kuchnia_orders_table_html( $orders, $actions = true, $resched = false ) {
	ob_start();
	?>
	<table class="kuchnia-table">
		<thead><tr><th>Nr</th><th>Termin</th><th>Nazwisko</th><th>Adres</th><th>Wartość</th><th>Status</th><?php if ( $actions ) : ?><th class="kuchnia-noprint"></th><?php endif; ?></tr></thead>
		<tbody>
		<?php foreach ( $orders as $order ) : ?>
			<?php
			$t     = $order->get_meta( '_dc_delivery_time' );
			$ptime = $order->get_meta( '_dc_planned_time' );
			$term  = ( $t ? $t : '—' ) . ( $ptime ? ' → ' . $ptime : '' );
			?>
			<tr<?php echo kuchnia_is_new_order( $order ) ? ' class="kuchnia-new"' : ''; ?>>
				<td data-label="Nr">#<?php echo esc_html( $order->get_order_number() ); ?></td>
				<td data-label="Termin"><?php echo esc_html( $term ); ?></td>
				<td data-label="Nazwisko"><?php echo esc_html( $order->get_formatted_billing_full_name() ); ?></td>
				<td data-label="Adres"><?php echo kuchnia_address_html( $order ); // phpcs:ignore ?></td>
				<td data-label="Wartość"><?php echo wp_kses_post( wc_price( $order->get_total(), array( 'currency' => $order->get_currency() ) ) ); ?></td>
				<td data-label="Status"><?php echo kuchnia_status_badge_html( $order ); ?></td>
				<?php if ( $actions ) : ?>
				<td data-label="" class="kuchnia-noprint">
					<?php if ( $resched && rzd_can( 'change' ) ) : // 2.30.0 ?>
						<button type="button" class="kuchnia-resched-btn" data-order="<?php echo (int) $order->get_id(); ?>">Nowy termin</button>
					<?php endif; ?>
					<?php if ( kuchnia_can_cancel( $order ) && rzd_can( 'change' ) ) : // 2.30.0 ?>
						<button type="button" class="kuchnia-cancel-btn" data-order="<?php echo (int) $order->get_id(); ?>">Anuluj</button>
					<?php endif; ?>
				</td>
				<?php endif; ?>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
	<?php
	return ob_get_clean();
}

// Zbiorczy znaczek otwarty/zamknięty dla grupy terminów (zamknięty = wszystkie zamknięte).
function kuchnia_group_badge_html( $slots ) {
	$closed = true;
	foreach ( $slots as $sl ) {
		if ( ! $sl['closed'] ) {
			$closed = false;
		}
	}
	return '<span class="kuchnia-cutoff-badge kuchnia-cutoff-' . ( $closed ? 'closed' : 'open' ) . '">' . ( $closed ? 'zamknięty' : 'otwarty' ) . '</span>';
}

// Lista pod kreską: $days = [ data => [ cutoff_ts => [ sloty ] ] ] w gotowej
// kolejności. Nagłówek dnia → "Cutoff: …" → "Wyjazd HH:MM" → tabela.
function kuchnia_days_html( $days, $actions ) {
	ob_start();
	foreach ( $days as $d => $cuts ) {
		$day_count = 0;
		foreach ( $cuts as $cut_slots ) {
			foreach ( $cut_slots as $sl ) {
				$day_count += count( $sl['orders'] );
			}
		}
		echo '<div class="kuchnia-section-header kuchnia-day-header">' . esc_html( ucfirst( function_exists( 'dc_date_label' ) ? dc_date_label( $d ) : $d ) ) . ' <span class="kuchnia-count">(' . (int) $day_count . ')</span></div>';
		foreach ( $cuts as $cut_ts => $cut_slots ) {
			echo '<div class="kuchnia-cutoff-header">' . ( $cut_ts ? 'Cutoff: ' . esc_html( kuchnia_cutoff_label( $cut_ts ) ) . ' ' . kuchnia_group_badge_html( $cut_slots ) : 'Bez godziny dostawy' ) . '</div>';
			foreach ( $cut_slots as $sl ) {
				echo '<div class="kuchnia-time-header">Wyjazd ' . esc_html( $sl['time'] ) . ' <span class="kuchnia-count">(' . count( $sl['orders'] ) . ')</span></div>';
				echo kuchnia_orders_table_html( $sl['orders'], $actions ); // phpcs:ignore
			}
		}
	}
	return ob_get_clean();
}

// [ 'HH:MM' => liczba zamówień ], posortowane godzinowo.
function kuchnia_slots_for_date( $date ) {
	$counts = array();
	foreach ( kuchnia_orders_for_date( $date ) as $order ) {
		$t = $order->get_meta( '_dc_delivery_time' );
		if ( ! $t ) {
			$t = '—';
		}
		$counts[ $t ] = ( isset( $counts[ $t ] ) ? $counts[ $t ] : 0 ) + 1;
	}
	ksort( $counts );
	return $counts;
}

// Zamówienia dokładnie na wybrany dzień + godzinę.
function kuchnia_orders_for_slot( $date, $time ) {
	$out = array();
	foreach ( kuchnia_orders_for_date( $date ) as $order ) {
		$t = $order->get_meta( '_dc_delivery_time' );
		if ( ( $t ? $t : '—' ) === $time ) {
			$out[] = $order;
		}
	}
	return $out;
}

// Statusy oznaczające "minął cutoff, zamówienie jest już w realizacji" –
// to one decydują o widoczności w zakładkach Kuchnia/Pakowanie/Planowanie/
// Kurier (w odróżnieniu od "Zamówienia", które pokazuje wszystko opłacone).
// Zamiast pokazywać w Kuchni/Pakowaniu/Planowaniu/Kurierze tylko to, co już
// przeszło cutoff, pokazujemy WSZYSTKIE opłacone zamówienia dnia – kuchnia ma
// wiedzieć wcześniej, co nadchodzi, żeby móc zacząć przygotowania z
// wyprzedzeniem. Rozróżnienie "cutoff otwarty/zamknięty" pokazujemy osobno,
// przy każdym oknie (patrz kuchnia_cutoff_badge_html), zamiast całkiem
// chować zamówienia, których okno jeszcze przyjmuje nowe zgłoszenia.
function kuchnia_pipeline_statuses() {
	$out = array();
	foreach ( kuchnia_statuses() as $s ) {
		$out[] = ( 0 === strpos( $s, 'wc-' ) ) ? substr( $s, 3 ) : $s;
	}
	return $out;
}

function kuchnia_orders_for_date_pipeline( $date ) {
	$statuses = kuchnia_pipeline_statuses();
	return array_values( array_filter( kuchnia_orders_for_date( $date ), function ( $o ) use ( $statuses ) {
		return in_array( $o->get_status(), $statuses, true );
	} ) );
}

function kuchnia_slots_for_date_pipeline( $date ) {
	$counts = array();
	foreach ( kuchnia_orders_for_date_pipeline( $date ) as $order ) {
		$t = $order->get_meta( '_dc_delivery_time' );
		if ( ! $t ) {
			$t = '—';
		}
		$counts[ $t ] = ( isset( $counts[ $t ] ) ? $counts[ $t ] : 0 ) + 1;
	}
	ksort( $counts );
	return $counts;
}

function kuchnia_orders_for_slot_pipeline( $date, $time ) {
	$out = array();
	foreach ( kuchnia_orders_for_date_pipeline( $date ) as $order ) {
		$t = $order->get_meta( '_dc_delivery_time' );
		if ( ( $t ? $t : '—' ) === $time ) {
			$out[] = $order;
		}
	}
	return $out;
}

// Pozycje jednego zamówienia rozbite na dania (zestaw -> jego dania) z ilością i info czy to dodatek.
function kuchnia_order_lines( $order ) {
	$lines = array();
	foreach ( $order->get_items() as $item ) {
		$qty = (int) $item->get_quantity();
		if ( $qty <= 0 ) {
			continue;
		}
		$w_zest = $item->get_meta( 'W zestawie' );
		if ( $w_zest ) {
			foreach ( array_filter( array_map( 'trim', explode( ',', $w_zest ) ) ) as $nazwa ) {
				$lines[] = array( 'name' => $nazwa, 'qty' => $qty, 'addon' => false, 'set_name' => $item->get_name(), 'kind' => 'danie' );
			}
		} else {
			$is_addon = (bool) $item->get_meta( 'Dodatek do' );
			$lines[]  = array( 'name' => $item->get_name(), 'qty' => $qty, 'addon' => $is_addon, 'set_name' => '', 'kind' => $is_addon ? 'dodatki' : 'danie' );
		}

		// Dodatki z modułu 10 (katalog Składników) – osobne, policzalne wiersze,
		// niezależnie od tego, czy to była pozycja zestawowa czy zwykły produkt.
		// "Odejmuje" pokazujemy jako osobną pozycję "Bez: …", żeby kuchnia
		// widziała wprost, ile sztuk NIE robić, zamiast cichego odjęcia od sumy.
		if ( function_exists( 'rzd_item_addon_usage' ) ) {
			foreach ( rzd_item_addon_usage( $item ) as $u ) {
				$kind    = function_exists( 'rzd_usage_kind' ) ? rzd_usage_kind( $u ) : 'dodatki';
				$name    = ( 'bez' === $kind ) ? ( 'Bez: ' . $u['name'] ) : $u['name'];
				$lines[] = array( 'name' => $name, 'qty' => (int) $u['qty'] * $qty, 'addon' => true, 'set_name' => '', 'kind' => $kind );
			}
		}
	}
	// Opakowania (moduł 21) – policzone przy zamówieniu, na całe zamówienie.
	if ( function_exists( 'rzd_order_packaging' ) ) {
		foreach ( rzd_order_packaging( $order ) as $p ) {
			if ( ! empty( $p['count'] ) ) {
				$lines[] = array( 'name' => $p['name'], 'qty' => (int) $p['count'], 'addon' => true, 'set_name' => '', 'kind' => 'opakowanie' );
			}
		}
	}
	return $lines;
}

// Modyfikacje wybrane na pozycji zamówienia (z modułu 10) – do widoku "Pakowanie".
function kuchnia_item_modifier_notes( $item ) {
	$notes = array();
	$skip  = array( 'W zestawie', 'Dodatek do', '_reduced_stock', '_qty', '_rzd_addon_usage', '_rwz_component_ids' );
	foreach ( $item->get_all_formatted_meta_data( '' ) as $meta ) {
		if ( in_array( $meta->key, $skip, true ) ) {
			continue;
		}
		$notes[] = $meta->display_key . ': ' . wp_strip_all_tags( $meta->display_value );
	}
	return $notes;
}

// Skład zestawu zapisany w pozycji zamówienia ("W zestawie", moduł 04) –
// dania zamrożone na dzień dostawy w chwili dodania do koszyka.
function kuchnia_item_set_html( $item ) {
	$w_zest = $item->get_meta( 'W zestawie' );
	if ( ! $w_zest ) {
		return '';
	}
	$names = array_filter( array_map( 'trim', explode( ',', $w_zest ) ) );
	if ( ! $names ) {
		return '';
	}
	return '<div class="kuchnia-set-sklad">W zestawie: ' . esc_html( implode( ', ', $names ) ) . '</div>';
}

