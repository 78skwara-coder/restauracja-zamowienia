<?php
/**
 * SNIPPET 1: Alergeny (z piktogramami)
 * Code Snippets → Run everywhere (pomiń pierwszą linię "<?php")
 *
 * - sekcja "Alergeny" (checkboxy) w edycji produktu
 * - każdy alergen może mieć piktogram (obrazek z biblioteki mediów)
 * - alergeny na karcie produktu
 * - funkcja rest_alergeny_html() używana przez snippet 2 (lista)
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'init', function () {
	register_taxonomy( 'alergen', 'product', [
		'label'             => 'Alergeny',
		'hierarchical'      => true,    // checkboxy w edycji produktu
		'public'            => false,
		'show_ui'           => true,
		'show_admin_column' => false,   // bez kolumny na liście wszystkich produktów
		'show_in_rest'      => true,
		'rewrite'           => false,
	] );

	// 14 podstawowych alergenów – dodają się raz, własne dopiszesz w Produkty → Alergeny
	if ( ! get_option( 'rest_alergeny_seeded' ) ) {
		$domyslne = [
			'Gluten', 'Skorupiaki', 'Jaja', 'Ryby', 'Orzeszki ziemne', 'Soja', 'Mleko',
			'Orzechy', 'Seler', 'Gorczyca', 'Sezam', 'Siarczyny', 'Łubin', 'Mięczaki',
		];
		foreach ( $domyslne as $nazwa ) {
			wp_insert_term( $nazwa, 'alergen' );
		}
		update_option( 'rest_alergeny_seeded', 1 );
	}
}, 20 );

/* ---------- Piktogram alergenu (pole w formularzu alergenu) ---------- */
function rest_alergen_icon_field_html( $icon_id = 0 ) {
	$preview = $icon_id ? wp_get_attachment_image( $icon_id, [ 40, 40 ] ) : '';
	?>
	<input type="hidden" name="alergen_icon_id" value="<?php echo esc_attr( $icon_id ?: '' ); ?>">
	<div class="rest-icon-preview" style="margin:6px 0"><?php echo $preview; ?></div>
	<button type="button" class="button rest-icon-pick">Wybierz obrazek</button>
	<button type="button" class="button rest-icon-remove">Usuń</button>
	<p class="description">Opcjonalnie. Najlepiej kwadratowy obrazek PNG. Bez piktogramu wyświetli się sama nazwa.</p>
	<?php
}

add_action( 'alergen_add_form_fields', function () {
	echo '<div class="form-field rest-icon-field"><label>Piktogram</label>';
	rest_alergen_icon_field_html();
	echo '</div>';
} );

add_action( 'alergen_edit_form_fields', function ( $term ) {
	$icon_id = (int) get_term_meta( $term->term_id, 'alergen_icon_id', true );
	echo '<tr class="form-field rest-icon-field"><th scope="row"><label>Piktogram</label></th><td>';
	rest_alergen_icon_field_html( $icon_id );
	echo '</td></tr>';
} );

function rest_save_alergen_icon( $term_id ) {
	if ( isset( $_POST['alergen_icon_id'] ) ) {
		$id = absint( $_POST['alergen_icon_id'] );
		if ( $id ) {
			update_term_meta( $term_id, 'alergen_icon_id', $id );
		} else {
			delete_term_meta( $term_id, 'alergen_icon_id' );
		}
	}
}
add_action( 'created_alergen', 'rest_save_alergen_icon' );
add_action( 'edited_alergen', 'rest_save_alergen_icon' );

/* Biblioteka mediów + skrypt wyboru obrazka (tylko na ekranach alergenów) */
add_action( 'admin_enqueue_scripts', function () {
	$screen = get_current_screen();
	if ( $screen && 'alergen' === $screen->taxonomy ) {
		wp_enqueue_media();
	}
} );

add_action( 'admin_footer', function () {
	$screen = get_current_screen();
	if ( ! $screen || 'alergen' !== $screen->taxonomy ) {
		return;
	}
	?>
	<script>
	jQuery(function ($) {
		$(document).on('click', '.rest-icon-pick', function (e) {
			e.preventDefault();
			var wrap = $(this).closest('.rest-icon-field');
			var frame = wp.media({ title: 'Wybierz piktogram', button: { text: 'Użyj' }, multiple: false, library: { type: 'image' } });
			frame.on('select', function () {
				var a = frame.state().get('selection').first().toJSON();
				var url = (a.sizes && a.sizes.thumbnail) ? a.sizes.thumbnail.url : a.url;
				wrap.find('input[type=hidden]').val(a.id);
				wrap.find('.rest-icon-preview').html('<img src="' + url + '" style="width:40px;height:40px;object-fit:contain">');
			});
			frame.open();
		});
		$(document).on('click', '.rest-icon-remove', function (e) {
			e.preventDefault();
			var wrap = $(this).closest('.rest-icon-field');
			wrap.find('input[type=hidden]').val('');
			wrap.find('.rest-icon-preview').empty();
		});
		// po dodaniu alergenu (AJAX) wyczyść pole piktogramu
		$(document).ajaxComplete(function (e, xhr, s) {
			if (s.data && s.data.indexOf('action=add-tag') > -1) {
				$('.rest-icon-field input[type=hidden]').val('');
				$('.rest-icon-preview').empty();
			}
		});
	});
	</script>
	<?php
} );

/* Kolumna z piktogramem na liście alergenów (Produkty → Alergeny) */
add_filter( 'manage_edit-alergen_columns', function ( $cols ) {
	$new = [];
	foreach ( $cols as $k => $v ) {
		$new[ $k ] = $v;
		if ( 'cb' === $k ) {
			$new['rest_icon'] = 'Piktogram';
		}
	}
	return $new;
} );
add_filter( 'manage_alergen_custom_column', function ( $out, $col, $term_id ) {
	if ( 'rest_icon' === $col ) {
		$id  = (int) get_term_meta( $term_id, 'alergen_icon_id', true );
		$out = $id ? wp_get_attachment_image( $id, [ 32, 32 ] ) : '—';
	}
	return $out;
}, 10, 3 );

/* ---------- Alergeny produktu (domyślnie własne; zestaw może je zbierać ze składników) ---------- */
function rest_alergeny_terms( $product_id ) {
	// Filtr "rest_alergeny_zrodla" pozwala wskazać INNE produkty, z których
	// zbieramy alergeny (używa go snippet 5 dla zestawów).
	$zrodla = apply_filters( 'rest_alergeny_zrodla', [ (int) $product_id ], (int) $product_id );
	$terms  = [];
	foreach ( $zrodla as $id ) {
		$p = wc_get_product( $id );
		if ( $p && $p->is_type( 'variation' ) ) {
			$id = $p->get_parent_id(); // alergeny są przypisane do produktu głównego
		}
		$t = get_the_terms( $id, 'alergen' );
		if ( $t && ! is_wp_error( $t ) ) {
			foreach ( $t as $term ) {
				$terms[ $term->term_id ] = $term;
			}
		}
	}
	return array_values( $terms );
}

/* ---------- Wyświetlanie alergenów (piktogram + nazwa) ---------- */
function rest_alergeny_html( $product_id ) {
	$terms = rest_alergeny_terms( $product_id );
	if ( ! $terms ) {
		return '';
	}
	$out = '<span class="rl-alergeny">';
	foreach ( $terms as $t ) {
		$icon_id = (int) get_term_meta( $t->term_id, 'alergen_icon_id', true );
		$icon    = $icon_id ? wp_get_attachment_image( $icon_id, [ 32, 32 ], false, [ 'class' => 'rl-alergen-ico', 'alt' => '' ] ) : '';
		$out    .= '<span class="rl-alergen">' . $icon . esc_html( $t->name ) . '</span>';
	}
	return $out . '</span>';
}

/* Alergeny na karcie produktu */
add_action( 'woocommerce_single_product_summary', function () {
	$html = rest_alergeny_html( get_the_ID() );
	if ( $html ) {
		echo '<p class="rl-single-alergeny"><strong>Alergeny:</strong> ' . $html . '</p>';
	}
}, 25 );
