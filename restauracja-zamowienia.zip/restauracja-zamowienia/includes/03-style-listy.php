<?php
/**
 * MODUŁ 03: Style i typografia
 * Wczytuje includes/css/lista-zamowien.css oraz czcionki Google Fonts
 * (Playfair Display na nagłówki/nazwy dań, Mulish na resztę tekstu –
 * obie z pełnym wsparciem polskich znaków) na froncie sklepu.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Adres czcionek Google (też dla podglądu w „Wygląd listy”, moduł 15).
function rzd_fonts_url() {
	return 'https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=Lato:wght@400;600;700&family=Oswald:wght@500;600;700&subset=latin-ext&display=swap';
}

/**
 * 2.27.6: czcionki z NASZEGO serwera zamiast z Google.
 * Serwer raz (w tle, przez WP-Cron) pobiera CSS z Google i pliki woff2
 * (tylko zestawy latin i latin-ext – polskie znaki), zapisuje je w
 * uploads/rzd/fonts/ i podmienia adresy na lokalne. Dopóki pliki nie są
 * gotowe albo pobranie się nie uda – czcionki idą z Google jak dawniej
 * (ponowna próba po dobie). Zysk: brak połączeń do fonts.googleapis.com
 * i fonts.gstatic.com (szybszy tekst na telefonie) i IP klienta nie trafia
 * do Google (RODO).
 */
function rzd_fonts_local_url() {
	static $url = null;
	if ( null !== $url ) {
		return $url;
	}
	$url = '';
	if ( ! apply_filters( 'rzd_fonts_local', true ) ) {
		return $url;
	}
	$o   = get_option( 'rzd_fonts_local' );
	$key = md5( rzd_fonts_url() );
	if ( is_array( $o ) && isset( $o['key'], $o['file'] ) && $o['key'] === $key ) {
		$up = wp_upload_dir( null, false );
		if ( empty( $up['error'] ) && is_file( trailingslashit( $up['basedir'] ) . $o['file'] ) ) {
			$url = set_url_scheme( trailingslashit( $up['baseurl'] ) . $o['file'] );
			return $url;
		}
	}
	// Brak plików – zaplanuj pobranie w tle (nie w czasie wyświetlania strony).
	$retry = is_array( $o ) && isset( $o['fail_until'] ) ? (int) $o['fail_until'] : 0;
	if ( $retry < time() && ! wp_next_scheduled( 'rzd_fonts_build' ) ) {
		wp_schedule_single_event( time() + 5, 'rzd_fonts_build' );
	}
	return $url;
}

// Adres arkusza czcionek: lokalny, gdy gotowy, inaczej Google.
function rzd_fonts_href() {
	$local = rzd_fonts_local_url();
	return '' !== $local ? $local : rzd_fonts_url();
}

add_action( 'rzd_fonts_build', 'rzd_fonts_build' );
function rzd_fonts_build() {
	$fail = function () {
		update_option( 'rzd_fonts_local', array( 'key' => '', 'fail_until' => time() + DAY_IN_SECONDS ), true );
		return false;
	};
	$up = wp_upload_dir( null, false );
	if ( ! empty( $up['error'] ) ) {
		return $fail();
	}
	$dir = trailingslashit( $up['basedir'] ) . 'rzd/fonts';
	if ( ! wp_mkdir_p( $dir ) ) {
		return $fail();
	}
	// Nowoczesna przeglądarka w nagłówku – Google zwraca wtedy woff2.
	$ua  = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36';
	$res = wp_remote_get( rzd_fonts_url(), array( 'timeout' => 20, 'user-agent' => $ua ) );
	if ( is_wp_error( $res ) || 200 !== (int) wp_remote_retrieve_response_code( $res ) ) {
		return $fail();
	}
	$css = rzd_fonts_filter_css( (string) wp_remote_retrieve_body( $res ) );
	if ( ! preg_match_all( '#url\((https://fonts\.gstatic\.com/[^)\s]+)\)#', $css, $m ) ) {
		return $fail();
	}
	foreach ( array_unique( $m[1] ) as $remote ) {
		$name = md5( $remote ) . '.' . ( preg_match( '#\.(woff2|woff|ttf)$#', $remote, $e ) ? $e[1] : 'woff2' );
		$path = $dir . '/' . $name;
		if ( ! is_file( $path ) || ! filesize( $path ) ) {
			$r = wp_remote_get( $remote, array( 'timeout' => 20, 'user-agent' => $ua ) );
			if ( is_wp_error( $r ) || 200 !== (int) wp_remote_retrieve_response_code( $r ) || '' === wp_remote_retrieve_body( $r ) ) {
				return $fail();
			}
			if ( false === file_put_contents( $path, wp_remote_retrieve_body( $r ) ) ) { // phpcs:ignore
				return $fail();
			}
		}
		// Adres względny wobec pliku CSS (ten sam katalog) – działa przy http i https.
		$css = str_replace( $remote, $name, $css );
	}
	$file = 'rzd-fonts-' . substr( md5( $css ), 0, 12 ) . '.css';
	if ( false === file_put_contents( $dir . '/' . $file, $css ) ) { // phpcs:ignore
		return $fail();
	}
	// Stare arkusze (po zmianie zestawu czcionek) – usuń.
	foreach ( (array) glob( $dir . '/rzd-fonts-*.css' ) as $old ) {
		if ( basename( $old ) !== $file ) {
			@unlink( $old ); // phpcs:ignore
		}
	}
	update_option( 'rzd_fonts_local', array( 'key' => md5( rzd_fonts_url() ), 'file' => 'rzd/fonts/' . $file, 'time' => time() ), true );
	return true;
}

// Zostaw tylko bloki @font-face z zestawami latin i latin-ext (Google
// opisuje je komentarzem /* latin-ext */ nad blokiem). Bez komentarzy –
// cały CSS bez zmian.
function rzd_fonts_filter_css( $css ) {
	if ( ! preg_match_all( '#/\*\s*([a-z0-9-]+)\s*\*/\s*(@font-face\s*\{[^}]*\})#i', $css, $m, PREG_SET_ORDER ) ) {
		return $css;
	}
	$out = '';
	foreach ( $m as $b ) {
		if ( in_array( strtolower( $b[1] ), array( 'latin', 'latin-ext' ), true ) ) {
			$out .= '/* ' . $b[1] . " */\n" . $b[2] . "\n";
		}
	}
	return '' !== $out ? $out : $css;
}

add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style(
		'rzd-fonts',
		rzd_fonts_href(),
		array(),
		null
	);
	wp_enqueue_style(
		'rzd-lista-zamowien',
		RZD_PLUGIN_URL . 'includes/css/lista-zamowien.css',
		array( 'rzd-fonts' ),
		// wersja wtyczki + data pliku: nowy CSS po każdej zmianie, nawet bez podbicia wersji
		RZD_PLUGIN_VERSION . '.' . (int) @filemtime( RZD_PLUGIN_DIR . 'includes/css/lista-zamowien.css' )
	);
} );

// 2.26.13: wcześniejsze połączenie z serwerami czcionek Google (preconnect) –
// przeglądarka zestawia połączenie równolegle z ładowaniem strony, zamiast
// dopiero po odczytaniu CSS. Zwykle 100–300 ms szybsze pierwsze wyświetlenie
// tekstu na telefonie.
add_filter( 'wp_resource_hints', function ( $urls, $relation ) {
	if ( 'preconnect' === $relation && ! is_admin() && '' === rzd_fonts_local_url() ) {
		$urls[] = 'https://fonts.googleapis.com';
		$urls[] = array( 'href' => 'https://fonts.gstatic.com', 'crossorigin' );
	}
	return $urls;
}, 10, 2 );
