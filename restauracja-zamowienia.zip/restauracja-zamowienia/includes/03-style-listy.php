<?php
/**
 * MODUŁ 03: Style i typografia
 * Wczytuje includes/css/lista-zamowien.css oraz czcionki Google Fonts
 * (Playfair Display na nagłówki/nazwy dań, Mulish na resztę tekstu –
 * obie z pełnym wsparciem polskich znaków) na froncie sklepu.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Adres czcionek Google (też dla podglądu w „Wygląd listy”, moduł 15).
function rzd_fonts_url() {
	return 'https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=Lato:wght@400;600;700&family=Oswald:wght@500;600;700&subset=latin-ext&display=swap';
}

add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style(
		'rzd-fonts',
		rzd_fonts_url(),
		array(),
		null
	);
	wp_enqueue_style(
		'rzd-lista-zamowien',
		RZD_PLUGIN_URL . 'includes/css/lista-zamowien.css',
		array( 'rzd-fonts' ),
		// wersja wtyczki + data pliku: nowy CSS po każdej zmianie, nawet bez podbicia wersji
		RZD_PLUGIN_VERSION . '.' . (int) @filemtime( RZD_PLUGIN_DIR . 'includes/css/lista-zamowien.css' )
	);
} );
