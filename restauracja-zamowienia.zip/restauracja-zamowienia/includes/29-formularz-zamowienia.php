<?php
/**
 * MODUŁ 29: Formularz zamówienia (kasa klasyczna WooCommerce) – wygląd, zgody, przycisk.
 *
 * Bez dodatkowych wtyczek (zastępuje Fluid Checkout) i BEZ nadpisywania szablonów WooCommerce:
 * tylko oficjalne filtry/haki (pola, zgody, tekst przycisku) + własny CSS i mały skrypt.
 * Działa z każdym klasycznym motywem (Astra itd.) i nie psuje się przy aktualizacjach WooCommerce.
 *
 * Dwie części:
 * 1. ZGODY I PRZYCISK – działają zawsze (wymogi prawne i Przelewy24):
 *    - wymagane pole regulaminu WooCommerce z treścią „…akceptuję [terms] oraz [privacy_policy]”
 *      (WooCommerce pokazuje je, gdy w Ustawienia → Zaawansowane wybrana jest strona regulaminu);
 *    - opcjonalnie: osobne pole polityki prywatności, dodatkowe pole (np. regulamin operatora płatności);
 *    - ślad akceptacji w zamówieniu (`_rzd_consents`: kiedy, które wersje stron);
 *    - przycisk „Zamawiam i płacę 67,50 zł” (art. 17 ustawy o prawach konsumenta – przycisk musi
 *      jednoznacznie mówić o obowiązku zapłaty).
 * 2. NOWY WYGLĄD – po włączeniu w Restauracja → Formularz zamówienia (szefowa decyduje):
 *    sekcje jako karty, kolejność pól (telefon przy kontakcie), bez pola „Kraj” przy jednym kraju,
 *    „Potrzebuję faktury” (NIP → `_billing_nip`, jak wtyczki do faktur), uwagi zwinięte,
 *    płatności jako kafelki, na komputerze podsumowanie obok formularza, kolory z „Wyglądu listy”.
 *    Gdy działa Fluid Checkout – nowy wygląd się nie włącza (dwa układy kasy naraz = bałagan).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 1. USTAWIENIA
 * ============================================================ */
function rzd_co_defaults() {
	return array(
		'design'        => 0,          // nowy wygląd – włącza szefowa
		'invoice'       => 1,          // „Potrzebuję faktury” (NIP) – w nowym wyglądzie
		'notes'         => 'collapsed', // collapsed / open / hidden
		'consent'       => 'combined', // combined (jedno pole: regulamin + polityka) / separate / woocommerce (bez zmian)
		'consent_text'  => 'Zapoznałem/am się i akceptuję [terms] oraz [privacy_policy].',
		'privacy_text'  => 'Akceptuję [privacy_policy].',
		'extra_consent' => '',         // np. „Akceptuję regulamin Przelewy24” – puste = brak
		'button_text'   => 'Zamawiam i płacę',
		'button_total'  => 1,
	);
}
function rzd_co_settings() {
	$s = get_option( 'rzd_checkout', array() );
	return wp_parse_args( is_array( $s ) ? $s : array(), rzd_co_defaults() );
}
function rzd_co_fluid_active() {
	return class_exists( 'FluidCheckout' );
}
function rzd_co_design_on() {
	$s = rzd_co_settings();
	return ! empty( $s['design'] ) && ! rzd_co_fluid_active();
}
function rzd_co_is_checkout_page() {
	return function_exists( 'is_checkout' ) && is_checkout() && ! is_order_received_page() && ! is_checkout_pay_page();
}
// Strony prawne: regulamin (WooCommerce) i polityka prywatności (WordPress) – opublikowane?
function rzd_co_legal_pages() {
	$t = function_exists( 'wc_terms_and_conditions_page_id' ) ? (int) wc_terms_and_conditions_page_id() : 0;
	$p = function_exists( 'wc_privacy_policy_page_id' ) ? (int) wc_privacy_policy_page_id() : (int) get_option( 'wp_page_for_privacy_policy' );
	return array(
		'terms'   => $t && 'publish' === get_post_status( $t ) ? $t : 0,
		'privacy' => $p && 'publish' === get_post_status( $p ) ? $p : 0,
	);
}

/* ============================================================
 * 2. ZGODY (zawsze, chyba że tryb „woocommerce”)
 * ============================================================ */
add_filter( 'woocommerce_get_terms_and_conditions_checkbox_text', function ( $text ) {
	$s = rzd_co_settings();
	if ( 'combined' === $s['consent'] ) {
		return rzd_co_policy_links( '' !== trim( $s['consent_text'] ) ? $s['consent_text'] : $text );
	}
	if ( 'separate' === $s['consent'] ) {
		return rzd_co_policy_links( 'Zapoznałem/am się i akceptuję [terms].' );
	}
	return $text;
}, 20 );

// Jedno pole z linkiem do polityki = osobny akapit o danych osobowych tylko powiela informację.
add_filter( 'woocommerce_get_privacy_policy_text', function ( $text, $type ) {
	$s = rzd_co_settings();
	if ( 'checkout' === $type && in_array( $s['consent'], array( 'combined', 'separate' ), true ) && function_exists( 'wc_terms_and_conditions_checkbox_enabled' ) && wc_terms_and_conditions_checkbox_enabled() ) {
		return '';
	}
	return $text;
}, 20, 2 );

// Linki w treści zgód w poprawnym przypadku („akceptuję regulamin oraz politykę prywatności”) –
// WooCommerce wstawia w [privacy_policy] mianownik („polityka prywatności”).
function rzd_co_policy_links( $text ) {
	$pages = rzd_co_legal_pages();
	if ( $pages['terms'] ) {
		$text = str_replace( '[terms]', '<a href="' . esc_url( get_permalink( $pages['terms'] ) ) . '" class="woocommerce-terms-and-conditions-link" target="_blank">regulamin</a>', $text );
	}
	if ( $pages['privacy'] ) {
		$text = str_replace( '[privacy_policy]', '<a href="' . esc_url( get_permalink( $pages['privacy'] ) ) . '" class="woocommerce-privacy-policy-link" target="_blank">politykę prywatności</a>', $text );
	}
	return $text;
}

// Dodatkowe pola (osobna polityka, pole operatora płatności) – zaraz pod polem regulaminu.
function rzd_co_extra_checkboxes() {
	$s   = rzd_co_settings();
	$out = array();
	if ( 'separate' === $s['consent'] && rzd_co_legal_pages()['privacy'] ) {
		$out['rzd_privacy'] = $s['privacy_text'];
	}
	if ( '' !== trim( (string) $s['extra_consent'] ) ) {
		$out['rzd_extra_consent'] = $s['extra_consent'];
	}
	return $out;
}
add_action( 'woocommerce_checkout_after_terms_and_conditions', function () {
	$boxes = rzd_co_extra_checkboxes();
	if ( ! $boxes ) {
		return;
	}
	echo '<div class="woocommerce-terms-and-conditions-wrapper rzd-co-consents">'; // ten sam wygląd co pole regulaminu
	foreach ( $boxes as $key => $text ) {
		$checked = ! empty( $_POST[ $key ] ); // phpcs:ignore -- ponowne wyświetlenie po błędzie
		echo '<p class="form-row validate-required rzd-co-consent">'
			. '<label class="woocommerce-form__label woocommerce-form__label-for-checkbox checkbox">'
			. '<input type="checkbox" class="woocommerce-form__input woocommerce-form__input-checkbox input-checkbox" name="' . esc_attr( $key ) . '" id="' . esc_attr( $key ) . '" value="1"' . checked( $checked, true, false ) . '> '
			. '<span>' . wp_kses_post( rzd_co_policy_links( $text ) ) . '</span>&nbsp;<abbr class="required" title="wymagane">*</abbr>'
			. '</label></p>';
	}
	echo '</div>';
} );
add_action( 'woocommerce_after_checkout_validation', function ( $data, $errors ) {
	foreach ( rzd_co_extra_checkboxes() as $key => $text ) {
		if ( empty( $_POST[ $key ] ) ) { // phpcs:ignore -- nonce kasy sprawdził WooCommerce
			$errors->add( 'validation', 'Zaznacz: ' . wp_strip_all_tags( rzd_co_policy_links( $text ) ) );
		}
	}
}, 10, 2 );

// Ślad akceptacji w zamówieniu – dowód przy sporze lub kontroli operatora płatności.
add_action( 'woocommerce_checkout_create_order', function ( $order ) {
	$pages = rzd_co_legal_pages();
	$terms = ! empty( $_POST['terms'] ); // phpcs:ignore
	$extra = array();
	foreach ( rzd_co_extra_checkboxes() as $key => $text ) {
		if ( ! empty( $_POST[ $key ] ) ) { // phpcs:ignore
			$extra[ $key ] = wp_strip_all_tags( rzd_co_policy_links( $text ) );
		}
	}
	if ( ! $terms && ! $extra ) {
		return;
	}
	$ver = function ( $id ) {
		return $id ? (string) get_post_field( 'post_modified', $id ) : '';
	};
	$order->update_meta_data( '_rzd_consents', array(
		'time'         => time(),
		'mode'         => rzd_co_settings()['consent'],
		'terms'        => $terms,
		'terms_page'   => $pages['terms'],
		'terms_ver'    => $ver( $pages['terms'] ),
		'privacy_page' => $pages['privacy'],
		'privacy_ver'  => $ver( $pages['privacy'] ),
		'extra'        => $extra,
	) );
} );

/* ============================================================
 * 3. PRZYCISK ZAMÓWIENIA
 * ============================================================ */
add_filter( 'woocommerce_order_button_text', function ( $text ) {
	$s = rzd_co_settings();
	if ( '' === trim( (string) $s['button_text'] ) ) {
		return $text;
	}
	$t = $s['button_text'];
	if ( ! empty( $s['button_total'] ) && function_exists( 'WC' ) && WC()->cart && ! WC()->cart->is_empty() ) {
		$t .= ' ' . html_entity_decode( wp_strip_all_tags( wc_price( WC()->cart->get_total( 'edit' ) ) ), ENT_QUOTES, 'UTF-8' );
	}
	return $t;
}, 20 );

/* ============================================================
 * 4. POLA (nowy wygląd)
 * ============================================================ */
add_filter( 'woocommerce_checkout_fields', function ( $fields ) {
	if ( ! rzd_co_design_on() ) {
		return $fields;
	}
	$s   = rzd_co_settings();
	$one = rzd_co_hide_country();
	$ord = rzd_co_field_order();
	foreach ( array( 'billing', 'shipping' ) as $g ) {
		if ( empty( $fields[ $g ] ) ) {
			continue;
		}
		foreach ( $ord as $k => $prio ) {
			if ( isset( $fields[ $g ][ $g . '_' . $k ] ) ) {
				$fields[ $g ][ $g . '_' . $k ]['priority'] = $prio;
			}
		}
		foreach ( array( 'phone' => 'form-row-wide', 'email' => 'form-row-wide', 'postcode' => 'form-row-first', 'city' => 'form-row-last' ) as $k => $cls ) {
			if ( isset( $fields[ $g ][ $g . '_' . $k ] ) ) {
				$c = array_diff( (array) ( isset( $fields[ $g ][ $g . '_' . $k ]['class'] ) ? $fields[ $g ][ $g . '_' . $k ]['class'] : array() ), array( 'form-row-wide', 'form-row-first', 'form-row-last' ) );
				$fields[ $g ][ $g . '_' . $k ]['class'] = array_merge( $c, array( $cls ) );
			}
		}
		if ( $one && isset( $fields[ $g ][ $g . '_country' ] ) ) {
			$fields[ $g ][ $g . '_country' ]['class'][] = 'rzd-hide'; // jeden kraj – pole zostaje (walidacja), niewidoczne
		}
		if ( isset( $fields[ $g ][ $g . '_company' ] ) ) {
			unset( $fields[ $g ][ $g . '_company' ] );
		}
	}
	if ( ! empty( $s['invoice'] ) && isset( $fields['billing'] ) ) {
		$fields['billing']['billing_rzd_invoice'] = array( 'type' => 'checkbox', 'label' => 'Potrzebuję faktury (firma)', 'required' => false, 'priority' => 90, 'class' => array( 'form-row-wide', 'rzd-inv-toggle' ) );
		$fields['billing']['billing_company']     = array( 'type' => 'text', 'label' => 'Nazwa firmy', 'required' => false, 'priority' => 91, 'class' => array( 'form-row-wide', 'rzd-inv' ), 'autocomplete' => 'organization' );
		$fields['billing']['billing_nip']         = array( 'type' => 'text', 'label' => 'NIP', 'required' => false, 'priority' => 92, 'class' => array( 'form-row-wide', 'rzd-inv' ), 'placeholder' => '10 cyfr', 'custom_attributes' => array( 'inputmode' => 'numeric' ) );
	}
	return $fields;
}, 50 );

// Kolejność pól. Ta sama dla formularza i dla ustawień kraju WooCommerce – skrypt adresu WooCommerce
// (address-i18n) porządkuje pola wg ustawień kraju, także telefon; bez tego wróciłaby kolejność domyślna.
function rzd_co_field_order() {
	return array( 'country' => 5, 'first_name' => 10, 'last_name' => 20, 'phone' => 30, 'email' => 40, 'address_1' => 50, 'address_2' => 60, 'postcode' => 70, 'city' => 80, 'state' => 85 );
}
// „Kraj” niewidoczny: sklep sprzedaje do jednego kraju albo dowozi tylko do miejscowości z listy (moduł 20).
function rzd_co_hide_country() {
	if ( function_exists( 'rzd_towns_enabled' ) && rzd_towns_enabled() ) {
		return true;
	}
	return function_exists( 'WC' ) && WC()->countries && 1 === count( (array) WC()->countries->get_allowed_countries() );
}
$rzd_co_locale = function ( $loc ) {
	if ( ! rzd_co_design_on() ) {
		return $loc;
	}
	foreach ( rzd_co_field_order() as $k => $prio ) {
		if ( 'email' === $k ) {
			continue;
		}
		if ( isset( $loc[ $k ] ) && is_array( $loc[ $k ] ) ) { // tylko istniejące pola – nie tworzymy nowych
			$loc[ $k ]['priority'] = $prio;
		}
	}
	return $loc;
};
add_filter( 'woocommerce_get_country_locale_default', $rzd_co_locale, 50 );
add_filter( 'woocommerce_get_country_locale_base', $rzd_co_locale, 50 );
add_filter( 'woocommerce_get_country_locale', function ( $all ) use ( $rzd_co_locale ) {
	if ( ! rzd_co_design_on() ) {
		return $all;
	}
	foreach ( $all as $cc => $loc ) {
		foreach ( rzd_co_field_order() as $k => $prio ) {
			if ( 'email' !== $k && isset( $loc[ $k ] ) && is_array( $loc[ $k ] ) && isset( $loc[ $k ]['priority'] ) ) {
				$all[ $cc ][ $k ]['priority'] = $prio;
			}
		}
	}
	return $all;
}, 50 );

if ( ! function_exists( 'rzd_co_nip_valid' ) ) {
	// NIP: 10 cyfr, suma kontrolna (wagi 6,5,7,2,3,4,5,6,7).
	function rzd_co_nip_valid( $nip ) {
		$n = preg_replace( '/\D/', '', (string) $nip );
		if ( 10 !== strlen( $n ) ) {
			return false;
		}
		$w   = array( 6, 5, 7, 2, 3, 4, 5, 6, 7 );
		$sum = 0;
		for ( $i = 0; $i < 9; $i++ ) {
			$sum += $w[ $i ] * (int) $n[ $i ];
		}
		return ( $sum % 11 ) === (int) $n[9];
	}
}
add_filter( 'woocommerce_checkout_posted_data', function ( $data ) {
	if ( ! rzd_co_design_on() || ! array_key_exists( 'billing_rzd_invoice', $data ) ) {
		return $data;
	}
	if ( empty( $data['billing_rzd_invoice'] ) ) {
		$data['billing_company'] = ''; // bez faktury – nie zapisujemy przypadkiem wpisanych danych firmy
		$data['billing_nip']     = '';
	} else {
		$data['billing_nip'] = preg_replace( '/\D/', '', (string) $data['billing_nip'] );
	}
	return $data;
}, 30 );
add_action( 'woocommerce_after_checkout_validation', function ( $data, $errors ) {
	if ( ! rzd_co_design_on() || empty( $data['billing_rzd_invoice'] ) ) {
		return;
	}
	if ( '' === trim( (string) ( isset( $data['billing_company'] ) ? $data['billing_company'] : '' ) ) ) {
		$errors->add( 'validation', 'Podaj nazwę firmy do faktury.' );
	}
	if ( ! rzd_co_nip_valid( isset( $data['billing_nip'] ) ? $data['billing_nip'] : '' ) ) {
		$errors->add( 'validation', 'Sprawdź NIP – powinien mieć 10 cyfr (np. 1234563218).' );
	}
}, 10, 2 );

// Uwagi do zamówienia ukryte całkiem.
add_filter( 'woocommerce_enable_order_notes_field', function ( $on ) {
	return ( rzd_co_design_on() && 'hidden' === rzd_co_settings()['notes'] ) ? false : $on;
}, 20 );

// NIP i zgody w panelu zamówienia.
add_action( 'woocommerce_admin_order_data_after_billing_address', function ( $order ) {
	$nip = $order->get_meta( '_billing_nip' );
	if ( $nip ) {
		echo '<p><strong>NIP:</strong> ' . esc_html( $nip ) . ' – <strong>prosi o fakturę</strong></p>';
	}
	$c = $order->get_meta( '_rzd_consents' );
	if ( is_array( $c ) ) {
		$parts = array();
		if ( ! empty( $c['terms'] ) ) {
			$parts[] = 'regulamin' . ( $c['terms_ver'] ? ' (wersja z ' . wp_date( 'j.m.Y', strtotime( $c['terms_ver'] ) ) . ')' : '' ) . ( 'combined' === $c['mode'] ? ' i polityka prywatności' . ( $c['privacy_ver'] ? ' (z ' . wp_date( 'j.m.Y', strtotime( $c['privacy_ver'] ) ) . ')' : '' ) : '' );
		}
		foreach ( (array) $c['extra'] as $t ) {
			$parts[] = $t;
		}
		echo '<p><strong>Zgody:</strong> ' . esc_html( implode( '; ', $parts ) ) . ' – zaakceptowane ' . esc_html( wp_date( 'j.m.Y H:i', (int) $c['time'] ) ) . '</p>';
	}
} );
add_filter( 'woocommerce_email_order_meta_fields', function ( $f, $sent_to_admin, $order ) {
	$nip = $order instanceof WC_Order ? $order->get_meta( '_billing_nip' ) : '';
	if ( $nip ) {
		$f['rzd_nip'] = array( 'label' => 'NIP (faktura)', 'value' => $nip );
	}
	return $f;
}, 10, 3 );

/* ============================================================
 * 5. WYGLĄD (CSS + skrypt) – tylko strona kasy
 * ============================================================ */
add_filter( 'body_class', function ( $c ) {
	if ( rzd_co_design_on() && rzd_co_is_checkout_page() ) {
		$c[] = 'rzd-co';
	}
	return $c;
} );
add_action( 'wp_enqueue_scripts', function () {
	if ( ! rzd_co_design_on() || ! rzd_co_is_checkout_page() ) {
		return;
	}
	wp_enqueue_style( 'rzd-kasa', RZD_PLUGIN_URL . 'assets/css/rzd-kasa.css', array(), rzd_asset_ver( 'assets/css/rzd-kasa.css' ) );
	$st  = function_exists( 'rzd_list_style_get' ) ? rzd_list_style_get() : array();
	$get = function ( $k, $d ) use ( $st ) {
		return isset( $st[ $k ] ) && '' !== (string) $st[ $k ] ? $st[ $k ] : $d;
	};
	$hex  = function ( $v, $d ) {
		$v = sanitize_hex_color( (string) $v );
		return $v ? $v : $d;
	};
	$font = preg_replace( '/[^A-Za-z0-9 \-]/', '', (string) $get( 'body_font', '' ) );
	$vars = ':root{'
		. '--rzd-co-accent:' . $hex( $get( 'button_border_color', '' ), '#c08a2e' ) . ';'
		. '--rzd-co-accent-text:' . $hex( $get( 'button_text_color', '' ), '#2b2110' ) . ';'
		. '--rzd-co-soft:' . $hex( $get( 'button_bg', '' ), '#faf3e3' ) . ';'
		. '--rzd-co-border:' . $hex( $get( 'box_border_color', '' ), '#d0d0d0' ) . ';'
		. '--rzd-co-radius:' . max( 4, min( 24, (int) $get( 'button_radius', 8 ) ) ) . 'px;'
		. ( $font ? '--rzd-co-font:"' . $font . '",sans-serif;' : '' )
		. '}';
	wp_add_inline_style( 'rzd-kasa', $vars );
	wp_enqueue_script( 'rzd-kasa', RZD_PLUGIN_URL . 'assets/js/rzd-kasa.js', array( 'jquery' ), rzd_asset_ver( 'assets/js/rzd-kasa.js' ), true );
	wp_add_inline_script( 'rzd-kasa', 'var rzdCo = ' . wp_json_encode( array( 'notes' => rzd_co_settings()['notes'] ) ) . ';', 'before' );
}, 30 );

/* ============================================================
 * 6. PANEL: Restauracja → Formularz zamówienia
 * ============================================================ */
add_action( 'admin_post_rzd_co_save', function () {
	if ( ! current_user_can( 'rzd_p_settings' ) ) {
		wp_die( 'Brak uprawnień.' );
	}
	check_admin_referer( 'rzd_co_save' );
	$p = wp_unslash( $_POST ); // phpcs:ignore -- pola czyszczone niżej
	$d = rzd_co_defaults();
	$s = array(
		'design'        => empty( $p['design'] ) ? 0 : 1,
		'invoice'       => empty( $p['invoice'] ) ? 0 : 1,
		'notes'         => isset( $p['notes'] ) && in_array( $p['notes'], array( 'collapsed', 'open', 'hidden' ), true ) ? $p['notes'] : 'collapsed',
		'consent'       => isset( $p['consent'] ) && in_array( $p['consent'], array( 'combined', 'separate', 'woocommerce' ), true ) ? $p['consent'] : 'combined',
		'consent_text'  => isset( $p['consent_text'] ) && '' !== trim( $p['consent_text'] ) ? sanitize_text_field( $p['consent_text'] ) : $d['consent_text'],
		'privacy_text'  => isset( $p['privacy_text'] ) && '' !== trim( $p['privacy_text'] ) ? sanitize_text_field( $p['privacy_text'] ) : $d['privacy_text'],
		'extra_consent' => isset( $p['extra_consent'] ) ? wp_kses( $p['extra_consent'], array( 'a' => array( 'href' => true, 'target' => true, 'rel' => true ) ) ) : '',
		'button_text'   => isset( $p['button_text'] ) ? sanitize_text_field( $p['button_text'] ) : $d['button_text'],
		'button_total'  => empty( $p['button_total'] ) ? 0 : 1,
	);
	update_option( 'rzd_checkout', $s, false );
	wp_safe_redirect( admin_url( 'admin.php?page=rzd-formularz&saved=1' ) );
	exit;
} );

function rzd_co_admin_page() {
	if ( ! current_user_can( 'rzd_p_settings' ) ) {
		return;
	}
	$s     = rzd_co_settings();
	$pages = rzd_co_legal_pages();
	$link  = function ( $id ) {
		return $id ? '<a href="' . esc_url( get_permalink( $id ) ) . '" target="_blank">' . esc_html( get_the_title( $id ) ) . '</a> ✅' : '<strong style="color:#b32d2e">nie ustawiona</strong>';
	};
	?>
	<div class="wrap">
		<h1>Formularz zamówienia</h1>
		<?php if ( isset( $_GET['saved'] ) ) : // phpcs:ignore ?><div class="notice notice-success is-dismissible"><p>Zapisano.</p></div><?php endif; ?>
		<p style="max-width:900px">Wygląd i zgody na stronie kasy (przed płatnością) – bez dodatkowych wtyczek. <a href="<?php echo esc_url( wc_get_checkout_url() ); ?>" target="_blank">Otwórz kasę</a> (z produktem w koszyku).</p>
		<?php if ( rzd_co_fluid_active() ) : ?>
			<div class="notice notice-warning inline"><p><strong>Działa Fluid Checkout</strong> – nowy wygląd z tej strony się nie włączy (dwa układy kasy naraz). Zgody i przycisk działają.</p></div>
		<?php endif; ?>
		<h2>Strony prawne</h2>
		<table class="widefat striped" style="max-width:900px"><tbody>
			<tr><td style="width:240px">Regulamin</td><td><?php echo $link( $pages['terms'] ); // phpcs:ignore ?> – ustawiasz w <a href="<?php echo esc_url( admin_url( 'admin.php?page=wc-settings&tab=advanced' ) ); ?>">WooCommerce → Ustawienia → Zaawansowane → Strona regulaminu</a>. Bez niej WooCommerce nie pokaże pola akceptacji (wymagane m.in. przez Przelewy24).</td></tr>
			<tr><td>Polityka prywatności</td><td><?php echo $link( $pages['privacy'] ); // phpcs:ignore ?> – ustawiasz w <a href="<?php echo esc_url( admin_url( 'options-privacy.php' ) ); ?>">Ustawienia → Prywatność</a> (strona musi być opublikowana).</td></tr>
		</tbody></table>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="rzd_co_save"><?php wp_nonce_field( 'rzd_co_save' ); ?>
			<h2>Zgody i przycisk (działają zawsze)</h2>
			<table class="form-table" role="presentation">
				<tr><th>Zgody</th><td>
					<label><input type="radio" name="consent" value="combined" <?php checked( $s['consent'], 'combined' ); ?>> jedno wymagane pole: regulamin + polityka prywatności (zalecane)</label><br>
					<label><input type="radio" name="consent" value="separate" <?php checked( $s['consent'], 'separate' ); ?>> dwa osobne wymagane pola</label><br>
					<label><input type="radio" name="consent" value="woocommerce" <?php checked( $s['consent'], 'woocommerce' ); ?>> bez zmian (ustawienia WooCommerce)</label>
				</td></tr>
				<tr><th><label for="rzd-co-ct">Treść pola (jedno pole)</label></th><td><input type="text" class="large-text" id="rzd-co-ct" name="consent_text" value="<?php echo esc_attr( $s['consent_text'] ); ?>"><p class="description"><code>[terms]</code> = link do regulaminu, <code>[privacy_policy]</code> = link do polityki prywatności. Pole nigdy nie jest zaznaczone z góry.</p></td></tr>
				<tr><th><label for="rzd-co-pt">Treść pola polityki (dwa pola)</label></th><td><input type="text" class="large-text" id="rzd-co-pt" name="privacy_text" value="<?php echo esc_attr( $s['privacy_text'] ); ?>"></td></tr>
				<tr><th><label for="rzd-co-ex">Dodatkowe wymagane pole</label></th><td><input type="text" class="large-text" id="rzd-co-ex" name="extra_consent" value="<?php echo esc_attr( $s['extra_consent'] ); ?>" placeholder="np. Akceptuję regulamin Przelewy24"><p class="description">Puste = brak. Jeśli operator płatności wymaga osobnej akceptacji swojego regulaminu – wpisz tu treść; link dodasz znacznikiem &lt;a href="adres z umowy"&gt;…&lt;/a&gt;.</p></td></tr>
				<tr><th><label for="rzd-co-bt">Przycisk zamówienia</label></th><td><input type="text" id="rzd-co-bt" name="button_text" value="<?php echo esc_attr( $s['button_text'] ); ?>"> <label><input type="checkbox" name="button_total" value="1" <?php checked( ! empty( $s['button_total'] ) ); ?>> z kwotą do zapłaty</label><p class="description">Prawo (art. 17 ustawy o prawach konsumenta) wymaga, by przycisk jednoznacznie mówił o obowiązku zapłaty – „Zamawiam i płacę” jest bezpieczne. Puste = tekst WooCommerce.</p></td></tr>
			</table>
			<h2>Nowy wygląd</h2>
			<table class="form-table" role="presentation">
				<tr><th>Nowy wygląd kasy</th><td><label><input type="checkbox" name="design" value="1" <?php checked( ! empty( $s['design'] ) ); ?>> włączony</label><p class="description">Sekcje jako karty, telefon przy danych kontaktowych, bez pola „Kraj” (gdy dowozimy tylko do miejscowości z listy albo sklep sprzedaje do jednego kraju), płatności jako kafelki, na komputerze podsumowanie obok formularza. Kolory i czcionka z „Wyglądu listy”. Wyłączenie = kasa jak dotąd.</p></td></tr>
				<tr><th>Faktura</th><td><label><input type="checkbox" name="invoice" value="1" <?php checked( ! empty( $s['invoice'] ) ); ?>> pole „Potrzebuję faktury (firma)” – nazwa firmy i NIP (sprawdzany)</label></td></tr>
				<tr><th>Uwagi do zamówienia</th><td>
					<label><input type="radio" name="notes" value="collapsed" <?php checked( $s['notes'], 'collapsed' ); ?>> zwinięte pod linkiem „+ Dodaj uwagi”</label><br>
					<label><input type="radio" name="notes" value="open" <?php checked( $s['notes'], 'open' ); ?>> widoczne</label><br>
					<label><input type="radio" name="notes" value="hidden" <?php checked( $s['notes'], 'hidden' ); ?>> bez uwag</label>
				</td></tr>
			</table>
			<?php submit_button( 'Zapisz' ); ?>
		</form>
	</div>
	<?php
}
