<?php
/**
 * MODUŁ 20: Dostawa wg miejscowości
 *
 * Powód: WooCommerce rozróżnia strefy wysyłki po kodzie pocztowym, a np.
 * Skórka (brak dostawy) i Piła (dostawa darmowa) mają ten sam kod.
 *
 *  - Matryca miejscowości (Panel restauracji → Miejscowości): nazwa,
 *    koszt dostawy, "darmowa od", minimalna wartość zamówienia (progi:
 *    „darmowa od” i minimum PRZED rabatem; brutto, bez dostawy), inne nazwy,
 *    dni dostawy (checkboxy) i godziny od–do (dotyczą godziny WYJAZDU).
 *    Miejscowość spoza listy = nie dowozimy.
 *  - Porównanie nazw bez wielkości liter, polskich znaków, myślników i
 *    nadmiarowych spacji: "pila", "PIŁA " → Piła.
 *  - Miejscowość wybiera się już w okienku terminu dostawy (moduł 06):
 *    kalendarz pokazuje tylko terminy pasujące do niej, a nazwa sama
 *    wpisuje się w kasie. W kasie sprawdzamy ponownie (klient mógł ją
 *    zmienić).
 *  - Metoda wysyłki "Dostawa wg miejscowości" (WooCommerce → Ustawienia →
 *    Wysyłka → strefa). Sprawdzanie miejscowości działa TYLKO dla niej –
 *    przyszły odbiór osobisty zadziała bez dopasowania.
 *  - W zamówieniu miasto zamieniane na poprawną nazwę z matrycy (+ meta
 *    _rzd_town), więc kuchnia i kurier widzą "Piła", a nie "pila".
 *  - Shortcode [koszty_dostawy] – tabelka dla klientów.
 * Pusta matryca = moduł nic nie robi (kalendarz działa jak przed 2.23.0).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 1. Dane i dopasowanie nazw
 * ============================================================ */
function rzd_towns() {
	$rows = get_option( 'rzd_towns', array() );
	return is_array( $rows ) ? $rows : array();
}

/**
 * Moduł działa, gdy lista miejscowości nie jest pusta ORAZ metoda „Dostawa
 * wg miejscowości” jest włączona w którejś strefie wysyłki. Po jej
 * wyłączeniu okienko terminu nie pyta o miejscowość, a w adresie można
 * wpisać dowolną wartość.
 */
function rzd_towns_enabled() {
	return (bool) rzd_towns() && rzd_town_method_active();
}

// Czy metoda rzd_town jest włączona w jakiejkolwiek strefie (jedno lekkie zapytanie na request).
function rzd_town_method_active() {
	static $on = null;
	if ( null === $on ) {
		global $wpdb;
		$on = (bool) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}woocommerce_shipping_zone_methods WHERE method_id = 'rzd_town' AND is_enabled = 1" );
	}
	return $on;
}

// "Piła-Zamość " → "pila zamosc"
function rzd_town_key( $s ) {
	$s = function_exists( 'mb_strtolower' ) ? mb_strtolower( (string) $s, 'UTF-8' ) : strtolower( (string) $s );
	$s = strtr( $s, array(
		'ą' => 'a', 'ć' => 'c', 'ę' => 'e', 'ł' => 'l', 'ń' => 'n', 'ó' => 'o', 'ś' => 's', 'ź' => 'z', 'ż' => 'z',
		'Ą' => 'a', 'Ć' => 'c', 'Ę' => 'e', 'Ł' => 'l', 'Ń' => 'n', 'Ó' => 'o', 'Ś' => 's', 'Ź' => 'z', 'Ż' => 'z',
	) );
	$s = preg_replace( '/[\s\-–—_.,]+/u', ' ', $s );
	return trim( $s );
}

// Wiersz matrycy dla wpisanej nazwy (nazwa albo "inne nazwy") – albo null.
function rzd_town_find( $name ) {
	$key = rzd_town_key( $name );
	if ( '' === $key ) {
		return null;
	}
	foreach ( rzd_towns() as $row ) {
		$names = array_merge( array( $row['name'] ), preg_split( '/[,;\n]+/', (string) $row['aliases'] ) );
		foreach ( $names as $n ) {
			if ( '' !== trim( $n ) && rzd_town_key( $n ) === $key ) {
				return $row;
			}
		}
	}
	return null;
}

// Ile punktów pojemności okna dostawy zajmuje zamówienie do tej miejscowości
// (np. Piła 1, Kaczory 3). Miejscowość spoza listy / stary wiersz = 1.
function rzd_town_points( $name_or_row ) {
	$row = is_array( $name_or_row ) ? $name_or_row : rzd_town_find( $name_or_row );
	if ( ! $row || ! isset( $row['points'] ) || '' === (string) $row['points'] ) {
		return 1;
	}
	return max( 1, (int) $row['points'] );
}

// Czy do tej miejscowości jedziemy w danym terminie (dzień tygodnia + godzina wyjazdu).
// Tryb okien: „od” zaokrąglane w górę do startu okna, „do” w dół do jego
// końca – tak samo jak zakres grupy w module 06.
function rzd_town_allows_slot( $row, $date, $time ) {
	if ( ! empty( $row['days'] ) ) {
		$dow = ( new DateTime( $date, wp_timezone() ) )->format( 'D' );
		if ( ! in_array( $dow, (array) $row['days'], true ) ) {
			return false;
		}
	}
	$end = $time;
	if ( function_exists( 'rzd_dc_windows_on' ) && rzd_dc_windows_on() ) {
		$w = rzd_dc_window_at( $date, $time );
		if ( ! $w ) {
			return false;
		}
		$end = $w['end'];
	}
	if ( ! empty( $row['from'] ) && $time < $row['from'] ) {
		return false;
	}
	if ( ! empty( $row['to'] ) && $end > $row['to'] ) {
		return false;
	}
	return true;
}

// Terminy z kalendarza (moduł 06) zawężone do miejscowości: [ 'Y-m-d' => [ 'HH:MM' ] ].
function rzd_town_filter_slots( $slots, $row ) {
	$out = array();
	foreach ( $slots as $date => $times ) {
		$ok = array_values( array_filter( $times, function ( $t ) use ( $row, $date ) {
			return rzd_town_allows_slot( $row, $date, $t );
		} ) );
		if ( $ok ) {
			$out[ $date ] = $ok;
		}
	}
	return $out;
}

// "Pon–Pt, 11:00–14:00" albo "codziennie, o każdej porze".
function rzd_town_schedule_label( $row ) {
	$days = function_exists( 'rzd_dc_compress_day_ranges' ) && ! empty( $row['days'] ) ? implode( ', ', rzd_dc_compress_day_ranges( $row['days'] ) ) : 'codziennie';
	if ( empty( $row['from'] ) && empty( $row['to'] ) ) {
		return $days;
	}
	return $days . ', wyjazdy ' . ( $row['from'] ? $row['from'] : '…' ) . '–' . ( $row['to'] ? $row['to'] : '…' );
}

// Wartość produktów PRZED rabatem, brutto, bez dostawy – do progu "darmowa od"
// i minimum zamówienia: kupon nie odbiera darmowej dostawy ani nie blokuje
// zamówienia. Ochrona przed zejściem poniżej minimum = „Minimalne wydatki” w kuponie.
function rzd_cart_value_before_discount() {
	if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
		return 0.0;
	}
	return (float) WC()->cart->get_subtotal() + (float) WC()->cart->get_subtotal_tax();
}

/**
 * Stan dostawy dla wiersza miejscowości i wartości koszyka – JEDNO miejsce liczenia progów
 * (metoda wysyłki, minimum w kasie i pasek dostawy – moduł 32). 2.41.0.
 * state: 'min' (poniżej minimum) | 'to_free' (do darmowej) | 'free' (darmowa: próg osiągnięty albo koszt 0) | 'paid' (płatna, bez progu darmowej).
 */
function rzd_town_status_for( $row, $value ) {
	$cost = '' === $row['cost'] ? 0.0 : (float) $row['cost'];
	$free = '' === $row['free_from'] ? null : (float) $row['free_from'];
	$min  = '' === $row['min_order'] ? null : (float) $row['min_order'];
	$out  = array(
		'town'      => $row['name'],
		'value'     => (float) $value,
		'cost'      => $cost,
		'free_from' => $free,
		'min'       => $min,
		'cost_now'  => ( null !== $free && $value >= $free ) ? 0.0 : $cost, // koszt dostawy przy tej wartości
		'missing'   => 0.0,
		'progress'  => 1.0,
	);
	if ( null !== $min && $value < $min ) {
		$out['state']    = 'min';
		$out['missing']  = round( $min - $value, 2 );
		$out['progress'] = $min > 0 ? max( 0, min( 1, $value / $min ) ) : 1;
	} elseif ( $cost <= 0 || ( null !== $free && $value >= $free ) ) {
		$out['state'] = 'free';
	} elseif ( null !== $free ) {
		$out['state']    = 'to_free';
		$out['missing']  = round( $free - $value, 2 );
		$out['progress'] = $free > 0 ? max( 0, min( 1, $value / $free ) ) : 1;
	} else {
		$out['state'] = 'paid';
	}
	return $out;
}

/**
 * Stan dostawy bieżącego koszyka (miejscowość z okienka terminu, a bez niej – z adresu klienta,
 * jak metoda wysyłki). null = dostawa wg miejscowości nie obowiązuje albo miejscowość nieznana.
 */
function rzd_town_delivery_status() {
	if ( ! rzd_town_check_applies() ) {
		return null;
	}
	$city = rzd_session_town();
	if ( '' === $city && WC()->customer ) {
		$city = (string) WC()->customer->get_shipping_city();
	}
	$row = '' !== $city ? rzd_town_find( $city ) : null;
	return $row ? rzd_town_status_for( $row, rzd_cart_value_before_discount() ) : null;
}

// Miejscowość wybrana w okienku terminu (sesja).
function rzd_session_town() {
	return ( function_exists( 'WC' ) && WC()->session ) ? (string) WC()->session->get( 'rzd_town' ) : '';
}

function rzd_price_txt( $v ) {
	return number_format_i18n( (float) $v, ( floor( (float) $v ) == (float) $v ) ? 0 : 2 ) . ' zł';
}

/* ============================================================
 * 2. Ustawienia: Panel restauracji → Miejscowości (moduł 34; do 2.43.x Restauracja → Miejscowości w kokpicie)
 * ============================================================ */

/**
 * ostrzeżenia o strefach wysyłki na stronie Miejscowości.
 * WooCommerce bierze PIERWSZĄ pasującą strefę (kolejność z listy stref), więc
 * strefa obejmująca Polskę ustawiona NAD strefą z „Dostawą wg miejscowości”
 * przejmuje klientów – kończy się to „Brak metod wysyłki” albo starą stawką.
 * Zwraca [ [ 'error'|'warning', tekst ], … ].
 */
function rzd_town_zone_warnings() {
	if ( ! class_exists( 'WC_Shipping_Zones' ) ) {
		return array();
	}
	$zones = WC_Shipping_Zones::get_zones(); // kolejność jak na liście stref (zone_order)
	$town  = null;
	$above = array();
	foreach ( $zones as $z ) {
		$has = false;
		foreach ( (array) $z['shipping_methods'] as $m ) {
			if ( isset( $m->id ) && 'rzd_town' === $m->id && 'yes' === $m->enabled ) {
				$has = true;
			}
		}
		if ( $has ) {
			$town = $z;
			break;
		}
		$above[] = $z;
	}
	if ( ! $town ) {
		return rzd_towns()
			? array( array( 'warning', 'Metoda „Dostawa wg miejscowości” nie jest włączona w żadnej strefie wysyłki – lista poniżej nie działa (klient może wpisać dowolne miasto, a koszt dostawy liczy inna metoda).' ) )
			: array();
	}
	$out = array();
	foreach ( $above as $z ) {
		$full    = false; // cała Polska (kraj, kontynent)
		$part    = false; // część Polski (województwo, kody pocztowe)
		$regions = false;
		foreach ( (array) $z['zone_locations'] as $loc ) {
			$loc  = (object) $loc;
			$type = isset( $loc->type ) ? $loc->type : '';
			$code = isset( $loc->code ) ? (string) $loc->code : '';
			if ( ( 'country' === $type && 'PL' === $code ) || ( 'continent' === $type && 'EU' === $code ) ) {
				$full = true;
			} elseif ( 'state' === $type && 0 === strpos( $code, 'PL:' ) ) {
				$part = true;
			}
			if ( in_array( $type, array( 'country', 'state', 'continent' ), true ) ) {
				$regions = true;
			}
		}
		// Strefa z samymi kodami pocztowymi (bez kraju) też łapie polskie adresy.
		if ( ! $regions && $z['zone_locations'] ) {
			$part = true;
		}
		if ( $full || $part ) {
			$out[] = array(
				'error',
				sprintf(
					'Strefa wysyłki „%1$s” jest na liście NAD strefą „%2$s” (tą z „Dostawą wg miejscowości”) i obejmuje %3$s. WooCommerce użyje dla tych klientów jej metod zamiast dostawy wg miejscowości. Przesuń ją pod „%2$s” albo usuń.',
					$z['zone_name'],
					$town['zone_name'],
					$full ? 'całą Polskę' : 'część Polski (województwa albo kody pocztowe)'
				),
			);
		}
	}
	return $out;
}

// „Darmowa od” niższa niż minimum – próg darmowej dostawy nigdy nie zadziała osobno (pasek „do darmowej” bez sensu). 2.41.0
function rzd_town_threshold_warnings() {
	$out = array();
	foreach ( rzd_towns() as $r ) {
		if ( isset( $r['free_from'], $r['min_order'] ) && '' !== (string) $r['free_from'] && '' !== (string) $r['min_order'] && (float) $r['free_from'] < (float) $r['min_order'] ) {
			$out[] = sprintf( '%1$s: „Darmowa od” (%2$s) jest niższa niż minimum zamówienia (%3$s) – każde przyjęte zamówienie ma darmową dostawę. Jeśli tak ma być, wyczyść „Darmowa od”; jeśli nie – podnieś próg.', $r['name'], rzd_price_txt( $r['free_from'] ), rzd_price_txt( $r['min_order'] ) );
		}
	}
	return $out;
}

// Miejscowości z większą liczbą punktów niż największe okno dostawy – nigdy nie dostaną terminu.
function rzd_town_points_warnings() {
	if ( ! function_exists( 'rzd_dc_windows_on' ) || ! rzd_dc_windows_on() ) {
		return array();
	}
	$max_cap = 0;
	foreach ( rzd_dc_win_defs() as $def ) {
		$max_cap = max( $max_cap, (int) $def['cap'] );
	}
	$too_big = array();
	foreach ( rzd_towns() as $r ) {
		if ( rzd_town_points( $r ) > $max_cap ) {
			$too_big[] = $r['name'];
		}
	}
	return $too_big ? array( 'Te miejscowości mają więcej punktów niż największe okno (' . $max_cap . ' pkt), więc nigdy nie dostaną terminu: ' . implode( ', ', $too_big ) . '.' ) : array();
}

/**
 * Czyszczenie listy miejscowości z formularza (Panel restauracji). Pusta albo zdublowana nazwa
 * jest pomijana; godziny „od” > „do” – zamieniane; kwoty ≥ 0 (puste = brak progu), punkty 1–99.
 * $in – już po wp_unslash().
 */
function rzd_towns_clean( $in ) {
	$clean = array();
	$seen  = array();
	$money = function ( $v ) {
		$v = str_replace( ',', '.', trim( (string) $v ) );
		return ( '' === $v || ! is_numeric( $v ) ) ? '' : (string) max( 0, round( (float) $v, 2 ) );
	};
	$time = function ( $v ) {
		$v = trim( (string) $v );
		return preg_match( '/^([01]\d|2[0-3]):[0-5]\d$/', $v ) ? $v : '';
	};
	foreach ( (array) $in as $r ) {
		$r    = is_array( $r ) ? $r : array();
		$name = sanitize_text_field( isset( $r['name'] ) ? $r['name'] : '' );
		$key  = rzd_town_key( $name );
		if ( '' === $key || isset( $seen[ $key ] ) ) {
			continue; // pusta albo zdublowana nazwa
		}
		$seen[ $key ] = true;
		$from         = $time( isset( $r['from'] ) ? $r['from'] : '' );
		$to           = $time( isset( $r['to'] ) ? $r['to'] : '' );
		if ( $from && $to && $to < $from ) {
			list( $from, $to ) = array( $to, $from );
		}
		$aliases = isset( $r['aliases'] ) ? $r['aliases'] : '';
		if ( is_array( $aliases ) ) {
			$aliases = implode( ', ', $aliases );
		}
		$clean[] = array(
			'name'      => $name,
			'cost'      => $money( isset( $r['cost'] ) ? $r['cost'] : '' ),
			'free_from' => $money( isset( $r['free_from'] ) ? $r['free_from'] : '' ),
			'min_order' => $money( isset( $r['min_order'] ) ? $r['min_order'] : '' ),
			'aliases'   => sanitize_text_field( $aliases ),
			'days'      => array_values( array_intersect( (array) ( isset( $r['days'] ) ? $r['days'] : array() ), array_keys( rzd_dc_days() ) ) ),
			'from'      => $from,
			'to'        => $to,
			'points'    => max( 1, min( 99, absint( isset( $r['points'] ) ? $r['points'] : 1 ) ) ),
		);
	}
	return $clean;
}

function rzd_towns_save( $in ) {
	$clean = rzd_towns_clean( $in );
	update_option( 'rzd_towns', $clean, true );
	if ( function_exists( 'rzd_dc_clear_slots_cache' ) ) {
		rzd_dc_clear_slots_cache(); // terminy zależą od miejscowości (dni, godziny, punkty)
	}
	return $clean;
}

/* ============================================================
 * 3. Metoda wysyłki "Dostawa wg miejscowości"
 * ============================================================ */
add_action( 'woocommerce_shipping_init', function () {
	if ( class_exists( 'RZD_Shipping_Town' ) || ! class_exists( 'WC_Shipping_Method' ) ) {
		return;
	}
	class RZD_Shipping_Town extends WC_Shipping_Method {
		public function __construct( $instance_id = 0 ) {
			$this->id                 = 'rzd_town';
			$this->instance_id        = absint( $instance_id );
			$this->method_title       = 'Dostawa wg miejscowości';
			$this->method_description = 'Koszt z listy w Panelu restauracji → Miejscowości. Miejscowość spoza listy = brak dostawy.';
			$this->supports           = array( 'shipping-zones', 'instance-settings', 'instance-settings-modal' );
			$this->instance_form_fields = array(
				'title'      => array(
					'title'   => 'Nazwa widoczna dla klienta',
					'type'    => 'text',
					'default' => 'Dostawa',
				),
				'tax_status' => array(
					'title'   => 'Status podatku',
					'type'    => 'select',
					'default' => 'none',
					'options' => array( 'taxable' => 'Podlega opodatkowaniu', 'none' => 'Brak' ),
				),
			);
			$this->init_settings();
			$this->title      = $this->get_option( 'title', 'Dostawa' );
			$this->tax_status = $this->get_option( 'tax_status', 'none' );
			add_action( 'woocommerce_update_options_shipping_' . $this->id, array( $this, 'process_admin_options' ) );
		}

		public function calculate_shipping( $package = array() ) {
			// Miejscowość z okienka terminu ma pierwszeństwo przed adresem z kartoteki.
			$city = rzd_session_town();
			if ( '' === $city ) {
				$city = isset( $package['destination']['city'] ) ? $package['destination']['city'] : '';
			}
			$row  = rzd_town_find( $city );
			if ( ! $row ) {
				return; // spoza listy – brak metody; komunikat daje walidacja kasy
			}
			$cost = rzd_town_status_for( $row, rzd_cart_value_before_discount() )['cost_now']; // wspólne liczenie progów (2.41.0)
			$this->add_rate( array(
				'id'    => $this->get_rate_id(),
				'label' => $this->title . ' – ' . $row['name'] . ( $cost > 0 ? '' : ' (gratis)' ),
				'cost'  => $cost,
			) );
		}
	}
} );

add_filter( 'woocommerce_shipping_methods', function ( $methods ) {
	$methods['rzd_town'] = 'RZD_Shipping_Town';
	return $methods;
} );

/* ============================================================
 * 4. Kasa: sprawdzenie miejscowości, minimum i terminu
 * ============================================================ */
// Czy obowiązuje dostawa wg miejscowości: moduł włączony, koszyk wymaga
// wysyłki, a klient nie wybrał innej metody (np. przyszłego odbioru osobistego).
function rzd_town_check_applies() {
	if ( ! rzd_towns_enabled() || ! function_exists( 'WC' ) || ! WC()->cart || ! WC()->cart->needs_shipping() ) {
		return false;
	}
	$chosen = WC()->session ? (array) WC()->session->get( 'chosen_shipping_methods' ) : array();
	foreach ( $chosen as $m ) {
		if ( $m && 0 !== strpos( (string) $m, 'rzd_town' ) ) {
			return false; // wybrana inna metoda
		}
	}
	return true;
}

/**
 * Miejscowość w kasie = miejscowość wybrana w okienku terminu.
 * Wartość z kartoteki klienta jest ignorowana: pole wypełnia się miejscowością
 * z sesji i jest tylko do odczytu, a przy wysłaniu formularza serwer i tak
 * wstawia miejscowość z sesji (pole readonly da się obejść w przeglądarce).
 * Bez miejscowości w sesji pole jest listą rozwijaną z miejscowościami z matrycy
 * (nie pole z podpowiedziami – datalist po wyborze pokazywał tylko wybrane
 * miasto). Lista działa też w Moje konto → Adresy.
 */
function rzd_town_lock_city() {
	return rzd_towns_enabled() && '' !== rzd_session_town();
}

/**
 * Miasto zapisane w koncie zalogowanego klienta (adres dostawy, a gdy pusty –
 * rozliczeniowy). Czytane z bazy, NIE z WC()->customer (to jest sesja, którą
 * okienko terminu nadpisuje miejscowością). '' dla gościa.
 */
function rzd_account_town() {
	static $city = null;
	if ( null === $city ) {
		$city = '';
		if ( is_user_logged_in() ) {
			$c    = new WC_Customer( get_current_user_id() );
			$city = (string) ( $c->get_shipping_city() ? $c->get_shipping_city() : $c->get_billing_city() );
		}
	}
	return $city;
}

/**
 * Kasa: miejscowość z okienka terminu ≠ miasto z konta → ostrzeżenie
 * nad adresem, bo ulica i numer podstawiają się z konta (np. „Gładyszewo,
 * ul. [ulica z Piły]”). Tylko informacja, nic nie blokuje. Raz na stronę.
 */
function rzd_town_mismatch_notice() {
	static $done = false;
	if ( $done || ! rzd_town_lock_city() ) {
		return;
	}
	$acc  = rzd_account_town();
	$town = rzd_session_town();
	if ( '' === $acc || rzd_town_key( $acc ) === rzd_town_key( $town ) ) {
		return;
	}
	$acc_row = rzd_town_find( $acc ); // „Piła” w koncie = „Piła - miasto” przez „inne nazwy”
	if ( $acc_row && rzd_town_key( $acc_row['name'] ) === rzd_town_key( $town ) ) {
		return;
	}
	$done = true;
	echo '<div class="woocommerce-info rzd-town-mismatch">Dostawa do: <strong>' . esc_html( $town ) . '</strong>. Adres zapisany w Twoim koncie jest w: <strong>' . esc_html( $acc ) . '</strong>. Sprawdź ulicę i numer domu – kurier pojedzie do miejscowości ' . esc_html( $town ) . '.</div>';
}
add_action( 'woocommerce_before_checkout_shipping_form', 'rzd_town_mismatch_notice', 5 );
add_action( 'woocommerce_before_checkout_billing_form', 'rzd_town_mismatch_notice', 5 );

add_filter( 'woocommerce_checkout_get_value', function ( $value, $input ) {
	if ( ! in_array( $input, array( 'billing_city', 'shipping_city' ), true ) || ! rzd_towns_enabled() ) {
		return $value;
	}
	if ( rzd_town_lock_city() ) {
		return rzd_session_town();
	}
	// Lista rozwijana: zapisane w kartotece „pila” zaznacza „Piła” z matrycy.
	$row = rzd_town_find( (string) $value );
	return $row ? $row['name'] : $value;
}, 20, 2 );

/**
 * Pole miasta jako lista rozwijana (kasa + Moje konto → Adresy). Opcje = nazwy
 * z matrycy; wartość spoza listy (stara kartoteka) zostawia „— wybierz —”.
 */
function rzd_town_select_options() {
	$opts = array( '' => '— wybierz miejscowość z listy —' );
	foreach ( rzd_towns() as $row ) {
		$opts[ $row['name'] ] = $row['name'];
	}
	return $opts;
}

foreach ( array( 'billing', 'shipping' ) as $rzd_addr_type ) {
	add_filter( 'woocommerce_' . $rzd_addr_type . '_fields', function ( $fields ) use ( $rzd_addr_type ) {
		$key = $rzd_addr_type . '_city';
		if ( ! isset( $fields[ $key ] ) || ! rzd_towns_enabled() ) {
			return $fields;
		}
		$fields[ $key ]['type']    = 'select';
		$fields[ $key ]['options'] = rzd_town_select_options();
		return $fields;
	}, 30 );
}
unset( $rzd_addr_type );

// Moje konto → Adresy: zapisane „pila” zaznacza na liście „Piła” z matrycy.
add_filter( 'woocommerce_my_account_edit_address_field_value', function ( $value, $key ) {
	if ( in_array( $key, array( 'billing_city', 'shipping_city' ), true ) && rzd_towns_enabled() ) {
		$row = rzd_town_find( (string) $value );
		if ( $row ) {
			return $row['name'];
		}
	}
	return $value;
}, 20, 2 );

add_filter( 'woocommerce_checkout_fields', function ( $fields ) {
	if ( ! rzd_towns_enabled() ) {
		return $fields;
	}
	$lock = rzd_town_lock_city();
	foreach ( array( 'billing', 'shipping' ) as $g ) {
		if ( ! isset( $fields[ $g ][ $g . '_city' ] ) ) {
			continue;
		}
		$f = &$fields[ $g ][ $g . '_city' ];
		if ( $lock ) {
			// Miasto z okienka terminu: zwykłe pole tylko do odczytu zamiast listy.
			$f['type']                          = 'text';
			unset( $f['options'] );
			$f['custom_attributes']             = isset( $f['custom_attributes'] ) ? (array) $f['custom_attributes'] : array();
			$f['custom_attributes']['readonly'] = 'readonly';
			$f['default']                       = rzd_session_town();
			$f['description']                   = 'Miejscowość z terminu dostawy – zmienisz ją przyciskiem „Zmień termin”.';
		} else {
			$f['type']    = 'select';
			$f['options'] = rzd_town_select_options();
		}
		unset( $f );
	}
	return $fields;
}, 30 );

add_filter( 'woocommerce_checkout_posted_data', function ( $data ) {
	if ( rzd_town_check_applies() && rzd_town_lock_city() ) {
		$town = rzd_session_town();
		foreach ( array( 'billing_city', 'shipping_city' ) as $k ) {
			if ( array_key_exists( $k, $data ) ) {
				$data[ $k ] = $town;
			}
		}
	}
	return $data;
}, 20 );

// Moje konto → Adresy: tylko miejscowość z listy, zapis pod poprawną nazwą („pila” → „Piła”).
foreach ( array( 'billing_city', 'shipping_city' ) as $rzd_city_key ) {
	add_filter( 'woocommerce_process_myaccount_field_' . $rzd_city_key, function ( $value ) {
		if ( ! rzd_towns_enabled() ) {
			return $value;
		}
		if ( '' === trim( (string) $value ) ) {
			return $value; // puste = komunikat „wymagane” z WooCommerce
		}
		$row = rzd_town_find( $value );
		if ( ! $row ) {
			wc_add_notice( 'Nie dowozimy do miejscowości „' . esc_html( $value ) . '”. Wybierz miejscowość z listy.', 'error' );
			return $value;
		}
		return $row['name'];
	} );
}
unset( $rzd_city_key );

add_action( 'woocommerce_after_checkout_validation', function ( $fields, $errors ) {
	if ( ! rzd_town_check_applies() ) {
		return;
	}
	$use_shipping = ! empty( $fields['ship_to_different_address'] );
	$city         = $use_shipping ? ( isset( $fields['shipping_city'] ) ? $fields['shipping_city'] : '' ) : ( isset( $fields['billing_city'] ) ? $fields['billing_city'] : '' );
	$row          = rzd_town_find( $city );
	if ( ! $row ) {
		$errors->add( 'validation', 'Sprawdź nazwę miejscowości – nie ma jej na liście miejscowości, do których dowozimy. Poprawna nazwa gwarantuje bezproblemową dostawę.' );
		return;
	}
	$st = rzd_town_status_for( $row, rzd_cart_value_before_discount() ); // minimum przed rabatem
	if ( 'min' === $st['state'] ) {
		$errors->add( 'validation', sprintf( 'Minimalne zamówienie z dostawą do miejscowości %1$s to %2$s (brakuje %3$s).', $row['name'], rzd_price_txt( $row['min_order'] ), rzd_price_txt( $st['missing'] ) ) );
	}
	$slot = function_exists( 'rzd_dc_get_slot' ) ? rzd_dc_get_slot() : null;
	if ( $slot && ! rzd_town_allows_slot( $row, $slot['date'], $slot['time'] ) ) {
		$errors->add( 'validation', sprintf( 'Do miejscowości %1$s dowozimy: %2$s. Zmień termin dostawy (przycisk „Zmień termin” na górze).', $row['name'], rzd_town_schedule_label( $row ) ) );
	}
}, 20, 2 );

// W zamówieniu poprawna nazwa z matrycy ("pila" → "Piła") + meta dla kuchni/raportów.
add_action( 'woocommerce_checkout_create_order', function ( $order ) {
	if ( ! rzd_towns_enabled() ) {
		return;
	}
	$row = null;
	if ( $order->get_shipping_city() ) {
		$row = rzd_town_find( $order->get_shipping_city() );
		if ( $row ) {
			$order->set_shipping_city( $row['name'] );
		}
	}
	$brow = rzd_town_find( $order->get_billing_city() );
	if ( $brow ) {
		$order->set_billing_city( $brow['name'] );
		$row = $row ? $row : $brow;
	}
	if ( $row ) {
		$order->update_meta_data( '_rzd_town', $row['name'] );
	}
	// Punkty pojemności okna – zamrożone w zamówieniu, żeby późniejsza
	// zmiana matrycy nie przeliczała już przyjętych kursów. Inna metoda niż
	// dostawa wg miejscowości (np. odbiór) nie zajmuje miejsca w kursie.
	if ( ! rzd_town_check_applies() ) {
		$order->update_meta_data( '_rzd_points', 0 );
	} elseif ( $row ) {
		$order->update_meta_data( '_rzd_points', rzd_town_points( $row ) );
	}
}, 20 );

// Usunięte podpowiedzi <datalist> w kasie – pole miasta jest listą rozwijaną.

/* ============================================================
 * 5. Shortcode [koszty_dostawy]
 * ============================================================ */
add_shortcode( 'koszty_dostawy', function () {
	$rows = rzd_towns();
	if ( ! $rows ) {
		return '';
	}
	usort( $rows, function ( $a, $b ) { return strcoll( $a['name'], $b['name'] ); } );
	$has_free = false;
	$has_min  = false;
	$has_when = false;
	foreach ( $rows as $r ) {
		$has_free = $has_free || '' !== $r['free_from'];
		$has_min  = $has_min || '' !== $r['min_order'];
		$has_when = $has_when || ! empty( $r['days'] ) || ! empty( $r['from'] ) || ! empty( $r['to'] );
	}
	ob_start();
	?>
	<div class="rzd-koszty-dostawy" style="overflow-x:auto;">
		<table style="width:100%;border-collapse:collapse;">
			<thead><tr>
				<th style="text-align:left;padding:6px 8px;border-bottom:2px solid #222;">Miejscowość</th>
				<th style="text-align:left;padding:6px 8px;border-bottom:2px solid #222;">Koszt dostawy</th>
				<?php if ( $has_free ) : ?><th style="text-align:left;padding:6px 8px;border-bottom:2px solid #222;">Darmowa od</th><?php endif; ?>
				<?php if ( $has_min ) : ?><th style="text-align:left;padding:6px 8px;border-bottom:2px solid #222;">Min. zamówienie</th><?php endif; ?>
				<?php if ( $has_when ) : ?><th style="text-align:left;padding:6px 8px;border-bottom:2px solid #222;">Kiedy dowozimy</th><?php endif; ?>
			</tr></thead>
			<tbody>
			<?php foreach ( $rows as $r ) : ?>
				<?php $cost = '' === $r['cost'] ? 0 : (float) $r['cost']; ?>
				<tr>
					<td style="padding:6px 8px;border-bottom:1px solid #ddd;"><?php echo esc_html( $r['name'] ); ?></td>
					<td style="padding:6px 8px;border-bottom:1px solid #ddd;"><?php echo esc_html( $cost > 0 ? rzd_price_txt( $cost ) : 'gratis' ); ?></td>
					<?php if ( $has_free ) : ?><td style="padding:6px 8px;border-bottom:1px solid #ddd;"><?php echo esc_html( '' !== $r['free_from'] && $cost > 0 ? rzd_price_txt( $r['free_from'] ) : '–' ); ?></td><?php endif; ?>
					<?php if ( $has_min ) : ?><td style="padding:6px 8px;border-bottom:1px solid #ddd;"><?php echo esc_html( '' !== $r['min_order'] ? rzd_price_txt( $r['min_order'] ) : '–' ); ?></td><?php endif; ?>
					<?php if ( $has_when ) : ?><td style="padding:6px 8px;border-bottom:1px solid #ddd;"><?php echo esc_html( ucfirst( rzd_town_schedule_label( $r ) ) ); ?></td><?php endif; ?>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<p style="font-size:13px;color:#666;margin-top:8px;">Nie ma Twojej miejscowości na liście? Niestety tam jeszcze nie dowozimy.</p>
	</div>
	<?php
	return ob_get_clean();
} );
