<?php
/**
 * Moduł 36-odbior – koszyk i kasa: metoda wysyłki „Odbiór osobisty” (bez strefy w WooCommerce – dokładana
 * do stawek, gdy klient wybrał odbiór; wtedy jedyna), kasa bez adresu, minimum, rabat (opłata ujemna),
 * płatność przy odbiorze, meta zamówienia, mail „Gotowe do odbioru” po „Spakowane”.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ---------- metoda wysyłki ---------- */
// Tryb w paczce – inny tryb = inny skrót paczki, więc WooCommerce przelicza stawki po przełączeniu.
add_filter( 'woocommerce_cart_shipping_packages', function ( $packages ) {
	if ( rzd_pickup_on() ) {
		foreach ( $packages as &$p ) {
			$p['rzd_mode'] = rzd_pickup_mode() ? 'pickup' : 'delivery';
		}
		unset( $p );
	}
	return $packages;
}, 20 );

add_filter( 'woocommerce_package_rates', function ( $rates, $package ) {
	if ( ! rzd_pickup_on() ) {
		return $rates;
	}
	if ( ! rzd_pickup_mode() ) {
		unset( $rates['rzd_pickup'] );
		return $rates;
	}
	$rate = new WC_Shipping_Rate( 'rzd_pickup', 'Odbiór osobisty', 0, array(), 'rzd_pickup', 0 );
	return array( 'rzd_pickup' => $rate );
}, 100, 2 );

// Kasa: przy odbiorze nie ma adresu dostawy.
add_filter( 'woocommerce_cart_needs_shipping_address', function ( $needs ) {
	return rzd_pickup_mode() ? false : $needs;
}, 20 );

/* ---------- pola kasy ---------- */
add_filter( 'woocommerce_checkout_fields', function ( $fields ) {
	if ( ! rzd_pickup_mode() ) {
		return $fields;
	}
	foreach ( array( 'billing_address_1', 'billing_address_2', 'billing_city', 'billing_postcode', 'billing_state' ) as $k ) {
		if ( isset( $fields['billing'][ $k ] ) ) {
			$fields['billing'][ $k ]['required'] = false;
			$fields['billing'][ $k ]['validate'] = array(); // puste PL: wc_format_postcode('') daje „-” i błąd „nieprawidłowy kod”
			$fields['billing'][ $k ]['class']    = array_merge( isset( $fields['billing'][ $k ]['class'] ) ? (array) $fields['billing'][ $k ]['class'] : array(), array( 'rzd-pk-hide' ) );
		}
	}
	return $fields;
}, 40 );

// Ukryte pola adresu nie idą do zamówienia (stare dane z konta / sesji nie mylą Kuchni) i nie są sprawdzane.
add_filter( 'woocommerce_checkout_posted_data', function ( $data ) {
	if ( rzd_pickup_mode() ) {
		foreach ( array( 'billing_address_1', 'billing_address_2', 'billing_city', 'billing_postcode', 'billing_state' ) as $k ) {
			if ( array_key_exists( $k, $data ) ) {
				$data[ $k ] = '';
			}
		}
		$data['ship_to_different_address'] = 0;
	}
	return $data;
}, 50 );

// Ten sam wymóg w danych kraju (WooCommerce sprawdza „wymagane” też z ustawień lokalnych).
foreach ( array( 'woocommerce_get_country_locale_default', 'woocommerce_get_country_locale_base' ) as $rzd_pk_hook ) {
	add_filter( $rzd_pk_hook, function ( $locale ) {
		if ( rzd_pickup_mode() ) {
			foreach ( array( 'address_1', 'address_2', 'city', 'postcode', 'state' ) as $k ) {
				$locale[ $k ]['required'] = false;
			}
		}
		return $locale;
	}, 70 );
}
unset( $rzd_pk_hook );
add_filter( 'woocommerce_get_country_locale', function ( $all ) {
	if ( rzd_pickup_mode() ) {
		foreach ( $all as &$loc ) {
			foreach ( array( 'address_1', 'address_2', 'city', 'postcode', 'state' ) as $k ) {
				if ( isset( $loc[ $k ] ) ) {
					$loc[ $k ]['required'] = false;
				}
			}
		}
		unset( $loc );
	}
	return $all;
}, 70 );

// Informacja nad danymi klienta + ukrycie pól adresu.
add_action( 'woocommerce_before_checkout_billing_form', function () {
	if ( ! rzd_pickup_mode() ) {
		return;
	}
	echo '<div class="woocommerce-info rzd-pk-info"><div>' . rzd_pickup_info_html( rzd_dc_get_slot() ) . '</div></div>'; // wewnętrzny div – ramka WooCommerce bywa flexem (zjada spacje) // phpcs:ignore -- escapowane w funkcji
}, 4 );

add_action( 'wp_head', function () {
	if ( function_exists( 'is_checkout' ) && is_checkout() && rzd_pickup_mode() ) {
		echo '<style id="rzd-pk-css">.rzd-pk-hide{display:none!important}.rzd-pk-info strong{white-space:nowrap}</style>' . "\n";
	}
} );

/** Ramka „Odbiór osobisty: kiedy, gdzie” (kasa, mail, zamówienie). */
function rzd_pickup_info_html( $slot, $with_pay = '' ) {
	$s = rzd_pickup_settings();
	$h = '<strong>Odbiór osobisty:</strong> ' . esc_html( $slot ? rzd_pickup_slot_label( $slot ) : '' );
	if ( '' !== trim( $s['address'] ) ) {
		$h .= '<br><strong>Gdzie:</strong> ' . esc_html( $s['address'] );
	}
	if ( '' !== trim( $s['note'] ) ) {
		$h .= '<br>' . nl2br( esc_html( $s['note'] ) );
	}
	if ( '' !== $with_pay ) {
		$h .= '<br><strong>' . esc_html( $with_pay ) . '</strong>';
	}
	return $h;
}

/* ---------- walidacja: minimum ---------- */
add_action( 'woocommerce_after_checkout_validation', function ( $fields, $errors ) {
	if ( ! rzd_pickup_mode() ) {
		return;
	}
	$min = (float) rzd_pickup_settings()['min'];
	$val = function_exists( 'rzd_cart_value_before_discount' ) ? rzd_cart_value_before_discount() : (float) WC()->cart->get_subtotal();
	if ( $min > 0 && $val < $min ) {
		$errors->add( 'validation', sprintf( 'Minimalne zamówienie z odbiorem osobistym to %1$s (brakuje %2$s).', rzd_price_txt( $min ), rzd_price_txt( $min - $val ) ) );
	}
	$slot = rzd_dc_get_slot();
	if ( $slot && ! in_array( $slot['time'], rzd_pickup_times_for_date( $slot['date'] ), true ) ) {
		$errors->add( 'validation', 'Wybrana godzina odbioru (' . rzd_pickup_slot_label( $slot ) . ') nie jest już dostępna. Wybierz inną (przycisk „Zmień termin” na górze).' );
	}
}, 22, 2 );

/* ---------- rabat ---------- */
add_action( 'woocommerce_cart_calculate_fees', function ( $cart ) {
	if ( ! rzd_pickup_mode() || ( is_admin() && ! wp_doing_ajax() ) ) {
		return;
	}
	$val = function_exists( 'rzd_cart_value_before_discount' ) ? rzd_cart_value_before_discount() : (float) $cart->get_subtotal();
	$amt = rzd_pickup_discount_amount( $val );
	if ( $amt > 0 ) {
		$s = rzd_pickup_settings();
		$cart->add_fee( 'Rabat za odbiór osobisty' . ( 'pct' === $s['disc_type'] ? ' (−' . str_replace( '.', ',', (string) (float) $s['disc_val'] ) . '%)' : '' ), -1 * $amt, false );
	}
}, 30 );

/* ---------- płatność przy odbiorze ---------- */
add_filter( 'woocommerce_available_payment_gateways', function ( $gws ) {
	if ( is_admin() && ! wp_doing_ajax() ) {
		return $gws;
	}
	if ( ! rzd_pickup_mode() ) {
		return $gws;
	}
	if ( ! rzd_pickup_pay_on_site_allowed() ) {
		unset( $gws['cod'] );
		return $gws;
	}
	if ( ! isset( $gws['cod'] ) ) { // „za pobraniem” ograniczone w WooCommerce do metod dostawy – przy odbiorze też je dajemy
		$all = WC()->payment_gateways() ? WC()->payment_gateways()->payment_gateways() : array();
		if ( isset( $all['cod'] ) && 'yes' === $all['cod']->enabled ) {
			$gws['cod'] = $all['cod'];
		}
	}
	if ( isset( $gws['cod'] ) ) {
		$gws['cod']->title       = 'Płatność przy odbiorze (gotówka lub karta)';
		$gws['cod']->description = 'Zapłacisz w lokalu przy odbiorze zamówienia.';
	}
	return $gws;
}, 30 );

/* ---------- zamówienie ---------- */
add_action( 'woocommerce_checkout_create_order', function ( $order ) {
	if ( ! rzd_pickup_mode() ) {
		return;
	}
	$order->update_meta_data( '_rzd_pickup', '1' );
	$order->update_meta_data( '_rzd_points', 0 );
	$order->delete_meta_data( '_rzd_town' );
	foreach ( array( 'first_name', 'last_name', 'company', 'address_1', 'address_2', 'city', 'postcode', 'state' ) as $f ) {
		$order->{"set_shipping_{$f}"}( '' );
	}
	if ( 'cod' === $order->get_payment_method() ) {
		$order->set_payment_method_title( 'Płatność przy odbiorze' );
	}
}, 40 );

/* ---------- mail „Gotowe do odbioru” ---------- */
add_action( 'woocommerce_order_status_w-dostawie', function ( $order_id, $order = null ) {
	$order = $order ? $order : wc_get_order( $order_id );
	if ( ! rzd_order_is_pickup( $order ) || empty( rzd_pickup_settings()['mail'] ) || $order->get_meta( '_rzd_pickup_mailed' ) ) {
		return;
	}
	$slot = array( 'date' => (string) $order->get_meta( '_dc_delivery_date' ), 'time' => (string) $order->get_meta( '_dc_delivery_time' ) );
	$pay  = 'cod' === $order->get_payment_method() ? 'Do zapłaty przy odbiorze: ' . html_entity_decode( wp_strip_all_tags( wc_price( $order->get_total() ) ), ENT_QUOTES, 'UTF-8' ) : '';
	$body = '<p>Dzień dobry' . ( $order->get_billing_first_name() ? ' ' . esc_html( $order->get_billing_first_name() ) : '' ) . ',</p>'
		. '<p>Twoje zamówienie <strong>#' . esc_html( $order->get_order_number() ) . '</strong> jest gotowe do odbioru.</p>'
		. '<p>' . rzd_pickup_info_html( $slot['date'] ? $slot : null, $pay ) . '</p>'
		. '<p>Do zobaczenia!</p>';
	if ( function_exists( 'rzd_customer_mail' ) && rzd_customer_mail( $order, 'Zamówienie #' . $order->get_order_number() . ' – gotowe do odbioru', 'Gotowe do odbioru', $body ) ) {
		$order->update_meta_data( '_rzd_pickup_mailed', current_time( 'Y-m-d H:i' ) );
		$order->save_meta_data();
		$order->add_order_note( 'Wysłano klientowi mail „Gotowe do odbioru”.' );
	}
}, 20, 2 );
