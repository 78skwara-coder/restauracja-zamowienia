<?php
/**
 * Moduł 36-odbior – Kuchnia: nazwy statusów przy zamówieniach z odbiorem. Pozostałe miejsca (zakładka
 * „Odbiór osobisty”, „Odebrane” w Pakowaniu, kurier bez odbiorów, automat po godzinie − „ile przed odbiorem”,
 * nowy termin z godzinami odbioru) – w modułach 12, 13 i 19 (szukaj „odbior” / rzd_order_is_pickup).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Statusy Kuchni widziane przy odbiorze: Spakowane = gotowe do odbioru, Dostarczone = odebrane. */
function rzd_pickup_status_labels() {
	return array(
		'w-dostawie' => 'Gotowe do odbioru',
		'wydane'     => 'Odebrane',
	);
}
