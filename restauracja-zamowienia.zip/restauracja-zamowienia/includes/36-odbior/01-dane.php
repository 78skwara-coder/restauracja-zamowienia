<?php
/**
 * Moduł 36-odbior – odbiór osobisty (2.47.0): ustawienia i silnik terminów odbioru.
 *
 * Odbiór to ten sam termin w sesji co dostawa (moduł 06, `dc_slot`), z kluczem `mode` = 'pickup'.
 * Klient wybiera go w okienku terminu przełącznikiem „Dostawa / Odbiór osobisty”. Dzień odbioru musi
 * być dniem, w którym kuchnia przyjmuje zamówienia na dania z koszyka (dni grupy, daty wyłączone,
 * horyzont, cutoff dzienny – bez godzin wyjazdu i okien dostaw), a godzina – z godzin odbioru
 * (Panel → Terminy → Odbiór osobisty: dni, od–do, co ile minut, ile przed odbiorem, limit na godzinę).
 * Zamówienie dostaje meta `_rzd_pickup` = 1 (+ zwykłe `_dc_delivery_date` / `_dc_delivery_time` = godzina odbioru).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ---------- ustawienia ---------- */
function rzd_pickup_defaults() {
	$hours = array();
	foreach ( array_keys( rzd_dc_days() ) as $d ) {
		$work          = ! in_array( $d, array( 'Sat', 'Sun' ), true );
		$hours[ $d ] = array( 'c' => $work ? 0 : 1, 'from' => $work ? '11:00' : '', 'to' => $work ? '16:00' : '' );
	}
	return array(
		'on'        => 0,
		'hours'     => $hours,
		'step'      => 15,
		'lead'      => 30,
		'max'       => 0,
		'address'   => '',
		'note'      => '',
		'min'       => '',
		'disc_type' => 'none',
		'disc_val'  => '',
		'pay'       => 'regular',
		'mail'      => 1,
	);
}

function rzd_pickup_settings( $reset = false ) {
	static $s = null;
	if ( $reset ) {
		$s = null;
	}
	if ( null !== $s ) {
		return $s;
	}
	$d = rzd_pickup_defaults();
	$o = get_option( 'rzd_pickup', array() );
	$o = is_array( $o ) ? $o : array();
	$s = wp_parse_args( $o, $d );
	$h = is_array( $s['hours'] ) ? $s['hours'] : array();
	foreach ( $d['hours'] as $k => $v ) {
		$s['hours'][ $k ] = isset( $h[ $k ] ) && is_array( $h[ $k ] ) ? wp_parse_args( $h[ $k ], $v ) : $v;
	}
	if ( '' === trim( (string) $s['address'] ) ) {
		$s['address'] = rzd_pickup_default_address();
	}
	return $s;
}

/** Adres lokalu: z wizytówki SEO, inaczej z adresu sklepu WooCommerce. */
function rzd_pickup_default_address() {
	if ( function_exists( 'rzd_seo_settings' ) ) {
		$seo = rzd_seo_settings();
		$a   = trim( implode( ', ', array_filter( array( isset( $seo['street'] ) ? $seo['street'] : '', trim( ( isset( $seo['postcode'] ) ? $seo['postcode'] : '' ) . ' ' . ( isset( $seo['city'] ) ? $seo['city'] : '' ) ) ) ) ) );
		if ( '' !== $a ) {
			return $a;
		}
	}
	$a = trim( (string) get_option( 'woocommerce_store_address', '' ) );
	$c = trim( get_option( 'woocommerce_store_postcode', '' ) . ' ' . get_option( 'woocommerce_store_city', '' ) );
	return trim( implode( ', ', array_filter( array( $a, $c ) ) ) );
}

function rzd_pickup_money( $v ) {
	$v = str_replace( array( ' ', ',' ), array( '', '.' ), trim( (string) $v ) );
	return ( '' !== $v && is_numeric( $v ) && (float) $v > 0 ) ? (string) round( (float) $v, 2 ) : '';
}

/** Zapis z panelu. Zwraca [ ok, message ]. */
function rzd_pickup_save( $in ) {
	$in  = is_array( $in ) ? $in : array();
	$old = rzd_pickup_settings();
	$d   = rzd_pickup_defaults();
	$hm  = function ( $v ) {
		$v = trim( (string) $v );
		return preg_match( '/^([01]?\d|2[0-3]):[0-5]\d$/', $v ) ? str_pad( $v, 5, '0', STR_PAD_LEFT ) : '';
	};
	$hours = array();
	$hin   = isset( $in['hours'] ) && is_array( $in['hours'] ) ? $in['hours'] : $old['hours'];
	foreach ( array_keys( $d['hours'] ) as $day ) {
		$r    = isset( $hin[ $day ] ) && is_array( $hin[ $day ] ) ? $hin[ $day ] : $old['hours'][ $day ]; // brak dnia – bez zmian
		$c    = empty( $r['c'] ) ? 0 : 1;
		$from = $hm( isset( $r['from'] ) ? $r['from'] : '' );
		$to   = $hm( isset( $r['to'] ) ? $r['to'] : '' );
		if ( ! $c && ( '' === $from || '' === $to || $from >= $to ) ) {
			return array( false, 'Godziny odbioru (' . rzd_dc_days()[ $day ] . '): podaj „od” i „do” (do później niż od) albo zaznacz „zamknięte”.' );
		}
		$hours[ $day ] = array( 'c' => $c, 'from' => $c ? '' : $from, 'to' => $c ? '' : $to );
	}
	$step = isset( $in['step'] ) ? (int) $in['step'] : $old['step'];
	$type = isset( $in['disc_type'] ) && in_array( $in['disc_type'], array( 'none', 'pct', 'fix' ), true ) ? $in['disc_type'] : 'none';
	$val  = rzd_pickup_money( isset( $in['disc_val'] ) ? $in['disc_val'] : '' );
	if ( 'none' !== $type && '' === $val ) {
		return array( false, 'Rabat za odbiór: podaj wartość większą od zera albo wybierz „bez rabatu”.' );
	}
	if ( 'pct' === $type && (float) $val > 50 ) {
		return array( false, 'Rabat za odbiór: najwyżej 50%.' );
	}
	$min = isset( $in['min'] ) ? trim( (string) $in['min'] ) : '';
	if ( '' !== $min && '' === rzd_pickup_money( $min ) ) {
		return array( false, 'Minimalna wartość zamówienia: podaj kwotę (np. 30) albo zostaw puste.' );
	}
	$s = array(
		'on'        => empty( $in['on'] ) ? 0 : 1,
		'hours'     => $hours,
		'step'      => in_array( $step, array( 10, 15, 20, 30, 60 ), true ) ? $step : 15,
		'lead'      => max( 0, min( 1440, (int) ( isset( $in['lead'] ) ? $in['lead'] : $old['lead'] ) ) ),
		'max'       => max( 0, min( 999, (int) ( isset( $in['max'] ) ? $in['max'] : $old['max'] ) ) ),
		'address'   => mb_substr( sanitize_text_field( isset( $in['address'] ) ? (string) $in['address'] : '' ), 0, 200 ),
		'note'      => mb_substr( sanitize_textarea_field( isset( $in['note'] ) ? (string) $in['note'] : '' ), 0, 500 ),
		'min'       => '' === $min ? '' : rzd_pickup_money( $min ),
		'disc_type' => $type,
		'disc_val'  => 'none' === $type ? '' : $val,
		'pay'       => isset( $in['pay'] ) && in_array( $in['pay'], array( 'online', 'regular', 'all' ), true ) ? $in['pay'] : 'regular',
		'mail'      => empty( $in['mail'] ) ? 0 : 1,
	);
	if ( $s['on'] && '' === trim( $s['address'] ) && '' === rzd_pickup_default_address() ) { // puste = adres z wizytówki / sklepu
		return array( false, 'Podaj adres miejsca odbioru – klient zobaczy go przy wyborze i w mailu.' );
	}
	update_option( 'rzd_pickup', $s, false );
	rzd_pickup_settings( true );
	if ( function_exists( 'rzd_dc_orders_maps_flush' ) ) {
		rzd_dc_orders_maps_flush();
	}
	return array( true, $s['on'] ? 'Zapisano – odbiór osobisty jest włączony.' : 'Zapisano. Odbiór osobisty jest wyłączony.' );
}

/** Odbiór działa: włączony i działa wybór terminu (moduł 06). */
function rzd_pickup_on() {
	$s = rzd_pickup_settings();
	return ! empty( $s['on'] ) && function_exists( 'rzd_dc_enabled' ) && rzd_dc_enabled();
}

/** Klient wybrał odbiór (termin w sesji ma mode=pickup). */
function rzd_pickup_mode() {
	if ( ! rzd_pickup_on() || ! function_exists( 'rzd_dc_get_slot' ) ) {
		return false;
	}
	$slot = rzd_dc_get_slot();
	return $slot && rzd_slot_is_pickup( $slot );
}

function rzd_slot_is_pickup( $slot ) {
	return is_array( $slot ) && isset( $slot['mode'] ) && 'pickup' === $slot['mode'];
}

function rzd_order_is_pickup( $order ) {
	return $order && is_object( $order ) && '1' === (string) $order->get_meta( '_rzd_pickup' );
}

/* ---------- silnik terminów odbioru ---------- */

/** Czy grupa (kalendarz) przyjmuje zamówienia na dzień $date – reguły dzienne, bez godzin wyjazdu i okien. */
function rzd_pickup_cal_open( $cal, $date ) {
	$s   = rzd_dc_get_settings();
	$tz  = wp_timezone();
	$now = rzd_dc_now();
	$today = $now->format( 'Y-m-d' );
	if ( $date < $today ) {
		return false;
	}
	$max = new DateTime( $today, $tz );
	$max->modify( '+' . (int) $cal['horizon'] . ' days' );
	if ( $date > $max->format( 'Y-m-d' ) ) {
		return false;
	}
	if ( ( ! empty( $cal['valid_from'] ) && $date < $cal['valid_from'] ) || ( ! empty( $cal['valid_to'] ) && $date > $cal['valid_to'] ) ) {
		return false;
	}
	$dow = ( new DateTime( $date, $tz ) )->format( 'D' );
	if ( ! in_array( $dow, (array) $cal['days'], true ) ) {
		return false;
	}
	if ( in_array( $date, (array) $cal['blocked'], true ) || in_array( $date, (array) $s['global_blocked'], true ) ) {
		return false;
	}
	$cutoff_days = isset( $cal['cutoff_days'] ) ? (int) $cal['cutoff_days'] : 0;
	if ( ! empty( $cal['cutoff'] ) || $cutoff_days > 0 ) {
		$deadline = rzd_dc_cutoff_deadline_date( $cal, $date ) . ' ' . ( ! empty( $cal['cutoff'] ) ? $cal['cutoff'] : '23:59' );
		if ( $now->format( 'Y-m-d H:i' ) > $deadline ) {
			return false;
		}
	}
	return true;
}

/** Liczba zamówień z odbiorem na dzień + godzinę (licznik z modułu 06, osobny od dostaw). */
function rzd_pickup_count( $date, $time ) {
	$maps = function_exists( 'rzd_dc_orders_slot_maps' ) ? rzd_dc_orders_slot_maps() : array();
	$key  = $date . '|' . $time;
	return isset( $maps['pickup'][ $key ] ) ? (int) $maps['pickup'][ $key ] : 0;
}

/** Godziny odbioru w dniu $date (siatka co `step` minut, po „ile przed odbiorem”, bez pełnych). */
function rzd_pickup_times_for_date( $date, $ignore_lead = false ) {
	static $memo = array();
	$mk = $date . '|' . ( $ignore_lead ? 1 : 0 );
	if ( isset( $memo[ $mk ] ) ) {
		return $memo[ $mk ];
	}
	$s   = rzd_pickup_settings();
	$dcs = rzd_dc_get_settings();
	$out = array();
	if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $date ) || in_array( $date, (array) $dcs['global_blocked'], true ) ) {
		return $memo[ $mk ] = $out;
	}
	$dow = ( new DateTime( $date, wp_timezone() ) )->format( 'D' );
	$h   = isset( $s['hours'][ $dow ] ) ? $s['hours'][ $dow ] : array( 'c' => 1 );
	if ( ! empty( $h['c'] ) || empty( $h['from'] ) || empty( $h['to'] ) ) {
		return $memo[ $mk ] = $out;
	}
	$min = clone rzd_dc_now();
	$min->modify( '+' . ( $ignore_lead ? 0 : (int) $s['lead'] ) . ' minutes' );
	$min_s = $min->format( 'Y-m-d H:i' );
	$step  = max( 5, (int) $s['step'] );
	for ( $m = rzd_dc_hm_to_min( $h['from'] ); $m <= rzd_dc_hm_to_min( $h['to'] ); $m += $step ) {
		$t = rzd_dc_min_to_hm( $m );
		if ( $date . ' ' . $t <= $min_s ) {
			continue;
		}
		if ( ! $ignore_lead && (int) $s['max'] > 0 && rzd_pickup_count( $date, $t ) >= (int) $s['max'] ) {
			continue;
		}
		$out[] = $t;
	}
	return $memo[ $mk ] = $out;
}

/** Czy produkt da się przygotować na odbiór w dniu $date (kalendarz jego grupy przyjmuje ten dzień). */
function rzd_pickup_product_day_ok( $product_id, $date ) {
	foreach ( rzd_dc_calendars_for_product( $product_id ) as $cal ) {
		if ( rzd_pickup_cal_open( $cal, $date ) ) {
			return true;
		}
	}
	return false;
}

/** Terminy odbioru wspólne dla produktów: [ 'Y-m-d' => [ 'HH:MM', … ] ]. Bez produktów – dni, w które przyjmuje jakakolwiek grupa. */
function rzd_pickup_slots_for_products( $ids ) {
	$ids = array_values( array_unique( array_map( 'intval', (array) $ids ) ) );
	$out = array();
	$day = rzd_dc_now();
	$max = rzd_dc_max_horizon();
	$cals = rzd_dc_get_settings()['groups'];
	for ( $i = 0; $i <= $max; $i++ ) {
		$date = $day->format( 'Y-m-d' );
		$day->modify( '+1 day' );
		$ok = true;
		if ( $ids ) {
			foreach ( $ids as $pid ) {
				if ( ! rzd_pickup_product_day_ok( $pid, $date ) || ! rzd_dc_product_available_on( $pid, $date ) ) {
					$ok = false;
					break;
				}
			}
		} else {
			$ok = false;
			foreach ( $cals as $cal ) {
				if ( rzd_pickup_cal_open( $cal, $date ) ) {
					$ok = true;
					break;
				}
			}
		}
		if ( ! $ok ) {
			continue;
		}
		$times = rzd_pickup_times_for_date( $date );
		if ( $times ) {
			$out[ $date ] = $times;
		}
	}
	return $out;
}

/** Moment, od którego kuchnia traktuje odbiór jako zamknięty (godzina odbioru − „ile przed odbiorem”). */
function rzd_pickup_cutoff_ts( $date, $time ) {
	$ts = function_exists( 'rzd_dc_date_ts' ) ? rzd_dc_date_ts( $date, $time ) : 0;
	return $ts ? $ts - 60 * (int) rzd_pickup_settings()['lead'] : 0;
}

/** Opis dla klienta: „Wtorek, 3 listopada 2026, godz. 12:30”. */
function rzd_pickup_slot_label( $slot ) {
	return rzd_dc_date_label( $slot['date'] ) . ', godz. ' . $slot['time'];
}

/** Czy klient może zapłacić przy odbiorze (ustawienie: online / stali klienci / wszyscy). */
function rzd_pickup_pay_on_site_allowed() {
	$s = rzd_pickup_settings();
	if ( 'all' === $s['pay'] ) {
		return true;
	}
	if ( 'regular' !== $s['pay'] || ! is_user_logged_in() ) {
		return false;
	}
	static $ok = null;
	if ( null === $ok ) {
		$done = wc_get_orders( array(
			'customer_id' => get_current_user_id(),
			'status'      => array( 'wc-completed', 'wc-wydane' ),
			'limit'       => 1,
			'return'      => 'ids',
		) );
		$ok = (bool) $done;
	}
	return $ok;
}

/** Rabat za odbiór w zł (brutto) od wartości produktów przed rabatami. */
function rzd_pickup_discount_amount( $value ) {
	$s = rzd_pickup_settings();
	$v = (float) $s['disc_val'];
	if ( 'pct' === $s['disc_type'] && $v > 0 ) {
		return round( $value * $v / 100, 2 );
	}
	if ( 'fix' === $s['disc_type'] && $v > 0 ) {
		return (float) min( $v, $value );
	}
	return 0.0;
}
