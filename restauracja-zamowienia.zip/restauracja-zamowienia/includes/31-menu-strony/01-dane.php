<?php
/**
 * MODUŁ 31: Menu strony – wygodny edytor nawigacji (Restauracja → Menu strony).
 * Część 1: odczyt i zapis menu WordPressa – bez własnego formatu:
 * - motyw klasyczny (np. Astra): menu nav_menu (to samo co Wygląd → Menu) + położenia motywu;
 * - motyw blokowy (np. Twenty Twenty-Five): wpisy wp_navigation (blok Nawigacja); inne bloki w nawigacji
 *   (lista stron, wyszukiwarka…) zostają nietknięte jako pozycje „blok”.
 * Dodatki wtyczki zapisywane jako klasy CSS pozycji (działają w obu rodzajach motywów, po wyłączeniu wtyczki nic nie psują):
 * rzd-nav-cta (wyróżnij jako przycisk), rzd-nav-in / rzd-nav-out (tylko zalogowani / goście),
 * rzd-nav-hide-mobile / rzd-nav-hide-desktop.
 *
 * Pozycja w edytorze (płaska lista z poziomem): id, type (post_type / taxonomy / custom / post_type_archive / block), object, object_id,
 * label, url, blank, cta, vis_user ('' / in / out), vis_dev ('' / mobile / desktop), classes (inne klasy), depth, raw (blok), desc.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'RZD_NAV_MAX_DEPTH', 2 ); // 3 poziomy: menu, podmenu, podmenu podmenu

function rzd_nav_block_mode() {
	return function_exists( 'wp_is_block_theme' ) && wp_is_block_theme();
}
function rzd_nav_can() {
	return current_user_can( 'manage_options' ) || current_user_can( 'rzd_p_settings' );
}

/* ============================================================
 * 1. KLASY ↔ USTAWIENIA POZYCJI
 * ============================================================ */
function rzd_nav_own_classes() {
	return array( 'rzd-nav-cta', 'rzd-nav-in', 'rzd-nav-out', 'rzd-nav-hide-mobile', 'rzd-nav-hide-desktop' );
}
function rzd_nav_classes_to_item( $classes, $item ) {
	$c                = array_values( array_filter( array_map( 'trim', is_array( $classes ) ? $classes : preg_split( '/\s+/', (string) $classes ) ) ) );
	$item['cta']      = in_array( 'rzd-nav-cta', $c, true ) ? 1 : 0;
	$item['vis_user'] = in_array( 'rzd-nav-in', $c, true ) ? 'in' : ( in_array( 'rzd-nav-out', $c, true ) ? 'out' : '' );
	$item['vis_dev']  = in_array( 'rzd-nav-hide-desktop', $c, true ) ? 'mobile' : ( in_array( 'rzd-nav-hide-mobile', $c, true ) ? 'desktop' : '' );
	$item['classes']  = implode( ' ', array_diff( $c, rzd_nav_own_classes() ) );
	return $item;
}
function rzd_nav_item_classes( $it ) {
	$c = array_filter( preg_split( '/\s+/', (string) $it['classes'] ) );
	if ( ! empty( $it['cta'] ) ) {
		$c[] = 'rzd-nav-cta';
	}
	if ( 'in' === $it['vis_user'] || 'out' === $it['vis_user'] ) {
		$c[] = 'rzd-nav-' . $it['vis_user'];
	}
	if ( 'mobile' === $it['vis_dev'] ) {
		$c[] = 'rzd-nav-hide-desktop';
	} elseif ( 'desktop' === $it['vis_dev'] ) {
		$c[] = 'rzd-nav-hide-mobile';
	}
	return array_values( array_unique( array_map( 'sanitize_html_class', $c ) ) );
}

// Opis pozycji w edytorze („Strona: Kontakt”) i aktualny adres obiektu.
function rzd_nav_object_info( $type, $object, $object_id ) {
	if ( 'post_type' === $type && $object_id ) {
		$p  = get_post( $object_id );
		$pt = get_post_type_object( $object );
		if ( ! $p || 'trash' === $p->post_status ) {
			return array( 'desc' => '⚠ usunięta treść', 'url' => '', 'title' => '' );
		}
		return array( 'desc' => ( $pt ? $pt->labels->singular_name : $object ) . ( 'publish' !== $p->post_status ? ' (nieopublikowana)' : '' ), 'url' => get_permalink( $p ), 'title' => get_the_title( $p ) );
	}
	if ( 'taxonomy' === $type && $object_id ) {
		$t  = get_term( $object_id, $object );
		$tx = get_taxonomy( $object );
		if ( ! $t || is_wp_error( $t ) ) {
			return array( 'desc' => '⚠ usunięta kategoria', 'url' => '', 'title' => '' );
		}
		$u = get_term_link( $t );
		return array( 'desc' => $tx ? $tx->labels->singular_name : $object, 'url' => is_wp_error( $u ) ? '' : $u, 'title' => $t->name );
	}
	if ( 'post_type_archive' === $type ) {
		$pt = get_post_type_object( $object );
		return array( 'desc' => 'Archiwum', 'url' => (string) get_post_type_archive_link( $object ), 'title' => $pt ? $pt->labels->name : $object );
	}
	return array( 'desc' => 'Link', 'url' => '', 'title' => '' );
}
function rzd_nav_item_defaults() {
	return array( 'id' => '', 'type' => 'custom', 'object' => 'custom', 'object_id' => 0, 'label' => '', 'url' => '', 'blank' => 0, 'cta' => 0, 'vis_user' => '', 'vis_dev' => '', 'classes' => '', 'depth' => 0, 'raw' => '', 'desc' => '' );
}

/* ============================================================
 * 2. MENU – LISTA, ODCZYT
 * ============================================================ */
// [ id => nazwa ]
function rzd_nav_menus() {
	$out = array();
	if ( rzd_nav_block_mode() ) {
		foreach ( get_posts( array( 'post_type' => 'wp_navigation', 'post_status' => 'publish', 'numberposts' => 100, 'orderby' => 'title', 'order' => 'ASC' ) ) as $p ) {
			$out[ $p->ID ] = '' !== $p->post_title ? $p->post_title : 'Nawigacja #' . $p->ID;
		}
	} else {
		foreach ( wp_get_nav_menus() as $m ) {
			$out[ $m->term_id ] = $m->name;
		}
	}
	return $out;
}

function rzd_nav_read( $menu_id ) {
	return rzd_nav_block_mode() ? rzd_nav_read_block( $menu_id ) : rzd_nav_read_classic( $menu_id );
}

function rzd_nav_read_classic( $menu_id ) {
	$items = wp_get_nav_menu_items( $menu_id, array( 'post_status' => 'publish,draft' ) );
	$items = is_array( $items ) ? $items : array();
	usort( $items, function ( $a, $b ) {
		return (int) $a->menu_order - (int) $b->menu_order;
	} );
	// kolejność drzewa (rodzic przed dziećmi) i poziom
	$kids = array();
	$ids  = wp_list_pluck( $items, 'ID' );
	foreach ( $items as $it ) {
		$par           = in_array( (int) $it->menu_item_parent, array_map( 'intval', $ids ), true ) ? (int) $it->menu_item_parent : 0;
		$kids[ $par ][] = $it;
	}
	$out  = array();
	$walk = function ( $parent, $depth ) use ( &$walk, &$kids, &$out ) {
		foreach ( isset( $kids[ $parent ] ) ? $kids[ $parent ] : array() as $it ) {
			$info  = rzd_nav_object_info( $it->type, $it->object, (int) $it->object_id );
			$row   = array_merge( rzd_nav_item_defaults(), array(
				'id'        => 'm' . $it->ID,
				'type'      => in_array( $it->type, array( 'post_type', 'taxonomy', 'custom', 'post_type_archive' ), true ) ? $it->type : 'custom',
				'object'    => (string) $it->object,
				'object_id' => (int) $it->object_id,
				'label'     => html_entity_decode( wp_strip_all_tags( (string) $it->title ), ENT_QUOTES, 'UTF-8' ),
				'url'       => 'custom' === $it->type ? (string) $it->url : $info['url'],
				'blank'     => '_blank' === $it->target ? 1 : 0,
				'depth'     => min( $depth, RZD_NAV_MAX_DEPTH ),
				'desc'      => $info['desc'],
			) );
			$out[] = rzd_nav_classes_to_item( (array) $it->classes, $row );
			$walk( (int) $it->ID, $depth + 1 );
		}
	};
	$walk( 0, 0 );
	return $out;
}

function rzd_nav_read_block( $post_id ) {
	$p = get_post( $post_id );
	if ( ! $p || 'wp_navigation' !== $p->post_type ) {
		return array();
	}
	$out  = array();
	$i    = 0;
	$walk = function ( $blocks, $depth ) use ( &$walk, &$out, &$i ) {
		foreach ( $blocks as $b ) {
			if ( empty( $b['blockName'] ) ) {
				continue; // odstępy między blokami
			}
			++$i;
			if ( in_array( $b['blockName'], array( 'core/navigation-link', 'core/navigation-submenu' ), true ) ) {
				$a    = $b['attrs'];
				$kind = isset( $a['kind'] ) ? $a['kind'] : 'custom';
				$type = 'post-type' === $kind ? 'post_type' : ( 'taxonomy' === $kind ? 'taxonomy' : 'custom' );
				$obj  = isset( $a['type'] ) ? (string) $a['type'] : 'custom';
				if ( 'taxonomy' === $type && 'tag' === $obj ) {
					$obj = 'post_tag';
				}
				$oid  = isset( $a['id'] ) ? (int) $a['id'] : 0;
				if ( 'custom' !== $type && ! $oid ) {
					$type = 'custom';
				}
				$info = rzd_nav_object_info( $type, $obj, $oid );
				$row  = array_merge( rzd_nav_item_defaults(), array(
					'id'        => 'b' . $i,
					'type'      => $type,
					'object'    => 'custom' === $type ? 'custom' : $obj,
					'object_id' => 'custom' === $type ? 0 : $oid,
					'label'     => html_entity_decode( wp_strip_all_tags( isset( $a['label'] ) ? (string) $a['label'] : '' ), ENT_QUOTES, 'UTF-8' ),
					'url'       => 'custom' === $type ? ( isset( $a['url'] ) ? (string) $a['url'] : '' ) : ( $info['url'] ? $info['url'] : ( isset( $a['url'] ) ? (string) $a['url'] : '' ) ),
					'blank'     => ! empty( $a['opensInNewTab'] ) ? 1 : 0,
					'depth'     => min( $depth, RZD_NAV_MAX_DEPTH ),
					'desc'      => $info['desc'],
				) );
				$out[] = rzd_nav_classes_to_item( isset( $a['className'] ) ? $a['className'] : '', $row );
				if ( ! empty( $b['innerBlocks'] ) ) {
					$walk( $b['innerBlocks'], $depth + 1 );
				}
			} else {
				$names = array( 'core/page-list' => 'Lista stron (automatyczna)', 'core/search' => 'Wyszukiwarka', 'core/social-links' => 'Ikony serwisów społecznościowych', 'core/home-link' => 'Strona główna', 'core/site-title' => 'Nazwa strony', 'core/site-logo' => 'Logo', 'core/spacer' => 'Odstęp', 'woocommerce/mini-cart' => 'Mini koszyk WooCommerce', 'woocommerce/customer-account' => 'Konto klienta WooCommerce' );
				$out[] = array_merge( rzd_nav_item_defaults(), array(
					'id'    => 'b' . $i,
					'type'  => 'block',
					'label' => isset( $names[ $b['blockName'] ] ) ? $names[ $b['blockName'] ] : 'Blok: ' . $b['blockName'],
					'raw'   => serialize_block( $b ),
					'depth' => min( $depth, RZD_NAV_MAX_DEPTH ),
					'desc'  => 'Blok (ustawiasz w edytorze witryny)',
				) );
			}
		}
	};
	$walk( parse_blocks( (string) $p->post_content ), 0 );
	return $out;
}

/* ============================================================
 * 3. ZAPIS
 * ============================================================ */

// Czyszczenie listy z edytora: znane typy, istniejące obiekty, poprawny poziom (najwyżej o 1 głębiej niż poprzednia pozycja).
function rzd_nav_sanitize_tree( $rows ) {
	$out  = array();
	$prev = -1;
	foreach ( array_slice( (array) $rows, 0, 300 ) as $r ) {
		if ( ! is_array( $r ) ) {
			continue;
		}
		$it       = array_merge( rzd_nav_item_defaults(), array_intersect_key( $r, rzd_nav_item_defaults() ) );
		$it['id'] = preg_match( '/^[mb]\d+$/', (string) $it['id'] ) ? $it['id'] : '';
		$type     = in_array( $it['type'], array( 'post_type', 'taxonomy', 'custom', 'post_type_archive', 'block' ), true ) ? $it['type'] : 'custom';
		$it['type']      = $type;
		$it['object']    = sanitize_key( $it['object'] );
		$it['object_id'] = absint( $it['object_id'] );
		if ( 'post_type' === $type && ( ! $it['object_id'] || ! get_post( $it['object_id'] ) ) ) {
			continue;
		}
		if ( 'taxonomy' === $type && ( ! $it['object_id'] || ! taxonomy_exists( $it['object'] ) || ! get_term( $it['object_id'], $it['object'] ) ) ) {
			continue;
		}
		if ( 'block' === $type ) {
			$parsed = parse_blocks( (string) $it['raw'] );
			if ( empty( $parsed[0]['blockName'] ) ) {
				continue;
			}
			$it['raw'] = serialize_block( $parsed[0] );
		} else {
			$it['raw'] = '';
		}
		$it['label'] = sanitize_text_field( $it['label'] );
		if ( 'custom' === $type ) {
			$u         = trim( (string) $it['url'] );
			$it['url'] = rzd_nav_clean_url( $u );
			if ( '' === $it['label'] && '' === $it['url'] ) {
				continue;
			}
			if ( '' === $it['label'] ) {
				$it['label'] = $it['url'];
			}
		}
		$it['blank']    = empty( $it['blank'] ) ? 0 : 1;
		$it['cta']      = empty( $it['cta'] ) ? 0 : 1;
		$it['vis_user'] = in_array( $it['vis_user'], array( 'in', 'out' ), true ) ? $it['vis_user'] : '';
		$it['vis_dev']  = in_array( $it['vis_dev'], array( 'mobile', 'desktop' ), true ) ? $it['vis_dev'] : '';
		$it['classes']  = implode( ' ', array_filter( array_map( 'sanitize_html_class', preg_split( '/\s+/', (string) $it['classes'] ) ) ) );
		$d              = max( 0, min( RZD_NAV_MAX_DEPTH, (int) $it['depth'] ) );
		$it['depth']    = min( $d, $prev + 1 );
		$prev           = $it['depth'];
		$out[]          = $it;
	}
	return $out;
}

// Adres własnego linku: tel:/mailto:/sms: (bez spacji), #kotwica, /ścieżka, a bez protokołu – https://.
function rzd_nav_clean_url( $u ) {
	$u = trim( (string) $u );
	if ( '' === $u ) {
		return '';
	}
	if ( preg_match( '#^(tel|mailto|sms):#i', $u ) ) {
		return esc_url_raw( preg_replace( '/\s+/', '', $u ), array( 'tel', 'mailto', 'sms' ) );
	}
	if ( '#' === $u[0] ) {
		return '#' . sanitize_title( substr( $u, 1 ) );
	}
	if ( '/' !== $u[0] && ! preg_match( '#^https?://#i', $u ) ) {
		$u = 'https://' . $u;
	}
	return esc_url_raw( $u, array( 'http', 'https' ) );
}

function rzd_nav_save( $menu_id, $rows ) {
	$rows = rzd_nav_sanitize_tree( $rows );
	$r    = rzd_nav_block_mode() ? rzd_nav_save_block( $menu_id, $rows ) : rzd_nav_save_classic( $menu_id, $rows );
	if ( ! is_wp_error( $r ) ) {
		rzd_nav_update_flags();
	}
	return $r;
}

function rzd_nav_save_classic( $menu_id, $rows ) {
	if ( ! is_nav_menu( $menu_id ) ) {
		return new WP_Error( 'rzd_nav', 'Nie ma takiego menu.' );
	}
	$old   = wp_list_pluck( (array) wp_get_nav_menu_items( $menu_id, array( 'post_status' => 'publish,draft' ) ), 'ID' );
	$keep  = array();
	$stack = array();
	foreach ( $rows as $pos => $it ) {
		if ( 'block' === $it['type'] ) {
			continue;
		}
		$db   = 'm' === substr( $it['id'], 0, 1 ) && in_array( (int) substr( $it['id'], 1 ), array_map( 'intval', $old ), true ) ? (int) substr( $it['id'], 1 ) : 0;
		$par  = $it['depth'] > 0 && isset( $stack[ $it['depth'] - 1 ] ) ? $stack[ $it['depth'] - 1 ] : 0;
		$args = array(
			'menu-item-type'      => $it['type'],
			'menu-item-object'    => 'custom' === $it['type'] ? 'custom' : $it['object'],
			'menu-item-object-id' => 'custom' === $it['type'] ? 0 : $it['object_id'],
			'menu-item-title'     => $it['label'],
			'menu-item-url'       => 'custom' === $it['type'] ? $it['url'] : '',
			'menu-item-target'    => $it['blank'] ? '_blank' : '',
			'menu-item-classes'   => implode( ' ', rzd_nav_item_classes( $it ) ),
			'menu-item-parent-id' => $par,
			'menu-item-position'  => $pos + 1,
			'menu-item-status'    => 'publish',
		);
		$id = wp_update_nav_menu_item( $menu_id, $db, $args );
		if ( is_wp_error( $id ) ) {
			return $id;
		}
		$keep[]                 = (int) $id;
		$stack[ $it['depth'] ]  = (int) $id;
		$stack                  = array_slice( $stack, 0, $it['depth'] + 1, true );
	}
	foreach ( array_diff( array_map( 'intval', $old ), $keep ) as $gone ) {
		wp_delete_post( $gone, true );
	}
	return true;
}

// Płaska lista z poziomami → drzewo bloków core/navigation-link / -submenu.
function rzd_nav_rows_to_blocks( $rows, &$i = 0, $depth = 0 ) {
	$blocks = array();
	$n      = count( $rows );
	while ( $i < $n && $rows[ $i ]['depth'] >= $depth ) {
		$it = $rows[ $i ];
		++$i;
		$inner = array();
		if ( $i < $n && $rows[ $i ]['depth'] > $it['depth'] ) {
			$inner = rzd_nav_rows_to_blocks( $rows, $i, $it['depth'] + 1 );
		}
		if ( 'block' === $it['type'] ) {
			$b = parse_blocks( $it['raw'] )[0];
			if ( $inner ) { // dzieci pod blokiem innego rodzaju – przenosimy na ten sam poziom
				$blocks[] = $b;
				$blocks   = array_merge( $blocks, $inner );
				continue;
			}
			$blocks[] = $b;
			continue;
		}
		$info  = rzd_nav_object_info( $it['type'], $it['object'], $it['object_id'] );
		$attrs = array( 'label' => esc_html( $it['label'] ) );
		if ( 'custom' === $it['type'] ) {
			$attrs['url']  = $it['url'];
			$attrs['kind'] = 'custom';
		} else {
			$attrs['type'] = 'taxonomy' === $it['type'] && 'post_tag' === $it['object'] ? 'tag' : $it['object'];
			$attrs['id']   = (int) $it['object_id'];
			$attrs['url']  = $info['url'];
			$attrs['kind'] = 'taxonomy' === $it['type'] ? 'taxonomy' : 'post-type';
		}
		if ( $it['blank'] ) {
			$attrs['opensInNewTab'] = true;
		}
		$cls = rzd_nav_item_classes( $it );
		if ( $cls ) {
			$attrs['className'] = implode( ' ', $cls );
		}
		$blocks[] = array(
			'blockName'    => $inner ? 'core/navigation-submenu' : 'core/navigation-link',
			'attrs'        => $attrs,
			'innerBlocks'  => $inner,
			'innerHTML'    => '',
			'innerContent' => $inner ? array_fill( 0, count( $inner ), null ) : array(),
		);
	}
	return $blocks;
}

function rzd_nav_save_block( $post_id, $rows ) {
	$p = get_post( $post_id );
	if ( ! $p || 'wp_navigation' !== $p->post_type ) {
		return new WP_Error( 'rzd_nav', 'Nie ma takiej nawigacji.' );
	}
	$i       = 0;
	$content = serialize_blocks( rzd_nav_rows_to_blocks( array_values( $rows ), $i, 0 ) );
	kses_remove_filters(); // treść to wyłącznie bloki zbudowane powyżej z oczyszczonych danych (jak zapis w edytorze witryny)
	$r = wp_update_post( wp_slash( array( 'ID' => $post_id, 'post_content' => $content ) ), true );
	kses_init_filters();
	return is_wp_error( $r ) ? $r : true;
}

// Czy któreś menu używa dodatków (CSS w <head> tylko wtedy).
function rzd_nav_update_flags() {
	$used = false;
	foreach ( array_keys( rzd_nav_menus() ) as $id ) {
		foreach ( rzd_nav_read( $id ) as $it ) {
			if ( $it['cta'] || $it['vis_dev'] ) {
				$used = true;
				break 2;
			}
		}
	}
	update_option( 'rzd_nav_css', $used ? 1 : 0, true );
}

/* ============================================================
 * 4. NOWE / KOPIA / USUŃ, POŁOŻENIA, NAGŁÓWEK MOTYWU BLOKOWEGO
 * ============================================================ */
function rzd_nav_create( $name, $copy_from = 0 ) {
	$name = sanitize_text_field( $name );
	$name = '' !== $name ? $name : 'Nowe menu';
	if ( rzd_nav_block_mode() ) {
		$id = wp_insert_post( array( 'post_type' => 'wp_navigation', 'post_status' => 'publish', 'post_title' => $name, 'post_content' => '' ), true );
	} else {
		$base = $name;
		for ( $n = 2; is_nav_menu( $name ); $n++ ) {
			$name = $base . ' (' . $n . ')';
		}
		$id = wp_create_nav_menu( $name );
	}
	if ( is_wp_error( $id ) ) {
		return $id;
	}
	if ( $copy_from ) {
		$rows = array_map( function ( $r ) {
			$r['id'] = '';
			return $r;
		}, rzd_nav_read( $copy_from ) );
		rzd_nav_save( $id, $rows );
	}
	return (int) $id;
}
function rzd_nav_delete( $id ) {
	if ( rzd_nav_block_mode() ) {
		return (bool) wp_trash_post( $id );
	}
	return ! is_wp_error( wp_delete_nav_menu( $id ) );
}

// Motyw klasyczny: położenia (nagłówek, stopka…) => menu.
function rzd_nav_locations() {
	return rzd_nav_block_mode() ? array() : get_registered_nav_menus();
}
function rzd_nav_set_locations( $menu_id, $wanted ) {
	$loc = get_nav_menu_locations();
	foreach ( rzd_nav_locations() as $slug => $label ) {
		if ( in_array( $slug, (array) $wanted, true ) ) {
			$loc[ $slug ] = (int) $menu_id;
		} elseif ( isset( $loc[ $slug ] ) && (int) $loc[ $slug ] === (int) $menu_id ) {
			$loc[ $slug ] = 0;
		}
	}
	set_theme_mod( 'nav_menu_locations', $loc );
}

// Motyw blokowy: nawigacja użyta w nagłówku (atrybut ref bloku Nawigacja w części szablonu „header”).
function rzd_nav_header_template() {
	if ( ! function_exists( 'get_block_template' ) ) {
		return null;
	}
	$t = get_block_template( get_stylesheet() . '//header', 'wp_template_part' );
	return $t && ! empty( $t->content ) ? $t : null;
}
// Bloki części szablonu z rozwiniętymi wzorcami (np. Twenty Twenty-Five: nagłówek = wzorzec „twentytwentyfive/header”).
function rzd_nav_expand_patterns( $blocks, $level = 0 ) {
	$out = array();
	foreach ( $blocks as $b ) {
		if ( 'core/pattern' === $b['blockName'] && $level < 3 && ! empty( $b['attrs']['slug'] ) && class_exists( 'WP_Block_Patterns_Registry' ) ) {
			$pat = WP_Block_Patterns_Registry::get_instance()->get_registered( $b['attrs']['slug'] );
			if ( $pat && ! empty( $pat['content'] ) ) {
				$out = array_merge( $out, rzd_nav_expand_patterns( parse_blocks( $pat['content'] ), $level + 1 ) );
				continue;
			}
		}
		if ( ! empty( $b['innerBlocks'] ) ) {
			$b['innerBlocks'] = rzd_nav_expand_patterns( $b['innerBlocks'], $level );
		}
		$out[] = $b;
	}
	return $out;
}
function rzd_nav_header_ref() {
	$t = rzd_nav_header_template();
	if ( ! $t ) {
		return 0;
	}
	$find = function ( $blocks ) use ( &$find ) {
		foreach ( $blocks as $b ) {
			if ( 'core/navigation' === $b['blockName'] ) {
				return isset( $b['attrs']['ref'] ) ? (int) $b['attrs']['ref'] : -1; // -1 = blok bez wskazanej nawigacji
			}
			$r = $find( $b['innerBlocks'] );
			if ( 0 !== $r ) {
				return $r;
			}
		}
		return 0;
	};
	return $find( rzd_nav_expand_patterns( parse_blocks( $t->content ) ) );
}
function rzd_nav_use_in_header( $nav_id ) {
	$t = rzd_nav_header_template();
	if ( ! $t ) {
		return new WP_Error( 'rzd_nav', 'Motyw nie ma części szablonu „header” – wybierz nawigację w edytorze witryny.' );
	}
	$done = false;
	$set  = function ( $blocks ) use ( &$set, &$done, $nav_id ) {
		foreach ( $blocks as $k => $b ) {
			if ( ! $done && 'core/navigation' === $b['blockName'] ) {
				$blocks[ $k ]['attrs']['ref'] = (int) $nav_id;
				$done                          = true;
			} elseif ( ! empty( $b['innerBlocks'] ) ) {
				$blocks[ $k ]['innerBlocks'] = $set( $b['innerBlocks'] );
			}
		}
		return $blocks;
	};
	$blocks = $set( rzd_nav_expand_patterns( parse_blocks( $t->content ) ) ); // wzorzec rozwinięty – jak przy zapisie w edytorze witryny
	if ( ! $done ) {
		return new WP_Error( 'rzd_nav', 'W nagłówku nie ma bloku Nawigacja – dodaj go w edytorze witryny.' );
	}
	$content = serialize_blocks( $blocks );
	kses_remove_filters();
	if ( 'custom' === $t->source && $t->wp_id ) {
		$r = wp_update_post( wp_slash( array( 'ID' => $t->wp_id, 'post_content' => $content ) ), true );
	} else { // pierwsza zmiana nagłówka motywu – zapis jak w edytorze witryny (własna kopia części szablonu)
		$r = wp_insert_post( wp_slash( array( 'post_type' => 'wp_template_part', 'post_status' => 'publish', 'post_name' => 'header', 'post_title' => $t->title ? $t->title : 'Header', 'post_content' => $content ) ), true );
		if ( ! is_wp_error( $r ) ) {
			wp_set_object_terms( $r, get_stylesheet(), 'wp_theme' );
			wp_set_object_terms( $r, $t->area ? $t->area : 'header', 'wp_template_part_area' );
		}
	}
	kses_init_filters();
	return is_wp_error( $r ) ? $r : true;
}
