<?php
/**
 * Moduł 31 – część 3: dane do edytora Menu strony (Panel restauracji → Menu strony, moduł 34; do 2.45.0 kokpit).
 * Gotowe pozycje restauracji, wyszukiwanie treści, wybór menu, zapis (drzewo + położenia + nazwa).
 * Zapis jednym przyciskiem; do zapisu nic nie zmienia się na stronie.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 1. POZYCJE DO DODANIA
 * ============================================================ */
function rzd_nav_post_item( $p, $label = '' ) {
	$info = rzd_nav_object_info( 'post_type', $p->post_type, $p->ID );
	return array_merge( rzd_nav_item_defaults(), array( 'type' => 'post_type', 'object' => $p->post_type, 'object_id' => $p->ID, 'label' => '' !== $label ? $label : html_entity_decode( get_the_title( $p ), ENT_QUOTES, 'UTF-8' ), 'url' => $info['url'], 'desc' => $info['desc'] ) );
}
function rzd_nav_term_item( $t, $label = '' ) {
	$info = rzd_nav_object_info( 'taxonomy', $t->taxonomy, $t->term_id );
	return array_merge( rzd_nav_item_defaults(), array( 'type' => 'taxonomy', 'object' => $t->taxonomy, 'object_id' => $t->term_id, 'label' => '' !== $label ? $label : html_entity_decode( $t->name, ENT_QUOTES, 'UTF-8' ), 'url' => $info['url'], 'desc' => $info['desc'] ) );
}

// Gotowe pozycje dla restauracji (te, które w sklepie istnieją).
function rzd_nav_quick_items() {
	$q    = array();
	$page = function ( $id, $label, $hint ) use ( &$q ) {
		$p = $id ? get_post( $id ) : null;
		if ( $p && 'publish' === $p->post_status ) {
			$q[] = array( 'hint' => $hint, 'item' => rzd_nav_post_item( $p, $label ) );
		}
	};
	$q[] = array( 'hint' => 'strona główna', 'item' => array_merge( rzd_nav_item_defaults(), array( 'label' => 'Strona główna', 'url' => home_url( '/' ), 'desc' => 'Link' ) ) );
	if ( function_exists( 'rzd_page_url_opt' ) ) {
		rzd_page_url_opt( 'rzd_list_page_id', 'lista_zamowien' );
		$page( (int) get_option( 'rzd_list_page_id' ), 'Zamów', 'lista dań z zamawianiem' );
	}
	foreach ( get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false, 'search' => 'zestaw', 'number' => 1 ) ) as $t ) {
		if ( ! is_wp_error( $t ) ) {
			$q[] = array( 'hint' => 'kategoria', 'item' => rzd_nav_term_item( $t ) );
		}
	}
	if ( function_exists( 'wc_get_page_id' ) ) {
		$page( (int) wc_get_page_id( 'cart' ), 'Koszyk', 'z licznikiem – Sklep → Koszyk' );
		$page( (int) wc_get_page_id( 'myaccount' ), 'Moje konto', 'logowanie i zamówienia klienta' );
	}
	$kontakt = get_posts( array( 'post_type' => 'page', 'post_status' => 'publish', 's' => '[rzd_kontakt', 'numberposts' => 5 ) );
	foreach ( $kontakt as $p ) {
		if ( has_shortcode( (string) $p->post_content, 'rzd_kontakt' ) ) {
			$q[] = array( 'hint' => 'strona z formularzem kontaktowym', 'item' => rzd_nav_post_item( $p ) );
		}
	}
	return $q;
}

/** Wyszukiwanie stron, produktów, wpisów i kategorii do dodania ($s = '' – strony i kategorie produktów). */
function rzd_nav_search_items( $s ) {
	$s   = sanitize_text_field( (string) $s );
	$out = array();
	$pts = array( 'page' => 'Strony', 'product' => 'Produkty', 'post' => 'Wpisy' );
	foreach ( $pts as $pt => $label ) {
		if ( ! post_type_exists( $pt ) ) {
			continue;
		}
		$args = array( 'post_type' => $pt, 'post_status' => 'publish', 'numberposts' => '' === $s ? ( 'page' === $pt ? 30 : 0 ) : 15, 'orderby' => '' === $s ? 'title' : 'relevance', 'order' => 'ASC' );
		if ( '' !== $s ) {
			$args['s'] = $s;
		}
		if ( 0 === $args['numberposts'] ) {
			continue;
		}
		$rows = array_map( 'rzd_nav_post_item', get_posts( $args ) );
		if ( $rows ) {
			$out[] = array( 'group' => $label, 'items' => $rows );
		}
	}
	foreach ( array( 'product_cat' => 'Kategorie produktów', 'category' => 'Kategorie wpisów' ) as $tx => $label ) {
		if ( ! taxonomy_exists( $tx ) || ( 'category' === $tx && '' === $s ) ) {
			continue;
		}
		$terms = get_terms( array( 'taxonomy' => $tx, 'hide_empty' => false, 'number' => 50, 'search' => $s ) );
		$rows  = is_wp_error( $terms ) ? array() : array_map( 'rzd_nav_term_item', $terms );
		if ( $rows ) {
			$out[] = array( 'group' => $label, 'items' => $rows );
		}
	}
	return $out;
}

// Polski opis położenia motywu (nazwy położeń motywy podają zwykle po angielsku).
function rzd_nav_location_hint( $slug ) {
	$s = strtolower( $slug );
	if ( false !== strpos( $s, 'mobile' ) || false !== strpos( $s, 'off' ) || false !== strpos( $s, 'handheld' ) ) {
		return 'menu na telefonie';
	}
	if ( false !== strpos( $s, 'footer' ) ) {
		return 'stopka';
	}
	if ( false !== strpos( $s, 'account' ) || false !== strpos( $s, 'logged' ) ) {
		return 'menu konta (zalogowani)';
	}
	if ( false !== strpos( $s, 'secondary' ) ) {
		return 'drugie menu w nagłówku';
	}
	if ( false !== strpos( $s, 'primary' ) || false !== strpos( $s, 'main' ) || false !== strpos( $s, 'header' ) ) {
		return 'główne menu w nagłówku';
	}
	return '';
}

/* ============================================================
 * 2. WYBÓR I ZAPIS MENU
 * ============================================================ */
/** Menu na start edytora: z nagłówka (motyw blokowy) / pierwsze z położeniem (klasyczny) / pierwsze. */
function rzd_nav_default_menu() {
	$menus = rzd_nav_menus();
	if ( rzd_nav_block_mode() ) {
		$ref = rzd_nav_header_ref();
		if ( $ref > 0 && isset( $menus[ $ref ] ) ) {
			return $ref;
		}
	} else {
		foreach ( get_nav_menu_locations() as $m ) {
			if ( $m && isset( $menus[ $m ] ) ) {
				return (int) $m;
			}
		}
	}
	return $menus ? (int) key( $menus ) : 0;
}

/**
 * Zapis z edytora: drzewo, położenia (motyw klasyczny; null = bez zmian), nazwa ('' = bez zmian).
 * Zwraca true albo WP_Error.
 */
function rzd_nav_save_all( $menu, $rows, $locations = null, $name = '' ) {
	$menu = (int) $menu;
	if ( ! isset( rzd_nav_menus()[ $menu ] ) ) {
		return new WP_Error( 'rzd_nav', 'Nie ma takiego menu.' );
	}
	$r = rzd_nav_save( $menu, is_array( $rows ) ? $rows : array() );
	if ( is_wp_error( $r ) ) {
		return $r;
	}
	if ( null !== $locations && ! rzd_nav_block_mode() ) {
		rzd_nav_set_locations( $menu, array_map( 'sanitize_key', (array) $locations ) );
	}
	$name = sanitize_text_field( (string) $name );
	if ( '' !== $name && $name !== rzd_nav_menus()[ $menu ] ) {
		if ( rzd_nav_block_mode() ) {
			wp_update_post( array( 'ID' => $menu, 'post_title' => $name ) );
		} else {
			wp_update_nav_menu_object( $menu, array( 'menu-name' => $name ) );
		}
	}
	return true;
}
