<?php
/**
 * Moduł 31 – część 3: panel Restauracja → Menu strony.
 * Z lewej „Dodaj” (gotowe pozycje restauracji, wyszukiwanie treści, własny link, telefon), z prawej drzewo menu
 * (przeciąganie myszą i palcem, w prawo = podmenu, strzałki z klawiatury, nazwa do zmiany w miejscu, ustawienia pozycji).
 * Zapis jednym przyciskiem; do zapisu nic nie zmienia się na stronie.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function rzd_nav_flash( $text, $type = 'success' ) {
	set_transient( 'rzd_nav_flash_' . get_current_user_id(), array( 'text' => $text, 'type' => $type ), 120 );
}
function rzd_nav_back( $menu = 0 ) {
	wp_safe_redirect( admin_url( 'admin.php?page=rzd-menu-strony' . ( $menu ? '&menu=' . (int) $menu : '' ) ) );
	exit;
}
function rzd_nav_guard( $nonce ) {
	if ( ! rzd_nav_can() ) {
		wp_die( 'Brak uprawnień.' );
	}
	check_admin_referer( $nonce );
}

/* ============================================================
 * 1. POZYCJE DO DODANIA
 * ============================================================ */
function rzd_nav_post_item( $p, $label = '' ) {
	$info = rzd_nav_object_info( 'post_type', $p->post_type, $p->ID );
	return array_merge( rzd_nav_item_defaults(), array( 'type' => 'post_type', 'object' => $p->post_type, 'object_id' => $p->ID, 'label' => '' !== $label ? $label : html_entity_decode( get_the_title( $p ), ENT_QUOTES, 'UTF-8' ), 'url' => $info['url'], 'desc' => $info['desc'] ) );
}
function rzd_nav_term_item( $t, $label = '' ) {
	$info = rzd_nav_object_info( 'taxonomy', $t->taxonomy, $t->term_id );
	return array_merge( rzd_nav_item_defaults(), array( 'type' => 'taxonomy', 'object' => $t->taxonomy, 'object_id' => $t->term_id, 'label' => '' !== $label ? $label : html_entity_decode( $t->name, ENT_QUOTES, 'UTF-8' ), 'url' => $info['url'], 'desc' => $info['desc'] ) );
}

// Gotowe pozycje dla restauracji (te, które w sklepie istnieją).
function rzd_nav_quick_items() {
	$q    = array();
	$page = function ( $id, $label, $hint ) use ( &$q ) {
		$p = $id ? get_post( $id ) : null;
		if ( $p && 'publish' === $p->post_status ) {
			$q[] = array( 'hint' => $hint, 'item' => rzd_nav_post_item( $p, $label ) );
		}
	};
	$q[] = array( 'hint' => 'strona główna', 'item' => array_merge( rzd_nav_item_defaults(), array( 'label' => 'Strona główna', 'url' => home_url( '/' ), 'desc' => 'Link' ) ) );
	if ( function_exists( 'rzd_page_url_opt' ) ) {
		rzd_page_url_opt( 'rzd_list_page_id', 'lista_zamowien' );
		$page( (int) get_option( 'rzd_list_page_id' ), 'Zamów', 'lista dań z zamawianiem' );
	}
	foreach ( get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false, 'search' => 'zestaw', 'number' => 1 ) ) as $t ) {
		if ( ! is_wp_error( $t ) ) {
			$q[] = array( 'hint' => 'kategoria', 'item' => rzd_nav_term_item( $t ) );
		}
	}
	if ( function_exists( 'wc_get_page_id' ) ) {
		$page( (int) wc_get_page_id( 'cart' ), 'Koszyk', 'z licznikiem – Restauracja → Koszyk' );
		$page( (int) wc_get_page_id( 'myaccount' ), 'Moje konto', 'logowanie i zamówienia klienta' );
	}
	$kontakt = get_posts( array( 'post_type' => 'page', 'post_status' => 'publish', 's' => '[rzd_kontakt', 'numberposts' => 5 ) );
	foreach ( $kontakt as $p ) {
		if ( has_shortcode( (string) $p->post_content, 'rzd_kontakt' ) ) {
			$q[] = array( 'hint' => 'strona z formularzem kontaktowym', 'item' => rzd_nav_post_item( $p ) );
		}
	}
	return $q;
}

add_action( 'wp_ajax_rzd_nav_search', function () {
	if ( ! rzd_nav_can() || ! check_ajax_referer( 'rzd_nav', '_ajax_nonce', false ) ) {
		wp_send_json_error();
	}
	$s   = isset( $_POST['q'] ) ? sanitize_text_field( wp_unslash( $_POST['q'] ) ) : ''; // phpcs:ignore
	$out = array();
	$pts = array( 'page' => 'Strony', 'product' => 'Produkty', 'post' => 'Wpisy' );
	foreach ( $pts as $pt => $label ) {
		if ( ! post_type_exists( $pt ) ) {
			continue;
		}
		$args = array( 'post_type' => $pt, 'post_status' => 'publish', 'numberposts' => '' === $s ? ( 'page' === $pt ? 30 : 0 ) : 15, 'orderby' => '' === $s ? 'title' : 'relevance', 'order' => 'ASC' );
		if ( '' !== $s ) {
			$args['s'] = $s;
		}
		if ( 0 === $args['numberposts'] ) {
			continue;
		}
		$rows = array_map( 'rzd_nav_post_item', get_posts( $args ) );
		if ( $rows ) {
			$out[] = array( 'group' => $label, 'items' => $rows );
		}
	}
	foreach ( array( 'product_cat' => 'Kategorie produktów', 'category' => 'Kategorie wpisów' ) as $tx => $label ) {
		if ( ! taxonomy_exists( $tx ) || ( 'category' === $tx && '' === $s ) ) {
			continue;
		}
		$terms = get_terms( array( 'taxonomy' => $tx, 'hide_empty' => false, 'number' => 50, 'search' => $s ) );
		$rows  = is_wp_error( $terms ) ? array() : array_map( 'rzd_nav_term_item', $terms );
		if ( $rows ) {
			$out[] = array( 'group' => $label, 'items' => $rows );
		}
	}
	wp_send_json_success( $out );
} );

// Polski opis położenia motywu (nazwy położeń motywy podają zwykle po angielsku).
function rzd_nav_location_hint( $slug ) {
	$s = strtolower( $slug );
	if ( false !== strpos( $s, 'mobile' ) || false !== strpos( $s, 'off' ) || false !== strpos( $s, 'handheld' ) ) {
		return 'menu na telefonie';
	}
	if ( false !== strpos( $s, 'footer' ) ) {
		return 'stopka';
	}
	if ( false !== strpos( $s, 'account' ) || false !== strpos( $s, 'logged' ) ) {
		return 'menu konta (zalogowani)';
	}
	if ( false !== strpos( $s, 'secondary' ) ) {
		return 'drugie menu w nagłówku';
	}
	if ( false !== strpos( $s, 'primary' ) || false !== strpos( $s, 'main' ) || false !== strpos( $s, 'header' ) ) {
		return 'główne menu w nagłówku';
	}
	return '';
}

/* ============================================================
 * 2. AKCJE
 * ============================================================ */
add_action( 'admin_post_rzd_nav_save', function () {
	rzd_nav_guard( 'rzd_nav_save' );
	$menu = isset( $_POST['menu'] ) ? absint( $_POST['menu'] ) : 0; // phpcs:ignore
	if ( ! isset( rzd_nav_menus()[ $menu ] ) ) {
		rzd_nav_flash( 'Nie ma takiego menu.', 'error' );
		rzd_nav_back();
	}
	$rows = json_decode( isset( $_POST['tree'] ) ? wp_unslash( $_POST['tree'] ) : '[]', true ); // phpcs:ignore -- czyszczone w rzd_nav_sanitize_tree
	$r    = rzd_nav_save( $menu, is_array( $rows ) ? $rows : array() );
	if ( is_wp_error( $r ) ) {
		rzd_nav_flash( 'Nie zapisano: ' . $r->get_error_message(), 'error' );
		rzd_nav_back( $menu );
	}
	if ( ! rzd_nav_block_mode() ) {
		rzd_nav_set_locations( $menu, array_map( 'sanitize_key', (array) ( isset( $_POST['locations'] ) ? wp_unslash( $_POST['locations'] ) : array() ) ) ); // phpcs:ignore
	}
	if ( isset( $_POST['menu_name'] ) ) { // phpcs:ignore
		$name = sanitize_text_field( wp_unslash( $_POST['menu_name'] ) ); // phpcs:ignore
		if ( '' !== $name ) {
			if ( rzd_nav_block_mode() ) {
				wp_update_post( array( 'ID' => $menu, 'post_title' => $name ) );
			} else {
				wp_update_nav_menu_object( $menu, array( 'menu-name' => $name ) );
			}
		}
	}
	rzd_nav_flash( 'Zapisano menu – zmiany są już na stronie.' );
	rzd_nav_back( $menu );
} );
add_action( 'admin_post_rzd_nav_new', function () {
	rzd_nav_guard( 'rzd_nav_new' );
	$copy = isset( $_POST['copy'] ) ? absint( $_POST['copy'] ) : 0; // phpcs:ignore
	$name = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : ''; // phpcs:ignore
	if ( $copy && '' === $name && isset( rzd_nav_menus()[ $copy ] ) ) {
		$name = rzd_nav_menus()[ $copy ] . ' (kopia)';
	}
	$id = rzd_nav_create( $name, $copy && isset( rzd_nav_menus()[ $copy ] ) ? $copy : 0 );
	if ( is_wp_error( $id ) ) {
		rzd_nav_flash( 'Nie utworzono menu: ' . $id->get_error_message(), 'error' );
		rzd_nav_back();
	}
	rzd_nav_flash( $copy ? 'Utworzono kopię menu.' : 'Utworzono menu – dodaj pozycje z lewej i zapisz.' );
	rzd_nav_back( $id );
} );
add_action( 'admin_post_rzd_nav_delete', function () {
	rzd_nav_guard( 'rzd_nav_delete' );
	$id = isset( $_POST['menu'] ) ? absint( $_POST['menu'] ) : 0; // phpcs:ignore
	if ( isset( rzd_nav_menus()[ $id ] ) && rzd_nav_delete( $id ) ) {
		rzd_nav_flash( 'Usunięto menu.' . ( rzd_nav_block_mode() ? ' (Jest w koszu – WordPress usunie je po 30 dniach.)' : '' ) );
	}
	rzd_nav_back();
} );
add_action( 'admin_post_rzd_nav_header', function () {
	rzd_nav_guard( 'rzd_nav_header' );
	$id = isset( $_POST['menu'] ) ? absint( $_POST['menu'] ) : 0; // phpcs:ignore
	$r  = isset( rzd_nav_menus()[ $id ] ) ? rzd_nav_use_in_header( $id ) : new WP_Error( 'rzd_nav', 'Nie ma takiej nawigacji.' );
	rzd_nav_flash( is_wp_error( $r ) ? $r->get_error_message() : 'Nagłówek strony pokazuje teraz to menu.', is_wp_error( $r ) ? 'error' : 'success' );
	rzd_nav_back( $id );
} );

/* ============================================================
 * 3. STRONA
 * ============================================================ */
add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( ! rzd_is_admin_page( $hook, 'rzd-menu-strony' ) ) {
		return;
	}
	wp_enqueue_script( 'rzd-menu-strony', RZD_PLUGIN_URL . 'assets/js/admin/rzd-menu-strony.js', array( 'jquery', 'jquery-ui-sortable', 'jquery-touch-punch' ), rzd_asset_ver( 'assets/js/admin/rzd-menu-strony.js' ), true );
	wp_enqueue_style( 'rzd-menu-strony', RZD_PLUGIN_URL . 'assets/css/admin/rzd-menu-strony.css', array(), rzd_asset_ver( 'assets/css/admin/rzd-menu-strony.css' ) );
} );

function rzd_nav_admin_page() {
	if ( ! rzd_nav_can() ) {
		wp_die( 'Brak uprawnień.' );
	}
	$menus = rzd_nav_menus();
	$block = rzd_nav_block_mode();
	$cur   = isset( $_GET['menu'] ) ? absint( $_GET['menu'] ) : 0; // phpcs:ignore -- wybór menu
	if ( ! isset( $menus[ $cur ] ) ) {
		$cur = 0;
		if ( $block ) {
			$ref = rzd_nav_header_ref();
			$cur = $ref > 0 && isset( $menus[ $ref ] ) ? $ref : 0;
		} else {
			foreach ( get_nav_menu_locations() as $m ) {
				if ( $m && isset( $menus[ $m ] ) ) {
					$cur = (int) $m;
					break;
				}
			}
		}
		if ( ! $cur && $menus ) {
			$cur = (int) key( $menus );
		}
	}
	$flash = get_transient( 'rzd_nav_flash_' . get_current_user_id() );
	if ( $flash ) {
		delete_transient( 'rzd_nav_flash_' . get_current_user_id() );
	}
	$theme = wp_get_theme();
	$post  = function ( $action, $fields, $label, $cls = 'button', $confirm = '' ) {
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline"' . ( $confirm ? ' onsubmit="return confirm(\'' . esc_js( $confirm ) . '\')"' : '' ) . '><input type="hidden" name="action" value="' . esc_attr( $action ) . '">';
		foreach ( $fields as $k => $v ) {
			echo '<input type="hidden" name="' . esc_attr( $k ) . '" value="' . esc_attr( $v ) . '">';
		}
		wp_nonce_field( $action );
		echo '<button class="' . esc_attr( $cls ) . '">' . esc_html( $label ) . '</button></form> ';
	};
	?>
	<div class="wrap rzd-nav-admin">
		<h1 class="wp-heading-inline">Menu strony</h1>
		<?php if ( $flash ) : ?><div class="notice notice-<?php echo esc_attr( $flash['type'] ); ?> is-dismissible"><p><?php echo esc_html( $flash['text'] ); ?></p></div><?php endif; ?>
		<p class="description" style="max-width:960px">Motyw <strong><?php echo esc_html( $theme->get( 'Name' ) ); ?></strong> –
			<?php echo $block ? 'motyw blokowy: edytujesz nawigacje bloku Nawigacja (te same co w Wygląd → Edytor).' : 'motyw klasyczny: edytujesz te same menu co w Wygląd → Menu, położenie (nagłówek, stopka…) wybierasz pod menu.'; ?>
			Zmiany trafiają na stronę dopiero po „Zapisz menu”.</p>

		<div class="rzd-nav-bar">
			<?php if ( $menus ) : ?>
				<form method="get" class="rzd-nav-pick"><input type="hidden" name="page" value="rzd-menu-strony">
					<label for="rzd-nav-menu"><strong>Menu:</strong></label>
					<select id="rzd-nav-menu" name="menu" onchange="this.form.submit()">
						<?php foreach ( $menus as $id => $name ) : ?><option value="<?php echo (int) $id; ?>" <?php selected( $cur, $id ); ?>><?php echo esc_html( $name ); ?></option><?php endforeach; ?>
					</select>
					<noscript><button class="button">Pokaż</button></noscript>
				</form>
				<?php $post( 'rzd_nav_new', array( 'copy' => $cur ), 'Kopiuj' ); ?>
				<?php $post( 'rzd_nav_delete', array( 'menu' => $cur ), 'Usuń', 'button button-link-delete', 'Usunąć menu „' . $menus[ $cur ] . '”?' ); ?>
			<?php endif; ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="rzd-nav-newform"><input type="hidden" name="action" value="rzd_nav_new"><?php wp_nonce_field( 'rzd_nav_new' ); ?>
				<input type="text" name="name" placeholder="nazwa nowego menu" aria-label="Nazwa nowego menu"> <button class="button">+ Nowe menu</button></form>
		</div>

		<?php if ( ! $menus ) : ?>
			<p>Nie ma jeszcze żadnego menu – utwórz pierwsze powyżej.</p>
		<?php else :
			$rows = rzd_nav_read( $cur );
			?>
		<div class="rzd-nav-cols">
			<div class="rzd-nav-add" aria-label="Dodaj do menu">
				<h2>Dodaj</h2>
				<h3>Gotowe pozycje</h3>
				<ul class="rzd-nav-quick">
					<?php foreach ( rzd_nav_quick_items() as $qi ) : ?>
						<li><button type="button" class="button rzd-nav-addbtn" data-item="<?php echo esc_attr( wp_json_encode( $qi['item'] ) ); ?>">+ <?php echo esc_html( $qi['item']['label'] ); ?></button> <small><?php echo esc_html( $qi['hint'] ); ?></small></li>
					<?php endforeach; ?>
				</ul>
				<h3><label for="rzd-nav-q">Strony, kategorie, produkty</label></h3>
				<input type="search" id="rzd-nav-q" class="widefat" placeholder="szukaj… (puste = strony i kategorie)">
				<div id="rzd-nav-results" class="rzd-nav-results" aria-live="polite"></div>
				<h3>Własny link</h3>
				<p><input type="text" id="rzd-nav-cl-label" class="widefat" placeholder="napis, np. Facebook"></p>
				<p><input type="text" id="rzd-nav-cl-url" class="widefat" placeholder="adres, np. facebook.com/… albo /strona/ albo #sekcja"></p>
				<p><button type="button" class="button" id="rzd-nav-cl-add">+ Dodaj link</button></p>
				<h3>Zadzwoń</h3>
				<p><input type="tel" id="rzd-nav-tel" class="widefat" placeholder="numer, np. 600 100 200"></p>
				<p><button type="button" class="button" id="rzd-nav-tel-add">+ Dodaj „Zadzwoń”</button> <small>na telefonie otwiera wybieranie numeru</small></p>
			</div>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="rzd-nav-main" id="rzd-nav-form">
				<input type="hidden" name="action" value="rzd_nav_save"><input type="hidden" name="menu" value="<?php echo (int) $cur; ?>">
				<?php wp_nonce_field( 'rzd_nav_save' ); ?>
				<input type="hidden" name="tree" id="rzd-nav-tree" value="<?php echo esc_attr( wp_json_encode( $rows ) ); ?>">
				<div class="rzd-nav-head">
					<label>Nazwa menu: <input type="text" name="menu_name" value="<?php echo esc_attr( $menus[ $cur ] ); ?>"></label>
					<span class="rzd-nav-state" id="rzd-nav-state" aria-live="polite"></span>
				</div>
				<p class="description">Przeciągnij za ☰ (myszą albo palcem); przesunięcie w prawo = podmenu. Klawiatura: na ☰ strzałki ↑ ↓ przesuwają, ← → zmieniają poziom. Kliknij nazwę, aby ją zmienić; ⚙ – ustawienia pozycji.</p>
				<ul id="rzd-nav-list" class="rzd-nav-list" data-max-depth="<?php echo (int) RZD_NAV_MAX_DEPTH; ?>"></ul>
				<p class="rzd-nav-empty" id="rzd-nav-empty" hidden>Menu jest puste – dodaj pozycje z lewej.</p>

				<?php if ( ! $block ) : $locs = rzd_nav_locations(); $now = get_nav_menu_locations(); ?>
					<?php if ( $locs ) : ?>
					<fieldset class="rzd-nav-locs"><legend><strong>Gdzie pokazać to menu</strong> (położenia motywu)</legend>
						<?php foreach ( $locs as $slug => $label ) : $other = ! empty( $now[ $slug ] ) && (int) $now[ $slug ] !== $cur && isset( $menus[ $now[ $slug ] ] ) ? $menus[ $now[ $slug ] ] : ''; ?>
							<label><input type="checkbox" name="locations[]" value="<?php echo esc_attr( $slug ); ?>" <?php checked( ! empty( $now[ $slug ] ) && (int) $now[ $slug ] === $cur ); ?>> <?php echo esc_html( $label ); ?><?php echo rzd_nav_location_hint( $slug ) ? ' <small>– ' . esc_html( rzd_nav_location_hint( $slug ) ) . '</small>' : ''; ?><?php echo $other ? ' <small>(teraz: ' . esc_html( $other ) . ')</small>' : ''; ?></label>
						<?php endforeach; ?>
						<?php if ( isset( $locs['primary'], $locs['mobile_menu'] ) && empty( $now['mobile_menu'] ) ) : ?>
							<p class="description">Astra na telefonie pokazuje menu z położenia „<?php echo esc_html( $locs['mobile_menu'] ); ?>” – bez niego zamiast menu jest lista wszystkich stron. Zaznacz je razem z nagłówkiem.</p>
						<?php endif; ?>
					</fieldset>
					<?php endif; ?>
				<?php else : $ref = rzd_nav_header_ref(); ?>
					<p class="rzd-nav-locs"><?php echo $ref === $cur ? '✅ To menu jest w nagłówku strony.' : ( rzd_nav_header_template() ? 'To menu nie jest w nagłówku strony.' : '' ); ?></p>
				<?php endif; ?>

				<p class="rzd-nav-actions">
					<button type="submit" class="button button-primary button-large" id="rzd-nav-save">Zapisz menu</button>
					<button type="button" class="button" id="rzd-nav-undo" disabled>Cofnij zmiany</button>
					<a class="button" href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank" rel="noopener">Zobacz na stronie ↗</a>
				</p>
			</form>
		</div>
		<?php if ( $block && rzd_nav_header_template() && rzd_nav_header_ref() !== $cur ) : ?>
			<p><?php $post( 'rzd_nav_header', array( 'menu' => $cur ), 'Pokaż to menu w nagłówku strony', 'button', 'Nagłówek strony będzie pokazywał menu „' . $menus[ $cur ] . '”. Kontynuować?' ); ?> <span class="description">zmienia blok Nawigacja w nagłówku motywu (jak w edytorze witryny)</span></p>
		<?php endif; ?>
		<?php endif; ?>
	</div>
	<script>var rzdNav = <?php echo wp_json_encode( array( 'ajax' => admin_url( 'admin-ajax.php' ), 'nonce' => wp_create_nonce( 'rzd_nav' ), 'max' => RZD_NAV_MAX_DEPTH ) ); ?>;</script>
	<?php
}
