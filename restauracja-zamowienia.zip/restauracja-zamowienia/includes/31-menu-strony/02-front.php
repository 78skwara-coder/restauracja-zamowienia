<?php
/**
 * Moduł 31 – część 2: dodatki edytora na stronie (oba rodzaje motywów).
 * - rzd-nav-in / rzd-nav-out: pozycja (z podmenu) tylko dla zalogowanych / gości;
 * - rzd-nav-cta: pozycja jako przycisk w kolorze akcentu („Wygląd listy”);
 * - rzd-nav-hide-mobile / -desktop: ukrycie na telefonie / komputerze (próg jak w Astrze: 921 px, filtr rzd_nav_breakpoint);
 * - motyw blokowy: pozycja „Koszyk” z licznikiem jak w menu motywu klasycznego (ustawienia: Panel restauracji → Sklep → Koszyk).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function rzd_nav_visible( $classes ) {
	$c = is_array( $classes ) ? $classes : preg_split( '/\s+/', (string) $classes );
	if ( in_array( 'rzd-nav-in', $c, true ) && ! is_user_logged_in() ) {
		return false;
	}
	if ( in_array( 'rzd-nav-out', $c, true ) && is_user_logged_in() ) {
		return false;
	}
	return true;
}

// Motyw klasyczny: ukryte pozycje razem z ich podmenu.
add_filter( 'wp_nav_menu_objects', function ( $items ) {
	if ( is_admin() ) {
		return $items;
	}
	$gone = array();
	$out  = array();
	foreach ( $items as $it ) { // WordPress podaje rodzica przed dziećmi
		if ( in_array( (int) $it->menu_item_parent, $gone, true ) || ! rzd_nav_visible( (array) $it->classes ) ) {
			$gone[] = (int) $it->ID;
			continue;
		}
		$out[] = $it;
	}
	return $out;
}, 20 );

// Motyw blokowy: widoczność i licznik koszyka.
add_filter( 'render_block', function ( $html, $block ) {
	if ( ! in_array( $block['blockName'], array( 'core/navigation-link', 'core/navigation-submenu' ), true ) ) {
		return $html;
	}
	$a = $block['attrs'];
	if ( ! rzd_nav_visible( isset( $a['className'] ) ? $a['className'] : '' ) ) {
		return '';
	}
	return $html;
}, 10, 2 );
add_filter( 'render_block_data', function ( $block ) {
	if ( 'core/navigation-link' !== $block['blockName'] || is_admin() || ! function_exists( 'wc_get_cart_url' ) || ! function_exists( 'rzd_koszyk_get_settings' ) ) {
		return $block;
	}
	$a       = $block['attrs'];
	$s       = rzd_koszyk_get_settings();
	$cart_id = (int) wc_get_page_id( 'cart' );
	$is_cart = ( isset( $a['kind'], $a['id'] ) && 'post-type' === $a['kind'] && (int) $a['id'] === $cart_id ) || ( ! empty( $a['url'] ) && untrailingslashit( $a['url'] ) === untrailingslashit( wc_get_cart_url() ) );
	if ( $is_cart && ! empty( $s['menu_replace'] ) ) {
		$block['attrs']['label'] = rzd_koszyk_render( 'menu' );
	}
	return $block;
} );

// CSS dodatków – tylko gdy któreś menu ich używa.
add_action( 'wp_head', function () {
	if ( ! get_option( 'rzd_nav_css' ) ) {
		return;
	}
	$st  = function_exists( 'rzd_list_style_get' ) ? rzd_list_style_get() : array();
	$acc = isset( $st['button_border_color'] ) && sanitize_hex_color( $st['button_border_color'] ) ? sanitize_hex_color( $st['button_border_color'] ) : '#c08a2e';
	$txt = function_exists( 'rzd_kf_contrast' ) ? rzd_kf_contrast( $acc ) : '#ffffff';
	$rad = isset( $st['button_radius'] ) && '' !== (string) $st['button_radius'] ? max( 0, min( 30, (int) $st['button_radius'] ) ) : 8;
	$bp  = (int) apply_filters( 'rzd_nav_breakpoint', 921 );
	echo '<style id="rzd-nav-css">'
		. 'li.menu-item.rzd-nav-cta>a,li.wp-block-navigation-item.rzd-nav-cta>a,li.rzd-nav-cta>.wp-block-navigation-item__content{background:' . esc_attr( $acc ) . ';color:' . esc_attr( $txt ) . ' !important;border-radius:' . (int) $rad . 'px;padding:.6em 1.2em !important;line-height:1.2 !important;height:auto !important;min-height:0 !important;align-self:center;margin:0 .35em;font-weight:700;text-decoration:none}'
		. 'li.menu-item.rzd-nav-cta>a:hover,li.wp-block-navigation-item.rzd-nav-cta>a:hover{filter:brightness(1.08);color:' . esc_attr( $txt ) . ' !important}'
		. 'li.menu-item.rzd-nav-cta,li.wp-block-navigation-item.rzd-nav-cta{display:flex;align-items:center}'
		. '@media (max-width:' . ( $bp - 1 ) . 'px){.rzd-nav-hide-mobile{display:none !important}}'
		. '@media (min-width:' . $bp . 'px){.rzd-nav-hide-desktop{display:none !important}}'
		. '</style>' . "\n";
}, 20 );
