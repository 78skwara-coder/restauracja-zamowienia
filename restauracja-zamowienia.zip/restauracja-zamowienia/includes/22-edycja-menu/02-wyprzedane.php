<?php
/**
 * Moduł 22-edycja-menu – wyprzedane wg dnia dostawy.
 * Część modułu (pliki wczytywane po kolei – kolejność jak w dawnym jednym pliku).
 */

/* ============================================================
 * 2. WYPRZEDANE (wg dnia dostawy)
 * ============================================================ */
function rzd_soldout_get( $pid ) {
	$s = get_post_meta( (int) $pid, '_rzd_soldout', true );
	$s = is_array( $s ) ? $s : array();
	return array(
		'always' => empty( $s['always'] ) ? 0 : 1,
		'dates'  => isset( $s['dates'] ) ? array_values( array_filter( (array) $s['dates'], function ( $d ) { return is_string( $d ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $d ); } ) ) : array(),
	);
}

function rzd_soldout_on( $pid, $date ) {
	$s = rzd_soldout_get( $pid );
	return $s['always'] || in_array( (string) $date, $s['dates'], true );
}

// Produkt albo zestaw (zestaw: sam albo którekolwiek jego danie w tym dniu).
function rzd_soldout_effective( $pid, $date ) {
	static $memo = array();
	$k = (int) $pid . '|' . $date;
	if ( isset( $memo[ $k ] ) ) {
		return $memo[ $k ];
	}
	$out = rzd_soldout_on( $pid, $date );
	if ( ! $out && function_exists( 'rwz_get_slots' ) && rwz_get_slots( $pid ) && function_exists( 'rwz_get_active_components' ) ) {
		$a = rwz_get_active_components( $pid, $date );
		foreach ( (array) $a['main'] as $p ) {
			if ( (int) $p->get_id() !== (int) $pid && rzd_soldout_on( $p->get_id(), $date ) ) {
				$out = true;
				break;
			}
		}
	}
	return $memo[ $k ] = $out;
}

function rzd_soldout_save( $pid, $always, $dates ) {
	$today = function_exists( 'dc_now' ) ? dc_now()->format( 'Y-m-d' ) : current_time( 'Y-m-d' );
	$dates = array_values( array_unique( array_filter( (array) $dates, function ( $d ) use ( $today ) {
		return is_string( $d ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $d ) && $d >= $today; // minione dni wypadają same
	} ) ) );
	sort( $dates );
	if ( ! $always && ! $dates ) {
		delete_post_meta( $pid, '_rzd_soldout' );
	} else {
		update_post_meta( $pid, '_rzd_soldout', array( 'always' => $always ? 1 : 0, 'dates' => $dates ) );
	}
}

// Kalendarz dostaw (moduł 06): wyprzedane w tym dniu = niedostępne (lista, okienko terminu, koszyk, kasa).
add_filter( 'dc_product_available_on', function ( $ok, $pid, $date ) {
	return ( $ok && rzd_soldout_effective( $pid, $date ) ) ? false : $ok;
}, 10, 3 );

// „Do odwołania” – nie do kupienia w ogóle (też bez kalendarza dostaw).
add_filter( 'woocommerce_is_purchasable', function ( $can, $product ) {
	if ( $can && $product && is_object( $product ) ) {
		$s = rzd_soldout_get( $product->get_parent_id() ? $product->get_parent_id() : $product->get_id() );
		if ( $s['always'] ) {
			return false;
		}
	}
	return $can;
}, 10, 2 );

