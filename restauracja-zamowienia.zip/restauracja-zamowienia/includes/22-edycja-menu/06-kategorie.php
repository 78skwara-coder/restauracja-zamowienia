<?php
/**
 * Moduł 22-edycja-menu – KATEGORIE (2.40.0).
 *
 * Zakładka „Kategorie” na stronie edycji menu i wybór kategorii przy daniu.
 * Uprawnienie „Kategorie” (rzd_p_cats, konfigurator – moduł 25); sama strona
 * wymaga też „Edycji menu” (rzd_ed_guard).
 *
 * Kategoria = taksonomia WooCommerce product_cat. Pola trzymane tam, gdzie już
 * są (te same dane co panel WP → Produkty → Kategorie):
 *  - nazwa (adres/slug BEZ zmian – linki w menu i kaflach działają dalej),
 *  - opakowanie standardowe + pojemność (term meta rzd_packaging / rzd_pack_capacity – moduł 21),
 *  - „Nie wyświetlaj w sklepie” (rwz_hide_in_shop – moduł 04),
 *  - kafel: zdjęcie (thumbnail_id – WooCommerce), kolejność (rzd_kategoria_order),
 *    adres docelowy (rzd_kategoria_url – moduł 17).
 * Nowa kategoria – tylko z ekranu komputera (decyzja użytkownika 2026-10-23; pilnuje
 * ekran – serwer nie zna szerokości okna). Usunąć można tylko pustą, bez podkategorii
 * i nie domyślną kategorię WooCommerce.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function rzd_ed_cats_can() {
	return function_exists( 'rzd_can' ) && rzd_can( 'cats' );
}

function rzd_ed_cats_guard() {
	rzd_ed_guard();
	if ( ! rzd_ed_cats_can() ) {
		wp_send_json_error( array( 'msg' => 'Brak uprawnienia „Kategorie”.' ), 403 );
	}
}

/** Wszystkie kategorie (też puste) w kolejności kafli, z polami do edycji. */
function rzd_ed_cats_all() {
	$terms = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false, 'orderby' => 'name' ) );
	if ( is_wp_error( $terms ) ) {
		return array();
	}
	$terms   = function_exists( 'rzd_kategorie_sort' ) ? rzd_kategorie_sort( $terms ) : $terms;
	$default = (int) get_option( 'default_product_cat', 0 );
	$kids    = array();
	foreach ( $terms as $t ) {
		if ( $t->parent ) {
			$kids[ (int) $t->parent ] = true;
		}
	}
	$out = array();
	foreach ( $terms as $t ) {
		$tid   = (int) $t->term_id;
		$thumb = (int) get_term_meta( $tid, 'thumbnail_id', true );
		$order = get_term_meta( $tid, 'rzd_kategoria_order', true );
		$link  = get_term_link( $t );
		$out[] = array(
			'id'       => $tid,
			'name'     => $t->name,
			'slug'     => $t->slug,
			'parent'   => (int) $t->parent,
			'count'    => (int) $t->count,
			'order'    => '' === (string) $order ? '' : (int) $order,
			'url'      => (string) get_term_meta( $tid, 'rzd_kategoria_url', true ),
			'hide'     => '1' === (string) get_term_meta( $tid, 'rwz_hide_in_shop', true ),
			'pack'     => (int) get_term_meta( $tid, 'rzd_packaging', true ),
			'cap'      => function_exists( 'rzd_pack_capacity_value' ) ? rzd_pack_capacity_value( get_term_meta( $tid, 'rzd_pack_capacity', true ) ) : max( 1, (int) get_term_meta( $tid, 'rzd_pack_capacity', true ) ),
			'thumb'    => rzd_ed_thumb( $thumb, 'medium' ),
			'link'     => is_wp_error( $link ) ? '' : $link,
			'default'  => $tid === $default,
			'has_kids' => isset( $kids[ $tid ] ),
		);
	}
	return $out;
}

/** Opakowania z katalogu (moduł 21) – do wyboru w kategorii. */
function rzd_ed_packagings() {
	$out = array();
	foreach ( function_exists( 'rzd_packaging_all' ) ? rzd_packaging_all() : array() as $p ) {
		$out[] = array( 'id' => (int) $p->ID, 'name' => $p->post_title, 'price' => rzd_ed_money( (float) get_post_meta( $p->ID, '_rzd_pack_price', true ) ) );
	}
	return $out;
}

function rzd_ed_cats_payload() {
	return array( 'cats_all' => rzd_ed_cats_all(), 'packagings' => rzd_ed_packagings() );
}

function rzd_ed_cats_flush() {
	clean_term_cache( array(), 'product_cat' );
	if ( function_exists( 'wc_delete_product_transients' ) ) {
		wc_delete_product_transients();
	}
	rzd_ed_clear_caches();
}

add_action( 'wp_ajax_rzd_ed_cats', function () {
	rzd_ed_cats_guard();
	wp_send_json_success( rzd_ed_cats_payload() );
} );

// Zapis jednej kategorii: tylko przesłane pola.
add_action( 'wp_ajax_rzd_ed_cat_save', function () {
	rzd_ed_cats_guard();
	$tid = absint( rzd_ed_post( 'id', 0 ) );
	$t   = $tid ? get_term( $tid, 'product_cat' ) : null;
	if ( ! $t || is_wp_error( $t ) ) {
		wp_send_json_error( array( 'msg' => 'Nie ma takiej kategorii.' ) );
	}
	$f = json_decode( (string) rzd_ed_post( 'data', '{}' ), true );
	$f = is_array( $f ) ? $f : array();
	if ( isset( $f['name'] ) ) {
		$name = trim( sanitize_text_field( $f['name'] ) );
		if ( '' === $name ) {
			wp_send_json_error( array( 'msg' => 'Nazwa nie może być pusta.' ) );
		}
		if ( $name !== $t->name ) {
			$r = wp_update_term( $tid, 'product_cat', array( 'name' => $name ) ); // slug zostaje – podajemy tylko nazwę
			if ( is_wp_error( $r ) ) {
				wp_send_json_error( array( 'msg' => 'Nie udało się zmienić nazwy: ' . $r->get_error_message() ) );
			}
		}
	}
	if ( array_key_exists( 'hide', $f ) ) {
		if ( ! empty( $f['hide'] ) ) {
			update_term_meta( $tid, 'rwz_hide_in_shop', '1' );
		} else {
			delete_term_meta( $tid, 'rwz_hide_in_shop' );
		}
	}
	if ( array_key_exists( 'pack', $f ) ) {
		$pid = absint( $f['pack'] );
		if ( $pid && ( ! function_exists( 'rzd_packaging_get' ) || ! rzd_packaging_get( $pid ) ) ) {
			wp_send_json_error( array( 'msg' => 'Nie ma takiego opakowania w katalogu.' ) );
		}
		update_term_meta( $tid, 'rzd_packaging', $pid ? $pid : '' ); // jak formularz panelu (moduł 21)
	}
	if ( array_key_exists( 'cap', $f ) ) {
		update_term_meta( $tid, 'rzd_pack_capacity', function_exists( 'rzd_pack_capacity_value' ) ? rzd_pack_capacity_value( $f['cap'] ) : max( 1, (int) $f['cap'] ) );
	}
	if ( array_key_exists( 'url', $f ) ) {
		$url = trim( (string) $f['url'] );
		if ( '' === $url ) {
			delete_term_meta( $tid, 'rzd_kategoria_url' );
		} else {
			$clean = esc_url_raw( $url, array( 'http', 'https' ) );
			if ( '' === $clean ) {
				wp_send_json_error( array( 'msg' => 'Adres kafla musi zaczynać się od https:// (albo zostaw puste).' ) );
			}
			update_term_meta( $tid, 'rzd_kategoria_url', $clean );
		}
	}
	rzd_ed_cats_flush();
	wp_send_json_success( rzd_ed_cats_payload() );
} );

// Kolejność kafli: lista ID od pierwszego; zapis 1, 2, 3… (jak pole „Kolejność kafla” w panelu).
add_action( 'wp_ajax_rzd_ed_cat_order', function () {
	rzd_ed_cats_guard();
	$ids = json_decode( (string) rzd_ed_post( 'ids', '[]' ), true );
	if ( ! is_array( $ids ) || ! $ids ) {
		wp_send_json_error( array( 'msg' => 'Brak kolejności.' ) );
	}
	$n = 0;
	foreach ( array_unique( array_map( 'absint', $ids ) ) as $tid ) {
		if ( $tid && term_exists( $tid, 'product_cat' ) ) {
			update_term_meta( $tid, 'rzd_kategoria_order', ++$n );
		}
	}
	rzd_ed_cats_flush();
	wp_send_json_success( rzd_ed_cats_payload() );
} );

add_action( 'wp_ajax_rzd_ed_cat_new', function () {
	rzd_ed_cats_guard();
	$name = trim( sanitize_text_field( (string) rzd_ed_post( 'name', '' ) ) );
	if ( '' === $name ) {
		wp_send_json_error( array( 'msg' => 'Podaj nazwę kategorii.' ) );
	}
	$r = wp_insert_term( $name, 'product_cat' );
	if ( is_wp_error( $r ) ) {
		wp_send_json_error( array( 'msg' => 'term_exists' === $r->get_error_code() ? 'Kategoria o tej nazwie już jest.' : 'Nie udało się dodać: ' . $r->get_error_message() ) );
	}
	$tid = (int) $r['term_id'];
	// na koniec kolejności kafli
	$max = 0;
	foreach ( rzd_ed_cats_all() as $c ) {
		if ( '' !== $c['order'] ) {
			$max = max( $max, (int) $c['order'] );
		}
	}
	update_term_meta( $tid, 'rzd_kategoria_order', $max + 1 );
	rzd_ed_cats_flush();
	wp_send_json_success( array( 'id' => $tid ) + rzd_ed_cats_payload() );
} );

add_action( 'wp_ajax_rzd_ed_cat_delete', function () {
	rzd_ed_cats_guard();
	$tid = absint( rzd_ed_post( 'id', 0 ) );
	$all = rzd_ed_cats_all();
	$c   = null;
	foreach ( $all as $x ) {
		if ( $x['id'] === $tid ) {
			$c = $x;
		}
	}
	if ( ! $c ) {
		wp_send_json_error( array( 'msg' => 'Nie ma takiej kategorii.' ) );
	}
	if ( $c['default'] ) {
		wp_send_json_error( array( 'msg' => 'To domyślna kategoria WooCommerce – nie da się jej usunąć.' ) );
	}
	if ( $c['has_kids'] ) {
		wp_send_json_error( array( 'msg' => 'Kategoria ma podkategorie – najpierw przenieś je w panelu WP.' ) );
	}
	$cnt = (int) ( new WP_Query( array( 'post_type' => 'product', 'post_status' => 'any', 'fields' => 'ids', 'posts_per_page' => 1, 'no_found_rows' => false, 'tax_query' => array( array( 'taxonomy' => 'product_cat', 'terms' => $tid, 'include_children' => false ) ) ) ) )->found_posts; // phpcs:ignore -- też szkice i prywatne
	if ( $cnt ) {
		wp_send_json_error( array( 'msg' => 'Kategoria ma dania (' . $cnt . ') – najpierw przenieś je do innej.' ) );
	}
	$r = wp_delete_term( $tid, 'product_cat' );
	if ( ! $r || is_wp_error( $r ) ) {
		wp_send_json_error( array( 'msg' => 'Nie udało się usunąć kategorii.' ) );
	}
	rzd_ed_cats_flush();
	wp_send_json_success( rzd_ed_cats_payload() );
} );

// Zdjęcie kafla (jak zdjęcie dania: zmniejszone w przeglądarce, sprawdzane po zawartości).
add_action( 'wp_ajax_rzd_ed_cat_photo', function () {
	rzd_ed_cats_guard();
	$tid = absint( rzd_ed_post( 'id', 0 ) );
	$t   = $tid ? get_term( $tid, 'product_cat' ) : null;
	if ( ! $t || is_wp_error( $t ) || empty( $_FILES['file'] ) ) {
		wp_send_json_error( array( 'msg' => 'Brak pliku albo kategorii.' ) );
	}
	$file  = $_FILES['file']; // phpcs:ignore
	$mimes = array( 'jpg|jpeg|jpe' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp' );
	if ( ! empty( $file['error'] ) || (int) $file['size'] > 12 * MB_IN_BYTES ) {
		wp_send_json_error( array( 'msg' => 'Plik jest za duży albo nie dotarł (max 12 MB).' ) );
	}
	$chk = wp_check_filetype_and_ext( $file['tmp_name'], $file['name'], $mimes );
	if ( empty( $chk['type'] ) ) {
		wp_send_json_error( array( 'msg' => 'To nie jest zdjęcie (JPG, PNG albo WebP).' ) );
	}
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	$_FILES['file']['name'] = sanitize_file_name( 'kategoria-' . $t->slug . '.' . ( 'image/png' === $chk['type'] ? 'png' : ( 'image/webp' === $chk['type'] ? 'webp' : 'jpg' ) ) );
	$att = media_handle_upload( 'file', 0, array( 'post_title' => $t->name ), array( 'test_form' => false, 'mimes' => $mimes ) );
	if ( is_wp_error( $att ) ) {
		wp_send_json_error( array( 'msg' => 'Nie udało się zapisać zdjęcia: ' . $att->get_error_message() ) );
	}
	update_post_meta( $att, '_wp_attachment_image_alt', $t->name );
	update_term_meta( $tid, 'thumbnail_id', (int) $att );
	rzd_ed_cats_flush();
	wp_send_json_success( rzd_ed_cats_payload() );
} );

// Przeniesienie dań: ids[] → do kategorii „to”; „from” = zamiana tej jednej kategorii
// (danie w kilku kategoriach zachowuje pozostałe), bez „from” – kategorie dania = tylko „to”.
add_action( 'wp_ajax_rzd_ed_cat_move', function () {
	rzd_ed_cats_guard();
	$ids  = json_decode( (string) rzd_ed_post( 'ids', '[]' ), true );
	$to   = absint( rzd_ed_post( 'to', 0 ) );
	$from = absint( rzd_ed_post( 'from', 0 ) );
	if ( ! is_array( $ids ) || ! $ids || ! $to || ! term_exists( $to, 'product_cat' ) ) {
		wp_send_json_error( array( 'msg' => 'Wybierz dania i kategorię docelową.' ) );
	}
	$rows = array();
	foreach ( array_unique( array_map( 'absint', $ids ) ) as $pid ) {
		$p = $pid ? wc_get_product( $pid ) : null;
		if ( ! $p ) {
			continue;
		}
		$cats = array_map( 'intval', (array) $p->get_category_ids() );
		$cats = $from ? array_values( array_diff( $cats, array( $from ) ) ) : array();
		$cats[] = $to;
		$p->set_category_ids( array_values( array_unique( $cats ) ) );
		$p->save();
		$rows[] = rzd_ed_row( wc_get_product( $pid ) );
	}
	rzd_ed_cats_flush();
	wp_send_json_success( array( 'rows' => $rows ) + rzd_ed_cats_payload() );
} );
