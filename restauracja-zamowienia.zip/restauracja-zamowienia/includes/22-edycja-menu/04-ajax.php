<?php
/**
 * Moduł 22-edycja-menu – AJAX.
 * Część modułu (pliki wczytywane po kolei – kolejność jak w dawnym jednym pliku).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 4. AJAX (tylko zalogowani z rzd_edit_menu)
 * ============================================================ */
function rzd_ed_guard() {
	if ( ! check_ajax_referer( 'rzd_ed', 'n', false ) ) {
		wp_send_json_error( array( 'msg' => 'Sesja wygasła – odśwież stronę.' ), 403 );
	}
	if ( ! rzd_ed_can() ) {
		wp_send_json_error( array( 'msg' => 'Brak uprawnień do edycji menu.' ), 403 );
	}
}

function rzd_ed_post( $k, $def = '' ) {
	return isset( $_POST[ $k ] ) ? wp_unslash( $_POST[ $k ] ) : $def; // phpcs:ignore
}

add_action( 'wp_ajax_rzd_ed_boot', function () {
	rzd_ed_guard();
	$ids  = wc_get_products( array( 'status' => array( 'publish', 'private' ), 'limit' => -1, 'return' => 'ids', 'orderby' => 'title', 'order' => 'ASC', 'type' => array( 'simple', 'variable', 'grouped', 'external' ) ) );
	_prime_post_caches( array_map( 'intval', $ids ), true, true ); // produkty z metadanymi i terminami jednym zapytaniem
	$rows = array();
	$used = array();
	foreach ( $ids as $id ) {
		$p = wc_get_product( $id );
		if ( ! $p ) {
			continue;
		}
		$r      = rzd_ed_row( $p );
		$rows[] = $r;
		foreach ( $r['cats'] as $c ) {
			$used[ $c ] = true;
		}
	}
	$cats = array();
	$terms = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false, 'include' => array_keys( $used ) ? array_keys( $used ) : array( 0 ) ) );
	if ( ! is_wp_error( $terms ) ) {
		foreach ( $terms as $t ) {
			if ( 'uncategorized' !== $t->slug ) {
				$cats[] = array( 'id' => (int) $t->term_id, 'name' => $t->name );
			}
		}
	}
	$sets = array();
	foreach ( $rows as $r ) {
		if ( $r['is_set'] ) {
			$sets[] = array( 'id' => $r['id'], 'name' => $r['name'], 'price' => $r['price'] );
		}
	}
	// Najpierw zestawy, w które nic nie jest wpięte wyżej (np. „Zestaw dnia”, „Danie dnia”), potem pośrednie.
	usort( $sets, function ( $a, $b ) {
		$pa = rzd_ed_set_parents( $a['id'] ) ? 1 : 0;
		$pb = rzd_ed_set_parents( $b['id'] ) ? 1 : 0;
		return $pa === $pb ? strcmp( $a['name'], $b['name'] ) : $pa - $pb;
	} );
	$alg = array();
	$at  = get_terms( array( 'taxonomy' => 'alergen', 'hide_empty' => false ) );
	if ( ! is_wp_error( $at ) ) {
		foreach ( $at as $t ) {
			$alg[] = array( 'id' => (int) $t->term_id, 'name' => $t->name );
		}
	}
	$days = array();
	$d    = function_exists( 'rzd_dc_now' ) ? rzd_dc_now() : new DateTime( 'now', wp_timezone() );
	for ( $i = 0; $i < 14; $i++ ) {
		$ymd    = $d->format( 'Y-m-d' );
		$days[] = array( 'date' => $ymd, 'label' => rzd_ed_day_label( $ymd ) );
		$d->modify( '+1 day' );
	}
	$cat = rzd_ed_catalog();
	$out = array( 'rows' => $rows, 'cats' => $cats, 'sets' => $sets, 'allergens' => $alg, 'days' => $days, 'today' => rzd_ed_today(), 'ingredients' => $cat['ingredients'], 'presets' => $cat['presets'], 'can_cats' => rzd_ed_cats_can(), 'group_dict' => function_exists( 'rzd_panel_group_dict' ) ? rzd_panel_group_dict() : null, 'ai' => function_exists( 'rzd_aidesc_box_data' ) ? rzd_aidesc_box_data() : array( 'on' => false ) );
	if ( $out['can_cats'] ) {
		$out += rzd_ed_cats_payload(); // zakładka „Kategorie” i wybór kategorii przy daniu (2.40.0)
	}
	wp_send_json_success( $out );
} );

add_action( 'wp_ajax_rzd_ed_get', function () {
	rzd_ed_guard();
	$p = wc_get_product( absint( rzd_ed_post( 'id', 0 ) ) );
	if ( ! $p ) {
		wp_send_json_error( array( 'msg' => 'Nie ma takiego produktu.' ) );
	}
	wp_send_json_success( rzd_ed_product_data( $p ) );
} );

add_action( 'wp_ajax_rzd_ed_save', function () {
	rzd_ed_guard();
	$p = wc_get_product( absint( rzd_ed_post( 'id', 0 ) ) );
	if ( ! $p ) {
		wp_send_json_error( array( 'msg' => 'Nie ma takiego produktu.' ) );
	}
	$f = json_decode( (string) rzd_ed_post( 'data', '{}' ), true );
	$f = is_array( $f ) ? $f : array();
	$is_set = rzd_ed_is_set( $p->get_id() );

	// grupy modyfikacji – sprawdzamy PRZED zapisem czegokolwiek, żeby
	// przy konflikcie (zmiana w panelu w międzyczasie) nie zapisać połowy.
	$new_mods = null;
	if ( ! $is_set && isset( $f['mods'] ) && is_array( $f['mods'] ) ) {
		if ( ! isset( $f['mods_sig'] ) || (string) $f['mods_sig'] !== rzd_ed_mods_sig( $p->get_id() ) ) {
			wp_send_json_error( array( 'msg' => 'Modyfikacje tego dania zmieniły się w międzyczasie (np. w panelu). Zamknij kartę, otwórz ją ponownie i powtórz zmianę.' ) );
		}
		$new_mods = rzd_ed_build_mods( $p->get_id(), $f['mods'] );
	}
	// opisy z edytora sekcji (moduł 24) – też sprawdzane przed zapisem.
	$new_desc = array();
	foreach ( array( 'short' => 'short_doc', 'long' => 'desc_doc' ) as $kind => $key ) {
		if ( isset( $f[ $key ] ) && is_array( $f[ $key ] ) ) {
			$d = rzd_desc_prepare( $p, $kind, $f[ $key ] );
			if ( is_wp_error( $d ) ) {
				wp_send_json_error( array( 'msg' => $d->get_error_message() ) );
			}
			$new_desc[ $kind ] = $d;
		}
	}

	// kategorie dania (2.40.0) – z uprawnieniem „Kategorie”; co najmniej jedna istniejąca.
	$new_cats = null;
	if ( isset( $f['cats'] ) && is_array( $f['cats'] ) && rzd_ed_cats_can() ) {
		$cids = array_values( array_filter( array_unique( array_map( 'absint', $f['cats'] ) ), function ( $c ) {
			return $c && term_exists( $c, 'product_cat' );
		} ) );
		if ( ! $cids ) {
			wp_send_json_error( array( 'msg' => 'Danie musi mieć co najmniej jedną kategorię.' ) );
		}
		$new_cats = $cids;
	}
	if ( isset( $f['name'] ) ) {
		$name = trim( sanitize_text_field( $f['name'] ) );
		if ( '' === $name ) {
			wp_send_json_error( array( 'msg' => 'Nazwa nie może być pusta.' ) );
		}
		$p->set_name( $name );
	}
	if ( isset( $f['price'] ) && $p->is_type( 'simple' ) ) {
		$raw = trim( str_replace( array( ' ', "\xc2\xa0", 'zł' ), '', (string) $f['price'] ) );
		$raw = str_replace( ',', '.', $raw );
		if ( '' !== $raw ) {
			if ( ! is_numeric( $raw ) || (float) $raw < 0 ) {
				wp_send_json_error( array( 'msg' => 'Cena musi być liczbą, np. 37,00.' ) );
			}
			$p->set_regular_price( wc_format_decimal( $raw, 2 ) ); // brutto – jak wszędzie w projekcie
		}
	}
	if ( null !== $new_cats ) {
		$p->set_category_ids( $new_cats );
	}
	foreach ( $new_desc as $kind => $d ) {
		rzd_desc_set( $p, $kind, $d[1] );
	}
	$p->save();
	foreach ( $new_desc as $kind => $d ) {
		rzd_desc_backup_after_change( $p->get_id(), $kind, $d[0], rzd_desc_get( $p, $kind ), $d[2] );
	}

	if ( isset( $f['allergens'] ) && taxonomy_exists( 'alergen' ) ) {
		$valid = get_terms( array( 'taxonomy' => 'alergen', 'hide_empty' => false, 'fields' => 'ids' ) );
		$ids   = array_values( array_intersect( array_map( 'intval', (array) $f['allergens'] ), is_wp_error( $valid ) ? array() : array_map( 'intval', $valid ) ) );
		wp_set_object_terms( $p->get_id(), $ids, 'alergen' );
	}
	if ( isset( $f['soldout'] ) && is_array( $f['soldout'] ) ) {
		rzd_soldout_save( $p->get_id(), ! empty( $f['soldout']['always'] ), isset( $f['soldout']['dates'] ) ? (array) $f['soldout']['dates'] : array() );
	}
	// skład – tylko istniejące dodatki z katalogu, bez powtórzeń (nowe pole; dawne _rzd_sklad zostaje).
	if ( ! $is_set && isset( $f['sklad'] ) && is_array( $f['sklad'] ) && function_exists( 'rzd_set_product_sklad' ) ) {
		rzd_set_product_sklad( $p->get_id(), $f['sklad'] );
	}
	if ( null !== $new_mods ) {
		if ( $new_mods ) {
			update_post_meta( $p->get_id(), '_rzd_modifiers', $new_mods );
		} else {
			delete_post_meta( $p->get_id(), '_rzd_modifiers' );
		}
	}
	rzd_ed_clear_caches();
	wc_delete_product_transients( $p->get_id() );
	$p = wc_get_product( $p->get_id() );
	wp_send_json_success( array( 'row' => rzd_ed_row( $p ), 'product' => rzd_ed_product_data( $p ) ) );
} );

// Zdjęcie: plik już zmniejszony w przeglądarce (JPG ~1600 px); i tak sprawdzamy typ i rozmiar.
add_action( 'wp_ajax_rzd_ed_photo', function () {
	rzd_ed_guard();
	$pid = absint( rzd_ed_post( 'id', 0 ) );
	$p   = wc_get_product( $pid );
	if ( ! $p || empty( $_FILES['file'] ) ) {
		wp_send_json_error( array( 'msg' => 'Brak pliku albo produktu.' ) );
	}
	$file = $_FILES['file']; // phpcs:ignore
	if ( ! empty( $file['error'] ) || (int) $file['size'] > 12 * MB_IN_BYTES ) {
		wp_send_json_error( array( 'msg' => 'Plik jest za duży albo nie dotarł (max 12 MB).' ) );
	}
	$chk = wp_check_filetype_and_ext( $file['tmp_name'], $file['name'], array( 'jpg|jpeg|jpe' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp' ) );
	if ( empty( $chk['type'] ) ) {
		wp_send_json_error( array( 'msg' => 'To nie jest zdjęcie (JPG, PNG albo WebP).' ) );
	}
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	$_FILES['file']['name'] = sanitize_file_name( sanitize_title( $p->get_name() ) . '.' . ( 'image/png' === $chk['type'] ? 'png' : ( 'image/webp' === $chk['type'] ? 'webp' : 'jpg' ) ) );
	$att = media_handle_upload( 'file', $pid, array( 'post_title' => $p->get_name() ), array( 'test_form' => false, 'mimes' => array( 'jpg|jpeg|jpe' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp' ) ) );
	if ( is_wp_error( $att ) ) {
		wp_send_json_error( array( 'msg' => 'Nie udało się zapisać zdjęcia: ' . $att->get_error_message() ) );
	}
	update_post_meta( $att, '_wp_attachment_image_alt', $p->get_name() );
	$p->set_image_id( $att );
	$p->save();
	rzd_ed_clear_caches();
	$p = wc_get_product( $pid );
	wp_send_json_success( array( 'img' => rzd_ed_thumb( $att, 'medium_large' ), 'row' => rzd_ed_row( $p ) ) );
} );

add_action( 'wp_ajax_rzd_ed_day', function () {
	rzd_ed_guard();
	$set  = absint( rzd_ed_post( 'set', 0 ) );
	$date = (string) rzd_ed_post( 'date', '' );
	if ( ! $set || ! rzd_ed_is_set( $set ) || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
		wp_send_json_error( array( 'msg' => 'Nieprawidłowy zestaw albo dzień.' ) );
	}
	wp_send_json_success( rzd_ed_day_data( $set, $date ) );
} );

add_action( 'wp_ajax_rzd_ed_day_save', function () {
	rzd_ed_guard();
	$set  = absint( rzd_ed_post( 'set', 0 ) );
	$date = (string) rzd_ed_post( 'date', '' );
	$own  = json_decode( (string) rzd_ed_post( 'owners', '{}' ), true );
	if ( ! $set || ! rzd_ed_is_set( $set ) || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) || ! is_array( $own ) || ! $own ) {
		wp_send_json_error( array( 'msg' => 'Nie ma czego zapisać.' ) );
	}
	if ( $date < rzd_ed_today() ) {
		wp_send_json_error( array( 'msg' => 'Minionych dni nie zmieniamy.' ) );
	}
	// Wolno zapisać tylko zestawy z drzewa tego zestawu na ten dzień.
	$owners = array();
	$info   = array();
	rzd_ed_day_owners( $set, $date, $owners, $info );
	$clean = array();
	foreach ( $own as $oid => $items ) {
		$oid = (int) $oid;
		if ( ! isset( $owners[ $oid ] ) || ! is_array( $items ) ) {
			continue;
		}
		$list = array();
		foreach ( $items as $it ) {
			$pid = isset( $it['product_id'] ) ? absint( $it['product_id'] ) : 0;
			if ( ! $pid || $pid === $oid || ! wc_get_product( $pid ) ) {
				continue;
			}
			$row = array( 'product_id' => $pid, 'type' => ( isset( $it['type'] ) && 'addon' === $it['type'] ) ? 'addon' : 'main' );
			if ( ! empty( $it['photo'] ) ) {
				$row['photo'] = 1;
			}
			$list[] = $row;
		}
		$clean[ $oid ] = $list;
	}
	if ( ! $clean ) {
		wp_send_json_error( array( 'msg' => 'Nie ma czego zapisać.' ) );
	}
	// Ostrzeżenie: na ten dzień są już złożone zamówienia ze starym składem (decyzja użytkownika).
	if ( '1' !== (string) rzd_ed_post( 'confirm', '' ) ) {
		$aff = array_values( array_unique( array_merge( array_keys( $owners ), rzd_ed_set_parents( $set ) ) ) );
		$o   = rzd_ed_orders_with_sets( $date, array_map( 'intval', $aff ) );
		if ( $o['count'] ) {
			wp_send_json_success( array( 'confirm' => sprintf(
				'Na %1$s są już złożone zamówienia z tym zestawem: %2$d. Mają zapisany stary skład (%3$s) – zmiana go w nich NIE poprawi, kuchnia przygotuje to, co w zamówieniach. Zapisać mimo to?',
				rzd_ed_day_label( $date ),
				$o['count'],
				$o['sklady'] ? implode( ' / ', $o['sklady'] ) : 'bez nazw'
			) ) );
		}
	}
	foreach ( $clean as $oid => $list ) {
		rzd_ed_write_day( $oid, $date, $list );
	}
	rzd_ed_clear_caches();
	wp_send_json_success( array( 'saved' => true ) );
} );

// Dania do wyboru: ostatnio w zestawach (z datą) + wyszukiwanie.
add_action( 'wp_ajax_rzd_ed_dishes', function () {
	rzd_ed_guard();
	$q    = trim( sanitize_text_field( (string) rzd_ed_post( 'q', '' ) ) );
	$last = array();
	if ( function_exists( 'rzd_all_sets' ) ) {
		foreach ( rzd_all_sets() as $sid ) {
			foreach ( rzd_zestaw_get_slots( $sid ) as $slot ) {
				$d = ! empty( $slot['date'] ) ? (string) $slot['date'] : '';
				foreach ( ( isset( $slot['items'] ) && is_array( $slot['items'] ) ) ? $slot['items'] : array() as $it ) {
					$pid = ! empty( $it['product_id'] ) ? (int) $it['product_id'] : 0;
					if ( ! $pid || rzd_ed_is_set( $pid ) ) {
						continue;
					}
					if ( ! isset( $last[ $pid ] ) || $d > $last[ $pid ] ) {
						$last[ $pid ] = $d;
					}
				}
			}
		}
	}
	$ids = array();
	if ( '' !== $q ) {
		$found = get_posts( array( 'post_type' => 'product', 'post_status' => array( 'publish', 'private' ), 'numberposts' => 30, 'fields' => 'ids', 's' => $q, 'orderby' => 'title', 'order' => 'ASC', 'suppress_filters' => false ) );
		foreach ( $found as $id ) {
			if ( ! rzd_ed_is_set( $id ) ) {
				$ids[] = (int) $id;
			}
		}
	} else {
		arsort( $last );
		$ids = array_slice( array_keys( $last ), 0, 25 );
	}
	$out = array();
	foreach ( $ids as $id ) {
		$p = wc_get_product( $id );
		if ( ! $p ) {
			continue;
		}
		$role  = function_exists( 'rzd_zestaw_get_set_role' ) ? rzd_zestaw_get_set_role( $id ) : array( 'label' => '' );
		$out[] = array(
			'id'    => $id,
			'name'  => $p->get_name(),
			'thumb' => rzd_ed_thumb( get_post_thumbnail_id( $id ) ),
			'role'  => $role['label'],
			'last'  => ! empty( $last[ $id ] ) ? 'ostatnio: ' . rzd_ed_day_label( $last[ $id ] ) : ( isset( $last[ $id ] ) ? 'w regule zestawu' : '' ),
		);
	}
	wp_send_json_success( array( 'dishes' => $out ) );
} );

// Nowe danie: kategorie, cena, rola, grupy modyfikacji i opakowanie jak u dania-wzoru (tej samej roli).
add_action( 'wp_ajax_rzd_ed_new_dish', function () {
	rzd_ed_guard();
	$name = trim( sanitize_text_field( (string) rzd_ed_post( 'name', '' ) ) );
	if ( '' === $name ) {
		wp_send_json_error( array( 'msg' => 'Podaj nazwę dania.' ) );
	}
	$like = wc_get_product( absint( rzd_ed_post( 'like', 0 ) ) );
	$p    = new WC_Product_Simple();
	$p->set_name( $name );
	$p->set_status( 'publish' );
	$p->set_short_description( wp_kses_post( trim( (string) rzd_ed_post( 'short', '' ) ) ) );
	$cat = absint( rzd_ed_post( 'cat', 0 ) );
	if ( $cat && term_exists( $cat, 'product_cat' ) ) {
		$p->set_category_ids( array( $cat ) ); // wybrana w oknie (nowe danie bez dania-wzoru)
	}
	if ( $like && ! rzd_ed_is_set( $like->get_id() ) ) {
		$p->set_category_ids( $like->get_category_ids() );
		if ( '' !== $like->get_regular_price() ) {
			$p->set_regular_price( $like->get_regular_price() );
		}
	}
	$id = $p->save();
	if ( ! $id ) {
		wp_send_json_error( array( 'msg' => 'Nie udało się utworzyć dania.' ) );
	}
	if ( $like && ! rzd_ed_is_set( $like->get_id() ) ) {
		$lid = $like->get_id();
		foreach ( array( '_rzd_modifiers', '_rwz_set_order', '_rzd_packaging', '_rzd_prod_pack_capacity' ) as $k ) {
			$v = get_post_meta( $lid, $k, true );
			if ( '' !== $v && null !== $v ) {
				update_post_meta( $id, $k, $v );
			}
		}
		$labels = wp_get_object_terms( $lid, 'rzd_set_label', array( 'fields' => 'ids' ) );
		if ( ! is_wp_error( $labels ) && $labels ) {
			wp_set_object_terms( $id, array_map( 'intval', $labels ), 'rzd_set_label' );
		}
	}
	$alg = json_decode( (string) rzd_ed_post( 'allergens', '[]' ), true );
	if ( is_array( $alg ) && taxonomy_exists( 'alergen' ) ) {
		wp_set_object_terms( $id, array_map( 'intval', $alg ), 'alergen' );
	}
	rzd_ed_clear_caches();
	$p = wc_get_product( $id );
	wp_send_json_success( array( 'id' => $id, 'row' => rzd_ed_row( $p ), 'info' => rzd_ed_dish_info( $id, rzd_ed_today() ) ) );
} );

