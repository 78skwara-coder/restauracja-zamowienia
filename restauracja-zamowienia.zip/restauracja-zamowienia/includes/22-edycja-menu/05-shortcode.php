<?php
/**
 * Moduł 22-edycja-menu – shortcode [edycja_produktow].
 * Część modułu (pliki wczytywane po kolei – kolejność jak w dawnym jednym pliku).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 5. SHORTCODE [edycja_produktow]
 * ============================================================ */
add_shortcode( 'edycja_produktow', function () {
	if ( ! is_user_logged_in() ) {
		return '<div class="rzd-ed-login" style="max-width:420px;margin:30px auto;font-size:16px">'
			. '<h2 style="margin:0 0 12px">Edycja menu</h2><p>Zaloguj się kontem redaktora menu.</p>'
			. wp_login_form( array( 'echo' => false, 'redirect' => get_permalink(), 'remember' => true, 'value_remember' => true ) )
			. '</div>';
	}
	if ( ! rzd_ed_can() ) {
		return '<p style="margin:30px auto;max-width:420px">To konto nie ma uprawnień do edycji menu. Poproś administratora o rolę „Redaktor menu”.</p>';
	}
	$ver = defined( 'RZD_PLUGIN_VERSION' ) ? RZD_PLUGIN_VERSION : '1';
	$js  = RZD_PLUGIN_DIR . 'assets/js/rzd-edycja.js';
	wp_enqueue_script( 'rzd-edycja', RZD_PLUGIN_URL . 'assets/js/rzd-edycja.js', array(), $ver . '.' . (int) @filemtime( $js ), true ); // phpcs:ignore
	wp_add_inline_script( 'rzd-edycja', 'window.rzdEd = ' . wp_json_encode( array(
		'ajax'    => admin_url( 'admin-ajax.php' ),
		'nonce'   => wp_create_nonce( 'rzd_ed' ),
		'logout'  => wp_logout_url( get_permalink() ),
		'home'    => home_url( '/' ),
		'user'    => wp_get_current_user()->display_name,
		// podgląd opisu w edytorze – ten sam CSS co w sklepie
		'opisCss' => RZD_PLUGIN_URL . 'assets/css/lista-zamowien.css?ver=' . rawurlencode( $ver . '.' . (int) @filemtime( RZD_PLUGIN_DIR . 'assets/css/lista-zamowien.css' ) ), // phpcs:ignore
	) ) . ';', 'before' );
	return '<div id="rzd-ed" class="rzd-ed"><div class="rzd-ed-loading">Wczytuję menu…</div></div>' . rzd_ed_css();
} );

function rzd_ed_css() {
	$c = '#rzd-ed{position:fixed;inset:0;z-index:999990;background:#FBF8F3;color:#2A2522;font-family:Lato,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;font-size:16px;line-height:1.4;display:flex;flex-direction:column;overflow:hidden;-webkit-text-size-adjust:100%}'
		. '#rzd-ed *{box-sizing:border-box}'
		. '#rzd-ed button,#rzd-ed input,#rzd-ed textarea,#rzd-ed select{font:inherit;color:inherit;margin:0;letter-spacing:normal;text-transform:none;box-shadow:none}'
		. '#rzd-ed .rzd-ed-loading{margin:auto;color:#6E645C}'
		. '#rzd-ed .ed-wrap{width:100%;max-width:640px;margin:0 auto;display:flex;flex-direction:column;flex:1;min-height:0}'
		. '#rzd-ed .ed-head{flex:none;padding:16px 16px 12px;border-bottom:1px solid #E8E0D5;display:flex;flex-direction:column;gap:12px;background:#FBF8F3}'
		. '#rzd-ed .ed-top{display:flex;align-items:center;gap:8px}'
		. '#rzd-ed .ed-top h1{margin:0;flex:1;font-family:"Playfair Display",Georgia,serif;font-size:24px;font-weight:700;line-height:1.2;color:#2A2522}'
		. '#rzd-ed .ed-top small{color:#6E645C;font-size:13px}'
		. '#rzd-ed .ed-ico{display:inline-flex;align-items:center;justify-content:center;width:44px;height:44px;border-radius:22px;border:0;background:transparent;cursor:pointer;padding:0;flex:none;text-decoration:none;color:#2A2522}'
		. '#rzd-ed .ed-ico svg{width:22px;height:22px}'
		. '#rzd-ed .ed-tabs{display:grid;grid-template-columns:1fr 1fr;background:#F1EAE0;border-radius:12px;padding:4px;gap:4px}'
		. '#rzd-ed .ed-tabs button{height:42px;border-radius:9px;border:0;background:transparent;color:#5C524A;cursor:pointer;font-size:15px}'
		. '#rzd-ed .ed-tabs button.on{background:#fff;font-weight:700;color:#2A2522;box-shadow:0 1px 2px rgba(42,37,34,.12)}'
		. '#rzd-ed .ed-search{display:flex;align-items:center;gap:10px;height:48px;padding:0 14px;background:#fff;border:1px solid #E0D6C9;border-radius:12px}'
		. '#rzd-ed .ed-search input{border:0;outline:0;flex:1;min-width:0;background:transparent;font-size:16px;padding:0;height:auto}'
		. '#rzd-ed .ed-chips{display:flex;gap:8px;overflow-x:auto;margin:0 -16px;padding:0 16px 2px;scrollbar-width:none}'
		. '#rzd-ed .ed-chip{flex:none;height:40px;padding:0 16px;border-radius:20px;border:1px solid #D9CEC0;background:#fff;cursor:pointer;white-space:nowrap;font-size:14px}'
		. '#rzd-ed .ed-chip.on{background:#2A2522;border-color:#2A2522;color:#fff;font-weight:700}'
		. '#rzd-ed .ed-body{flex:1;overflow-y:auto;-webkit-overflow-scrolling:touch;padding:4px 16px 120px}'
		// Skład i Modyfikacje na karcie dania
		. '#rzd-ed .ed-sub{display:block;color:#6E645C;font-size:13px;margin-top:2px}'
		. '#rzd-ed .ed-rows{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:6px}'
		. '#rzd-ed .ed-rows li{display:flex;align-items:center;gap:6px;padding:8px 6px 8px 12px;border:1px solid #E8E0D5;border-radius:10px;background:#FBF8F3}'
		. '#rzd-ed .ed-rows li.is-new{border-style:dashed;border-color:#B58A4C;background:#FFF8EC}'
		. '#rzd-ed .ed-r-main{flex:1;min-width:0;display:flex;flex-direction:column}'
		. '#rzd-ed .ed-r-main b{overflow-wrap:anywhere}'
		. '#rzd-ed .ed-r-main small{color:#6E645C;font-size:12.5px}'
		. '#rzd-ed .ed-mini{flex:none;width:40px;height:40px;border-radius:10px;border:1px solid #D9CEC0;background:#fff;cursor:pointer;font-size:16px;padding:0}'
		. '#rzd-ed .ed-mini:disabled{opacity:.35;cursor:default}'
		. '#rzd-ed .ed-found{display:flex;flex-direction:column;gap:6px}'
		. '#rzd-ed .ed-hit{text-align:left;min-height:44px;padding:8px 12px;border-radius:10px;border:1px solid #D9CEC0;background:#fff;cursor:pointer}'
		. '#rzd-ed .ed-hit small{color:#6E645C}'
		. '#rzd-ed .ed-addrow{display:flex;gap:8px;align-items:stretch}'
		. '#rzd-ed .ed-addrow select{flex:1;min-width:0}'
		. '#rzd-ed .ed-addrow .ed-btn{flex:none;width:auto;padding:0 14px}'
		. '#rzd-ed .ed-row{display:flex;align-items:center;gap:14px;width:100%;padding:12px 0;border:0;border-bottom:1px solid #ECE4D9;background:transparent;text-align:left;cursor:pointer;min-height:64px}'
		. '#rzd-ed .ed-th{flex:none;width:56px;height:56px;border-radius:12px;background:#E8DFD3 center/cover no-repeat;object-fit:cover}'
		. '#rzd-ed .ed-rt{flex:1;min-width:0;display:flex;flex-direction:column;gap:3px}'
		. '#rzd-ed .ed-rt b{font-size:16px;line-height:1.25}'
		. '#rzd-ed .ed-rt span{font-size:13px;color:#6E645C}'
		. '#rzd-ed .ed-pr{font-family:Oswald,sans-serif;font-size:17px;white-space:nowrap}'
		. '#rzd-ed .ed-pr.mut{color:#6E645C;font-family:inherit;font-size:13px}'
		. '#rzd-ed .ed-badge{align-self:flex-start;margin-top:2px;font-size:12px;font-weight:700;color:#fff;background:#A84D0C;border-radius:6px;padding:2px 8px}'
		. '#rzd-ed .ed-badge.gray{background:#6E645C}'
		. '#rzd-ed .ed-rt .ed-badge{color:#fff;font-size:12px}'
		. '#rzd-ed .ed-foot{position:absolute;left:0;right:0;bottom:0;padding:12px 16px calc(16px + env(safe-area-inset-bottom));background:#FBF8F3;border-top:1px solid #E8E0D5}'
		. '#rzd-ed .ed-foot .ed-wrap{flex-direction:row;gap:10px}'
		. '#rzd-ed .ed-btn{display:flex;align-items:center;justify-content:center;gap:8px;min-height:52px;padding:0 16px;border-radius:14px;border:1px solid #D9CEC0;background:#fff;cursor:pointer;font-size:16px;text-decoration:none;color:#2A2522;flex:1}'
		. '#rzd-ed .ed-btn.pri{background:#FBF1E1;border:1.5px solid #8A5A2B;font-weight:700;flex:2}'
		. '#rzd-ed .ed-btn.sm{min-height:42px;font-size:14px;border-radius:10px;flex:none}'
		. '#rzd-ed .ed-btn[disabled]{opacity:.55;cursor:default}'
		. '#rzd-ed .ed-field{display:flex;flex-direction:column;gap:6px;margin:0 0 18px}'
		. '#rzd-ed .ed-field>span{font-size:14px;font-weight:700}'
		. '#rzd-ed .ed-field>span em{font-weight:400;font-style:normal;color:#6E645C}'
		. '#rzd-ed .ed-in{width:100%;min-height:48px;padding:10px 14px;border:1px solid #D9CEC0;border-radius:12px;background:#fff;font-size:16px;outline:0}'
		. '#rzd-ed .ed-in:focus{border-color:#8A5A2B}'
		. '#rzd-ed textarea.ed-in{resize:vertical;line-height:1.45}'
		. '#rzd-ed .ed-note{padding:12px 14px;border-radius:12px;background:#F3ECE2;font-size:14px;line-height:1.45;color:#4A4039;margin:0 0 18px}'
		. '#rzd-ed .ed-note.warn{background:#FFF4EC;border:1px solid #E0A57A;color:#7A3606}'
		. '#rzd-ed .ed-photo{position:relative;height:240px;border-radius:16px;background:#E8DFD3 center/cover no-repeat;display:flex;align-items:flex-end;justify-content:center;gap:10px;padding:14px;margin:12px 0 18px}'
		. '#rzd-ed .ed-photo label{display:inline-flex;align-items:center;gap:8px;min-height:46px;padding:0 16px;border-radius:12px;background:rgba(255,255,255,.92);font-weight:700;font-size:15px;cursor:pointer}'
		. '#rzd-ed .ed-photo input{position:absolute;width:1px;height:1px;opacity:0;pointer-events:none}'
		. '#rzd-ed .ed-photo .ed-empty{position:absolute;top:12px;left:14px;font-size:13px;background:rgba(255,255,255,.8);padding:3px 8px;border-radius:6px}'
		. '#rzd-ed .ed-box{padding:14px;border-radius:14px;background:#fff;border:1px solid #E0D6C9;margin:0 0 18px;display:flex;flex-direction:column;gap:12px}'
		. '#rzd-ed .ed-sw{display:flex;align-items:center;justify-content:space-between;gap:12px;min-height:44px;cursor:pointer}'
		. '#rzd-ed .ed-sw input{width:26px;height:26px;accent-color:#A84D0C;flex:none}'
		. '#rzd-ed .ed-sw b{display:block;font-size:16px}'
		. '#rzd-ed .ed-sw small{display:block;font-size:13px;color:#6E645C}'
		. '#rzd-ed .ed-seg{display:grid;grid-template-columns:repeat(3,1fr);gap:6px}'
		. '#rzd-ed .ed-seg button{min-height:44px;border-radius:10px;border:1px solid #D9CEC0;background:#FBF8F3;cursor:pointer;font-size:13px;line-height:1.2;padding:4px}'
		. '#rzd-ed .ed-seg button.on{background:#2A2522;color:#fff;border-color:#2A2522;font-weight:700}'
		. '#rzd-ed .ed-alg{display:flex;flex-wrap:wrap;gap:8px}'
		. '#rzd-ed .ed-alg button{min-height:40px;padding:0 12px;border-radius:20px;border:1px solid #D9CEC0;background:#fff;cursor:pointer;font-size:14px}'
		. '#rzd-ed .ed-alg button.on{background:#FBF1E1;border:1.5px solid #8A5A2B;font-weight:700}'
		. '#rzd-ed .ed-sets{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:8px}'
		. '#rzd-ed .ed-sets button{display:flex;flex-direction:column;align-items:flex-start;gap:2px;min-height:56px;padding:8px 12px;border-radius:12px;border:1px solid #D9CEC0;background:#fff;cursor:pointer;text-align:left;font-size:14px}'
		. '#rzd-ed .ed-sets button.on{background:#FBF1E1;border:1.5px solid #8A5A2B}'
		. '#rzd-ed .ed-sets b{font-size:14px}'
		. '#rzd-ed .ed-sets span{font-family:Oswald,sans-serif;font-size:15px}'
		. '#rzd-ed .ed-days{display:flex;gap:6px;overflow-x:auto;margin:0 -16px;padding:0 16px 2px;scrollbar-width:none}'
		. '#rzd-ed .ed-days button{flex:none;display:flex;flex-direction:column;align-items:center;justify-content:center;width:54px;height:64px;border-radius:12px;border:1px solid #D9CEC0;background:#fff;cursor:pointer;line-height:1.15}'
		. '#rzd-ed .ed-days button b{font-size:18px}'
		. '#rzd-ed .ed-days button small{font-size:11px}'
		. '#rzd-ed .ed-days button.on{background:#2A2522;color:#fff;border-color:#2A2522}'
		. '#rzd-ed .ed-prev{display:flex;gap:14px;align-items:center;margin:16px 0}'
		. '#rzd-ed .ed-prev .ed-th{width:96px;height:96px;border-radius:14px}'
		. '#rzd-ed .ed-prev small{display:block;font-size:12px;color:#6E645C;text-transform:uppercase;letter-spacing:.06em}'
		. '#rzd-ed .ed-prev b{display:block;font-family:"Playfair Display",Georgia,serif;font-size:19px;line-height:1.25}'
		. '#rzd-ed .ed-dish{display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid #ECE4D9}'
		. '#rzd-ed .ed-dish:last-of-type{border-bottom:0}'
		. '#rzd-ed .ed-dish .ed-th{width:48px;height:48px;border-radius:10px}'
		. '#rzd-ed .ed-x{flex:none;width:40px;height:40px;border-radius:10px;border:1px solid #D9CEC0;background:#fff;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;padding:0}'
		. '#rzd-ed .ed-add{display:flex;align-items:center;gap:10px;min-height:48px;border:0;background:transparent;color:#5C3A1A;font-weight:700;cursor:pointer;padding:0;font-size:15px}'
		. '#rzd-ed h2.ed-h{margin:22px 0 10px;font-family:"Playfair Display",Georgia,serif;font-size:19px;font-weight:700;color:#2A2522}'
		. '#rzd-ed .ed-sheet{position:absolute;inset:0;background:rgba(42,37,34,.55);display:flex;align-items:flex-end;justify-content:center;z-index:5}'
		. '#rzd-ed .ed-sheet>div{width:100%;max-width:640px;height:92%;background:#FBF8F3;border-radius:22px 22px 0 0;display:flex;flex-direction:column}'
		. '#rzd-ed .ed-toast{position:absolute;left:50%;bottom:96px;transform:translateX(-50%);background:#2A2522;color:#fff;padding:10px 16px;border-radius:12px;font-size:14px;z-index:9;max-width:90%;text-align:center}'
		. '#rzd-ed .ed-toast.err{background:#A84D0C}'
		. '#rzd-ed .ed-hide{display:none!important}'
		// edytor opisu (sekcje, pasek, emotki, podgląd, kopie)
		. '#rzd-ed .ed-de{position:absolute;inset:0;z-index:7;background:#FBF8F3;display:flex;flex-direction:column}'
		. '#rzd-ed .ed-dsum{font-size:14px;color:#4A4039;line-height:1.45;overflow-wrap:anywhere}'
		. '#rzd-ed .ed-sec{gap:10px}'
		. '#rzd-ed .ed-sec-ctl{display:flex;align-items:center;gap:6px}'
		. '#rzd-ed .ed-sec-h{font-weight:700;font-family:"Segoe UI",Roboto,Helvetica,Arial,sans-serif}'
		. '#rzd-ed .ed-sec-h.ed-h2{font-size:22px}#rzd-ed .ed-sec-h.ed-h3{font-size:19px}#rzd-ed .ed-sec-h.ed-h4{font-size:16px}'
		. '#rzd-ed .ed-tb{display:flex;flex-wrap:wrap;gap:6px}'
		. '#rzd-ed .ed-tb button{min-width:44px;height:44px;padding:0 10px;border-radius:10px;border:1px solid #D9CEC0;background:#FBF8F3;cursor:pointer;font-size:17px;line-height:1;color:#2A2522}'
		. '#rzd-ed .ed-tb button:active{background:#F1EAE0}'
		. '#rzd-ed .ed-rich{min-height:110px;padding:12px 14px;border:1px solid #D9CEC0;border-radius:12px;background:#fff;outline:0;font-size:16px;line-height:1.55;overflow-wrap:anywhere;color:#333;-webkit-user-select:text;user-select:text}'
		. '#rzd-ed .ed-rich:focus{border-color:#8A5A2B;box-shadow:0 0 0 3px rgba(138,90,43,.12)}'
		. '#rzd-ed .ed-rich:empty:before{content:attr(data-ph);color:#9A8F86}'
		. '#rzd-ed .ed-rich p{margin:0 0 .6em}#rzd-ed .ed-rich>*:last-child{margin-bottom:0}'
		. '#rzd-ed .ed-rich ul,#rzd-ed .ed-rich ol{margin:0 0 .6em 1.4em;padding:0}#rzd-ed .ed-rich li{margin:0 0 4px}'
		. '#rzd-ed .ed-rich hr{border:0;border-top:1px dashed #C9BDAF;margin:14px 0;height:0}'
		. '#rzd-ed .ed-rich.k2 ul,#rzd-ed .ed-rich.k2 ol{columns:2;column-gap:24px}'
		. '#rzd-ed .ed-pv{display:block;width:100%;min-height:60px;border:1px solid #E0D6C9;border-radius:12px;background:#fff;margin:0 0 6px}'
		. '#rzd-ed .ed-bk{display:flex;flex-direction:column;gap:8px;padding:10px 0;border-top:1px solid #ECE4D9}'
		. '#rzd-ed .ed-bk-row{display:flex;gap:6px;flex-wrap:wrap}'
		. '#rzd-ed .ed-emo{position:absolute;left:0;right:0;bottom:0;z-index:8;max-height:48%;display:flex;flex-direction:column;background:#fff;border-top:1px solid #E0D6C9;border-radius:18px 18px 0 0;box-shadow:0 -8px 24px rgba(42,37,34,.18);padding-bottom:env(safe-area-inset-bottom)}'
		. '#rzd-ed .ed-emo-top{display:flex;align-items:center;gap:6px;padding:4px 6px 0 16px}#rzd-ed .ed-emo-top b{flex:1;font-size:14px}'
		. '#rzd-ed .ed-emo-tabs{flex:none;display:flex;gap:6px;overflow-x:auto;padding:4px 12px 8px;border-bottom:1px solid #EEE6DB;scrollbar-width:none}'
		. '#rzd-ed .ed-emo-tabs button{flex:none;height:36px;padding:0 12px;border-radius:18px;border:1px solid #D9CEC0;background:#fff;font-size:13px;cursor:pointer;white-space:nowrap}'
		. '#rzd-ed .ed-emo-tabs button.on{background:#2A2522;color:#fff;border-color:#2A2522}'
		. '#rzd-ed .ed-emo-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(46px,1fr));gap:2px;padding:8px 10px 14px;overflow-y:auto}'
		. '#rzd-ed .ed-emo-grid button{height:46px;border:0;border-radius:10px;background:transparent;font-size:25px;line-height:1;cursor:pointer;padding:0}'
		. '#rzd-ed .ed-emo-grid button:hover,#rzd-ed .ed-emo-grid button:active{background:#F3ECE2}'
		// wąskie telefony – mniejsze napisy na przyciskach, żeby się mieściły
		. '#rzd-ed select.ed-in{appearance:auto;-webkit-appearance:menulist;padding-right:10px;font-weight:700;font-size:15px}'
		. '@media (max-width:420px){#rzd-ed .ed-btn{font-size:15px;padding:0 12px}#rzd-ed .ed-btn.sm{font-size:13px;padding:0 10px;min-height:40px}#rzd-ed .ed-tabs button{font-size:14px}#rzd-ed .ed-top h1{font-size:22px}#rzd-ed .ed-photo label{font-size:14px;padding:0 12px}#rzd-ed .ed-body{padding-left:12px;padding-right:12px}#rzd-ed .ed-head{padding:12px 12px 10px}#rzd-ed .ed-days,#rzd-ed .ed-chips{margin:0 -12px;padding:0 12px 2px}#rzd-ed .ed-foot{padding-left:12px;padding-right:12px}}';
	return '<style id="rzd-ed-css">' . $c . '</style>';
}
