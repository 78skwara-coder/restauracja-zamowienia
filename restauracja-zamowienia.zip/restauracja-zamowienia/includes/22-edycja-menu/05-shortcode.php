<?php
/**
 * Moduł 22-edycja-menu – shortcode [edycja_produktow].
 * Część modułu (pliki wczytywane po kolei – kolejność jak w dawnym jednym pliku).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 5. SHORTCODE [edycja_produktow]
 * ============================================================ */
add_shortcode( 'edycja_produktow', function () {
	if ( ! is_user_logged_in() ) {
		return rzd_staff_login_html( 'Edycja menu', 'Zaloguj się kontem redaktora menu.', 'rzd-ed-login' ); // (2.57.1) wspólny wygląd logowania
	}
	if ( ! rzd_ed_can() ) {
		return '<p style="margin:30px auto;max-width:420px">To konto nie ma uprawnień do edycji menu. Poproś administratora o rolę „Redaktor menu”.</p>';
	}
	$ver = defined( 'RZD_PLUGIN_VERSION' ) ? RZD_PLUGIN_VERSION : '1';
	$js  = RZD_PLUGIN_DIR . 'assets/js/rzd-edycja.js';
	// edytor grup modyfikacji (2.45.0) – wspólny z Panelem restauracji
	wp_enqueue_style( 'rzd-grupy', RZD_PLUGIN_URL . 'assets/css/rzd-grupy.css', array(), rzd_asset_ver( 'assets/css/rzd-grupy.css' ) );
	wp_enqueue_script( 'rzd-grupy', RZD_PLUGIN_URL . 'assets/js/rzd-grupy.js', array(), rzd_asset_ver( 'assets/js/rzd-grupy.js' ), true );
	wp_enqueue_script( 'rzd-edycja', RZD_PLUGIN_URL . 'assets/js/rzd-edycja.js', array( 'rzd-grupy' ), $ver . '.' . (int) @filemtime( $js ), true ); // phpcs:ignore
	wp_add_inline_script( 'rzd-edycja', 'window.rzdEd = ' . wp_json_encode( array(
		'ajax'    => admin_url( 'admin-ajax.php' ),
		'nonce'   => wp_create_nonce( 'rzd_ed' ),
		'logout'  => wp_logout_url( get_permalink() ),
		'home'    => home_url( '/' ),
		'user'    => wp_get_current_user()->display_name,
		'brand'   => function_exists( 'rzd_brand' ) ? rzd_brand() : null, // logo → sklep (2.44.0)
		'panel'   => function_exists( 'rzd_panel_can' ) && rzd_panel_can() ? rzd_panel_url() : '',
		// podgląd opisu w edytorze – ten sam CSS co w sklepie
		'opisCss' => RZD_PLUGIN_URL . 'assets/css/lista-zamowien.css?ver=' . rawurlencode( $ver . '.' . (int) @filemtime( RZD_PLUGIN_DIR . 'assets/css/lista-zamowien.css' ) ), // phpcs:ignore
	) ) . ';', 'before' );
	return '<div id="rzd-ed" class="rzd-ed"><div class="rzd-ed-loading">Wczytuję menu…</div></div>' . rzd_ed_css();
} );

function rzd_ed_css() {
	return rzd_css_tag( 'assets/css/rzd-edycja.css' ); // style ekranu w pliku (2.40.0; wcześniej składane tutaj)
}
