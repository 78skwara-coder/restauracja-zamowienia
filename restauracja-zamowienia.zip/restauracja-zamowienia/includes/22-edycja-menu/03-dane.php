<?php
/**
 * Moduł 22-edycja-menu – dane dla strony.
 * Część modułu (pliki wczytywane po kolei – kolejność jak w dawnym jednym pliku).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 3. DANE DLA STRONY
 * ============================================================ */
function rzd_ed_today() {
	return function_exists( 'rzd_dc_now' ) ? rzd_dc_now()->format( 'Y-m-d' ) : current_time( 'Y-m-d' );
}

function rzd_ed_is_set( $pid ) {
	return function_exists( 'rzd_zestaw_get_slots' ) && (bool) rzd_zestaw_get_slots( $pid );
}

// Danie tylko do zestawów: kategoria z „Nie wyświetlaj w sklepie” (moduł 04).
function rzd_ed_only_in_set( $product ) {
	foreach ( (array) $product->get_category_ids() as $cid ) {
		if ( '1' === (string) get_term_meta( $cid, 'rwz_hide_in_shop', true ) ) {
			return true;
		}
	}
	return false;
}

function rzd_ed_money( $v ) {
	return html_entity_decode( wp_strip_all_tags( wc_price( (float) $v ) ), ENT_QUOTES, 'UTF-8' );
}

function rzd_ed_thumb( $att_id, $size = 'thumbnail' ) {
	$u = $att_id ? wp_get_attachment_image_url( (int) $att_id, $size ) : '';
	return $u ? $u : '';
}

// Wiersz listy produktów.
function rzd_ed_row( $p ) {
	$id     = $p->get_id();
	$is_set = rzd_ed_is_set( $id );
	$thumb  = '';
	if ( $is_set && function_exists( 'rzd_zestaw_split_image_html' ) ) {
		$thumb = rzd_zestaw_split_image_html( $id, 'thumbnail', array(), true );
		if ( ! $thumb && function_exists( 'rzd_zestaw_get_display_image_id' ) ) {
			$thumb = rzd_ed_thumb( rzd_zestaw_get_display_image_id( $id ) );
		}
	}
	if ( ! $thumb ) {
		$thumb = rzd_ed_thumb( get_post_thumbnail_id( $id ) );
	}
	$only = ! $is_set && rzd_ed_only_in_set( $p );
	$sold = rzd_soldout_get( $id );
	return array(
		'id'      => $id,
		'name'    => $p->get_name(),
		'cats'    => array_map( 'intval', (array) $p->get_category_ids() ),
		'price'   => $only ? 'w zestawie' : ( '' !== $p->get_price() ? rzd_ed_money( $p->get_price() ) : '' ),
		'thumb'   => $thumb,
		'is_set'  => $is_set,
		'only'    => $only,
		'sold'    => $sold['always'] ? 'do odwołania' : ( in_array( rzd_ed_today(), $sold['dates'], true ) ? 'dziś' : ( $sold['dates'] ? 'w wybrane dni' : '' ) ),
		'hidden'  => 'publish' !== $p->get_status(),
	);
}

// opisy – edytor sekcji w module 24 (rzd_desc_doc / rzd_desc_prepare); rzd_ed_html_to_text() usunięta.

function rzd_ed_product_data( $p ) {
	$id     = $p->get_id();
	$is_set = rzd_ed_is_set( $id );
	$alg    = wp_get_object_terms( $id, 'alergen', array( 'fields' => 'ids' ) );
	$own    = get_post_thumbnail_id( $id );
	return array(
		'id'         => $id,
		'name'       => $p->get_name(),
		'is_set'     => $is_set,
		'only'       => ! $is_set && rzd_ed_only_in_set( $p ),
		'price_edit' => $p->is_type( 'simple' ),
		'price'      => '' !== $p->get_regular_price() ? str_replace( '.', ',', wc_format_decimal( $p->get_regular_price(), 2 ) ) : '',
		'sale'       => '' !== $p->get_sale_price(),
		// opisy jako sekcje (moduł 24) + kopie opisu
		'short_doc'  => rzd_desc_doc( $p->get_short_description() ),
		'desc_doc'   => rzd_desc_doc( $p->get_description() ),
		'backups'    => rzd_desc_backups_info( $id ),
		'img'        => rzd_ed_thumb( $own, 'medium_large' ),
		'allergens'  => is_wp_error( $alg ) ? array() : array_map( 'intval', $alg ),
		'cats'       => array_map( 'intval', (array) $p->get_category_ids() ), // wybór kategorii (2.40.0)
		'soldout'    => rzd_soldout_get( $id ),
		'edit_url'   => current_user_can( 'edit_post', $id ) ? get_edit_post_link( $id, 'raw' ) : '',
		// skład i grupy modyfikacji (tylko dania – zestaw bierze je ze swoich dań).
		'sklad'      => $is_set ? array() : rzd_ed_sklad_ids( $id ),
		'mods'       => $is_set ? array() : rzd_ed_mods_list( $id ),
		// pełne grupy – edytor grup (2.45.0, assets/js/rzd-grupy.js); kolejność = indeksy z 'mods'
		'groups'     => ( $is_set || ! function_exists( 'rzd_panel_sections_for_editor' ) ) ? array() : rzd_panel_sections_for_editor( rzd_get_sections( $id ) ),
		'mods_sig'   => rzd_ed_mods_sig( $id ),
	);
}

/* ---------- Skład i modyfikacje ---------- */

// ID składników dania (tylko istniejące, opublikowane), w kolejności.
function rzd_ed_sklad_ids( $id ) {
	$out = array();
	foreach ( function_exists( 'rzd_get_product_sklad' ) ? rzd_get_product_sklad( $id ) : array() as $ing ) {
		$out[] = (int) $ing['id'];
	}
	return $out;
}

// Grupy modyfikacji dania – do listy na telefonie (bez szczegółów opcji).
function rzd_ed_mods_list( $id ) {
	$out = array();
	foreach ( function_exists( 'rzd_get_sections' ) ? rzd_get_sections( $id ) : array() as $i => $sec ) {
		$pid   = isset( $sec['preset'] ) ? (int) $sec['preset'] : 0;
		$out[] = array(
			'i'      => (int) $i,
			'header' => isset( $sec['header'] ) ? (string) $sec['header'] : '',
			'count'  => isset( $sec['items'] ) ? count( (array) $sec['items'] ) : 0,
			'preset' => $pid,
		);
	}
	return $out;
}

// Podpis grup – zapis z telefonu odrzucony, gdy ktoś w międzyczasie zmienił grupy w panelu.
function rzd_ed_mods_sig( $id ) {
	return md5( maybe_serialize( get_post_meta( $id, '_rzd_modifiers', true ) ) );
}

/**
 * Nowa lista grup z edycji menu. $ops w kolejności: ['k' => 'own', 'i' => indeks
 * istniejącej grupy] (zostaje bez zmian), ['k' => 'preset', 'id' => ID wzoru]
 * (wstawia KOPIĘ grup wzoru) albo (2.45.0) ['k' => 'data', 'sec' => grupa z edytora grup]
 * – nowa albo zmieniona grupa, czyszczona rzd_sanitize_sections (pusta grupa odpada).
 */
function rzd_ed_build_mods( $id, $ops ) {
	$cur = get_post_meta( $id, '_rzd_modifiers', true );
	$cur = is_array( $cur ) ? array_values( $cur ) : array();
	$out = array();
	$used = array();
	foreach ( $ops as $op ) {
		if ( ! is_array( $op ) || empty( $op['k'] ) ) {
			continue;
		}
		if ( 'own' === $op['k'] ) {
			$i = isset( $op['i'] ) ? (int) $op['i'] : -1;
			if ( isset( $cur[ $i ] ) && ! isset( $used[ $i ] ) ) {
				$out[]      = $cur[ $i ];
				$used[ $i ] = true;
			}
		} elseif ( 'data' === $op['k'] && isset( $op['sec'] ) && is_array( $op['sec'] ) && function_exists( 'rzd_sanitize_sections' ) ) {
			foreach ( rzd_sanitize_sections( array( $op['sec'] ) ) as $sec ) {
				$out[] = $sec;
			}
		} elseif ( 'preset' === $op['k'] && function_exists( 'rzd_preset_copy_sections' ) ) {
			$pid = isset( $op['id'] ) ? absint( $op['id'] ) : 0;
			if ( $pid && 'rzd_mod_preset' === get_post_type( $pid ) && 'publish' === get_post_status( $pid ) ) {
				foreach ( rzd_preset_copy_sections( $pid ) as $sec ) {
					$out[] = $sec;
				}
			}
		}
	}
	return $out;
}

// Katalog do wyboru: dodatki do składu (z Typem) i wzory modyfikacji (z liczbą grup).
function rzd_ed_catalog() {
	$ings = array();
	foreach ( function_exists( 'rzd_get_all_addons' ) ? rzd_get_all_addons() : array() as $ing ) { // skład = dodatki (jeden katalog od 2.32.0)
		if ( ! $ing ) {
			continue;
		}
		$ings[] = array( 'id' => (int) $ing['id'], 'name' => $ing['name'], 'type' => $ing['type_name'] );
	}
	$presets = array();
	foreach ( function_exists( 'rzd_get_all_presets' ) ? rzd_get_all_presets() : array() as $pid => $title ) {
		$n = count( rzd_get_preset_sections( $pid ) );
		if ( $n ) {
			$presets[] = array( 'id' => (int) $pid, 'title' => $title, 'groups' => $n );
		}
	}
	return array( 'ingredients' => $ings, 'presets' => $presets );
}

/* ---------- Zestaw na dzień ---------- */

// Surowe pozycje zestawu w danym dniu (wszystkie pasujące terminy, z „zastępuje”).
function rzd_ed_day_items( $set_id, $date ) {
	$items = array();
	$src   = 'rule';
	foreach ( rzd_zestaw_slots_for_date( $set_id, $date ) as $slot ) {
		if ( ! rzd_zestaw_slot_matches_date( $slot, $date ) ) {
			continue;
		}
		if ( ! empty( $slot['override'] ) ) {
			$src = 'day';
		} elseif ( ! empty( $slot['date'] ) && 'day' !== $src ) {
			$src = 'date';
		}
		foreach ( ( isset( $slot['items'] ) && is_array( $slot['items'] ) ) ? $slot['items'] : array() as $it ) {
			if ( empty( $it['product_id'] ) ) {
				continue;
			}
			$items[] = array(
				'product_id' => (int) $it['product_id'],
				'type'       => ( isset( $it['type'] ) && 'addon' === $it['type'] ) ? 'addon' : 'main',
				'photo'      => empty( $it['photo'] ) ? 0 : 1,
			);
		}
	}
	return array( $items, $src );
}

// Opis produktu do wiersza dnia (nazwa, miniatura, rola, wyprzedane).
function rzd_ed_dish_info( $pid, $date ) {
	$p = wc_get_product( $pid );
	if ( ! $p ) {
		return null;
	}
	$role = function_exists( 'rzd_zestaw_get_set_role' ) ? rzd_zestaw_get_set_role( $pid ) : array( 'label' => '' );
	return array(
		'id'     => (int) $pid,
		'name'   => $p->get_name(),
		'thumb'  => rzd_ed_thumb( get_post_thumbnail_id( $pid ) ),
		'role'   => $role['label'],
		'is_set' => rzd_ed_is_set( $pid ),
		'sold'   => rzd_soldout_on( $pid, $date ),
	);
}

// Zestaw + wszystkie zestawy zagnieżdżone: [ id => [ name, items, src ] ], $info = opisy produktów.
function rzd_ed_day_owners( $set_id, $date, &$owners, &$info, $depth = 0 ) {
	if ( isset( $owners[ $set_id ] ) || $depth > 4 ) {
		return;
	}
	list( $items, $src ) = rzd_ed_day_items( $set_id, $date );
	$owners[ $set_id ] = array( 'name' => get_the_title( $set_id ), 'items' => $items, 'src' => $src );
	foreach ( $items as $it ) {
		$pid = $it['product_id'];
		if ( ! isset( $info[ $pid ] ) ) {
			$i = rzd_ed_dish_info( $pid, $date );
			if ( $i ) {
				$info[ $pid ] = $i;
			}
		}
		if ( rzd_ed_is_set( $pid ) && (int) $pid !== (int) $set_id ) {
			rzd_ed_day_owners( $pid, $date, $owners, $info, $depth + 1 );
		}
	}
}

// Zestawy, w które wpięto dany zestaw (rekurencyjnie w górę).
function rzd_ed_set_parents( $set_id, $seen = array() ) {
	static $memo = array();
	if ( ! $seen && isset( $memo[ (int) $set_id ] ) ) {
		return $memo[ (int) $set_id ];
	}
	$top = ! $seen;
	$out = array();
	if ( ! function_exists( 'rzd_all_sets' ) ) {
		return $out;
	}
	foreach ( rzd_all_sets() as $sid ) {
		if ( (int) $sid === (int) $set_id || in_array( $sid, $seen, true ) ) {
			continue;
		}
		foreach ( rzd_zestaw_get_slots( $sid ) as $slot ) {
			foreach ( ( isset( $slot['items'] ) && is_array( $slot['items'] ) ) ? $slot['items'] : array() as $it ) {
				if ( ! empty( $it['product_id'] ) && (int) $it['product_id'] === (int) $set_id ) {
					$out[] = (int) $sid;
					break 2;
				}
			}
		}
	}
	$all = $out;
	foreach ( $out as $p ) {
		$all = array_merge( $all, rzd_ed_set_parents( $p, array_merge( $seen, array( (int) $set_id ), $out ) ) );
	}
	$all = array_values( array_unique( $all ) );
	if ( $top ) {
		$memo[ (int) $set_id ] = $all;
	}
	return $all;
}

// Złożone zamówienia na ten dzień z którymkolwiek z zestawów (ich skład jest zamrożony).
function rzd_ed_orders_with_sets( $date, $set_ids ) {
	$res = array( 'count' => 0, 'sklady' => array() );
	if ( ! function_exists( 'rzd_kuchnia_orders_for_date' ) || ! $set_ids ) {
		return $res;
	}
	foreach ( rzd_kuchnia_orders_for_date( $date ) as $o ) {
		if ( in_array( $o->get_status(), array( 'cancelled', 'failed', 'refunded' ), true ) ) {
			continue;
		}
		$hit = false;
		foreach ( $o->get_items() as $item ) {
			if ( in_array( (int) $item->get_product_id(), $set_ids, true ) ) {
				$hit = true;
				$w   = (string) $item->get_meta( 'W zestawie' );
				if ( '' !== $w ) {
					$res['sklady'][ $w ] = true;
				}
			}
		}
		if ( $hit ) {
			$res['count']++;
		}
	}
	$res['sklady'] = array_slice( array_keys( $res['sklady'] ), 0, 3 );
	return $res;
}

function rzd_ed_day_data( $set_id, $date ) {
	$owners = array();
	$info   = array();
	rzd_ed_day_owners( $set_id, $date, $owners, $info );
	$active = rzd_zestaw_get_active_components( $set_id, $date );
	$names  = array();
	foreach ( (array) $active['main'] as $p ) {
		if ( (int) $p->get_id() !== (int) $set_id ) {
			$names[] = $p->get_name();
		}
	}
	$preview = function_exists( 'rzd_zestaw_split_image_html' ) ? rzd_zestaw_split_image_html( $set_id, 'woocommerce_thumbnail', array(), true, $date ) : '';
	if ( ! $preview && function_exists( 'rzd_zestaw_get_display_image_ids' ) ) {
		$ids     = rzd_zestaw_get_display_image_ids( $set_id, $date );
		$preview = rzd_ed_thumb( $ids ? $ids[0] : get_post_thumbnail_id( $set_id ), 'woocommerce_thumbnail' );
	}
	$affected = array_values( array_unique( array_merge( array_map( 'intval', array_keys( $owners ) ), rzd_ed_set_parents( $set_id ) ) ) );
	$set      = wc_get_product( $set_id );
	return array(
		'set'      => (int) $set_id,
		'date'     => $date,
		'label'    => rzd_ed_day_label( $date ),
		'owners'   => $owners,
		'info'     => $info,
		'title'    => $names ? implode( ' + ', $names ) : '',
		'preview'  => $preview,
		'has_dish' => function_exists( 'rzd_zestaw_set_has_dish' ) ? rzd_zestaw_set_has_dish( $set_id, $date ) : (bool) $names,
		'orders'   => rzd_ed_orders_with_sets( $date, $affected ),
		'product'  => $set ? rzd_ed_product_data( $set ) : null,
	);
}

function rzd_ed_day_label( $date ) {
	$ts = strtotime( $date . ' 12:00:00' );
	$wd = array( 'nd', 'pon', 'wt', 'śr', 'czw', 'pt', 'sob' );
	return $ts ? $wd[ (int) gmdate( 'w', $ts ) ] . ' ' . gmdate( 'j.m', $ts ) : $date;
}

// Zapis dnia jednego zestawu: jeden termin z tą datą i „zastępuje”, inne terminy tej daty znikają.
function rzd_ed_write_day( $owner, $date, $items ) {
	$slots = rzd_zestaw_get_slots( $owner );
	$keep  = array();
	$from  = '';
	$to    = '';
	foreach ( $slots as $s ) {
		if ( isset( $s['date'] ) && $s['date'] === $date ) {
			continue; // ich dania są w $items (edytor zaczynał od sumy wszystkich terminów dnia)
		}
		if ( '' === $from && '' === $to && empty( $s['date'] ) && rzd_zestaw_slot_matches_date( $s, $date ) ) {
			$from = isset( $s['from'] ) ? (string) $s['from'] : '';
			$to   = isset( $s['to'] ) ? (string) $s['to'] : '';
		}
		$keep[] = $s;
	}
	$keep[] = array(
		'days'      => array(),
		'date'      => $date,
		'date_from' => '',
		'date_to'   => '',
		'from'      => $from,
		'to'        => $to,
		'items'     => $items,
		'override'  => 1,
	);
	update_post_meta( $owner, '_rwz_slots', array_values( $keep ) );
	if ( function_exists( 'rzd_zestaw_rebuild_component_flags' ) ) {
		rzd_zestaw_rebuild_component_flags( $owner );
	}
}

function rzd_ed_clear_caches() {
	if ( function_exists( 'rzd_dc_clear_slots_cache' ) ) {
		rzd_dc_clear_slots_cache();
	}
	if ( function_exists( 'rzd_zestaw_slots_for_date' ) ) {
		rzd_zestaw_slots_for_date( 0, '', true );
	}
}

