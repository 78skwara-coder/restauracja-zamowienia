<?php
/**
 * Moduł 22 – EDYCJA MENU Z TELEFONU
 *
 * Shortcode [edycja_produktow] – osobna strona pełnoekranowa (jak Kuchnia):
 *  - zakładka Produkty: lista z wyszukiwarką i filtrem kategorii; karta
 *    produktu: zdjęcie (aparat / galeria, zmniejszane w przeglądarce),
 *    nazwa, cena brutto, wyprzedane, alergeny, krótki i pełny opis
 *    (edytor sekcji – moduł 24),
 *  - zakładka Zestaw dnia: dania zestawu na wybrany dzień (zmiana, dodanie,
 *    usunięcie, kopiowanie z innego dnia, nowe danie), sam zestaw (nazwa,
 *    cena, wyprzedane w dniu, zdjęcie zastępcze).
 *
 * Dostęp (decyzja użytkownika): konto WordPress z uprawnieniem rzd_edit_menu –
 * rola „Redaktor menu” (tylko ta strona, bez kokpitu) albo administrator /
 * kierownik sklepu. NIE PIN – strona zmienia sklep i wgrywa pliki.
 *
 * Zapis dnia zestawu = termin z KONKRETNĄ DATĄ i znacznikiem 'override'
 * (moduł 04, rwz_slots_for_date): zastępuje reguły dni tygodnia tylko w tym
 * dniu; reguły zostają nietknięte. Zestaw zagnieżdżony (np. „Zupa dnia”
 * w „Zestawie dnia”) zapisuje się w SWOIM harmonogramie – struktura
 * (opakowania, modyfikacje zestawu pośredniego) zostaje.
 *
 * Wyprzedane (meta _rzd_soldout = [ always, dates[] ]) – wg DNIA DOSTAWY,
 * nie magazynu (klient zamawia też na przyszłe dni). Wyprzedane danie
 * wyprzedaje zestaw, w którym jest w tym dniu (decyzja użytkownika).
 */

defined( 'ABSPATH' ) || exit;

if ( ! defined( 'RZD_ED_CAP' ) ) {
	define( 'RZD_ED_CAP', 'rzd_edit_menu' );
}

/* ============================================================
 * 1. ROLA „REDAKTOR MENU” I DOSTĘP
 * ============================================================ */
add_action( 'init', function () {
	if ( '1' === get_option( 'rzd_ed_roles_v' ) ) {
		return;
	}
	if ( ! get_role( 'rzd_menu_editor' ) ) {
		add_role( 'rzd_menu_editor', 'Redaktor menu', array( 'read' => true, RZD_ED_CAP => true ) );
	}
	foreach ( array( 'administrator', 'shop_manager' ) as $r ) {
		$role = get_role( $r );
		if ( $role ) {
			$role->add_cap( RZD_ED_CAP );
		}
	}
	update_option( 'rzd_ed_roles_v', '1', true );
}, 20 );

function rzd_ed_can() {
	return is_user_logged_in() && current_user_can( RZD_ED_CAP );
}

// Sam „Redaktor menu” (bez uprawnień sklepu) – bez kokpitu i paska admina.
function rzd_ed_is_editor_only( $user = null ) {
	$user = $user ? $user : wp_get_current_user();
	return $user && $user->exists() && in_array( 'rzd_menu_editor', (array) $user->roles, true ) && ! user_can( $user, 'manage_woocommerce' ) && ! user_can( $user, 'edit_posts' );
}

function rzd_ed_page_url() {
	$url = function_exists( 'rzd_page_url_opt' ) ? rzd_page_url_opt( 'rzd_ed_page_id', 'edycja_produktow' ) : ''; // też gdy nikt jeszcze nie otworzył strony
	if ( '' !== $url ) {
		return $url;
	}
	$id = (int) get_option( 'rzd_ed_page_id' );
	return ( $id && 'publish' === get_post_status( $id ) ) ? get_permalink( $id ) : home_url( '/' );
}

add_filter( 'show_admin_bar', function ( $show ) {
	return rzd_ed_is_editor_only() ? false : $show;
} );

add_action( 'admin_init', function () {
	if ( wp_doing_ajax() || ! rzd_ed_is_editor_only() ) {
		return;
	}
	wp_safe_redirect( rzd_ed_page_url() );
	exit;
} );

add_filter( 'login_redirect', function ( $to, $requested, $user ) {
	return ( $user instanceof WP_User && rzd_ed_is_editor_only( $user ) ) ? rzd_ed_page_url() : $to;
}, 20, 3 );
add_filter( 'woocommerce_login_redirect', function ( $to, $user ) {
	return ( $user instanceof WP_User && rzd_ed_is_editor_only( $user ) ) ? rzd_ed_page_url() : $to;
}, 20, 2 );

// Strona z edycją nie może trafić do cache strony (dane się zmieniają, jest zalogowany redaktor).
add_action( 'template_redirect', function () {
	if ( ! is_singular() ) {
		return;
	}
	$post = get_post();
	if ( $post && has_shortcode( $post->post_content, 'edycja_produktow' ) ) {
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true );
		}
		nocache_headers();
		if ( (int) get_option( 'rzd_ed_page_id' ) !== (int) $post->ID ) {
			update_option( 'rzd_ed_page_id', (int) $post->ID, false );
		}
	}
} );

