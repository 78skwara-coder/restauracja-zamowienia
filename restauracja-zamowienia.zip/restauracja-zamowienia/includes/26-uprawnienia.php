<?php
/**
 * Moduł 26 – KONFIGURATOR UPRAWNIEŃ: Użytkownicy → Uprawnienia
 *
 * Tabela rola × uprawnienie (model i synchronizacja – moduł 25). Dla
 * Administratora i ról z uprawnieniem „Uprawnienia i konta pracowników”.
 *  - Administrator: zawsze wszystko (wiersz zablokowany),
 *  - Manager: „Panel WP” zablokowany (to rola WooCommerce kierownika sklepu),
 *  - nazwy ról edytowalne; role wbudowane nie do usunięcia,
 *  - „+ Dodaj rolę”: pusta albo kopia istniejącej; własną rolę można usunąć,
 *    gdy nikt jej nie ma,
 *  - zależności: Ustawienia / Raporty / Konta pracowników → Panel WP,
 *  - nie można odebrać sobie dostępu do konfiguratora (poza Administratorem),
 *  - awaryjny PIN kuriera: domyślnie wyłączony, przypomnienie w panelu.
 */

defined( 'ABSPATH' ) || exit;

function rzd_roles_admin_can() {
	return current_user_can( 'manage_options' ) || current_user_can( 'rzd_p_staff' );
}

add_action( 'admin_menu', function () {
	if ( rzd_roles_admin_can() ) {
		add_users_page( 'Uprawnienia', 'Uprawnienia', current_user_can( 'manage_options' ) ? 'manage_options' : 'rzd_p_staff', 'rzd-uprawnienia', 'rzd_roles_admin_page' );
	}
} );

function rzd_roles_user_counts() {
	$c = count_users();
	return isset( $c['avail_roles'] ) ? (array) $c['avail_roles'] : array();
}

function rzd_roles_admin_page() {
	if ( ! rzd_roles_admin_can() ) {
		wp_die( 'Brak uprawnień.' );
	}
	$cfg    = rzd_roles_cfg();
	$cat    = rzd_perm_catalog();
	$counts = rzd_roles_user_counts();
	$msg    = isset( $_GET['rzd_msg'] ) ? sanitize_text_field( wp_unslash( $_GET['rzd_msg'] ) ) : '';
	$err    = isset( $_GET['rzd_err'] ) ? sanitize_text_field( wp_unslash( $_GET['rzd_err'] ) ) : '';
	?>
	<div class="wrap rzd-perm">
		<h1>Uprawnienia</h1>
		<p class="description" style="max-width:900px">Kto co widzi i może zrobić. Zaznacz uprawnienie w wierszu roli i zapisz – zmiana działa od razu dla wszystkich kont z tą rolą.
			Rolę konkretnej osobie nadajesz w <a href="<?php echo esc_url( admin_url( 'users.php' ) ); ?>">Użytkownicy</a> (edycja konta → Rola). Najedź na nagłówek kolumny, żeby zobaczyć opis.</p>
		<?php if ( $msg ) : ?><div class="notice notice-success"><p><?php echo esc_html( $msg ); ?></p></div><?php endif; ?>
		<?php if ( $err ) : ?><div class="notice notice-error"><p><?php echo esc_html( $err ); ?></p></div><?php endif; ?>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="rzd-perm-form">
			<input type="hidden" name="action" value="rzd_roles_save">
			<?php wp_nonce_field( 'rzd_roles_save' ); ?>
			<div class="rzd-perm-scroll">
			<table class="widefat rzd-perm-table">
				<thead><tr>
					<th class="rzd-perm-role">Rola</th>
					<th class="rzd-perm-n" title="Liczba kont z tą rolą">Osób</th>
					<?php foreach ( $cat as $k => $p ) : ?>
						<th title="<?php echo esc_attr( $p[2] . ( $p[3] ? ' Wymaga „Panelu WP”.' : '' ) ); ?>"><span><?php echo esc_html( $p[0] ); ?></span></th>
					<?php endforeach; ?>
					<th></th>
				</tr></thead>
				<tbody>
					<tr class="rzd-perm-locked">
						<td class="rzd-perm-role"><strong>Administrator</strong><br><small>zawsze wszystko</small></td>
						<td class="rzd-perm-n"><?php echo (int) ( isset( $counts['administrator'] ) ? $counts['administrator'] : 0 ); ?></td>
						<?php foreach ( $cat as $k => $p ) : ?><td><input type="checkbox" checked disabled aria-label="<?php echo esc_attr( 'Administrator – ' . $p[0] ); ?>"></td><?php endforeach; ?>
						<td></td>
					</tr>
					<?php foreach ( $cfg['roles'] as $slug => $r ) :
						$perms = rzd_perms_normalize( $r['perms'] );
						$n     = isset( $counts[ $slug ] ) ? (int) $counts[ $slug ] : 0;
						?>
					<tr data-role="<?php echo esc_attr( $slug ); ?>">
						<td class="rzd-perm-role">
							<input type="text" name="roles[<?php echo esc_attr( $slug ); ?>][name]" value="<?php echo esc_attr( $r['name'] ); ?>" maxlength="40" aria-label="Nazwa roli">
							<?php if ( empty( $r['builtin'] ) ) : ?><br><small>własna</small><?php endif; ?>
						</td>
						<td class="rzd-perm-n"><?php echo $n ? '<a href="' . esc_url( admin_url( 'users.php?role=' . rawurlencode( $slug ) ) ) . '">' . (int) $n . '</a>' : '0'; ?></td>
						<?php foreach ( $cat as $k => $p ) :
							$on     = in_array( $k, $perms, true ) || ( 'shop_manager' === $slug && 'shop' === $k );
							$locked = ( 'shop_manager' === $slug && 'shop' === $k );
							?>
							<td>
								<input type="checkbox" class="rzd-pc" data-k="<?php echo esc_attr( $k ); ?>" data-needs-shop="<?php echo $p[3] ? '1' : '0'; ?>" name="roles[<?php echo esc_attr( $slug ); ?>][perms][]" value="<?php echo esc_attr( $k ); ?>"<?php checked( $on ); ?><?php disabled( $locked ); ?> aria-label="<?php echo esc_attr( $r['name'] . ' – ' . $p[0] ); ?>">
								<?php if ( $locked ) : ?><input type="hidden" name="roles[<?php echo esc_attr( $slug ); ?>][perms][]" value="shop"><?php endif; ?>
							</td>
						<?php endforeach; ?>
						<td>
							<?php if ( empty( $r['builtin'] ) ) : ?>
								<button type="submit" class="button-link-delete" name="delete" value="<?php echo esc_attr( $slug ); ?>"<?php disabled( $n > 0 ); ?> title="<?php echo $n ? esc_attr( 'Najpierw zmień rolę osobom, które ją mają (' . $n . ')' ) : 'Usuń rolę'; ?>" onclick="return confirm('Usunąć rolę „<?php echo esc_js( $r['name'] ); ?>”?');">Usuń</button>
							<?php endif; ?>
						</td>
					</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			</div>
			<p class="rzd-perm-dep" id="rzd-perm-dep" hidden></p>
			<p><button type="submit" class="button button-primary" name="save" value="1">Zapisz uprawnienia</button></p>

			<h2>Dodaj rolę</h2>
			<p class="description">Np. „Kelner” albo „Pomoc kuchenna”. Możesz zacząć od kopii istniejącej roli i potem zmienić uprawnienia w tabeli.</p>
			<p>
				<input type="text" name="new_name" maxlength="40" placeholder="Nazwa roli" aria-label="Nazwa nowej roli">
				<select name="new_base" aria-label="Uprawnienia na start">
					<option value="">— bez uprawnień —</option>
					<?php foreach ( $cfg['roles'] as $slug => $r ) : ?>
						<option value="<?php echo esc_attr( $slug ); ?>">jak „<?php echo esc_html( $r['name'] ); ?>”</option>
					<?php endforeach; ?>
				</select>
				<button type="submit" class="button" name="add" value="1">+ Dodaj rolę</button>
			</p>

			<h2>Kurier – awaryjny PIN</h2>
			<p class="description" style="max-width:900px">Kurier loguje się własnym kontem (rola z uprawnieniem „Kurier”, logowanie na 30 dni). PIN jest tylko na zastępstwo – np. kurier na jeden dzień bez konta.
				Każdy z PIN-em może oznaczać zamówienia jako „Dostarczone” i widzi adresy klientów, a w zamówieniu zapisze się tylko „kurier (PIN awaryjny)”. Po 5 błędnych próbach wejście jest blokowane na 15 minut. Wyłącz PIN, gdy zastępstwo się skończy.</p>
			<p>
				<label><input type="checkbox" name="pin_on" value="1"<?php checked( ! empty( $cfg['pin']['on'] ) ); ?>> Włącz awaryjny PIN kuriera</label>
				<?php if ( ! empty( $cfg['pin']['on'] ) && $cfg['pin']['since'] ) : ?><small>(włączony od <?php echo esc_html( mysql2date( 'd.m.Y', $cfg['pin']['since'] ) ); ?>)</small><?php endif; ?>
			</p>
			<p><label>PIN (min. 4 znaki): <input type="text" name="pin" value="<?php echo esc_attr( get_option( 'kurier_pin', '' ) ); ?>" autocomplete="off" style="width:120px"></label></p>
			<p><button type="submit" class="button button-primary" name="save" value="1">Zapisz</button></p>

			<h2>Opis uprawnień</h2>
			<table class="widefat striped" style="max-width:900px"><tbody>
				<?php foreach ( $cat as $k => $p ) : ?>
					<tr><td style="width:220px"><strong><?php echo esc_html( $p[0] ); ?></strong></td><td><?php echo esc_html( $p[2] ); ?><?php echo $p[3] ? ' <em>Wymaga „Panelu WP”.</em>' : ''; ?></td></tr>
				<?php endforeach; ?>
			</tbody></table>
		</form>
	</div>
	<?php echo rzd_css_tag( 'assets/css/admin/rzd-uprawnienia.css' ); // phpcs:ignore ?>
	<?php echo rzd_js_tag( 'assets/js/admin/rzd-uprawnienia.js' ); // phpcs:ignore ?>
	<?php
}

/* ============================================================
 * Zapis
 * ============================================================ */
add_action( 'admin_post_rzd_roles_save', function () {
	if ( ! rzd_roles_admin_can() ) {
		wp_die( 'Brak uprawnień.' );
	}
	check_admin_referer( 'rzd_roles_save' );
	$cfg    = rzd_roles_cfg();
	$cat    = rzd_perm_catalog();
	$back   = admin_url( 'users.php?page=rzd-uprawnienia' );
	$msg    = 'Zapisano uprawnienia.';
	$err    = '';
	$in     = isset( $_POST['roles'] ) && is_array( $_POST['roles'] ) ? wp_unslash( $_POST['roles'] ) : array(); // phpcs:ignore
	$admin  = current_user_can( 'manage_options' );
	$mine   = (array) wp_get_current_user()->roles;

	// 1. Tabela: nazwy i uprawnienia ról
	foreach ( $cfg['roles'] as $slug => $r ) {
		if ( ! isset( $in[ $slug ] ) || ! is_array( $in[ $slug ] ) ) {
			continue;
		}
		$name = isset( $in[ $slug ]['name'] ) ? trim( sanitize_text_field( $in[ $slug ]['name'] ) ) : '';
		if ( '' !== $name ) {
			$cfg['roles'][ $slug ]['name'] = function_exists( 'mb_substr' ) ? mb_substr( $name, 0, 40 ) : substr( $name, 0, 40 );
		}
		$perms = rzd_perms_normalize( isset( $in[ $slug ]['perms'] ) ? (array) $in[ $slug ]['perms'] : array() );
		if ( 'shop_manager' === $slug && ! in_array( 'shop', $perms, true ) ) {
			$perms = rzd_perms_normalize( array_merge( $perms, array( 'shop' ) ) );
		}
		// Nie można odebrać SOBIE dostępu do konfiguratora (Administrator ma go zawsze).
		if ( ! $admin && in_array( $slug, $mine, true ) && ! in_array( 'staff', $perms, true ) ) {
			$perms = rzd_perms_normalize( array_merge( $perms, array( 'staff' ) ) );
			$err   = 'Nie możesz odebrać sobie uprawnienia „Uprawnienia i konta pracowników” – zostało zachowane w roli „' . $cfg['roles'][ $slug ]['name'] . '”.';
		}
		$cfg['roles'][ $slug ]['perms'] = $perms;
	}

	// 2. Usunięcie własnej roli (tylko bez użytkowników)
	if ( ! empty( $_POST['delete'] ) ) {
		$slug   = sanitize_key( wp_unslash( $_POST['delete'] ) );
		$counts = rzd_roles_user_counts();
		if ( isset( $cfg['roles'][ $slug ] ) && empty( $cfg['roles'][ $slug ]['builtin'] ) ) {
			if ( ! empty( $counts[ $slug ] ) ) {
				$err = 'Rola „' . $cfg['roles'][ $slug ]['name'] . '” ma przypisane konta (' . (int) $counts[ $slug ] . ') – najpierw zmień im rolę.';
			} else {
				$msg = 'Usunięto rolę „' . $cfg['roles'][ $slug ]['name'] . '”.';
				unset( $cfg['roles'][ $slug ] );
				remove_role( $slug );
			}
		}
	}

	// 3. Nowa rola
	if ( ! empty( $_POST['add'] ) ) {
		$name = isset( $_POST['new_name'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['new_name'] ) ) ) : '';
		if ( '' === $name ) {
			$err = 'Podaj nazwę nowej roli.';
		} else {
			$base = isset( $_POST['new_base'] ) ? sanitize_key( wp_unslash( $_POST['new_base'] ) ) : '';
			$key  = sanitize_key( str_replace( '-', '_', sanitize_title( $name ) ) );
			$key  = '' !== $key ? $key : 'rola';
			$slug = 'rzd_role_c_' . substr( $key, 0, 30 );
			$i    = 2;
			while ( isset( $cfg['roles'][ $slug ] ) || get_role( $slug ) ) {
				$slug = 'rzd_role_c_' . substr( $key, 0, 27 ) . '_' . $i++;
			}
			$cfg['roles'][ $slug ] = array(
				'name'    => function_exists( 'mb_substr' ) ? mb_substr( $name, 0, 40 ) : substr( $name, 0, 40 ),
				'builtin' => 0,
				'perms'   => ( $base && isset( $cfg['roles'][ $base ] ) ) ? rzd_perms_normalize( $cfg['roles'][ $base ]['perms'] ) : array(),
			);
			$msg = 'Dodano rolę „' . $cfg['roles'][ $slug ]['name'] . '” – ustaw jej uprawnienia w tabeli i zapisz.';
		}
	}

	// 4. Awaryjny PIN kuriera
	$pin_on = ! empty( $_POST['pin_on'] );
	$pin    = isset( $_POST['pin'] ) ? preg_replace( '/[^0-9A-Za-z]/', '', wp_unslash( $_POST['pin'] ) ) : (string) get_option( 'kurier_pin', '' );
	if ( $pin_on && strlen( $pin ) < 4 ) {
		$pin_on = false;
		$err    = 'Awaryjny PIN musi mieć co najmniej 4 znaki – PIN pozostaje wyłączony.';
	}
	update_option( 'kurier_pin', $pin, false );
	if ( $pin_on && empty( $cfg['pin']['on'] ) ) {
		$cfg['pin']['since'] = current_time( 'mysql' );
	}
	$cfg['pin']['on'] = $pin_on ? 1 : 0;
	if ( ! $pin_on ) {
		$cfg['pin']['since'] = '';
	}

	update_option( 'rzd_roles_cfg', $cfg, true );
	rzd_roles_cfg_flush();
	rzd_roles_sync( rzd_roles_cfg() );

	wp_safe_redirect( add_query_arg( array_filter( array( 'rzd_msg' => $msg, 'rzd_err' => $err ) ), $back ) );
	exit;
} );
