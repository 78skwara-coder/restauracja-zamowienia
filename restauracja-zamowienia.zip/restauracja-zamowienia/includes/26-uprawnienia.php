<?php
/**
 * Moduł 26 – KONFIGURATOR UPRAWNIEŃ (zapis) – ekran: Panel restauracji → Zespół → Uprawnienia (moduł 34;
 * do 2.45.0 kokpit: Użytkownicy → Uprawnienia).
 *
 * Tabela rola × uprawnienie (model i synchronizacja – moduł 25). Dla
 * Administratora i ról z uprawnieniem „Uprawnienia i konta pracowników”.
 *  - Administrator: zawsze wszystko (wiersz zablokowany),
 *  - Manager: „Panel WP” zablokowany (to rola WooCommerce kierownika sklepu),
 *  - nazwy ról edytowalne; role wbudowane nie do usunięcia,
 *  - „+ Dodaj rolę”: pusta albo kopia istniejącej; własną rolę można usunąć,
 *    gdy nikt jej nie ma,
 *  - zależności: Ustawienia / Raporty / Formularze / Konta pracowników → Panel WP,
 *  - nie można odebrać sobie dostępu do konfiguratora (poza Administratorem),
 *  - awaryjny PIN kuriera: domyślnie wyłączony, przypomnienie w panelu.
 */

defined( 'ABSPATH' ) || exit;

function rzd_roles_admin_can() {
	return current_user_can( 'manage_options' ) || current_user_can( 'rzd_p_staff' );
}

function rzd_roles_user_counts() {
	$c = count_users();
	return isset( $c['avail_roles'] ) ? (array) $c['avail_roles'] : array();
}

/** Zapis konfiguracji ról + synchronizacja z rolami WordPressa. */
function rzd_roles_commit( $cfg ) {
	$cfg['known'] = array_keys( rzd_perm_catalog() ); // uprawnienia znane w chwili zapisu – nowe dopisze migracja (moduł 25)
	update_option( 'rzd_roles_cfg', $cfg, true );
	rzd_roles_cfg_flush();
	rzd_roles_sync( rzd_roles_cfg() );
}

function rzd_roles_clip( $name ) {
	$name = trim( sanitize_text_field( (string) $name ) );
	return function_exists( 'mb_substr' ) ? mb_substr( $name, 0, 40 ) : substr( $name, 0, 40 );
}

/**
 * Tabela: $in = { slug: { name, perms[], hist_days } }. Zwraca '' albo ostrzeżenie (np. próba
 * odebrania sobie konfiguratora – uprawnienie zostaje).
 */
function rzd_roles_save_table( $in ) {
	$cfg   = rzd_roles_cfg();
	$in    = is_array( $in ) ? $in : array();
	$admin = current_user_can( 'manage_options' );
	$mine  = (array) wp_get_current_user()->roles;
	$warn  = '';
	foreach ( $cfg['roles'] as $slug => $r ) {
		if ( ! isset( $in[ $slug ] ) || ! is_array( $in[ $slug ] ) ) {
			continue;
		}
		$name = isset( $in[ $slug ]['name'] ) ? rzd_roles_clip( $in[ $slug ]['name'] ) : '';
		if ( '' !== $name ) {
			$cfg['roles'][ $slug ]['name'] = $name;
		}
		$perms = rzd_perms_normalize( isset( $in[ $slug ]['perms'] ) ? (array) $in[ $slug ]['perms'] : array() );
		if ( 'shop_manager' === $slug && ! in_array( 'shop', $perms, true ) ) {
			$perms = rzd_perms_normalize( array_merge( $perms, array( 'shop' ) ) );
		}
		// Nie można odebrać SOBIE dostępu do konfiguratora (Administrator ma go zawsze).
		if ( ! $admin && in_array( $slug, $mine, true ) && ! in_array( 'staff', $perms, true ) ) {
			$perms = rzd_perms_normalize( array_merge( $perms, array( 'staff' ) ) );
			$warn  = 'Nie możesz odebrać sobie uprawnienia „Uprawnienia i konta pracowników” – zostało zachowane w roli „' . $cfg['roles'][ $slug ]['name'] . '”.';
		}
		$cfg['roles'][ $slug ]['perms'] = $perms;
		// Dni wstecz w Kuchni (puste = bez limitu) – od 2.41.0 przy każdej roli.
		if ( isset( $in[ $slug ]['hist_days'] ) ) {
			$hd = trim( (string) $in[ $slug ]['hist_days'] );
			$cfg['roles'][ $slug ]['hist_days'] = ( '' === $hd || ! is_numeric( $hd ) ) ? '' : max( 0, min( rzd_history_days_max(), (int) $hd ) );
		}
	}
	rzd_roles_commit( $cfg );
	return $warn;
}

/** Nowa rola (pusta albo z uprawnieniami $base). Slug albo WP_Error. */
function rzd_roles_add( $name, $base = '' ) {
	$cfg  = rzd_roles_cfg();
	$name = rzd_roles_clip( $name );
	if ( '' === $name ) {
		return new WP_Error( 'rzd_roles', 'Podaj nazwę nowej roli.' );
	}
	foreach ( $cfg['roles'] as $r ) {
		if ( 0 === strcasecmp( (string) $r['name'], $name ) ) {
			return new WP_Error( 'rzd_roles', 'Rola „' . $name . '” już jest.' );
		}
	}
	$base = sanitize_key( (string) $base );
	$key  = sanitize_key( str_replace( '-', '_', sanitize_title( $name ) ) );
	$key  = '' !== $key ? $key : 'rola';
	$slug = 'rzd_role_c_' . substr( $key, 0, 30 );
	$i    = 2;
	while ( isset( $cfg['roles'][ $slug ] ) || get_role( $slug ) ) {
		$slug = 'rzd_role_c_' . substr( $key, 0, 27 ) . '_' . $i++;
	}
	$cfg['roles'][ $slug ] = array(
		'name'    => $name,
		'builtin' => 0,
		'perms'   => ( $base && isset( $cfg['roles'][ $base ] ) ) ? rzd_perms_normalize( $cfg['roles'][ $base ]['perms'] ) : array(),
	);
	if ( $base && isset( $cfg['roles'][ $base ]['hist_days'] ) ) {
		$cfg['roles'][ $slug ]['hist_days'] = $cfg['roles'][ $base ]['hist_days'];
	}
	rzd_roles_commit( $cfg );
	return $slug;
}

/** Usunięcie własnej roli – tylko bez kont. true albo WP_Error. */
function rzd_roles_delete( $slug ) {
	$cfg  = rzd_roles_cfg();
	$slug = sanitize_key( (string) $slug );
	if ( ! isset( $cfg['roles'][ $slug ] ) || ! empty( $cfg['roles'][ $slug ]['builtin'] ) ) {
		return new WP_Error( 'rzd_roles', 'Tej roli nie można usunąć.' );
	}
	$counts = rzd_roles_user_counts();
	if ( ! empty( $counts[ $slug ] ) ) {
		return new WP_Error( 'rzd_roles', 'Rola „' . $cfg['roles'][ $slug ]['name'] . '” ma przypisane konta (' . (int) $counts[ $slug ] . ') – najpierw zmień im rolę.' );
	}
	unset( $cfg['roles'][ $slug ] );
	remove_role( $slug );
	rzd_roles_commit( $cfg );
	return true;
}

/** Awaryjny PIN kuriera. true albo WP_Error (PIN krótszy niż 4 znaki – zostaje wyłączony). */
function rzd_courier_pin_save( $on, $pin ) {
	$cfg = rzd_roles_cfg();
	$pin = preg_replace( '/[^0-9A-Za-z]/', '', (string) $pin );
	$err = null;
	$on  = (bool) $on;
	if ( $on && strlen( $pin ) < 4 ) {
		$on  = false;
		$err = new WP_Error( 'rzd_pin', 'Awaryjny PIN musi mieć co najmniej 4 znaki (litery, cyfry) – PIN pozostaje wyłączony.' );
	}
	update_option( 'kurier_pin', $pin, false );
	if ( $on && empty( $cfg['pin']['on'] ) ) {
		$cfg['pin']['since'] = current_time( 'mysql' );
	}
	$cfg['pin']['on'] = $on ? 1 : 0;
	if ( ! $on ) {
		$cfg['pin']['since'] = '';
	}
	rzd_roles_commit( $cfg );
	return $err ? $err : true;
}

/* ============================================================
 * KONTA PRACOWNIKÓW (Panel restauracji → Zespół → Konta, 2.45.0)
 * Konto = użytkownik WordPressa z rolą z konfiguratora. Uprawnienia WordPressa (create_users,
 * edit_user…) daje rola z „Uprawnieniami i kontami pracowników” (moduł 25), a map_meta_cap
 * pilnuje, żeby nikt poza Administratorem nie ruszał kont Administratora.
 * Wyłączenie konta = bez roli (poprzednia zapamiętana, sesje wylogowane) – do ponownego włączenia.
 * ============================================================ */

// Ostatnie logowanie – do listy kont (kto jeszcze korzysta z konta).
add_action( 'wp_login', function ( $login, $user ) {
	if ( $user instanceof WP_User ) {
		update_user_meta( $user->ID, 'rzd_last_login', time() );
	}
}, 10, 2 );

/** Role, które wolno nadać: z konfiguratora (+ Administrator – tylko przez Administratora). */
function rzd_staff_roles() {
	$out = array();
	if ( current_user_can( 'manage_options' ) ) {
		$out['administrator'] = 'Administrator';
	}
	foreach ( rzd_roles_cfg()['roles'] as $slug => $r ) {
		if ( get_role( $slug ) ) {
			$out[ $slug ] = (string) $r['name'];
		}
	}
	return $out;
}

/** Konta pracowników (bez klientów): z rolą z konfiguratora, Administratorzy i konta wyłączone. */
function rzd_staff_users() {
	$roles = array_merge( array( 'administrator' ), array_keys( rzd_roles_cfg()['roles'] ) );
	$ids   = get_users( array( 'role__in' => $roles, 'fields' => 'ID', 'number' => 500 ) );
	$off   = get_users( array( 'meta_key' => '_rzd_disabled_roles', 'fields' => 'ID', 'number' => 200 ) ); // phpcs:ignore
	$names = rzd_roles_cfg()['roles'];
	$out   = array();
	foreach ( array_unique( array_map( 'intval', array_merge( $ids, $off ) ) ) as $id ) {
		$u = get_userdata( $id );
		if ( ! $u ) {
			continue;
		}
		$disabled = (array) get_user_meta( $id, '_rzd_disabled_roles', true );
		$disabled = array_filter( $disabled );
		$role     = '';
		foreach ( (array) $u->roles as $r ) {
			if ( 'administrator' === $r || isset( $names[ $r ] ) ) {
				$role = $r;
				break;
			}
		}
		if ( '' === $role && $disabled ) {
			$role = (string) reset( $disabled );
		}
		$last = (int) get_user_meta( $id, 'rzd_last_login', true );
		$out[] = array(
			'id'       => $id,
			'login'    => $u->user_login,
			'name'     => $u->display_name,
			'email'    => $u->user_email,
			'role'     => $role,
			'roleName' => 'administrator' === $role ? 'Administrator' : ( isset( $names[ $role ] ) ? (string) $names[ $role ]['name'] : $role ),
			'disabled' => (bool) $disabled,
			'self'     => get_current_user_id() === $id,
			'canEdit'  => current_user_can( 'edit_user', $id ),
			'canDel'   => get_current_user_id() !== $id && current_user_can( 'delete_user', $id ),
			'last'     => $last ? wp_date( 'j.m.Y H:i', $last ) : '',
		);
	}
	usort( $out, function ( $a, $b ) {
		return $a['disabled'] !== $b['disabled'] ? ( $a['disabled'] ? 1 : -1 ) : strcoll( $a['name'], $b['name'] );
	} );
	return $out;
}

/**
 * Nowe konto ($id = 0) albo zmiana. $in: login (tylko nowe), name, email, role, pass ('' = bez zmiany;
 * przy nowym puste = wygenerowane). Zwraca [ id, hasło wygenerowane albo '' ] albo WP_Error.
 */
function rzd_staff_user_save( $id, $in ) {
	$id    = (int) $id;
	$in    = is_array( $in ) ? $in : array();
	$roles = rzd_staff_roles();
	$role  = isset( $in['role'] ) ? sanitize_key( (string) $in['role'] ) : '';
	$name  = trim( sanitize_text_field( isset( $in['name'] ) ? (string) $in['name'] : '' ) );
	$email = trim( sanitize_email( isset( $in['email'] ) ? (string) $in['email'] : '' ) );
	$pass  = isset( $in['pass'] ) ? (string) $in['pass'] : '';
	if ( isset( $in['email'] ) && '' !== trim( (string) $in['email'] ) && ! is_email( $email ) ) {
		return new WP_Error( 'rzd_staff', 'Niepoprawny adres e-mail.' );
	}
	if ( '' !== $pass && ( function_exists( 'mb_strlen' ) ? mb_strlen( $pass ) : strlen( $pass ) ) < 8 ) {
		return new WP_Error( 'rzd_staff', 'Hasło musi mieć co najmniej 8 znaków.' );
	}
	$gen = '';
	if ( ! $id ) {
		if ( ! current_user_can( 'create_users' ) ) {
			return new WP_Error( 'rzd_staff', 'To konto nie może zakładać kont.' );
		}
		$login = sanitize_user( preg_replace( '/\s+/', '.', trim( isset( $in['login'] ) ? (string) $in['login'] : '' ) ), true ); // spacje → kropka (ania.kuchnia)
		if ( '' === $login ) {
			return new WP_Error( 'rzd_staff', 'Podaj login (bez polskich znaków i spacji, np. ania.kuchnia).' );
		}
		if ( username_exists( $login ) ) {
			return new WP_Error( 'rzd_staff', 'Login „' . $login . '” jest już zajęty.' );
		}
		if ( ! isset( $roles[ $role ] ) ) {
			return new WP_Error( 'rzd_staff', 'Wybierz rolę.' );
		}
		if ( '' !== $email && email_exists( $email ) ) {
			return new WP_Error( 'rzd_staff', 'Ten adres e-mail ma już inne konto.' );
		}
		if ( '' === $pass ) {
			$gen  = wp_generate_password( 12, false );
			$pass = $gen;
		}
		$new = wp_insert_user( array(
			'user_login'   => $login,
			'user_pass'    => $pass,
			'user_email'   => $email,
			'display_name' => '' !== $name ? $name : $login,
			'first_name'   => '' !== $name ? $name : '',
			'role'         => $role,
		) );
		if ( is_wp_error( $new ) ) {
			return $new;
		}
		update_user_meta( $new, 'show_admin_bar_front', 'false' );
		return array( (int) $new, $gen );
	}
	$u = get_userdata( $id );
	if ( ! $u || ! current_user_can( 'edit_user', $id ) ) {
		return new WP_Error( 'rzd_staff', 'Nie możesz zmieniać tego konta.' );
	}
	if ( '' !== $role && ! in_array( $role, (array) $u->roles, true ) ) {
		if ( ! isset( $roles[ $role ] ) || ! current_user_can( 'promote_user', $id ) ) {
			return new WP_Error( 'rzd_staff', 'Tej roli nie możesz nadać.' );
		}
		if ( get_current_user_id() === $id ) {
			return new WP_Error( 'rzd_staff', 'Nie zmienisz roli własnego konta – poproś o to drugą osobę z dostępem do Zespołu.' );
		}
	}
	$data = array( 'ID' => $id );
	if ( '' !== $name ) {
		$data['display_name'] = $name;
	}
	if ( isset( $in['email'] ) ) {
		$other = '' !== $email ? email_exists( $email ) : false;
		if ( $other && (int) $other !== $id ) {
			return new WP_Error( 'rzd_staff', 'Ten adres e-mail ma już inne konto.' );
		}
		$data['user_email'] = $email;
	}
	if ( '' !== $pass ) {
		$data['user_pass'] = $pass;
	}
	$r = wp_update_user( $data );
	if ( is_wp_error( $r ) ) {
		return $r;
	}
	$off = array_filter( (array) get_user_meta( $id, '_rzd_disabled_roles', true ) );
	if ( '' !== $role && ! $off ) {
		if ( ! in_array( $role, (array) $u->roles, true ) ) {
			$u = new WP_User( $id );
			foreach ( array_merge( array( 'administrator' ), array_keys( rzd_roles_cfg()['roles'] ) ) as $r0 ) {
				if ( in_array( $r0, (array) $u->roles, true ) ) {
					$u->remove_role( $r0 ); // inne role (np. klient sklepu) zostają
				}
			}
			$u->add_role( $role );
		}
	} elseif ( '' !== $role && $off && isset( $roles[ $role ] ) ) {
		update_user_meta( $id, '_rzd_disabled_roles', array( $role ) ); // wyłączone – nowa rola po włączeniu
	}
	return array( $id, '' );
}

/** Wyłączenie / włączenie konta. true albo WP_Error. */
function rzd_staff_user_toggle( $id, $enable ) {
	$id = (int) $id;
	$u  = get_userdata( $id );
	if ( ! $u || get_current_user_id() === $id || ! current_user_can( 'edit_user', $id ) || ! current_user_can( 'promote_user', $id ) ) {
		return new WP_Error( 'rzd_staff', 'Nie możesz wyłączyć tego konta.' );
	}
	$u = new WP_User( $id );
	if ( $enable ) {
		$prev = array_filter( (array) get_user_meta( $id, '_rzd_disabled_roles', true ) );
		$ok   = array_intersect( $prev, array_keys( rzd_staff_roles() ) );
		if ( ! $ok ) {
			return new WP_Error( 'rzd_staff', 'Nie ma już poprzedniej roli tego konta – wybierz rolę i zapisz.' );
		}
		foreach ( $ok as $r ) {
			$u->add_role( $r );
		}
		delete_user_meta( $id, '_rzd_disabled_roles' );
		return true;
	}
	$keep = array_values( (array) $u->roles );
	if ( ! $keep ) {
		return true;
	}
	update_user_meta( $id, '_rzd_disabled_roles', $keep );
	$u->set_role( '' );
	if ( class_exists( 'WP_Session_Tokens' ) ) {
		WP_Session_Tokens::get_instance( $id )->destroy_all(); // wylogowanie ze wszystkich urządzeń
	}
	return true;
}

/** Usunięcie konta – treści (wpisy, strony) przechodzą na usuwającego. true albo WP_Error. */
function rzd_staff_user_delete( $id ) {
	$id = (int) $id;
	if ( ! get_userdata( $id ) || get_current_user_id() === $id || ! current_user_can( 'delete_user', $id ) ) {
		return new WP_Error( 'rzd_staff', 'Nie możesz usunąć tego konta.' );
	}
	require_once ABSPATH . 'wp-admin/includes/user.php';
	return wp_delete_user( $id, get_current_user_id() ) ? true : new WP_Error( 'rzd_staff', 'Nie udało się usunąć konta.' );
}

/** Link do ustawienia hasła mailem (konto musi mieć e-mail). true albo WP_Error. */
function rzd_staff_user_reset_link( $id ) {
	$u = get_userdata( (int) $id );
	if ( ! $u || ! current_user_can( 'edit_user', (int) $id ) ) {
		return new WP_Error( 'rzd_staff', 'Nie możesz zmieniać tego konta.' );
	}
	if ( '' === (string) $u->user_email ) {
		return new WP_Error( 'rzd_staff', 'Konto nie ma adresu e-mail – ustaw hasło ręcznie.' );
	}
	$r = retrieve_password( $u->user_login );
	return is_wp_error( $r ) ? $r : true;
}
