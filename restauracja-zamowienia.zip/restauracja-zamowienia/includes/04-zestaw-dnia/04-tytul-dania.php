<?php
/**
 * Moduł 04-zestaw-dnia – tytuł dania dnia na stronie produktu.
 * Część modułu (pliki wczytywane po kolei – kolejność jak w dawnym jednym pliku).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// 5) Podmień tytuł na stronie produktu na dzisiejsze "danie główne"
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_title', 5 );
add_action( 'woocommerce_single_product_summary', 'rzd_zestaw_render_single_title', 5 );
/**
 * Złożona nazwa zestawu (np. "Tradycyjny Schab z Kością + Zupa dnia") –
 * ta sama logika, co na stronie pojedynczego produktu (rzd_zestaw_render_single_title),
 * tylko jako zwykła funkcja do użycia gdzie indziej (np. na liście zamówień).
 * Zwraca $default_name bez zmian, jeśli to nie jest zestaw (albo nie ma
 * dziś żadnych aktywnych dań głównych).
 */
/**
 * ID zdjęcia do pokazania dla zestawu: w pierwszej kolejności zdjęcie
 * PODPIĘTEGO na dziś dania głównego (jeśli jest i faktycznie ma zdjęcie),
 * dopiero gdy nic nie jest podpięte (albo podpięty produkt nie ma własnego
 * zdjęcia) – zdjęcie produktu NADRZĘDNEGO (samego zestawu). Używane zarówno
 * na liście (moduł 2), jak i na stronie pojedynczego produktu.
 */
function rzd_zestaw_get_display_image_id( $product_id ) {
	$ids = rzd_zestaw_get_display_image_ids( $product_id );
	return $ids ? $ids[0] : get_post_thumbnail_id( $product_id );
}

/**
 * zdjęcia dań do pokazania dla zestawu (0, 1 albo 2 ID załączników).
 * Checkbox „Zdjęcie” przy daniu w zestawie:
 *  - zaznaczone DOKŁADNIE jedno danie (z własnym zdjęciem) → tylko ono (bez podziału),
 *  - zaznaczone kilka → podział między zaznaczone,
 *  - żadne → podział między dania z własnym zdjęciem (kolejność z zestawu).
 * Zawsze najwyżej DWA zdjęcia (decyzja użytkownika – nawet gdy dań jest więcej).
 * Pusta tablica = brak dania ze zdjęciem (wołający bierze zdjęcie samego zestawu).
 */
function rzd_zestaw_get_display_image_ids( $product_id, $date = null ) {
	static $memo = array();
	$product_id = (int) $product_id;
	$mk         = $product_id . '|' . ( $date ? $date : '' );
	if ( isset( $memo[ $mk ] ) ) {
		return $memo[ $mk ];
	}
	if ( ! function_exists( 'rzd_zestaw_get_active_components' ) ) {
		return array();
	}
	$active = rzd_zestaw_get_active_components( $product_id, $date );
	$marked = array();
	$all    = array();
	foreach ( (array) $active['main'] as $p ) {
		if ( (int) $p->get_id() === $product_id ) {
			continue; // to sam zestaw (brak podpiętego dania na dziś)
		}
		$img = (int) $p->get_image_id();
		if ( ! $img || in_array( $img, $all, true ) ) {
			continue; // bez zdjęcia albo to samo zdjęcie drugi raz – podział nie miałby sensu
		}
		$all[] = $img;
		if ( ! empty( $active['roles'][ $p->get_id() ]['photo'] ) ) {
			$marked[] = $img;
		}
	}
	$ids = $marked ? $marked : $all;
	$memo[ $mk ] = array_slice( $ids, 0, 2 );
	return $memo[ $mk ];
}

