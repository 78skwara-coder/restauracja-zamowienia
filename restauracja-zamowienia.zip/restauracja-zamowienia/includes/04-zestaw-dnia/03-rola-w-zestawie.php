<?php
/**
 * Moduł 04-zestaw-dnia – rola produktu w zestawie (etykieta, kolejność).
 * Część modułu (pliki wczytywane po kolei – kolejność jak w dawnym jednym pliku).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * ROLA PRODUKTU W ZESTAWIE: etykieta + kolejność
 *
 * Etykieta ("Pierwsze danie", "Drugie danie"…) wybierana z listy zarządzanej
 * w Panelu restauracji → Menu → Etykiety (od 2.45.0); kolejność to liczba. Obie należą do
 * PRODUKTU (Schabowy jest zawsze "drugim daniem"), nie do konkretnego zestawu.
 * Kolejność steruje kolejnością zdjęć, nazw w sklejonej nazwie zestawu,
 * krótkiego opisu i listy składników; bez kolejności produkt ląduje na końcu.
 * ============================================================ */
add_action( 'init', function () {
	register_taxonomy( 'rzd_set_label', 'product', array(
		'labels'            => array(
			'name'          => 'Etykiety na zestawie',
			'singular_name' => 'Etykieta na zestawie',
			'menu_name'     => 'Etykiety na zestawie',
			'add_new_item'  => 'Dodaj etykietę',
			'edit_item'     => 'Edytuj etykietę',
			'search_items'  => 'Szukaj etykiet',
			'all_items'     => 'Wszystkie etykiety',
		),
		'public'            => false,
		'show_ui'           => true,
		'show_in_menu'      => false, // w menu Restauracja (moduł 00-menu)
		'show_in_nav_menus' => false,
		'show_admin_column' => false,
		'hierarchical'      => false,
		'rewrite'           => false,
		'meta_box_cb'       => false, // własne pole w ramce "Rola w zestawie" (dokładnie jedna etykieta)
	) );
} );

function rzd_zestaw_get_set_role( $product_id ) {
	static $cache = array();
	$product_id = (int) $product_id;
	if ( isset( $cache[ $product_id ] ) ) {
		return $cache[ $product_id ];
	}
	$names = wp_get_object_terms( $product_id, 'rzd_set_label', array( 'fields' => 'names' ) );
	$raw   = get_post_meta( $product_id, '_rwz_set_order', true );
	return $cache[ $product_id ] = array(
		'label' => ( ! is_wp_error( $names ) && $names ) ? $names[0] : '',
		'order' => ( '' === $raw || false === $raw ) ? null : (int) $raw,
	);
}

// Rola składnika WZGLĘDEM tego zestawu (dla zagnieżdżonego – rola pozycji wpiętej w zestaw).
function rzd_zestaw_get_component_role( $set_id, $component_id ) {
	$active = rzd_zestaw_get_active_components( $set_id );
	return isset( $active['roles'][ $component_id ] ) ? $active['roles'][ $component_id ] : array( 'label' => '', 'order' => null );
}

add_action( 'add_meta_boxes', function () {
	add_meta_box( 'rwz_set_role', 'Rola w zestawie', 'rzd_zestaw_set_role_box_html', 'product', 'side', 'default' );
} );

function rzd_zestaw_set_role_box_html( $post ) {
	wp_nonce_field( 'rwz_set_role', 'rwz_set_role_nonce' );
	$role   = rzd_zestaw_get_set_role( $post->ID );
	$labels = get_terms( array( 'taxonomy' => 'rzd_set_label', 'hide_empty' => false ) );
	?>
	<p>
		<label for="rwz_set_label"><strong>Etykieta</strong></label><br>
		<select name="rwz_set_label" id="rwz_set_label" style="width:100%;">
			<option value="">— bez etykiety —</option>
			<?php if ( ! is_wp_error( $labels ) ) : foreach ( $labels as $t ) : ?>
				<option value="<?php echo esc_attr( $t->term_id ); ?>" <?php selected( $role['label'], $t->name ); ?>><?php echo esc_html( $t->name ); ?></option>
			<?php endforeach; endif; ?>
		</select>
	</p>
	<p>
		<label for="rwz_set_order"><strong>Kolejność na zestawie</strong></label><br>
		<input type="number" min="0" step="1" name="rwz_set_order" id="rwz_set_order" value="<?php echo null === $role['order'] ? '' : (int) $role['order']; ?>" style="width:100%;" placeholder="np. 1">
	</p>
	<p class="description">Dotyczy tego produktu, gdy jest daniem w zestawie: najmniejsza liczba idzie pierwsza (zdjęcia, sklejona nazwa). Bez liczby – na końcu. Nowe etykiety dodasz w Panelu restauracji → Menu → Etykiety.</p>
	<?php
}

add_action( 'save_post_product', function ( $post_id ) {
	if ( ! isset( $_POST['rwz_set_role_nonce'] ) || ! wp_verify_nonce( $_POST['rwz_set_role_nonce'], 'rwz_set_role' ) ) {
		return;
	}
	if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	rzd_zestaw_set_role_save( $post_id, isset( $_POST['rwz_set_label'] ) ? absint( $_POST['rwz_set_label'] ) : 0, isset( $_POST['rwz_set_order'] ) ? wp_unslash( $_POST['rwz_set_order'] ) : '' ); // phpcs:ignore
} );

/** Rola produktu w zestawie: etykieta (term_id albo 0) i kolejność ('' = bez). Też Panel restauracji → Menu → Etykiety. */
function rzd_zestaw_set_role_save( $post_id, $term_id, $order ) {
	$term_id = absint( $term_id );
	if ( $term_id && ! term_exists( $term_id, 'rzd_set_label' ) ) {
		$term_id = 0;
	}
	wp_set_object_terms( $post_id, $term_id ? array( $term_id ) : array(), 'rzd_set_label', false );
	$order = trim( (string) $order );
	if ( '' === $order || ! is_numeric( $order ) ) {
		delete_post_meta( $post_id, '_rwz_set_order' );
	} else {
		update_post_meta( $post_id, '_rwz_set_order', max( 0, (int) $order ) );
	}
}

function rzd_zestaw_get_active_components( $product_id, $date = null, $depth = 0 ) {
	if ( null === $date ) {
		if ( function_exists( 'rzd_dc_selected_date' ) && rzd_dc_selected_date() ) {
			$date = rzd_dc_selected_date(); // klient już wybrał termin – liczy się jego data dostawy
		} else {
			$date = rzd_zestaw_default_delivery_date( $product_id ); // brak wyboru – najbliższa możliwa data
		}
	}

	// WYDAJNOŚĆ: ten sam zestaw dla tej samej daty jest odpytywany wielokrotnie
	// na jednym wczytaniu strony (raz dla linków do dań, raz dla dodatków, raz
	// dla alergenów) – zapamiętujemy wynik zamiast liczyć go za każdym razem.
	static $memo = array();
	$memo_key = $product_id . '|' . ( $date ? $date : 'teraz' );
	if ( 0 === $depth && isset( $memo[ $memo_key ] ) ) {
		return $memo[ $memo_key ];
	}

	// 'via' = [ id dania => [ id zestawu pośredniego, … ] ] – przez jakie zagnieżdżone
	// zestawy danie trafiło do tego zestawu (od zewnętrznego do najgłębszego).
	// Skład ich nie pokazuje (zasada najgłębszego zagnieżdżenia), ale modyfikacje
	// tak: np. opakowanie ustawione na "Zupie dnia" (moduł 10).
	$result = array( 'main' => array(), 'addon' => array(), 'roles' => array(), 'via' => array() );
	if ( $depth > 5 ) {
		return $result; // ochrona przed pętlą zestaw → zestaw → …
	}

	// bez daty („teraz”) też przez indeks dnia – działa wtedy „zastępuje” z dzisiejszą datą.
	$cands = rzd_zestaw_slots_for_date( $product_id, $date ? $date : current_time( 'Y-m-d' ) );
	foreach ( $cands as $slot ) {
		$match = $date ? rzd_zestaw_slot_matches_date( $slot, $date ) : rzd_zestaw_slot_matches_now( $slot );
		if ( ! $match ) {
			continue;
		}
		$items = ( isset( $slot['items'] ) && is_array( $slot['items'] ) ) ? $slot['items'] : array();
		foreach ( $items as $row ) {
			if ( empty( $row['product_id'] ) ) {
				continue;
			}
			$p = wc_get_product( $row['product_id'] );
			if ( ! $p ) {
				continue;
			}
			$bucket = ( isset( $row['type'] ) && 'addon' === $row['type'] ) ? 'addon' : 'main';
			// Rola liczy się dla pozycji wpiętej BEZPOŚREDNIO w ten zestaw – także wtedy, gdy
			// pod nią rozwija się zagnieżdżony zestaw (Zupa dnia → Grochówka dziedziczy rolę Zupy dnia).
			$role   = rzd_zestaw_get_set_role( $p->get_id() );
			$role['photo'] = ! empty( $row['photo'] ); // to danie jest "zdjęciem zestawu" na liście

			// Zagnieżdżony zestaw → schodzimy głębiej. Dania z niego trafiają tam, gdzie
			// był sam zestaw (danie główne / dodatek), jego dodatki zostają dodatkami.
			if ( (int) $p->get_id() !== (int) $product_id && rzd_zestaw_get_slots( $p->get_id() ) ) {
				$inner = rzd_zestaw_get_active_components( $p->get_id(), $date, $depth + 1 );
				if ( $inner['main'] ) {
					// Zasada najgłębszego zagnieżdżenia: zagnieżdżony zestaw MA coś
					// zaplanowane na dziś (choćby przez kolejny poziom zagnieżdżenia)
					// – bierzemy to, a nie sam zestaw pośredni.
					foreach ( $inner['main'] as $ip ) {
						$result[ $bucket ][ $ip->get_id() ] = $ip;
						$result['roles'][ $ip->get_id() ]   = $role;
						$deeper = isset( $inner['via'][ $ip->get_id() ] ) ? $inner['via'][ $ip->get_id() ] : array();
						$result['via'][ $ip->get_id() ] = array_merge( array( (int) $p->get_id() ), $deeper );
					}
				} else {
					// Zagnieżdżony zestaw nie ma DZIŚ żadnego dopasowanego terminu –
					// zamiast pustki (i przez to zniknięcia tej pozycji ze składu),
					// pokazujemy nazwę samego zestawu pośredniego (np. "Zupa dnia").
					$result[ $bucket ][ $p->get_id() ] = $p;
					$result['roles'][ $p->get_id() ]   = $role;
				}
				foreach ( $inner['addon'] as $ip ) {
					$result['addon'][ $ip->get_id() ] = $ip;
				}
				continue;
			}

			// klucz = ID, żeby ten sam produkt z nakładających się terminów nie dublował się
			$result[ $bucket ][ $p->get_id() ] = $p;
			$result['roles'][ $p->get_id() ]   = $role;
		}
	}

	// Dania główne wg "kolejności na zestawie": najmniejsza liczba pierwsza,
	// bez liczby – na końcu; przy remisie zostaje dotychczasowa kolejność.
	$mains = array_values( $result['main'] );
	$pos   = array();
	foreach ( $mains as $i => $m ) {
		$pos[ $m->get_id() ] = $i;
	}
	usort( $mains, function ( $a, $b ) use ( $result, $pos ) {
		$oa = isset( $result['roles'][ $a->get_id() ] ) ? $result['roles'][ $a->get_id() ]['order'] : null;
		$ob = isset( $result['roles'][ $b->get_id() ] ) ? $result['roles'][ $b->get_id() ]['order'] : null;
		if ( $oa === $ob ) {
			return $pos[ $a->get_id() ] - $pos[ $b->get_id() ];
		}
		if ( null === $oa ) {
			return 1;
		}
		if ( null === $ob ) {
			return -1;
		}
		return $oa - $ob;
	} );
	$result['main']  = $mains;
	$result['addon'] = array_values( $result['addon'] );

	if ( 0 === $depth ) {
		$memo[ $memo_key ] = $result;
	}
	return $result;
}

// 4b) Nad tytułem: pasek terminu dostawy – klient może zmienić datę, żeby
//     podejrzeć, jaki będzie skład zestawu tego dnia (ta sama mechanika co na liście)
add_action( 'woocommerce_single_product_summary', function () {
	$product = rzd_current_product(); // obiekt produktu albo null (globalne $product bywa napisem – szablony blokowe)
	if ( $product && function_exists( 'rzd_zestaw_get_slots' ) && rzd_zestaw_get_slots( $product->get_id() ) && function_exists( 'rzd_dc_render_bar' ) ) {
		echo rzd_dc_render_bar();
	}
}, 4 );

