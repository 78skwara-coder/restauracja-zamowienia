<?php
/**
 * Moduł 04-zestaw-dnia – kategorie: „Nie wyświetlaj w sklepie”.
 * Część modułu (pliki wczytywane po kolei – kolejność jak w dawnym jednym pliku).
 */

/* ============================================================
 * KATEGORIE: widoczność w sklepie ("Nie wyświetlaj w sklepie")
 * ============================================================
 * Kategoria z tą flagą: produkty w niej NIE pokazują się na liście/w
 * wyszukiwarce sklepu i NIE da się ich kupić samodzielnie z listy –
 * ale ich strona produktu jest dostępna pod bezpośrednim linkiem,
 * a same produkty widać normalnie w koszyku, zamówieniu i w zestawach
 * (tam dodawanie do koszyka odbywa się "obok" tej blokady, przez moduł
 * 4/5, więc jej to nie dotyczy).
 * Użyj tej flagi np. dla produktów z puli dodatków.
 */
add_action( 'product_cat_add_form_fields', function () {
	echo '<div class="form-field"><label><input type="checkbox" name="rwz_hide_in_shop" value="1"> Nie wyświetlaj w sklepie</label>'
		. '<p class="description">Produkty z tej kategorii znikają z listy/wyszukiwarki sklepu (strona produktu nadal działa).</p></div>';
} );
add_action( 'product_cat_edit_form_fields', function ( $term ) {
	$checked = get_term_meta( $term->term_id, 'rwz_hide_in_shop', true );
	echo '<tr class="form-field"><th scope="row"><label>Widoczność</label></th><td>'
		. '<label><input type="checkbox" name="rwz_hide_in_shop" value="1" ' . checked( $checked, '1', false ) . '> Nie wyświetlaj w sklepie</label>'
		. '<p class="description">Produkty z tej kategorii znikają z listy/wyszukiwarki sklepu (strona produktu nadal działa).</p></td></tr>';
} );
add_action( 'created_product_cat', 'rwz_save_hide_in_shop' );
add_action( 'edited_product_cat', 'rwz_save_hide_in_shop' );
function rwz_save_hide_in_shop( $term_id ) {
	if ( isset( $_POST['rwz_hide_in_shop'] ) ) {
		update_term_meta( $term_id, 'rwz_hide_in_shop', '1' );
	} else {
		delete_term_meta( $term_id, 'rwz_hide_in_shop' );
	}
}

function rwz_product_in_hidden_category( $product_id ) {
	static $cache = array();
	if ( isset( $cache[ $product_id ] ) ) {
		return $cache[ $product_id ];
	}
	$hidden = false;
	foreach ( (array) wc_get_product_term_ids( $product_id, 'product_cat' ) as $tid ) {
		if ( get_term_meta( $tid, 'rwz_hide_in_shop', true ) ) {
			$hidden = true;
			break;
		}
	}
	$cache[ $product_id ] = $hidden;
	return $hidden;
}

add_filter( 'woocommerce_product_is_visible', function ( $visible, $product_id ) {
	return rwz_product_in_hidden_category( $product_id ) ? false : $visible;
}, 10, 2 );
