<?php
/**
 * MODUŁ 04: Zestaw dnia – wersja z TERMINAMI
 *
 * Jeden stały produkt (ten sam link/SKU), którego tytuł, zdjęcie i opis
 * podmieniają się wg harmonogramu, plus opcjonalne "dodatki" (np. zupa).
 *
 * CO SIĘ ZMIENIŁO wobec poprzedniej wersji:
 * - "+ Dodaj pozycję" dodaje teraz TERMIN: dni tygodnia i/lub konkretną datę
 *   oraz zakres godzin (od–do).
 * - W każdym terminie własnym plusem "+ Dodaj produkt" dodajesz kolejne
 *   produkty; każdy jest "daniem głównym" albo "dodatkiem opcjonalnym".
 * - Reszta mechaniki bez zmian (podmiana tytułu/zdjęcia/opisu, dodatki
 *   z osobnym przyciskiem, lista składników w koszyku i zamówieniu,
 *   ukrywanie składników w katalogu, blokada zakupu dań głównych,
 *   znikanie pustego zestawu).
 * - Stare dane (pojedyncze pozycje z poprzedniej wersji) są odczytywane
 *   automatycznie jako terminy i zapiszą się w nowym formacie przy pierwszym
 *   zapisie produktu.
 *
 * Godziny: puste "od" i "do" = cały dzień; samo "od" = od tej godziny do
 * końca dnia; samo "do" = od początku dnia do tej godziny. Zakres dotyczy
 * jednego dnia (nie przechodzi przez północ).
 *
 * Prefiks funkcji rwz_ – nie koliduje z innymi modułami.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// 0) Załaduj select2 do wyszukiwania produktów na ekranie edycji produktu
add_action( 'admin_enqueue_scripts', 'rzd_zestaw_enqueue_admin_assets' );
function rzd_zestaw_enqueue_admin_assets( $hook ) {
	global $post_type;
	if ( 'product' === $post_type && in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
		wp_enqueue_script( 'wc-enhanced-select' );
		wp_enqueue_style( 'woocommerce_admin_styles' );
		add_action( 'admin_print_styles', 'rzd_admin_tabs_layout_fix' );
	}
}

/**
 * NAPRAWA UKŁADU trzech naszych zakładek w edycji produktu: "Zestaw dnia",
 * i "Możliwe modyfikacje" (moduł 10 – tam też teraz mieszkają dodatki,
 * patrz typ modyfikacji "radio" z ikonką).
 *
 * Przyczyna problemu z poprzedniej wiadomości ("rozjeżdżający się" formularz,
 * pola nachodzące na siebie): pola i etykiety mają sztywną szerokość podaną
 * w pikselach (np. width:300px), ale BEZ box-sizing:border-box. Domyślnie
 * przeglądarka dolicza do tej szerokości jeszcze obramowanie i wypełnienie,
 * więc realna szerokość pola jest WIĘKSZA, niż zakładaliśmy. W węższym oknie
 * admina (bo po lewej jest jeszcze kolumna zakładek Ogólne/Magazyn/Wysyłka…)
 * sumaryczna szerokość kilku takich pól obok siebie zaczyna przekraczać
 * dostępne miejsce – stąd nachodzenie na siebie.
 *
 * Naprawa: wymuszamy border-box na wszystkich naszych polach we wszystkich
 * trzech zakładkach, ograniczamy im maksymalną szerokość do 100% dostępnego
 * miejsca (żeby się zwężały zamiast wychodzić poza kontener) i porządkujemy
 * odstępy, żeby kolejne pola nie stykały się ze sobą.
 */
function rzd_admin_tabs_layout_fix() {
	echo rzd_css_tag( 'assets/css/admin/rzd-zakladki-produktu.css' ); // phpcs:ignore
}

// 1) Nowa zakładka "Zestaw dnia" w danych produktu
add_filter( 'woocommerce_product_data_tabs', 'rzd_zestaw_add_zestaw_tab' );
function rzd_zestaw_add_zestaw_tab( $tabs ) {
	$tabs['rwz_zestaw'] = array(
		'label'    => __( 'Zestaw', 'woocommerce' ), // do 2.42.0 „Zestaw dnia”
		'target'   => 'rwz_zestaw_data',
		'class'    => array(),
		'priority' => 21,
	);
	return $tabs;
}

// Lista dni używana i w renderze terminów
function rzd_zestaw_days_labels() {
	return array(
		'Mon' => 'Pon',
		'Tue' => 'Wt',
		'Wed' => 'Śr',
		'Thu' => 'Czw',
		'Fri' => 'Pt',
		'Sat' => 'Sob',
		'Sun' => 'Ndz',
	);
}

// Terminy zestawu. Jeśli produkt ma jeszcze STARE dane (_rwz_components
// z poprzedniej wersji), zamieniamy je w locie na terminy.
function rzd_zestaw_get_slots( $product_id ) {
	$slots = get_post_meta( $product_id, '_rwz_slots', true );
	if ( is_array( $slots ) ) {
		return $slots;
	}

	$slots  = array();
	$legacy = get_post_meta( $product_id, '_rwz_components', true );
	if ( is_array( $legacy ) ) {
		foreach ( $legacy as $row ) {
			if ( empty( $row['product_id'] ) ) {
				continue;
			}
			$slots[] = array(
				'days'  => ( isset( $row['days'] ) && is_array( $row['days'] ) ) ? $row['days'] : array(),
				'date'  => isset( $row['date'] ) ? $row['date'] : '',
				'from'  => '',
				'to'    => '',
				'items' => array(
					array(
						'product_id' => absint( $row['product_id'] ),
						'type'       => ( isset( $row['type'] ) && 'addon' === $row['type'] ) ? 'addon' : 'main',
					),
				),
			);
		}
	}
	return $slots;
}

// Funkcja pomocnicza: czy dzień/data pasuje do DZISIAJ
function rzd_zestaw_matches_today( $days, $date ) {
	$current_day  = current_time( 'D' );
	$current_date = current_time( 'Y-m-d' );

	if ( ! empty( $date ) ) {
		return $current_date === $date;
	}
	if ( empty( $days ) ) {
		return true;
	}
	return in_array( $current_day, (array) $days, true );
}

// Zakres dat terminu: "Od dnia" / "Do dnia", oba włącznie, każde
// może być puste (= bez ograniczenia z tej strony). Działa RAZEM z dniami
// tygodnia; "konkretna data" jest nadrzędna i wtedy zakres się pomija.
function rzd_zestaw_in_date_range( $slot, $date ) {
	$df = isset( $slot['date_from'] ) ? (string) $slot['date_from'] : '';
	$dt = isset( $slot['date_to'] ) ? (string) $slot['date_to'] : '';
	if ( '' !== $df && $date < $df ) {
		return false;
	}
	if ( '' !== $dt && $date > $dt ) {
		return false;
	}
	return true;
}

// Funkcja pomocnicza: czy termin jest aktywny TERAZ (dzień/data + zakres + godziny)
function rzd_zestaw_slot_matches_now( $slot ) {
	$days = ( isset( $slot['days'] ) && is_array( $slot['days'] ) ) ? $slot['days'] : array();
	$date = isset( $slot['date'] ) ? $slot['date'] : '';
	$from = isset( $slot['from'] ) ? $slot['from'] : '';
	$to   = isset( $slot['to'] ) ? $slot['to'] : '';

	if ( ! rzd_zestaw_matches_today( $days, $date ) ) {
		return false;
	}
	if ( '' === $date && ! rzd_zestaw_in_date_range( $slot, current_time( 'Y-m-d' ) ) ) {
		return false;
	}

	$now = current_time( 'H:i' );
	if ( $from && $now < $from ) {
		return false;
	}
	if ( $to && $now > $to ) {
		return false;
	}
	return true;
}

// Renderuje jeden wiersz produktu wewnątrz terminu
// (dla szablonu JS: $slot_index = '__SLOT__', $item_index = '__ITEM__', $item = array())
function rzd_zestaw_render_item_row( $slot_index, $item_index, $item ) {
	$product_id = isset( $item['product_id'] ) ? absint( $item['product_id'] ) : 0;
	$type       = ( isset( $item['type'] ) && 'addon' === $item['type'] ) ? 'addon' : 'main';
	$name       = 'rwz_slot[' . $slot_index . '][items][' . $item_index . ']';

	ob_start();
	?>
	<div class="rwz-item" style="border:1px solid #ddd; margin:8px 0; padding:10px 34px 10px 10px; background:#fff; position:relative;">
		<a href="#" class="rwz-remove-item" style="position:absolute; top:6px; right:10px; color:#d63638; text-decoration:none; font-size:18px; font-weight:bold;" title="<?php esc_attr_e( 'Usuń produkt', 'woocommerce' ); ?>">&times;</a>

		<select name="<?php echo esc_attr( $name ); ?>[product_id]" class="wc-product-search" style="width:300px;" data-action="woocommerce_json_search_products_and_variations" data-placeholder="<?php esc_attr_e( 'Wybierz produkt…', 'woocommerce' ); ?>">
			<?php
			if ( $product_id ) {
				$p = wc_get_product( $product_id );
				if ( $p ) {
					echo '<option value="' . esc_attr( $product_id ) . '" selected="selected">' . esc_html( $p->get_formatted_name() ) . '</option>';
				}
			}
			?>
		</select>
		&nbsp;
		<select name="<?php echo esc_attr( $name ); ?>[type]">
			<option value="main" <?php selected( $type, 'main' ); ?>><?php esc_html_e( 'Danie główne (podmienia tytuł / zdjęcie / opis)', 'woocommerce' ); ?></option>
			<option value="addon" <?php selected( $type, 'addon' ); ?>><?php esc_html_e( 'Dodatek opcjonalny (osobny przycisk „Dodaj do koszyka”)', 'woocommerce' ); ?></option>
		</select>
		&nbsp;
		<label style="white-space:nowrap;" title="Zdjęcie tego dania będzie zdjęciem zestawu na liście (tam jest tylko jedno zdjęcie).">
			<input type="checkbox" name="<?php echo esc_attr( $name ); ?>[photo]" value="1" <?php checked( ! empty( $item['photo'] ) ); ?>> Zdjęcie
		</label>
	</div>
	<?php
	return ob_get_clean();
}

// Renderuje jeden TERMIN (dla szablonu JS: $index = '__SLOT__', $slot = array())
function rzd_zestaw_render_slot( $index, $slot ) {
	$days_labels = rzd_zestaw_days_labels();

	$row_days = ( isset( $slot['days'] ) && is_array( $slot['days'] ) ) ? $slot['days'] : array();
	$row_date = isset( $slot['date'] ) ? $slot['date'] : '';
	$row_df   = isset( $slot['date_from'] ) ? $slot['date_from'] : '';
	$row_dt   = isset( $slot['date_to'] ) ? $slot['date_to'] : '';
	$row_from = isset( $slot['from'] ) ? $slot['from'] : '';
	$row_to   = isset( $slot['to'] ) ? $slot['to'] : '';
	$items    = ( isset( $slot['items'] ) && is_array( $slot['items'] ) ) ? array_values( $slot['items'] ) : array();
	$name     = 'rwz_slot[' . $index . ']';

	ob_start();
	?>
	<div class="rwz-slot" data-slot="<?php echo esc_attr( $index ); ?>" data-next-item="<?php echo (int) count( $items ); ?>" style="border:2px solid #b5bfc9; margin:14px 12px; padding:12px; background:#f6f7f7; position:relative;">
		<a href="#" class="rwz-remove-slot" style="position:absolute; top:8px; right:10px; color:#d63638; text-decoration:none; font-size:20px; font-weight:bold;" title="<?php esc_attr_e( 'Usuń cały termin', 'woocommerce' ); ?>">&times;</a>

		<strong><?php esc_html_e( 'Termin', 'woocommerce' ); ?></strong><br><br>

		<label><?php esc_html_e( 'Dni tygodnia:', 'woocommerce' ); ?></label><br>
		<?php foreach ( $days_labels as $key => $label ) : ?>
			<label style="margin-right:10px;"><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[days][]" value="<?php echo esc_attr( $key ); ?>" <?php checked( in_array( $key, $row_days, true ) ); ?> /> <?php echo esc_html( $label ); ?></label>
		<?php endforeach; ?>
		<br><small style="color:#777;"><?php esc_html_e( 'Brak zaznaczonych dni = codziennie (chyba że ustawisz konkretną datę).', 'woocommerce' ); ?></small><br><br>

		<label><?php esc_html_e( 'Zakres dat: od', 'woocommerce' ); ?></label>
		<input type="date" name="<?php echo esc_attr( $name ); ?>[date_from]" value="<?php echo esc_attr( $row_df ); ?>" />
		<label><?php esc_html_e( 'do', 'woocommerce' ); ?></label>
		<input type="date" name="<?php echo esc_attr( $name ); ?>[date_to]" value="<?php echo esc_attr( $row_dt ); ?>" /><br>
		<small style="color:#777;"><?php esc_html_e( 'Oba dni włącznie. Działa razem z dniami tygodnia (np. piątki od 1.10 do 31.10). Puste = bez ograniczenia.', 'woocommerce' ); ?></small><br><br>

		<label><?php esc_html_e( 'Lub konkretna data (nadrzędna wobec dni powyżej):', 'woocommerce' ); ?></label><br>
		<input type="date" name="<?php echo esc_attr( $name ); ?>[date]" value="<?php echo esc_attr( $row_date ); ?>" /><br>
		<label><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[override]" value="1" <?php checked( ! empty( $slot['override'] ) ); ?> /> <?php esc_html_e( 'Zastępuje inne terminy w tym dniu (np. ustawione z telefonu)', 'woocommerce' ); ?></label><br>
		<small style="color:#777;"><?php esc_html_e( 'Tylko z konkretną datą. Bez zaznaczenia dania z tej daty DOKŁADAJĄ SIĘ do dań z dni tygodnia.', 'woocommerce' ); ?></small><br><br>

		<label><?php esc_html_e( 'Godziny: od', 'woocommerce' ); ?></label>
		<input type="time" name="<?php echo esc_attr( $name ); ?>[from]" value="<?php echo esc_attr( $row_from ); ?>" />
		<label><?php esc_html_e( 'do', 'woocommerce' ); ?></label>
		<input type="time" name="<?php echo esc_attr( $name ); ?>[to]" value="<?php echo esc_attr( $row_to ); ?>" /><br>
		<small style="color:#777;"><?php esc_html_e( 'Puste = cały dzień. Zakres dotyczy jednego dnia (np. 11:00–15:00).', 'woocommerce' ); ?></small>

		<div class="rwz-items" style="margin-top:12px;">
			<?php
			foreach ( $items as $j => $item ) {
				echo rzd_zestaw_render_item_row( $index, $j, $item );
			}
			?>
		</div>
		<p style="margin:8px 0 0;"><button type="button" class="button rwz-add-item">+ <?php esc_html_e( 'Dodaj produkt', 'woocommerce' ); ?></button></p>

		<?php if ( ! empty( $items ) ) : ?>
			<?php $is_active = rzd_zestaw_slot_matches_now( $slot ); ?>
			<p style="margin-top:10px; padding:6px 10px; background:#f0f6fc; border-left:3px solid #72aee6;"><em>
				<?php
				echo esc_html( sprintf( __( 'Aktywny teraz (%s)? ', 'woocommerce' ), wp_date( 'l Y-m-d H:i' ) ) );
				echo $is_active
					? '<strong style="color:#008a20;">' . esc_html__( 'TAK', 'woocommerce' ) . '</strong>'
					: '<strong style="color:#d63638;">' . esc_html__( 'NIE', 'woocommerce' ) . '</strong>';
				?>
			</em></p>
		<?php endif; ?>
	</div>
	<?php
	return ob_get_clean();
}

// 2) Renderuj zawartość zakładki: istniejące terminy + przycisk "+ Dodaj pozycję"
add_action( 'woocommerce_product_data_panels', 'rzd_zestaw_render_zestaw_panel' );
function rzd_zestaw_render_zestaw_panel() {
	global $post;

	$slots = array_values( rzd_zestaw_get_slots( $post->ID ) );

	// WooCommerce w panelach produktu przesuwa każdy <label> 150 px w lewo (float + ujemny
	// margines, pod kolumnę etykiet p.form-field). Nasze terminy nie używają p.form-field,
	// więc etykiety – a z nimi checkboxy dni tygodnia – lądowały poza ekranem. Reset tylko tu.
	echo '<style>#woocommerce-product-data #rwz_zestaw_data .rwz-slot label{float:none;width:auto;margin-left:0;padding:0;display:inline;}</style>';
	echo '<div id="rwz_zestaw_data" class="panel woocommerce_options_panel">';
	echo '<p style="padding:0 12px; color:#555;">' . esc_html__( 'Dodaj pozycję = termin (dni/data + godziny). W terminie dodajesz produkty: "Danie główne" podmienia tytuł, zdjęcie i opis TEGO produktu w czasie trwania terminu, "Dodatek opcjonalny" pokazuje się jako osobna pozycja z przyciskiem zakupu. Podpięte produkty automatycznie znikają z katalogu/wyszukiwarki sklepu. Najnowsze terminy są na górze.', 'woocommerce' ) . '</p>';
	echo '<p style="padding:0 12px;"><button type="button" class="button button-primary" id="rwz-add-slot">+ ' . esc_html__( 'Dodaj pozycję', 'woocommerce' ) . '</button></p>';

	// kolejka – najnowszy termin na górze. Indeksy pól zostają te same,
	// a zapis (rzd_zestaw_save_zestaw_fields) odwraca kolejność z powrotem, więc w bazie
	// nadal najstarszy jest pierwszy i rzd_zestaw_get_active_components() działa jak dawniej.
	echo '<div id="rwz-slots">';
	foreach ( array_reverse( $slots, true ) as $i => $slot ) {
		echo rzd_zestaw_render_slot( $i, $slot );
	}
	echo '</div>';

	// Szablony (przeglądarka ich nie renderuje — type="text/html")
	echo '<script type="text/html" id="rwz-slot-template">';
	echo rzd_zestaw_render_slot( '__SLOT__', array() );
	echo '</script>';
	echo '<script type="text/html" id="rwz-item-template">';
	echo rzd_zestaw_render_item_row( '__SLOT__', '__ITEM__', array() );
	echo '</script>';

	$next_slot = count( $slots );
	?>
	<script>var rzdZestawNext = <?php echo (int) $next_slot; ?>;</script>
	<?php echo rzd_js_tag( 'assets/js/admin/rzd-zestaw-produkt.js' ); // phpcs:ignore ?>
	<?php

	echo '</div>';
}

