<?php
/**
 * Moduł 04-zestaw-dnia – zapis konfiguracji i przeliczenie składowych.
 * Część modułu (pliki wczytywane po kolei – kolejność jak w dawnym jednym pliku).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// 3) Zapisz konfigurację (indeksy przepisywane sekwencyjnie od 0)
add_action( 'woocommerce_process_product_meta', 'rzd_zestaw_save_zestaw_fields', 10 );
function rzd_zestaw_save_zestaw_fields( $post_id ) {
	// formularz pokazuje najnowszy termin na górze – zapis odwraca (w bazie najstarszy pierwszy)
	rzd_zestaw_save_slots( $post_id, ( isset( $_POST['rwz_slot'] ) && is_array( $_POST['rwz_slot'] ) ) ? wp_unslash( $_POST['rwz_slot'] ) : array(), true ); // phpcs:ignore
}

/**
 * Zapis terminów zestawu (_rwz_slots). $raw – terminy jak w formularzu; $reverse – czy podane są
 * od najnowszego (formularz karty produktu i dawna strona Zestawy) – w bazie najstarszy pierwszy,
 * od tej kolejności zależy składanie dań. Panel restauracji podaje kolejność z bazy ($reverse = false).
 * Zwraca liczbę zapisanych terminów.
 */
function rzd_zestaw_save_slots( $post_id, $raw, $reverse = false ) {
	// Stare dane z poprzedniej wersji zawsze kasujemy — od teraz żyje tylko _rwz_slots
	delete_post_meta( $post_id, '_rwz_components' );
	$clean = rzd_zestaw_clean_slots( $raw );
	if ( $reverse ) {
		$clean = array_reverse( $clean );
	}
	if ( empty( $clean ) ) {
		delete_post_meta( $post_id, '_rwz_slots' );
	} else {
		update_post_meta( $post_id, '_rwz_slots', $clean );
	}
	return count( $clean );
}

/** Czyszczenie terminów zestawu (kolejność bez zmian). */
function rzd_zestaw_clean_slots( $raw ) {
	$valid_days = array_keys( rzd_zestaw_days_labels() );
	$clean      = array();

	foreach ( (array) $raw as $slot ) {
		if ( ! is_array( $slot ) ) {
			continue;
		}

		$items = array();
		if ( isset( $slot['items'] ) && is_array( $slot['items'] ) ) {
			foreach ( $slot['items'] as $item ) {
				$product_id = isset( $item['product_id'] ) ? absint( $item['product_id'] ) : 0;
				if ( ! $product_id ) {
					continue; // pomiń puste/usunięte produkty
				}
				$row_item = array(
					'product_id' => $product_id,
					'type'       => ( isset( $item['type'] ) && 'addon' === $item['type'] ) ? 'addon' : 'main',
				);
				if ( ! empty( $item['photo'] ) ) {
					$row_item['photo'] = 1; // "to zdjęcie pokaż na liście" (na liście jest tylko jedno zdjęcie)
				}
				$items[] = $row_item;
			}
		}

		$days = isset( $slot['days'] )
			? array_values( array_intersect( array_map( 'sanitize_text_field', (array) $slot['days'] ), $valid_days ) )
			: array();

		$date = isset( $slot['date'] ) ? sanitize_text_field( $slot['date'] ) : '';
		if ( $date && ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
			$date = '';
		}

		$from = isset( $slot['from'] ) ? rzd_clean_time( $slot['from'] ) : '';
		$to   = isset( $slot['to'] ) ? rzd_clean_time( $slot['to'] ) : '';

		$date_from = isset( $slot['date_from'] ) ? sanitize_text_field( $slot['date_from'] ) : '';
		$date_to   = isset( $slot['date_to'] ) ? sanitize_text_field( $slot['date_to'] ) : '';
		if ( $date_from && ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date_from ) ) {
			$date_from = '';
		}
		if ( $date_to && ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date_to ) ) {
			$date_to = '';
		}
		if ( $date_from && $date_to && $date_to < $date_from ) { // odwrotnie wpisane – zamieniamy
			list( $date_from, $date_to ) = array( $date_to, $date_from );
		}

		// Całkiem pusty termin (bez produktów, dni, dat i godzin) pomijamy
		if ( empty( $items ) && empty( $days ) && '' === $date && '' === $date_from && '' === $date_to && '' === $from && '' === $to ) {
			continue;
		}

		$row_clean = array(
			'days'      => $days,
			'date'      => $date,
			'date_from' => $date_from,
			'date_to'   => $date_to,
			'from'  => $from,
			'to'    => $to,
			'items' => $items,
		);
		// termin z konkretną datą może ZASTĘPOWAĆ inne terminy tego dnia (rzd_zestaw_slots_for_date).
		if ( $date && ! empty( $slot['override'] ) ) {
			$row_clean['override'] = 1;
		}
		$clean[] = $row_clean;
	}
	return $clean;
}

// 4) Po zapisaniu — przelicz globalnie, które produkty są "składowymi"
//    (żeby móc je ukryć/zablokować), na podstawie WSZYSTKICH "zestawów"
add_action( 'woocommerce_process_product_meta', 'rzd_zestaw_rebuild_component_flags', 20 );

// Zmiana składu/terminów zestawu wpływa na to, co pokazuje bufor terminów
// dostawy (moduł 06) – wyczyść go, żeby zmiana była widoczna od razu.
add_action( 'woocommerce_process_product_meta', function () {
	if ( function_exists( 'rzd_dc_clear_slots_cache' ) ) {
		rzd_dc_clear_slots_cache();
	}
}, 21 );
function rzd_zestaw_rebuild_component_flags( $post_id ) {
	global $wpdb;

	$all_used   = array();
	$addon_used = array();
	$main_used  = array();

	$zestaw_posts = $wpdb->get_col(
		"SELECT DISTINCT post_id FROM {$wpdb->postmeta} WHERE meta_key IN ('_rwz_slots', '_rwz_components')"
	);

	foreach ( $zestaw_posts as $zestaw_id ) {
		foreach ( rzd_zestaw_get_slots( $zestaw_id ) as $slot ) {
			if ( empty( $slot['items'] ) || ! is_array( $slot['items'] ) ) {
				continue;
			}
			foreach ( $slot['items'] as $row ) {
				if ( empty( $row['product_id'] ) ) {
					continue;
				}
				$pid        = absint( $row['product_id'] );
				$all_used[] = $pid;
				if ( isset( $row['type'] ) && 'addon' === $row['type'] ) {
					$addon_used[] = $pid;
				} else {
					$main_used[] = $pid;
				}
			}
		}
	}

	$all_used   = array_unique( $all_used );
	$addon_used = array_unique( $addon_used );
	// "tylko danie główne" = użyty jako główne i NIGDZIE jako dodatek
	$main_only = array_diff( array_unique( $main_used ), $addon_used );

	// Flaga "ukryty z katalogu/wyszukiwarki" — dla WSZYSTKICH składowych
	$previously_hidden = $wpdb->get_col(
		"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_rwz_hidden_as_component' AND meta_value = 'yes'"
	);
	foreach ( array_diff( $previously_hidden, $all_used ) as $pid ) {
		delete_post_meta( $pid, '_rwz_hidden_as_component' );
	}
	foreach ( $all_used as $pid ) {
		update_post_meta( $pid, '_rwz_hidden_as_component', 'yes' );
	}

	// Flaga "zablokuj samodzielny zakup" — TYLKO dla dań głównych,
	// które nigdzie nie są jednocześnie użyte jako dodatek
	$previously_blocked = $wpdb->get_col(
		"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_rwz_hidden_as_component_main' AND meta_value = 'yes'"
	);
	foreach ( array_diff( $previously_blocked, $main_only ) as $pid ) {
		delete_post_meta( $pid, '_rwz_hidden_as_component_main' );
	}
	foreach ( $main_only as $pid ) {
		update_post_meta( $pid, '_rwz_hidden_as_component_main', 'yes' );
	}
}

// Czy termin obejmuje podany dzień (tylko zakres dzienny – godziny pomijane)
function rzd_zestaw_slot_matches_date( $slot, $date ) {
	if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $date ) ) {
		return false;
	}
	$days      = ( isset( $slot['days'] ) && is_array( $slot['days'] ) ) ? $slot['days'] : array();
	$slot_date = isset( $slot['date'] ) ? $slot['date'] : '';

	if ( ! empty( $slot_date ) ) {
		return $slot_date === $date;
	}
	if ( ! rzd_zestaw_in_date_range( $slot, $date ) ) {
		return false;
	}
	if ( empty( $days ) ) {
		return true;
	}
	$dow = ( new DateTime( $date, wp_timezone() ) )->format( 'D' );
	return in_array( $dow, $days, true );
}

/**
 * WYDAJNOŚĆ: terminy z konkretną datą przybywają codziennie i zostają
 * w zestawie na zawsze. Zamiast przy każdym dniu harmonogramu (i każdym zestawie
 * zagnieżdżonym) sprawdzać wszystkie, indeksujemy je raz na żądanie po dacie:
 * do sprawdzenia trafiają tylko terminy z TĄ datą + terminy bez konkretnej daty.
 * Klucze = pozycje w bazie, więc kolejność terminów zostaje bez zmian.
 */
function rzd_zestaw_slots_for_date( $product_id, $date, $reset = false ) {
	static $idx = array();
	if ( $reset ) { // po zapisie terminów w tym samym żądaniu (moduł 22)
		$idx = array();
		return array();
	}
	$product_id = (int) $product_id;
	if ( ! isset( $idx[ $product_id ] ) ) {
		$by  = array();
		$gen = array();
		foreach ( rzd_zestaw_get_slots( $product_id ) as $i => $slot ) {
			$d = isset( $slot['date'] ) ? (string) $slot['date'] : '';
			if ( '' !== $d ) {
				$by[ $d ][ $i ] = $slot;
			} else {
				$gen[ $i ] = $slot;
			}
		}
		$idx[ $product_id ] = array( $by, $gen );
	}
	list( $by, $gen ) = $idx[ $product_id ];
	if ( empty( $by[ $date ] ) ) {
		return $gen;
	}
	// termin z tą datą oznaczony „zastępuje” (np. zapis z telefonu, moduł 22) –
	// liczą się WYŁĄCZNIE terminy z tą datą, reguły dni tygodnia tego dnia nie działają.
	foreach ( $by[ $date ] as $one ) {
		if ( ! empty( $one['override'] ) ) {
			return $by[ $date ];
		}
	}
	$out = $by[ $date ] + $gen;
	ksort( $out );
	return $out;
}

// Funkcja pomocnicza: aktywne "dania główne" i "dodatki".
// $date = null    → data dostawy wybrana przez klienta (moduł 06);
//                   gdy jej nie ma – to, co aktywne TERAZ (dni/data + godziny).
// $date = Y-m-d   → to, co aktywne w tym dniu (tylko zakres dzienny, bez godzin).
// Składnik, który sam jest zestawem (np. "Zupa dnia" w "Zestawie dnia"), jest
// rozwijany: zwracamy to, co aktywne NA KOŃCU zagnieżdżenia (np. konkretną zupę).
// Gdy klient jeszcze nie wybrał terminu dostawy, domyślnie pokazujemy skład
// z NAJBLIŻSZEJ możliwej daty dostawy tego zestawu (a nie z "teraz") – dzięki
// temu w niedzielę widać już np. poniedziałkowe danie, a nie pustkę.
function rzd_zestaw_default_delivery_date( $product_id ) {
	static $cache = array();
	if ( isset( $cache[ $product_id ] ) ) {
		return $cache[ $product_id ];
	}
	$date = null;
	if ( function_exists( 'rzd_dc_enabled' ) && rzd_dc_enabled() && function_exists( 'rzd_dc_slots_for_products' ) ) {
		$slots = rzd_dc_slots_for_products( array( $product_id ) );
		if ( $slots ) {
			$dates = array_keys( $slots );
			$date  = $dates[0]; // rzd_dc_slots_for_products zwraca daty rosnąco
		}
	}
	$cache[ $product_id ] = $date;
	return $date;
}

