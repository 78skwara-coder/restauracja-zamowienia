<?php
/**
 * Moduł 04-zestaw-dnia – zdjęcie dzielone zestawu.
 * Część modułu (pliki wczytywane po kolei – kolejność jak w dawnym jednym pliku).
 */

/* ------------------------------------------------------------------
 * ZDJĘCIE DZIELONE zestawu (dwa dania na jednym zdjęciu).
 * Z dwóch zdjęć składamy JEDEN plik JPG (GD) i trzymamy go w
 * uploads/rzd/split/. Jeden zwykły obrazek działa wszędzie tak samo –
 * motyw (kafle sklepu, mini-koszyk), koszyk blokowy, okienka – bez walki
 * ze stylami motywu. Nazwa pliku = skrót z ID zdjęć, rozmiaru i ustawień
 * z „Wygląd listy” → Zdjęcie produktu, więc zmiana dań albo ustawień
 * daje nowy plik. Brak GD / błąd = zwykłe zdjęcie pierwszego dania.
 * ------------------------------------------------------------------ */

// Ustawienia podziału z panelu „Wygląd listy” (wspólne dla telefonu i komputera).
function rwz_split_settings() {
	$s = function_exists( 'rzd_list_style_get' ) ? rzd_list_style_get() : array();
	$mode  = ( isset( $s['set_split'] ) && 'vert' === $s['set_split'] ) ? 'vert' : 'diag';
	$line  = isset( $s['set_split_line'] ) ? max( 0, min( 20, (float) $s['set_split_line'] ) ) : 0;
	$color = ( isset( $s['set_split_color'] ) && preg_match( '/^#[0-9a-fA-F]{6}$/', $s['set_split_color'] ) ) ? strtolower( $s['set_split_color'] ) : '#ffffff';
	return array( 'mode' => $mode, 'line' => $line, 'color' => $color );
}

// Najmniejszy plik zdjęcia, który pokrywa $w × $h (inaczej oryginał) – mniej pamięci w GD.
function rwz_split_source_path( $att_id, $w, $h ) {
	$full = get_attached_file( $att_id );
	$meta = wp_get_attachment_metadata( $att_id );
	if ( ! $full || ! is_array( $meta ) || empty( $meta['sizes'] ) ) {
		return $full;
	}
	$best = null;
	foreach ( $meta['sizes'] as $sz ) {
		if ( empty( $sz['file'] ) || (int) $sz['width'] < $w || (int) $sz['height'] < $h ) {
			continue;
		}
		if ( ! $best || (int) $sz['width'] * (int) $sz['height'] < (int) $best['width'] * (int) $best['height'] ) {
			$best = $sz;
		}
	}
	if ( $best ) {
		$p = path_join( dirname( $full ), $best['file'] );
		if ( file_exists( $p ) ) {
			return $p;
		}
	}
	return $full;
}

// Zdjęcie przycięte do środka („cover”) do $w × $h, na białym tle (przezroczyste PNG).
function rwz_split_cover( $path, $w, $h ) {
	$data = ( $path && file_exists( $path ) ) ? @file_get_contents( $path ) : false; // phpcs:ignore
	$src  = $data ? @imagecreatefromstring( $data ) : false; // phpcs:ignore
	if ( ! $src ) {
		return false;
	}
	$sw  = imagesx( $src );
	$sh  = imagesy( $src );
	$dst = imagecreatetruecolor( $w, $h );
	imagefill( $dst, 0, 0, imagecolorallocate( $dst, 255, 255, 255 ) );
	$scale = max( $w / $sw, $h / $sh );
	$cw    = (int) round( $w / $scale );
	$ch    = (int) round( $h / $scale );
	$cx    = (int) floor( ( $sw - $cw ) / 2 );
	$cy    = (int) floor( ( $sh - $ch ) / 2 );
	imagecopyresampled( $dst, $src, 0, 0, max( 0, $cx ), max( 0, $cy ), $w, $h, min( $cw, $sw ), min( $ch, $sh ) );
	imagedestroy( $src );
	return $dst;
}

/**
 * Adres złożonego pliku dla zdjęć $a i $b o docelowym rozmiarze $w × $h
 * (rozmiar pokazywania; plik robimy do 2× większy – ostry na ekranach Retina).
 * Zwraca array( url, szerokość pliku, wysokość pliku ) albo false.
 */
function rwz_split_image_file( $a, $b, $w, $h ) {
	$w = (int) $w;
	$h = (int) $h;
	if ( ! $a || ! $b || $w < 8 || $h < 8 || ! function_exists( 'imagecreatetruecolor' ) || ! function_exists( 'imagecreatefromstring' ) ) {
		return false;
	}
	$scale = max( 1, min( 2, 1200 / $w ) );
	$W     = (int) round( $w * $scale );
	$H     = (int) round( $h * $scale );
	$cfg   = rwz_split_settings();
	$pa    = rwz_split_source_path( $a, $cfg['mode'] === 'vert' ? (int) ceil( $W / 2 ) : $W, $H );
	$pb    = rwz_split_source_path( $b, $cfg['mode'] === 'vert' ? (int) ceil( $W / 2 ) : $W, $H );
	if ( ! $pa || ! $pb ) {
		return false;
	}
	$up = wp_upload_dir( null, false );
	if ( ! empty( $up['error'] ) ) {
		return false;
	}
	$key  = substr( md5( implode( '|', array( $a, $b, $pa, $pb, (int) @filemtime( $pa ), (int) @filemtime( $pb ), $W, $H, $cfg['mode'], $cfg['line'], $cfg['color'], 1 ) ) ), 0, 16 ); // phpcs:ignore
	$dir  = trailingslashit( $up['basedir'] ) . 'rzd/split';
	$name = 'zestaw-' . $key . '.jpg';
	$path = $dir . '/' . $name;
	$url  = set_url_scheme( trailingslashit( $up['baseurl'] ) . 'rzd/split/' . $name );
	if ( file_exists( $path ) ) {
		return array( $url, $W, $H );
	}
	if ( ! wp_mkdir_p( $dir ) ) {
		return false;
	}

	if ( 'vert' === $cfg['mode'] ) {
		// Pół na pół: każde danie przycięte do środka swojej połówki – cały talerz widoczny.
		$lw  = (int) floor( $W / 2 );
		$ia  = rwz_split_cover( $pa, $lw, $H );
		$ib  = rwz_split_cover( $pb, $W - $lw, $H );
		if ( ! $ia || ! $ib ) {
			return false;
		}
		$dst = imagecreatetruecolor( $W, $H );
		imagecopy( $dst, $ia, 0, 0, 0, 0, $lw, $H );
		imagecopy( $dst, $ib, $lw, 0, 0, 0, $W - $lw, $H );
	} else {
		// Skos „/” – od prawego górnego do lewego dolnego rogu: pierwsze danie
		// w lewym górnym trójkącie, drugie w prawym dolnym. Wiersz po wierszu,
		// piksel na granicy mieszany (wygładzona krawędź).
		$dst = rwz_split_cover( $pa, $W, $H );
		$ib  = rwz_split_cover( $pb, $W, $H );
		if ( ! $dst || ! $ib ) {
			return false;
		}
		for ( $y = 0; $y < $H; $y++ ) {
			$x0 = $W - ( $y + 0.5 ) * $W / $H; // granica w tym wierszu
			$xi = (int) ceil( $x0 );
			if ( $xi < $W ) {
				imagecopy( $dst, $ib, max( 0, $xi ), $y, max( 0, $xi ), $y, $W - max( 0, $xi ), 1 );
			}
			$xf = $xi - 1;
			if ( $xf >= 0 && $xf < $W ) {
				$pct = (int) round( ( $xi - $x0 ) * 100 ); // część piksela po stronie drugiego dania
				if ( $pct > 0 ) {
					imagecopymerge( $dst, $ib, $xf, $y, $xf, $y, 1, 1, $pct );
				}
			}
		}
	}
	if ( isset( $ia ) && $ia ) {
		imagedestroy( $ia );
	}
	if ( isset( $ib ) && $ib ) {
		imagedestroy( $ib );
	}

	// Kreska podziału (grubość w px pokazywanego zdjęcia → przeliczona na plik).
	if ( $cfg['line'] > 0 ) {
		$t   = max( 1, $cfg['line'] * $scale );
		$rgb = sscanf( $cfg['color'], '#%02x%02x%02x' );
		$col = imagecolorallocate( $dst, $rgb[0], $rgb[1], $rgb[2] );
		if ( 'vert' === $cfg['mode'] ) {
			$mid = $W / 2;
			imagefilledrectangle( $dst, (int) round( $mid - $t / 2 ), 0, (int) round( $mid + $t / 2 ) - 1, $H - 1, $col );
		} else {
			$len = sqrt( $W * $W + $H * $H );
			$nx  = $H / $len * $t / 2; // prostopadła do linii (W,0)→(0,H)
			$ny  = $W / $len * $t / 2;
			$pts = array( $W + $nx, 0 + $ny, $W - $nx, 0 - $ny, 0 - $nx, $H - $ny, 0 + $nx, $H + $ny );
			$pts = array_map( 'intval', array_map( 'round', $pts ) );
			if ( PHP_VERSION_ID >= 80000 ) {
				imagefilledpolygon( $dst, $pts, $col );
			} else {
				imagefilledpolygon( $dst, $pts, 4, $col ); // phpcs:ignore
			}
		}
	}

	$tmp = $path . '.' . wp_rand( 1000, 9999 ) . '.tmp';
	$ok  = imagejpeg( $dst, $tmp, 85 );
	imagedestroy( $dst );
	if ( ! $ok || ! @rename( $tmp, $path ) ) { // phpcs:ignore
		@unlink( $tmp ); // phpcs:ignore
		return false;
	}
	// Sprzątanie: co ~50. nowy plik kasuje pliki nieużywane od 30 dni.
	if ( 1 === wp_rand( 1, 50 ) ) {
		foreach ( (array) glob( $dir . '/zestaw-*' ) as $old ) {
			if ( $old && $old !== $path && @filemtime( $old ) < time() - 30 * DAY_IN_SECONDS ) { // phpcs:ignore
				@unlink( $old ); // phpcs:ignore
			}
		}
	}
	return array( $url, $W, $H );
}

/**
 * <img> ze zdjęciem dzielonym zestawu w rozmiarze $size (jak wp_get_attachment_image).
 * '' = nie ma dwóch dań ze zdjęciem albo nie udało się złożyć pliku.
 * $want_url = true → zwraca sam adres pliku (okienka, koszyk blokowy).
 */
function rwz_split_image_html( $product_id, $size = 'woocommerce_thumbnail', $attr = array(), $want_url = false, $date = null ) {
	$ids = rwz_get_display_image_ids( $product_id, $date ); // $date: podgląd dnia w module 22
	if ( count( $ids ) < 2 ) {
		return '';
	}
	$src = wp_get_attachment_image_src( $ids[0], $size );
	if ( ! $src || empty( $src[1] ) || empty( $src[2] ) ) {
		return '';
	}
	$file = rwz_split_image_file( $ids[0], $ids[1], $src[1], $src[2] );
	if ( ! $file ) {
		return '';
	}
	if ( $want_url ) {
		return $file[0];
	}
	$size_cls = is_array( $size ) ? implode( 'x', array_map( 'intval', $size ) ) : $size;
	$attr     = is_array( $attr ) ? $attr : array();
	$class    = 'attachment-' . $size_cls . ' size-' . $size_cls . ' rwz-split-img' . ( ! empty( $attr['class'] ) ? ' ' . $attr['class'] : '' );
	$alt      = isset( $attr['alt'] ) ? $attr['alt'] : get_the_title( $product_id );
	$extra    = '';
	foreach ( $attr as $k => $v ) {
		if ( in_array( $k, array( 'class', 'alt', 'src', 'srcset', 'sizes', 'width', 'height' ), true ) || ! is_scalar( $v ) ) {
			continue;
		}
		$extra .= ' ' . esc_attr( $k ) . '="' . esc_attr( $v ) . '"';
	}
	if ( false === strpos( $extra, ' loading=' ) ) {
		$extra .= ' loading="lazy"';
	}
	return '<img src="' . esc_url( $file[0] ) . '" width="' . (int) $src[1] . '" height="' . (int) $src[2] . '" class="' . esc_attr( $class ) . '" alt="' . esc_attr( $alt ) . '" decoding="async"' . $extra . '>';
}

// Zestaw? (ten sam test co w rwz_loop_image_id)
function rwz_is_set_product( $pid ) {
	return get_post_meta( $pid, '_rwz_slots', true ) || get_post_meta( $pid, '_rwz_components', true );
}

/**
 * zdjęcie dzielone w motywie – kafle sklepu/kategorii, podobne produkty,
 * mini-koszyk, koszyk klasyczny (wszystko, co woła $product->get_image()).
 */
add_filter( 'woocommerce_product_get_image', 'rwz_split_product_image', 10, 4 );
function rwz_split_product_image( $image, $product, $size = 'woocommerce_thumbnail', $attr = array() ) {
	if ( ( is_admin() && ! wp_doing_ajax() ) || ! $product || ! rwz_is_set_product( $product->get_id() ) ) {
		return $image;
	}
	$html = rwz_split_image_html( $product->get_id(), $size, $attr );
	return $html ? $html : $image;
}

// koszyk i kasa blokowe (Store API, WooCommerce 9.6+) – ten sam złożony plik.
add_filter( 'woocommerce_store_api_cart_item_images', 'rwz_split_store_api_images', 10, 3 );
function rwz_split_store_api_images( $images, $cart_item, $cart_item_key ) {
	$pid = isset( $cart_item['product_id'] ) ? (int) $cart_item['product_id'] : 0;
	if ( ! $pid || ! rwz_is_set_product( $pid ) ) {
		return $images;
	}
	$url = rwz_split_image_html( $pid, 'woocommerce_thumbnail', array(), true );
	if ( ! $url ) {
		return $images;
	}
	$name = get_the_title( $pid );
	return array(
		(object) array(
			'id'        => 0,
			'src'       => $url,
			'thumbnail' => $url,
			'srcset'    => '',
			'sizes'     => '',
			'name'      => $name,
			'alt'       => $name,
		),
	);
}

/**
 * zdjęcie zestawu poza naszą listą (strona kategorii / sklepu motywu,
 * bloki produktów, mini-koszyk) = to samo co na liście: zdjęcie podpiętego dziś
 * dania (rwz_get_display_image_id). Tylko front; strona pojedynczego produktu ma
 * własną podmianę (rwz_override_main_image), więc tam nie ruszamy.
 */
add_filter( 'woocommerce_product_get_image_id', 'rwz_loop_image_id', 10, 2 );
function rwz_loop_image_id( $image_id, $product ) {
	static $busy = false;
	if ( $busy || ( is_admin() && ! wp_doing_ajax() ) || ! $product || ( function_exists( 'is_product' ) && is_product() ) ) {
		return $image_id;
	}
	$pid = $product->get_id();
	if ( ! get_post_meta( $pid, '_rwz_slots', true ) && ! get_post_meta( $pid, '_rwz_components', true ) ) {
		return $image_id; // nie zestaw
	}
	$busy = true; // ochrona: get_image_id() dań w środku znów wywołuje ten filtr
	$id   = rwz_get_display_image_id( $pid );
	$busy = false;
	return $id ? $id : $image_id;
}

function rwz_get_display_name( $product_id, $default_name ) {
	if ( ! function_exists( 'rwz_get_active_components' ) ) {
		return $default_name;
	}
	$active = rwz_get_active_components( $product_id );
	if ( empty( $active['main'] ) ) {
		return $default_name;
	}
	$names = array_map( function ( $p ) { return $p->get_name(); }, $active['main'] );
	return implode( ' + ', $names );
}

function rwz_render_single_title() {
	global $product;
	$title = get_the_title();

	if ( $product ) {
		$title = rwz_get_display_name( $product->get_id(), $title );
	}

	echo '<h1 class="product_title entry-title rwz-title">' . esc_html( $title ) . '</h1>'; // rwz-title – moduł 15 chowa zdublowany tytuł motywu
}

