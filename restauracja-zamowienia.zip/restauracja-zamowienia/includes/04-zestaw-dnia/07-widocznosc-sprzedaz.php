<?php
/**
 * Moduł 04-zestaw-dnia – widoczność w katalogu, sprzedaż osobno, informacja na stronie produktu.
 * Część modułu (pliki wczytywane po kolei – kolejność jak w dawnym jednym pliku).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// 9) Widoczność w katalogu: NIE ukrywamy już automatycznie składowych.
//    Widoczność w sklepie ustawia się teraz ręcznie, na poziomie kategorii
//    produktów, flagą "Nie wyświetlaj w sklepie" (patrz sekcja "KATEGORIE:
//    widoczność w sklepie" niżej).

// 10) Danie główne zestawu a sprzedaż osobno (reguła na prośbę użytkownika).
//     Dawniej: danie użyte gdziekolwiek jako „danie główne” zestawu NIGDY nie było do kupienia
//     osobno (np. Devolay w zestawie na czwartek blokował Devolaya też w środę).
//     Teraz: w dniu dostawy, w którym danie jest w zestawie, kupuje się je tylko w zestawie;
//     w pozostałe dni – normalnie (wg kalendarza swojej kategorii, moduł 06).
//     Wyjątek bez zmian: danie z kategorii „Nie wyświetlaj w sklepie” = nigdy osobno.

// Nazwa zestawu, w którym produkt jest DANIEM GŁÓWNYM w danym dniu ('' = w żadnym).
function rzd_zestaw_set_main_on_date( $product_id, $date ) {
	static $memo = array();
	$k = (int) $product_id . '|' . $date;
	if ( isset( $memo[ $k ] ) ) {
		return $memo[ $k ];
	}
	$memo[ $k ] = '';
	if ( ! $date || 'yes' !== get_post_meta( $product_id, '_rwz_hidden_as_component_main', true ) ) {
		return '';
	}
	$sets = function_exists( 'rzd_dc_set_ids' ) ? rzd_dc_set_ids() : ( function_exists( 'rzd_all_sets' ) ? rzd_all_sets() : array() );
	foreach ( $sets as $set_id ) {
		$active = rzd_zestaw_get_active_components( $set_id, $date );
		foreach ( (array) $active['main'] as $p ) {
			if ( (int) $p->get_id() === (int) $product_id ) {
				return $memo[ $k ] = get_the_title( $set_id );
			}
		}
	}
	return '';
}

// Data, dla której sprawdzamy (termin klienta, a bez niego – dziś).
function rzd_zestaw_main_check_date() {
	$d = function_exists( 'rzd_dc_selected_date' ) ? rzd_dc_selected_date() : null;
	return $d ? $d : current_time( 'Y-m-d' );
}

add_filter( 'woocommerce_is_purchasable', 'rzd_zestaw_block_main_only_purchase', 10, 2 );
function rzd_zestaw_block_main_only_purchase( $purchasable, $product ) {
	if ( ! $purchasable || 'yes' !== get_post_meta( $product->get_id(), '_rwz_hidden_as_component_main', true ) ) {
		return $purchasable;
	}
	if ( function_exists( 'rzd_zestaw_product_in_hidden_category' ) && rzd_zestaw_product_in_hidden_category( $product->get_id() ) ) {
		return false; // danie tylko do zestawów – jak dawniej
	}
	// Z kalendarzem dostaw o dniu decyduje termin (moduł 06: dc_product_available_on);
	// bez kalendarza – blokada tylko w dniu, gdy danie jest w zestawie (dziś).
	if ( ! function_exists( 'rzd_dc_enabled' ) || ! rzd_dc_enabled() ) {
		return '' === rzd_zestaw_set_main_on_date( $product->get_id(), current_time( 'Y-m-d' ) );
	}
	return $purchasable;
}

add_filter( 'woocommerce_add_to_cart_validation', 'rzd_zestaw_block_main_only_validation', 5, 2 );
function rzd_zestaw_block_main_only_validation( $passed, $product_id ) {
	if ( ! $passed || 'yes' !== get_post_meta( $product_id, '_rwz_hidden_as_component_main', true ) ) {
		return $passed;
	}
	if ( function_exists( 'rzd_zestaw_product_in_hidden_category' ) && rzd_zestaw_product_in_hidden_category( $product_id ) ) {
		wc_add_notice( 'Ten produkt jest dostępny wyłącznie w ramach zestawu i nie można go dodać do koszyka osobno.', 'error' );
		return false;
	}
	$date = rzd_zestaw_main_check_date();
	$set  = rzd_zestaw_set_main_on_date( $product_id, $date );
	if ( '' !== $set ) {
		$day = function_exists( 'rzd_dc_date_label' ) ? rzd_dc_date_label( $date ) : $date;
		wc_add_notice( sprintf( 'W dniu dostawy (%1$s) „%2$s” jest w zestawie „%3$s” – zamów zestaw albo wybierz inny dzień.', $day, get_the_title( $product_id ), $set ), 'error' );
		return false;
	}
	return $passed;
}

// 11) Informacja na stronie produktu
add_action( 'woocommerce_single_product_summary', 'rzd_zestaw_show_component_only_notice', 6 );
function rzd_zestaw_show_component_only_notice() {
	$product = rzd_current_product(); // obiekt produktu albo null (globalne $product bywa napisem – szablony blokowe)
	if ( ! $product || 'yes' !== get_post_meta( $product->get_id(), '_rwz_hidden_as_component_main', true ) ) {
		return;
	}
	if ( function_exists( 'rzd_zestaw_product_in_hidden_category' ) && rzd_zestaw_product_in_hidden_category( $product->get_id() ) ) {
		echo '<p class="woocommerce-info">' . esc_html__( 'Ten produkt jest dostępny wyłącznie w zestawie.', 'woocommerce' ) . '</p>';
		return;
	}
	echo '<p class="woocommerce-info">' . esc_html__( 'W dni, gdy to danie jest w zestawie, zamówisz je tylko w zestawie.', 'woocommerce' ) . '</p>';
}

// (Dawna reguła 12 – ukrywanie zestawu bez aktywnych składników – została usunięta.
//  O dostępności zestawu w dniu dostawy decyduje kalendarz dostaw, moduł 06.)


