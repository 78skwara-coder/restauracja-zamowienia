<?php
/**
 * SNIPPET 7: Koszyk – konfigurator
 * Code Snippets → Run everywhere (pomiń pierwszą linię "<?php")
 *
 * W menu admina pojawia się pozycja "Koszyk", w której ustawiasz:
 * - obrazek koszyka (z biblioteki mediów; bez obrazka jest domyślna ikona),
 * - nazwę koszyka,
 * - czy pokazywać obrazek + nazwę, czy tylko obrazek,
 * - czy pokazywać ilość produktów i wartość koszyka,
 * - czy zastąpić pozycję menu prowadzącą do koszyka,
 * - czy włączyć pływający koszyk (opcjonalnie tylko na telefonach) i po której stronie.
 *
 * Koszyk możesz też wstawić w dowolne miejsce shortcodem [koszyk].
 * Liczniki odświeżają się same po dodaniu produktu przez AJAX.
 * Jeśli masz już inny snippet z koszykiem w menu / pływającym koszykiem – wyłącz go.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 0. USTAWIENIA
 * ============================================================ */
function kc_defaults() {
	return array(
		'image_id'          => 0,
		'name'              => 'Koszyk',
		'display'           => 'both',   // both = obrazek + nazwa, image = tylko obrazek
		'show_qty'          => 1,
		'show_total'        => 0,
		'menu_replace'      => 1,
		'float_enabled'     => 0,
		'float_mobile_only' => 0,
		'float_pos'         => 'right',
		'mobile_enabled'    => 0,
		'mobile_breakpoint' => 782,
		'mobile_logo_sel'   => '',
		'mobile_menu_sel'   => '',
		'added_popup'       => 1,
		'list_url'          => '',
	);
}

function kc_get_settings() {
	$s = get_option( 'kc_settings', array() );
	$s = wp_parse_args( is_array( $s ) ? $s : array(), kc_defaults() );
	if ( '' === trim( (string) $s['name'] ) ) {
		$s['name'] = 'Koszyk';
	}
	return $s;
}

/* ============================================================
 * 1. WYGLĄD KOSZYKA (jedna funkcja dla menu, pływającego i shortcode)
 * ============================================================ */
function kc_image_html( $s ) {
	$id = (int) $s['image_id'];
	if ( $id && wp_attachment_is_image( $id ) ) {
		return wp_get_attachment_image( $id, array( 64, 64 ), false, array( 'class' => 'kc-img', 'alt' => '' ) );
	}
	// domyślna ikona koszyka
	return '<svg class="kc-img kc-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg>';
}

// $variant: 'menu' (w linii, np. w menu/shortcode) albo 'float' (pływający przycisk)
function kc_render( $variant = 'menu', $preview = false ) {
	$s = kc_get_settings();

	if ( $preview ) {
		$count = 3;
		$total = wc_price( 48 );
	} else {
		$has_cart = function_exists( 'WC' ) && WC()->cart;
		$count    = $has_cart ? (int) WC()->cart->get_cart_contents_count() : 0;
		$total    = $has_cart ? WC()->cart->get_cart_subtotal() : '';
	}
	$has = $count > 0;

	$classes = array( 'kc-cart', 'kc-' . $variant . '-cart' );
	if ( $has ) {
		$classes[] = 'kc-has-items';
	}
	if ( 'float' === $variant ) {
		$classes[] = ( 'left' === $s['float_pos'] ) ? 'kc-float-left' : 'kc-float-right';
		if ( ! empty( $s['float_mobile_only'] ) ) {
			$classes[] = 'kc-float-mobile';
		}
	}

	$is_link = in_array( $variant, array( 'float', 'mobile' ), true );
	$tag     = $is_link ? 'a' : 'span';
	$attrs   = $is_link ? ' href="' . esc_url( wc_get_cart_url() ) . '"' : '';

	ob_start();
	echo '<' . $tag . ' class="' . esc_attr( implode( ' ', $classes ) ) . '"' . $attrs . '>';
	echo '<span class="kc-icon">' . kc_image_html( $s );
	if ( $has ) {
		echo ! empty( $s['show_qty'] )
			? '<span class="kc-badge">' . (int) $count . '</span>'
			: '<span class="kc-dot"></span>'; // sam znacznik, że w koszyku coś jest
	}
	echo '</span>';

	if ( 'both' === $s['display'] ) {
		echo '<span class="kc-name">' . esc_html( $s['name'] ) . '</span>';
	} else {
		echo '<span class="screen-reader-text">' . esc_html( $s['name'] ) . '</span>';
	}
	if ( ! empty( $s['show_total'] ) ) {
		echo '<span class="kc-total">' . wp_kses_post( $total ) . '</span>';
	}
	echo '</' . $tag . '>';
	return ob_get_clean();
}

function kc_css() {
	$s = kc_get_settings();
	?>
	<style>
		.kc-cart{display:inline-flex;align-items:center;gap:8px;line-height:1;vertical-align:middle}
		.kc-icon{position:relative;display:inline-flex}
		.kc-img{width:28px;height:28px;object-fit:contain;display:block}
		.kc-badge{position:absolute;top:-8px;right:-10px;min-width:18px;height:18px;padding:0 5px;border-radius:9px;background:#d63638;color:#fff;font-size:11px;line-height:18px;text-align:center;font-weight:700;box-sizing:border-box}
		.kc-dot{position:absolute;top:-3px;right:-4px;width:10px;height:10px;border-radius:50%;background:#d63638}
		.kc-name,.kc-total{font-weight:600;white-space:nowrap}
		.kc-float-cart,.kc-float-cart:hover,.kc-float-cart:focus{position:fixed;bottom:18px;z-index:9998;padding:12px 16px;border-radius:32px;background:#fff !important;color:#222 !important;text-decoration:none !important;box-shadow:0 4px 16px rgba(0,0,0,.3)}
		.kc-float-cart .kc-name,.kc-float-cart .kc-total,.kc-float-cart .kc-total *{color:#222 !important}
		.kc-float-right{right:18px}
		.kc-float-left{left:18px}
		@media (min-width:783px){.kc-float-mobile{display:none !important}}
		.kc-preview .kc-float-cart{position:static;display:inline-flex}
		.kc-mobile-wrap{display:none;margin-left:auto;margin-right:auto;align-items:center;flex:0 0 auto;width:max-content;max-width:100%}
		.kc-mobile-cart,.kc-mobile-cart:hover,.kc-mobile-cart:focus{color:inherit;text-decoration:none}
		<?php if ( ! empty( $s['mobile_enabled'] ) ) : ?>
		@media (max-width: <?php echo (int) $s['mobile_breakpoint']; ?>px){
			.kc-mobile-wrap.kc-placed{display:flex}
		}
		@media (max-width: <?php echo (int) $s['mobile_breakpoint']; ?>px){
			li:has(> a .kc-menu-cart),li:has(> .kc-menu-cart){display:none !important}
		}
		<?php endif; ?>
		/* Wygląd okienka "Dodano do koszyka": moduł 15 → rzd_popup_css() */
	</style>
	<?php
}

/* ============================================================
 * 2. WSTAWIANIE: menu, pływający koszyk, shortcode, odświeżanie
 * ============================================================ */
add_action( 'wp_head', 'kc_css' );

// Pozycja menu prowadząca do koszyka → koszyk z obrazkiem/nazwą/licznikiem
add_filter( 'nav_menu_item_title', function ( $title, $item, $args = null, $depth = 0 ) {
	$s = kc_get_settings();
	if ( is_admin() || empty( $s['menu_replace'] ) || ! function_exists( 'wc_get_page_id' ) ) {
		return $title;
	}
	$cart_page = (int) wc_get_page_id( 'cart' );
	$is_cart   = ( 'page' === $item->object && (int) $item->object_id === $cart_page )
		|| ( ! empty( $item->url ) && untrailingslashit( $item->url ) === untrailingslashit( wc_get_cart_url() ) );
	return $is_cart ? kc_render( 'menu' ) : $title;
}, 10, 4 );

// Pływający koszyk (nie pokazujemy go na stronie koszyka i kasy)
add_action( 'wp_footer', function () {
	$s = kc_get_settings();
	if ( is_admin() || empty( $s['float_enabled'] ) ) {
		return;
	}
	if ( function_exists( 'is_cart' ) && ( is_cart() || is_checkout() ) ) {
		return;
	}
	echo kc_render( 'float' );
} );

add_shortcode( 'koszyk', function () {
	return kc_render( 'menu' );
} );

// Po dodaniu do koszyka przez AJAX odśwież liczniki
add_filter( 'woocommerce_add_to_cart_fragments', function ( $fragments ) {
	$s = kc_get_settings();
	$fragments['span.kc-menu-cart'] = kc_render( 'menu' );
	if ( ! empty( $s['float_enabled'] ) ) {
		$fragments['a.kc-float-cart'] = kc_render( 'float' );
	}
	if ( ! empty( $s['mobile_enabled'] ) ) {
		$fragments['a.kc-mobile-cart'] = kc_render( 'mobile' );
	}
	if ( ! empty( $s['added_popup'] ) ) {
		$fragments['div.kc-added-data'] = kc_added_payload_html();
	}
	return $fragments;
} );

/* ============================================================
 * 3. PANEL ADMINA: menu "Koszyk"
 * ============================================================ */
add_action( 'admin_menu', function () {
	add_menu_page( 'Koszyk', 'Koszyk', 'manage_woocommerce', 'kc-koszyk', 'kc_render_admin_page', 'dashicons-cart', 57 );
} );

add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( 'toplevel_page_kc-koszyk' === $hook ) {
		wp_enqueue_media();
	}
} );

add_action( 'admin_post_kc_save', function () {
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		wp_die( 'Brak uprawnień.' );
	}
	$nonce = isset( $_POST['kc_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['kc_nonce'] ) ) : '';
	if ( ! wp_verify_nonce( $nonce, 'kc_save' ) ) {
		wp_die( 'Formularz wygasł – odśwież stronę i spróbuj ponownie.' );
	}
	$p = wp_unslash( $_POST );

	$image_id = isset( $p['kc_image_id'] ) ? absint( $p['kc_image_id'] ) : 0;
	if ( $image_id && ! wp_attachment_is_image( $image_id ) ) {
		$image_id = 0;
	}
	$name = isset( $p['kc_name'] ) ? sanitize_text_field( $p['kc_name'] ) : '';

	update_option( 'kc_settings', array(
		'image_id'          => $image_id,
		'name'              => '' === $name ? 'Koszyk' : $name,
		'display'           => ( isset( $p['kc_display'] ) && 'image' === $p['kc_display'] ) ? 'image' : 'both',
		'show_qty'          => empty( $p['kc_show_qty'] ) ? 0 : 1,
		'show_total'        => empty( $p['kc_show_total'] ) ? 0 : 1,
		'menu_replace'      => empty( $p['kc_menu_replace'] ) ? 0 : 1,
		'float_enabled'     => empty( $p['kc_float_enabled'] ) ? 0 : 1,
		'float_mobile_only' => empty( $p['kc_float_mobile_only'] ) ? 0 : 1,
		'float_pos'         => ( isset( $p['kc_float_pos'] ) && 'left' === $p['kc_float_pos'] ) ? 'left' : 'right',
		'mobile_enabled'    => empty( $p['kc_mobile_enabled'] ) ? 0 : 1,
		'mobile_breakpoint' => ( isset( $p['kc_mobile_bp'] ) && absint( $p['kc_mobile_bp'] ) >= 320 ) ? min( 1400, absint( $p['kc_mobile_bp'] ) ) : 782,
		'mobile_logo_sel'   => isset( $p['kc_mobile_logo_sel'] ) ? sanitize_text_field( $p['kc_mobile_logo_sel'] ) : '',
		'mobile_menu_sel'   => isset( $p['kc_mobile_menu_sel'] ) ? sanitize_text_field( $p['kc_mobile_menu_sel'] ) : '',
		'added_popup'       => empty( $p['kc_added_popup'] ) ? 0 : 1,
		'list_url'          => isset( $p['kc_list_url'] ) ? esc_url_raw( trim( $p['kc_list_url'] ) ) : '',
	), false );

	wp_safe_redirect( add_query_arg( array( 'page' => 'kc-koszyk', 'saved' => 1 ), admin_url( 'admin.php' ) ) );
	exit;
} );

function kc_render_admin_page() {
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		return;
	}
	$s       = kc_get_settings();
	$preview = ( (int) $s['image_id'] && wp_attachment_is_image( (int) $s['image_id'] ) )
		? wp_get_attachment_image( (int) $s['image_id'], array( 48, 48 ) )
		: '';
	kc_css();
	?>
	<div class="wrap">
		<h1>Koszyk</h1>
		<?php if ( isset( $_GET['saved'] ) ) : ?>
			<div class="notice notice-success is-dismissible"><p>Zapisano.</p></div>
		<?php endif; ?>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" novalidate>
			<input type="hidden" name="action" value="kc_save">
			<input type="hidden" name="kc_nonce" value="<?php echo esc_attr( wp_create_nonce( 'kc_save' ) ); ?>">

			<table class="form-table" role="presentation"><tbody>
				<tr>
					<th scope="row">Obrazek koszyka</th>
					<td id="kc-image-field">
						<input type="hidden" name="kc_image_id" value="<?php echo esc_attr( $s['image_id'] ?: '' ); ?>">
						<div class="kc-image-preview" style="margin:0 0 8px"><?php echo $preview; ?></div>
						<button type="button" class="button kc-pick">Wybierz obrazek</button>
						<button type="button" class="button kc-remove">Usuń (wróć do ikony domyślnej)</button>
						<p class="description">Najlepiej kwadratowy PNG z przezroczystym tłem.</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="kc_name">Nazwa koszyka</label></th>
					<td><input type="text" id="kc_name" name="kc_name" class="regular-text" value="<?php echo esc_attr( $s['name'] ); ?>"></td>
				</tr>
				<tr>
					<th scope="row">Wyświetlanie</th>
					<td>
						<label><input type="radio" name="kc_display" value="both" <?php checked( $s['display'], 'both' ); ?>> Obrazek i nazwa</label><br>
						<label><input type="radio" name="kc_display" value="image" <?php checked( $s['display'], 'image' ); ?>> Tylko obrazek</label>
					</td>
				</tr>
				<tr>
					<th scope="row">Dodatkowe informacje</th>
					<td>
						<label><input type="checkbox" name="kc_show_qty" value="1" <?php checked( ! empty( $s['show_qty'] ) ); ?>> Pokaż ilość produktów w koszyku</label><br>
						<label><input type="checkbox" name="kc_show_total" value="1" <?php checked( ! empty( $s['show_total'] ) ); ?>> Pokaż wartość koszyka</label>
						<p class="description">Bez ilości, ale z produktami w koszyku, pojawia się mały czerwony znacznik.</p>
					</td>
				</tr>
				<tr>
					<th scope="row">Menu</th>
					<td>
						<label><input type="checkbox" name="kc_menu_replace" value="1" <?php checked( ! empty( $s['menu_replace'] ) ); ?>> Zastąp pozycję menu prowadzącą do koszyka tym koszykiem</label>
						<p class="description">Możesz też wstawić koszyk w dowolnym miejscu shortcodem <code>[koszyk]</code>.</p>
					</td>
				</tr>
				<tr>
					<th scope="row">Pływający koszyk</th>
					<td>
						<label><input type="checkbox" name="kc_float_enabled" value="1" <?php checked( ! empty( $s['float_enabled'] ) ); ?>> Włącz pływający koszyk</label><br>
						<label><input type="checkbox" name="kc_float_mobile_only" value="1" <?php checked( ! empty( $s['float_mobile_only'] ) ); ?>> Pokazuj tylko na telefonach i tabletach</label><br>
						<label>Położenie:
							<select name="kc_float_pos">
								<option value="right" <?php selected( $s['float_pos'], 'right' ); ?>>Prawy dolny róg</option>
								<option value="left" <?php selected( $s['float_pos'], 'left' ); ?>>Lewy dolny róg</option>
							</select>
						</label>
						<p class="description">Pływający koszyk nie pokazuje się na stronie koszyka i kasy.</p>
					</td>
				</tr>
				<tr>
					<th scope="row">Koszyk na telefonie</th>
					<td>
						<label><input type="checkbox" name="kc_mobile_enabled" value="1" <?php checked( ! empty( $s['mobile_enabled'] ) ); ?>> Pokaż koszyk w nagłówku na urządzeniach mobilnych (między logo a menu)</label><br>
						<label>Pokazuj przy szerokości ekranu do: <input type="number" name="kc_mobile_bp" value="<?php echo esc_attr( $s['mobile_breakpoint'] ); ?>" style="width:80px"> px</label>
						<p class="description">Wygląda jak koszyk w menu na stronie głównej (ten sam obrazek, nazwa i liczniki). Na telefonie pozycja koszyka w rozwijanym menu jest wtedy ukrywana, żeby się nie dublowała.</p>
						<details style="margin-top:8px">
							<summary style="cursor:pointer">Zaawansowane: dopasowanie do motywu</summary>
							<p class="description">Zostaw puste, żeby użyć automatycznego wykrywania. Jeśli koszyk ląduje w złym miejscu, wpisz selektory CSS logo i przycisku menu (burgera) Twojego motywu.</p>
							<p><label>Selektor logo:<br><input type="text" class="regular-text" name="kc_mobile_logo_sel" value="<?php echo esc_attr( $s['mobile_logo_sel'] ); ?>" placeholder="<?php echo esc_attr( kc_default_logo_sel() ); ?>"></label></p>
							<p><label>Selektor przycisku menu:<br><input type="text" class="regular-text" name="kc_mobile_menu_sel" value="<?php echo esc_attr( $s['mobile_menu_sel'] ); ?>" placeholder="<?php echo esc_attr( kc_default_menu_sel() ); ?>"></label></p>
						</details>
					</td>
				</tr>
				<tr>
					<th scope="row">Po dodaniu do koszyka</th>
					<td>
						<label><input type="checkbox" name="kc_added_popup" value="1" <?php checked( ! empty( $s['added_popup'] ) ); ?>> Pokaż okienko z tym, co dodano (Przejdź do koszyka / Kontynuuj zakupy)</label>
						<p style="margin:10px 0 4px"><label>Adres strony z listą produktów:<br><input type="url" class="regular-text" name="kc_list_url" value="<?php echo esc_attr( $s['list_url'] ); ?>" placeholder="https://twoja-strona.pl/zamow/"></label></p>
						<p class="description">Do tej strony wracasz po „Kontynuuj zakupy” (gdy dodawałeś z innej strony) oraz po „Wybierz inny produkt” w kalendarzu dostaw.</p>
					</td>
				</tr>
			</tbody></table>
			<button type="submit" class="button button-primary">Zapisz</button>
		</form>

		<h2>Podgląd zapisanych ustawień</h2>
		<div class="kc-preview" style="background:#fff;border:1px solid #c3c4c7;padding:16px;max-width:520px">
			<p style="margin-top:0">W menu / shortcode:</p>
			<?php echo kc_render( 'menu', true ); ?>
			<p>Pływający:</p>
			<?php echo kc_render( 'float', true ); ?>
		</div>
	</div>
	<script>
	jQuery(function ($) {
		$('#kc-image-field').on('click', '.kc-pick', function (e) {
			e.preventDefault();
			var wrap = $('#kc-image-field');
			var frame = wp.media({ title: 'Wybierz obrazek koszyka', button: { text: 'Użyj' }, multiple: false, library: { type: 'image' } });
			frame.on('select', function () {
				var a = frame.state().get('selection').first().toJSON();
				var url = (a.sizes && a.sizes.thumbnail) ? a.sizes.thumbnail.url : a.url;
				wrap.find('input[type=hidden]').val(a.id);
				wrap.find('.kc-image-preview').html('<img src="' + url + '" style="width:48px;height:48px;object-fit:contain">');
			});
			frame.open();
		});
		$('#kc-image-field').on('click', '.kc-remove', function (e) {
			e.preventDefault();
			$('#kc-image-field input[type=hidden]').val('');
			$('#kc-image-field .kc-image-preview').empty();
		});
	});
	</script>
	<?php
}

/* ============================================================
 * KOSZYK: stały przycisk powrotu + pusty koszyk bez "nowości"
 * ============================================================
 * "woocommerce_before_cart" wykonuje się ZAWSZE na stronie koszyka – zarówno
 * gdy są w nim produkty, jak i gdy jest pusty – więc to tu wstawiamy przycisk
 * powrotu, żeby był widoczny w każdym przypadku, a nie tylko przy pustym
 * koszyku.
 */
function kc_back_to_shop_url() {
	$s = kc_get_settings();
	if ( ! empty( $s['list_url'] ) ) {
		return esc_url( $s['list_url'] );
	}

	// Bez wypełnionego pola "Adres strony z listą produktów" wracaliśmy na
	// domyślną stronę sklepu WooCommerce – a to prawie nigdy nie jest ta
	// sama strona, na której faktycznie jest lista zamówień (shortcode
	// [lista_zamowien]), więc klient trafiał w przypadkowe miejsce. Zanim
	// wrócimy do sklepu WooCommerce, spróbujmy najpierw znaleźć stronę
	// z tym shortcode'em i skierować tam.
	static $cached = null;
	if ( null === $cached ) {
		// Tylko "page" (nie "post") – strona z listą produktów restauracji to
		// prawie zawsze zwykła podstrona, nie wpis na blogu; ORDER BY ID ASC
		// daje przewidywalny, powtarzalny wynik (ta sama strona za każdym
		// razem), zamiast zależeć od niejawnej "trafności" wyszukiwania
		// WordPressa, gdy shortcode występuje na więcej niż jednej stronie.
		$found  = get_posts( array(
			'post_type'      => array( 'page' ),
			'post_status'    => 'publish',
			'posts_per_page' => 1,
			'orderby'        => 'ID',
			'order'          => 'ASC',
			's'              => '[lista_zamowien',
			'fields'         => 'ids',
		) );
		$cached = $found ? get_permalink( $found[0] ) : wc_get_page_permalink( 'shop' );
	}
	return esc_url( $cached );
}

add_action( 'woocommerce_before_cart', function () {
	echo '<p class="kc-back-to-shop"><a class="button wc-backward" href="' . kc_back_to_shop_url() . '">Wróć do listy produktów</a></p>';
}, 5 );

// Sam komunikat pustego koszyka: bez przycisku (jest już powyżej, na stałe)
add_filter( 'wc_empty_cart_message', function () {
	return '<p class="cart-empty woocommerce-info">Koszyk jest pusty.</p>';
} );

// Motywy różnie doklejają dodatkową zawartość do pustego koszyka (np. "Nowości")
// pod hookiem "woocommerce_cart_is_empty" – nie znamy nazwy funkcji Twojego
// motywu, więc zamiast zgadywać, czyścimy CAŁY ten hook tuż przed
// wyrenderowaniem strony koszyka.
add_action( 'wp', function () {
	if ( function_exists( 'is_cart' ) && is_cart() ) {
		remove_all_actions( 'woocommerce_cart_is_empty' );
	}
}, 20 );

/**
 * Jeżeli strona koszyka korzysta z NOWEGO koszyka blokowego (Gutenberg,
 * blok "Koszyk") zamiast starego kodu [woocommerce_cart], powyższe hooki
 * ("woocommerce_before_cart" i inne) w ogóle się nie wykonują – blok
 * renderuje się inaczej i ich nie używa. Dlatego przycisk powrotu wstawiamy
 * DODATKOWO przez JS, już po wczytaniu strony: to zadziała niezależnie od
 * tego, czy masz stary czy nowy (blokowy) koszyk – JS znajdzie kontener
 * koszyka na stronie i wstawi przycisk tuż przed nim, jeśli PHP go tam
 * jeszcze nie wstawił.
 */
add_action( 'wp_footer', function () {
	if ( ! function_exists( 'is_cart' ) || ! is_cart() ) {
		return;
	}
	?>
	<script>
	(function () {
		if (document.querySelector('.kc-back-to-shop')) { return; } // już jest (stary koszyk przez PHP)
		var target = document.querySelector(
			'.wp-block-woocommerce-cart, .wc-block-cart, .woocommerce-cart-form, ' +
			'.wc-empty-cart-message, .cart-empty, .wp-block-woocommerce-empty-cart-block'
		);
		if (!target || !target.parentNode) { return; }
		var p = document.createElement('p');
		p.className = 'kc-back-to-shop';
		var a = document.createElement('a');
		a.className = 'button wc-backward';
		a.href = <?php echo wp_json_encode( kc_back_to_shop_url() ); ?>;
		a.textContent = 'Wróć do listy produktów';
		p.appendChild(a);
		target.parentNode.insertBefore(p, target);
	})();

	/**
	 * Usunięcie samego napisu "Nowości"/"Nowe w sklepie" nad pustym koszykiem.
	 * CSS ukrywa siatkę produktów (jej klasy znamy), ale nagłówek nad nią to
	 * osobny element z tekstem, którego CSS "po klasie" nie złapie. Dodatkowo,
	 * jeśli to blokowy koszyk (React), taki nagłówek może pojawić się w DOM
	 * dopiero PO wczytaniu strony (dociągnięty przez skrypt koszyka) – dlatego
	 * pilnujemy zmian na stronie przez chwilę, zamiast sprawdzić tylko raz.
	 */
	(function () {
		var re = /nowo[śs]ci|nowe w sklepie|mo[żz]e ci[ęe] zainteresowa|polecane produkty|may be interested|you might like/i;
		function sweep(root) {
			(root || document).querySelectorAll('h1, h2, h3, h4, h5, .wp-block-heading').forEach(function (el) {
				if (el.getAttribute('data-kc-hidden') === '1') { return; }
				if (re.test(el.textContent || '')) {
					el.setAttribute('data-kc-hidden', '1');
					el.style.display = 'none';
					var sib = el.nextElementSibling;
					if (sib) { sib.style.display = 'none'; }
				}
			});
		}
		sweep();
		if (window.MutationObserver) {
			var mo = new MutationObserver(function () { sweep(); });
			mo.observe(document.body, { childList: true, subtree: true });
			setTimeout(function () { mo.disconnect(); }, 8000);
		}
	})();
	</script>
	<?php
}, 5 );

/**
 * TO SAMO na stronie płatności: przycisk powrotu do sklepu ma być dostępny
 * "nawet tuż przed płatnością", nie tylko w koszyku. Klasyczna strona kasy
 * dostaje przycisk przez PHP (hook "woocommerce_before_checkout_form"),
 * a blokowa (Gutenberg) – tak jak w koszyku – przez JS w stopce, na wypadek
 * gdyby klasyczny hook się nie wykonał.
 */
add_action( 'woocommerce_before_checkout_form', function () {
	echo '<p class="kc-back-to-shop"><a class="button wc-backward" href="' . kc_back_to_shop_url() . '">Wróć do listy produktów</a></p>';
}, 5 );

add_action( 'wp_footer', function () {
	if ( ! function_exists( 'is_checkout' ) || ! is_checkout() || is_order_received_page() ) {
		return;
	}
	?>
	<script>
	(function () {
		if (document.querySelector('.kc-back-to-shop')) { return; } // już jest (klasyczna kasa przez PHP)
		var target = document.querySelector(
			'.wp-block-woocommerce-checkout, .wc-block-checkout, form.woocommerce-checkout, .woocommerce-checkout'
		);
		if (!target || !target.parentNode) { return; }
		var p = document.createElement('p');
		p.className = 'kc-back-to-shop';
		var a = document.createElement('a');
		a.className = 'button wc-backward';
		a.href = <?php echo wp_json_encode( kc_back_to_shop_url() ); ?>;
		a.textContent = 'Wróć do listy produktów';
		p.appendChild(a);
		target.parentNode.insertBefore(p, target);
	})();
	</script>
	<?php
}, 5 );


/* ============================================================
 * 4. KOSZYK NA TELEFONIE: w nagłówku, między logo a menu (burger)
 * ============================================================ */
function kc_default_logo_sel() {
	return '.custom-logo-link, .site-logo, .site-branding, .logo, #logo, a[rel="home"]';
}
function kc_default_menu_sel() {
	return '.menu-toggle, .navbar-toggler, .mobile-menu-toggle, .hamburger, .menu-btn, .nav-toggle, .elementor-menu-toggle, .mobile-menu-button, button[aria-controls*="menu"]';
}

add_action( 'wp_footer', function () {
	$s = kc_get_settings();
	if ( is_admin() || empty( $s['mobile_enabled'] ) ) {
		return;
	}
	$logo = '' !== trim( (string) $s['mobile_logo_sel'] ) ? $s['mobile_logo_sel'] : kc_default_logo_sel();
	$menu = '' !== trim( (string) $s['mobile_menu_sel'] ) ? $s['mobile_menu_sel'] : kc_default_menu_sel();

	echo '<div class="kc-mobile-wrap">' . kc_render( 'mobile' ) . '</div>';
	?>
	<script>
	(function () {
		var wrap = document.querySelector('.kc-mobile-wrap');
		if (!wrap) { return; }
		var logoSel = <?php echo wp_json_encode( $logo ); ?>;
		var menuSel = <?php echo wp_json_encode( $menu ); ?>;

		function q(root, sel) { try { return root.querySelector(sel); } catch (e) { return null; } }
		function placed() { wrap.className += ' kc-placed'; }

		var roots = document.querySelectorAll('header, .site-header, #masthead, #header, .header');
		var logo = null, menu = null, i;
		for (i = 0; i < roots.length; i++) {
			if (!logo) { logo = q(roots[i], logoSel); }
			if (!menu) { menu = q(roots[i], menuSel); }
		}
		if (!logo) { logo = q(document, logoSel); }
		if (!menu) { menu = q(document, menuSel); }

		// 1) Logo i przycisk menu: wstawiamy koszyk POMIĘDZY nimi
		if (logo && menu) {
			var anc = logo;
			while (anc && !anc.contains(menu)) { anc = anc.parentNode; }
			if (anc && anc !== logo) {
				var lc = logo; while (lc.parentNode !== anc) { lc = lc.parentNode; }
				var mc = menu; while (mc.parentNode !== anc) { mc = mc.parentNode; }
				if (lc !== mc) {
					var menuAfterLogo = !!(lc.compareDocumentPosition(mc) & Node.DOCUMENT_POSITION_FOLLOWING);
					anc.insertBefore(wrap, menuAfterLogo ? lc.nextSibling : mc.nextSibling);
					placed();
					return;
				}
			}
		}
		// 2) Tylko logo: koszyk zaraz za logo
		if (logo && logo.parentNode) {
			logo.parentNode.insertBefore(wrap, logo.nextSibling);
			placed();
			return;
		}
		// 3) Ostatecznie: na końcu nagłówka
		if (roots.length) { roots[0].appendChild(wrap); placed(); }
	})();
	</script>
	<?php
}, 30 );

/* ============================================================
 * 5. OKIENKO PO DODANIU DO KOSZYKA
 * ============================================================ */
function kc_list_url() {
	$s = kc_get_settings();
	return $s['list_url'] ? esc_url_raw( $s['list_url'] ) : '';
}

// Zapamiętujemy, co klient dodał (produkt + jego dodatki), żeby pokazać w okienku
add_action( 'woocommerce_add_to_cart', 'kc_record_added', 5, 6 );
function kc_record_added( $cart_item_key, $product_id, $quantity, $variation_id, $variation, $cart_item_data ) {
	$s = kc_get_settings();
	if ( empty( $s['added_popup'] ) || ! function_exists( 'WC' ) || ! WC()->session ) {
		return;
	}
	$p = wc_get_product( $variation_id ? $variation_id : $product_id );
	if ( ! $p ) {
		return;
	}
	if ( ! empty( $cart_item_data['rwz_child_of'] ) ) {
		$cur = WC()->session->get( 'kc_added' );
		if ( is_array( $cur ) ) {
			$cur['children'][] = array( 'name' => $p->get_name(), 'qty' => (int) $quantity );
			WC()->session->set( 'kc_added', $cur );
		}
		return;
	}
	WC()->session->set( 'kc_added', array( 'name' => $p->get_name(), 'qty' => (int) $quantity, 'children' => array() ) );
}

// Standardowy komunikat WooCommerce jest zbędny, gdy działa okienko
add_filter( 'wc_add_to_cart_message_html', function ( $message ) {
	$s = kc_get_settings();
	return empty( $s['added_popup'] ) ? $message : '';
} );

// Dane dla okienka (odczyt kasuje zapis w sesji, więc okienko pokaże się raz)
function kc_added_payload_html() {
	$data = ( function_exists( 'WC' ) && WC()->session ) ? WC()->session->get( 'kc_added' ) : null;
	if ( $data && WC()->session ) {
		WC()->session->set( 'kc_added', null );
	}
	return '<div class="kc-added-data" hidden data-json="' . esc_attr( wp_json_encode( $data ? $data : null ) ) . '"></div>';
}

add_action( 'wp_footer', function () {
	$s = kc_get_settings();
	if ( is_admin() || empty( $s['added_popup'] ) ) {
		return;
	}
	$cfg = array( 'listUrl' => kc_list_url() );
	?>
	<div id="kc-added" hidden>
		<div class="kc-added-panel" role="dialog" aria-modal="true">
			<h3>Dodano do koszyka</h3>
			<div class="kc-added-list"></div>
			<div class="kc-added-actions">
				<div class="kc-added-act"><button type="button" class="kc-added-continue">Kontynuuj zakupy</button></div>
				<div class="kc-added-act"><a class="kc-added-cart" href="<?php echo esc_url( wc_get_cart_url() ); ?>">Przejdź do koszyka</a></div>
			</div>
		</div>
	</div>
	<?php echo kc_added_payload_html(); ?>
	<script>
	var kcAddedCfg = <?php echo wp_json_encode( $cfg ); ?>;
	(function () {
		var modal = document.getElementById('kc-added');
		if (!modal) { return; }
		var list = modal.querySelector('.kc-added-list');

		function show(d) {
			if (!d) { return; }
			list.innerHTML = '';
			var main = document.createElement('div');
			main.className = 'kc-added-main';
			main.textContent = d.name + ' × ' + d.qty;
			list.appendChild(main);
			if (d.children && d.children.length) {
				var ul = document.createElement('ul');
				d.children.forEach(function (c) {
					var li = document.createElement('li');
					li.textContent = c.name + ' × ' + c.qty;
					ul.appendChild(li);
				});
				list.appendChild(ul);
			}
			modal.hidden = false;
		}

		function parse(el) {
			try { return JSON.parse(el.getAttribute('data-json')); } catch (e) { return null; }
		}

		// po przeładowaniu strony (dodanie z formularza)
		var holder = document.querySelector('.kc-added-data');
		if (holder) { show(parse(holder)); }

		// po dodaniu przez AJAX (przyciski w pętlach motywu)
		if (window.jQuery) {
			window.jQuery(document.body).on('added_to_cart', function (e, fragments) {
				var html = fragments && fragments['div.kc-added-data'];
				if (!html) { return; }
				var t = document.createElement('div');
				t.innerHTML = html;
				if (t.firstChild) { show(parse(t.firstChild)); }
			});
		}

		modal.querySelector('.kc-added-continue').addEventListener('click', function () {
			modal.hidden = true;
			// "Kontynuuj zakupy" wraca do listy produktów (jeśli jesteśmy gdzie indziej)
			if (kcAddedCfg.listUrl) {
				try {
					var u = new URL(kcAddedCfg.listUrl, window.location.href);
					if (u.pathname.replace(/\/$/, '') !== window.location.pathname.replace(/\/$/, '')) { window.location.href = u.href; }
				} catch (err) {}
			}
		});
		document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !modal.hidden) { modal.hidden = true; } });
	})();
	</script>
	<?php
}, 40 );

/* ============================================================
 * 6. CZYSZCZENIE KOSZYKA PO ZŁOŻENIU ZAMÓWIENIA (poprawka 2.17.1)
 * ============================================================
 * WooCommerce sam czyści koszyk na stronie "Zamówienie przyjęte", ALE
 * tylko wtedy, gdy zamówienie ma już status inny niż "Oczekujące na
 * płatność". Przy płatnościach online potwierdzenie z bramki (webhook)
 * często dochodzi PÓŹNIEJ niż klient wraca na stronę podsumowania – wtedy
 * zamówienie jest jeszcze "pending", WooCommerce koszyka nie rusza i klient
 * może kupić to samo drugi raz.
 *
 * Zasada tutaj: skoro klient doszedł do strony podsumowania SWOJEGO
 * zamówienia (poprawny klucz zamówienia w adresie), koszyk jest pusty,
 * niezależnie od statusu. Jeśli płatność się nie udała, klient opłaci
 * TO SAMO zamówienie linkiem "Zapłać" (z e-maila / z Moje konto), a nie
 * przez ponowne złożenie koszyka. Opróżnienie koszyka zwalnia też termin
 * dostawy (hook woocommerce_cart_emptied w module 06).
 */
add_action( 'template_redirect', 'kc_clear_cart_after_order', 20 );
function kc_clear_cart_after_order() {
	if ( ! function_exists( 'is_order_received_page' ) || ! is_order_received_page() ) {
		return;
	}
	if ( ! function_exists( 'WC' ) || ! WC()->cart || WC()->cart->is_empty() ) {
		return;
	}
	global $wp;
	$order_id  = isset( $wp->query_vars['order-received'] ) ? absint( $wp->query_vars['order-received'] ) : 0;
	$order_key = isset( $_GET['key'] ) ? wc_clean( wp_unslash( $_GET['key'] ) ) : '';
	if ( ! $order_id || '' === $order_key ) {
		return;
	}
	$order = wc_get_order( $order_id );
	if ( ! $order || ! hash_equals( (string) $order->get_order_key(), (string) $order_key ) ) {
		return; // obcy lub zmyślony adres – nie ruszamy koszyka
	}
	WC()->cart->empty_cart();
	if ( WC()->session ) {
		WC()->session->set( 'order_awaiting_payment', null );
	}
}
