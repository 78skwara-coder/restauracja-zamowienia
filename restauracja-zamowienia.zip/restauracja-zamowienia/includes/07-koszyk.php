<?php
/**
 * MODUŁ 07: Koszyk – konfigurator
 *
 * W menu admina pojawia się pozycja "Koszyk", w której ustawiasz:
 * - obrazek koszyka (z biblioteki mediów; bez obrazka jest domyślna ikona),
 * - nazwę koszyka,
 * - czy pokazywać obrazek + nazwę, czy tylko obrazek,
 * - czy pokazywać ilość produktów i wartość koszyka,
 * - czy zastąpić pozycję menu prowadzącą do koszyka,
 * - czy włączyć pływający koszyk (opcjonalnie tylko na telefonach) i po której stronie.
 *
 * Koszyk możesz też wstawić w dowolne miejsce shortcodem [koszyk].
 * Liczniki odświeżają się same po dodaniu produktu przez AJAX.
 * Jeśli masz już inną wtyczkę / kod z koszykiem w menu / pływającym koszykiem – wyłącz go.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 0. USTAWIENIA
 * ============================================================ */
function rzd_koszyk_defaults() {
	return array(
		'image_id'          => 0,
		'name'              => 'Koszyk',
		'display'           => 'both',   // both = obrazek + nazwa, image = tylko obrazek
		'show_qty'          => 1,
		'show_total'        => 0,
		'menu_replace'      => 1,
		'float_enabled'     => 0,
		'float_mobile_only' => 0,
		'float_pos'         => 'right',
		'mobile_enabled'    => 0,
		'mobile_breakpoint' => 782,
		'mobile_logo_sel'   => '',
		'mobile_menu_sel'   => '',
		'added_popup'       => 1,
		'list_url'          => '',
		// strona koszyka – pusty koszyk i przycisk powrotu.
		'empty_text'        => 'Twój koszyk jest obecnie pusty!',
		'empty_icon'        => 'default', // default = smutna buźka WooCommerce | none | image
		'empty_icon_id'     => 0,
		'empty_icon_size'   => 96,
		'empty_icon_full'   => 0, // ikonka na całą szerokość (wysokość = „Wielkość ikonki”)
		'back_text'         => 'Wróć do listy produktów',
		'back_center'       => 1,
	);
}

function rzd_koszyk_back_text() {
	$s = rzd_koszyk_get_settings();
	return '' !== trim( (string) $s['back_text'] ) ? $s['back_text'] : 'Wróć do listy produktów';
}

function rzd_koszyk_get_settings() {
	$s = get_option( 'kc_settings', array() );
	$s = wp_parse_args( is_array( $s ) ? $s : array(), rzd_koszyk_defaults() );
	if ( '' === trim( (string) $s['name'] ) ) {
		$s['name'] = 'Koszyk';
	}
	return $s;
}

/* ============================================================
 * 1. WYGLĄD KOSZYKA (jedna funkcja dla menu, pływającego i shortcode)
 * ============================================================ */
function rzd_koszyk_image_html( $s ) {
	$id = (int) $s['image_id'];
	if ( $id && wp_attachment_is_image( $id ) ) {
		return wp_get_attachment_image( $id, array( 64, 64 ), false, array( 'class' => 'kc-img', 'alt' => '' ) );
	}
	// domyślna ikona koszyka
	return '<svg class="kc-img kc-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg>';
}

/**
 * kwota przy ikonie koszyka = łącznie do zapłaty (produkty +
 * opakowania i inne opłaty + dostawa − rabat), tak jak „Szacowana łączna
 * kwota” w koszyku. Dostawa nieznana (brak miejscowości/terminu) = bez niej.
 * Koszyk przeliczany raz na żądanie i tylko, gdy nikt go jeszcze nie
 * przeliczył (na stronie koszyka/kasy WooCommerce robi to sam).
 */
function rzd_koszyk_cart_total_html() {
	$cart = WC()->cart;
	if ( ! $cart || $cart->is_empty() ) {
		return wc_price( 0 );
	}
	static $done = false;
	if ( ! $done && ! did_action( 'woocommerce_after_calculate_totals' ) && ! doing_action( 'woocommerce_before_calculate_totals' ) && ! doing_action( 'woocommerce_cart_calculate_fees' ) && did_action( 'wp_loaded' ) ) {
		$done = true;
		$cart->calculate_totals();
	}
	return wc_price( (float) $cart->get_total( 'edit' ) );
}

// $variant: 'menu' (w linii, np. w menu/shortcode) albo 'float' (pływający przycisk)
function rzd_koszyk_render( $variant = 'menu', $preview = false ) {
	$s = rzd_koszyk_get_settings();

	if ( $preview ) {
		$count = 3;
		$total = wc_price( 48 );
	} else {
		$has_cart = function_exists( 'WC' ) && WC()->cart;
		$count    = $has_cart ? (int) WC()->cart->get_cart_contents_count() : 0;
		$total    = $has_cart ? rzd_koszyk_cart_total_html() : ''; // do zapłaty, nie same produkty
	}
	$has = $count > 0;

	$classes = array( 'kc-cart', 'kc-' . $variant . '-cart' );
	if ( $has ) {
		$classes[] = 'kc-has-items';
	}
	if ( 'float' === $variant ) {
		$classes[] = ( 'left' === $s['float_pos'] ) ? 'kc-float-left' : 'kc-float-right';
		if ( ! empty( $s['float_mobile_only'] ) ) {
			$classes[] = 'kc-float-mobile';
		}
	}

	$is_link = in_array( $variant, array( 'float', 'mobile' ), true );
	$tag     = $is_link ? 'a' : 'span';
	$attrs   = $is_link ? ' href="' . esc_url( wc_get_cart_url() ) . '"' : '';

	ob_start();
	echo '<' . $tag . ' class="' . esc_attr( implode( ' ', $classes ) ) . '"' . $attrs . '>';
	echo '<span class="kc-icon">' . rzd_koszyk_image_html( $s );
	if ( $has ) {
		echo ! empty( $s['show_qty'] )
			? '<span class="kc-badge">' . (int) $count . '</span>'
			: '<span class="kc-dot"></span>'; // sam znacznik, że w koszyku coś jest
	}
	echo '</span>';

	if ( 'both' === $s['display'] ) {
		echo '<span class="kc-name">' . esc_html( $s['name'] ) . '</span>';
	} else {
		echo '<span class="screen-reader-text">' . esc_html( $s['name'] ) . '</span>';
	}
	if ( ! empty( $s['show_total'] ) ) {
		echo '<span class="kc-total">' . wp_kses_post( $total ) . '</span>';
	}
	echo '</' . $tag . '>';
	return ob_get_clean();
}

function rzd_koszyk_css() {
	$s = rzd_koszyk_get_settings();
	?>
	<style>
		.kc-cart{display:inline-flex;align-items:center;gap:8px;line-height:1;vertical-align:middle}
		.kc-icon{position:relative;display:inline-flex}
		.kc-img{width:28px;height:28px;object-fit:contain;display:block}
		.kc-badge{position:absolute;top:-8px;right:-10px;min-width:18px;height:18px;padding:0 5px;border-radius:9px;background:#d63638;color:#fff;font-size:11px;line-height:18px;text-align:center;font-weight:700;box-sizing:border-box}
		.kc-dot{position:absolute;top:-3px;right:-4px;width:10px;height:10px;border-radius:50%;background:#d63638}
		.kc-name,.kc-total{font-weight:600;white-space:nowrap}
		.kc-float-cart,.kc-float-cart:hover,.kc-float-cart:focus{position:fixed;bottom:18px;z-index:9998;padding:12px 16px;border-radius:32px;background:#fff !important;color:#222 !important;text-decoration:none !important;box-shadow:0 4px 16px rgba(0,0,0,.3)}
		.kc-float-cart .kc-name,.kc-float-cart .kc-total,.kc-float-cart .kc-total *{color:#222 !important}
		.kc-float-right{right:18px}
		.kc-float-left{left:18px}
		@media (min-width:783px){.kc-float-mobile{display:none !important}}
		.kc-preview .kc-float-cart{position:static;display:inline-flex}
		.kc-mobile-wrap{display:none;margin-left:auto;margin-right:auto;align-items:center;flex:0 0 auto;width:max-content;max-width:100%}
		.kc-mobile-cart,.kc-mobile-cart:hover,.kc-mobile-cart:focus{color:inherit;text-decoration:none}
		<?php if ( ! empty( $s['mobile_enabled'] ) ) : ?>
		@media (max-width: <?php echo (int) $s['mobile_breakpoint']; ?>px){
			.kc-mobile-wrap.kc-placed{display:flex}
		}
		@media (max-width: <?php echo (int) $s['mobile_breakpoint']; ?>px){
			li:has(> a .kc-menu-cart),li:has(> .kc-menu-cart){display:none !important}
		}
		<?php endif; ?>
		/* Wygląd okienka "Dodano do koszyka": moduł 15 → rzd_popup_css() */
	</style>
	<?php
}

/* ============================================================
 * 2. WSTAWIANIE: menu, pływający koszyk, shortcode, odświeżanie
 * ============================================================ */
add_action( 'wp_head', 'rzd_koszyk_css' );

// Pozycja menu prowadząca do koszyka → koszyk z obrazkiem/nazwą/licznikiem
add_filter( 'nav_menu_item_title', function ( $title, $item, $args = null, $depth = 0 ) {
	$s = rzd_koszyk_get_settings();
	if ( is_admin() || empty( $s['menu_replace'] ) || ! function_exists( 'wc_get_page_id' ) ) {
		return $title;
	}
	$cart_page = (int) wc_get_page_id( 'cart' );
	$is_cart   = ( 'page' === $item->object && (int) $item->object_id === $cart_page )
		|| ( ! empty( $item->url ) && untrailingslashit( $item->url ) === untrailingslashit( wc_get_cart_url() ) );
	return $is_cart ? rzd_koszyk_render( 'menu' ) : $title;
}, 10, 4 );

// Pływający koszyk (nie pokazujemy go na stronie koszyka i kasy)
add_action( 'wp_footer', function () {
	$s = rzd_koszyk_get_settings();
	if ( is_admin() || empty( $s['float_enabled'] ) ) {
		return;
	}
	if ( function_exists( 'is_cart' ) && ( is_cart() || is_checkout() ) ) {
		return;
	}
	echo rzd_koszyk_render( 'float' );
} );

add_shortcode( 'koszyk', function () {
	return rzd_koszyk_render( 'menu' );
} );

// Po dodaniu do koszyka przez AJAX odśwież liczniki
add_filter( 'woocommerce_add_to_cart_fragments', function ( $fragments ) {
	$s = rzd_koszyk_get_settings();
	$fragments['span.kc-menu-cart'] = rzd_koszyk_render( 'menu' );
	if ( ! empty( $s['float_enabled'] ) ) {
		$fragments['a.kc-float-cart'] = rzd_koszyk_render( 'float' );
	}
	if ( ! empty( $s['mobile_enabled'] ) ) {
		$fragments['a.kc-mobile-cart'] = rzd_koszyk_render( 'mobile' );
	}
	if ( ! empty( $s['added_popup'] ) ) {
		$fragments['div.kc-added-data'] = rzd_koszyk_added_payload_html();
	}
	return $fragments;
} );

/* ============================================================
 * 3. ZAPIS USTAWIEŃ (Panel restauracji → Sklep → Koszyk, moduł 34; do 2.45.0 strona kokpitu)
 * ============================================================ */
/** Zapis z tablicy kluczy jak w opcji kc_settings (bez prefiksu). Zwraca zapisane ustawienia. */
function rzd_koszyk_save( $p ) {
	$p   = is_array( $p ) ? $p : array();
	$img = function ( $k ) use ( $p ) {
		$id = isset( $p[ $k ] ) ? absint( $p[ $k ] ) : 0;
		return $id && wp_attachment_is_image( $id ) ? $id : 0;
	};
	$txt = function ( $k, $def ) use ( $p ) {
		return isset( $p[ $k ] ) && '' !== trim( (string) $p[ $k ] ) ? sanitize_text_field( (string) $p[ $k ] ) : $def;
	};
	$on  = function ( $k ) use ( $p ) {
		return empty( $p[ $k ] ) ? 0 : 1;
	};
	$empty_icon_id = $img( 'empty_icon_id' );
	$empty_icon    = isset( $p['empty_icon'] ) && in_array( $p['empty_icon'], array( 'default', 'none', 'image' ), true ) ? $p['empty_icon'] : 'default';
	if ( 'image' === $empty_icon && ! $empty_icon_id ) {
		$empty_icon = 'default';
	}
	$bp = isset( $p['mobile_breakpoint'] ) ? absint( $p['mobile_breakpoint'] ) : 0;
	update_option( 'kc_settings', array(
		'image_id'          => $img( 'image_id' ),
		'name'              => $txt( 'name', 'Koszyk' ),
		'display'           => ( isset( $p['display'] ) && 'image' === $p['display'] ) ? 'image' : 'both',
		'show_qty'          => $on( 'show_qty' ),
		'show_total'        => $on( 'show_total' ),
		'menu_replace'      => $on( 'menu_replace' ),
		'float_enabled'     => $on( 'float_enabled' ),
		'float_mobile_only' => $on( 'float_mobile_only' ),
		'float_pos'         => ( isset( $p['float_pos'] ) && 'left' === $p['float_pos'] ) ? 'left' : 'right',
		'mobile_enabled'    => $on( 'mobile_enabled' ),
		'mobile_breakpoint' => $bp >= 320 ? min( 1400, $bp ) : 782,
		'mobile_logo_sel'   => isset( $p['mobile_logo_sel'] ) ? sanitize_text_field( (string) $p['mobile_logo_sel'] ) : '',
		'mobile_menu_sel'   => isset( $p['mobile_menu_sel'] ) ? sanitize_text_field( (string) $p['mobile_menu_sel'] ) : '',
		'added_popup'       => $on( 'added_popup' ),
		'list_url'          => isset( $p['list_url'] ) ? esc_url_raw( trim( (string) $p['list_url'] ) ) : '',
		'empty_text'        => $txt( 'empty_text', 'Twój koszyk jest obecnie pusty!' ),
		'empty_icon'        => $empty_icon,
		'empty_icon_id'     => $empty_icon_id,
		'empty_icon_size'   => isset( $p['empty_icon_size'] ) && '' !== (string) $p['empty_icon_size'] ? max( 24, min( 400, absint( $p['empty_icon_size'] ) ) ) : 96,
		'empty_icon_full'   => $on( 'empty_icon_full' ),
		'back_text'         => $txt( 'back_text', 'Wróć do listy produktów' ),
		'back_center'       => $on( 'back_center' ),
	), false );
	return rzd_koszyk_get_settings();
}

/** Podgląd zapisanych ustawień (menu i pływający) – osobny dokument do <iframe> w panelu. */
function rzd_koszyk_preview_doc() {
	ob_start();
	rzd_koszyk_css();
	$css = ob_get_clean();
	return '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">' . $css
		. '<style>body{margin:0;padding:16px;font:15px/1.4 Lato,sans-serif;color:#2A2522;background:#fff}p{margin:0 0 8px;color:#6E645C;font-size:13px}.box{margin:0 0 18px}.screen-reader-text{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0,0,0,0)}</style></head><body class="kc-preview">'
		. '<div class="box"><p>W menu / shortcode [koszyk]:</p>' . rzd_koszyk_render( 'menu', true ) . '</div>'
		. '<div class="box"><p>Pływający:</p>' . rzd_koszyk_render( 'float', true ) . '</div></body></html>';
}

/* ============================================================
 * KOSZYK: stały przycisk powrotu + pusty koszyk bez "nowości"
 * ============================================================
 * "woocommerce_before_cart" wykonuje się ZAWSZE na stronie koszyka – zarówno
 * gdy są w nim produkty, jak i gdy jest pusty – więc to tu wstawiamy przycisk
 * powrotu, żeby był widoczny w każdym przypadku, a nie tylko przy pustym
 * koszyku.
 */
function rzd_koszyk_back_to_shop_url() {
	$s = rzd_koszyk_get_settings();
	if ( ! empty( $s['list_url'] ) ) {
		return esc_url( $s['list_url'] );
	}

	// Bez wypełnionego pola "Adres strony z listą produktów" wracaliśmy na
	// domyślną stronę sklepu WooCommerce – a to prawie nigdy nie jest ta
	// sama strona, na której faktycznie jest lista zamówień (shortcode
	// [lista_zamowien]), więc klient trafiał w przypadkowe miejsce. Zanim
	// wrócimy do sklepu WooCommerce, spróbujmy najpierw znaleźć stronę
	// z tym shortcode'em i skierować tam.
	static $cached = null;
	if ( null === $cached ) {
		// Tylko "page" (nie "post") – strona z listą produktów restauracji to
		// prawie zawsze zwykła podstrona, nie wpis na blogu; ORDER BY ID ASC
		// daje przewidywalny, powtarzalny wynik (ta sama strona za każdym
		// razem), zamiast zależeć od niejawnej "trafności" wyszukiwania
		// WordPressa, gdy shortcode występuje na więcej niż jednej stronie.
		$found  = get_posts( array(
			'post_type'      => array( 'page' ),
			'post_status'    => 'publish',
			'posts_per_page' => 1,
			'orderby'        => 'ID',
			'order'          => 'ASC',
			's'              => '[lista_zamowien',
			'fields'         => 'ids',
		) );
		$cached = $found ? get_permalink( $found[0] ) : wc_get_page_permalink( 'shop' );
	}
	return esc_url( $cached );
}

add_action( 'woocommerce_before_cart', function () {
	echo '<p class="kc-back-to-shop"><a class="button wc-backward" href="' . rzd_koszyk_back_to_shop_url() . '">' . esc_html( rzd_koszyk_back_text() ) . '</a></p>';
}, 5 );

// Sam komunikat pustego koszyka: bez przycisku (jest już powyżej, na stałe).
// napis i ikonka z ustawień Koszyka.
add_filter( 'wc_empty_cart_message', function () {
	$s   = rzd_koszyk_get_settings();
	$img = ( 'image' === $s['empty_icon'] && $s['empty_icon_id'] ) ? '<span class="kc-empty-img">' . wp_get_attachment_image( (int) $s['empty_icon_id'], 'medium', false, array( 'alt' => '' ) ) . '</span>' : '';
	return $img . '<p class="cart-empty woocommerce-info">' . esc_html( $s['empty_text'] ) . '</p>';
} );

/**
 * wygląd pustego koszyka (blokowego i klasycznego) i przycisku powrotu.
 * Blok „Pusty koszyk” rysuje buźkę jako ::before nagłówka (maska SVG).
 */
add_action( 'wp_head', function () {
	if ( ! function_exists( 'is_cart' ) || ( ! is_cart() && ! is_checkout() ) ) {
		return;
	}
	$s  = rzd_koszyk_get_settings();
	$sz = max( 24, min( 400, (int) $s['empty_icon_size'] ) );
	$t  = '.wc-block-cart__empty-cart__title.with-empty-cart-icon::before';
	echo '<style id="kc-empty-css">';
	if ( ! empty( $s['back_center'] ) ) {
		echo '.kc-back-to-shop{text-align:center}';
	}
	echo '.wc-block-cart__empty-cart__title,.cart-empty.woocommerce-info{text-align:center}';
	// pozycje koszyka blokowego na telefonie – czytelny układ:
	// [zdjęcie] | nazwa (wartość pozycji w prawym górnym rogu), pod spodem
	// cena (przekreślona + nowa), plakietka „Oszczędzasz…” w osobnej linii,
	// wybrane modyfikacje, a na dole licznik z koszem obok siebie.
	echo '@media (max-width:700px){'
		. 'body.woocommerce-cart table.wc-block-cart-items,body.woocommerce-cart table.wc-block-cart-items tbody{display:block!important;width:100%!important}'
		. 'body.woocommerce-cart .wc-block-cart-items__header{display:none!important}'
		. 'body.woocommerce-cart .wc-block-cart-items__row{position:relative;display:grid!important;grid-template-columns:64px minmax(0,1fr);column-gap:12px;align-items:start;width:100%;box-sizing:border-box;padding:14px 0!important}'
		. 'body.woocommerce-cart .wc-block-cart-items__row>td{display:block!important;padding:0!important;min-width:0;border:0!important}'
		. 'body.woocommerce-cart .wc-block-cart-item__image{grid-column:1;grid-row:1;width:64px!important}'
		. 'body.woocommerce-cart .wc-block-cart-item__image img{width:64px!important;height:64px!important;object-fit:cover;border-radius:8px}'
		. 'body.woocommerce-cart .wc-block-cart-item__product{grid-column:2;grid-row:1}'
		. 'body.woocommerce-cart .wc-block-cart-item__wrap{display:flex;flex-direction:column;align-items:flex-start;gap:4px}'
		. 'body.woocommerce-cart .wc-block-components-product-name{display:block;padding-right:84px;line-height:1.3}'
		. 'body.woocommerce-cart .wc-block-cart-item__total{position:absolute;top:14px;right:0;text-align:right;white-space:nowrap;font-weight:600}'
		. 'body.woocommerce-cart .wc-block-cart-item__total .wc-block-components-sale-badge{display:none!important}'
		. 'body.woocommerce-cart .wc-block-cart-item__prices{display:block;line-height:1.4}'
		. 'body.woocommerce-cart .wc-block-cart-item__prices .wc-block-components-product-price{display:flex;flex-wrap:wrap;align-items:baseline;gap:2px 8px}'
		. 'body.woocommerce-cart .wc-block-cart-item__prices del{opacity:.6}'
		. 'body.woocommerce-cart .wc-block-components-sale-badge{position:static!important;display:inline-block;margin:0!important;padding:1px 8px!important;border-radius:10px;font-size:12px!important;line-height:1.5;white-space:nowrap}'
		. 'body.woocommerce-cart .wc-block-components-product-metadata{font-size:13px;line-height:1.45;margin:2px 0 0!important;overflow-wrap:anywhere}'
		. 'body.woocommerce-cart .wc-block-cart-item__quantity{display:flex!important;align-items:center;gap:12px;flex-wrap:nowrap;margin-top:8px}'
		. 'body.woocommerce-cart .wc-block-components-quantity-selector{width:112px!important;min-width:112px;max-width:112px;margin:0!important}'
		. 'body.woocommerce-cart .wc-block-cart-item__remove-link{margin:0!important;flex:0 0 auto}'
		. '}';
	if ( 'none' === $s['empty_icon'] ) {
		echo $t . '{display:none!important}'; // phpcs:ignore
	} elseif ( 'image' === $s['empty_icon'] && $s['empty_icon_id'] ) {
		$url = wp_get_attachment_image_url( (int) $s['empty_icon_id'], 'medium' );
		echo $t . '{-webkit-mask-image:none!important;mask-image:none!important;background:url(' . esc_url( $url ) . ') center/contain no-repeat!important;opacity:1!important;width:' . $sz . 'px!important;height:' . $sz . 'px!important}'; // phpcs:ignore
		echo '.kc-empty-img{display:block;text-align:center;margin:0 auto 14px}.kc-empty-img img{width:' . $sz . 'px;height:' . $sz . 'px;object-fit:contain}'; // phpcs:ignore
	} else {
		echo $t . '{width:' . $sz . 'px!important;height:' . $sz . 'px!important;-webkit-mask-size:contain!important;mask-size:contain!important}'; // phpcs:ignore
	}
	if ( ! empty( $s['empty_icon_full'] ) && 'none' !== $s['empty_icon'] ) { // nagłówek i ikonka na całą szerokość
		echo '.wp-block-woocommerce-empty-cart-block .wc-block-cart__empty-cart__title{width:100%!important;max-width:none!important;margin-left:0!important;margin-right:0!important}'; // phpcs:ignore
		echo $t . '{width:100%!important;height:' . $sz . 'px!important;-webkit-mask-size:contain!important;mask-size:contain!important;background-size:contain!important}'; // phpcs:ignore
		echo '.kc-empty-img img{width:100%!important;height:' . $sz . 'px!important}'; // phpcs:ignore
	}
	echo '</style>';
} );

// Motywy różnie doklejają dodatkową zawartość do pustego koszyka (np. "Nowości")
// pod hookiem "woocommerce_cart_is_empty" – nie znamy nazwy funkcji Twojego
// motywu, więc zamiast zgadywać, czyścimy CAŁY ten hook tuż przed
// wyrenderowaniem strony koszyka.
add_action( 'wp', function () {
	if ( function_exists( 'is_cart' ) && is_cart() ) {
		remove_all_actions( 'woocommerce_cart_is_empty' );
	}
}, 20 );

/**
 * Jeżeli strona koszyka korzysta z NOWEGO koszyka blokowego (Gutenberg,
 * blok "Koszyk") zamiast starego kodu [woocommerce_cart], powyższe hooki
 * ("woocommerce_before_cart" i inne) w ogóle się nie wykonują – blok
 * renderuje się inaczej i ich nie używa. Dlatego przycisk powrotu wstawiamy
 * DODATKOWO przez JS, już po wczytaniu strony: to zadziała niezależnie od
 * tego, czy masz stary czy nowy (blokowy) koszyk – JS znajdzie kontener
 * koszyka na stronie i wstawi przycisk tuż przed nim, jeśli PHP go tam
 * jeszcze nie wstawił.
 */
add_action( 'wp_footer', function () {
	if ( ! function_exists( 'is_cart' ) || ! is_cart() ) {
		return;
	}
	?>
	<script>var rzdKcBack = <?php echo wp_json_encode( array( 'url' => rzd_koszyk_back_to_shop_url(), 'text' => rzd_koszyk_back_text(), 'emptyTxt' => rzd_koszyk_get_settings()['empty_text'] ) ); ?>;</script>
	<?php echo rzd_js_tag( 'assets/js/rzd-koszyk-powrot.js' ); // phpcs:ignore ?>
	<?php
}, 5 );

/**
 * TO SAMO na stronie płatności: przycisk powrotu do sklepu ma być dostępny
 * "nawet tuż przed płatnością", nie tylko w koszyku. Klasyczna strona kasy
 * dostaje przycisk przez PHP (hook "woocommerce_before_checkout_form"),
 * a blokowa (Gutenberg) – tak jak w koszyku – przez JS w stopce, na wypadek
 * gdyby klasyczny hook się nie wykonał.
 */
add_action( 'woocommerce_before_checkout_form', function () {
	echo '<p class="kc-back-to-shop"><a class="button wc-backward" href="' . rzd_koszyk_back_to_shop_url() . '">' . esc_html( rzd_koszyk_back_text() ) . '</a></p>';
}, 5 );

add_action( 'wp_footer', function () {
	if ( ! function_exists( 'is_checkout' ) || ! is_checkout() || is_order_received_page() ) {
		return;
	}
	?>
	<script>var rzdKcBack = <?php echo wp_json_encode( array( 'url' => rzd_koszyk_back_to_shop_url(), 'text' => rzd_koszyk_back_text() ) ); ?>;</script>
	<?php echo rzd_js_tag( 'assets/js/rzd-kasa-powrot.js' ); // phpcs:ignore ?>
	<?php
}, 5 );


/* ============================================================
 * 4. KOSZYK NA TELEFONIE: w nagłówku, między logo a menu (burger)
 * ============================================================ */
function rzd_koszyk_default_logo_sel() {
	return '.custom-logo-link, .site-logo, .site-branding, .logo, #logo, a[rel="home"]';
}
function rzd_koszyk_default_menu_sel() {
	return '.menu-toggle, .navbar-toggler, .mobile-menu-toggle, .hamburger, .menu-btn, .nav-toggle, .elementor-menu-toggle, .mobile-menu-button, button[aria-controls*="menu"]';
}

add_action( 'wp_footer', function () {
	$s = rzd_koszyk_get_settings();
	if ( is_admin() || empty( $s['mobile_enabled'] ) ) {
		return;
	}
	$logo = '' !== trim( (string) $s['mobile_logo_sel'] ) ? $s['mobile_logo_sel'] : rzd_koszyk_default_logo_sel();
	$menu = '' !== trim( (string) $s['mobile_menu_sel'] ) ? $s['mobile_menu_sel'] : rzd_koszyk_default_menu_sel();

	echo '<div class="kc-mobile-wrap">' . rzd_koszyk_render( 'mobile' ) . '</div>';
	?>
	<script>var rzdKcMobile = <?php echo wp_json_encode( array( 'logo' => $logo, 'menu' => $menu ) ); ?>;</script>
	<?php echo rzd_js_tag( 'assets/js/rzd-koszyk-telefon.js' ); // phpcs:ignore ?>
	<?php
}, 30 );

/* ============================================================
 * 5. OKIENKO PO DODANIU DO KOSZYKA
 * ============================================================ */
function rzd_koszyk_list_url() {
	$s = rzd_koszyk_get_settings();
	return $s['list_url'] ? esc_url_raw( $s['list_url'] ) : '';
}

// Zapamiętujemy, co klient dodał (produkt + jego dodatki), żeby pokazać w okienku
add_action( 'woocommerce_add_to_cart', 'rzd_koszyk_record_added', 5, 6 );
function rzd_koszyk_record_added( $cart_item_key, $product_id, $quantity, $variation_id, $variation, $cart_item_data ) {
	$s = rzd_koszyk_get_settings();
	if ( empty( $s['added_popup'] ) || ! function_exists( 'WC' ) || ! WC()->session ) {
		return;
	}
	$p = wc_get_product( $variation_id ? $variation_id : $product_id );
	if ( ! $p ) {
		return;
	}
	WC()->session->set( 'kc_added', array( 'name' => $p->get_name(), 'qty' => (int) $quantity ) );
}

// Standardowy komunikat WooCommerce jest zbędny, gdy działa okienko
add_filter( 'wc_add_to_cart_message_html', function ( $message ) {
	$s = rzd_koszyk_get_settings();
	return empty( $s['added_popup'] ) ? $message : '';
} );

// Dane dla okienka (odczyt kasuje zapis w sesji, więc okienko pokaże się raz)
function rzd_koszyk_added_payload_html() {
	$data = ( function_exists( 'WC' ) && WC()->session ) ? WC()->session->get( 'kc_added' ) : null;
	if ( $data && WC()->session ) {
		WC()->session->set( 'kc_added', null );
		$data = apply_filters( 'rzd_koszyk_added_data', $data ); // np. linijka paska dostawy (moduł 32)
	}
	return '<div class="kc-added-data" hidden data-json="' . esc_attr( wp_json_encode( $data ? $data : null ) ) . '"></div>';
}

add_action( 'wp_footer', function () {
	$s = rzd_koszyk_get_settings();
	if ( is_admin() || empty( $s['added_popup'] ) ) {
		return;
	}
	$cfg = array( 'listUrl' => rzd_koszyk_list_url() );
	?>
	<div id="kc-added" hidden>
		<div class="kc-added-panel" role="dialog" aria-modal="true">
			<h3>Dodano do koszyka</h3>
			<div class="kc-added-list"></div>
			<div class="kc-added-actions">
				<div class="kc-added-act"><button type="button" class="kc-added-continue">Kontynuuj zakupy</button></div>
				<div class="kc-added-act"><a class="kc-added-cart" href="<?php echo esc_url( wc_get_cart_url() ); ?>">Przejdź do koszyka</a></div>
			</div>
		</div>
	</div>
	<?php echo rzd_koszyk_added_payload_html(); ?>
	<script>var kcAddedCfg = <?php echo wp_json_encode( $cfg ); ?>;</script>
	<?php echo rzd_js_tag( 'assets/js/rzd-dodano.js' ); // phpcs:ignore ?>
	<?php
}, 40 );

/* ============================================================
 * 6. CZYSZCZENIE KOSZYKA PO ZŁOŻENIU ZAMÓWIENIA
 * ============================================================
 * WooCommerce sam czyści koszyk na stronie "Zamówienie przyjęte", ALE
 * tylko wtedy, gdy zamówienie ma już status inny niż "Oczekujące na
 * płatność". Przy płatnościach online potwierdzenie z bramki (webhook)
 * często dochodzi PÓŹNIEJ niż klient wraca na stronę podsumowania – wtedy
 * zamówienie jest jeszcze "pending", WooCommerce koszyka nie rusza i klient
 * może kupić to samo drugi raz.
 *
 * Zasada tutaj: skoro klient doszedł do strony podsumowania SWOJEGO
 * zamówienia (poprawny klucz zamówienia w adresie), koszyk jest pusty,
 * niezależnie od statusu. Jeśli płatność się nie udała, klient opłaci
 * TO SAMO zamówienie linkiem "Zapłać" (z e-maila / z Moje konto), a nie
 * przez ponowne złożenie koszyka. Opróżnienie koszyka zwalnia też termin
 * dostawy (hook woocommerce_cart_emptied w module 06).
 */
add_action( 'template_redirect', 'rzd_koszyk_clear_cart_after_order', 20 );
function rzd_koszyk_clear_cart_after_order() {
	if ( ! function_exists( 'is_order_received_page' ) || ! is_order_received_page() ) {
		return;
	}
	if ( ! function_exists( 'WC' ) || ! WC()->cart || WC()->cart->is_empty() ) {
		return;
	}
	global $wp;
	$order_id  = isset( $wp->query_vars['order-received'] ) ? absint( $wp->query_vars['order-received'] ) : 0;
	$order_key = isset( $_GET['key'] ) ? wc_clean( wp_unslash( $_GET['key'] ) ) : '';
	if ( ! $order_id || '' === $order_key ) {
		return;
	}
	$order = wc_get_order( $order_id );
	if ( ! $order || ! hash_equals( (string) $order->get_order_key(), (string) $order_key ) ) {
		return; // obcy lub zmyślony adres – nie ruszamy koszyka
	}
	WC()->cart->empty_cart();
	if ( WC()->session ) {
		WC()->session->set( 'order_awaiting_payment', null );
	}
}
