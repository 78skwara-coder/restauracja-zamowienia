<?php
/**
 * Moduł 25 – DOSTĘP I UPRAWNIENIA
 *
 * Model: RBAC (Role-Based Access Control). Każda kolumna konfiguratora (moduł 26,
 * Użytkownicy → Uprawnienia) = jedno uprawnienie WordPressa (capability) rzd_p_*;
 * zapis konfiguratora dopisuje / zdejmuje je z ról (rzd_roles_sync). Ekrany
 * i akcje sprawdzają UPRAWNIENIE (rzd_can), nigdy nazwę roli.
 *
 * Role startowe (slug → nazwa, nazwy edytowalne):
 *   administrator      – zawsze wszystko (zablokowany w konfiguratorze),
 *   rzd_role_boss      – Szef: sklep + wszystko, bez rzeczy technicznych WP,
 *   shop_manager       – Manager (rola WooCommerce „Kierownik sklepu”),
 *   rzd_role_chef      – Szef kuchni, rzd_role_floor – Kierownik sali,
 *   rzd_role_courier   – Kurier, rzd_menu_editor – Redaktor menu (moduł 22),
 *   rzd_role_c_*       – role dodane w konfiguratorze.
 * UWAGA: slug roli działa w WP także jak uprawnienie – stąd role „rzd_role_*”
 * i uprawnienia „rzd_p_*” (bez kolizji nazw).
 *
 * „Panel WP” = uprawnienia roli WooCommerce shop_manager (kopiowane i
 * odświeżane przy każdej wersji wtyczki – WooCommerce dopisuje je przy
 * aktualizacjach). Szef nie może tworzyć / edytować kont Administratora.
 *
 * Kuchnia i Edycja menu – tylko zalogowani. Kurier – konto (30 dni logowania)
 * albo AWARYJNY PIN (domyślnie wyłączony, limit 5 prób / 15 min).
 * Konta „tylko obsługa” (bez Panelu WP): bez kokpitu i paska admina,
 * po logowaniu prosto na swój ekran; z Kuchnią – 90 dni logowania.
 * Akcje Kuchni/Kuriera (moduł 13) – nonce (CSRF).
 */

defined( 'ABSPATH' ) || exit;

/* ============================================================
 * 1. KATALOG UPRAWNIEŃ I ROLE STARTOWE
 * ============================================================ */

/** Kolumny konfiguratora: klucz => [ etykieta, capability, opis, wymaga Panelu WP ]. */
function rzd_perm_catalog() {
	return array(
		'shop'      => array( 'Panel WP', 'rzd_p_shop', 'Kokpit WordPressa: zamówienia, produkty, klienci, zestawy, dodatki (uprawnienia kierownika sklepu WooCommerce).', false ),
		'settings'  => array( 'Ustawienia wtyczki', 'rzd_p_settings', 'Kalendarz dostaw, miejscowości, koszyk, wygląd listy oraz ⚙ w Kuchni (auto przygotowanie, dni wstecz).', true ),
		'reports'   => array( 'Raporty (CSV)', 'rzd_p_reports', 'Raporty sprzedaży i eksport CSV.', true ),
		'dashboard' => array( '📊 Dashboard', 'rzd_p_dashboard', 'Zakładka ze statystykami sprzedaży w Kuchni.', false ),
		'orders'    => array( 'Zamówienia', 'rzd_p_orders', 'Zakładka Zamówienia w Kuchni (nadchodzące, do przeplanowania).', false ),
		'kitchen'   => array( 'Kuchnia', 'rzd_p_kitchen', 'Zakładka Kuchnia (co przygotować, „Przygotowane”).', false ),
		'packing'   => array( 'Pakowanie', 'rzd_p_packing', 'Zakładka Pakowanie („Przygotowane”, „Spakowane”).', false ),
		'planning'  => array( 'Planowanie', 'rzd_p_planning', 'Zakładka Planowanie (kolejność i godziny dostaw).', false ),
		'history'   => array( 'Historia', 'rzd_p_history', 'Zakładka Historia (zamówienia z ostatnich dni, też anulowane).', false ),
		'courier'   => array( 'Kurier', 'rzd_p_courier', 'Ekran kuriera („Dostarczone”).', false ),
		'menu'      => array( 'Edycja menu', 'rzd_edit_menu', 'Strona edycji menu z telefonu (zdjęcia, ceny, opisy, zestaw dnia).', false ),
		'change'    => array( 'Nowy termin i anulowanie', 'rzd_p_change', 'Zmiana terminu dostawy i anulowanie zamówień klienta.', false ),
		'staff'     => array( 'Uprawnienia i konta pracowników', 'rzd_p_staff', 'Ten konfigurator oraz zakładanie i edycja kont pracowników (bez kont Administratora).', true ),
	);
}

function rzd_perm_cap( $key ) {
	$c = rzd_perm_catalog();
	return isset( $c[ $key ] ) ? $c[ $key ][1] : '';
}

/** Widoki Kuchni => uprawnienie (kolejność zakładek). */
function rzd_kitchen_view_perms() {
	return array( 'zamowienia' => 'orders', 'kuchnia' => 'kitchen', 'pakowanie' => 'packing', 'planowanie' => 'planning', 'historia' => 'history', 'dashboard' => 'dashboard' );
}

function rzd_roles_default() {
	$all = array_keys( rzd_perm_catalog() );
	return array(
		'rzd_role_boss'    => array( 'name' => 'Szef', 'builtin' => 1, 'perms' => $all ),
		'shop_manager'     => array( 'name' => 'Manager', 'builtin' => 1, 'perms' => array_values( array_diff( $all, array( 'dashboard', 'staff' ) ) ) ),
		'rzd_role_chef'    => array( 'name' => 'Szef kuchni', 'builtin' => 1, 'perms' => array( 'orders', 'kitchen', 'packing' ) ),
		'rzd_role_floor'   => array( 'name' => 'Kierownik sali', 'builtin' => 1, 'perms' => array( 'orders', 'kitchen', 'packing' ) ),
		'rzd_role_courier' => array( 'name' => 'Kurier', 'builtin' => 1, 'perms' => array( 'courier' ) ),
		'rzd_menu_editor'  => array( 'name' => 'Redaktor menu', 'builtin' => 1, 'perms' => array( 'menu' ) ),
	);
}

/** Konfiguracja: { roles: { slug: {name, builtin, perms[]} }, pin: { on, since } }. */
function rzd_roles_cfg() {
	if ( isset( $GLOBALS['rzd_roles_cfg_cache'] ) ) {
		return $GLOBALS['rzd_roles_cfg_cache'];
	}
	$c   = get_option( 'rzd_roles_cfg', array() );
	$c   = is_array( $c ) ? $c : array();
	$def = rzd_roles_default();
	$c['roles'] = isset( $c['roles'] ) && is_array( $c['roles'] ) ? $c['roles'] : array();
	foreach ( $def as $slug => $r ) {
		if ( ! isset( $c['roles'][ $slug ] ) ) {
			$c['roles'][ $slug ] = $r; // brakująca rola wbudowana (pierwsze uruchomienie)
		}
		$c['roles'][ $slug ]['builtin'] = 1;
	}
	$c['pin'] = isset( $c['pin'] ) && is_array( $c['pin'] ) ? $c['pin'] + array( 'on' => 0, 'since' => '' ) : array( 'on' => 0, 'since' => '' );
	$GLOBALS['rzd_roles_cfg_cache'] = $c;
	return $c;
}

function rzd_roles_cfg_flush() {
	unset( $GLOBALS['rzd_roles_cfg_cache'] );
}

/** Zależności: „Ustawienia”, „Raporty”, „Konta pracowników” wymagają Panelu WP. */
function rzd_perms_normalize( $perms ) {
	$cat   = rzd_perm_catalog();
	$perms = array_values( array_unique( array_intersect( (array) $perms, array_keys( $cat ) ) ) );
	foreach ( $perms as $k ) {
		if ( $cat[ $k ][3] && ! in_array( 'shop', $perms, true ) ) {
			$perms[] = 'shop';
		}
	}
	return array_values( array_intersect( array_keys( $cat ), $perms ) ); // kolejność jak w katalogu
}

/* ============================================================
 * 2. SYNCHRONIZACJA Z ROLAMI WORDPRESSA
 * ============================================================ */
function rzd_staff_wp_caps() {
	return array( 'list_users', 'create_users', 'edit_users', 'promote_users', 'delete_users', 'remove_users' );
}

function rzd_roles_sync( $cfg = null ) {
	$cfg  = $cfg ? $cfg : rzd_roles_cfg();
	$cat  = rzd_perm_catalog();
	$caps = array();
	foreach ( $cat as $p ) {
		$caps[] = $p[1];
	}
	// Uprawnienia „Panelu WP” = rola WooCommerce shop_manager (bez naszych i bez 'read').
	$sm        = get_role( 'shop_manager' );
	$shop_caps = $sm ? array_keys( array_filter( (array) $sm->capabilities ) ) : array();
	$shop_caps = array_values( array_diff( $shop_caps, $caps, array( 'read' ) ) );
	$prev_shop = (array) get_option( 'rzd_shop_caps_copied', array() );
	$added     = (array) get_option( 'rzd_staff_caps_added', array() );

	$admin = get_role( 'administrator' );
	if ( $admin ) {
		foreach ( $caps as $c ) {
			$admin->add_cap( $c );
		}
	}
	foreach ( $cfg['roles'] as $slug => $r ) {
		$role = get_role( $slug );
		if ( ! $role ) {
			if ( 'shop_manager' === $slug ) {
				continue; // WooCommerce nieaktywny – nie tworzymy jego roli
			}
			$role = add_role( $slug, $r['name'], array( 'read' => true ) );
			if ( ! $role ) {
				continue;
			}
		}
		$perms = rzd_perms_normalize( $r['perms'] );
		if ( 'shop_manager' === $slug && ! in_array( 'shop', $perms, true ) ) {
			$perms[] = 'shop'; // Manager JEST rolą „Panelu WP”
		}
		foreach ( $cat as $k => $p ) {
			if ( in_array( $k, $perms, true ) ) {
				$role->add_cap( $p[1] );
			} else {
				$role->remove_cap( $p[1] );
			}
		}
		if ( 'shop_manager' !== $slug ) {
			if ( in_array( 'shop', $perms, true ) ) {
				foreach ( $shop_caps as $c ) {
					$role->add_cap( $c );
				}
				foreach ( array_diff( $prev_shop, $shop_caps ) as $c ) {
					$role->remove_cap( $c ); // WooCommerce zabrał je kierownikowi
				}
			} else {
				foreach ( array_unique( array_merge( $shop_caps, $prev_shop ) ) as $c ) {
					$role->remove_cap( $c );
				}
			}
		}
		// Konta pracowników: dopisujemy uprawnienia WP do użytkowników; zdejmujemy TYLKO te, które sami dodaliśmy.
		$mine = isset( $added[ $slug ] ) ? (array) $added[ $slug ] : array();
		if ( in_array( 'staff', $perms, true ) ) {
			foreach ( rzd_staff_wp_caps() as $c ) {
				if ( empty( $role->capabilities[ $c ] ) ) {
					$role->add_cap( $c );
					$mine[] = $c;
				}
			}
		} else {
			foreach ( $mine as $c ) {
				$role->remove_cap( $c );
			}
			$mine = array();
		}
		$added[ $slug ] = array_values( array_unique( $mine ) );
	}
	update_option( 'rzd_shop_caps_copied', $shop_caps, false );
	update_option( 'rzd_staff_caps_added', $added, false );
	update_option( 'rzd_roles_synced', defined( 'RZD_PLUGIN_VERSION' ) ? RZD_PLUGIN_VERSION : '1', true );
}

// Przy pierwszym uruchomieniu i po każdej aktualizacji wtyczki (WooCommerce mógł zmienić rolę kierownika).
add_action( 'init', function () {
	if ( get_option( 'rzd_roles_synced' ) === ( defined( 'RZD_PLUGIN_VERSION' ) ? RZD_PLUGIN_VERSION : '1' ) ) {
		return;
	}
	rzd_roles_sync();
	delete_option( 'kuchnia_pin' ); // PIN kuchni już nie istnieje (Kuchnia tylko przez konta)
}, 25 );

// Nazwy ról z konfiguratora (w tym „Kierownik sklepu” → „Manager”) – w pamięci, bez zapisu do bazy.
add_action( 'init', function () {
	$wr = function_exists( 'wp_roles' ) ? wp_roles() : null;
	if ( ! $wr ) {
		return;
	}
	foreach ( rzd_roles_cfg()['roles'] as $slug => $r ) {
		if ( isset( $wr->roles[ $slug ] ) && '' !== (string) $r['name'] ) {
			$wr->roles[ $slug ]['name'] = $r['name'];
			$wr->role_names[ $slug ]    = $r['name'];
		}
	}
}, 26 );

/* ============================================================
 * 3. SPRAWDZANIE UPRAWNIEŃ
 * ============================================================ */

/** Czy zalogowany (albo podany) użytkownik ma uprawnienie z konfiguratora. Administrator – zawsze. */
function rzd_can( $key, $user = null ) {
	$cap = rzd_perm_cap( $key );
	if ( ! $cap ) {
		return false;
	}
	if ( $user instanceof WP_User ) {
		return $user->exists() && ( user_can( $user, $cap ) || user_can( $user, 'manage_options' ) );
	}
	return is_user_logged_in() && ( current_user_can( $cap ) || current_user_can( 'manage_options' ) );
}

/** Zakładki Kuchni dostępne dla użytkownika (w kolejności). */
function rzd_kitchen_views( $user = null ) {
	$out = array();
	foreach ( rzd_kitchen_view_perms() as $view => $perm ) {
		if ( rzd_can( $perm, $user ) ) {
			$out[] = $view;
		}
	}
	return $out;
}

/** Wejście na ekran Kuchni = choć jedna zakładka. */
function rzd_kitchen_can( $user = null ) {
	return (bool) rzd_kitchen_views( $user );
}

/** Konto „tylko obsługa” – bez Panelu WP (i bez pisania wpisów), ale z czymś z wtyczki. */
function rzd_staff_only( $user = null ) {
	$user = $user instanceof WP_User ? $user : wp_get_current_user();
	if ( ! $user || ! $user->exists() || user_can( $user, 'manage_options' ) || user_can( $user, 'manage_woocommerce' ) || user_can( $user, 'edit_posts' ) ) {
		return false;
	}
	return rzd_kitchen_can( $user ) || rzd_can( 'courier', $user ) || rzd_can( 'menu', $user );
}

/**
 * Adres strony obsługi (Kuchnia, Kurier, Edycja). Zapamiętany przy pierwszym wejściu;
 * gdy jeszcze nie – szukamy opublikowanej strony z shortcodem i zapamiętujemy.
 */
function rzd_page_url_opt( $opt, $shortcode = '' ) {
	$id = (int) get_option( $opt );
	if ( ( ! $id || 'publish' !== get_post_status( $id ) ) && $shortcode ) {
		$found = get_posts( array( 'post_type' => 'page', 'post_status' => 'publish', 's' => '[' . $shortcode, 'numberposts' => 5, 'fields' => 'ids' ) );
		$id    = 0;
		foreach ( $found as $pid ) {
			if ( has_shortcode( (string) get_post_field( 'post_content', $pid ), $shortcode ) ) {
				$id = (int) $pid;
				update_option( $opt, $id, false );
				break;
			}
		}
	}
	return ( $id && 'publish' === get_post_status( $id ) ) ? get_permalink( $id ) : '';
}
function rzd_kitchen_page_url() {
	return rzd_page_url_opt( 'rzd_kuchnia_page_id', 'kuchnia_dashboard' );
}

/** Strona startowa konta obsługi: Kuchnia → Kurier → Edycja menu; '' = żadnej nie znaleziono. */
function rzd_staff_home( $user ) {
	if ( rzd_kitchen_can( $user ) && rzd_kitchen_page_url() ) {
		return rzd_kitchen_page_url();
	}
	if ( rzd_can( 'courier', $user ) && rzd_page_url_opt( 'rzd_kurier_page_id', 'kurier_dashboard' ) ) {
		return rzd_page_url_opt( 'rzd_kurier_page_id', 'kurier_dashboard' );
	}
	if ( rzd_can( 'menu', $user ) && rzd_page_url_opt( 'rzd_ed_page_id', 'edycja_produktow' ) ) {
		return rzd_page_url_opt( 'rzd_ed_page_id', 'edycja_produktow' );
	}
	return '';
}

/* ============================================================
 * 4. KONTA OBSŁUGI: bez kokpitu i paska admina, przekierowania
 * ============================================================ */
add_filter( 'show_admin_bar', function ( $show ) {
	return rzd_staff_only() ? false : $show;
}, 20 );

add_action( 'admin_init', function () {
	if ( wp_doing_ajax() || ! rzd_staff_only() ) {
		return;
	}
	$home = rzd_staff_home( wp_get_current_user() );
	wp_safe_redirect( '' !== $home ? $home : home_url( '/' ) );
	exit;
}, 5 );

// Nieznana strona obsługi – zostaje adres, z którego się logowano (np. formularz na stronie Kuchni).
add_filter( 'login_redirect', function ( $to, $requested, $user ) {
	$home = ( $user instanceof WP_User && rzd_staff_only( $user ) ) ? rzd_staff_home( $user ) : '';
	return '' !== $home ? $home : $to;
}, 30, 3 );
add_filter( 'woocommerce_login_redirect', function ( $to, $user ) {
	$home = ( $user instanceof WP_User && rzd_staff_only( $user ) ) ? rzd_staff_home( $user ) : '';
	return '' !== $home ? $home : $to;
}, 30, 2 );

// Kuchnia i Kurier: zapamiętany adres strony + nigdy z cache strony.
add_action( 'template_redirect', function () {
	if ( ! is_singular() ) {
		return;
	}
	$post = get_post();
	if ( ! $post ) {
		return;
	}
	$pages = array( 'kuchnia_dashboard' => 'rzd_kuchnia_page_id', 'kurier_dashboard' => 'rzd_kurier_page_id' );
	foreach ( $pages as $sc => $opt ) {
		if ( has_shortcode( $post->post_content, $sc ) ) {
			if ( ! defined( 'DONOTCACHEPAGE' ) ) {
				define( 'DONOTCACHEPAGE', true );
			}
			nocache_headers();
			if ( (int) get_option( $opt ) !== (int) $post->ID ) {
				update_option( $opt, (int) $post->ID, false );
			}
		}
	}
} );

/* „Zapamiętaj mnie”: konto obsługi z Kuchnią – 90 dni (tablet w kuchni),
 * sam Kurier – 30 dni (prywatny telefon gubi się częściej). Reszta – jak WordPress. */
add_filter( 'auth_cookie_expiration', function ( $length, $user_id, $remember ) {
	if ( ! $remember ) {
		return $length;
	}
	$user = get_userdata( $user_id );
	if ( ! $user || ! rzd_staff_only( $user ) ) {
		return $length;
	}
	if ( rzd_kitchen_can( $user ) ) {
		return max( (int) $length, 90 * DAY_IN_SECONDS );
	}
	if ( rzd_can( 'courier', $user ) ) {
		return max( (int) $length, 30 * DAY_IN_SECONDS );
	}
	return $length;
}, 20, 3 );

/** Formularz logowania WordPress dla ekranów obsługi, „Zapamiętaj mnie” zaznaczone. */
function rzd_staff_login_html( $title, $note = '' ) {
	return '<div class="rzd-staff-login" style="max-width:360px;margin:60px auto;padding:24px;border:2px solid #222;border-radius:12px;font-family:sans-serif;font-size:16px">'
		. '<h2 style="margin-top:0;text-align:center">' . esc_html( $title ) . '</h2>'
		. ( $note ? '<p style="color:#555">' . esc_html( $note ) . '</p>' : '' )
		. wp_login_form( array( 'echo' => false, 'redirect' => get_permalink(), 'remember' => true, 'value_remember' => true ) )
		. '</div>';
}

function rzd_no_access_html( $what ) {
	return '<p style="max-width:420px;margin:60px auto;font-family:sans-serif;font-size:16px">To konto nie ma dostępu do: ' . esc_html( $what ) . '. Poproś szefa o uprawnienie (Użytkownicy → Uprawnienia). <a href="' . esc_url( wp_logout_url( get_permalink() ) ) . '">Wyloguj</a></p>';
}

/* ============================================================
 * 5. KONTA PRACOWNIKÓW: nikt poza Administratorem nie tworzy ani nie
 *    edytuje kont Administratora (niezależnie od zabezpieczeń WooCommerce)
 * ============================================================ */
add_filter( 'editable_roles', function ( $roles ) {
	if ( ! current_user_can( 'manage_options' ) ) {
		unset( $roles['administrator'] );
	}
	return $roles;
}, 20 );

// WooCommerce pozwala kierownikowi edytować tylko klientów – z uprawnieniem „Konta pracowników” też role obsługi.
add_filter( 'woocommerce_shop_manager_editable_roles', function ( $roles ) {
	if ( current_user_can( 'rzd_p_staff' ) ) {
		$roles = array_merge( (array) $roles, array_keys( rzd_roles_cfg()['roles'] ), array( 'customer' ) );
		$roles = array_values( array_diff( array_unique( $roles ), array( 'administrator' ) ) );
	}
	return $roles;
} );

add_filter( 'map_meta_cap', function ( $caps, $cap, $user_id, $args ) {
	if ( ! in_array( $cap, array( 'edit_user', 'delete_user', 'promote_user', 'remove_user' ), true ) || empty( $args[0] ) || (int) $args[0] === (int) $user_id ) {
		return $caps;
	}
	if ( user_can( (int) $user_id, 'manage_options' ) ) {
		return $caps;
	}
	$target = get_userdata( (int) $args[0] );
	if ( $target && in_array( 'administrator', (array) $target->roles, true ) ) {
		$caps[] = 'do_not_allow';
	}
	return $caps;
}, 20, 4 );

/* ============================================================
 * 6. KURIER: awaryjny PIN (domyślnie wyłączony) i limit prób
 * ============================================================ */
function rzd_courier_pin_enabled() {
	$c = rzd_roles_cfg();
	return ! empty( $c['pin']['on'] ) && '' !== (string) get_option( 'kurier_pin', '' );
}

function rzd_pin_key( $scope ) {
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) $_SERVER['REMOTE_ADDR'] : '';
	return 'rzd_pin_' . md5( $scope . '|' . $ip );
}

/** Ile minut blokady zostało (0 = można próbować). */
function rzd_pin_locked( $scope ) {
	$d = get_transient( rzd_pin_key( $scope ) );
	if ( is_array( $d ) && ! empty( $d['until'] ) && $d['until'] > time() ) {
		return (int) ceil( ( $d['until'] - time() ) / 60 );
	}
	return 0;
}

function rzd_pin_fail( $scope ) {
	$k = rzd_pin_key( $scope );
	$d = get_transient( $k );
	$d = is_array( $d ) ? $d : array( 'n' => 0, 'until' => 0 );
	$d['n']++;
	if ( $d['n'] >= 5 ) {
		$d = array( 'n' => 0, 'until' => time() + 15 * MINUTE_IN_SECONDS );
	}
	set_transient( $k, $d, 30 * MINUTE_IN_SECONDS );
}

function rzd_pin_ok( $scope ) {
	delete_transient( rzd_pin_key( $scope ) );
}

// Przypomnienie: awaryjny PIN włączony – wyłączyć po zastępstwie.
add_action( 'admin_notices', function () {
	if ( ! current_user_can( 'rzd_p_staff' ) && ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$c = rzd_roles_cfg();
	if ( empty( $c['pin']['on'] ) ) {
		return;
	}
	$days = $c['pin']['since'] ? max( 0, (int) floor( ( current_time( 'timestamp' ) - strtotime( $c['pin']['since'] ) ) / DAY_IN_SECONDS ) ) : 0;
	echo '<div class="notice notice-warning"><p><strong>Awaryjny PIN kuriera jest włączony</strong>' . ( $days ? ' od ' . (int) $days . ' dni' : '' ) . '. Wyłącz go, gdy zastępstwo się skończy – <a href="' . esc_url( admin_url( 'users.php?page=rzd-uprawnienia' ) ) . '">Użytkownicy → Uprawnienia</a>.</p></div>';
} );

/* ============================================================
 * 7. NONCE AKCJI KUCHNI I KURIERA (moduł 13, rzd-kuchnia.js)
 *    Token w treści ekranu (.kuchnia-n) – odświeża się przy każdym miękkim
 *    przeładowaniu, więc tablet otwarty dniami go nie traci.
 * ============================================================ */
function rzd_kitchen_nonce() {
	return wp_create_nonce( 'rzd_kuchnia' );
}

function rzd_kitchen_check_nonce() {
	if ( ! check_ajax_referer( 'rzd_kuchnia', '_n', false ) ) {
		wp_send_json( array( 'ok' => false, 'code' => 'nonce', 'message' => 'Sesja ekranu wygasła – odświeżam stronę.' ), 403 );
	}
}

/** Endpoint wymaga uprawnienia – inaczej 403 (ukryty przycisk to nie zabezpieczenie). */
function rzd_need( $key ) {
	if ( ! rzd_can( $key ) ) {
		wp_send_json( array( 'ok' => false, 'message' => 'Brak uprawnienia: ' . rzd_perm_catalog()[ $key ][0] . '.' ), 403 );
	}
}
