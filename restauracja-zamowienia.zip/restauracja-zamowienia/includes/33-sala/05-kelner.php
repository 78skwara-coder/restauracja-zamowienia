<?php
/**
 * Moduł 33-sala – panel kelnera: shortcode [rzd_sala] (telefon / tablet, pełny ekran).
 * Okno modyfikacji – to samo co w sklepie (rzd-modyfikacje.js, kroki bramy rzdRunAddSteps),
 * ze wszystkimi grupami naraz (window.rzdModsAll) i przyciskiem „Dodaj do rachunku”.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function rzd_sala_is_page() {
	if ( is_admin() || ! is_singular() ) {
		return false;
	}
	$post = get_post();
	return $post && has_shortcode( $post->post_content, 'rzd_sala' );
}

// adres strony zapamiętany + nigdy z cache strony; bez skryptu emotek WordPressa (emotki w uwagach = tekst)
add_action( 'template_redirect', function () {
	if ( ! rzd_sala_is_page() ) {
		return;
	}
	if ( ! defined( 'DONOTCACHEPAGE' ) ) {
		define( 'DONOTCACHEPAGE', true );
	}
	nocache_headers();
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'wp_enqueue_scripts', 'wp_enqueue_emoji_styles' );
	$id = (int) get_the_ID();
	if ( (int) get_option( 'rzd_sala_page_id' ) !== $id ) {
		update_option( 'rzd_sala_page_id', $id, false );
	}
} );
// bez paska WordPressa (Szef, Manager): panel jest pełnoekranowy i pasek zasłaniał nagłówek z menu ⋯ (2.44.0).
// Przed _wp_admin_bar_init (template_redirect, priorytet 0).
add_action( 'template_redirect', function () {
	if ( rzd_sala_is_page() ) {
		add_filter( 'show_admin_bar', '__return_false', 99 );
	}
}, -1 );
add_action( 'wp_head', function () {
	if ( rzd_sala_is_page() ) {
		echo '<meta name="robots" content="noindex,nofollow">' . "\n";
	}
} );

add_action( 'wp_enqueue_scripts', function () {
	if ( ! rzd_sala_is_page() || ! is_user_logged_in() || ! rzd_can( 'sala' ) ) {
		return;
	}
	// sklepowe okienka terminu i dosprzedaży nie mają tu sensu (zamówienie na teraz, na miejscu)
	foreach ( array( 'rzd-termin', 'rzd-dobierz' ) as $h ) {
		wp_dequeue_script( $h );
	}
	wp_enqueue_style( 'rzd-sala', RZD_PLUGIN_URL . 'assets/css/rzd-sala.css', array(), rzd_asset_ver( 'assets/css/rzd-sala.css' ) );
	$deps = array( 'rzd-brama' );
	if ( wp_script_is( 'rzd-modyfikacje', 'enqueued' ) ) {
		$deps[] = 'rzd-modyfikacje';
		wp_add_inline_script( 'rzd-modyfikacje', 'window.rzdModsAll = true; window.rzdModsOkText = "Dodaj do rachunku";', 'before' );
	}
	wp_enqueue_script( 'rzd-sala', RZD_PLUGIN_URL . 'assets/js/rzd-sala.js', $deps, rzd_asset_ver( 'assets/js/rzd-sala.js' ), array( 'in_footer' => true, 'strategy' => 'defer' ) );
	wp_add_inline_script( 'rzd-sala', 'var rzdSala = ' . wp_json_encode( array(
		'ajax'    => admin_url( 'admin-ajax.php' ),
		'nonce'   => wp_create_nonce( 'rzd_sala' ),
		'user'    => rzd_sala_user_name(),
		'logout'  => wp_logout_url( get_permalink() ),
		'brand'   => function_exists( 'rzd_brand' ) ? rzd_brand() : null, // logo → sklep (2.44.0)
		'panel'   => function_exists( 'rzd_panel_can' ) && rzd_panel_can() ? rzd_panel_url() : '',
		'kitchen' => ( function_exists( 'rzd_kitchen_can' ) && rzd_kitchen_can() && function_exists( 'rzd_kitchen_page_url' ) ) ? rzd_kitchen_page_url() : '',
		'cur'     => html_entity_decode( get_woocommerce_currency_symbol(), ENT_QUOTES, 'UTF-8' ),
	) ) . ';', 'before' );
}, 30 );

add_shortcode( 'rzd_sala', function () {
	if ( ! is_user_logged_in() ) {
		return rzd_staff_login_html( 'Sala', 'Zaloguj się kontem kelnera. Zostaw zaznaczone „Zapamiętaj mnie” – telefon / tablet pozostanie zalogowany.' );
	}
	if ( ! rzd_can( 'sala' ) ) {
		return rzd_no_access_html( 'Sala (kelner)' );
	}
	if ( ! rzd_sala_tables() ) {
		return '<p style="max-width:460px;margin:60px auto;font-family:sans-serif;font-size:16px">Nie ma jeszcze stolików. Dodaj je w Panelu restauracji → Sala.</p>';
	}
	return '<div id="rzd-sala" class="rzd-sala" aria-live="polite"><p class="sl-load">Wczytuję salę…</p></div>';
} );
