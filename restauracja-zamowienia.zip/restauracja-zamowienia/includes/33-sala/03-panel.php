<?php
/**
 * Moduł 33-sala – panel: Restauracja → Sala (strefy, stoliki, kategorie: gdzie sprzedawane i bilet).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function rzd_sala_admin_page() {
	if ( ! current_user_can( 'rzd_p_settings' ) && ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$c     = rzd_sala_cfg();
	$cats  = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false ) );
	$url   = rzd_sala_page_url();
	$open  = function_exists( 'rzd_sala_open_tables' ) ? rzd_sala_open_tables() : array();
	$msg   = isset( $_GET['saved'] ) ? 'Zapisano.' : ( isset( $_GET['page_made'] ) ? 'Utworzono stronę panelu kelnera.' : '' ); // phpcs:ignore
	$err   = isset( $_GET['kept'] ) ? 'Stolików z otwartym rachunkiem nie można usunąć – zostały (najpierw zamknij rachunek): ' . sanitize_text_field( wp_unslash( $_GET['kept'] ) ) : ''; // phpcs:ignore
	?>
	<div class="wrap rzd-sala-admin">
		<h1>Sala</h1>
		<p class="description" style="max-width:900px">Zamówienia przy stoliku: kelner na telefonie lub tablecie otwiera stolik, dodaje dania i napoje, wysyła do kuchni (każde dobranie to osobna runda), a na koniec zamyka rachunek – gotówka albo karta. Kuchnia widzi bilety w zakładce „Sala”. Zamówienia z sali są zwykłymi zamówieniami WooCommerce (z numerem stolika), ale nie trafiają do dostaw, Pakowania ani Kuriera. <strong>Paragon fiskalny</strong> kelner wybija jak dotąd na kasie restauracji.</p>
		<?php if ( $msg ) : ?><div class="notice notice-success"><p><?php echo esc_html( $msg ); ?></p></div><?php endif; ?>
		<?php if ( $err ) : ?><div class="notice notice-warning"><p><?php echo esc_html( $err ); ?></p></div><?php endif; ?>

		<div class="card" style="max-width:900px">
			<h2 style="margin-top:.6em">Panel kelnera</h2>
			<?php if ( $url ) : ?>
				<p>Strona: <a href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $url ); ?></a> – otwórz na telefonie / tablecie kontem z uprawnieniem „Sala (kelner)” (Użytkownicy → Uprawnienia; na start: Szef, Manager, Kierownik sali). Bilety dla kuchni: Kuchnia → zakładka „Sala” (uprawnienie „Bilety z sali”).</p>
			<?php else : ?>
				<p>Nie ma jeszcze strony z panelem kelnera (shortcode <code>[rzd_sala]</code>).</p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="rzd_sala_make_page"><?php wp_nonce_field( 'rzd_sala_make_page' ); ?>
					<button class="button">Utwórz stronę „Sala”</button>
				</form>
			<?php endif; ?>
		</div>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="rzd-sala-form">
			<input type="hidden" name="action" value="rzd_sala_save"><?php wp_nonce_field( 'rzd_sala_save' ); ?>

			<h2>Strefy</h2>
			<p class="description">Np. Sala, Ogródek, Piętro – stoliki w panelu kelnera są pogrupowane według stref.</p>
			<table class="widefat striped" style="max-width:520px" id="rzd-sala-zones"><thead><tr><th>Nazwa strefy</th><th style="width:70px">Usuń</th></tr></thead><tbody>
				<?php foreach ( $c['zones'] as $z ) : ?>
					<tr><td><input type="hidden" name="zones[<?php echo esc_attr( $z['id'] ); ?>][id]" value="<?php echo esc_attr( $z['id'] ); ?>"><input type="text" class="regular-text" name="zones[<?php echo esc_attr( $z['id'] ); ?>][name]" value="<?php echo esc_attr( $z['name'] ); ?>" maxlength="40" required></td>
						<td><input type="checkbox" name="zones[<?php echo esc_attr( $z['id'] ); ?>][del]" value="1" aria-label="Usuń strefę"></td></tr>
				<?php endforeach; ?>
			</tbody></table>
			<p><button type="button" class="button" id="rzd-sala-addzone">+ Strefa</button></p>

			<h2>Stoliki</h2>
			<table class="widefat striped" style="max-width:900px" id="rzd-sala-tables"><thead><tr><th>Nazwa / numer</th><th style="width:90px">Miejsc</th><th>Strefa</th><th style="width:80px">Aktywny</th><th style="width:70px">Usuń</th></tr></thead><tbody>
				<?php foreach ( $c['tables'] as $t ) : $busy = isset( $open[ $t['id'] ] ); ?>
					<tr>
						<td><input type="hidden" name="tables[<?php echo esc_attr( $t['id'] ); ?>][id]" value="<?php echo esc_attr( $t['id'] ); ?>"><input type="text" name="tables[<?php echo esc_attr( $t['id'] ); ?>][name]" value="<?php echo esc_attr( $t['name'] ); ?>" maxlength="30" required><?php echo $busy ? ' <span class="description">(otwarty rachunek)</span>' : ''; ?></td>
						<td><input type="number" min="1" max="99" style="width:70px" name="tables[<?php echo esc_attr( $t['id'] ); ?>][seats]" value="<?php echo (int) $t['seats']; ?>"></td>
						<td><select name="tables[<?php echo esc_attr( $t['id'] ); ?>][zone]"><?php foreach ( $c['zones'] as $z ) : ?><option value="<?php echo esc_attr( $z['id'] ); ?>" <?php selected( $t['zone'], $z['id'] ); ?>><?php echo esc_html( $z['name'] ); ?></option><?php endforeach; ?></select></td>
						<td><input type="checkbox" name="tables[<?php echo esc_attr( $t['id'] ); ?>][active]" value="1" <?php checked( ! empty( $t['active'] ) ); ?>></td>
						<td><input type="checkbox" name="tables[<?php echo esc_attr( $t['id'] ); ?>][del]" value="1" <?php disabled( $busy ); ?> aria-label="Usuń stolik"></td>
					</tr>
				<?php endforeach; ?>
			</tbody></table>
			<p>
				<button type="button" class="button" id="rzd-sala-addtable">+ Stolik</button>
				&nbsp; albo dodaj kilka naraz: <input type="number" min="1" max="60" name="bulk_n" style="width:64px" aria-label="Ile stolików"> stolików do strefy
				<select name="bulk_zone"><?php foreach ( $c['zones'] as $z ) : ?><option value="<?php echo esc_attr( $z['id'] ); ?>"><?php echo esc_html( $z['name'] ); ?></option><?php endforeach; ?></select>
				po <input type="number" min="1" max="99" name="bulk_seats" value="4" style="width:56px" aria-label="Miejsc przy stoliku"> miejsca (numeracja dalej od ostatniego)
			</p>

			<h2>Kategorie: gdzie sprzedawane</h2>
			<p class="description" style="max-width:900px">„Tylko na miejscu” – np. kawa, herbata: sklep internetowy ich nie pokazuje i nie sprzedaje, kelner tak. „Tylko dostawa / na wynos” – kelner ich nie widzi. „Bilet: dolna sekcja” – na bilecie kuchni pod kreską (napoje), żeby nie mieszały się z daniami.</p>
			<table class="widefat striped" style="max-width:900px"><thead><tr><th>Kategoria</th><th>Gdzie sprzedawane</th><th>Bilet: dolna sekcja</th></tr></thead><tbody>
				<?php foreach ( is_array( $cats ) ? $cats : array() as $t ) : if ( get_term_meta( $t->term_id, 'rwz_hide_in_shop', true ) ) { continue; } ?>
					<tr><td><?php echo esc_html( $t->name ); ?></td>
						<td><select name="cats[<?php echo (int) $t->term_id; ?>][sell]"><?php foreach ( rzd_sell_scopes() as $k => $lbl ) : ?><option value="<?php echo esc_attr( $k ); ?>" <?php selected( rzd_cat_sell( $t->term_id ), $k ); ?>><?php echo esc_html( $lbl ); ?></option><?php endforeach; ?></select></td>
						<td><label><input type="checkbox" name="cats[<?php echo (int) $t->term_id; ?>][low]" value="1" <?php checked( (bool) get_term_meta( $t->term_id, 'rzd_ticket_low', true ) ); ?>> pod kreską</label></td></tr>
				<?php endforeach; ?>
			</tbody></table>
			<p><button type="submit" class="button button-primary">Zapisz salę</button></p>
		</form>
		<template id="rzd-sala-tpl-table"><tr>
			<td><input type="text" name="new_tables[__i__][name]" maxlength="30" required placeholder="np. 12"></td>
			<td><input type="number" min="1" max="99" style="width:70px" name="new_tables[__i__][seats]" value="4"></td>
			<td><select name="new_tables[__i__][zone]"><?php foreach ( $c['zones'] as $z ) : ?><option value="<?php echo esc_attr( $z['id'] ); ?>"><?php echo esc_html( $z['name'] ); ?></option><?php endforeach; ?></select></td>
			<td><input type="checkbox" name="new_tables[__i__][active]" value="1" checked></td><td></td></tr></template>
		<template id="rzd-sala-tpl-zone"><tr><td><input type="text" class="regular-text" name="new_zones[__i__]" maxlength="40" required placeholder="np. Ogródek"></td><td></td></tr></template>
		<script>
		(function () {
			var n = 0;
			function add(tpl, tb) {
				var t = document.getElementById(tpl).innerHTML.replace(/__i__/g, String(n++));
				var tbody = document.querySelector(tb + ' tbody');
				tbody.insertAdjacentHTML('beforeend', t);
				var inp = tbody.lastElementChild.querySelector('input[type=text]'); if (inp) { inp.focus(); }
			}
			document.getElementById('rzd-sala-addtable').addEventListener('click', function () { add('rzd-sala-tpl-table', '#rzd-sala-tables'); });
			document.getElementById('rzd-sala-addzone').addEventListener('click', function () { add('rzd-sala-tpl-zone', '#rzd-sala-zones'); });
		})();
		</script>
	</div>
	<?php
}

add_action( 'admin_post_rzd_sala_save', function () {
	if ( ! current_user_can( 'rzd_p_settings' ) && ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Brak uprawnień.' );
	}
	check_admin_referer( 'rzd_sala_save' );
	$in   = wp_unslash( $_POST ); // phpcs:ignore
	$c    = rzd_sala_cfg();
	$next = max( 1, (int) $c['next'] );
	$open = function_exists( 'rzd_sala_open_tables' ) ? rzd_sala_open_tables() : array();
	$name = function ( $v, $max ) {
		$v = trim( sanitize_text_field( (string) $v ) );
		return function_exists( 'mb_substr' ) ? mb_substr( $v, 0, $max ) : substr( $v, 0, $max );
	};
	// strefy
	$zones = array();
	foreach ( (array) ( isset( $in['zones'] ) ? $in['zones'] : array() ) as $z ) {
		$zid = isset( $z['id'] ) ? sanitize_key( $z['id'] ) : '';
		$nm  = isset( $z['name'] ) ? $name( $z['name'], 40 ) : '';
		if ( '' === $zid || '' === $nm || ! empty( $z['del'] ) ) {
			continue;
		}
		$zones[ $zid ] = array( 'id' => $zid, 'name' => $nm );
	}
	foreach ( (array) ( isset( $in['new_zones'] ) ? $in['new_zones'] : array() ) as $nm ) {
		$nm = $name( $nm, 40 );
		if ( '' !== $nm ) {
			$zid           = 'z' . ( $next++ );
			$zones[ $zid ] = array( 'id' => $zid, 'name' => $nm );
		}
	}
	if ( ! $zones ) {
		$zones = array( 'z1' => array( 'id' => 'z1', 'name' => 'Sala' ) );
	}
	$first = array_keys( $zones )[0];
	$zone  = function ( $v ) use ( $zones, $first ) {
		$v = sanitize_key( (string) $v );
		return isset( $zones[ $v ] ) ? $v : $first;
	};
	// stoliki
	$tables = array();
	$kept   = array();
	foreach ( (array) ( isset( $in['tables'] ) ? $in['tables'] : array() ) as $t ) {
		$tid = isset( $t['id'] ) ? sanitize_key( $t['id'] ) : '';
		if ( '' === $tid ) {
			continue;
		}
		$nm = isset( $t['name'] ) ? $name( $t['name'], 30 ) : '';
		if ( ! empty( $t['del'] ) || '' === $nm ) {
			if ( isset( $open[ $tid ] ) ) {
				$old    = rzd_sala_table( $tid );
				$kept[] = $old ? $old['name'] : $tid;
				$tables[] = $old; // otwarty rachunek – stolik zostaje
			}
			continue;
		}
		$tables[] = array( 'id' => $tid, 'name' => $nm, 'seats' => max( 1, min( 99, (int) ( isset( $t['seats'] ) ? $t['seats'] : 4 ) ) ), 'zone' => $zone( isset( $t['zone'] ) ? $t['zone'] : '' ), 'active' => empty( $t['active'] ) ? 0 : 1 );
	}
	foreach ( (array) ( isset( $in['new_tables'] ) ? $in['new_tables'] : array() ) as $t ) {
		$nm = isset( $t['name'] ) ? $name( $t['name'], 30 ) : '';
		if ( '' === $nm ) {
			continue;
		}
		$tables[] = array( 'id' => 't' . ( $next++ ), 'name' => $nm, 'seats' => max( 1, min( 99, (int) ( isset( $t['seats'] ) ? $t['seats'] : 4 ) ) ), 'zone' => $zone( isset( $t['zone'] ) ? $t['zone'] : '' ), 'active' => empty( $t['active'] ) ? 0 : 1 );
	}
	$bulk = isset( $in['bulk_n'] ) ? max( 0, min( 60, (int) $in['bulk_n'] ) ) : 0;
	if ( $bulk ) {
		$nums = array_filter( array_map( function ( $t ) { return is_numeric( $t['name'] ) ? (int) $t['name'] : 0; }, $tables ) );
		$num  = $nums ? max( $nums ) : 0;
		for ( $i = 0; $i < $bulk; $i++ ) {
			$tables[] = array( 'id' => 't' . ( $next++ ), 'name' => (string) ( ++$num ), 'seats' => max( 1, min( 99, (int) ( isset( $in['bulk_seats'] ) ? $in['bulk_seats'] : 4 ) ) ), 'zone' => $zone( isset( $in['bulk_zone'] ) ? $in['bulk_zone'] : '' ), 'active' => 1 );
		}
	}
	update_option( 'rzd_sala', array( 'zones' => array_values( $zones ), 'tables' => array_values( array_filter( $tables ) ), 'next' => $next ), false );
	// kategorie
	foreach ( (array) ( isset( $in['cats'] ) ? $in['cats'] : array() ) as $tid => $v ) {
		$tid = (int) $tid;
		if ( ! $tid || ! term_exists( $tid, 'product_cat' ) ) {
			continue;
		}
		$sell = isset( $v['sell'] ) && isset( rzd_sell_scopes()[ $v['sell'] ] ) ? $v['sell'] : '';
		'' === $sell ? delete_term_meta( $tid, 'rzd_sell' ) : update_term_meta( $tid, 'rzd_sell', $sell );
		empty( $v['low'] ) ? delete_term_meta( $tid, 'rzd_ticket_low' ) : update_term_meta( $tid, 'rzd_ticket_low', 1 );
	}
	$args = array( 'page' => 'rzd-sala', 'saved' => 1 );
	if ( $kept ) {
		$args['kept'] = implode( ', ', $kept );
	}
	wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php' ) ) );
	exit;
} );

add_action( 'admin_post_rzd_sala_make_page', function () {
	if ( ! current_user_can( 'rzd_p_settings' ) && ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Brak uprawnień.' );
	}
	check_admin_referer( 'rzd_sala_make_page' );
	if ( ! rzd_sala_page_url() ) {
		$id = wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_title' => 'Sala', 'post_name' => 'sala', 'post_content' => '[rzd_sala]' ) );
		if ( $id && ! is_wp_error( $id ) ) {
			update_option( 'rzd_sala_page_id', (int) $id, false );
		}
	}
	wp_safe_redirect( add_query_arg( array( 'page' => 'rzd-sala', 'page_made' => 1 ), admin_url( 'admin.php' ) ) );
	exit;
} );
