<?php
/**
 * Moduł 33-sala – zapis ustawień sali: strefy, stoliki, kategorie (gdzie sprzedawane i bilet).
 * Ekran: Panel restauracji → Sala (moduł 34; do 2.43.x Restauracja → Sala w kokpicie).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Zapis sali. $zones = [ {id?, name} ], $tables = [ {id?, name, seats, zone, active} ],
 * $cats = { term_id: {sell, low} } (null = kategorie bez zmian). Element bez id = nowy.
 * Strefa / stolik pominięty w liście = usunięty – z wyjątkiem stolika z otwartym rachunkiem
 * (zostaje; jego nazwa wraca w 'kept'). Nowa strefa może mieć tymczasowe id „new…” – stoliki
 * wskazują ją tym id, a zapis nadaje prawdziwe. Zwraca [ 'kept' => [nazwy], 'cfg' => konfiguracja ].
 */
function rzd_sala_save( $zones_in, $tables_in, $cats = null ) {
	$c    = rzd_sala_cfg();
	$next = max( 1, (int) $c['next'] );
	$open = function_exists( 'rzd_sala_open_tables' ) ? rzd_sala_open_tables() : array();
	$old  = rzd_sala_tables( false );
	$name = function ( $v, $max ) {
		$v = trim( sanitize_text_field( (string) $v ) );
		return function_exists( 'mb_substr' ) ? mb_substr( $v, 0, $max ) : substr( $v, 0, $max );
	};
	$known_zones = array();
	foreach ( $c['zones'] as $z ) {
		$known_zones[ $z['id'] ] = true;
	}
	// strefy
	$zones = array();
	$map   = array(); // tymczasowe id nowej strefy => nadane
	foreach ( (array) $zones_in as $z ) {
		$z   = is_array( $z ) ? $z : array();
		$zid = isset( $z['id'] ) ? sanitize_key( $z['id'] ) : '';
		$nm  = isset( $z['name'] ) ? $name( $z['name'], 40 ) : '';
		if ( '' === $nm ) {
			continue;
		}
		if ( '' === $zid || ! isset( $known_zones[ $zid ] ) ) {
			do {
				$new = 'z' . ( $next++ );
			} while ( isset( $known_zones[ $new ] ) || isset( $zones[ $new ] ) );
			if ( '' !== $zid ) {
				$map[ $zid ] = $new;
			}
			$zid = $new;
		}
		$zones[ $zid ] = array( 'id' => $zid, 'name' => $nm );
	}
	if ( ! $zones ) {
		$zones = array( 'z1' => array( 'id' => 'z1', 'name' => 'Sala' ) );
	}
	$first = array_keys( $zones )[0];
	$zone  = function ( $v ) use ( $zones, $first, $map ) {
		$v = sanitize_key( (string) $v );
		if ( isset( $map[ $v ] ) ) {
			$v = $map[ $v ];
		}
		return isset( $zones[ $v ] ) ? $v : $first;
	};
	// stoliki
	$tables = array();
	$seen   = array();
	foreach ( (array) $tables_in as $t ) {
		$t  = is_array( $t ) ? $t : array();
		$nm = isset( $t['name'] ) ? $name( $t['name'], 30 ) : '';
		if ( '' === $nm ) {
			continue;
		}
		$tid = isset( $t['id'] ) ? sanitize_key( $t['id'] ) : '';
		if ( '' === $tid || ! isset( $old[ $tid ] ) || isset( $seen[ $tid ] ) ) {
			do {
				$tid = 't' . ( $next++ );
			} while ( isset( $old[ $tid ] ) || isset( $seen[ $tid ] ) );
		}
		$seen[ $tid ] = true;
		$tables[]     = array(
			'id'     => $tid,
			'name'   => $nm,
			'seats'  => max( 1, min( 99, (int) ( isset( $t['seats'] ) ? $t['seats'] : 4 ) ) ),
			'zone'   => $zone( isset( $t['zone'] ) ? $t['zone'] : '' ),
			'active' => empty( $t['active'] ) ? 0 : 1,
		);
	}
	$kept = array();
	foreach ( $old as $tid => $t ) {
		if ( ! isset( $seen[ $tid ] ) && isset( $open[ $tid ] ) ) {
			$t['zone'] = $zone( $t['zone'] ); // strefa mogła zniknąć
			$tables[]  = $t; // otwarty rachunek – stolik zostaje
			$kept[]    = $t['name'];
		}
	}
	$cfg = array( 'zones' => array_values( $zones ), 'tables' => array_values( $tables ), 'next' => $next );
	update_option( 'rzd_sala', $cfg, false );
	// kategorie
	if ( is_array( $cats ) ) {
		foreach ( $cats as $tid => $v ) {
			$tid = (int) $tid;
			$v   = is_array( $v ) ? $v : array();
			if ( ! $tid || ! term_exists( $tid, 'product_cat' ) ) {
				continue;
			}
			$sell = isset( $v['sell'] ) && isset( rzd_sell_scopes()[ $v['sell'] ] ) ? $v['sell'] : '';
			'' === $sell ? delete_term_meta( $tid, 'rzd_sell' ) : update_term_meta( $tid, 'rzd_sell', $sell );
			empty( $v['low'] ) ? delete_term_meta( $tid, 'rzd_ticket_low' ) : update_term_meta( $tid, 'rzd_ticket_low', 1 );
		}
	}
	return array( 'kept' => $kept, 'cfg' => $cfg );
}

/** Kategorie do ustawień sali (bez „Nie wyświetlaj w sklepie”). */
function rzd_sala_cats_cfg() {
	$out  = array();
	$cats = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false ) );
	foreach ( is_array( $cats ) ? $cats : array() as $t ) {
		if ( get_term_meta( $t->term_id, 'rwz_hide_in_shop', true ) ) {
			continue;
		}
		$out[] = array( 'id' => (int) $t->term_id, 'name' => $t->name, 'sell' => rzd_cat_sell( $t->term_id ), 'low' => (bool) get_term_meta( $t->term_id, 'rzd_ticket_low', true ) );
	}
	return $out;
}

/** Strona panelu kelnera – tworzy, gdy jej nie ma. Zwraca adres. */
function rzd_sala_make_page() {
	$url = rzd_sala_page_url();
	if ( $url ) {
		return $url;
	}
	$id = wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_title' => 'Sala', 'post_name' => 'sala', 'post_content' => '[rzd_sala]' ) );
	if ( $id && ! is_wp_error( $id ) ) {
		update_option( 'rzd_sala_page_id', (int) $id, false );
		return get_permalink( $id );
	}
	return '';
}
