<?php
/**
 * Moduł 33-sala – sklep internetowy: produkty z kategorii „tylko na miejscu” (kawa, herbata…)
 * nie pokazują się i nie da się ich kupić online. Panel kelnera tworzy pozycje zamówienia
 * bezpośrednio (bez koszyka), więc te ograniczenia go nie dotyczą.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function rzd_sala_online_blocked( $product ) {
	if ( is_admin() && ! wp_doing_ajax() ) {
		return false; // panel WP – edycja produktów, ręczne zamówienia
	}
	$id = is_object( $product ) ? $product->get_id() : (int) $product;
	return 'onsite' === rzd_product_sell( $id );
}

add_filter( 'woocommerce_is_purchasable', function ( $ok, $product ) {
	return ( $ok && rzd_sala_online_blocked( $product ) ) ? false : $ok;
}, 20, 2 );
add_filter( 'woocommerce_product_is_visible', function ( $vis, $id ) {
	return ( $vis && rzd_sala_online_blocked( $id ) ) ? false : $vis;
}, 20, 2 );

/** tax_query „bez kategorii tylko na miejscu” – lista [lista_zamowien] i strony sklepu WooCommerce. */
function rzd_sala_exclude_onsite_tax( $tq ) {
	$cats = rzd_cats_with_sell( 'onsite' );
	if ( ! $cats ) {
		return $tq;
	}
	$tq   = is_array( $tq ) ? $tq : array();
	$tq[] = array( 'taxonomy' => 'product_cat', 'field' => 'term_id', 'terms' => $cats, 'operator' => 'NOT IN' );
	if ( count( $tq ) > 1 && ! isset( $tq['relation'] ) ) {
		$tq['relation'] = 'AND';
	}
	return $tq;
}
add_filter( 'rzd_lista_query_args', function ( $args ) {
	$args['tax_query'] = rzd_sala_exclude_onsite_tax( isset( $args['tax_query'] ) ? $args['tax_query'] : array() ); // phpcs:ignore
	return $args;
} );
add_action( 'woocommerce_product_query', function ( $q ) {
	$q->set( 'tax_query', rzd_sala_exclude_onsite_tax( $q->get( 'tax_query' ) ) );
} );
