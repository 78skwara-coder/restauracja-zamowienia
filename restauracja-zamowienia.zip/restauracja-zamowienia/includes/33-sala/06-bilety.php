<?php
/**
 * Moduł 33-sala – ekran wydawania: zakładka „Sala” w Kuchni (uprawnienie „Bilety z sali”).
 * Bilet = runda zamówienia ze stolika: dania u góry, napoje (kategorie „Bilet: dolna sekcja”) pod kreską.
 * „Gotowe” → kelner widzi przy stoliku „Do wydania”. Gotowe z ostatnich 15 min – pasek z „Cofnij”.
 * Odświeżanie co 8 s (rzd-sala-bilety.js), dźwięk przy nowym bilecie.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function rzd_sala_kds_html() {
	return '<div id="rzd-kds" class="kds" data-ready-keep="900"><p class="kds-empty">Wczytuję bilety z sali…</p></div>';
}

// skrypt i style poza treścią zakładki (przełączanie zakładek podmienia treść bez wykonywania skryptów)
add_action( 'rzd_kuchnia_after_scripts', function ( $mode ) {
	if ( 'kuchnia' !== $mode || ! rzd_can( 'bilety' ) ) {
		return;
	}
	echo rzd_css_tag( 'assets/css/rzd-sala-bilety.css', 'rzd-sala-bilety-css' ); // phpcs:ignore
	echo '<script src="' . esc_url( RZD_PLUGIN_URL . 'assets/js/rzd-sala-bilety.js?ver=' . rzd_asset_ver( 'assets/js/rzd-sala-bilety.js' ) ) . '"></script>'; // phpcs:ignore
} );

/** Wiersze pozycji na bilet. */
function rzd_sala_ticket_item( $it ) {
	$lines = array();
	foreach ( $it->get_formatted_meta_data( '_' ) as $m ) {
		$lines[] = array( 'k' => $m->display_key, 'v' => wp_strip_all_tags( $m->display_value ) );
	}
	return array( 'qty' => (int) $it->get_quantity(), 'name' => $it->get_name(), 'lines' => $lines );
}

/** Bilety: rundy „new” i „ready” (z ostatnich 15 min) otwartych rachunków. */
function rzd_sala_tickets() {
	$out  = array();
	$keep = time() - 900;
	foreach ( rzd_sala_open_orders() as $o ) {
		$rounds = rzd_sala_rounds( $o );
		if ( ! $rounds ) {
			continue;
		}
		$items = array();
		foreach ( $o->get_items() as $it ) {
			$items[ (int) $it->get_meta( '_rzd_round' ) ][] = $it;
		}
		$t     = rzd_sala_table( (string) $o->get_meta( '_rzd_table' ) );
		foreach ( $rounds as $r ) {
			$st = $r['status'];
			if ( 'new' !== $st && ! ( 'ready' === $st && (int) $r['ready'] >= $keep ) ) {
				continue;
			}
			$top = array();
			$low = array();
			foreach ( isset( $items[ (int) $r['n'] ] ) ? $items[ (int) $r['n'] ] : array() as $it ) {
				if ( rzd_product_ticket_low( $it->get_product_id() ) ) {
					$low[] = rzd_sala_ticket_item( $it );
				} else {
					$top[] = rzd_sala_ticket_item( $it );
				}
			}
			if ( ! $top && ! $low ) {
				continue; // cała runda usunięta (storno)
			}
			$out[] = array(
				'order'  => $o->get_id(),
				'table'  => $t ? $t['name'] : (string) $o->get_meta( '_rzd_table_label' ),
				'n'      => (int) $r['n'],
				'sent'   => (int) $r['sent'],
				'by'     => isset( $r['by_name'] ) ? $r['by_name'] : '',
				'status' => $st,
				'ready'  => (int) $r['ready'],
				'top'    => $top,
				'low'    => $low,
			);
		}
	}
	usort( $out, function ( $a, $b ) { return $a['sent'] <=> $b['sent']; } );
	return $out;
}

function rzd_sala_kds_guard() {
	rzd_kitchen_check_nonce();
	rzd_need( 'bilety' );
	if ( function_exists( 'rzd_kitchen_authed' ) && ! rzd_kitchen_authed() ) {
		wp_send_json( array( 'ok' => false, 'message' => 'Brak dostępu.' ), 403 );
	}
}
add_action( 'wc_ajax_kuchnia_sala', function () {
	rzd_sala_kds_guard();
	wp_send_json( array( 'ok' => true, 'now' => time(), 'tickets' => rzd_sala_tickets() ) );
} );
// „Gotowe” (albo „Cofnij” – z powrotem do przygotowania)
add_action( 'wc_ajax_kuchnia_sala_ready', function () {
	rzd_sala_kds_guard();
	$o    = wc_get_order( isset( $_POST['order'] ) ? absint( $_POST['order'] ) : 0 ); // phpcs:ignore
	$n    = isset( $_POST['round'] ) ? (int) $_POST['round'] : 0; // phpcs:ignore
	$undo = ! empty( $_POST['undo'] ); // phpcs:ignore
	if ( ! rzd_sala_is_order( $o ) || 'przyjete' !== $o->get_status() ) {
		wp_send_json( array( 'ok' => false, 'message' => 'Ten rachunek jest już zamknięty.' ) );
	}
	$rounds = rzd_sala_rounds( $o );
	$hit    = false;
	foreach ( $rounds as &$r ) {
		if ( (int) $r['n'] !== $n ) {
			continue;
		}
		if ( $undo && 'ready' === $r['status'] ) {
			$r['status'] = 'new';
			$r['ready']  = 0;
			$hit         = true;
		} elseif ( ! $undo && 'new' === $r['status'] ) {
			$r['status'] = 'ready';
			$r['ready']  = time();
			$hit         = true;
		}
	}
	unset( $r );
	if ( $hit ) {
		$o->update_meta_data( '_rzd_rounds', $rounds );
		$o->save();
	}
	wp_send_json( array( 'ok' => true, 'tickets' => rzd_sala_tickets(), 'now' => time() ) );
} );
