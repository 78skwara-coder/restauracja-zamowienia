<?php
/**
 * MODUŁ 33: SALA – zamówienia przy stoliku (2.43.0).
 *
 * Zamówienie z sali = zwykłe zamówienie WooCommerce (jak Woo POS) z oznaczeniem:
 *   _rzd_type = dine_in, _rzd_channel = pos, _rzd_table (id stolika), _rzd_table_label, _rzd_waiter,
 *   _rzd_rounds = [ { n, sent, by, status: new|ready|served, ready, served } ] – rundy („dobranie”),
 *   pozycja: _rzd_round (numer rundy), „Uwagi” (tekst kelnera), meta modyfikacji jak z kasy (moduł 10).
 * BEZ _dc_delivery_date – dlatego nie trafia do zakładek dostaw Kuchni, Pakowania, Kuriera,
 * terminów ani limitów okien (wszystkie zapytania tamtych widoków wymagają daty dostawy).
 * Otwarte: status „Przyjęte”; zamknięte rachunkiem: „Dostarczone” + metoda Gotówka/Karta.
 * Kierunek zgodny z ARCHITEKTURA-3.0 (type dine_in, channel pos, table_ref, ruchy gotówki).
 *
 * Części: 01-dane (stoliki, kategorie: gdzie sprzedawane, bilet), 02-sklep (ograniczenia sklepu
 * internetowego), 03-panel (Restauracja → Sala), 04-zamowienia (model + AJAX kelnera),
 * 05-kelner ([rzd_sala]), 06-bilety (zakładka „Sala” w Kuchni).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 1. STOLIKI I STREFY (opcja rzd_sala)
 * ============================================================ */
/** { zones: [ {id, name} ], tables: [ {id, name, seats, zone, active} ], next: int } */
function rzd_sala_cfg() {
	$c = get_option( 'rzd_sala', array() );
	$c = is_array( $c ) ? $c : array();
	$c = wp_parse_args( $c, array( 'zones' => array(), 'tables' => array(), 'next' => 1 ) );
	if ( ! $c['zones'] ) {
		$c['zones'] = array( array( 'id' => 'z1', 'name' => 'Sala' ) );
	}
	return $c;
}
function rzd_sala_tables( $only_active = true ) {
	$c   = rzd_sala_cfg();
	$out = array();
	foreach ( (array) $c['tables'] as $t ) {
		if ( ! $only_active || ! empty( $t['active'] ) ) {
			$out[ $t['id'] ] = $t;
		}
	}
	return $out;
}
function rzd_sala_table( $id ) {
	$t = rzd_sala_tables( false );
	return isset( $t[ $id ] ) ? $t[ $id ] : null;
}

/* ============================================================
 * 2. KATEGORIE: GDZIE SPRZEDAWANE, BILET KUCHNI
 *    term meta rzd_sell: '' (wszędzie) | onsite (tylko na miejscu) | delivery (tylko dostawa / na wynos)
 *    term meta rzd_ticket_low: 1 = na bilecie w dolnej sekcji pod kreską (napoje: kawa, herbata)
 * ============================================================ */
function rzd_sell_scopes() {
	return array( '' => 'Wszędzie', 'onsite' => 'Tylko na miejscu (sala)', 'delivery' => 'Tylko dostawa / na wynos' );
}
function rzd_cat_sell( $term_id ) {
	$v = (string) get_term_meta( (int) $term_id, 'rzd_sell', true );
	return isset( rzd_sell_scopes()[ $v ] ) ? $v : '';
}
/** Kategorie z danym zakresem (z cache na żądanie). */
function rzd_cats_with_sell( $scope ) {
	static $memo = array();
	if ( ! isset( $memo[ $scope ] ) ) {
		$memo[ $scope ] = array_map( 'intval', get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false, 'fields' => 'ids', 'meta_key' => 'rzd_sell', 'meta_value' => $scope ) ) ); // phpcs:ignore
		if ( is_wp_error( $memo[ $scope ] ) ) {
			$memo[ $scope ] = array();
		}
	}
	return $memo[ $scope ];
}
/**
 * Zakres produktu: 'onsite' gdy choć jedna jego kategoria (albo nadrzędna) jest „tylko na miejscu”,
 * 'delivery' gdy „tylko dostawa”, inaczej '' (wszędzie).
 */
function rzd_product_sell( $product_id ) {
	static $memo = array();
	$pid = (int) $product_id;
	if ( isset( $memo[ $pid ] ) ) {
		return $memo[ $pid ];
	}
	$p = wc_get_product( $pid );
	if ( $p && $p->get_parent_id() ) {
		$pid = (int) $p->get_parent_id();
	}
	$found = '';
	foreach ( (array) wc_get_product_term_ids( $pid, 'product_cat' ) as $tid ) {
		foreach ( array_merge( array( (int) $tid ), array_map( 'intval', get_ancestors( (int) $tid, 'product_cat', 'taxonomy' ) ) ) as $id ) {
			$v = rzd_cat_sell( $id );
			if ( 'onsite' === $v ) {
				$found = 'onsite';
				break 2;
			}
			if ( 'delivery' === $v ) {
				$found = 'delivery';
			}
		}
	}
	return $memo[ (int) $product_id ] = $found;
}
function rzd_product_ticket_low( $product_id ) {
	foreach ( (array) wc_get_product_term_ids( (int) $product_id, 'product_cat' ) as $tid ) {
		if ( get_term_meta( (int) $tid, 'rzd_ticket_low', true ) ) {
			return true;
		}
	}
	return false;
}

/* ============================================================
 * 3. POMOCNICZE
 * ============================================================ */
function rzd_sala_today() {
	return current_time( 'Y-m-d' );
}
function rzd_sala_money( $v ) {
	return html_entity_decode( wp_strip_all_tags( wc_price( (float) $v ) ), ENT_QUOTES, 'UTF-8' );
}
function rzd_sala_page_url() {
	return function_exists( 'rzd_page_url_opt' ) ? rzd_page_url_opt( 'rzd_sala_page_id', 'rzd_sala' ) : '';
}
