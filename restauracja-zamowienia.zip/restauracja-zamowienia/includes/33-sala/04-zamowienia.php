<?php
/**
 * Moduł 33-sala – zamówienia z sali: model (zamówienie WooCommerce + rundy) i AJAX panelu kelnera.
 * Endpointy: admin-ajax (tylko zalogowani), nonce „rzd_sala”, uprawnienie „Sala (kelner)”.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 1. ODCZYT
 * ============================================================ */
function rzd_sala_open_orders() {
	return wc_get_orders( array(
		'limit'      => -1,
		'status'     => array( 'wc-przyjete' ),
		'meta_query' => array( array( 'key' => '_rzd_type', 'value' => 'dine_in' ) ), // phpcs:ignore
		'orderby'    => 'date',
		'order'      => 'ASC',
		'return'     => 'objects',
	) );
}
/** stolik => zamówienie (otwarty rachunek). */
function rzd_sala_open_tables() {
	$out = array();
	foreach ( rzd_sala_open_orders() as $o ) {
		$t = (string) $o->get_meta( '_rzd_table' );
		if ( '' !== $t && ! isset( $out[ $t ] ) ) {
			$out[ $t ] = $o;
		}
	}
	return $out;
}
function rzd_sala_is_order( $order ) {
	return $order && 'dine_in' === $order->get_meta( '_rzd_type' );
}
function rzd_sala_rounds( $order ) {
	$r = $order->get_meta( '_rzd_rounds' );
	return is_array( $r ) ? $r : array();
}

/** Produkt do sprzedaży na sali dziś: '' = tak, inaczej powód. */
function rzd_sala_product_reject( $pid ) {
	$p = wc_get_product( $pid );
	if ( ! $p || 'publish' !== $p->get_status() || ! $p->is_type( 'simple' ) ) {
		return 'Produkt niedostępny.';
	}
	if ( 'delivery' === rzd_product_sell( $pid ) ) {
		return '„' . $p->get_name() . '” jest tylko na dostawę / na wynos.';
	}
	if ( function_exists( 'rzd_zestaw_product_in_hidden_category' ) && rzd_zestaw_product_in_hidden_category( $pid ) && ! ( function_exists( 'rzd_zestaw_get_slots' ) && rzd_zestaw_get_slots( $pid ) ) ) {
		return '„' . $p->get_name() . '” sprzedaje się tylko w zestawie.';
	}
	$today = rzd_sala_today();
	if ( function_exists( 'rzd_dc_product_available_on' ) && ! rzd_dc_product_available_on( $pid, $today ) ) {
		return '„' . $p->get_name() . '” nie jest dziś dostępny.';
	}
	if ( function_exists( 'rzd_soldout_effective' ) && rzd_soldout_effective( $pid, $today ) ) {
		return '„' . $p->get_name() . '” jest dziś wyprzedany.';
	}
	return '';
}

/** Menu sali na dziś: [ { id, name, items: [ {id, name, price, price_html, mods, sklad, low} ] } ] w kolejności kafli sklepu. */
function rzd_sala_menu() {
	$ids   = wc_get_products( array( 'status' => 'publish', 'type' => 'simple', 'limit' => -1, 'return' => 'ids', 'orderby' => 'title', 'order' => 'ASC' ) );
	$mods  = function_exists( 'rzd_products_with_modifiers' ) ? rzd_products_with_modifiers() : array();
	$terms = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false ) );
	$terms = is_array( $terms ) ? $terms : array();
	if ( function_exists( 'rzd_kategorie_sort' ) ) {
		$terms = rzd_kategorie_sort( $terms );
	}
	$order = array();
	foreach ( $terms as $i => $t ) {
		$order[ (int) $t->term_id ] = array( 'pos' => $i, 'name' => $t->name );
	}
	$cats = array();
	foreach ( $ids as $pid ) {
		$pid = (int) $pid;
		if ( '' !== rzd_sala_product_reject( $pid ) ) {
			continue;
		}
		$p = wc_get_product( $pid );
		// kategoria do grupowania: pierwsza widoczna wg kolejności kafli (ukryte „Nie wyświetlaj” pomijamy)
		$best = null;
		foreach ( (array) $p->get_category_ids() as $cid ) {
			if ( isset( $order[ $cid ] ) && ! get_term_meta( $cid, 'rwz_hide_in_shop', true ) && ( null === $best || $order[ $cid ]['pos'] < $order[ $best ]['pos'] ) ) {
				$best = (int) $cid;
			}
		}
		$key = null === $best ? 0 : $best;
		if ( ! isset( $cats[ $key ] ) ) {
			$cats[ $key ] = array( 'id' => $key, 'name' => $key ? $order[ $key ]['name'] : 'Inne', 'pos' => $key ? $order[ $key ]['pos'] : 9999, 'items' => array() );
		}
		$sk = function_exists( 'rzd_get_product_sklad' ) ? implode( ', ', wp_list_pluck( rzd_get_product_sklad( $pid ), 'name' ) ) : '';
		if ( function_exists( 'rzd_zestaw_get_slots' ) && rzd_zestaw_get_slots( $pid ) && function_exists( 'rzd_zestaw_get_active_components' ) ) {
			$a  = rzd_zestaw_get_active_components( $pid, rzd_sala_today() );
			$sk = implode( ', ', array_map( function ( $x ) { return $x->get_name(); }, (array) $a['main'] ) );
		}
		$price = (float) $p->get_price();
		$cats[ $key ]['items'][] = array(
			'id'         => $pid,
			'name'       => $p->get_name(),
			'price'      => $price,
			'price_html' => rzd_sala_money( $price ),
			'mods'       => in_array( $pid, $mods, true ),
			'sklad'      => $sk,
		);
	}
	usort( $cats, function ( $a, $b ) { return $a['pos'] <=> $b['pos']; } );
	return array_values( array_map( function ( $c ) { unset( $c['pos'] ); return $c; }, $cats ) );
}

/** Rachunek stolika do panelu kelnera. */
function rzd_sala_order_data( $order ) {
	$rounds = rzd_sala_rounds( $order );
	$by_n   = array();
	foreach ( $rounds as $r ) {
		$by_n[ (int) $r['n'] ] = array( 'n' => (int) $r['n'], 'status' => $r['status'], 'sent' => (int) $r['sent'], 'by' => isset( $r['by_name'] ) ? $r['by_name'] : '', 'items' => array() );
	}
	foreach ( $order->get_items() as $iid => $it ) {
		$n = (int) $it->get_meta( '_rzd_round' );
		if ( ! isset( $by_n[ $n ] ) ) {
			$by_n[ $n ] = array( 'n' => $n, 'status' => 'served', 'sent' => 0, 'by' => '', 'items' => array() );
		}
		$lines = array();
		foreach ( $it->get_formatted_meta_data( '_' ) as $m ) {
			$lines[] = $m->display_key . ': ' . wp_strip_all_tags( $m->display_value );
		}
		$by_n[ $n ]['items'][] = array( 'id' => (int) $iid, 'name' => $it->get_name(), 'qty' => (int) $it->get_quantity(), 'total_html' => rzd_sala_money( (float) $it->get_total() + (float) $it->get_total_tax() ), 'lines' => $lines );
	}
	ksort( $by_n );
	$t = rzd_sala_table( (string) $order->get_meta( '_rzd_table' ) );
	return array(
		'id'         => $order->get_id(),
		'number'     => $order->get_order_number(),
		'table'      => (string) $order->get_meta( '_rzd_table' ),
		'table_name' => $t ? $t['name'] : (string) $order->get_meta( '_rzd_table_label' ),
		'opened'     => $order->get_date_created() ? $order->get_date_created()->getTimestamp() : time(),
		'total'      => (float) $order->get_total(),
		'total_html' => rzd_sala_money( $order->get_total() ),
		'rounds'     => array_values( $by_n ),
	);
}

/** Stan sali: strefy, stoliki z otwartymi rachunkami. */
function rzd_sala_state() {
	$c     = rzd_sala_cfg();
	$open  = rzd_sala_open_tables();
	$tbls  = array();
	foreach ( rzd_sala_tables() as $id => $t ) {
		$row = array( 'id' => $id, 'name' => $t['name'], 'seats' => (int) $t['seats'], 'zone' => $t['zone'], 'order' => null );
		if ( isset( $open[ $id ] ) ) {
			$o     = $open[ $id ];
			$ready = 0;
			$new   = 0;
			foreach ( rzd_sala_rounds( $o ) as $r ) {
				$ready += ( 'ready' === $r['status'] ) ? 1 : 0;
				$new   += ( 'new' === $r['status'] ) ? 1 : 0;
			}
			$row['order'] = array( 'id' => $o->get_id(), 'total_html' => rzd_sala_money( $o->get_total() ), 'opened' => $o->get_date_created() ? $o->get_date_created()->getTimestamp() : time(), 'ready' => $ready, 'cooking' => $new, 'bill' => (bool) $o->get_meta( '_rzd_bill_asked' ) );
		}
		$tbls[] = $row;
	}
	return array( 'zones' => array_values( $c['zones'] ), 'tables' => $tbls, 'now' => time() );
}

/* ============================================================
 * 2. ZAPIS
 * ============================================================ */
/** Prosta blokada stolika (dwóch kelnerów naraz nie otworzy dwóch rachunków). */
function rzd_sala_lock( $key ) {
	$opt = 'rzd_sala_lock_' . md5( $key );
	for ( $i = 0; $i < 20; $i++ ) {
		if ( add_option( $opt, time(), '', 'no' ) ) {
			return $opt;
		}
		if ( time() - (int) get_option( $opt ) > 15 ) {
			delete_option( $opt );
			continue;
		}
		usleep( 150000 );
	}
	return '';
}
function rzd_sala_unlock( $opt ) {
	if ( $opt ) {
		delete_option( $opt );
	}
}

function rzd_sala_user_name() {
	$u = wp_get_current_user();
	return $u && $u->exists() ? ( $u->first_name ? $u->first_name : $u->display_name ) : '';
}

/** Nowe zamówienie (rachunek) dla stolika. */
function rzd_sala_create_order( $table ) {
	$order = wc_create_order( array( 'created_via' => 'rzd_sala' ) );
	if ( is_wp_error( $order ) ) {
		return $order;
	}
	$order->set_billing_first_name( 'Stolik' );
	$order->set_billing_last_name( $table['name'] );
	$order->update_meta_data( '_rzd_type', 'dine_in' );
	$order->update_meta_data( '_rzd_channel', 'pos' );
	$order->update_meta_data( '_rzd_table', $table['id'] );
	$order->update_meta_data( '_rzd_table_label', $table['name'] );
	$order->update_meta_data( '_rzd_waiter', get_current_user_id() );
	$order->update_meta_data( '_rzd_rounds', array() );
	$order->set_status( 'przyjete', 'Rachunek otwarty na sali – stolik ' . $table['name'] . ( rzd_sala_user_name() ? ' (' . rzd_sala_user_name() . ')' : '' ) . '.' );
	$order->save();
	return $order;
}

/** Pozycja zamówienia z panelu kelnera – te same dane co z kasy sklepu (skład po wyborze, dodatki, zestaw). */
function rzd_sala_make_item( $pid, $qty, $raw, $note, $round ) {
	$p      = wc_get_product( $pid );
	$values = array( 'product_id' => $pid );
	$delta  = 0.0;
	if ( function_exists( 'rzd_get_modifier_groups' ) && rzd_get_modifier_groups( $pid ) ) {
		$raw              = function_exists( 'rzd_sanitize_raw_selection' ) ? rzd_sanitize_raw_selection( $raw ) : array();
		$sel              = rzd_read_selection( $pid, $raw );
		$values['rzd_raw'] = $raw;
		if ( $sel['lines'] ) {
			$values['rzd_mods']  = $sel['lines'];
			$values['rzd_usage'] = $sel['usage'];
			$delta               = (float) $sel['delta'];
		}
	}
	if ( function_exists( 'rzd_zestaw_get_slots' ) && rzd_zestaw_get_slots( $pid ) && function_exists( 'rzd_zestaw_get_active_components' ) ) {
		$a = rzd_zestaw_get_active_components( $pid, rzd_sala_today() );
		if ( ! empty( $a['main'] ) ) {
			$values['rwz_components']    = array_map( function ( $x ) { return $x->get_name(); }, $a['main'] );
			$values['rwz_component_ids'] = function_exists( 'rzd_zestaw_component_ids' ) ? rzd_zestaw_component_ids( $a['main'] ) : array();
		}
	}
	$unit  = max( 0, (float) $p->get_price() + $delta ); // brutto jak w sklepie
	$gross = $unit * $qty;
	$net   = wc_tax_enabled() && wc_prices_include_tax() ? wc_get_price_excluding_tax( $p, array( 'qty' => $qty, 'price' => $unit ) ) : $gross;
	$item  = new WC_Order_Item_Product();
	$item->set_product( $p );
	$item->set_quantity( $qty );
	$item->set_subtotal( $net );
	$item->set_total( $net );
	if ( function_exists( 'rzd_item_display_lines' ) ) {
		foreach ( rzd_item_display_lines( $pid, $values ) as $l ) {
			$item->add_meta_data( $l['key'], $l['value'], true );
		}
	}
	if ( ! empty( $values['rzd_usage'] ) ) {
		$item->add_meta_data( '_rzd_addon_usage', wp_json_encode( $values['rzd_usage'] ), true );
	}
	if ( function_exists( 'rzd_zestaw_add_order_line_item_meta' ) ) {
		rzd_zestaw_add_order_line_item_meta( $item, '', $values, null );
	}
	if ( '' !== $note ) {
		$item->add_meta_data( 'Uwagi', $note, true );
	}
	$item->add_meta_data( '_rzd_round', (int) $round, true );
	return $item;
}

function rzd_sala_recalc( $order ) {
	$order->calculate_totals( wc_tax_enabled() );
}

/* ============================================================
 * 3. AJAX PANELU KELNERA
 * ============================================================ */
function rzd_sala_guard() {
	if ( ! check_ajax_referer( 'rzd_sala', 'n', false ) ) {
		wp_send_json( array( 'ok' => false, 'code' => 'nonce', 'msg' => 'Sesja wygasła – odświeżam stronę.' ), 403 );
	}
	if ( ! function_exists( 'rzd_can' ) || ! rzd_can( 'sala' ) ) {
		wp_send_json( array( 'ok' => false, 'msg' => 'Brak uprawnienia: Sala (kelner).' ), 403 );
	}
}
function rzd_sala_post( $k, $def = '' ) {
	return isset( $_POST[ $k ] ) ? wp_unslash( $_POST[ $k ] ) : $def; // phpcs:ignore
}
/** Zamówienie z sali z żądania – otwarte (albo dowolne przy $any). */
function rzd_sala_req_order( $any = false ) {
	$o = wc_get_order( absint( rzd_sala_post( 'order', 0 ) ) );
	if ( ! rzd_sala_is_order( $o ) || ( ! $any && 'przyjete' !== $o->get_status() ) ) {
		wp_send_json( array( 'ok' => false, 'msg' => 'Ten rachunek jest już zamknięty – odświeżam salę.', 'code' => 'closed' ) );
	}
	return $o;
}

add_action( 'wp_ajax_rzd_sala_state', function () {
	rzd_sala_guard();
	wp_send_json( array( 'ok' => true ) + rzd_sala_state() );
} );
add_action( 'wp_ajax_rzd_sala_menu', function () {
	rzd_sala_guard();
	wp_send_json( array( 'ok' => true, 'cats' => rzd_sala_menu() ) );
} );
add_action( 'wp_ajax_rzd_sala_bill', function () {
	rzd_sala_guard();
	$tid  = sanitize_key( (string) rzd_sala_post( 'table' ) );
	$open = rzd_sala_open_tables();
	wp_send_json( array( 'ok' => true, 'order' => isset( $open[ $tid ] ) ? rzd_sala_order_data( $open[ $tid ] ) : null ) );
} );

// Wyślij do kuchni: nowa runda (pierwsza – otwiera rachunek).
add_action( 'wp_ajax_rzd_sala_send', function () {
	rzd_sala_guard();
	$tid   = sanitize_key( (string) rzd_sala_post( 'table' ) );
	$table = rzd_sala_tables()[ $tid ] ?? null;
	if ( ! $table ) {
		wp_send_json( array( 'ok' => false, 'msg' => 'Nie ma takiego stolika.' ) );
	}
	$items = json_decode( (string) rzd_sala_post( 'items', '[]' ), true );
	$items = is_array( $items ) ? array_slice( $items, 0, 60 ) : array();
	$clean = array();
	foreach ( $items as $it ) {
		$pid = isset( $it['pid'] ) ? absint( $it['pid'] ) : 0;
		$qty = isset( $it['qty'] ) ? max( 1, min( 99, (int) $it['qty'] ) ) : 1;
		$why = $pid ? rzd_sala_product_reject( $pid ) : 'Produkt niedostępny.';
		if ( '' !== $why ) {
			wp_send_json( array( 'ok' => false, 'msg' => $why ) );
		}
		$note    = isset( $it['note'] ) ? trim( sanitize_text_field( (string) $it['note'] ) ) : '';
		$clean[] = array( $pid, $qty, isset( $it['raw'] ) && is_array( $it['raw'] ) ? $it['raw'] : array(), function_exists( 'mb_substr' ) ? mb_substr( $note, 0, 140 ) : substr( $note, 0, 140 ) );
	}
	if ( ! $clean ) {
		wp_send_json( array( 'ok' => false, 'msg' => 'Nic do wysłania.' ) );
	}
	$lock = rzd_sala_lock( 'table-' . $tid );
	$open = rzd_sala_open_tables();
	$o    = isset( $open[ $tid ] ) ? $open[ $tid ] : rzd_sala_create_order( $table );
	if ( is_wp_error( $o ) ) {
		rzd_sala_unlock( $lock );
		wp_send_json( array( 'ok' => false, 'msg' => 'Nie udało się otworzyć rachunku.' ) );
	}
	$rounds = rzd_sala_rounds( $o );
	$n      = $rounds ? max( wp_list_pluck( $rounds, 'n' ) ) + 1 : 1;
	foreach ( $clean as $c ) {
		$o->add_item( rzd_sala_make_item( $c[0], $c[1], $c[2], $c[3], $n ) );
	}
	$rounds[] = array( 'n' => $n, 'sent' => time(), 'by' => get_current_user_id(), 'by_name' => rzd_sala_user_name(), 'status' => 'new', 'ready' => 0, 'served' => 0 );
	$o->update_meta_data( '_rzd_rounds', $rounds );
	rzd_sala_recalc( $o );
	$o->add_order_note( 'Sala: runda ' . $n . ' wysłana do kuchni (' . count( $clean ) . ' poz.)' . ( rzd_sala_user_name() ? ' – ' . rzd_sala_user_name() : '' ) . '.' );
	$o->save();
	rzd_sala_unlock( $lock );
	wp_send_json( array( 'ok' => true, 'order' => rzd_sala_order_data( $o ) ) );
} );

// Wydane na stół.
add_action( 'wp_ajax_rzd_sala_served', function () {
	rzd_sala_guard();
	$o      = rzd_sala_req_order();
	$n      = (int) rzd_sala_post( 'round', 0 );
	$rounds = rzd_sala_rounds( $o );
	foreach ( $rounds as &$r ) {
		if ( (int) $r['n'] === $n ) {
			$r['status'] = 'served';
			$r['served'] = time();
		}
	}
	unset( $r );
	$o->update_meta_data( '_rzd_rounds', $rounds );
	$o->save();
	wp_send_json( array( 'ok' => true, 'order' => rzd_sala_order_data( $o ) ) );
} );

// Usunięcie pozycji (storno przed zapłatą) – notatka z powodem; pusty rachunek = anulowany, stolik wolny.
add_action( 'wp_ajax_rzd_sala_void', function () {
	rzd_sala_guard();
	$o    = rzd_sala_req_order();
	$iid  = absint( rzd_sala_post( 'item', 0 ) );
	$item = $o->get_item( $iid );
	if ( ! $item ) {
		wp_send_json( array( 'ok' => false, 'msg' => 'Nie ma już tej pozycji.' ) );
	}
	$why = trim( sanitize_text_field( (string) rzd_sala_post( 'why', '' ) ) );
	$o->add_order_note( 'Sala: usunięto „' . $item->get_name() . '” ×' . (int) $item->get_quantity() . ( '' !== $why ? ' – powód: ' . $why : '' ) . ( rzd_sala_user_name() ? ' (' . rzd_sala_user_name() . ')' : '' ) . '.' );
	$o->remove_item( $iid );
	if ( ! count( $o->get_items() ) ) {
		$o->update_meta_data( '_rzd_rounds', array() );
		rzd_sala_recalc( $o );
		$o->set_status( 'cancelled', 'Sala: rachunek bez pozycji – anulowany, stolik wolny.' );
		$o->save();
		wp_send_json( array( 'ok' => true, 'order' => null ) );
	}
	rzd_sala_recalc( $o );
	$o->save();
	wp_send_json( array( 'ok' => true, 'order' => rzd_sala_order_data( $o ) ) );
} );

// Rachunek: zapłata gotówką / kartą, zamknięcie.
add_action( 'wp_ajax_rzd_sala_pay', function () {
	rzd_sala_guard();
	$o      = rzd_sala_req_order();
	$method = sanitize_key( (string) rzd_sala_post( 'method' ) );
	$titles = array( 'cash' => 'Gotówka', 'card' => 'Karta' );
	if ( ! isset( $titles[ $method ] ) ) {
		wp_send_json( array( 'ok' => false, 'msg' => 'Wybierz: gotówka albo karta.' ) );
	}
	$total  = (float) $o->get_total();
	$given  = str_replace( array( ',', ' ', 'zł' ), array( '.', '', '' ), (string) rzd_sala_post( 'given', '' ) );
	$given  = ( 'cash' === $method && '' !== $given && is_numeric( $given ) ) ? round( (float) $given, 2 ) : null;
	if ( null !== $given && $given + 0.001 < $total ) {
		wp_send_json( array( 'ok' => false, 'msg' => 'Otrzymano mniej niż do zapłaty (' . rzd_sala_money( $total ) . ').' ) );
	}
	$change = null !== $given ? round( $given - $total, 2 ) : null;
	$o->set_payment_method( 'rzd_' . $method );
	$o->set_payment_method_title( $titles[ $method ] );
	$o->set_date_paid( time() );
	$o->update_meta_data( '_rzd_paid_method', $method );
	$o->update_meta_data( '_rzd_closed_by', get_current_user_id() );
	if ( null !== $given ) {
		$o->update_meta_data( '_rzd_cash_given', $given );
		$o->update_meta_data( '_rzd_cash_change', $change );
	}
	$o->update_meta_data( '_dc_delivered_at', current_time( 'Y-m-d H:i' ) );
	$o->set_status( 'wydane', 'Sala: rachunek zamknięty – ' . $titles[ $method ] . ' ' . rzd_sala_money( $total ) . ( null !== $change ? ' (otrzymano ' . rzd_sala_money( $given ) . ', reszta ' . rzd_sala_money( $change ) . ')' : '' ) . ( rzd_sala_user_name() ? ' – ' . rzd_sala_user_name() : '' ) . '.' );
	$o->save();
	wp_send_json( array( 'ok' => true, 'change' => $change, 'change_html' => null !== $change ? rzd_sala_money( $change ) : '' ) );
} );
