<?php
/**
 * Moduł 10-modyfikacje – koszyk: dopłata do ceny i wyszczególnienie.
 * Część modułu (pliki wczytywane po kolei – kolejność jak w dawnym jednym pliku).
 */

/* ============================================================
 * 4. KOSZYK: dopłata do ceny pozycji + wyszczególnienie modyfikacji
 * ============================================================ */
add_filter( 'woocommerce_add_cart_item_data', function ( $data, $product_id ) {
	if ( ! rzd_get_modifier_groups( $product_id ) ) {
		return $data;
	}
	$sel = rzd_read_selection( $product_id );
	// zawsze (także bez wyboru) – podstawa edycji w koszyku.
	$data['rzd_raw'] = rzd_sanitize_raw_selection( ( isset( $_POST['rzd_mod'] ) && is_array( $_POST['rzd_mod'] ) ) ? wp_unslash( $_POST['rzd_mod'] ) : array() );
	if ( $sel['lines'] ) {
		$data['rzd_mods']       = $sel['lines'];
		$data['rzd_mods_delta'] = $sel['delta'];
		$data['rzd_usage']      = $sel['usage']; // maszynowe dane dla kuchni/raportów
		$data['rzd_base_price'] = (float) wc_get_product( $product_id )->get_price();
		// różny wybór modyfikacji = osobna pozycja w koszyku
		$data['unique_key'] = md5( wp_json_encode( $sel['lines'] ) . microtime() );
	}
	return $data;
}, 10, 2 );

add_action( 'woocommerce_before_calculate_totals', function ( $cart ) {
	if ( is_admin() && ! defined( 'DOING_AJAX' ) ) {
		return;
	}
	foreach ( $cart->get_cart() as $item ) {
		if ( isset( $item['rzd_base_price'], $item['rzd_mods_delta'] ) ) {
			$item['data']->set_price( max( 0, (float) $item['rzd_base_price'] + (float) $item['rzd_mods_delta'] ) );
		}
	}
}, 20 );

/**
 * Opis modyfikacji w koszyku, kasie, zamówieniu i mailach – w czterech
 * rodzajach (rzd_mod_kind): "Wybór w zestawie", "Dodatki (płatne)",
 * "Obowiązkowe", "Bez". Pola tekstowe zostają jako własne linijki.
 * Zwraca gotowe pary [ ['key','value'], … ] do wyświetlenia/zapisu.
 */
function rzd_group_mod_lines_for_display( $lines ) {
	$groups = array_fill_keys( array_keys( rzd_mod_kind_labels() ), array() );
	$out    = array();

	foreach ( $lines as $l ) {
		$role = isset( $l['role'] ) ? $l['role'] : 'dodaje';
		$qty  = isset( $l['qty'] ) ? (int) $l['qty'] : 1;

		if ( 'tekst' === $role ) {
			$out[] = array( 'key' => $l['name'], 'value' => $l['label'] . rzd_format_delta( $l['price'] ) );
			continue;
		}
		// Pozycje z koszyka sprzed 2.24.0 nie mają 'kind' – liczymy z roli i ceny.
		$kind = ! empty( $l['kind'] ) ? $l['kind'] : rzd_mod_kind( $role, isset( $l['price'] ) ? $l['price'] : 0 );
		$ile  = ( $qty > 1 ) ? ( $qty . '× ' ) : '';
		// "Wybór w zestawie" nie zmienia ceny – bez kwoty, żeby nie mylić.
		$groups[ $kind ][] = $ile . $l['name'] . ( 'zestaw' === $kind ? '' : rzd_format_delta( $l['price'] ) );
	}

	foreach ( rzd_mod_kind_labels() as $kind => $label ) {
		if ( $groups[ $kind ] ) {
			$out[] = array( 'key' => $label, 'value' => implode( ', ', $groups[ $kind ] ) );
		}
	}
	return $out;
}

add_filter( 'woocommerce_get_item_data', function ( $item_data, $cart_item ) {
	if ( ! empty( $cart_item['rzd_mods'] ) ) {
		$item_data = array_merge( $item_data, rzd_group_mod_lines_for_display( $cart_item['rzd_mods'] ) );
	}
	return $item_data;
}, 10, 2 );

add_action( 'woocommerce_checkout_create_order_line_item', function ( $item, $cart_item_key, $values, $order ) {
	if ( ! empty( $values['rzd_mods'] ) ) {
		foreach ( rzd_group_mod_lines_for_display( $values['rzd_mods'] ) as $l ) {
			$item->add_meta_data( $l['key'], $l['value'], true );
		}
	}
	// Dane maszynowe dla kuchni/raportów – ukryty meta klucz (prefiks "_"),
	// nie pokazuje się klientowi ani na standardowym widoku zamówienia.
	if ( ! empty( $values['rzd_usage'] ) ) {
		$item->add_meta_data( '_rzd_addon_usage', wp_json_encode( $values['rzd_usage'] ), true );
	}
}, 10, 4 );

// Panel administratora WooCommerce pokazuje w pozycjach także pola z prefiksem
// "_" (ukrywa je tylko przed klientem, w mailach i na stronie zamówienia) –
// dlatego surowy JSON z _rzd_addon_usage wyświetlał się pod każdą pozycją.
// Dopisujemy go do listy pól ukrywanych w tym widoku. Dane nadal są zapisane
// i czytane przez Kuchnię i Raporty – znika tylko wyświetlanie.
add_filter( 'woocommerce_hidden_order_itemmeta', function ( $hidden ) {
	$hidden[] = '_rzd_addon_usage';
	return $hidden;
} );

/**
 * Odczyt maszynowych danych o użytych dodatkach z pozycji zamówienia –
 * używane przez moduł 12 (Kuchnia) i moduł 09 (Raporty).
 * Zwraca: [ ['addon_id','name','qty','role'], … ]
 */
function rzd_item_addon_usage( $item ) {
	$raw = $item->get_meta( '_rzd_addon_usage' );
	if ( ! $raw ) {
		return array();
	}
	$data = json_decode( $raw, true );
	return is_array( $data ) ? $data : array();
}

