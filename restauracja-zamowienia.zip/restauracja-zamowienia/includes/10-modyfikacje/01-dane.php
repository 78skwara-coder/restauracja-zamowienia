<?php
/**
 * MODUŁ 10: Możliwe modyfikacje produktu (wersja 3 — Dodatki + Składniki)
 *
 * UWAGA: to jest przebudowa architektury, świadomie BEZ migracji starych
 * danych (stara, płaska konfiguracja modyfikacji przestaje działać —
 * ustawienia trzeba wprowadzić na nowo).
 *
 * Model: GRUPA (nagłówek + opis) → MODYFIKACJE. Każda modyfikacja typu
 * radio/tap/stepper NIE MA własnej nazwy/ceny/ikony – zamiast tego wskazuje
 * na wcześniej zdefiniowany DODATEK (moduł 14: nazwa, cena "przy dodaniu",
 * cena "przy odejmowaniu", ikonka, czy obowiązkowy) i deklaruje swoją ROLĘ
 * wobec niego:
 *  - dodaje       – aktywacja DOLICZA cenę dodatku (np. "Dodatkowe mięso")
 *  - odejmuje     – aktywacja ODEJMUJE cenę "przy odejmowaniu" (np. "Bez mięsa")
 *  - neutralna    – bez wpływu na cenę i bez wpływu na inne modyfikacje
 *  - obowiązkowa  – zawsze aktywna, klient nie może jej wyłączyć/zmienić
 *  - dezaktywuje  – jak "odejmuje", DODATKOWO blokuje w tym samym formularzu
 *                   wszystkie inne modyfikacje tego samego dodatku (np.
 *                   "ani frytki, ani ziemniaki")
 *
 * Ten sam dodatek użyty w kilku miejscach (np. "Mięso" jako "dodaje" w
 * jednym miejscu i jako "odejmuje"/"dezaktywuje" gdzie indziej) wzajemnie
 * się BLOKUJE: aktywacja jednego wyszarza pozostałe, żeby nie dało się
 * jednocześnie dodać i zdjąć to samo. Dodatek oznaczony w katalogu jako
 * "obowiązkowy" jest zawsze zablokowany do edycji, niezależnie od roli –
 * ale nadal POKAZUJE SIĘ w oknie wyboru (klient ma widzieć, za co płaci).
 *
 * SKŁAD I TYP – jak dodatek "wie", jaki dokładnie składnik zmienić:
 * Produkt może mieć zdefiniowany SKŁAD (sekcja niżej w tej samej zakładce)
 * – listę Składników (moduł 14: sama nazwa + typ, bez ceny), wyłącznie do
 * WYŚWIETLANIA ("nazwa produktu + skład" wszędzie, gdzie dotąd sama nazwa).
 * Jeśli Dodatek ma ustawiony TYP, to w chwili użycia system szuka w Składzie
 * TEGO KONKRETNEGO produktu Składnika tego samego typu i pokazuje klientowi
 * JEGO nazwę (np. Dodatek "Mięso" na Schabowym pokaże się jako "Kotlet
 * schabowy", na Sznyclu jako "Kotlet z kurczaka") – ale CENA zawsze
 * pochodzi z Dodatku, nigdy ze Składnika (Składnik ceny nie ma). Dodatek
 * bez typu (np. "Opakowanie") działa wprost, swoją własną nazwą i ceną,
 * niezależnie od Składu. Dodatek z typem, dla którego produkt nie ma w
 * Składzie pasującego Składnika, po prostu nie pokazuje się dla tego
 * produktu (patrz rzd_resolve_addon_name_for_product).
 *
 * Typ "text" (samo pole tekstowe) zostaje BEZ ZMIAN – nie odwołuje się do
 * dodatku, ma własną nazwę/cenę/podpowiedź, bo to wolny tekst (np. grawer
 * imienia), nie policzalna pozycja magazynowa dla kuchni.
 *
 * Wybrane modyfikacje (poza "text") trafiają do zamówienia PODWÓJNIE:
 * jako czytelny opis dla klienta (jak dotąd) ORAZ jako ukryte, maszynowo
 * czytelne dane (_rzd_addon_usage) – to na nich opiera się liczenie
 * dodatków w module 12 (Kuchnia) i module 09 (Raporty), niezależnie od
 * tego, w ilu różnych produktach/modyfikacjach dany dodatek jest użyty.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * RODZAJ modyfikacji – żeby kuchnia wiedziała, czy frytki to
 * dodatek płatny, czy wybór w ramach ceny zestawu:
 *  - zestaw      "Wybór w zestawie:" – nie zmienia ceny (np. ziemniaki/frytki do ryby)
 *  - dodatki     "Dodatki (płatne):" – dopłata > 0
 *  - obowiazkowe "Obowiązkowe:"      – rola obowiązkowa albo Dodatek obowiązkowy (np. opakowanie), także płatne
 *  - bez         "Bez:"              – odejmuje / dezaktywuje
 * Napis "W zestawie" jest zajęty przez skład zestawu dnia (moduł 04) – stąd "Wybór w zestawie".
 */
function rzd_mod_kind( $role, $price, $mandatory = false ) {
	if ( 'tekst' === $role ) {
		return 'tekst';
	}
	if ( in_array( $role, array( 'odejmuje', 'dezaktywuje' ), true ) ) {
		return 'bez';
	}
	if ( 'obowiazkowa' === $role || $mandatory ) {
		return 'obowiazkowe';
	}
	return ( (float) $price > 0.001 ) ? 'dodatki' : 'zestaw';
}

function rzd_mod_kind_labels() {
	return array(
		'zestaw'      => 'Wybór w zestawie',
		'dodatki'     => 'Dodatki (płatne)',
		'obowiazkowe' => 'Obowiązkowe',
		'bez'         => 'Bez',
	);
}

// Rodzaj wpisu z _rzd_addon_usage; zamówienia sprzed 2.24.0 nie mają 'kind' – zgadujemy z roli.
function rzd_usage_kind( $u ) {
	if ( ! empty( $u['kind'] ) ) {
		return $u['kind'];
	}
	$map = array( 'odejmuje' => 'bez', 'dezaktywuje' => 'bez', 'obowiazkowa' => 'obowiazkowe', 'neutralna' => 'zestaw' );
	$r   = isset( $u['role'] ) ? $u['role'] : 'dodaje';
	return isset( $map[ $r ] ) ? $map[ $r ] : 'dodatki';
}

// Etykieta rodzaju w Kuchni i raportach ('danie' = pozycja/danie, nie modyfikacja).
function rzd_kind_label( $kind ) {
	$l = rzd_mod_kind_labels();
	if ( 'danie' === $kind ) {
		return 'Danie/produkt';
	}
	if ( 'dodatki' === $kind ) {
		return 'Dodatek płatny';
	}
	if ( 'opakowanie' === $kind ) {
		return 'Opakowanie'; // moduł 21
	}
	return isset( $l[ $kind ] ) ? $l[ $kind ] : 'Dodatek';
}

function rzd_modifier_roles() {
	return array(
		'dodaje'      => 'Dodaje (dolicza cenę dodatku)',
		'odejmuje'    => 'Odejmuje (odejmuje cenę dodatku)',
		'neutralna'   => 'Neutralna (bez wpływu na cenę)',
		'obowiazkowa' => 'Obowiązkowa (zawsze aktywna)',
		'dezaktywuje' => 'Dezaktywuje (np. "ani jedno, ani drugie") – odejmuje cenę I blokuje inne modyfikacje tego samego typu',
	);
}

/* ============================================================
 * 0. DANE
 * ============================================================ */
function rzd_get_sections( $product_id ) {
	$data = get_post_meta( $product_id, '_rzd_modifiers', true );
	if ( ! is_array( $data ) ) {
		return array();
	}
	// miejsce wyboru ustawia się na GRUPIE (sekcji) – każda modyfikacja
	// dostaje je stąd, więc reszta kodu (rzd_group_place) czyta $g['place'] jak wcześniej.
	$data = array_values( $data );
	foreach ( $data as $si => $section ) {
		$place = rzd_section_place( $section );
		if ( isset( $section['items'] ) && is_array( $section['items'] ) ) {
			foreach ( $section['items'] as $mi => $mod ) {
				$data[ $si ]['items'][ $mi ]['place'] = $place;
			}
		}
	}
	return $data;
}

/**
 * miejsce wyboru grupy – 'before' albo 'cart' (przegląd zamówienia).
 * Grupy zapisane w 2.26.16 nie mają pola – wtedy 'cart', jeśli któraś
 * modyfikacja miała je ustawione pojedynczo (przeniesienie ustawienia).
 */
function rzd_section_place( $section ) {
	if ( isset( $section['place'] ) ) {
		return 'cart' === $section['place'] ? 'cart' : 'before';
	}
	foreach ( ( isset( $section['items'] ) ? (array) $section['items'] : array() ) as $mod ) {
		if ( isset( $mod['place'] ) && 'cart' === $mod['place'] ) {
			return 'cart';
		}
	}
	return 'before';
}

/**
 * Sekcje modyfikacji, które FAKTYCZNIE obowiązują przy dodawaniu produktu do
 * koszyka. Zwykły produkt – jego własne sekcje. ZESTAW – najpierw sekcje
 * dań aktywnych na wybrany dzień (w kolejności z "Roli w zestawie", każda
 * sekcja z nazwą dania w nagłówku), a na końcu własne sekcje samego zestawu
 * (np. torba). Każda sekcja niesie 'src' = ID produktu, od którego pochodzi –
 * to wg jego SKŁADU rozwiązują się nazwy dodatków "po typie".
 * To jedno źródło prawdy: okno wyboru, odczyt wyboru i koszyk czytają ją
 * tak samo, więc numeracja pól (index) zawsze się zgadza.
 */
function rzd_get_effective_sections( $product_id, $depth = 0 ) {
	static $memo = array();
	$sel_date = ( function_exists( 'rzd_dc_selected_date' ) && rzd_dc_selected_date() ) ? rzd_dc_selected_date() : '';
	$key      = $product_id . '|' . $sel_date;
	if ( 0 === $depth && isset( $memo[ $key ] ) ) {
		return $memo[ $key ];
	}

	$out = array();
	if ( $depth < 3 && function_exists( 'rzd_zestaw_get_slots' ) && rzd_zestaw_get_slots( $product_id ) ) {
		$active = rzd_zestaw_get_active_components( $product_id );
		$via    = isset( $active['via'] ) ? $active['via'] : array();

		// Zestawy pośrednie (np. "Zupa dnia" wpięta w "Zestaw dnia"): ich WŁASNE
		// sekcje (np. opakowanie) dokładamy raz, zaraz po ostatnim daniu, które
		// przez nie przyszło. Najpierw najgłębszy zestaw, potem zewnętrzny.
		$via_last  = array(); // id zestawu pośredniego => id ostatniego dania z niego
		$via_count = array(); // id zestawu pośredniego => ile dań przez niego przyszło
		foreach ( $active['main'] as $comp ) {
			$cid = (int) $comp->get_id();
			if ( empty( $via[ $cid ] ) ) {
				continue;
			}
			foreach ( $via[ $cid ] as $mid ) {
				$via_last[ $mid ]  = $cid;
				$via_count[ $mid ] = ( isset( $via_count[ $mid ] ) ? $via_count[ $mid ] : 0 ) + 1;
			}
		}

		foreach ( $active['main'] as $comp ) {
			$cid = (int) $comp->get_id();
			if ( $cid === (int) $product_id ) {
				continue;
			}
			$label = isset( $active['roles'][ $cid ]['label'] ) ? $active['roles'][ $cid ]['label'] : '';
			$dish  = ( $label ? $label . ': ' : '' ) . $comp->get_name();
			foreach ( rzd_get_effective_sections( $cid, $depth + 1 ) as $sec ) {
				$head          = isset( $sec['header'] ) ? trim( $sec['header'] ) : '';
				$sec['header'] = $dish . ( '' !== $head ? ' — ' . $head : '' );
				$out[]         = $sec;
			}

			if ( empty( $via[ $cid ] ) ) {
				continue;
			}
			foreach ( array_reverse( $via[ $cid ] ) as $mid ) {
				if ( $via_last[ $mid ] !== $cid || (int) $mid === (int) $product_id ) {
					continue;
				}
				$single = ( 1 === $via_count[ $mid ] );
				if ( $single ) {
					// Jedno danie z tego zestawu: sekcja występuje pod nazwą dania
					// i rozwiązuje się wg JEGO składu (dodatki z Typem, blokady).
					$m_head = $dish;
					$m_src  = $cid;
				} else {
					$mp     = wc_get_product( $mid );
					$m_head = ( $label ? $label . ': ' : '' ) . ( $mp ? $mp->get_name() : '' );
					$m_src  = (int) $mid;
				}
				foreach ( rzd_get_sections( $mid ) as $sec ) {
					$head          = isset( $sec['header'] ) ? trim( $sec['header'] ) : '';
					$sec['header'] = $m_head . ( '' !== $head ? ' — ' . $head : '' );
					$sec['src']    = $m_src;
					$out[]         = $sec;
				}
			}
		}
	}
	foreach ( rzd_get_sections( $product_id ) as $section ) {
		$section['src'] = (int) $product_id;
		$out[]          = $section;
	}

	if ( 0 === $depth ) {
		$memo[ $key ] = $out;
	}
	return $out;
}

// Spłaszczona lista WSZYSTKICH modyfikacji ze wszystkich obowiązujących sekcji, w kolejności.
// Każda niesie '_src' – produkt, wg którego składu rozwiązują się jej dodatki.
function rzd_get_modifier_groups( $product_id ) {
	$flat = array();
	foreach ( rzd_get_effective_sections( $product_id ) as $section ) {
		foreach ( (array) $section['items'] as $mod ) {
			$mod['_src'] = isset( $section['src'] ) ? (int) $section['src'] : (int) $product_id;
			$flat[]      = $mod;
		}
	}
	return $flat;
}

function rzd_products_with_modifiers() {
	static $ids = null;
	if ( null === $ids ) {
		global $wpdb;
		// Także ZESTAWY (mają harmonogram _rwz_slots): ich okno składa się z modyfikacji
		// dań na wybrany dzień, więc trzeba je zapytać, nawet gdy sam zestaw nie ma własnych.
		$ids = array_map( 'intval', $wpdb->get_col( "SELECT DISTINCT post_id FROM {$wpdb->postmeta} WHERE meta_key IN ( '_rzd_modifiers', '_rwz_slots' )" ) );
	}
	return $ids;
}

/**
 * Dodatki obowiązkowe (rolą "obowiązkowa" albo z flagi w katalogu Dodatki)
 * na typach tap/stepper – klient i tak ich nie wybiera, więc pokazujemy je
 * jako informację, a nie jako coś do skonfigurowania w oknie wyboru.
 * Zwraca: [ ['name','price','qty'], … ]
 */
function rzd_get_mandatory_addons( $product_id ) {
	$out = array();
	foreach ( rzd_get_modifier_groups( $product_id ) as $g ) {
		if ( ! in_array( $g['type'], array( 'tap', 'stepper' ), true ) ) {
			continue; // "obowiązkowa" ma sens tylko dla pojedynczego dodatku, nie dla wyboru/pola tekstowego
		}
		$addon = rzd_get_addon( $g['addon_id'] );
		if ( ! $addon ) {
			continue;
		}
		if ( 'obowiazkowa' === $g['role'] || $addon['mandatory'] ) {
			$qty   = ( 'stepper' === $g['type'] ) ? max( 1, (int) $g['min'] ) : 1;
			$out[] = array( 'name' => $addon['name'], 'price' => (float) $addon['price'], 'qty' => $qty );
		}
	}
	return $out;
}

// Notatka pod nazwą produktu na liście: "(do produktu zostanie dodany X o wartości Y)"
add_filter( 'rest_produkt_obowiazkowe_dodatki', function ( $html, $product_id ) {
	$mandatory = rzd_get_mandatory_addons( $product_id );
	if ( ! $mandatory ) {
		return $html;
	}
	$parts = array();
	foreach ( $mandatory as $m ) {
		$ile     = ( $m['qty'] > 1 ) ? ( $m['qty'] . '× ' ) : '';
		$parts[] = sprintf(
			'do produktu zostanie dodany %s%s o wartości %s',
			esc_html( $ile ),
			esc_html( $m['name'] ),
			esc_html( html_entity_decode( wp_strip_all_tags( wc_price( $m['price'] ) ), ENT_QUOTES, 'UTF-8' ) )
		);
	}
	return '(' . implode( '; ', $parts ) . ')';
}, 10, 2 );

function rzd_format_delta( $delta ) {
	$delta = (float) $delta;
	if ( abs( $delta ) < 0.0001 ) {
		return '';
	}
	$sign = $delta > 0 ? '+' : '';
	// wp_strip_all_tags + html_entity_decode: wc_price() zwraca HTML i encje
	// (np. "&#322;" zamiast "ł") – w polach wypełnianych przez JS przez
	// textContent musi to być zwykły, gotowy do wyświetlenia tekst.
	return ' (' . $sign . html_entity_decode( wp_strip_all_tags( wc_price( $delta ) ), ENT_QUOTES, 'UTF-8' ) . ')';
}

