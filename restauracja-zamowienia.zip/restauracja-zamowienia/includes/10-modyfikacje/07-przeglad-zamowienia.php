<?php
/**
 * Moduł 10-modyfikacje – przegląd zamówienia.
 * Część modułu (pliki wczytywane po kolei – kolejność jak w dawnym jednym pliku).
 */

/* ============================================================
 * 6. PRZEGLĄD ZAMÓWIENIA – okno po „Przejdź do koszyka”
 * ============================================================
 * Lista pozycji koszyka: ilość × nazwa, zdjęcie, skład, wybrane modyfikacje,
 * przycisk „Dodatki płatne” (okno w trybie koszyka – modyfikacje z miejscem
 * „w koszyku”). Zestawy: dania z ich składem + ten sam przycisk (grupy dań). Na dole
 * podsumowanie bez dostawy (dostawa liczy się w koszyku).
 */
function rzd_review_names( $product_id ) {
	$out = array();
	if ( function_exists( 'rzd_get_product_sklad' ) ) {
		foreach ( rzd_get_product_sklad( $product_id ) as $ing ) {
			$out[] = $ing['name'];
		}
	}
	return $out;
}

/**
 * kosz w przeglądzie zamówienia – usunięcie pozycji „w ostatniej chwili”
 * i „Cofnij” (WooCommerce trzyma usuniętą pozycję w sesji: restore_cart_item).
 * Nonce ten sam co zapis dodatków (rzd_mods_save).
 */
function rzd_review_cart_action( $restore ) {
	if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'rzd_mods_save' ) ) {
		wp_send_json( array( 'ok' => false, 'msg' => 'Sesja wygasła – odśwież stronę.' ) );
	}
	$cart = ( function_exists( 'WC' ) && WC()->cart ) ? WC()->cart : null;
	$key  = isset( $_POST['cart_key'] ) ? sanitize_text_field( wp_unslash( $_POST['cart_key'] ) ) : '';
	if ( ! $cart || '' === $key ) {
		wp_send_json( array( 'ok' => false, 'msg' => 'Nie znaleziono pozycji.' ) );
	}
	if ( $restore ) {
		$done = $cart->restore_cart_item( $key );
	} else {
		$done = $cart->get_cart_item( $key ) ? $cart->remove_cart_item( $key ) : false;
	}
	if ( ! $done ) {
		wp_send_json( array( 'ok' => false, 'msg' => $restore ? 'Nie udało się przywrócić pozycji.' : 'Tej pozycji nie ma już w koszyku.' ) );
	}
	$cart->calculate_totals();
	wp_send_json( array( 'ok' => true, 'empty' => $cart->is_empty() ) );
}
add_action( 'wc_ajax_rzd_review_remove', function () { rzd_review_cart_action( false ); } );
add_action( 'wc_ajax_rzd_review_restore', function () { rzd_review_cart_action( true ); } );

add_action( 'wc_ajax_rzd_review', function () {
	$cart = ( function_exists( 'WC' ) && WC()->cart ) ? WC()->cart : null;
	// kontrola zestawów (moduł 04) – przeterminowane / bez dania / zmieniony skład.
	$notes = ( $cart && function_exists( 'rwz_cart_sync' ) ) ? rwz_cart_sync( false ) : array();
	if ( ! $cart || $cart->is_empty() ) {
		foreach ( $notes as $m ) {
			wc_add_notice( $m, 'error' ); // okienko przejdzie do koszyka – tam zobaczy komunikat
		}
		wp_send_json( array( 'ok' => true, 'items' => array() ) );
	}
	$cart->calculate_totals();
	$items = array();
	foreach ( $cart->get_cart() as $key => $it ) {
		$pid  = (int) $it['product_id'];
		$prod = $it['data'];
		$img  = $prod ? wp_get_attachment_image_url( $prod->get_image_id(), 'woocommerce_thumbnail' ) : '';
		$is_set = ! empty( $it['rwz_components'] ) || ( function_exists( 'rwz_get_slots' ) && rwz_get_slots( $pid ) );
		if ( $is_set && function_exists( 'rwz_split_image_html' ) ) { // zdjęcie dzielone zestawu
			$split = rwz_split_image_html( $pid, 'woocommerce_thumbnail', array(), true );
			$img   = $split ? $split : $img;
		}
		$comps  = array();
		$raw    = isset( $it['rzd_raw'] ) ? (array) $it['rzd_raw'] : null;
		// skład po wyborze klienta (zamiana dodatku tego samego typu, „Bez …”); bez zapisanego wyboru – skład dania
		$names_of = function ( $src ) use ( $pid, $raw ) {
			return null !== $raw ? rzd_effective_sklad_names( $pid, $src, $raw ) : rzd_review_names( $src );
		};
		if ( $is_set ) {
			$active = function_exists( 'rwz_get_active_components' ) ? rwz_get_active_components( $pid ) : array();
			if ( ! empty( $active['main'] ) ) {
				foreach ( $active['main'] as $c ) {
					if ( (int) $c->get_id() === $pid ) {
						continue;
					}
					$comps[] = array(
						'id'    => (int) $c->get_id(),
						'name'  => $c->get_name(),
						'img'   => wp_get_attachment_image_url( $c->get_image_id(), 'thumbnail' ) ?: '',
						'sklad' => $names_of( (int) $c->get_id() ),
					);
				}
			} elseif ( ! empty( $it['rwz_components'] ) ) {
				foreach ( (array) $it['rwz_components'] as $n ) {
					$comps[] = array( 'name' => wp_strip_all_tags( $n ), 'img' => '', 'sklad' => array() );
				}
			}
		}
		// „Wybór w zestawie” (wybór bez wpływu na cenę, np. Frytki) dopisujemy do
		// składu – zwykłe danie: do jego składu; zestaw: do składu dania, z którego pochodzi
		// wybór (src w linii; pozycje sprzed 2.26.18 bez src zostają w modyfikacjach).
		// Dopłaty, „Bez” i obowiązkowe zostają jako osobne linie.
		$rest   = array();
		$sk_add = array(); // klucz: 0 = samo danie, id = danie zestawu
		foreach ( ! empty( $it['rzd_mods'] ) ? (array) $it['rzd_mods'] : array() as $l ) {
			$role = isset( $l['role'] ) ? $l['role'] : 'dodaje';
			$kind = ! empty( $l['kind'] ) ? $l['kind'] : ( 'tekst' === $role ? '' : rzd_mod_kind( $role, isset( $l['price'] ) ? $l['price'] : 0 ) );
			// także KAŻDY pojedynczy wybór (pick), z dopłatą lub odjęciem – np. „Bez dodatków”
			// z wymaganego wyboru to też skład; kwota w nawiasie, żeby klient widział zmianę ceny.
			$pick = ! empty( $l['pick'] );
			if ( 'tekst' === $role || 'bez' === $kind || ( 'zestaw' !== $kind && ! $pick ) ) { // „Bez dodatku” z wyboru – do linii „Bez:”, nie do składu
				$rest[] = $l;
				continue;
			}
			$q    = isset( $l['qty'] ) ? (int) $l['qty'] : 1;
			$name = ( $q > 1 ? $q . '× ' : '' ) . $l['name'] . ( 'zestaw' === $kind ? '' : rzd_format_delta( isset( $l['price'] ) ? $l['price'] : 0 ) );
			if ( ! $is_set ) {
				$sk_add[0][] = $name;
			} elseif ( ! empty( $l['src'] ) ) {
				$sk_add[ (int) $l['src'] ][] = $name;
			} else {
				$rest[] = $l;
			}
		}
		// dopisanie wyboru do składu: ta sama nazwa już jest (skład po wyborze) – zostaje,
		// tylko z kwotą w nawiasie, jeśli wybór zmienia cenę; inaczej – dopisany na końcu
		$add_to = function ( $list, $extra ) {
			$low = array_map( 'mb_strtolower', $list );
			foreach ( $extra as $n ) {
				$base = mb_strtolower( preg_replace( '/^\d+× /u', '', preg_replace( '/ \([^()]*\)$/u', '', $n ) ) );
				$at   = array_search( $base, $low, true );
				if ( false !== $at ) {
					$list[ $at ] = $n;
					$low[ $at ]  = mb_strtolower( $n );
				} elseif ( ! in_array( mb_strtolower( $n ), $low, true ) ) {
					$list[] = $n;
					$low[]  = mb_strtolower( $n );
				}
			}
			return $list;
		};
		$sklad = $is_set ? array() : $names_of( $pid );
		if ( ! empty( $sk_add[0] ) ) {
			$sklad = $add_to( $sklad, $sk_add[0] );
		}
		if ( $is_set ) {
			foreach ( $comps as $ci => $c ) {
				if ( ! empty( $c['id'] ) && ! empty( $sk_add[ $c['id'] ] ) ) {
					$comps[ $ci ]['sklad'] = $add_to( $c['sklad'], $sk_add[ $c['id'] ] );
					unset( $sk_add[ $c['id'] ] );
				}
			}
			// wybór z dania, którego nie ma na liście dań (inny termin) – nie gubimy go
			foreach ( $sk_add as $sid => $names ) {
				if ( $sid ) {
					foreach ( $names as $n ) {
						$rest[] = array( 'name' => $n, 'label' => $n, 'price' => 0, 'role' => 'neutralna', 'qty' => 1, 'kind' => 'zestaw' );
					}
				}
			}
		}
		$mods = array();
		if ( $rest ) {
			foreach ( rzd_group_mod_lines_for_display( $rest ) as $l ) {
				$mods[] = array( 'k' => $l['key'], 'v' => wp_strip_all_tags( html_entity_decode( $l['value'], ENT_QUOTES, 'UTF-8' ) ) );
			}
		}
		$items[] = array(
			'key'     => $key,
			'qty'     => (int) $it['quantity'],
			'name'    => $prod ? $prod->get_name() : get_the_title( $pid ),
			'img'     => $img ?: '',
			'sklad'   => $sklad,
			'comps'   => $comps,
			'mods'    => $mods,
			'total'   => wc_price( (float) $it['line_subtotal'] + (float) $it['line_subtotal_tax'] ),
			// Zestaw też: okno pokazuje grupy „w koszyku” jego dań, każda sekcja
			// pod nazwą dania.
			'can_add' => isset( $it['rzd_raw'] ) && rzd_product_has_cart_groups( $pid ),
		);
	}
	$sum   = array();
	$total = (float) $cart->get_subtotal() + (float) $cart->get_subtotal_tax();
	$sum[] = array( 'label' => 'Produkty', 'value' => wc_price( $total ) );
	foreach ( $cart->get_fees() as $fee ) {
		$v      = (float) $fee->total + (float) $fee->tax;
		$total += $v;
		$sum[]  = array( 'label' => $fee->name, 'value' => wc_price( $v ) );
	}
	$disc = (float) $cart->get_discount_total() + (float) $cart->get_discount_tax();
	if ( $disc > 0 ) {
		$total -= $disc;
		$sum[]  = array( 'label' => 'Rabat', 'value' => wc_price( -1 * $disc ) );
	}
	// dostawa (gdy już wybrana) – „Razem” jak w koszyku i przy ikonie koszyka.
	$ship = (float) $cart->get_shipping_total() + (float) $cart->get_shipping_tax();
	$ship_label = rzd_review_shipping_label();
	$has_ship   = ( $ship > 0 || '' !== $ship_label );
	if ( $has_ship ) {
		$total += $ship;
		$sum[]  = array( 'label' => '' !== $ship_label ? $ship_label : 'Dostawa', 'value' => wc_price( $ship ) );
	}
	wp_send_json( array(
		'ok'      => true,
		'notices' => array_values( $notes ),
		'items'   => $items,
		'summary' => $sum,
		'total'   => wc_price( $total ),
		'shipping' => $has_ship, // JS nie dopisuje wtedy „+ dostawa – w koszyku”
	) );
} );

// Nazwa wybranej metody dostawy (np. „Dostawa - Piła - Dolaszewo”), '' gdy nic nie wybrano.
function rzd_review_shipping_label() {
	if ( ! function_exists( 'WC' ) || ! WC()->session || ! WC()->shipping() ) {
		return '';
	}
	$chosen = (array) WC()->session->get( 'chosen_shipping_methods', array() );
	foreach ( WC()->shipping()->get_packages() as $i => $pkg ) {
		$id = isset( $chosen[ $i ] ) ? $chosen[ $i ] : '';
		if ( $id && isset( $pkg['rates'][ $id ] ) ) {
			return wp_strip_all_tags( $pkg['rates'][ $id ]->get_label() );
		}
	}
	return '';
}

// skrypt okienka modyfikacji jako plik (wcześniej w stopce każdej strony).
add_action( 'wp_enqueue_scripts', function () {
	$products = rzd_products_with_modifiers();
	if ( ! $products ) {
		return;
	}
	wp_enqueue_script( 'rzd-modyfikacje', RZD_PLUGIN_URL . 'assets/js/rzd-modyfikacje.js', array(), rzd_asset_ver( 'assets/js/rzd-modyfikacje.js' ), array( 'in_footer' => true, 'strategy' => 'defer' ) );
	wp_add_inline_script( 'rzd-modyfikacje', 'var rzdMods = ' . wp_json_encode( array( 'url' => WC_AJAX::get_endpoint( 'rzd_mods' ), 'save' => WC_AJAX::get_endpoint( 'rzd_mods_save' ), 'nonce' => wp_create_nonce( 'rzd_mods_save' ), 'review' => WC_AJAX::get_endpoint( 'rzd_review' ), 'rvRemove' => WC_AJAX::get_endpoint( 'rzd_review_remove' ), 'rvRestore' => WC_AJAX::get_endpoint( 'rzd_review_restore' ), 'cartUrl' => wc_get_cart_url(), 'products' => array_values( $products ) ) ) . ';', 'before' );
} );

add_action( 'wp_footer', function () {
	if ( is_admin() ) {
		return;
	}
	$products = rzd_products_with_modifiers();
	if ( ! $products ) {
		return;
	}
	?>
	<?php echo rzd_css_tag( 'assets/css/rzd-modyfikacje.css', 'rzd-mods-css' ); // phpcs:ignore ?>
	<div id="rzd-mods" hidden>
		<div class="rzd-panel" role="dialog" aria-modal="true">
			<div class="rzd-head"><h3>Dostosuj produkt</h3><button type="button" class="rzd-x" aria-label="Zamknij">✕</button></div>
			<div class="rzd-groups"></div>
			<div class="rzd-summary"><span>Dopłata</span><span class="rzd-total">bez dopłaty</span></div>
			<div class="rzd-picked"></div>
			<div class="rzd-actions">
				<div class="rzd-act"><button type="button" class="rzd-cancel">Anuluj</button></div>
				<div class="rzd-act"><button type="button" class="rzd-ok">Dodaj do koszyka</button></div>
			</div>
		</div>
	</div>
	<?php // przegląd zamówienia – wygląd w module 15 (rzd_popup_css). ?>
	<div id="rzd-review" hidden>
		<div class="dc-panel" role="dialog" aria-modal="true" aria-labelledby="rzd-rv-title">
			<div class="rzd-rv-head"><h3 id="rzd-rv-title">Sprawdź zamówienie</h3><button type="button" class="rzd-rv-x" aria-label="Zamknij">✕</button></div>
			<div class="rzd-rv-list"></div>
			<div class="rzd-rv-foot">
				<div class="rzd-rv-sum"></div>
				<div class="dc-actions"><div class="dc-act"><button type="button" class="dc-ok rzd-rv-go">Potwierdź i przejdź do koszyka</button></div></div>
			</div>
		</div>
	</div>
	
	<?php
} );
