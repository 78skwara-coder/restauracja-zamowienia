<?php
/**
 * Moduł 10-modyfikacje – odczyt wyboru klienta.
 * Część modułu (pliki wczytywane po kolei – kolejność jak w dawnym jednym pliku).
 */

/* ============================================================
 * 3. ODCZYT WYBORU KLIENTA (z $_POST['rzd_mod'])
 * ============================================================
 * Zwraca:
 *  'lines' – do wyświetlenia klientowi/w koszyku: [ ['name','label','price'], … ]
 *  'delta' – suma dopłat/odjęć do ceny produktu
 *  'usage' – dane MASZYNOWE dla kuchni/raportów: [ ['addon_id','name','qty','role'], … ]
 *            (bez wpisów o roli "neutralna" – nic nie trzeba dla nich liczyć)
 */
function rzd_role_sign( $role ) {
	if ( 'odejmuje' === $role || 'dezaktywuje' === $role ) {
		return -1;
	}
	if ( 'neutralna' === $role ) {
		return 0;
	}
	return 1; // dodaje, obowiazkowa
}

/**
 * Cena dodatku, jaka faktycznie obowiązuje przy danej roli. Zestaw kilku
 * dodatków zwykle kosztuje MNIEJ niż suma ich cen osobno (np. mięso + frytki
 * + surówka osobno to 50 zł, w zestawie 37 zł) – dlatego dodatek ma DWIE
 * wartości: "przy dodaniu" i "przy odejmowaniu", i to ta druga liczy się
 * dla roli "odejmuje", a nie ta sama wartość co przy dodawaniu.
 */
function rzd_addon_role_price( $addon, $role ) {
	if ( 'odejmuje' === $role || 'dezaktywuje' === $role ) {
		return -1 * (float) $addon['price_minus'];
	}
	if ( 'neutralna' === $role ) {
		return 0.0;
	}
	return (float) $addon['price']; // dodaje, obowiazkowa
}

/**
 * Nazwa, jaką dodatek pokazuje klientowi/kuchni NA TYM KONKRETNYM produkcie.
 * Bez typu – zawsze własna nazwa dodatku. Z typem – szuka w Składzie tego
 * produktu pasującego Składnika i bierze JEGO nazwę (cena i tak zawsze
 * pochodzi z dodatku, to dotyczy wyłącznie tego, jak się to nazywa).
 * Zwraca null, gdy dodatek ma typ, ale w składzie produktu nie ma nic
 * pasującego – to sygnał dla wywołującego kodu, żeby całą modyfikację
 * pominąć (nie dotyczy tego produktu).
 */
function rzd_resolve_addon_name_for_product( $product_id, $addon, $sklad = null ) {
	if ( empty( $addon['type_id'] ) ) {
		return $addon['name'];
	}
	if ( null === $sklad ) {
		$sklad = function_exists( 'rzd_get_product_sklad' ) ? rzd_get_product_sklad( $product_id ) : array();
	}
	$ing = function_exists( 'rzd_find_in_sklad_by_type' ) ? rzd_find_in_sklad_by_type( $sklad, $addon['type_id'] ) : null;
	return $ing ? $ing['name'] : null;
}

/**
 * Pozycje „Powiel skład” (dokładki): każdy dodatek ze składu PO wyborze klienta,
 * który ma wartość „przy dodaniu” > 0 (to cena dokładki). [ [addon, key], … ];
 * key = "<nr modyfikacji>_<ID dodatku>" – pole w oknie i w rzd_raw.
 */
function rzd_clone_rows( $product_id, $gi, $g, $raw ) {
	$src = isset( $g['_src'] ) ? (int) $g['_src'] : (int) $product_id;
	$out = array();
	foreach ( rzd_effective_sklad( $product_id, $src, $raw )['items'] as $a ) {
		if ( (float) $a['price'] > 0.001 && empty( $a['mandatory'] ) ) {
			$out[] = array( 'addon' => $a, 'key' => $gi . '_' . (int) $a['id'] );
		}
	}
	return $out;
}

/**
 * gdzie klient wybiera modyfikację – 'before' (okno przed dodaniem)
 * albo 'cart' (przegląd zamówienia – „Dodatki płatne”). Pojedynczy wybór (radio,
 * w oknie wymagany) i obowiązkowe (rolą albo z katalogu) – zawsze 'before',
 * nawet gdy w ustawieniach zapisano inaczej albo dodatek zmienił się później.
 */
function rzd_group_place( $g ) {
	if ( empty( $g['place'] ) || 'cart' !== $g['place'] || 'radio' === $g['type'] ) {
		return 'before';
	}
	if ( ! in_array( $g['type'], array( 'text', 'clone' ), true ) ) {
		if ( 'obowiazkowa' === $g['role'] ) {
			return 'before';
		}
		$addon = rzd_get_addon( $g['addon_id'] );
		if ( ! $addon || ! empty( $addon['mandatory'] ) ) {
			return 'before';
		}
	}
	return 'cart';
}

// czy produkt (na termin koszyka) ma choć jedną modyfikację „w koszyku”,
// która go dotyczy (dodatek z Typem bez dopasowania w składzie – nie).
function rzd_product_has_cart_groups( $product_id ) {
	static $memo = array();
	$product_id = (int) $product_id;
	if ( isset( $memo[ $product_id ] ) ) {
		return $memo[ $product_id ];
	}
	$has = false;
	foreach ( rzd_get_modifier_groups( $product_id ) as $g ) {
		if ( 'cart' !== rzd_group_place( $g ) ) {
			continue;
		}
		if ( 'text' === $g['type'] || 'clone' === $g['type'] ) {
			$has = true; // „Powiel skład” – dokładki zależą od wyboru klienta, przycisk zostaje
			break;
		}
		$addon = rzd_get_addon( $g['addon_id'] );
		if ( $addon && null !== rzd_resolve_addon_name_for_product( isset( $g['_src'] ) ? (int) $g['_src'] : $product_id, $addon ) ) {
			$has = true;
			break;
		}
	}
	return $memo[ $product_id ] = $has;
}

// surowe zaznaczenia z okna ( [ index => [ 'val' => … ] ] ) – zapisywane
// w pozycji koszyka, żeby okno w koszyku otworzyło się z wyborem klienta.
function rzd_sanitize_raw_selection( $posted ) {
	$raw = array();
	foreach ( (array) $posted as $k => $v ) {
		if ( is_array( $v ) && isset( $v['val'] ) && '' !== (string) $v['val'] && ! is_array( $v['val'] ) ) {
			// klucz: numer modyfikacji albo „numer_ID dodatku” (pozycja „Powiel skład”)
			$key         = preg_match( '/^\d+_\d+$/', (string) $k ) ? (string) $k : absint( $k );
			$raw[ $key ] = array( 'val' => sanitize_text_field( (string) $v['val'] ) );
		}
	}
	return $raw;
}

// Czy klucz z rzd_raw należy do modyfikacji nr $gi (zwykły albo pozycja „Powiel skład”)?
function rzd_raw_key_of( $key, $gi ) {
	return (string) $key === (string) $gi || 0 === strpos( (string) $key, $gi . '_' );
}

function rzd_read_selection( $product_id, $posted = null ) {
	if ( null === $posted ) {
		$posted = ( isset( $_POST['rzd_mod'] ) && is_array( $_POST['rzd_mod'] ) ) ? wp_unslash( $_POST['rzd_mod'] ) : array();
	}
	$lines = array();
	$usage = array();
	$delta = 0.0;

	foreach ( rzd_get_modifier_groups( $product_id ) as $gi => $g ) {
		$posted_g = isset( $posted[ $gi ] ) && is_array( $posted[ $gi ] ) ? $posted[ $gi ] : array();
		$src      = isset( $g['_src'] ) ? (int) $g['_src'] : (int) $product_id; // dla zestawu: danie, z którego pochodzi ta modyfikacja

		if ( 'text' === $g['type'] ) {
			$text = isset( $posted_g['val'] ) ? sanitize_text_field( $posted_g['val'] ) : '';
			if ( '' === $text ) {
				continue;
			}
			$lines[] = array( 'name' => $g['name'], 'label' => $text, 'price' => (float) $g['price'], 'role' => 'tekst', 'qty' => 1 );
			$delta  += (float) $g['price'];
			continue;
		}

		if ( 'clone' === $g['type'] ) { // „Powiel skład” – dokładki tego, co danie zawiera po wyborze
			foreach ( rzd_clone_rows( $product_id, $gi, $g, $posted ) as $cr ) {
				$a   = $cr['addon'];
				$pv  = isset( $posted[ $cr['key'] ] ) && is_array( $posted[ $cr['key'] ] ) ? $posted[ $cr['key'] ] : array();
				$qty = isset( $pv['val'] ) ? intval( $pv['val'] ) : 0;
				$qty = max( 0, min( max( 1, (int) $g['max'] ), $qty ) );
				if ( $qty <= 0 ) {
					continue;
				}
				$price   = (float) $a['price'] * $qty;
				$lines[] = array( 'name' => $a['name'], 'label' => ( $qty > 1 ? $a['name'] . ' ×' . $qty : $a['name'] ), 'price' => $price, 'role' => 'dodaje', 'qty' => $qty, 'kind' => 'dodatki', 'src' => (int) $src, 'extra' => 1 );
				$delta  += $price;
				$usage[] = array( 'addon_id' => $a['id'], 'name' => $a['name'], 'qty' => $qty, 'role' => 'dodaje', 'kind' => 'dodatki', 'src' => (int) $src );
			}
			continue;
		}

		if ( 'radio' === $g['type'] ) {
			if ( ! isset( $posted_g['val'] ) || '' === $posted_g['val'] ) {
				continue;
			}
			$oi = absint( $posted_g['val'] );
			if ( ! isset( $g['options'][ $oi ] ) ) {
				continue;
			}
			$opt   = $g['options'][ $oi ];
			$addon = rzd_get_addon( $opt['addon_id'] );
			if ( ! $addon ) {
				continue;
			}
			$eff_name = $addon['name']; // wybór „jedno z kilku” – zawsze własna nazwa dodatku (zastępuje w składzie dodatek tego typu)
			$price   = rzd_addon_role_price( $addon, $opt['role'] );
			$kind    = rzd_mod_kind( $opt['role'], $price, ! empty( $addon['mandatory'] ) );
			$lines[] = array( 'name' => $eff_name, 'label' => $eff_name, 'price' => $price, 'role' => $opt['role'], 'qty' => 1, 'kind' => $kind, 'src' => (int) $src, 'pick' => 1 ); // src – danie zestawu; pick – pojedynczy wybór (przegląd: do składu)
			$delta  += $price;
			// Także wybory bez dopłaty – kuchnia musi zsumować np. frytki do zestawów.
			$usage[] = array( 'addon_id' => $addon['id'], 'name' => $eff_name, 'qty' => 1, 'role' => $opt['role'], 'kind' => $kind, 'src' => (int) $src ); // src – Kuchnia: przy którym daniu zestawu
			continue;
		}

		// tap / stepper – wspólna logika, różni się tylko sposobem ustalenia $qty
		$addon = rzd_get_addon( $g['addon_id'] );
		if ( ! $addon ) {
			continue;
		}
		// w „Dodatkach płatnych” dodatek z typem – nazwa ze składu PO wyborze klienta (wybrał ziemniaki → ziemniaki)
		$eff_name = rzd_resolve_addon_name_for_product( $src, $addon, 'cart' === rzd_group_place( $g ) ? rzd_effective_sklad( $product_id, $src, $posted )['items'] : null );
		if ( null === $eff_name ) {
			continue; // dodatek ma typ, ale danie nie ma w składzie dodatku tego typu
		}

		if ( 'obowiazkowa' === $g['role'] || $addon['mandatory'] ) {
			// zawsze aktywna, klient nic tu nie wybiera – niezależnie od tego,
			// co (jeśli cokolwiek) przyszło w $_POST
			$qty = ( 'stepper' === $g['type'] ) ? max( 1, (int) $g['min'] ) : 1;
		} elseif ( 'tap' === $g['type'] ) {
			$qty = empty( $posted_g['val'] ) ? 0 : 1;
		} else { // stepper
			$qty = isset( $posted_g['val'] ) ? intval( $posted_g['val'] ) : 0;
			$qty = max( (int) $g['min'], min( (int) $g['max'], $qty ) );
		}
		if ( $qty <= 0 ) {
			continue;
		}

		$price = rzd_addon_role_price( $addon, $g['role'] ) * $qty;
		$label = ( 'stepper' === $g['type'] && $qty > 1 ) ? ( $eff_name . ' ×' . $qty ) : $eff_name;

		$kind    = rzd_mod_kind( $g['role'], $price, ! empty( $addon['mandatory'] ) );
		$lines[] = array( 'name' => $eff_name, 'label' => $label, 'price' => $price, 'role' => $g['role'], 'qty' => $qty, 'kind' => $kind, 'src' => (int) $src );
		$delta  += $price;
		$usage[] = array( 'addon_id' => $addon['id'], 'name' => $eff_name, 'qty' => $qty, 'role' => $g['role'], 'kind' => $kind, 'src' => (int) $src );
	}

	// Rola "dezaktywuje" liczy się cenowo dokładnie jak "odejmuje" (patrz
	// rzd_addon_role_price) – dodatkowe BLOKOWANIE innych modyfikacji tego
	// samego typu (np. "ani frytki, ani ziemniaki" gasi osobny licznik
	// "dodatkowe ziemniaki") dzieje się po stronie front-endu, w oknie
	// wyboru, zanim klient w ogóle kliknie "Dodaj do koszyka" – patrz
	// updateExclusions() niżej w tym pliku.

	return array( 'lines' => $lines, 'delta' => $delta, 'usage' => $usage );
}

