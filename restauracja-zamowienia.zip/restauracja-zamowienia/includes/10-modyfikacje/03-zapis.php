<?php
/**
 * Moduł 10-modyfikacje – zapis.
 * Część modułu (pliki wczytywane po kolei – kolejność jak w dawnym jednym pliku).
 */

/* ============================================================
 * 2. ZAPIS
 * ============================================================ */
function rzd_sanitize_modifier( $g ) {
	if ( ! is_array( $g ) ) {
		return null;
	}
	$type = ( isset( $g['type'] ) && in_array( $g['type'], array( 'radio', 'tap', 'text', 'stepper', 'clone' ), true ) ) ? $g['type'] : 'tap';

	if ( 'clone' === $type ) { // „Powiel skład” – dokładki ze składu po wyborze; bez własnego dodatku
		return array( 'type' => 'clone', 'role' => 'dodaje', 'max' => isset( $g['clone_max'] ) ? max( 1, min( 20, intval( $g['clone_max'] ) ) ) : ( isset( $g['max'] ) ? max( 1, min( 20, intval( $g['max'] ) ) ) : 3 ) );
	}

	if ( 'text' === $type ) {
		$name = isset( $g['name'] ) ? sanitize_text_field( $g['name'] ) : '';
		if ( '' === $name ) {
			return null; // pole tekstowe bez nazwy jest pomijane
		}
		return array(
			'type'        => 'text',
			'name'        => $name,
			'price'       => isset( $g['price'] ) ? (float) $g['price'] : 0.0,
			'placeholder' => isset( $g['placeholder'] ) ? sanitize_text_field( $g['placeholder'] ) : '',
		);
	}

	if ( 'radio' === $type ) {
		$options = array();
		if ( isset( $g['options'] ) && is_array( $g['options'] ) ) {
			foreach ( $g['options'] as $opt ) {
				$addon_id = isset( $opt['addon_id'] ) ? absint( $opt['addon_id'] ) : 0;
				if ( ! $addon_id || ! rzd_get_addon( $addon_id ) ) {
					continue; // opcja bez wybranego (istniejącego) dodatku jest pomijana
				}
				$role      = ( isset( $opt['role'] ) && array_key_exists( $opt['role'], rzd_modifier_roles() ) ) ? $opt['role'] : 'dodaje';
				$options[] = array( 'addon_id' => $addon_id, 'role' => $role );
			}
		}
		if ( empty( $options ) ) {
			return null; // wybór bez żadnej poprawnej opcji nie ma sensu
		}
		return array( 'type' => 'radio', 'options' => $options );
	}

	// tap / stepper
	$addon_id = isset( $g['addon_id'] ) ? absint( $g['addon_id'] ) : 0;
	if ( ! $addon_id || ! rzd_get_addon( $addon_id ) ) {
		return null; // bez wybranego dodatku modyfikacja nie ma sensu
	}
	$role = ( isset( $g['role'] ) && array_key_exists( $g['role'], rzd_modifier_roles() ) ) ? $g['role'] : 'dodaje';
	$row  = array( 'type' => $type, 'addon_id' => $addon_id, 'role' => $role );

	if ( 'stepper' === $type ) {
		$row['min'] = isset( $g['min'] ) ? max( 0, intval( $g['min'] ) ) : 0;
		$row['max'] = isset( $g['max'] ) ? max( 0, intval( $g['max'] ) ) : 10;
		if ( $row['max'] < $row['min'] ) {
			$row['max'] = $row['min'];
		}
	}
	return $row;
}

add_action( 'woocommerce_process_product_meta', function ( $post_id ) {
	// Skład zapisuje się niezależnie od modyfikacji – jest sensowny nawet na
	// produkcie, który nie ma żadnej modyfikacji do wyboru.
	// skład = dodatki z katalogu (nowe pole; dawne _rzd_sklad zostaje nietknięte – powrót do 2.31.0)
	rzd_set_product_sklad( $post_id, ( isset( $_POST['rzd_sklad'] ) && is_array( $_POST['rzd_sklad'] ) ) ? wp_unslash( $_POST['rzd_sklad'] ) : array() );

	$clean = rzd_sanitize_sections( isset( $_POST['rzd_section'] ) ? wp_unslash( $_POST['rzd_section'] ) : array() );
	if ( empty( $clean ) ) {
		delete_post_meta( $post_id, '_rzd_modifiers' );
	} else {
		update_post_meta( $post_id, '_rzd_modifiers', $clean );
	}
}, 20 );

/**
 * Czyści grupy modyfikacji z formularza (pola rzd_section[…]). Wspólne dla
 * produktu i wzorów (moduł 18). Puste grupy i modyfikacje bez dodatku są
 * pomijane. Dane wejściowe już po wp_unslash().
 */
function rzd_sanitize_sections( $raw ) {
	$clean = array();
	if ( ! is_array( $raw ) ) {
		return $clean;
	}
	foreach ( $raw as $section ) {
		if ( ! is_array( $section ) ) {
			continue;
		}
		$items = array();
		if ( isset( $section['items'] ) && is_array( $section['items'] ) ) {
			foreach ( $section['items'] as $g ) {
				$row = rzd_sanitize_modifier( $g );
				if ( null !== $row ) {
					$items[] = $row;
				}
			}
		}
		if ( empty( $items ) ) {
			continue; // pusta grupa jest pomijana
		}
		$row = array(
			'header'      => isset( $section['header'] ) ? sanitize_text_field( $section['header'] ) : '',
			'description' => isset( $section['description'] ) ? sanitize_textarea_field( $section['description'] ) : '',
			'place'       => ( isset( $section['place'] ) && 'cart' === $section['place'] ) ? 'cart' : 'before',
			'items'       => $items,
		);
		// grupa wstawiona ze wzoru pamięta jego ID (tylko informacja dla edycji z telefonu – to nadal KOPIA).
		$preset = isset( $section['preset'] ) ? absint( $section['preset'] ) : 0;
		if ( $preset && 'rzd_mod_preset' === get_post_type( $preset ) ) {
			$row['preset'] = $preset;
		}
		$clean[] = $row;
	}
	return $clean;
}

