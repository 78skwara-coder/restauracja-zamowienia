<?php
/**
 * Moduł 10-modyfikacje – okno wyboru (krok bramy dodawania).
 * Część modułu (pliki wczytywane po kolei – kolejność jak w dawnym jednym pliku).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 5. OKNO WYBORU (krok 15 bramy dodawania – moduł 08)
 * ============================================================ */
add_action( 'wc_ajax_rzd_mods', function () {
	$pid        = isset( $_GET['product_id'] ) ? absint( $_GET['product_id'] ) : 0;
	$where      = 'before';
	// panel kelnera (sala, moduł 33): jedno okno ze wszystkimi modyfikacjami – także „Dodatki płatne”
	if ( ! empty( $_GET['all'] ) && function_exists( 'rzd_can' ) && rzd_can( 'sala' ) ) {
		$where = 'all';
	}
	$preset     = array();
	$extra      = array();
	// okno w koszyku – pozycja koszyka po kluczu, tylko modyfikacje „w koszyku”,
	// zaznaczone tak, jak klient wybrał.
	$cart_key = isset( $_GET['cart_key'] ) ? sanitize_text_field( wp_unslash( $_GET['cart_key'] ) ) : '';
	if ( '' !== $cart_key ) {
		$item = ( function_exists( 'WC' ) && WC()->cart ) ? WC()->cart->get_cart_item( $cart_key ) : null;
		if ( ! $item || ! isset( $item['rzd_raw'] ) ) {
			wp_send_json( array( 'ok' => false, 'sections' => array() ) );
		}
		$pid    = (int) $item['product_id'];
		$where  = 'cart';
		$preset = (array) $item['rzd_raw'];
		$extra  = array( 'qty' => (int) $item['quantity'], 'title' => get_the_title( $pid ) );
	}
	// W oknie „Dodatki płatne” (koszyk / przegląd) liczy się skład PO wyborze klienta
	// sprzed dodania do koszyka (rzd_effective_sklad): „Zawiera już”, nazwy dodatków
	// z typem, „to dodatkowa porcja” i pozycje „Powiel skład”. Przed dodaniem – skład dania.
	$eff = function ( $src ) use ( $pid, $where, $preset ) {
		static $memo = array();
		if ( ! isset( $memo[ $src ] ) ) {
			$memo[ $src ] = ( 'cart' === $where ) ? rzd_effective_sklad( $pid, $src, $preset )['items'] : rzd_get_product_sklad( $src );
		}
		return $memo[ $src ];
	};
	$in_sklad = function ( $sklad, $addon, $eff_name ) {
		foreach ( $sklad as $it ) {
			if ( (int) $it['id'] === (int) $addon['id'] || mb_strtolower( $it['name'] ) === mb_strtolower( $eff_name ) || ( $addon['type_id'] && (int) $it['type_id'] === (int) $addon['type_id'] ) ) {
				return true;
			}
		}
		return false;
	};
	$out        = array();
	$flat_index = 0;
	$shown_src  = array();
	foreach ( rzd_get_effective_sections( $pid ) as $section ) {
		$items = array();
		$src   = isset( $section['src'] ) ? (int) $section['src'] : $pid; // produkt, z którego pochodzi sekcja (dla zestawu: konkretne danie)
		foreach ( (array) $section['items'] as $g ) {
			if ( 'all' !== $where && rzd_group_place( $g ) !== $where ) {
				$flat_index++; // modyfikacja z drugiego miejsca – pomijamy, numeracja idzie dalej
				continue;
			}
			$row  = array( 'index' => (int) $flat_index, 'type' => $g['type'], 'scope' => $src );
			$skip = false; // typ bez dopasowania w składzie TEGO produktu – modyfikacja go pomija, ale numeracja (flat_index) musi iść dalej

			if ( 'clone' === $g['type'] ) {
				// „Powiel skład” – osobny licznik dla każdego dodatku składu z ceną dokładki
				foreach ( rzd_clone_rows( $pid, $flat_index, $g, $preset ) as $cr ) {
					$a       = $cr['addon'];
					$items[] = array(
						'index' => $cr['key'], 'type' => 'stepper', 'scope' => $src, 'label' => $a['name'], 'addon_id' => $a['id'], 'role' => 'dodaje',
						'price' => (float) $a['price'], 'price_html' => rzd_format_delta( $a['price'] ), 'icon_url' => $a['icon_url'], 'locked' => false,
						'min' => 0, 'max' => max( 1, (int) $g['max'] ), 'has_note' => '+1 porcja: ' . $a['name'] . ' do tego dania',
					);
				}
				$flat_index++;
				continue;
			}
			if ( 'text' === $g['type'] ) {
				$row['price']       = (float) $g['price'];
				$row['price_html']  = rzd_format_delta( $g['price'] );
				$row['placeholder'] = isset( $g['placeholder'] ) ? $g['placeholder'] : '';
				$row['label']       = $g['name'];
			} elseif ( 'radio' === $g['type'] ) {
				$opts = array();
				foreach ( $g['options'] as $orig_oi => $opt ) {
					$addon = rzd_get_addon( $opt['addon_id'] );
					if ( ! $addon ) {
						continue; // dodatek usunięty z katalogu po skonfigurowaniu modyfikacji
					}
					$eff_name = $addon['name']; // wybór „jedno z kilku” – zawsze własna nazwa (zastępuje w składzie dodatek tego typu)
					$price   = rzd_addon_role_price( $addon, $opt['role'] );
					$opts[]  = array(
						// POPRAWKA: numer opcji w USTAWIENIACH. Wcześniej okno wysyłało numer
						// na liście po odfiltrowaniu (dodatek usunięty / Typ bez dopasowania w składzie),
						// a odczyt brał $g['options'][ten numer] – po każdej pominiętej opcji wybór
						// przesuwał się na sąsiednią (np. „Bez dodatków −7 zł” liczyło się jak opcja bez ceny).
						'oi'         => (int) $orig_oi,
						'addon_id'   => $addon['id'],
						'role'       => $opt['role'],
						'label'      => $eff_name,
						'price'      => $price,
						'price_html' => rzd_format_delta( $price ),
						'icon_url'   => $addon['icon_url'],
						'mandatory'  => $addon['mandatory'],
					);
				}
				if ( ! $opts ) {
					$skip = true; // ŻADNA opcja nie pasuje do tego produktu – cała modyfikacja znika
				}
				$row['options'] = $opts;
			} else { // tap / stepper
				$addon = rzd_get_addon( $g['addon_id'] );
				$eff_name = $addon ? rzd_resolve_addon_name_for_product( $src, $addon, $eff( $src ) ) : null;
				if ( ! $addon || null === $eff_name ) {
					$skip = true;
				} else {
					$locked      = ( 'obowiazkowa' === $g['role'] || $addon['mandatory'] );
					$price       = rzd_addon_role_price( $addon, $g['role'] );
					$row['label']      = $eff_name;
					$row['addon_id']   = $addon['id'];
					$row['role']       = $g['role'];
					$row['price']      = $price;
					$row['price_html'] = rzd_format_delta( $price );
					$row['icon_url']   = $addon['icon_url'];
					// Obowiązkowy (rolą albo z katalogu) NADAL pokazuje się w oknie –
					// klient ma widzieć, za co płaci – tylko jest zablokowany do
					// zmiany (JS: przycisk/licznik wyszarzony, "Zawsze dołączone").
					$row['locked']     = $locked;
					// „to dodatkowa porcja” – ten dodatek (albo dodatek tego typu) danie już zawiera
					if ( ! $locked && 'dodaje' === $g['role'] && $in_sklad( $eff( $src ), $addon, $eff_name ) ) {
						$row['has_note'] = $eff_name . ' jest już w daniu – to dodatkowa porcja';
					}
					if ( 'stepper' === $g['type'] ) {
						$row['min'] = (int) $g['min'];
						$row['max'] = (int) $g['max'];
					}
				}
			}
			if ( ! $skip ) {
				$items[] = $row;
			}
			$flat_index++;
		}
		if ( $items ) {
			// „Zawiera już: …” – skład dania, raz na danie (pierwsza jego sekcja w oknie).
			$contains = array();
			if ( ! isset( $shown_src[ $src ] ) ) {
				$shown_src[ $src ] = true;
				foreach ( $eff( $src ) as $ing ) {
					$contains[] = $ing['name'];
				}
			}
			$out[] = array(
				'header'      => isset( $section['header'] ) ? $section['header'] : '',
				'description' => isset( $section['description'] ) ? $section['description'] : '',
				'contains'    => $contains,
				'items'       => $items,
			);
		}
	}
	wp_send_json( array_merge( array( 'ok' => true, 'where' => $where, 'preset' => (object) $preset, 'sections' => $out ), $extra ) );
} );

/**
 * zapis zmian z okna w koszyku. Zmienia tylko modyfikacje „w koszyku”
 * (wybory sprzed dodania zostają), przelicza linie/dopłatę/rzd_usage tak jak
 * przy dodawaniu. split = 1 przy ilości > 1: zmiana dotyczy jednej sztuki,
 * która staje się osobną pozycją.
 */
add_action( 'wc_ajax_rzd_mods_save', function () {
	if ( ! rzd_request_same_origin() || ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'rzd_mods_save' ) ) {
		wp_send_json( array( 'ok' => false, 'msg' => 'Sesja wygasła – odśwież stronę.' ) );
	}
	$cart = ( function_exists( 'WC' ) && WC()->cart ) ? WC()->cart : null;
	$key  = isset( $_POST['cart_key'] ) ? sanitize_text_field( wp_unslash( $_POST['cart_key'] ) ) : '';
	$item = $cart ? $cart->get_cart_item( $key ) : null;
	if ( ! $item || ! isset( $item['rzd_raw'] ) ) {
		wp_send_json( array( 'ok' => false, 'msg' => 'Nie znaleziono pozycji w koszyku.' ) );
	}
	$pid    = (int) $item['product_id'];
	$posted = rzd_sanitize_raw_selection( ( isset( $_POST['rzd_mod'] ) && is_array( $_POST['rzd_mod'] ) ) ? wp_unslash( $_POST['rzd_mod'] ) : array() );
	$raw    = (array) $item['rzd_raw'];
	foreach ( rzd_get_modifier_groups( $pid ) as $gi => $g ) {
		if ( 'cart' !== rzd_group_place( $g ) ) {
			continue;
		}
		foreach ( array_keys( $raw ) as $rk ) { // także pozycje „Powiel skład” (klucz „nr_ID”)
			if ( rzd_raw_key_of( $rk, $gi ) ) {
				unset( $raw[ $rk ] );
			}
		}
		foreach ( $posted as $pk => $pv ) {
			if ( rzd_raw_key_of( $pk, $gi ) ) {
				$raw[ $pk ] = $pv;
			}
		}
	}
	$sel   = rzd_read_selection( $pid, $raw );
	// znacznik „z podpowiedzi paska dostawy” (moduł 32 – pod pomiar); tylko gdy wybór przybył (dopłata wzrosła)
	$from_hint = isset( $_POST['rzd_upsell'] ) && 'hint' === sanitize_key( wp_unslash( $_POST['rzd_upsell'] ) ) && $sel['delta'] > ( isset( $item['rzd_mods_delta'] ) ? (float) $item['rzd_mods_delta'] : 0 ) + 0.001;
	$apply = function ( $it ) use ( $sel, $raw, $pid, $from_hint ) {
		$it['rzd_raw'] = $raw;
		if ( $from_hint ) {
			$it['rzd_upsell'] = 'hint';
		}
		if ( $sel['lines'] ) {
			$it['rzd_mods']       = $sel['lines'];
			$it['rzd_mods_delta'] = $sel['delta'];
			$it['rzd_usage']      = $sel['usage'];
			if ( ! isset( $it['rzd_base_price'] ) ) {
				$p                    = wc_get_product( $pid );
				$it['rzd_base_price'] = $p ? (float) $p->get_price() : 0;
			}
		} else {
			unset( $it['rzd_mods'], $it['rzd_mods_delta'], $it['rzd_usage'], $it['rzd_base_price'] );
		}
		return $it;
	};

	$qty = (int) $item['quantity'];
	if ( ! empty( $_POST['split'] ) && $qty > 1 ) {
		$new             = $apply( $item );
		$new_key         = md5( $key . '|rzd|' . microtime() );
		$new['key']      = $new_key;
		$new['quantity'] = 1;
		$new['unique_key'] = $new_key;
		$prod            = wc_get_product( ! empty( $item['variation_id'] ) ? (int) $item['variation_id'] : $pid );
		if ( ! $prod ) {
			wp_send_json( array( 'ok' => false, 'msg' => 'Produkt jest niedostępny.' ) );
		}
		$new['data'] = $prod; // osobny obiekt – inaczej obie pozycje dostałyby tę samą cenę
		$cart->set_quantity( $key, $qty - 1, false );
		$cart->cart_contents[ $new_key ] = $new;
	} else {
		$cart->cart_contents[ $key ] = $apply( $item );
	}
	$cart->calculate_totals();
	if ( method_exists( $cart, 'set_session' ) ) {
		$cart->set_session();
	}
	wp_send_json( array( 'ok' => true ) );
} );

