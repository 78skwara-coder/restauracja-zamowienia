<?php
/**
 * Moduł 10-modyfikacje – panel: zakładka „Możliwe modyfikacje”.
 * Część modułu (pliki wczytywane po kolei – kolejność jak w dawnym jednym pliku).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 1. PANEL: zakładka "Możliwe modyfikacje"
 * ============================================================ */
add_action( 'admin_enqueue_scripts', function ( $hook ) {
	global $post_type;
	if ( 'product' === $post_type && in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
		wp_enqueue_media();
		add_action( 'admin_print_styles', 'rzd_admin_tabs_layout_fix' );
	}
} );

/**
 * Uwaga: funkcja rzd_admin_tabs_layout_fix() (naprawa układu tej zakładki –
 * box-sizing, odstępy między polami) jest zdefiniowana w module 04, bo tam
 * powstała jako pierwsza i obsługuje też zakładkę "Zestaw dnia". Oba moduły
 * ładują się w tym samym żądaniu, więc funkcja jest dostępna, niezależnie
 * od tego, w którym pliku faktycznie siedzi definicja – nie trzeba (i nie
 * wolno) definiować jej drugi raz tutaj, bo PHP nie pozwala na dwie
 * definicje tej samej nazwy funkcji (błąd krytyczny "Cannot redeclare").
 */

/**
 * Wybór dodatku + roli – wspólny fragment formularza dla modyfikacji typu
 * tap/stepper (jeden dodatek) i dla każdej opcji typu radio (jeden dodatek
 * na opcję). $name to pełna nazwa pola (np. "rzd_section[0][items][1]").
 */
function rzd_render_addon_picker( $name, $addon_id, $role ) {
	$addons = function_exists( 'rzd_get_all_addons' ) ? rzd_get_all_addons() : array();
	ob_start();
	?>
	<p class="rzd-field">
		<label><strong>Dodatek</strong> (nazwa, cena i ikonka z katalogu Dodatki):</label>
		<select name="<?php echo esc_attr( $name ); ?>[addon_id]">
			<option value="">— wybierz —</option>
			<?php foreach ( $addons as $a ) : ?>
				<option value="<?php echo esc_attr( $a['id'] ); ?>" <?php selected( (int) $addon_id, $a['id'] ); ?>>
					<?php
					// obie ceny – „przy dodaniu” i „przy odejmowaniu” (rola Odejmuje/Dezaktywuje bierze tę drugą).
					$pl = number_format( $a['price'], 2, ',', '' );
					$mi = number_format( $a['price_minus'], 2, ',', '' );
					echo esc_html( rzd_addon_admin_label( $a ) . ' (' . ( $pl === $mi ? $pl . ' zł' : '+' . $pl . ' zł / −' . $mi . ' zł' ) . ')' . ( $a['mandatory'] ? ' — obowiązkowy' : '' ) );
					?>
				</option>
			<?php endforeach; ?>
		</select>
		<?php if ( ! $addons ) : ?>
			<p class="description">Nie masz jeszcze żadnego dodatku – dodaj go najpierw w menu <strong>Dodatki</strong>.</p>
		<?php endif; ?>
	</p>
	<p class="rzd-field">
		<label><strong>Rola</strong> wobec tego dodatku:</label>
		<select name="<?php echo esc_attr( $name ); ?>[role]">
			<?php foreach ( rzd_modifier_roles() as $slug => $label ) : ?>
				<option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $role, $slug ); ?>><?php echo esc_html( $label ); ?></option>
			<?php endforeach; ?>
		</select>
	</p>
	<?php
	return ob_get_clean();
}

function rzd_render_option_row( $g, $i, $opt ) {
	$addon_id = isset( $opt['addon_id'] ) ? (int) $opt['addon_id'] : 0;
	$role     = isset( $opt['role'] ) ? $opt['role'] : 'dodaje';
	$name     = 'rzd_section[' . $g . '][options][' . $i . ']'; // $g to ścieżka wewnątrz sekcji, np. "0][items][2"
	ob_start();
	?>
	<div class="rzd-opt" style="border:1px solid #ddd;background:#fff;padding:10px;margin:8px 0;position:relative;">
		<a href="#" class="rzd-remove-opt" style="position:absolute;top:8px;right:10px;color:#d63638;font-size:18px;font-weight:bold;text-decoration:none;" title="Usuń opcję">&times;</a>
		<?php echo rzd_render_addon_picker( $name, $addon_id, $role ); ?>
	</div>
	<?php
	return ob_get_clean();
}

function rzd_render_group( $index, $group ) {
	$type        = isset( $group['type'] ) ? $group['type'] : 'tap';
	$addon_id    = isset( $group['addon_id'] ) ? (int) $group['addon_id'] : 0;
	$role        = isset( $group['role'] ) ? $group['role'] : 'dodaje';
	$min         = isset( $group['min'] ) ? $group['min'] : 0;
	$max         = isset( $group['max'] ) ? $group['max'] : 10;
	$name        = isset( $group['name'] ) ? $group['name'] : ''; // tylko typ "text"
	$price       = isset( $group['price'] ) ? $group['price'] : ''; // tylko typ "text"
	$placeholder = isset( $group['placeholder'] ) ? $group['placeholder'] : ''; // tylko typ "text"
	$options     = ( isset( $group['options'] ) && is_array( $group['options'] ) ) ? array_values( $group['options'] ) : array();
	$fname       = 'rzd_section[' . $index . ']'; // $index to ścieżka wewnątrz sekcji, np. "0][items][2"

	ob_start();
	?>
	<div class="rzd-group" data-group="<?php echo esc_attr( $index ); ?>" data-next-opt="<?php echo (int) count( $options ); ?>" style="border:2px solid #b5bfc9;margin:10px 0;padding:12px;background:#f6f7f7;position:relative;">
		<a href="#" class="rzd-remove-group" style="position:absolute;top:10px;right:12px;color:#d63638;text-decoration:none;font-size:20px;font-weight:bold;" title="Usuń modyfikację">&times;</a>

		<p class="rzd-field">
			<label><strong>Sposób wyświetlania:</strong></label>
			<select class="rzd-type" name="<?php echo esc_attr( $fname ); ?>[type]">
				<option value="radio" <?php selected( $type, 'radio' ); ?>>Pojedynczy wybór (lista opcji)</option>
				<option value="tap" <?php selected( $type, 'tap' ); ?>>Duży przycisk włącz/wyłącz</option>
				<option value="text" <?php selected( $type, 'text' ); ?>>Samo pole tekstowe</option>
				<option value="stepper" <?php selected( $type, 'stepper' ); ?>>Licznik ze strzałkami +/-</option>
				<option value="clone" <?php selected( $type, 'clone' ); ?>>Powiel skład (dokładki – licznik +/- przy każdym dodatku dania)</option>
			</select>
		</p>

		<div class="rzd-only-clone" style="<?php echo ( 'clone' === $type ) ? '' : 'display:none;'; ?>">
			<p class="description">Klient zobaczy osobny licznik − / + przy każdym dodatku, który danie zawiera <strong>po jego wyborze</strong> (np. wybrał ziemniaki → „Ziemniaki gotowane”, nie frytki). Cena dokładki = „Wartość przy dodaniu” dodatku z katalogu; dodatki z ceną 0 zł się nie pokazują. Najlepiej w grupie „W przeglądzie zamówienia (Dodatki płatne)”.</p>
			<p class="rzd-field rzd-field-inline">
				<label style="display:inline;"><strong>Najwięcej dokładek jednego dodatku:</strong></label>
				<input type="number" min="1" max="20" step="1" name="<?php echo esc_attr( $fname ); ?>[clone_max]" value="<?php echo esc_attr( 'clone' === $type ? $max : 3 ); ?>" style="width:70px;">
			</p>
		</div>


		<div class="rzd-only-radio" style="<?php echo ( 'radio' === $type ) ? '' : 'display:none;'; ?>">
			<label><strong>Opcje do wyboru</strong> – każda to osobny dodatek + jego rola:</label>
			<div class="rzd-opts">
				<?php foreach ( $options as $j => $opt ) : ?>
					<?php echo rzd_render_option_row( $index, $j, $opt ); ?>
				<?php endforeach; ?>
			</div>
			<p><button type="button" class="button rzd-add-opt">+ Dodaj opcję</button></p>
		</div>

		<div class="rzd-only-addon" style="<?php echo in_array( $type, array( 'tap', 'stepper' ), true ) ? '' : 'display:none;'; ?>">
			<?php echo rzd_render_addon_picker( $fname, $addon_id, $role ); ?>
			<div class="rzd-only-stepper-range" style="<?php echo ( 'stepper' === $type ) ? '' : 'display:none;'; ?>">
				<p class="rzd-field rzd-field-inline">
					<label style="display:inline;"><strong>Ilość: od</strong></label>
					<input type="number" min="0" step="1" name="<?php echo esc_attr( $fname ); ?>[min]" value="<?php echo esc_attr( $min ); ?>" style="width:70px;">
					<label style="display:inline;"><strong>do</strong></label>
					<input type="number" min="0" step="1" name="<?php echo esc_attr( $fname ); ?>[max]" value="<?php echo esc_attr( $max ); ?>" style="width:70px;">
				</p>
			</div>
		</div>

		<div class="rzd-only-text" style="<?php echo ( 'text' === $type ) ? '' : 'display:none;'; ?>">
			<p class="rzd-field">
				<label><strong>Nazwa</strong> (widoczna dla klienta):</label>
				<input type="text" name="<?php echo esc_attr( $fname ); ?>[name]" value="<?php echo esc_attr( $name ); ?>" style="width:280px;" placeholder="np. Grawer imienia">
			</p>
			<p class="rzd-field">
				<label><strong>Cena</strong> (nalicza się, gdy pole nie jest puste, może być ujemna):</label>
				<input type="number" step="0.01" name="<?php echo esc_attr( $fname ); ?>[price]" value="<?php echo esc_attr( $price ); ?>" style="width:110px;">
			</p>
			<p class="rzd-field">
				<label><strong>Podpowiedź w polu tekstowym</strong> (opcjonalnie):</label>
				<input type="text" name="<?php echo esc_attr( $fname ); ?>[placeholder]" value="<?php echo esc_attr( $placeholder ); ?>" style="width:280px;" placeholder="np. Wpisz imię do grawerunku">
			</p>
		</div>
	</div>
	<?php
	return ob_get_clean();
}

function rzd_render_sklad_row( $i, $ingredient_id, $ingredients ) {
	ob_start();
	?>
	<p class="rzd-sklad-row" style="display:flex;align-items:center;gap:8px;margin:0 0 8px;">
		<select name="rzd_sklad[<?php echo esc_attr( $i ); ?>]" style="min-width:220px;">
			<option value="">— wybierz dodatek —</option>
			<?php foreach ( $ingredients as $ing ) : ?>
				<option value="<?php echo esc_attr( $ing['id'] ); ?>" <?php selected( (int) $ingredient_id, $ing['id'] ); ?>><?php echo esc_html( rzd_addon_admin_label( $ing ) ); ?></option>
			<?php endforeach; ?>
		</select>
		<a href="#" class="rzd-remove-sklad" style="color:#d63638;text-decoration:none;font-size:16px;font-weight:bold;" title="Usuń">&times;</a>
	</p>
	<?php
	return ob_get_clean();
}

function rzd_render_section( $si, $section ) {
	$header      = isset( $section['header'] ) ? $section['header'] : '';
	$description = isset( $section['description'] ) ? $section['description'] : '';
	$items       = ( isset( $section['items'] ) && is_array( $section['items'] ) ) ? array_values( $section['items'] ) : array();
	$place       = rzd_section_place( $section );
	$sname       = 'rzd_section[' . $si . ']';

	ob_start();
	?>
	<div class="rzd-section" data-section="<?php echo esc_attr( $si ); ?>" data-next-item="<?php echo (int) count( $items ); ?>" style="border:2px solid #8a8f99;margin:18px 12px;padding:14px;background:#eef0f3;position:relative;">
		<a href="#" class="rzd-remove-section" style="position:absolute;top:10px;right:12px;color:#d63638;text-decoration:none;font-size:22px;font-weight:bold;" title="Usuń całą grupę">&times;</a>
		<?php if ( ! empty( $section['preset'] ) ) : // z którego wzoru wstawiono grupę (tylko informacja) ?>
			<input type="hidden" name="<?php echo esc_attr( $sname ); ?>[preset]" value="<?php echo (int) $section['preset']; ?>">
		<?php endif; ?>
		<a href="#" class="button button-small rzd-copy-section" style="position:absolute;top:10px;right:42px;" title="Wstaw pod spodem kopię tej grupy (ze wszystkimi modyfikacjami i opcjami) – potem zmień tylko to, co się różni">⧉ Kopiuj grupę</a>

		<p class="rzd-field">
			<label><strong>Nagłówek grupy</strong> (widoczny dla klienta nad tymi modyfikacjami):</label>
			<input type="text" name="<?php echo esc_attr( $sname ); ?>[header]" value="<?php echo esc_attr( $header ); ?>" style="width:340px;" placeholder="np. Dodaj do zestawu">
		</p>
		<p class="rzd-field">
			<label><strong>Opis grupy</strong> (mniejsza czcionka pod nagłówkiem, opcjonalnie):</label>
			<textarea name="<?php echo esc_attr( $sname ); ?>[description]" rows="2" style="width:100%;max-width:480px;" placeholder="np. Te produkty wchodzą w skład zestawu, ich zmiana nie ma wpływu na cenę"><?php echo esc_textarea( $description ); ?></textarea>
		</p>
		<p class="rzd-field">
			<label><strong>Gdzie klient wybiera modyfikacje z tej grupy:</strong></label>
			<select name="<?php echo esc_attr( $sname ); ?>[place]">
				<option value="before" <?php selected( $place, 'before' ); ?>>Przed dodaniem do koszyka</option>
				<option value="cart" <?php selected( $place, 'cart' ); ?>>W przeglądzie zamówienia (Dodatki płatne)</option>
			</select>
			<span class="description" style="display:block;">„W przeglądzie zamówienia” = klient dobiera je po kliknięciu „Przejdź do koszyka”, przyciskiem „Dodatki płatne”. Pojedynczy wybór (lista opcji) i modyfikacje obowiązkowe z tej grupy i tak pokażą się przed dodaniem do koszyka.</span>
		</p>

		<div class="rzd-items" style="margin-top:10px;">
			<?php foreach ( $items as $mi => $mod ) : ?>
				<?php echo rzd_render_group( $si . '][items][' . $mi, $mod ); ?>
			<?php endforeach; ?>
		</div>
		<p><button type="button" class="button rzd-add-item">+ Dodaj modyfikację do tej grupy</button></p>
	</div>
	<?php
	return ob_get_clean();
}

add_filter( 'woocommerce_product_data_tabs', function ( $tabs ) {
	$tabs['rzd_mods'] = array(
		'label'    => __( 'Możliwe modyfikacje', 'rzd' ),
		'target'   => 'rzd_mods_data',
		'class'    => array(),
		'priority' => 23,
	);
	return $tabs;
} );

add_action( 'woocommerce_product_data_panels', function () {
	global $post;
	$sections    = rzd_get_sections( $post->ID );
	$sklad       = array_map( function ( $a ) { return (int) $a['id']; }, rzd_get_product_sklad( $post->ID ) );
	$ingredients = rzd_get_all_addons(); // skład = dodatki z katalogu (jeden katalog od 2.32.0)

	echo '<div id="rzd_mods_data" class="panel woocommerce_options_panel">';

	echo '<div id="rzd-sklad-wrap" style="padding:0 12px;margin-bottom:18px;border-bottom:1px solid #ddd;padding-bottom:14px;">';
	echo '<h4 style="margin-bottom:4px;">Skład</h4>';
	echo '<p class="description" style="margin-top:0;">Z czego składa się danie – dodatki z katalogu <strong>Dodatki</strong> (nazwa produktu + skład mniejszą czcionką na liście, w koszyku i w Kuchni). Wybór klienta „jedno z kilku” zastępuje tu dodatek tego samego typu albo się dopisuje (np. bez węglowodanów w składzie – wybrane frytki dopiszą się), „Bez …” go skreśla. Dodatki z typem w modyfikacjach biorą nazwę stąd.</p>';
	echo '<div id="rzd-sklad-rows" data-next="' . (int) count( $sklad ) . '">';
	foreach ( $sklad as $i => $ingredient_id ) {
		echo rzd_render_sklad_row( $i, $ingredient_id, $ingredients );
	}
	echo '</div>';
	echo '<p><button type="button" class="button" id="rzd-add-sklad">+ Dodaj do składu</button></p>';
	echo '<script type="text/html" id="rzd-sklad-template">' . rzd_render_sklad_row( '__I__', 0, $ingredients ) . '</script>';
	echo '</div>';

	echo '<p style="padding:0 12px;color:#555;">' . esc_html__( 'Dodaj grupę (np. "Dodaj do zestawu"), a w środku modyfikacje – każda (poza polem tekstowym i „Powiel skład”) odwołuje się do dodatku z katalogu Dodatki i określa swoją rolę wobec niego. Klient zobaczy to w okienku wyboru tuż przed dodaniem produktu do koszyka.', 'rzd' ) . '</p>';

	rzd_render_sections_editor( $sections );
	?>
	<?php echo rzd_js_tag( 'assets/js/admin/rzd-sklad.js' ); // phpcs:ignore ?>
	<?php
	echo '</div>';
} );

/**
 * Edytor grup modyfikacji (wspólny dla produktu i dla „Wzorów
 * modyfikacji” z modułu 18): lista grup, przycisk „+ Dodaj grupę”, szablony
 * i obsługa w JS. Pola mają nazwy rzd_section[…] – zapis w obu miejscach
 * idzie przez rzd_sanitize_sections().
 * Licznik kolejnej grupy siedzi w atrybucie data-next na #rzd-sections, żeby
 * mógł z niego korzystać także przycisk „Dodaj z predefiniowanych”.
 * $with_presets = true → pod edytorem wybór wzoru (tylko na produkcie).
 */
function rzd_render_sections_editor( $sections, $with_presets = true ) {
	$sections = is_array( $sections ) ? array_values( $sections ) : array();

	echo '<div id="rzd-sections" data-next="' . (int) count( $sections ) . '">';
	foreach ( $sections as $si => $section ) {
		echo rzd_render_section( $si, $section );
	}
	echo '</div>';
	echo '<p style="padding:0 12px;"><button type="button" class="button button-primary" id="rzd-add-section">+ ' . esc_html__( 'Dodaj grupę', 'rzd' ) . '</button></p>';

	if ( $with_presets && function_exists( 'rzd_render_preset_picker' ) ) {
		rzd_render_preset_picker(); // moduł 18
	}

	echo '<script type="text/html" id="rzd-section-template">' . rzd_render_section( '__S__', array() ) . '</script>';
	echo '<script type="text/html" id="rzd-item-template">' . rzd_render_group( '__S__][items][__M__', array() ) . '</script>';
	echo '<script type="text/html" id="rzd-opt-template">' . rzd_render_option_row( '__S____M__', '__I__', array() ) . '</script>';
	?>
	<?php echo rzd_js_tag( 'assets/js/admin/rzd-modyfikacje-edytor.js' ); // phpcs:ignore ?>
	<?php
}

