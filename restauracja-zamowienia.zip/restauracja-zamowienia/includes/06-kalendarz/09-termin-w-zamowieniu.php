<?php
/**
 * Moduł 06-kalendarz – termin w zamówieniu (box na górze, kolumna na liście).
 * Część modułu (pliki wczytywane po kolei – kolejność jak w dawnym jednym pliku).
 */

/* ============================================================
 * 7. TERMIN W ZAMÓWIENIU
 * ============================================================ */
function dc_save_slot_to_order( $order ) {
	$slot = dc_get_slot();
	if ( $slot && dc_enabled() ) {
		$order->update_meta_data( '_dc_delivery_date', $slot['date'] );
		$order->update_meta_data( '_dc_delivery_time', $slot['time'] );
	}
}
add_action( 'woocommerce_checkout_create_order', 'dc_save_slot_to_order', 10, 1 );
add_action( 'woocommerce_store_api_checkout_update_order_from_request', 'dc_save_slot_to_order', 10, 1 );

function dc_order_slot_label( $order ) {
	$d = $order->get_meta( '_dc_delivery_date' );
	$t = $order->get_meta( '_dc_delivery_time' );
	return ( $d && $t ) ? dc_slot_label( array( 'date' => $d, 'time' => $t ) ) : '';
}

/* ---------- Termin dostawy: duży, czytelny box NA GÓRZE zamówienia ---------- */
function dc_order_screen_ids() {
	return array( 'shop_order', 'woocommerce_page_wc-orders' );
}

add_action( 'add_meta_boxes', function () {
	foreach ( dc_order_screen_ids() as $screen ) {
		add_meta_box(
			'dc_delivery_slot_box',
			'Termin dostawy',
			'dc_render_order_slot_box',
			$screen,
			'normal',
			'high' // wyżej niż standardowe sekcje WooCommerce
		);
	}
} );

function dc_render_order_slot_box( $post_or_order ) {
	$order = ( $post_or_order instanceof WC_Order ) ? $post_or_order : wc_get_order( $post_or_order->ID );
	if ( ! $order ) {
		return;
	}
	$l = dc_order_slot_label( $order );
	if ( ! $l ) {
		echo '<p style="margin:0;color:#777">Brak wybranego terminu dostawy.</p>';
		return;
	}
	$d = $order->get_meta( '_dc_delivery_date' );
	$t = $order->get_meta( '_dc_delivery_time' );
	echo '<div style="font-size:20px;line-height:1.4">'
		. '<span style="display:inline-block;background:#eef6ee;border:1px solid #bcd9bc;border-radius:6px;padding:6px 14px;font-weight:700;">'
		. esc_html( ucfirst( dc_date_label( $d ) ) ) . ' &middot; godz. ' . esc_html( $t )
		. '</span></div>';
}
add_action( 'woocommerce_order_details_after_order_table', function ( $order ) {
	$l = dc_order_slot_label( $order );
	if ( $l ) {
		echo '<p><strong>Termin dostawy:</strong> ' . esc_html( $l ) . '</p>';
	}
} );
/* ---------- Kolumna z terminem dostawy na liście zamówień (sortowalna) ---------- */
add_filter( 'manage_edit-shop_order_columns', 'dc_add_order_column' );
add_filter( 'woocommerce_shop_order_list_table_columns', 'dc_add_order_column' );
function dc_add_order_column( $columns ) {
	$new = array();
	foreach ( $columns as $key => $label ) {
		$new[ $key ] = $label;
		if ( 'order_status' === $key ) {
			$new['dc_delivery'] = 'Termin dostawy';
		}
	}
	return $new;
}

add_action( 'manage_shop_order_posts_custom_column', 'dc_render_order_column', 10, 2 );
add_action( 'woocommerce_shop_order_list_table_custom_column', 'dc_render_order_column', 10, 2 );
function dc_render_order_column( $column, $post_or_order_id ) {
	if ( 'dc_delivery' !== $column ) {
		return;
	}
	$order = ( $post_or_order_id instanceof WC_Order ) ? $post_or_order_id : wc_get_order( $post_or_order_id );
	$l     = $order ? dc_order_slot_label( $order ) : '';
	echo $l ? esc_html( $l ) : '&mdash;';
}

add_filter( 'manage_edit-shop_order_sortable_columns', 'dc_sortable_order_column' );
add_filter( 'woocommerce_shop_order_list_table_sortable_columns', 'dc_sortable_order_column' );
function dc_sortable_order_column( $columns ) {
	$columns['dc_delivery'] = 'dc_delivery';
	return $columns;
}

add_action( 'pre_get_posts', function ( $query ) {
	if ( is_admin() && $query->is_main_query() && 'dc_delivery' === $query->get( 'orderby' ) ) {
		$query->set( 'meta_key', '_dc_delivery_date' );
		$query->set( 'orderby', 'meta_value' );
	}
} );
add_filter( 'woocommerce_order_query_args', function ( $args ) {
	if ( isset( $args['orderby'] ) && 'dc_delivery' === $args['orderby'] ) {
		$args['meta_key'] = '_dc_delivery_date';
		$args['orderby']  = 'meta_value';
	}
	return $args;
} );

add_filter( 'woocommerce_email_order_meta_fields', function ( $fields, $sent_to_admin, $order ) {
	$l = dc_order_slot_label( $order );
	if ( $l ) {
		$fields['dc_slot'] = array( 'label' => 'Termin dostawy', 'value' => $l );
	}
	return $fields;
}, 10, 3 );
