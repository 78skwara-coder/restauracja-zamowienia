<?php
/**
 * Moduł 06-kalendarz – front: pasek z terminem, okno wyboru, blokada bez terminu.
 * Część modułu (pliki wczytywane po kolei – kolejność jak w dawnym jednym pliku).
 */

/* ============================================================
 * 6. FRONTEND: pasek z terminem, okno wyboru, blokada bez terminu
 * ============================================================ */
function dc_render_bar() {
	if ( ! dc_enabled() ) {
		return '';
	}
	$slot = dc_current_slot();
	ob_start();
	?>
	<div class="dc-bar<?php echo $slot ? '' : ' dc-bar-empty'; ?>">
		<?php if ( $slot ) : ?>
			<span>Dostawa: <strong class="dc-bar-label"><?php echo esc_html( dc_slot_label_town( $slot ) ); ?></strong></span>
			<button type="button" class="dc-change">Zmień termin</button>
		<?php else : ?>
			<span>Termin dostawy wybierzesz przy dodawaniu pierwszego produktu do koszyka.</span>
		<?php endif; ?>
	</div>
	<?php
	return ob_get_clean();
}
add_shortcode( 'dc_termin', 'dc_render_bar' );
add_action( 'woocommerce_before_cart', function () { echo dc_render_bar(); } );
add_action( 'woocommerce_before_checkout_form', function () { echo dc_render_bar(); }, 5 );

add_action( 'wp_head', function () {
	if ( ! dc_enabled() ) {
		return;
	}
	?>
	<?php echo rzd_css_tag( 'assets/css/rzd-termin.css', 'rzd-termin-css' ); // phpcs:ignore ?>
	<?php
} );

add_action( 'wp_footer', 'dc_footer', 15 ); // znaczniki okienek przed skryptami stopki (20)
// dane dla skryptu okienka terminu (assets/js/rzd-termin.js).
function dc_front_data() {
	$data = array(
		'slotsUrl' => WC_AJAX::get_endpoint( 'dc_slots' ),
		'setUrl'   => WC_AJAX::get_endpoint( 'dc_set_slot' ),
		'slot'     => dc_current_slot(),
		'checkUrl' => WC_AJAX::get_endpoint( 'dc_check' ),
		'cartUrl'  => wc_get_cart_url(),
		'listUrl'  => function_exists( 'kc_list_url' ) && kc_list_url() ? kc_list_url() : wc_get_page_permalink( 'shop' ),
		'town'     => function_exists( 'rzd_session_town' ) ? rzd_session_town() : '',
	);
	// zalogowany bez wybranej miejscowości – domyślnie miasto z konta
	// (o ile jest na liście). Inne miasto klient wybiera już świadomie.
	if ( '' === $data['town'] && function_exists( 'rzd_account_town' ) && function_exists( 'rzd_towns_enabled' ) && rzd_towns_enabled() ) {
		$acc_row      = rzd_town_find( rzd_account_town() );
		$data['town'] = $acc_row ? $acc_row['name'] : '';
	}
	return $data;
}

add_action( 'wp_enqueue_scripts', function () {
	if ( ! dc_enabled() ) {
		return;
	}
	wp_enqueue_script( 'rzd-termin', RZD_PLUGIN_URL . 'assets/js/rzd-termin.js', array(), rzd_asset_ver( 'assets/js/rzd-termin.js' ), array( 'in_footer' => true, 'strategy' => 'defer' ) );
	wp_add_inline_script( 'rzd-termin', 'var dcData = ' . wp_json_encode( dc_front_data() ) . ';', 'before' );
} );

function dc_footer() {
	if ( ! dc_enabled() || is_admin() ) {
		return;
	}
	$towns_on = function_exists( 'rzd_towns_enabled' ) && rzd_towns_enabled();
	?>
	<div id="dc-modal" hidden>
		<div class="dc-panel" role="dialog" aria-modal="true" aria-labelledby="dc-title">
			<h3 id="dc-title" class="dc-title">Wybierz termin dostawy</h3>
			<p class="dc-msg"></p>
			<?php if ( $towns_on ) : ?>
			<?php // lista rozwijana zamiast pola z podpowiedziami (datalist po wyborze pokazywał tylko wybrane miasto). ?>
			<label class="dc-field">Miejscowość dostawy<select class="dc-town">
				<option value="">— wybierz miejscowość z listy —</option>
				<?php foreach ( rzd_towns() as $trow ) : ?>
					<option value="<?php echo esc_attr( $trow['name'] ); ?>"><?php echo esc_html( $trow['name'] ); ?></option>
				<?php endforeach; ?>
			</select></label>
			<?php endif; ?>
			<label class="dc-field">Data dostawy<select class="dc-date"></select></label>
			<div class="dc-field">Godzina dostawy<div class="dc-times"></div></div>
			<div class="dc-actions">
				<div class="dc-act"><button type="button" class="dc-cancel">Anuluj</button></div>
				<div class="dc-act"><button type="button" class="dc-ok" disabled>Zatwierdź termin</button></div>
			</div>
		</div>
	</div>
	<div id="dc-conflict" hidden>
		<div class="dc-panel" role="dialog" aria-modal="true">
			<h3 class="dc-title dc-conf-title">Zmień datę, by dodać do koszyka</h3>
			<p class="dc-msg dc-err dc-conflict-msg"></p>
			<div class="dc-actions">
				<div class="dc-act"><button type="button" class="dc-conf-other">Wybierz inny produkt</button></div>
				<div class="dc-act dc-act-change"><button type="button" class="dc-ok dc-conf-change">Zmień datę dostawy</button></div>
				<div class="dc-act dc-act-cart" hidden><button type="button" class="dc-ok dc-conf-cart">Przejdź do koszyka</button></div>
			</div>
		</div>
	</div>

	<!-- Wersja informacyjna tego samego komunikatu (ikonka "i" na liście) –
	     tylko wyjaśnia, dlaczego produkt jest zablokowany, bez akcji zmiany
	     terminu wprost stąd – klient i tak zobaczy je przy próbie dodania. -->
	<div id="dc-info-popup" hidden>
		<div class="dc-panel" role="dialog" aria-modal="true">
			<h3 class="dc-title">Zmień datę, by dodać do koszyka</h3>
			<p class="dc-msg dc-err dc-info-msg"></p>
			<div class="dc-actions">
				<div class="dc-act"><button type="button" class="dc-ok dc-info-close">OK</button></div>
			</div>
		</div>
	</div>
	
	<?php
}

