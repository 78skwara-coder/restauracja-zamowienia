<?php
/**
 * MODUŁ 06: Kalendarz terminów dostawy – termin wybierany PRZED zakupem
 *
 * JAK TO DZIAŁA
 * - Ustawienia: Panel restauracji → Terminy (moduł 34, od 2.45.0). Dla każdej grupy (kategorii
 *   produktów) ustawiasz: godziny wyjazdu, cutoff dzienny (godzina + ile dni
 *   przed dostawą), min. czas przed wyjazdem, dni dostaw, horyzont i dni wolne.
 * - Matryca "Godziny dostaw w dniach tygodnia": dla każdej grupy
 *   i dla wszystkich grup naraz przedział "od–do" godzin dostawy w danym dniu
 *   tygodnia. Obowiązuje węższy z nich (późniejszy początek, wcześniejszy
 *   koniec) – patrz rzd_dc_window_for_date().
 * - Produkt musi należeć do grupy (kategorii) z zapisanym kalendarzem – bez tego
 *   nie da się go zamówić. Podkategoria dziedziczy kalendarz kategorii nadrzędnej.
 * - Klient klikając PIERWSZY produkt musi wybrać datę i godzinę dostawy.
 *   Domyślnie zaznaczony jest najwcześniejszy możliwy termin dla tego produktu.
 * - Każdy kolejny produkt musi się dać dostarczyć w tym terminie – inaczej
 *   dodanie jest blokowane z komunikatem. Termin można zmienić (przycisk
 *   "Zmień termin") – widać wtedy tylko terminy pasujące do WSZYSTKICH
 *   produktów w koszyku.
 * - Dostępność produktu w dniu dostawy: zestawy (moduł 04) i ich składowe
 *   sprawdzane są po dniu (bez godzin). Dla zwykłych produktów z własną datą
 *   ważności podepnij swój kod pod filtr 'dc_product_available_on'.
 * - Termin zapisuje się w zamówieniu (panel, maile, strona zamówienia).
 *
 * Wymaga modułu 08 (brama dodawania do koszyka), który uruchamia okno wyboru terminu.
 * Shortcode [wybierz_date_dostawy] wstawia przycisk otwierający wybór daty dostawy.
 *
 * Nic nie działa, dopóki nie zaznaczysz "Włącz wybór terminu dostawy"
 * na stronie Terminy – możesz spokojnie wgrać i skonfigurować.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 0. USTAWIENIA
 * ============================================================ */
function rzd_dc_days() {
	return array( 'Mon' => 'Pon', 'Tue' => 'Wt', 'Wed' => 'Śr', 'Thu' => 'Czw', 'Fri' => 'Pt', 'Sat' => 'Sob', 'Sun' => 'Ndz' );
}

function rzd_dc_default_group() {
	return array(
		'times'   => array(),
		'cutoff'  => '',
		'cutoff_days' => 0, // ile dni PRZED dniem dostawy obowiązuje godzina cutoffu (0 = w dniu dostawy)
		'lead'    => 0,
		'days'    => array_keys( rzd_dc_days() ),
		'horizon' => 7,
		'blocked' => array(),
		'valid_from' => '',
		'valid_to'   => '',
		'window'     => array(), // matryca: [ 'Mon' => [ 'from' => 'HH:MM', 'to' => 'HH:MM' ], … ]
	);
}

function rzd_dc_get_settings( $reset = false ) {
	static $cache = null;
	if ( $reset ) {
		$cache = null; // po zapisie w tym samym żądaniu (Panel restauracji odsyła świeże dane)
	}
	if ( null !== $cache ) {
		return $cache;
	}
	$s = get_option( 'dc_settings', array() );
	$s = is_array( $s ) ? $s : array();
	$s = wp_parse_args( $s, array( 'enabled' => 0, 'global_blocked' => array(), 'groups' => array(), 'max_per_slot' => 6, 'global_window' => array(), 'off_days' => array(), 'win_on' => 0, 'win_defs' => array(), 'win_days' => array(), 'win_next' => 1 ) );

	$groups = array();
	foreach ( (array) $s['groups'] as $term_id => $g ) {
		$groups[ (int) $term_id ] = wp_parse_args( (array) $g, rzd_dc_default_group() );
	}
	$s['groups'] = $groups;

	$cache = $s;
	return $cache;
}

function rzd_dc_enabled() {
	if ( is_admin() && ! wp_doing_ajax() ) {
		return false;
	}
	$s = rzd_dc_get_settings();
	return ! empty( $s['enabled'] );
}

function rzd_dc_max_horizon() {
	$s   = rzd_dc_get_settings();
	$max = 0;
	foreach ( $s['groups'] as $g ) {
		$max = max( $max, (int) $g['horizon'] );
	}
	return min( 60, $max );
}

function rzd_dc_parse_times( $text ) {
	$out = array();
	foreach ( preg_split( '/[\s,;]+/', (string) $text, -1, PREG_SPLIT_NO_EMPTY ) as $t ) {
		if ( preg_match( '/^(\d{1,2}):(\d{2})$/', $t, $m ) && (int) $m[1] < 24 && (int) $m[2] < 60 ) {
			$out[] = sprintf( '%02d:%02d', $m[1], $m[2] );
		}
	}
	$out = array_values( array_unique( $out ) );
	sort( $out );
	return $out;
}

function rzd_dc_parse_dates( $text ) {
	$out = array();
	foreach ( preg_split( '/[\s,;]+/', (string) $text, -1, PREG_SPLIT_NO_EMPTY ) as $d ) {
		if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $d ) ) {
			$out[] = $d;
		}
	}
	$out = array_values( array_unique( $out ) );
	sort( $out );
	return $out;
}

// $g musi być już po wp_unslash()
function rzd_dc_sanitize_group( $g ) {
	$g    = is_array( $g ) ? $g : array();
	$days = isset( $g['days'] )
		? array_values( array_intersect( array_map( 'sanitize_text_field', (array) $g['days'] ), array_keys( rzd_dc_days() ) ) )
		: array();
	return array(
		'times'   => rzd_dc_parse_times( isset( $g['times'] ) ? $g['times'] : '' ),
		'cutoff'  => isset( $g['cutoff'] ) ? rzd_clean_time( $g['cutoff'] ) : '',
		'cutoff_days' => isset( $g['cutoff_days'] ) ? max( 0, min( 60, absint( $g['cutoff_days'] ) ) ) : 0,
		'lead'    => isset( $g['lead'] ) ? max( 0, min( 1440, absint( $g['lead'] ) ) ) : 0,
		'days'    => $days,
		'horizon' => isset( $g['horizon'] ) ? max( 0, min( 60, absint( $g['horizon'] ) ) ) : 7,
		'blocked' => rzd_dc_parse_dates( isset( $g['blocked'] ) ? $g['blocked'] : '' ),
		'valid_from' => ( isset( $g['valid_from'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $g['valid_from'] ) ) ? $g['valid_from'] : '',
		'valid_to'   => ( isset( $g['valid_to'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $g['valid_to'] ) ) ? $g['valid_to'] : '',
	);
	// 'window' (matryca) celowo NIE jest tu czytane – zapisuje ją osobny
	// formularz matrycy; zapis grupy przenosi starą wartość (dc_save_group).
}

// Matryca "od–do" jednego wiersza: [ 'All' => […], 'Mon' => [ 'from' => '', 'to' => '' ], … ]
// 'All' = kolumna "Wszystkie dni" (dotyczy każdego dnia tygodnia tego wiersza).
function rzd_dc_sanitize_window( $w ) {
	$w   = is_array( $w ) ? $w : array();
	$out = array();
	foreach ( array_merge( array( 'All' ), array_keys( rzd_dc_days() ) ) as $d ) {
		$from = isset( $w[ $d ]['from'] ) ? rzd_clean_time( $w[ $d ]['from'] ) : '';
		$to   = isset( $w[ $d ]['to'] ) ? rzd_clean_time( $w[ $d ]['to'] ) : '';
		if ( '' !== $from || '' !== $to ) {
			$out[ $d ] = array( 'from' => $from, 'to' => $to );
		}
	}
	return $out;
}

