<?php
/**
 * Moduł 06-kalendarz – panel admina (Restauracja → Terminy).
 * Część modułu (pliki wczytywane po kolei – kolejność jak w dawnym jednym pliku).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 1. PANEL ADMINA: Restauracja → Terminy (menu w module 00-menu, adres delivery-calendar)
 *    Każda grupa ma własny formularz i zapisuje się niezależnie.
 * ============================================================ */

function rzd_dc_raw_settings() {
	$s = get_option( 'dc_settings', array() );
	return is_array( $s ) ? $s : array();
}

function rzd_dc_admin_guard() {
	if ( ! current_user_can( 'rzd_p_settings' ) ) {
		wp_die( 'Brak uprawnień.' );
	}
	$nonce = isset( $_POST['dc_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['dc_nonce'] ) ) : '';
	if ( ! wp_verify_nonce( $nonce, 'dc_save' ) ) {
		wp_die( 'Formularz wygasł – odśwież stronę Terminy i spróbuj ponownie.' );
	}
}

function rzd_dc_admin_redirect( $args = array() ) {
	wp_safe_redirect( add_query_arg( array_merge( array( 'page' => 'delivery-calendar' ), $args ), admin_url( 'admin.php' ) ) );
	exit;
}

// Ustawienia ogólne: włączenie + dni bez dostaw dla wszystkich grup
add_action( 'admin_post_dc_save_general', function () {
	rzd_dc_admin_guard();
	$post = wp_unslash( $_POST );
	$s    = rzd_dc_raw_settings();

	$s['enabled']        = empty( $post['dc_enabled'] ) ? 0 : 1;
	$s['global_blocked'] = rzd_dc_parse_dates( isset( $post['dc_global_blocked'] ) ? $post['dc_global_blocked'] : '' );
	$s['max_per_slot']   = isset( $post['dc_max_per_slot'] ) ? max( 1, absint( $post['dc_max_per_slot'] ) ) : 6;
	update_option( 'dc_settings', $s, true );
	rzd_dc_clear_slots_cache();

	rzd_dc_admin_redirect( array( 'saved' => 'general' ) );
} );

// Zapis JEDNEJ grupy
add_action( 'admin_post_dc_save_group', function () {
	rzd_dc_admin_guard();
	$post    = wp_unslash( $_POST );
	$term_id = isset( $post['term_id'] ) ? absint( $post['term_id'] ) : 0;
	if ( ! $term_id || ! term_exists( $term_id, 'product_cat' ) ) {
		wp_die( 'Nieprawidłowa grupa.' );
	}

	$s      = rzd_dc_raw_settings();
	$groups = ( isset( $s['groups'] ) && is_array( $s['groups'] ) ) ? $s['groups'] : array();
	$g      = rzd_dc_sanitize_group( isset( $post['dc_g'] ) ? $post['dc_g'] : array() );
	// matryca godzin tej grupy zapisuje się osobnym formularzem – nie gubimy jej
	$g['window'] = ( isset( $groups[ $term_id ]['window'] ) && is_array( $groups[ $term_id ]['window'] ) ) ? $groups[ $term_id ]['window'] : array();

	$groups[ $term_id ] = $g;
	$s['groups']        = $groups;
	update_option( 'dc_settings', $s, true );
	rzd_dc_clear_slots_cache();

	$args = array( 'saved' => 'group', 'open' => $term_id );
	if ( empty( $g['times'] ) ) {
		$args['empty'] = 1;
	}
	rzd_dc_admin_redirect( $args );
} );

// Zapis matrycy "Godziny dostaw w dniach tygodnia" (wszystkie grupy + wiersz globalny)
add_action( 'admin_post_dc_save_matrix', function () {
	rzd_dc_admin_guard();
	$post = wp_unslash( $_POST );
	$w    = ( isset( $post['dc_w'] ) && is_array( $post['dc_w'] ) ) ? $post['dc_w'] : array();
	$s    = rzd_dc_raw_settings();

	$s['global_window'] = rzd_dc_sanitize_window( isset( $w['global'] ) ? $w['global'] : array() );
	// Wiersz "Dostawy wyłączone": dni tygodnia bez dostaw we wszystkich grupach.
	$s['off_days'] = array_values( array_intersect( (array) ( isset( $post['dc_off_days'] ) ? $post['dc_off_days'] : array() ), array_keys( rzd_dc_days() ) ) );
	if ( isset( $s['groups'] ) && is_array( $s['groups'] ) ) {
		foreach ( $s['groups'] as $term_id => $g ) {
			// tylko grupy z zapisanym kalendarzem mają wiersz w matrycy
			$s['groups'][ $term_id ]['window'] = rzd_dc_sanitize_window( isset( $w[ $term_id ] ) ? $w[ $term_id ] : array() );
		}
	}
	update_option( 'dc_settings', $s, true );
	rzd_dc_clear_slots_cache();

	rzd_dc_admin_redirect( array( 'saved' => 'matrix' ) );
} );

// Zapis okien dostaw: przełącznik trybu, katalog okien i oś każdego dnia tygodnia.
add_action( 'admin_post_dc_save_windows', function () {
	rzd_dc_admin_guard();
	$post = wp_unslash( $_POST );
	$s    = rzd_dc_raw_settings();
	$next = isset( $s['win_next'] ) ? max( 1, (int) $s['win_next'] ) : 1;
	$old  = ( isset( $s['win_defs'] ) && is_array( $s['win_defs'] ) ) ? $s['win_defs'] : array();

	$defs = array();
	foreach ( (array) ( isset( $post['dc_win'] ) ? $post['dc_win'] : array() ) as $row ) {
		$name = sanitize_text_field( isset( $row['name'] ) ? $row['name'] : '' );
		$len  = isset( $row['len'] ) ? absint( $row['len'] ) : 0;
		$cap  = isset( $row['cap'] ) ? absint( $row['cap'] ) : 0;
		if ( '' === $name && ! $len && ! $cap ) {
			continue; // pusty wiersz
		}
		$id = isset( $row['id'] ) ? sanitize_key( $row['id'] ) : '';
		if ( '' === $id || ! isset( $old[ $id ] ) || isset( $defs[ $id ] ) ) {
			$id = 'w' . $next++;
		}
		$defs[ $id ] = array(
			'name' => '' !== $name ? $name : 'Okno ' . $id,
			'len'  => max( 5, min( 600, $len ? $len : 60 ) ),
			'cap'  => max( 1, min( 99, $cap ? $cap : 6 ) ),
		);
	}

	$days = array();
	$in   = ( isset( $post['dc_wday'] ) && is_array( $post['dc_wday'] ) ) ? $post['dc_wday'] : array();
	foreach ( array_keys( rzd_dc_days() ) as $dow ) {
		$d   = isset( $in[ $dow ] ) && is_array( $in[ $dow ] ) ? $in[ $dow ] : array();
		$seq = array();
		foreach ( (array) ( isset( $d['seq'] ) ? $d['seq'] : array() ) as $id ) {
			$id = sanitize_key( $id );
			if ( '' !== $id && isset( $defs[ $id ] ) ) {
				$seq[] = $id; // to samo okno może wystąpić w dniu kilka razy
			}
		}
		$days[ $dow ] = array(
			'on'    => empty( $d['on'] ) ? 0 : 1,
			'start' => rzd_clean_time( isset( $d['start'] ) ? $d['start'] : '' ),
			'seq'   => $seq,
		);
	}

	$s['win_on']   = empty( $post['dc_win_on'] ) ? 0 : 1;
	$s['win_defs'] = $defs;
	$s['win_days'] = $days;
	$s['win_next'] = $next;
	update_option( 'dc_settings', $s, true );
	rzd_dc_clear_slots_cache();

	rzd_dc_admin_redirect( array( 'saved' => 'windows' ) );
} );

// Usunięcie kalendarza jednej grupy
add_action( 'admin_post_dc_delete_group', function () {
	rzd_dc_admin_guard();
	$term_id = isset( $_POST['term_id'] ) ? absint( $_POST['term_id'] ) : 0;
	$s       = rzd_dc_raw_settings();
	if ( $term_id && isset( $s['groups'][ $term_id ] ) ) {
		unset( $s['groups'][ $term_id ] );
		update_option( 'dc_settings', $s, true );
		rzd_dc_clear_slots_cache();
	}
	rzd_dc_admin_redirect( array( 'saved' => 'deleted' ) );
} );

// Produkty, których nie da się zamówić, bo nie należą do żadnej skonfigurowanej grupy
function rzd_dc_products_without_group() {
	$ids = get_posts( array(
		'post_type'      => 'product',
		'post_status'    => 'publish',
		'posts_per_page' => 300,
		'fields'         => 'ids',
		'no_found_rows'  => true,
	) );
	$out = array();
	foreach ( $ids as $id ) {
		// dania tylko do zestawów (kategoria „Nie wyświetlaj w sklepie”) nie są zamawiane osobno;
		// pozostałe dania zestawów sprzedają się osobno w inne dni – potrzebują grupy
		if ( 'yes' === get_post_meta( $id, '_rwz_hidden_as_component_main', true ) && function_exists( 'rzd_zestaw_product_in_hidden_category' ) && rzd_zestaw_product_in_hidden_category( $id ) ) {
			continue;
		}
		if ( ! rzd_dc_group_ids_for_product( $id ) ) {
			$out[] = $id;
		}
	}
	return $out;
}

function rzd_dc_render_group_fields( $name, $g ) {
	?>
	<table class="form-table" role="presentation"><tbody>
		<tr>
			<th scope="row">Godziny wyjazdu</th>
			<td>
				<?php if ( rzd_dc_windows_on() ) : ?>
					<p class="description" style="margin-bottom:6px"><strong>Działa tryb okien dostaw</strong> – godziny grupy wynikają z okien w jej zakresie z matrycy „Godziny dostaw w dniach tygodnia”. Poniższe pole jest zachowane na wypadek powrotu do starego trybu.</p>
				<?php endif; ?>
				<input type="text" class="regular-text" name="<?php echo esc_attr( $name ); ?>[times]" value="<?php echo esc_attr( implode( ', ', (array) $g['times'] ) ); ?>" placeholder="08:00, 09:00, 10:00, 11:00">
				<p class="description">Godziny oddzielone przecinkami. To są godziny dostawy do wyboru dla tej grupy. Bez nich produkty z grupy nie mogą być zamówione.</p>
			</td>
		</tr>
		<tr>
			<th scope="row">Cutoff dzienny <span style="font-weight:400;color:#666;">(opcjonalnie)</span></th>
			<td>
				do godz. <input type="time" name="<?php echo esc_attr( $name ); ?>[cutoff]" value="<?php echo esc_attr( $g['cutoff'] ); ?>">
				<input type="number" min="0" max="60" step="1" name="<?php echo esc_attr( $name ); ?>[cutoff_days]" value="<?php echo esc_attr( (int) $g['cutoff_days'] ); ?>" style="width:70px"> dni przed dostawą
				<p class="description">Do której godziny i ile dni wcześniej trzeba złożyć zamówienie na dany dzień dostawy. <strong>0 dni</strong> = w dniu dostawy (po tej godzinie najwcześniejszy termin to następny dzień, niezależnie od tego, jak odległy jest jeszcze jakiś wyjazd). <strong>1 dzień</strong> = na jutro zamawia się do tej godziny dziś, np. ciasta: 10:30 i 1 dzień → do 10:30 można jeszcze zamówić na jutro, później najbliższy termin to pojutrze. <strong>2 dni</strong> = dwa dni wcześniej itd. <strong>Liczą się tylko dni dostaw tej grupy</strong> – dni nieodhaczone w „Dni dostaw” i daty wyłączone (święta) się pomija: przy pon–pt i 1 dniu na poniedziałek zamawia się do piątku, na wtorek do poniedziałku. Puste pole godziny przy 0 dniach = brak cutoffu dziennego; puste pole godziny przy 1+ dniach = do końca tamtego dnia. Zamówienie złożone dokładnie o tej godzinie jest jeszcze przyjęte.</p>
			</td>
		</tr>
		<tr>
			<th scope="row">Min. czas do wyjazdu (min) — cutoff dostawy</th>
			<td>
				<input type="number" name="<?php echo esc_attr( $name ); ?>[lead]" value="<?php echo esc_attr( $g['lead'] ); ?>" style="width:80px">
				<p class="description">O ile minut wcześniej niż konkretny wyjazd trzeba zamówić. To jest właściwy <strong>cutoff dostawy</strong> — liczony osobno dla KAŻDEGO terminu (godzina wyjazdu minus ta wartość), a nie jedna wspólna godzina na cały dzień. To on decyduje, kiedy dany termin znika z wyboru dla klienta i kiedy w module Kuchnia jest oznaczany jako zamknięty (można zaczynać przygotowanie/pakowanie, bo nic nowego już do niego nie dojdzie). 0 = wystarczy, że wyjazd jest później niż teraz.</p>
			</td>
		</tr>
		<tr>
			<th scope="row">Dni dostaw</th>
			<td>
				<?php foreach ( rzd_dc_days() as $key => $label ) : ?>
					<label style="margin-right:12px"><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[days][]" value="<?php echo esc_attr( $key ); ?>" <?php checked( in_array( $key, (array) $g['days'], true ) ); ?>> <?php echo esc_html( $label ); ?></label>
				<?php endforeach; ?>
				<p class="description">Zaznacz dni tygodnia, w które dowozisz. Brak zaznaczonych = brak dostaw.</p>
			</td>
		</tr>
		<tr>
			<th scope="row">Ile dni do przodu</th>
			<td>
				<input type="number" name="<?php echo esc_attr( $name ); ?>[horizon]" value="<?php echo esc_attr( $g['horizon'] ); ?>" style="width:80px">
				<p class="description">Maks. liczba dni od dziś, na które klient może zamawiać (0 = tylko dziś, maks. 60).</p>
			</td>
		</tr>
		<tr>
			<th scope="row">Kalendarz ważny od / do</th>
			<td>
				<input type="date" name="<?php echo esc_attr( $name ); ?>[valid_from]" value="<?php echo esc_attr( $g['valid_from'] ); ?>">
				–
				<input type="date" name="<?php echo esc_attr( $name ); ?>[valid_to]" value="<?php echo esc_attr( $g['valid_to'] ); ?>">
				<p class="description">Zakres dat DOSTAWY, w którym produkty tej grupy są dostępne (np. oferta sezonowa). Puste = bez ograniczeń.</p>
			</td>
		</tr>
		<tr>
			<th scope="row">Dni bez dostaw tej grupy</th>
			<td>
				<textarea name="<?php echo esc_attr( $name ); ?>[blocked]" rows="3" cols="30" placeholder="2026-12-24"><?php echo esc_textarea( implode( "\n", (array) $g['blocked'] ) ); ?></textarea>
				<p class="description">Jedna data na linię, format RRRR-MM-DD.</p>
			</td>
		</tr>
	</tbody></table>
	<?php
}

/**
 * Matryca "Godziny dostaw w dniach tygodnia": wiersze = "Wszystkie grupy"
 * + każda grupa z zapisanym kalendarzem, kolumny = dni tygodnia, w komórce
 * "od" i "do". Filtruje godziny wyjazdu grupy w danym dniu tygodnia dostawy.
 */
function rzd_dc_render_matrix( $s, $url, $nonce ) {
	$rows = array( 'global' => array( 'name' => 'Wszystkie grupy', 'window' => (array) $s['global_window'], 'days' => array_keys( rzd_dc_days() ) ) );
	foreach ( $s['groups'] as $term_id => $g ) {
		$term = get_term( (int) $term_id, 'product_cat' );
		if ( ! $term || is_wp_error( $term ) ) {
			continue;
		}
		$rows[ (int) $term_id ] = array( 'name' => $term->name, 'window' => (array) $g['window'], 'days' => (array) $g['days'] );
	}
	?>
	<h2 style="margin-top:28px">Godziny dostaw w dniach tygodnia</h2>
	<p class="description" style="max-width:820px">W każdej komórce: od której i do której godziny grupa dowozi w danym dniu tygodnia (dzień <strong>dostawy</strong>, nie dzień składania zamówienia). Klient widzi tylko te godziny wyjazdu grupy, które mieszczą się w przedziale (obie granice włącznie). Puste pole = bez ograniczenia z tej strony. Wiersz <strong>Wszystkie grupy</strong> dotyczy każdej grupy, a kolumna <strong>Wszystkie dni</strong> każdego dnia tygodnia (komórka na ich przecięciu – wszystkich grup we wszystkie dni). Gdy dla jednego terminu wypełnionych jest kilka komórek, obowiązuje najwęższy przedział — najpóźniejszy początek i najwcześniejszy koniec. Przykład: grupa w poniedziałek od 07:00, wszystkie grupy od 10:00 → klient zamawiający w piątek na poniedziałek zobaczy pierwszy termin o 10:00. Szare komórki = dzień, w którym grupa w ogóle nie dowozi (zaznaczasz to w „Dni dostaw” grupy).</p>
	<?php if ( rzd_dc_windows_on() ) : ?>
		<p class="description" style="max-width:820px"><strong>Tryb okien dostaw:</strong> grupa dostaje okna, które zaczynają się nie wcześniej niż „od” i kończą nie później niż „do” (okno przecięte granicą odpada). Dni bez dostaw ustawiasz w „Okna w dniach tygodnia” (znacznik Dostawa).</p>
	<?php endif; ?>
	<form method="post" action="<?php echo esc_url( $url ); ?>" novalidate>
		<input type="hidden" name="action" value="dc_save_matrix">
		<input type="hidden" name="dc_nonce" value="<?php echo esc_attr( $nonce ); ?>">
		<div style="overflow-x:auto;max-width:100%">
		<table class="widefat striped" style="width:auto">
			<thead><tr>
				<th>Grupa</th>
				<?php foreach ( array_merge( array( 'All' => 'Wszystkie dni' ), rzd_dc_days() ) as $label ) : ?>
					<th style="text-align:center"><?php echo esc_html( $label ); ?></th>
				<?php endforeach; ?>
			</tr></thead>
			<tbody>
				<?php if ( rzd_dc_windows_on() ) : ?>
					<?php foreach ( (array) $s['off_days'] as $dk ) : ?>
						<input type="hidden" name="dc_off_days[]" value="<?php echo esc_attr( $dk ); ?>">
					<?php endforeach; ?>
				<?php else : ?>
				<tr style="background:#fcf0f1">
					<th scope="row" style="white-space:nowrap"><strong>Dostawy wyłączone</strong></th>
					<td style="border-right:2px solid #c3c4c7;"></td>
					<?php foreach ( rzd_dc_days() as $dk => $dl ) : ?>
						<td style="text-align:center"><label title="Brak dostaw w ten dzień tygodnia we wszystkich grupach"><input type="checkbox" name="dc_off_days[]" value="<?php echo esc_attr( $dk ); ?>" <?php checked( in_array( $dk, (array) $s['off_days'], true ) ); ?>> wył.</label></td>
					<?php endforeach; ?>
				</tr>
				<?php endif; ?>
			<?php foreach ( $rows as $key => $row ) : ?>
				<tr<?php echo ( 'global' === $key ) ? ' style="background:#f0f6fc"' : ''; ?>>
					<th scope="row" style="white-space:nowrap"><strong><?php echo esc_html( $row['name'] ); ?></strong></th>
					<?php foreach ( array_merge( array( 'All' ), array_keys( rzd_dc_days() ) ) as $d ) :
						$from = isset( $row['window'][ $d ]['from'] ) ? $row['window'][ $d ]['from'] : '';
						$to   = isset( $row['window'][ $d ]['to'] ) ? $row['window'][ $d ]['to'] : '';
						$off  = ( 'All' !== $d ) && ! in_array( $d, $row['days'], true );
						$bad  = ( '' !== $from && '' !== $to && $from > $to );
						$td   = $off ? 'background:#f0f0f1;opacity:.6;' : ( $bad ? 'background:#fcf0f1;' : '' );
						$td  .= ( 'All' === $d ) ? 'border-right:2px solid #c3c4c7;' : '';
						$base = 'dc_w[' . $key . '][' . $d . ']';
						?>
						<td style="white-space:nowrap;<?php echo esc_attr( $td ); ?>" <?php echo $off ? 'title="Grupa nie dowozi w ten dzień"' : ( $bad ? 'title="Początek jest późniejszy niż koniec – w ten dzień nie będzie żadnej godziny"' : '' ); ?>>
							<input type="time" name="<?php echo esc_attr( $base ); ?>[from]" value="<?php echo esc_attr( $from ); ?>" style="width:96px" aria-label="od"><br>
							<input type="time" name="<?php echo esc_attr( $base ); ?>[to]" value="<?php echo esc_attr( $to ); ?>" style="width:96px;margin-top:4px" aria-label="do">
						</td>
					<?php endforeach; ?>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		</div>
		<?php if ( count( $rows ) < 2 ) : ?>
			<p class="description">Wiersze grup pojawią się po zapisaniu kalendarza grupy (niżej).</p>
		<?php endif; ?>
		<p class="description">W każdej komórce: górne pole „od”, dolne „do”. <strong>Dostawy wyłączone</strong> = w ten dzień tygodnia nie dowozimy wcale (wszystkie grupy); już złożone zamówienia zostają. Pojedyncze daty (święta) – „Dni bez dostaw” w ustawieniach ogólnych.</p>
		<p><button type="submit" class="button button-primary">Zapisz godziny dostaw</button></p>
	</form>
	<?php
}

/**
 * Sekcja „Okna dostaw”: przełącznik trybu, katalog okien (nazwa, długość,
 * pojemność) i oś dnia (dostawa tak/nie, start, kolejność okien).
 */
function rzd_dc_render_windows( $s, $url, $nonce ) {
	$defs = rzd_dc_win_defs();
	?>
	<h2 style="margin-top:28px">Okna dostaw</h2>
	<p class="description" style="max-width:820px">Okno = odcinek pracy kuriera o danej długości i pojemności w <strong>punktach</strong> (punkty zamówienia ustawiasz przy miejscowości, np. Piła 1, Kaczory 3). Okna są wspólne dla wszystkich grup. Dla każdego dnia tygodnia ustawiasz start i kolejność okien – idą jedno po drugim, bez przerw. Godzina wyjazdu terminu = start okna, klient widzi przedział okna (np. 11:00–12:00). Grupa dostaje okna ze swojego zakresu w matrycy „Godziny dostaw w dniach tygodnia”: początek zaokrąglany w górę do startu okna, koniec w dół do jego końca.</p>
	<form method="post" action="<?php echo esc_url( $url ); ?>" novalidate>
		<input type="hidden" name="action" value="dc_save_windows">
		<input type="hidden" name="dc_nonce" value="<?php echo esc_attr( $nonce ); ?>">
		<p><label><input type="checkbox" name="dc_win_on" value="1" <?php checked( ! empty( $s['win_on'] ) ); ?>> <strong>Używaj okien dostaw</strong> (zamiast godzin wyjazdu wpisanych w grupach)</label></p>
		<?php if ( ! empty( $s['win_on'] ) && ! $defs ) : ?>
			<div class="notice notice-warning inline"><p>Tryb okien jest zaznaczony, ale katalog okien jest pusty – dopóki nie dodasz okien, sklep działa po staremu.</p></div>
		<?php endif; ?>

		<h3>Katalog okien</h3>
		<table class="widefat striped" style="width:auto">
			<thead><tr><th>Nazwa</th><th>Długość (min)</th><th>Pojemność (pkt)</th><th>Krok w Planowaniu</th><th></th></tr></thead>
			<tbody id="dc-win-body">
			<?php
			$i = 0;
			foreach ( $defs as $id => $d ) {
				rzd_dc_render_window_row( $i++, $id, $d );
			}
			?>
			</tbody>
		</table>
		<p><button type="button" class="button" id="dc-win-add">+ Dodaj okno</button></p>
		<script type="text/template" id="dc-win-tpl"><?php rzd_dc_render_window_row( '__i__', '', array( 'name' => '', 'len' => 60, 'cap' => 6 ) ); ?></script>

		<h3>Okna w dniach tygodnia</h3>
		<?php if ( ! $defs ) : ?>
			<p class="description">Najpierw dodaj okna i zapisz – potem ułożysz je w dniach tygodnia.</p>
		<?php else : ?>
			<p class="description">Nowe okna z katalogu pojawią się na listach po zapisaniu. Puste pole listy = koniec dnia; po zapisie zawsze dochodzą trzy puste pola na kolejne okna.</p>
			<div style="overflow-x:auto;max-width:100%">
			<table class="widefat striped" style="width:auto">
				<thead><tr><th>Dzień</th><th>Dostawa</th><th>Start</th><th>Kolejność okien</th><th>Wychodzi</th></tr></thead>
				<tbody>
				<?php foreach ( rzd_dc_days() as $dow => $label ) :
					$day  = rzd_dc_win_day( $dow );
					$seq  = (array) $day['seq'];
					$base = 'dc_wday[' . $dow . ']';
					$line = rzd_dc_windows_for_dow( $dow );
					?>
					<tr<?php echo empty( $day['on'] ) ? ' style="background:#fcf0f1"' : ''; ?>>
						<th scope="row"><?php echo esc_html( $label ); ?></th>
						<td style="text-align:center"><input type="checkbox" name="<?php echo esc_attr( $base ); ?>[on]" value="1" <?php checked( ! empty( $day['on'] ) ); ?>></td>
						<td><input type="time" name="<?php echo esc_attr( $base ); ?>[start]" value="<?php echo esc_attr( $day['start'] ); ?>" style="width:96px"></td>
						<td>
							<?php // węższe pola, zawijają się zamiast rozpychać tabelę. ?>
							<div style="display:flex;flex-wrap:wrap;align-items:center;gap:4px;max-width:760px">
							<?php for ( $k = 0; $k < count( $seq ) + 3; $k++ ) :
								$cur = isset( $seq[ $k ] ) ? $seq[ $k ] : '';
								?>
								<select name="<?php echo esc_attr( $base ); ?>[seq][]" style="width:auto;min-width:0;max-width:110px;min-height:28px;padding:0 22px 0 6px;font-size:12px;line-height:26px">
									<option value="">–</option>
									<?php foreach ( $defs as $id => $d ) : ?>
										<option value="<?php echo esc_attr( $id ); ?>" <?php selected( $cur, $id ); ?>><?php echo esc_html( $d['name'] ); ?></option>
									<?php endforeach; ?>
								</select><?php echo ( $k < count( $seq ) + 2 ) ? '<span style="color:#888">→</span>' : ''; // phpcs:ignore ?>
							<?php endfor; ?>
							</div>
						</td>
						<td style="font-size:12px;white-space:nowrap">
							<?php
							if ( empty( $day['on'] ) ) {
								echo 'brak dostaw';
							} elseif ( '' === $day['start'] ) {
								echo '<span style="color:#b32d2e">brak godziny startu – brak dostaw</span>';
							} elseif ( ! $line ) {
								echo '<span style="color:#b32d2e">brak okien – brak dostaw</span>';
							} else {
								// skrót – początek–koniec dnia, liczba okien i suma punktów
								// (okna idą jedno po drugim bez przerw). Pełna lista w dymku.
								$bits = array();
								$pts  = 0;
								foreach ( $line as $w ) {
									$bits[] = $w['start'] . '–' . $w['end'] . ' ' . $w['name'] . ' (' . $w['cap'] . ' pkt)';
									$pts   += (int) $w['cap'];
								}
								$n     = count( $line );
								$okien = ( 1 === $n ) ? 'okno' : ( ( $n % 10 >= 2 && $n % 10 <= 4 && ( $n % 100 < 12 || $n % 100 > 14 ) ) ? 'okna' : 'okien' );
								$first = reset( $line );
								$last  = end( $line );
								echo '<span title="' . esc_attr( implode( "\n", $bits ) ) . '" style="cursor:help"><strong>' . esc_html( $first['start'] . '–' . $last['end'] ) . '</strong><br>'
									. esc_html( $n . ' ' . $okien . ' · ' . $pts . ' pkt' ) . '</span>'; // phpcs:ignore
								if ( count( $line ) < count( array_filter( $seq, function ( $id ) use ( $defs ) { return isset( $defs[ $id ] ); } ) ) ) {
									echo '<br><span style="color:#b32d2e">część okien wychodzi poza północ – pominięte</span>';
								}
							}
							?>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			</div>
		<?php endif; ?>
		<p><button type="submit" class="button button-primary">Zapisz okna dostaw</button></p>
	</form>
	<?php echo rzd_js_tag( 'assets/js/admin/rzd-kalendarz-okna.js' ); // phpcs:ignore ?>
	<?php
}

// Jeden wiersz katalogu okien (także szablon dla „+ Dodaj okno”).
function rzd_dc_render_window_row( $i, $id, $d ) {
	$name = 'dc_win[' . $i . ']';
	$len  = (int) $d['len'];
	$cap  = (int) $d['cap'];
	?>
	<tr>
		<td><input type="hidden" name="<?php echo esc_attr( $name ); ?>[id]" value="<?php echo esc_attr( $id ); ?>"><input type="text" name="<?php echo esc_attr( $name ); ?>[name]" value="<?php echo esc_attr( $d['name'] ); ?>" placeholder="np. Godzina" style="width:150px"></td>
		<td><input type="number" class="dc-win-len" min="5" max="600" step="5" name="<?php echo esc_attr( $name ); ?>[len]" value="<?php echo esc_attr( $len ); ?>" style="width:80px"></td>
		<td><input type="number" class="dc-win-cap" min="1" max="99" name="<?php echo esc_attr( $name ); ?>[cap]" value="<?php echo esc_attr( $cap ); ?>" style="width:70px"></td>
		<td class="dc-win-step"><?php echo ( $len && $cap ) ? esc_html( round( $len / $cap, 1 ) . ' min' ) : '–'; ?></td>
		<td><button type="button" class="button-link-delete dc-win-del" title="Usuń">✕</button></td>
	</tr>
	<?php
}

function rzd_dc_render_admin_page() {
	if ( ! current_user_can( 'rzd_p_settings' ) ) {
		return;
	}
	$s     = rzd_dc_get_settings();
	$terms = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false, 'orderby' => 'name' ) );
	if ( is_wp_error( $terms ) ) {
		$terms = array();
	}
	$open  = isset( $_GET['open'] ) ? absint( $_GET['open'] ) : 0;
	$saved = isset( $_GET['saved'] ) ? sanitize_key( wp_unslash( $_GET['saved'] ) ) : '';
	$nonce = wp_create_nonce( 'dc_save' );
	$url   = admin_url( 'admin-post.php' );
	?>
	<div class="wrap">
		<h1>Terminy</h1>

		<?php if ( $saved ) : ?>
			<div class="notice notice-success is-dismissible"><p><?php echo esc_html( 'deleted' === $saved ? 'Kalendarz grupy usunięty.' : ( 'matrix' === $saved ? 'Zapisano godziny dostaw w dniach tygodnia.' : ( 'windows' === $saved ? 'Zapisano okna dostaw.' : 'Zapisano.' ) ) ); ?></p></div>
			<?php if ( isset( $_GET['empty'] ) && ! rzd_dc_windows_on() ) : ?>
				<div class="notice notice-warning"><p>Ta grupa nie ma godzin wyjazdu – jej produkty nie mogą być zamówione, dopóki ich nie wpiszesz.</p></div>
			<?php endif; ?>
		<?php endif; ?>

		<h2>Ustawienia ogólne</h2>
		<form method="post" action="<?php echo esc_url( $url ); ?>" novalidate>
			<input type="hidden" name="action" value="dc_save_general">
			<input type="hidden" name="dc_nonce" value="<?php echo esc_attr( $nonce ); ?>">
			<p><label><input type="checkbox" name="dc_enabled" value="1" <?php checked( ! empty( $s['enabled'] ) ); ?>> <strong>Włącz wybór terminu dostawy w sklepie</strong></label></p>
			<p>
				<label><strong>Maksymalnie zamówień na jedno okno dostawy</strong></label><br>
				<input type="number" min="1" name="dc_max_per_slot" value="<?php echo esc_attr( isset( $s['max_per_slot'] ) ? $s['max_per_slot'] : 6 ); ?>" style="width:80px;">
			</p>
			<p class="description">Gdy okno osiągnie ten limit, znika z wyboru dla kolejnych klientów – tak jak po zamknięciu cutoffu. Dotyczy każdej godziny wyjazdu z osobna, we wszystkich kategoriach razem (to jedna fizyczna dostawa, nie limit na kategorię).<?php echo rzd_dc_windows_on() ? ' <strong>Teraz nieużywane – działa tryb okien dostaw, pojemność w punktach bierze się z okna.</strong>' : ''; ?></p>
			<p><strong>Dni bez dostaw (wszystkie grupy)</strong></p>
			<textarea name="dc_global_blocked" rows="3" cols="30" placeholder="2026-12-25"><?php echo esc_textarea( implode( "\n", (array) $s['global_blocked'] ) ); ?></textarea>
			<p class="description">Święta i dni zamknięcia – jedna data na linię (RRRR-MM-DD).</p>
			<button type="submit" class="button button-primary">Zapisz ustawienia ogólne</button>
		</form>

		<?php if ( ! empty( $s['enabled'] ) && function_exists( 'rzd_towns_enabled' ) && ! rzd_towns_enabled() ) : ?>
			<div class="notice notice-error inline" style="margin-top:20px"><p>
				<?php if ( ! rzd_towns() ) : ?>
					<strong>Lista miejscowości jest pusta.</strong> Dodaj miejscowości w <a href="<?php echo esc_url( admin_url( 'admin.php?page=rzd-towns' ) ); ?>">Restauracja → Miejscowości</a>.
				<?php else : ?>
					<strong>Metoda „Dostawa wg miejscowości” nie jest włączona w żadnej strefie wysyłki</strong> (WooCommerce → Ustawienia → Wysyłka).
				<?php endif; ?>
				Do tego czasu klient nie wybiera miejscowości w okienku terminu, w adresie można wpisać dowolną, a punkty okien liczą każde zamówienie jako 1.
			</p></div>
		<?php endif; ?>
		<?php
		// produkty „tylko na miejscu” (sala, moduł 33) nie potrzebują kalendarza dostaw
		$brak = array_values( array_filter( rzd_dc_products_without_group(), function ( $x ) {
			$id = is_object( $x ) ? ( method_exists( $x, 'get_id' ) ? $x->get_id() : ( isset( $x->ID ) ? $x->ID : 0 ) ) : (int) $x;
			return ! ( function_exists( 'rzd_product_sell' ) && $id && 'onsite' === rzd_product_sell( $id ) );
		} ) );
		?>
		<?php if ( $brak ) : ?>
			<div class="notice notice-warning inline" style="margin-top:20px"><p>
				<strong>Produkty bez skonfigurowanej grupy (<?php echo (int) count( $brak ); ?>) nie mogą być zamówione:</strong>
				<?php
				$nazwy = array_map( 'get_the_title', array_slice( $brak, 0, 15 ) );
				echo esc_html( implode( ', ', $nazwy ) . ( count( $brak ) > 15 ? ' …' : '' ) );
				?>
			</p></div>
		<?php endif; ?>

		<?php rzd_dc_render_windows( $s, $url, $nonce ); ?>

		<?php rzd_dc_render_matrix( $s, $url, $nonce ); ?>

		<h2>Grupy (kategorie produktów)</h2>
		<p class="description">Każdą grupę zapisujesz osobnym przyciskiem. Kalendarz mają tylko grupy zapisane poniżej – produkt musi należeć do co najmniej jednej z nich (podkategoria dziedziczy kalendarz nadrzędnej). Produkt w kilku grupach musi spełniać kalendarze wszystkich.</p>
		<?php
		foreach ( $terms as $t ) {
			$conf = isset( $s['groups'][ $t->term_id ] );
			$g    = $conf ? $s['groups'][ $t->term_id ] : rzd_dc_default_group();
			if ( ! $conf ) {
				$info = 'brak kalendarza';
			} elseif ( rzd_dc_windows_on() ) {
				$info = 'okna dostaw' . ( $g['cutoff'] ? ' · cutoff dzienny ' . $g['cutoff'] : '' ) . ( (int) $g['cutoff_days'] > 0 ? ( $g['cutoff'] ? '' : ' · cutoff' ) . ' (' . (int) $g['cutoff_days'] . ' dn. przed dostawą)' : '' );
			} elseif ( empty( $g['times'] ) ) {
				$info = 'brak godzin wyjazdu!';
			} else {
				$info = implode( ', ', $g['times'] ) . ( $g['cutoff'] ? ' · cutoff dzienny ' . $g['cutoff'] : '' ) . ( (int) $g['cutoff_days'] > 0 ? ( $g['cutoff'] ? '' : ' · cutoff' ) . ' (' . (int) $g['cutoff_days'] . ' dn. przed dostawą)' : '' );
			}
			?>
			<details style="background:#fff;border:1px solid #c3c4c7;padding:8px 14px;margin:8px 0;max-width:820px" <?php echo ( (int) $t->term_id === $open ) ? 'open' : ''; ?>>
				<summary style="cursor:pointer"><strong><?php echo esc_html( $t->name ); ?></strong> <span style="color:#666">— <?php echo esc_html( $info ); ?></span></summary>
				<form method="post" action="<?php echo esc_url( $url ); ?>" novalidate>
					<input type="hidden" name="action" value="dc_save_group">
					<input type="hidden" name="dc_nonce" value="<?php echo esc_attr( $nonce ); ?>">
					<input type="hidden" name="term_id" value="<?php echo (int) $t->term_id; ?>">
					<?php rzd_dc_render_group_fields( 'dc_g', $g ); ?>
					<button type="submit" class="button button-primary">Zapisz tę grupę</button>
				</form>
				<?php if ( $conf ) : ?>
					<form method="post" action="<?php echo esc_url( $url ); ?>" style="margin-top:8px" onsubmit="return confirm('Usunąć kalendarz tej grupy?');">
						<input type="hidden" name="action" value="dc_delete_group">
						<input type="hidden" name="dc_nonce" value="<?php echo esc_attr( $nonce ); ?>">
						<input type="hidden" name="term_id" value="<?php echo (int) $t->term_id; ?>">
						<button type="submit" class="button-link-delete">Usuń kalendarz tej grupy</button>
					</form>
				<?php endif; ?>
			</details>
			<?php
		}
		?>
	</div>
	<?php
}

