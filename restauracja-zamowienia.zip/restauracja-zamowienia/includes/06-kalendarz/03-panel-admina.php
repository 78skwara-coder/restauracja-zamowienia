<?php
/**
 * Moduł 06-kalendarz – zapis ustawień Terminów. Od 2.45.0 ustawia się je wyłącznie w Panelu
 * restauracji (moduł 34, sekcja Terminy); dawna strona kokpitu „Restauracja → Terminy”
 * (adres delivery-calendar) przekierowuje do panelu.
 * Każda funkcja zapisu czyta surową opcję dc_settings, zmienia swój kawałek, czyści pamięć
 * podręczną terminów (rzd_dc_clear_slots_cache) i odświeża rzd_dc_get_settings().
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function rzd_dc_raw_settings() {
	$s = get_option( 'dc_settings', array() );
	return is_array( $s ) ? $s : array();
}

/**
 * Ustawienia ogólne: włączenie, dni bez dostaw dla wszystkich grup, limit zamówień na okno.
 * Panel restauracji (moduł 34). $blocked – tablica dat RRRR-MM-DD.
 */
function rzd_dc_save_general( $enabled, $blocked, $max_per_slot ) {
	$s                   = rzd_dc_raw_settings();
	$s['enabled']        = $enabled ? 1 : 0;
	$s['global_blocked'] = rzd_dc_parse_dates( implode( ' ', (array) $blocked ) );
	$s['max_per_slot']   = max( 1, absint( $max_per_slot ) );
	rzd_dc_put_settings( $s );
}

/** Dni bez dostaw jednej grupy (kategorii z kalendarzem). Zwraca false, gdy grupa nie ma kalendarza. */
function rzd_dc_save_group_blocked( $term_id, $blocked ) {
	$s = rzd_dc_raw_settings();
	if ( empty( $s['groups'][ (int) $term_id ] ) || ! is_array( $s['groups'][ (int) $term_id ] ) ) {
		return false;
	}
	$s['groups'][ (int) $term_id ]['blocked'] = rzd_dc_parse_dates( implode( ' ', (array) $blocked ) );
	rzd_dc_put_settings( $s );
	return true;
}

/** Zapis opcji + odświeżenie pamięci (wspólne dla funkcji niżej). */
function rzd_dc_put_settings( $s ) {
	update_option( 'dc_settings', $s, true );
	rzd_dc_get_settings( true );
	rzd_dc_clear_slots_cache();
}

/**
 * Kalendarz jednej grupy (kategorii). $in – pola jak w rzd_dc_sanitize_group(); times i blocked
 * mogą być tablicą albo tekstem. Matryca godzin grupy (window) zostaje bez zmian.
 * Zwraca zapisaną grupę albo WP_Error.
 */
function rzd_dc_save_group( $term_id, $in ) {
	$term_id = absint( $term_id );
	if ( ! $term_id || ! term_exists( $term_id, 'product_cat' ) ) {
		return new WP_Error( 'term', 'Nie ma takiej kategorii.' );
	}
	$in = is_array( $in ) ? $in : array();
	foreach ( array( 'times', 'blocked' ) as $k ) {
		if ( isset( $in[ $k ] ) && is_array( $in[ $k ] ) ) {
			$in[ $k ] = implode( ' ', array_map( 'strval', $in[ $k ] ) );
		}
	}
	$s      = rzd_dc_raw_settings();
	$groups = ( isset( $s['groups'] ) && is_array( $s['groups'] ) ) ? $s['groups'] : array();
	$g      = rzd_dc_sanitize_group( $in );
	$g['window'] = ( isset( $groups[ $term_id ]['window'] ) && is_array( $groups[ $term_id ]['window'] ) ) ? $groups[ $term_id ]['window'] : array();
	$groups[ $term_id ] = $g;
	$s['groups']        = $groups;
	rzd_dc_put_settings( $s );
	return $g;
}

/** Usunięcie kalendarza grupy (produkty tej kategorii przestają być zamawialne, jeśli nie mają innej grupy). */
function rzd_dc_delete_group( $term_id ) {
	$term_id = absint( $term_id );
	$s       = rzd_dc_raw_settings();
	if ( ! $term_id || ! isset( $s['groups'][ $term_id ] ) ) {
		return false;
	}
	unset( $s['groups'][ $term_id ] );
	rzd_dc_put_settings( $s );
	return true;
}

/**
 * Matryca „Godziny dostaw w dniach tygodnia”: $global – wiersz wszystkich grup, $rows – [ term_id => okno ],
 * $off_days – dni tygodnia bez dostaw (wszystkie grupy). Grupy bez kalendarza są pomijane.
 */
function rzd_dc_save_matrix( $global, $rows, $off_days ) {
	$s                  = rzd_dc_raw_settings();
	$s['global_window'] = rzd_dc_sanitize_window( $global );
	$s['off_days']      = array_values( array_intersect( (array) $off_days, array_keys( rzd_dc_days() ) ) );
	if ( isset( $s['groups'] ) && is_array( $s['groups'] ) ) {
		foreach ( $s['groups'] as $term_id => $g ) {
			$s['groups'][ $term_id ]['window'] = rzd_dc_sanitize_window( isset( $rows[ $term_id ] ) ? $rows[ $term_id ] : array() );
		}
	}
	rzd_dc_put_settings( $s );
}

/**
 * Okna dostaw: $on – tryb okien, $defs – [ {id, name, len, cap} ] (nowe bez id albo z id spoza
 * katalogu dostają nowe id 'wN'), $days – [ dow => {on, start, seq[]} ]; seq może wskazywać
 * tymczasowe id nowych okien (mapowane). Zwraca katalog po zapisie.
 */
function rzd_dc_save_windows( $on, $defs_in, $days_in ) {
	$s    = rzd_dc_raw_settings();
	$next = isset( $s['win_next'] ) ? max( 1, (int) $s['win_next'] ) : 1;
	$old  = ( isset( $s['win_defs'] ) && is_array( $s['win_defs'] ) ) ? $s['win_defs'] : array();
	$defs = array();
	$map  = array();
	foreach ( (array) $defs_in as $row ) {
		$row  = is_array( $row ) ? $row : array();
		$name = sanitize_text_field( isset( $row['name'] ) ? $row['name'] : '' );
		$len  = isset( $row['len'] ) ? absint( $row['len'] ) : 0;
		$cap  = isset( $row['cap'] ) ? absint( $row['cap'] ) : 0;
		if ( '' === $name && ! $len && ! $cap ) {
			continue;
		}
		$given = isset( $row['id'] ) ? sanitize_key( $row['id'] ) : '';
		$id    = $given;
		if ( '' === $id || ! isset( $old[ $id ] ) || isset( $defs[ $id ] ) ) {
			do {
				$id = 'w' . $next++;
			} while ( isset( $old[ $id ] ) || isset( $defs[ $id ] ) );
			if ( '' !== $given ) {
				$map[ $given ] = $id;
			}
		}
		$defs[ $id ] = array(
			'name' => '' !== $name ? $name : 'Okno ' . $id,
			'len'  => max( 5, min( 600, $len ? $len : 60 ) ),
			'cap'  => max( 1, min( 99, $cap ? $cap : 6 ) ),
		);
	}
	$days = array();
	foreach ( array_keys( rzd_dc_days() ) as $dow ) {
		$d   = ( isset( $days_in[ $dow ] ) && is_array( $days_in[ $dow ] ) ) ? $days_in[ $dow ] : array();
		$seq = array();
		foreach ( (array) ( isset( $d['seq'] ) ? $d['seq'] : array() ) as $id ) {
			$id = sanitize_key( $id );
			if ( isset( $map[ $id ] ) ) {
				$id = $map[ $id ];
			}
			if ( '' !== $id && isset( $defs[ $id ] ) ) {
				$seq[] = $id; // to samo okno może wystąpić w dniu kilka razy
			}
		}
		$days[ $dow ] = array(
			'on'    => empty( $d['on'] ) ? 0 : 1,
			'start' => rzd_clean_time( isset( $d['start'] ) ? $d['start'] : '' ),
			'seq'   => $seq,
		);
	}
	$s['win_on']   = $on ? 1 : 0;
	$s['win_defs'] = $defs;
	$s['win_days'] = $days;
	$s['win_next'] = $next;
	rzd_dc_put_settings( $s );
	return $defs;
}

// Produkty, których nie da się zamówić, bo nie należą do żadnej skonfigurowanej grupy
function rzd_dc_products_without_group() {
	$ids = get_posts( array(
		'post_type'      => 'product',
		'post_status'    => 'publish',
		'posts_per_page' => 300,
		'fields'         => 'ids',
		'no_found_rows'  => true,
	) );
	$out = array();
	foreach ( $ids as $id ) {
		// dania tylko do zestawów (kategoria „Nie wyświetlaj w sklepie”) nie są zamawiane osobno;
		// pozostałe dania zestawów sprzedają się osobno w inne dni – potrzebują grupy
		if ( 'yes' === get_post_meta( $id, '_rwz_hidden_as_component_main', true ) && function_exists( 'rzd_zestaw_product_in_hidden_category' ) && rzd_zestaw_product_in_hidden_category( $id ) ) {
			continue;
		}
		if ( ! rzd_dc_group_ids_for_product( $id ) ) {
			$out[] = $id;
		}
	}
	return $out;
}
