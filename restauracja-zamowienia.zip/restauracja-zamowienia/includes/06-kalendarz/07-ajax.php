<?php
/**
 * Moduł 06-kalendarz – AJAX: lista terminów, zapis wyboru, zgodność z koszykiem, shortcode przycisku.
 * Część modułu (pliki wczytywane po kolei – kolejność jak w dawnym jednym pliku).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 5. AJAX (wc-ajax): lista terminów i zapis wyboru
 * ============================================================ */
add_action( 'wc_ajax_dc_slots', 'rzd_dc_ajax_slots' );
function rzd_dc_ajax_slots() {
	$pid = isset( $_GET['product_id'] ) ? absint( $_GET['product_id'] ) : 0;
	$ids = rzd_dc_cart_product_ids();
	if ( $pid ) {
		$ids[] = $pid;
	}

	if ( $ids ) {
		$slots = rzd_dc_slots_for_products( $ids );
		$mode  = $pid ? 'product' : 'cart';
		$none  = 'Ten produkt nie jest teraz dostępny w żadnym terminie zgodnym z produktami w Twoim koszyku.';
		if ( ! $pid ) {
			$none = 'Nie ma terminu, który pasuje do wszystkich produktów w koszyku. Usuń któryś produkt i spróbuj ponownie.';
		}
	} else {
		// pusty koszyk i brak produktu: klient wybiera datę z góry – pokazujemy terminy wszystkich grup
		$slots = rzd_dc_slots_all_groups();
		$mode  = 'all';
		$none  = 'Żaden termin dostawy nie jest teraz dostępny.';
	}

	// Miejscowość (moduł 20): terminy tylko te, w które jedziemy do niej.
	$town = '';
	if ( function_exists( 'rzd_towns_enabled' ) && rzd_towns_enabled() ) {
		$typed = isset( $_GET['town'] ) ? sanitize_text_field( wp_unslash( $_GET['town'] ) ) : rzd_session_town();
		if ( '' === trim( $typed ) ) {
			wp_send_json( array( 'ok' => true, 'mode' => $mode, 'dates' => array(), 'need_town' => true, 'message' => 'Wybierz miejscowość dostawy z listy – pokażemy terminy, w które do niej dowozimy.' ) );
		}
		$row = rzd_town_find( $typed );
		if ( ! $row ) {
			wp_send_json( array( 'ok' => true, 'mode' => $mode, 'dates' => array(), 'need_town' => true, 'message' => 'Sprawdź nazwę miejscowości – nie ma jej na liście miejscowości, do których dowozimy. Poprawna nazwa gwarantuje bezproblemową dostawę.' ) );
		}
		$town  = $row['name'];
		$slots = rzd_town_filter_slots( $slots, $row );
		if ( ! $slots ) {
			$none = 'Do miejscowości ' . $town . ' dowozimy: ' . rzd_town_schedule_label( $row ) . '. ' . ( 'all' === $mode ? 'W najbliższych dniach nie ma takiego terminu.' : 'Nie ma takiego terminu dla produktów z koszyka.' );
		}
	}

	// Tryb okien: tylko okna, w których zmieszczą się punkty tej miejscowości.
	if ( $slots && rzd_dc_windows_on() ) {
		$slots = rzd_dc_filter_slots_by_room( $slots, rzd_dc_customer_points( $town ) );
		if ( ! $slots ) {
			$none = 'Wszystkie najbliższe terminy dostaw' . ( $town ? ' do miejscowości ' . $town : '' ) . ' są już zajęte.';
		}
	}

	$dates = array();
	foreach ( $slots as $d => $times ) {
		$labels = array();
		foreach ( $times as $t ) {
			$labels[ $t ] = rzd_dc_time_window_label( $t, $d );
		}
		$dates[] = array( 'date' => $d, 'label' => rzd_dc_date_label( $d ), 'times' => $times, 'labels' => $labels );
	}
	wp_send_json( array(
		'ok'      => true,
		'mode'    => $mode,
		'town'    => $town,
		'dates'   => $dates,
		'message' => $dates ? '' : $none,
	) );
}

add_action( 'wc_ajax_dc_set_slot', 'rzd_dc_ajax_set_slot' );
function rzd_dc_ajax_set_slot() {
	if ( ! rzd_request_same_origin() || ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'rzd_dc_slot' ) ) {
		wp_send_json( array( 'ok' => false, 'message' => 'Sesja wygasła – odśwież stronę i wybierz termin jeszcze raz.' ) );
	}
	// Wybór terminu jest tylko preferencją sesji i jest w pełni walidowany po stronie serwera.
	$date = isset( $_POST['date'] ) ? sanitize_text_field( wp_unslash( $_POST['date'] ) ) : '';
	$time = isset( $_POST['time'] ) ? rzd_clean_time( wp_unslash( $_POST['time'] ) ) : '';
	$pid  = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;

	if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) || ! $time ) {
		wp_send_json( array( 'ok' => false, 'message' => 'Nieprawidłowy termin.' ) );
	}
	$slot = array( 'date' => $date, 'time' => $time );

	// Miejscowość (moduł 20): musi być na liście i pasować do terminu.
	$town = '';
	if ( function_exists( 'rzd_towns_enabled' ) && rzd_towns_enabled() ) {
		$row = rzd_town_find( isset( $_POST['town'] ) ? sanitize_text_field( wp_unslash( $_POST['town'] ) ) : '' );
		if ( ! $row ) {
			wp_send_json( array( 'ok' => false, 'message' => 'Sprawdź nazwę miejscowości – nie ma jej na liście miejscowości, do których dowozimy.' ) );
		}
		if ( ! rzd_town_allows_slot( $row, $date, $time ) ) {
			wp_send_json( array( 'ok' => false, 'message' => 'Do miejscowości ' . $row['name'] . ' dowozimy: ' . rzd_town_schedule_label( $row ) . '.' ) );
		}
		$town = $row['name'];
	}

	$ids = rzd_dc_cart_product_ids();
	if ( $pid ) {
		$ids[] = $pid;
	}
	foreach ( array_unique( $ids ) as $id ) {
		$msg = rzd_dc_check_product_for_slot( $id, $slot );
		if ( $msg ) {
			wp_send_json( array( 'ok' => false, 'message' => $msg ) );
		}
	}
	if ( ! $ids ) {
		$all = rzd_dc_slots_all_groups();
		if ( empty( $all[ $date ] ) || ! in_array( $time, $all[ $date ], true ) ) {
			wp_send_json( array( 'ok' => false, 'message' => 'Ten termin dostawy nie jest dostępny.' ) );
		}
	}
	if ( ! rzd_dc_slot_has_room( $date, $time, rzd_dc_customer_points( $town ) ) ) {
		wp_send_json( array( 'ok' => false, 'message' => 'Ten termin dostawy jest już zajęty. Wybierz inny.' ) );
	}

	if ( WC()->session ) {
		WC()->session->set_customer_session_cookie( true );
		WC()->session->set( 'dc_slot', $slot );
		if ( $town ) {
			WC()->session->set( 'rzd_town', $town );
			// Miejscowość sama wpisze się w kasie.
			if ( WC()->customer ) {
				WC()->customer->set_billing_city( $town );
				WC()->customer->set_shipping_city( $town );
				WC()->customer->save();
			}
		}
	}

	// Zestawy w koszyku "zamrażają" listę dań – odśwież ją pod nową datę
	if ( WC()->cart && function_exists( 'rzd_zestaw_get_active_components' ) ) {
		foreach ( WC()->cart->cart_contents as $key => $item ) {
			if ( isset( $item['rwz_components'] ) ) {
				$active = rzd_zestaw_get_active_components( $item['product_id'], $date );
				WC()->cart->cart_contents[ $key ]['rwz_components'] = array_map( function ( $p ) {
					return $p->get_name();
				}, $active['main'] );
				if ( function_exists( 'rzd_zestaw_component_ids' ) ) { // ID dań – kontrola koszyka (moduł 04)
					WC()->cart->cart_contents[ $key ]['rwz_component_ids'] = rzd_zestaw_component_ids( $active['main'] );
				}
			}
		}
		WC()->cart->set_session();
	}

	wp_send_json( array( 'ok' => true, 'slot' => $slot, 'town' => $town, 'label' => rzd_dc_slot_label_town( $slot ) ) );
}

/* ---------- Terminy wspólne dla wszystkich grup (wybór daty przed produktami) ---------- */
function rzd_dc_slots_all_groups() {
	$s   = rzd_dc_get_settings();
	$out = array();
	$day = rzd_dc_now();
	$max = rzd_dc_max_horizon();
	for ( $i = 0; $i <= $max; $i++ ) {
		$date  = $day->format( 'Y-m-d' );
		$times = array();
		foreach ( $s['groups'] as $g ) {
			$times = array_merge( $times, rzd_dc_calendar_times_for_date( $g, $date ) );
		}
		$times = array_values( array_unique( $times ) );
		sort( $times );
		if ( $times ) {
			$out[ $date ] = $times;
		}
		$day->modify( '+1 day' );
	}
	return $out;
}

/* ---------- Brak wspólnego terminu z koszykiem ----------
 * Zmiana daty pomaga tylko wtedy, gdy koszyk + produkt mają jakikolwiek
 * wspólny termin. Gdy nie mają (np. śniadanie i obiad), klient dostaje inne
 * okienko – bez „Zmień datę dostawy”, z informacją o osobnym zamówieniu.
 */
function rzd_dc_fits_with_cart( $product_id ) {
	static $memo = array();
	$product_id = (int) $product_id;
	if ( isset( $memo[ $product_id ] ) ) {
		return $memo[ $product_id ];
	}
	$ids = rzd_dc_cart_product_ids();
	if ( ! $ids || in_array( $product_id, $ids, true ) ) {
		return $memo[ $product_id ] = true;
	}
	$ids[] = $product_id;
	return $memo[ $product_id ] = (bool) rzd_dc_slots_for_products( $ids );
}

// Nazwy grup (kategorii z kalendarzem) dla listy produktów, bez powtórzeń.
function rzd_dc_group_names_for_products( $product_ids ) {
	$names = array();
	foreach ( (array) $product_ids as $pid ) {
		foreach ( rzd_dc_group_ids_for_product( $pid ) as $gid ) {
			$term = get_term( (int) $gid, 'product_cat' );
			if ( $term && ! is_wp_error( $term ) ) {
				$names[ $term->term_id ] = $term->name;
			}
		}
	}
	return array_values( $names );
}

/* ---------- Kontrola zgodności produktu z terminem w koszyku (okno "nie można dodać") ---------- */
add_action( 'wc_ajax_dc_check', 'rzd_dc_ajax_check' );
function rzd_dc_ajax_check() {
	$pid  = isset( $_GET['product_id'] ) ? absint( $_GET['product_id'] ) : 0;
	$slot = rzd_dc_current_slot();
	if ( ! $pid || ! $slot || ! rzd_dc_check_product_for_slot( $pid, $slot ) ) {
		wp_send_json( array( 'ok' => true ) );
	}

	$times = rzd_dc_times_for_product_date( $pid, $slot['date'] );
	$alt   = '';
	if ( $times ) {
		$alt = implode( ', ', $times ); // ten sam dzień, inne godziny
	} else {
		$first = rzd_dc_slots_for_products( array( $pid ) );
		if ( $first ) {
			$d   = key( $first );
			$alt = rzd_dc_date_label( $d ) . ', ' . $first[ $d ][0];
		}
	}
	$cart_ids  = rzd_dc_cart_product_ids();
	$no_common = $cart_ids && ! rzd_dc_fits_with_cart( $pid );
	$p_groups  = $no_common ? rzd_dc_group_names_for_products( array( $pid ) ) : array();
	$c_groups  = $no_common ? array_values( array_diff( rzd_dc_group_names_for_products( $cart_ids ), $p_groups ) ) : array();
	wp_send_json( array(
		'ok'             => false,
		'product'        => get_the_title( rzd_dc_product_root_id( $pid ) ),
		'cart_label'     => rzd_dc_slot_label( $slot ),
		'has_cart'       => (bool) $cart_ids,
		'alt'            => $alt,
		'alt_same_day'   => (bool) $times,
		'no_common'      => $no_common,
		'product_groups' => $p_groups,
		'cart_groups'    => $c_groups,
	) );
}

/* ---------- Czerwona uwaga pod nazwą produktu na liście (moduł 02) ---------- */
add_filter( 'rest_lista_uwaga', function ( $msg, $product_id ) {
	if ( ! rzd_dc_enabled() ) {
		return $msg;
	}
	$slot = rzd_dc_current_slot();
	if ( $slot && ! rzd_dc_slot_expired( $slot ) && rzd_dc_check_product_for_slot( $product_id, $slot ) ) {
		if ( ! rzd_dc_fits_with_cart( $product_id ) ) {
			return 'Nie da się zamówić razem z produktami z koszyka – dowozimy je w innych godzinach. Zamów osobno.';
		}
		return 'Zmień datę dostawy, by dodać do koszyka — ta data jest niezgodna z terminem dostawy wybranym w koszyku.';
	}
	return $msg;
}, 10, 2 );

// Ikonka "i (więcej)" obok czerwonej uwagi – pokazuje ten sam komunikat, co
// przy próbie dodania do koszyka, ale na żądanie, zanim klient w ogóle spróbuje.
function rzd_dc_conflict_info_icon_html( $product_id ) {
	if ( ! rzd_dc_enabled() ) {
		return '';
	}
	$slot = rzd_dc_current_slot();
	if ( ! $slot || rzd_dc_slot_expired( $slot ) || ! rzd_dc_check_product_for_slot( $product_id, $slot ) ) {
		return '';
	}
	return '<button type="button" class="rl2-info-icon" data-product="' . esc_attr( $product_id ) . '" aria-label="Więcej informacji">i</button>'
		. '<button type="button" class="rl2-info-icon-label" data-product="' . esc_attr( $product_id ) . '">(więcej)</button>';
}

/* ---------- Shortcode: przycisk "Wybierz datę dostawy" ---------- */
// Użycie: [wybierz_date_dostawy]  albo  [wybierz_date_dostawy tekst="Ustaw dostawę"]
add_shortcode( 'wybierz_date_dostawy', function ( $atts ) {
	if ( ! rzd_dc_enabled() ) {
		return '';
	}
	$a    = shortcode_atts( array( 'tekst' => 'Wybierz datę dostawy' ), $atts );
	$slot = rzd_dc_current_slot();
	$out  = '<button type="button" class="dc-open-picker">' . esc_html( $a['tekst'] ) . '</button>';
	if ( $slot ) {
		$out .= ' <span class="dc-picker-label">' . esc_html( rzd_dc_slot_label( $slot ) ) . '</span>';
	}
	return $out;
} );

