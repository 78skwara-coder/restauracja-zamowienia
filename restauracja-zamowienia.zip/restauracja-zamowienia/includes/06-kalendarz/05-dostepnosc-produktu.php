<?php
/**
 * Moduł 06-kalendarz – dostępność produktu w dniu dostawy.
 * Część modułu (pliki wczytywane po kolei – kolejność jak w dawnym jednym pliku).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* --- dostępność produktu w dniu dostawy --- */
function rzd_dc_set_ids() {
	static $ids = null;
	if ( null === $ids ) {
		global $wpdb;
		$ids = array_map( 'intval', $wpdb->get_col( "SELECT DISTINCT post_id FROM {$wpdb->postmeta} WHERE meta_key IN ('_rwz_slots', '_rwz_components')" ) );
	}
	return $ids;
}

// Czy produkt jest wystawiony (jako danie lub dodatek) w którymś zestawie w tym dniu
function rzd_dc_component_available_on( $product_id, $date ) {
	foreach ( rzd_dc_set_ids() as $set_id ) {
		$active = rzd_zestaw_get_active_components( $set_id, $date );
		foreach ( array_merge( $active['main'], $active['addon'] ) as $p ) {
			if ( (int) $p->get_id() === (int) $product_id ) {
				return true;
			}
		}
	}
	return false;
}

function rzd_dc_product_available_on( $product_id, $date ) {
	static $cache = array();
	$key = $product_id . '|' . $date;
	if ( isset( $cache[ $key ] ) ) {
		return $cache[ $key ];
	}

	$ok = true;
	if ( function_exists( 'rzd_zestaw_get_slots' ) ) {
		if ( rzd_zestaw_get_slots( $product_id ) ) {
			// zestaw: musi mieć w tym dniu choć jedno PRAWDZIWE danie (tylko zakres dzienny).
			// sam zestaw pośredni bez dania (np. „Zupa dnia” bez zupy) ani same
			// dodatki już nie wystarczą – decyzja użytkownika „usuń i blokuj”.
			$ok = function_exists( 'rzd_zestaw_set_has_dish' ) ? rzd_zestaw_set_has_dish( $product_id, $date ) : true;
		} elseif ( 'yes' === get_post_meta( $product_id, '_rwz_hidden_as_component_main', true ) ) {
			// danie główne zestawu – osobno w każdy dzień POZA dniami, gdy jest w zestawie
			// (wtedy tylko w zestawie); danie z kategorii „Nie wyświetlaj w sklepie” – nigdy osobno.
			$hidden = function_exists( 'rzd_zestaw_product_in_hidden_category' ) && rzd_zestaw_product_in_hidden_category( $product_id );
			$ok     = ! $hidden && ( ! function_exists( 'rzd_zestaw_set_main_on_date' ) || '' === rzd_zestaw_set_main_on_date( $product_id, $date ) );
		} elseif ( 'yes' === get_post_meta( $product_id, '_rwz_hidden_as_component', true ) ) {
			// składowa zestawu (np. dodatek): tylko w dni, gdy któryś zestaw ją wystawia
			$ok = rzd_dc_component_available_on( $product_id, $date );
		}
	}

	/**
	 * Tu podpinasz własną datę ważności zwykłych produktów:
	 * add_filter( 'dc_product_available_on', function ( $ok, $product_id, $date ) { ... }, 10, 3 );
	 */
	$ok = (bool) apply_filters( 'dc_product_available_on', $ok, (int) $product_id, $date );

	$cache[ $key ] = $ok;
	return $ok;
}

// Godziny, o których da się dostarczyć produkt w danym dniu
function rzd_dc_times_for_product_date( $product_id, $date ) {
	if ( ! rzd_dc_product_available_on( $product_id, $date ) ) {
		return array();
	}
	$times = null;
	foreach ( rzd_dc_calendars_for_product( $product_id ) as $cal ) {
		$t     = rzd_dc_calendar_times_for_date( $cal, $date );
		$times = ( null === $times ) ? $t : array_values( array_intersect( $times, $t ) );
	}
	return $times ? $times : array();
}

// Terminy wspólne dla wszystkich podanych produktów: [ 'Y-m-d' => [ 'HH:MM', ... ] ]
function rzd_dc_slots_for_products( $product_ids ) {
	$product_ids = array_values( array_unique( array_map( 'intval', (array) $product_ids ) ) );
	if ( ! $product_ids ) {
		return array();
	}
	// terminy kilku produktów = część wspólna terminów każdego z nich
	// (dzień po dniu, godziny wspólne) – dokładnie to samo, co wcześniej liczono
	// w jednej pętli. Dzięki temu bufor trzyma wyniki POJEDYNCZYCH produktów
	// (wspólne dla wszystkich klientów), a nie każdą kombinację koszyka osobno.
	$out = null;
	foreach ( $product_ids as $pid ) {
		$one = rzd_dc_slots_for_product( $pid );
		if ( null === $out ) {
			$out = $one;
		} else {
			$next = array();
			foreach ( $out as $date => $times ) {
				if ( isset( $one[ $date ] ) ) {
					$common = array_values( array_intersect( $times, $one[ $date ] ) );
					if ( $common ) {
						$next[ $date ] = $common;
					}
				}
			}
			$out = $next;
		}
		if ( ! $out ) {
			return array();
		}
	}
	return $out;
}

/**
 * Terminy jednego produktu: [ 'Y-m-d' => [ 'HH:MM', … ] ].
 * WYDAJNOŚĆ: pamięć na czas żądania + JEDEN wspólny bufor
 * (transient „dc_slots_bundle”, 2 min) dla wszystkich produktów – wcześniej
 * osobny transient na produkt/kombinację = 2 zapytania SQL na każdy produkt
 * listy, gdy klient miał coś w koszyku.
 */
function rzd_dc_slots_for_product( $pid ) {
	static $memo = array();
	$pid = (int) $pid;
	if ( isset( $memo[ $pid ] ) ) {
		return $memo[ $pid ];
	}
	$bundle =& dc_slots_bundle();
	$now    = time();
	if ( isset( $bundle['items'][ $pid ] ) && $bundle['items'][ $pid ][0] > $now ) {
		return $memo[ $pid ] = $bundle['items'][ $pid ][1];
	}
	$out = array();
	$day = rzd_dc_now();
	$max = rzd_dc_max_horizon();
	for ( $i = 0; $i <= $max; $i++ ) {
		$date = $day->format( 'Y-m-d' );
		$t    = rzd_dc_times_for_product_date( $pid, $date );
		if ( $t ) {
			$out[ $date ] = array_values( $t );
		}
		$day->modify( '+1 day' );
	}
	$bundle['items'][ $pid ] = array( $now + 2 * MINUTE_IN_SECONDS, $out );
	$bundle['dirty']         = true;
	return $memo[ $pid ] = $out;
}

// Wspólny bufor terminów produktów – wczytany raz, zapisany raz (na koniec żądania).
function &dc_slots_bundle() {
	static $bundle = null;
	if ( null === $bundle ) {
		$items  = get_transient( 'dc_slots_bundle' );
		$bundle = array( 'items' => is_array( $items ) ? $items : array(), 'dirty' => false );
		add_action( 'shutdown', 'rzd_dc_slots_bundle_save' );
	}
	return $bundle;
}

function rzd_dc_slots_bundle_save() {
	$bundle =& dc_slots_bundle();
	if ( empty( $bundle['dirty'] ) ) {
		return;
	}
	$now   = time();
	$items = array_filter( $bundle['items'], function ( $e ) use ( $now ) { return is_array( $e ) && $e[0] > $now; } );
	set_transient( 'dc_slots_bundle', $items, 5 * MINUTE_IN_SECONDS );
	$bundle['dirty'] = false;
}

/**
 * Wywołaj po zapisaniu kalendarza albo zestawu, żeby zmiana była widoczna
 * od razu, zamiast czekać do 2 minut na wygaśnięcie bufora.
 */
function rzd_dc_clear_slots_cache() {
	global $wpdb;
	// wspólny bufor (działa też przy Redis/Memcached, gdzie transienty nie leżą w tabeli opcji).
	delete_transient( 'dc_slots_bundle' );
	rzd_dc_orders_maps_flush();
	$bundle          =& dc_slots_bundle();
	$bundle['items'] = array();
	$bundle['dirty'] = false;
	$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_dc_slots_%' OR option_name LIKE '_transient_timeout_dc_slots_%'" );
}

// '' = produkt da się dostarczyć w terminie; w przeciwnym razie komunikat dla klienta
function rzd_dc_check_product_for_slot( $product_id, $slot ) {
	// na liście sprawdzane 2× na produkt (uwaga + ikonka „i”) – raz wystarczy.
	static $memo = array();
	$mkey = (int) $product_id . '|' . ( isset( $slot['date'] ) ? $slot['date'] : '' ) . '|' . ( isset( $slot['time'] ) ? $slot['time'] : '' );
	if ( ! isset( $memo[ $mkey ] ) ) {
		$memo[ $mkey ] = rzd_dc_check_product_for_slot_calc( $product_id, $slot );
	}
	return $memo[ $mkey ];
}

function rzd_dc_check_product_for_slot_calc( $product_id, $slot ) {
	$name  = get_the_title( rzd_dc_product_root_id( $product_id ) );
	$label = rzd_dc_slot_label( $slot );

	if ( ! rzd_dc_calendars_for_product( $product_id ) ) {
		return sprintf( 'Produkt „%s” nie należy do żadnej grupy z kalendarzem dostaw, więc nie można go teraz zamówić.', $name );
	}
	$in_set = function_exists( 'rzd_zestaw_set_main_on_date' ) ? rzd_zestaw_set_main_on_date( rzd_dc_product_root_id( $product_id ), $slot['date'] ) : '';
	if ( '' !== $in_set ) {
		return sprintf( 'W dniu dostawy (%1$s) „%2$s” jest w zestawie „%3$s” – zamów zestaw albo wybierz inny dzień.', rzd_dc_date_label( $slot['date'] ), $name, $in_set );
	}
	if ( function_exists( 'rzd_soldout_effective' ) && rzd_soldout_effective( $product_id, $slot['date'] ) ) { // wyprzedane na dzień (moduł 22)
		return sprintf( 'Produkt „%1$s” jest wyprzedany na %2$s.', $name, rzd_dc_date_label( $slot['date'] ) );
	}
	if ( ! rzd_dc_product_available_on( $product_id, $slot['date'] ) ) {
		return sprintf( 'Produkt „%1$s” nie jest dostępny w dniu dostawy (%2$s).', $name, rzd_dc_date_label( $slot['date'] ) );
	}
	if ( ! in_array( $slot['time'], rzd_dc_times_for_product_date( $product_id, $slot['date'] ), true ) ) {
		return sprintf( 'Produkt „%1$s” nie może być dostarczony w wybranym terminie (%2$s).', $name, $label );
	}
	return '';
}

