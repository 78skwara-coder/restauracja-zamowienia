<?php
/**
 * Moduł 06-kalendarz – okna dostaw, punkty i pojemność, siatka slotów do Planowania.
 * Część modułu (pliki wczytywane po kolei – kolejność jak w dawnym jednym pliku).
 */

/* ============================================================
 * 0b. OKNA DOSTAW
 *
 * Okno = nazwa + długość (min) + pojemność (punkty). Okna są wspólne dla
 * wszystkich grup (jeden kurier, jeden kurs). Każdy dzień tygodnia ma
 * znacznik „dostawa”, godzinę startu i kolejność okien – jedno po drugim,
 * bez przerw. Godzina wyjazdu terminu = start okna, więc zamówienia,
 * Kuchnia, Kurier i maile działają na tych samych danych co wcześniej.
 *
 * Tryb włącza się świadomie (dc_settings['win_on']). Wyłączony albo pusty
 * katalog = wszystko po staremu na godzinach wyjazdu grup ('times').
 *
 * Grupa obsługuje okna w swoim zakresie „od–do” z matrycy: początek
 * zaokrąglany W GÓRĘ do startu okna (okno zaczęte przed grupą odpada),
 * koniec W DÓŁ do końca okna (okno kończące się po grupie odpada).
 *
 * Pojemność: suma punktów zamówień terminu (punkty miejscowości, moduł 20)
 * + punkty klienta ≤ pojemność okna.
 * ============================================================ */
function dc_windows_on() {
	$s = dc_get_settings();
	return ! empty( $s['win_on'] ) && ! empty( $s['win_defs'] ) && is_array( $s['win_defs'] );
}

function dc_win_defs() {
	$s = dc_get_settings();
	return ( isset( $s['win_defs'] ) && is_array( $s['win_defs'] ) ) ? $s['win_defs'] : array();
}

// Ustawienie dnia tygodnia: [ 'on' => 0/1, 'start' => 'HH:MM', 'seq' => [ id, … ] ]
function dc_win_day( $dow ) {
	$s   = dc_get_settings();
	$day = ( isset( $s['win_days'][ $dow ] ) && is_array( $s['win_days'][ $dow ] ) ) ? $s['win_days'][ $dow ] : array();
	return wp_parse_args( $day, array( 'on' => 0, 'start' => '', 'seq' => array() ) );
}

function dc_hm_to_min( $t ) {
	return preg_match( '/^(\d{2}):(\d{2})$/', (string) $t, $m ) ? ( (int) $m[1] * 60 + (int) $m[2] ) : -1;
}

function dc_min_to_hm( $m ) {
	$m = max( 0, (int) $m );
	return sprintf( '%02d:%02d', floor( $m / 60 ), $m % 60 );
}

/**
 * Oś jednego dnia tygodnia: lista okien [ id, name, start, end, len, cap ].
 * Okno, które skończyłoby się po północy, i wszystkie po nim – pomijane
 * (panel ostrzega). Wynik nie zależy od daty, tylko od dnia tygodnia.
 */
function dc_windows_for_dow( $dow ) {
	static $memo = array();
	if ( isset( $memo[ $dow ] ) ) {
		return $memo[ $dow ];
	}
	$out  = array();
	$day  = dc_win_day( $dow );
	$defs = dc_win_defs();
	$cur  = dc_hm_to_min( $day['start'] );
	if ( ! empty( $day['on'] ) && $cur >= 0 ) {
		foreach ( (array) $day['seq'] as $id ) {
			if ( ! isset( $defs[ $id ] ) ) {
				continue;
			}
			$len = max( 5, (int) $defs[ $id ]['len'] );
			if ( $cur + $len > 1440 ) {
				break;
			}
			$out[] = array(
				'id'    => $id,
				'name'  => $defs[ $id ]['name'],
				'start' => dc_min_to_hm( $cur ),
				'end'   => dc_min_to_hm( $cur + $len ),
				'len'   => $len,
				'cap'   => max( 1, (int) $defs[ $id ]['cap'] ),
			);
			$cur += $len;
		}
	}
	$memo[ $dow ] = $out;
	return $out;
}

function dc_windows_for_date( $date ) {
	if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $date ) ) {
		return array();
	}
	return dc_windows_for_dow( ( new DateTime( $date, wp_timezone() ) )->format( 'D' ) );
}

// Okno zaczynające się o $time w dniu $date – albo null.
function dc_window_at( $date, $time ) {
	foreach ( dc_windows_for_date( $date ) as $w ) {
		if ( $w['start'] === $time ) {
			return $w;
		}
	}
	return null;
}

/**
 * Godziny wyjazdu grupy w danym dniu – BEZ cutoffów, horyzontu i pojemności.
 * Tryb okien: starty okien w zakresie grupy z matrycy (zaokrąglanie jak
 * w opisie wyżej). Tryb stary: 'times' grupy przycięte matrycą.
 */
function dc_group_times( $cal, $date ) {
	list( $w_from, $w_to ) = dc_window_for_date( $cal, $date );
	if ( dc_windows_on() ) {
		$times = array();
		foreach ( dc_windows_for_date( $date ) as $w ) {
			if ( ( '' === $w_from || $w['start'] >= $w_from ) && ( '' === $w_to || $w['end'] <= $w_to ) ) {
				$times[] = $w['start'];
			}
		}
		return $times;
	}
	$times = array_values( (array) ( isset( $cal['times'] ) ? $cal['times'] : array() ) );
	if ( '' !== $w_from || '' !== $w_to ) {
		$times = array_values( array_filter( $times, function ( $t ) use ( $w_from, $w_to ) {
			return ( '' === $w_from || $t >= $w_from ) && ( '' === $w_to || $t <= $w_to );
		} ) );
	}
	return $times;
}

// Czy grupa w ogóle ma tę godzinę wyjazdu tego dnia (do cutoffów w Kuchni).
function dc_group_has_time( $cal, $date, $time ) {
	if ( dc_windows_on() ) {
		return in_array( $time, dc_group_times( $cal, $date ), true );
	}
	return ! empty( $cal['times'] ) && in_array( $time, (array) $cal['times'], true );
}

/* --- Punkty i pojemność (tryb okien) --- */

// Punkty zapisanego zamówienia: meta _rzd_points, a dla starszych
// zamówień – punkty jego miejscowości z matrycy, a bez niej 1.
function dc_order_points( $order ) {
	$p = $order->get_meta( '_rzd_points' );
	if ( '' !== $p && is_numeric( $p ) ) {
		return max( 0, (int) $p );
	}
	if ( function_exists( 'rzd_town_points' ) ) {
		$town = (string) $order->get_meta( '_rzd_town' );
		if ( '' !== $town ) {
			return rzd_town_points( $town );
		}
	}
	return 1;
}

// Ile punktów zajmie klient: punkty miejscowości (wpisanej albo z sesji), bez miejscowości 1.
function dc_customer_points( $town = null ) {
	if ( function_exists( 'rzd_towns_enabled' ) && rzd_towns_enabled() && function_exists( 'rzd_town_points' ) ) {
		$name = ( null === $town ) ? rzd_session_town() : $town;
		if ( '' !== trim( (string) $name ) ) {
			return rzd_town_points( $name );
		}
	}
	return 1;
}

function dc_slot_capacity( $date, $time ) {
	$w = dc_window_at( $date, $time );
	return $w ? (int) $w['cap'] : 0;
}

// Czy w oknie zmieszczą się jeszcze $need punkty. Stary tryb – zawsze tak
// (tam limit liczy dc_calendar_times_for_date po liczbie zamówień).
function dc_slot_has_room( $date, $time, $need ) {
	if ( ! dc_windows_on() ) {
		return true;
	}
	$w = dc_window_at( $date, $time );
	if ( ! $w ) {
		return false;
	}
	return dc_orders_points_for_slot( $date, $time ) + max( 0, (int) $need ) <= (int) $w['cap'];
}

// Terminy [ 'Y-m-d' => [ 'HH:MM' ] ] bez okien, w których brak miejsca na $need punktów.
function dc_filter_slots_by_room( $slots, $need ) {
	if ( ! dc_windows_on() ) {
		return $slots;
	}
	$out = array();
	foreach ( $slots as $date => $times ) {
		$ok = array_values( array_filter( (array) $times, function ( $t ) use ( $date, $need ) {
			return dc_slot_has_room( $date, $t, $need );
		} ) );
		if ( $ok ) {
			$out[ $date ] = $ok;
		}
	}
	return $out;
}

/* --- Siatka slotów do Planowania ---
 * Okno dzielone na tyle slotów, ile ma punktów: krok = długość / pojemność,
 * godziny zaokrąglane do minuty (60/8 → :00, :08, :15, :23…). Zamówienie za
 * N punktów zajmuje N kolejnych slotów, a jego godzina dostawy = pierwszy
 * slot. Gdy okno jest przeładowane (np. „Nowy termin” z Kuchni), siatka
 * wydłuża się tym samym krokiem za koniec okna, żeby każdy dostał godzinę.
 * Zamówienie za 0 pkt (odbiór) może mieć dowolny slot i niczego nie zajmuje. */
function dc_plan_slot_time( $w, $k ) {
	$step = max( 1, (int) $w['len'] / max( 1, (int) $w['cap'] ) );
	return dc_min_to_hm( dc_hm_to_min( $w['start'] ) + (int) round( $k * $step ) );
}

/**
 * $orders = wszystkie zamówienia terminu. $exclude_id = zamówienie, dla
 * którego liczymy wolne miejsca (jego własny slot nie przeszkadza).
 * Zwraca null poza trybem okien albo dla godziny, która nie jest oknem.
 */
function dc_plan_grid( $date, $time, $orders, $exclude_id = 0 ) {
	if ( ! dc_windows_on() ) {
		return null;
	}
	$w = dc_window_at( $date, $time );
	if ( ! $w ) {
		return null;
	}
	$used = 0;
	foreach ( $orders as $o ) {
		$used += dc_order_points( $o );
	}
	$n     = max( (int) $w['cap'], $used );
	$slots = array();
	for ( $k = 0; $k < $n; $k++ ) {
		$slots[ $k ] = dc_plan_slot_time( $w, $k );
	}
	$occ       = array(); // indeks slotu => id zamówienia
	$conflicts = array(); // opisy nakładań
	$offgrid   = array(); // numery zamówień z godziną spoza siatki
	foreach ( $orders as $o ) {
		if ( (int) $o->get_id() === (int) $exclude_id ) {
			continue;
		}
		$pt = (string) $o->get_meta( '_dc_planned_time' );
		if ( '' === $pt ) {
			continue;
		}
		$idx = array_search( $pt, $slots, true );
		if ( false === $idx ) {
			$offgrid[] = $o->get_order_number();
			continue;
		}
		$p = dc_order_points( $o );
		for ( $j = $idx; $j < $idx + $p; $j++ ) {
			if ( isset( $occ[ $j ] ) && $occ[ $j ] !== (int) $o->get_id() ) {
				$other       = wc_get_order( $occ[ $j ] );
				$conflicts[] = '#' . $o->get_order_number() . ' nachodzi na #' . ( $other ? $other->get_order_number() : $occ[ $j ] );
				break;
			}
			$occ[ $j ] = (int) $o->get_id();
		}
	}
	return array(
		'win'       => $w,
		'cap'       => (int) $w['cap'],
		'used'      => $used,
		'slots'     => $slots,
		'occ'       => $occ,
		'conflicts' => array_values( array_unique( $conflicts ) ),
		'offgrid'   => $offgrid,
	);
}

// Godziny, od których zamówienie się zmieści: [ 'HH:MM' => etykieta ].
function dc_plan_options( $grid, $order ) {
	$out = array();
	if ( ! $grid ) {
		return $out;
	}
	$p = dc_order_points( $order );
	$n = count( $grid['slots'] );
	for ( $i = 0; $i < $n; $i++ ) {
		if ( $p > 0 && $i + $p > $n ) {
			break;
		}
		$free = true;
		for ( $j = $i; $j < $i + $p; $j++ ) {
			if ( isset( $grid['occ'][ $j ] ) ) {
				$free = false;
				break;
			}
		}
		if ( ! $free ) {
			continue;
		}
		$t     = $grid['slots'][ $i ];
		$label = $t;
		if ( $p > 1 ) {
			$label .= '–' . dc_plan_slot_time( $grid['win'], $i + $p );
		}
		if ( $i + max( 1, $p ) > $grid['cap'] ) {
			$label .= ' (po oknie)';
		}
		$out[ $t ] = $label;
	}
	return $out;
}

