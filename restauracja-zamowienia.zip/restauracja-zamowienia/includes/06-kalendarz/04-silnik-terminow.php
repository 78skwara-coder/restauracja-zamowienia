<?php
/**
 * Moduł 06-kalendarz – silnik: które terminy są możliwe.
 * Część modułu (pliki wczytywane po kolei – kolejność jak w dawnym jednym pliku).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 2. SILNIK: które terminy są możliwe
 * ============================================================ */
function rzd_dc_now() {
	return new DateTime( 'now', wp_timezone() );
}

/**
 * Numer domu obowiązkowy przy składaniu zamówienia – bez niego kurier/kuchnia
 * w Planowaniu nie ma z czym pracować. Pole "Adres" WooCommerce (address_1)
 * samo w sobie jest już wymagane, ale nic nie sprawdza, czy klient faktycznie
 * wpisał w nim numer – dopisujemy tę jedną, dodatkową regułę.
 * woocommerce_after_checkout_validation działa zarówno przy klasycznym
 * formularzu kasy, jak i przy nowym, blokowym checkoutcie WooCommerce.
 */
add_action( 'woocommerce_after_checkout_validation', function ( $fields, $errors ) {
	// Sprawdzamy ŁĄCZNIE pole "Adres" (address_1) i "Numer domu/mieszkania"
	// (address_2) – niektóre wtyczki checkoutu (np. Fluid Checkout) trzymają
	// numer domu właśnie w address_2 jako osobnym polu, a nie doklejony do
	// nazwy ulicy w address_1. Sprawdzanie tylko address_1 fałszywie
	// odrzucało zamówienia, w których numer był poprawnie podany, tylko
	// w tym drugim polu.
	$needs_shipping = function_exists( 'WC' ) && WC()->cart && WC()->cart->needs_shipping();
	$use_shipping   = $needs_shipping && ! empty( $fields['ship_to_different_address'] );
	$key1           = $use_shipping ? 'shipping_address_1' : 'billing_address_1';
	$key2           = $use_shipping ? 'shipping_address_2' : 'billing_address_2';
	$val1           = isset( $fields[ $key1 ] ) ? $fields[ $key1 ] : '';
	$val2           = isset( $fields[ $key2 ] ) ? $fields[ $key2 ] : '';
	$combined       = trim( $val1 . ' ' . $val2 );
	if ( '' !== $combined && ! preg_match( '/\d/', $combined ) ) {
		$errors->add( 'validation', 'Podaj numer domu/mieszkania w adresie – bez niego nie da się zaplanować dostawy.' );
	}

	// Numer telefonu obowiązkowy – niezależnie od tego, czy checkout (np.
	// Fluid Checkout) sam pokazuje to pole jako wymagane. Kuchnia i kurier
	// potrzebują telefonu do klienta przy dostawie, więc egzekwujemy to
	// twardo, tu, po stronie serwera – nie tylko oznaczeniem pola gwiazdką.
	// Kasa klasyczna sama zgłasza puste pole wymagane (kod „billing_phone_required”) –
	// wtedy bez drugiego komunikatu o tym samym (2.39.0).
	if ( '' === trim( (string) ( isset( $fields['billing_phone'] ) ? $fields['billing_phone'] : '' ) ) && ! $errors->get_error_messages( 'billing_phone_required' ) ) {
		$errors->add( 'validation', rzd_phone_required_text() );
	}
}, 10, 2 );

function rzd_phone_required_text() {
	return 'Podaj numer telefonu – jest potrzebny przy dostawie.';
}

// Komunikat WooCommerce o pustym telefonie („Numer telefonu rozliczeniowy jest wymaganym polem”)
// → zrozumiały dla klienta restauracji. Ten sam tekst pokazuje się też pod polem.
add_filter( 'woocommerce_checkout_required_field_notice', function ( $notice, $label = '', $key = '' ) {
	return 'billing_phone' === $key ? rzd_phone_required_text() : $notice;
}, 10, 3 );

// Telefon wymagany także w ustawieniu WooCommerce („Pole numeru telefonu” w Dostosuj → WooCommerce → Kasa)
// i w danych kraju (locale) – skrypt adresu WooCommerce (address-i18n) po załadowaniu kasy przepisuje
// etykietę wg nich; bez tego pole wyglądało na „(opcjonalne)”, choć walidacja go wymagała (2.39.0).
add_filter( 'pre_option_woocommerce_checkout_phone_field', function () {
	return 'required';
} );
$rzd_phone_locale = function ( $loc ) {
	if ( is_array( $loc ) && isset( $loc['phone'] ) && is_array( $loc['phone'] ) ) {
		$loc['phone']['required'] = true;
		$loc['phone']['hidden']   = false;
	}
	return $loc;
};
add_filter( 'woocommerce_get_country_locale_default', $rzd_phone_locale, 60 );
add_filter( 'woocommerce_get_country_locale_base', $rzd_phone_locale, 60 );
add_filter( 'woocommerce_get_country_locale', function ( $all ) use ( $rzd_phone_locale ) {
	foreach ( (array) $all as $cc => $loc ) {
		$all[ $cc ] = $rzd_phone_locale( $loc );
	}
	return $all;
}, 60 );

// Druga linia adresu (domyślnie „Nr mieszkania, lokalu, itp.”) obowiązkowa –
// kurier musi wiedzieć, do którego mieszkania. Mieszkający w domu wpisują
// „dom”, co też jest dla kuriera informacją. Numer domu pilnuje reguła
// wyżej (cyfra w adresie).
add_filter( 'woocommerce_default_address_fields', function ( $fields ) {
	if ( isset( $fields['address_2'] ) ) {
		$fields['address_2']['required']    = true;
		$fields['address_2']['label']       = 'Nr mieszkania / lokalu';
		$fields['address_2']['placeholder'] = 'mieszkasz w domu? Wpisz: dom';
		$fields['address_2']['label_class'] = array_diff( (array) ( isset( $fields['address_2']['label_class'] ) ? $fields['address_2']['label_class'] : array() ), array( 'screen-reader-text' ) );
	}
	return $fields;
}, 20 );

// Oznaczenie pola telefonu jako wymagane na klasycznym formularzu kasy –
// dla porządku (gwiazdka, natywny komunikat WooCommerce), choć twarde
// wymuszenie i tak dzieje się wyżej, niezależnie od tego pola.
add_filter( 'woocommerce_billing_fields', function ( $fields ) {
	if ( isset( $fields['billing_phone'] ) ) {
		$fields['billing_phone']['required'] = true;
	}
	return $fields;
} );

// telefon w kroku „Kontakt” Fluid Checkout (obok e-maila), a nie dopiero
// w adresie. Filtr Fluid Checkout – bez tej wtyczki po prostu nic nie robi.
add_filter( 'fc_checkout_contact_step_field_ids', function ( $ids ) {
	$ids = (array) $ids;
	if ( ! in_array( 'billing_phone', $ids, true ) ) {
		$ids[] = 'billing_phone';
	}
	return $ids;
} );

function rzd_dc_date_ts( $date, $time = '12:00' ) {
	$dt = DateTime::createFromFormat( 'Y-m-d H:i', $date . ' ' . $time, wp_timezone() );
	return $dt ? $dt->getTimestamp() : 0;
}

/**
 * Czy dla danego terminu (data + godzina) minął już CUTOFF DOSTAWY –
 * czyli czy ten konkretny wyjazd jest już zamknięty na nowe zamówienia?
 * To jest EFEKTYWNY, połączony wynik dwóch niezależnych ustawień grupy:
 * cutoffu dziennego (jedna godzina na cały dzień, opcjonalna) ORAZ
 * minimalnego czasu do wyjazdu (osobno dla każdego terminu) – którykolwiek
 * z nich zamyka termin wcześniej, ten obowiązuje.
 *
 * Używane w dwóch miejscach: (1) moduł 12 (Kuchnia) – do automatycznego
 * przełączenia zamówienia w status "W przygotowaniu" i do znaczka
 * "Otwarte/Zamknięte" przy każdym oknie dostawy; (2) sam wybór terminu na
 * liście – ten sam warunek decyduje, czy klient może jeszcze coś zamówić.
 * Dzięki jednej wspólnej funkcji klient i kuchnia zawsze widzą to samo.
 *
 * Sprawdzamy WSZYSTKIE grupy (kategorie), które mają tę godzinę w swojej
 * konfiguracji: jeśli choć jedna z nich WCIĄŻ przyjmuje zamówienia na tę
 * godzinę (rzd_dc_calendar_times_for_date, który sam w sobie już uwzględnia
 * oba ustawienia), cutoff dostawy jeszcze nie minął.
 */
function rzd_dc_is_cutoff_passed( $date, $time ) {
	if ( ! $date || ! $time ) {
		return false; // brak danych – nie zgadujemy
	}
	$s           = rzd_dc_get_settings();
	$matched_any = false;
	foreach ( $s['groups'] as $cal ) {
		if ( ! rzd_dc_group_has_time( $cal, $date, $time ) ) {
			continue;
		}
		$matched_any = true;
		if ( in_array( $time, rzd_dc_calendar_times_for_date( $cal, $date ), true ) ) {
			return false; // co najmniej jedna grupa z tą godziną wciąż przyjmuje zamówienia
		}
	}
	if ( ! $matched_any ) {
		// Żadna skonfigurowana grupa nie ma tej godziny – porównujemy wprost
		// z momentem wyjazdu, zamiast zgadywać.
		$ts = rzd_dc_date_ts( $date, $time );
		return $ts && rzd_dc_now()->getTimestamp() >= $ts;
	}
	return true; // dopasowano przynajmniej jedną grupę i żadna już nie przyjmuje zamówień na tę godzinę
}

/**
 * KIEDY zamyka się dany termin (data + godzina wyjazdu) – znacznik czasu.
 * Uzupełnienie rzd_dc_is_cutoff_passed() (która mówi tylko CZY), potrzebne w
 * Kuchni do grupowania zamówień wg cutoffu (moduł 12, zakładka Zamówienia).
 *
 * Dla jednej grupy: wcześniejszy z dwóch momentów – cutoff dzienny
 * (godzina w dniu D − „dni przed dostawą”; pusta godzina przy 1+ dniach =
 * 23:59) oraz wyjazd minus „Min. czas do wyjazdu”. Gdy tę godzinę ma kilka
 * grup, obowiązuje NAJPÓŹNIEJSZY z ich momentów (tak samo jak w
 * rzd_dc_is_cutoff_passed: termin jest otwarty, dopóki przyjmuje go choć jedna
 * grupa). Żadna grupa nie ma tej godziny → sam moment wyjazdu.
 * Limit pojemności i matryca nie mają „momentu”, więc tu ich nie ma.
 */
/**
 * dzień, do którego trzeba zamówić na dostawę $date przy „N dni przed
 * dostawą”. Liczymy DNI DOSTAW tej grupy wstecz, a nie dni kalendarzowe:
 * dni nieodhaczone w „Dni dostaw”, daty wyłączone (grupy i globalne), w trybie
 * okien dni bez dostawy na osi dnia, a w starym trybie „Dostawy wyłączone” – pomijamy.
 * Przykład: pon–pt, 1 dzień, 10:30 → na poniedziałek do piątku 10:30, na wtorek
 * do poniedziałku 10:30; święto w środę → na czwartek do wtorku.
 * 0 dni = sam dzień dostawy (jak dotąd).
 */
function rzd_dc_cutoff_deadline_date( $cal, $date ) {
	$n = isset( $cal['cutoff_days'] ) ? (int) $cal['cutoff_days'] : 0;
	if ( $n <= 0 ) {
		return $date;
	}
	static $memo = array();
	$key = md5( wp_json_encode( array( isset( $cal['days'] ) ? $cal['days'] : array(), isset( $cal['blocked'] ) ? $cal['blocked'] : array() ) ) ) . '|' . $n . '|' . $date;
	if ( isset( $memo[ $key ] ) ) {
		return $memo[ $key ];
	}
	$s     = rzd_dc_get_settings();
	$tz    = wp_timezone();
	$win   = rzd_dc_windows_on();
	$d     = new DateTime( $date, $tz );
	$count = 0;
	for ( $i = 0; $i < 120; $i++ ) { // bezpiecznik: grupa bez żadnego dnia dostaw
		$d->modify( '-1 day' );
		$ymd = $d->format( 'Y-m-d' );
		$dow = $d->format( 'D' );
		if ( ! in_array( $dow, (array) $cal['days'], true ) ) {
			continue;
		}
		if ( in_array( $ymd, (array) $cal['blocked'], true ) || in_array( $ymd, (array) $s['global_blocked'], true ) ) {
			continue;
		}
		if ( $win ? ! rzd_dc_windows_for_dow( $dow ) : in_array( $dow, (array) $s['off_days'], true ) ) {
			continue;
		}
		if ( ++$count >= $n ) {
			return $memo[ $key ] = $ymd;
		}
	}
	// Nie znaleziono (np. brak dni dostaw) – stare liczenie kalendarzowe.
	$d = new DateTime( $date, $tz );
	$d->modify( '-' . $n . ' days' );
	return $memo[ $key ] = $d->format( 'Y-m-d' );
}

function rzd_dc_cutoff_ts( $date, $time ) {
	$depart = rzd_dc_date_ts( $date, $time );
	if ( ! $depart ) {
		return 0;
	}
	$s     = rzd_dc_get_settings();
	$tz    = wp_timezone();
	$found = array();
	foreach ( $s['groups'] as $cal ) {
		if ( ! rzd_dc_group_has_time( $cal, $date, $time ) ) {
			continue;
		}
		$ts = $depart - 60 * (int) ( isset( $cal['lead'] ) ? $cal['lead'] : 0 );
		$cutoff_days = isset( $cal['cutoff_days'] ) ? (int) $cal['cutoff_days'] : 0;
		if ( ! empty( $cal['cutoff'] ) || $cutoff_days > 0 ) {
			// „N dni przed” = N dni dostaw wstecz (rzd_dc_cutoff_deadline_date).
			$daily = rzd_dc_date_ts( rzd_dc_cutoff_deadline_date( $cal, $date ), ! empty( $cal['cutoff'] ) ? $cal['cutoff'] : '23:59' );
			if ( $daily && $daily < $ts ) {
				$ts = $daily;
			}
		}
		$found[] = $ts;
	}
	return $found ? max( $found ) : $depart;
}

/**
 * Harmonogram dostaw DLA PRODUKTU (nie mylić z harmonogramem SKŁADU zestawu
 * z modułu 5) – zwięzłe podsumowanie konfiguracji kalendarza kategorii, do
 * której należy produkt, np. "pn–pt: 8:30–9:30, 9:30–10:30". Dni ze sobą
 * sąsiadujące są kompresowane do zakresu (pn–pt), pojedyncze wypisane osobno.
 */
function rzd_dc_compress_day_ranges( $days ) {
	$order = array_keys( rzd_dc_days() ); // Mon..Sun w tej kolejności
	$set   = array_values( array_filter( $order, function ( $d ) use ( $days ) {
		return in_array( $d, (array) $days, true );
	} ) );
	if ( ! $set ) {
		return array();
	}
	$labels = rzd_dc_days();
	$ranges = array();
	$start  = $set[0];
	$prev   = $set[0];
	for ( $i = 1; $i <= count( $set ); $i++ ) {
		$cur          = isset( $set[ $i ] ) ? $set[ $i ] : null;
		$prev_index   = array_search( $prev, $order, true );
		$is_consecutive = $cur && ( array_search( $cur, $order, true ) === $prev_index + 1 );
		if ( ! $is_consecutive ) {
			$ranges[] = ( $start === $prev ) ? $labels[ $start ] : ( $labels[ $start ] . '–' . $labels[ $prev ] );
			$start    = $cur;
		}
		$prev = $cur;
	}
	return $ranges;
}

// Tytuł ramki z harmonogramem dostaw (do zmiany w „Wygląd listy”).
function rzd_dc_delivery_box_title() {
	return function_exists( 'rzd_list_label' ) ? rzd_list_label( 'delivery' ) : 'Możliwe dostawy';
}

function rzd_dc_product_schedule_summary_html( $product_id ) {
	// treść zależy tylko od grup produktu – produkty z tych samych grup
	// (np. wszystkie bajgle) dostają gotowy wynik zamiast liczenia od nowa.
	static $memo = array();
	$gkey = implode( ',', rzd_dc_group_ids_for_product( $product_id ) );
	if ( ! isset( $memo[ $gkey ] ) ) {
		$memo[ $gkey ] = rzd_dc_product_schedule_summary_calc( $product_id );
	}
	return $memo[ $gkey ];
}

function rzd_dc_product_schedule_summary_calc( $product_id ) {
	$cals = rzd_dc_calendars_for_product( $product_id );
	if ( ! $cals ) {
		return '';
	}
	// Tryb okien: godziny różnią się między dniami tygodnia, więc dni z tym
	// samym zestawem okien łączymy („Pon–Pt: 11:00–12:00, …; Sob: …”).
	if ( rzd_dc_windows_on() ) {
		$by_label = array();
		$day      = rzd_dc_now();
		for ( $i = 0; $i < 7; $i++ ) {
			$date  = $day->format( 'Y-m-d' );
			$dow   = $day->format( 'D' );
			$day->modify( '+1 day' );
			$times = array();
			foreach ( $cals as $cal ) {
				if ( in_array( $dow, (array) $cal['days'], true ) ) {
					$times = array_merge( $times, rzd_dc_group_times( $cal, $date ) );
				}
			}
			$times = array_values( array_unique( $times ) );
			sort( $times );
			if ( ! $times ) {
				continue;
			}
			$label = implode( ', ', array_map( function ( $t ) use ( $date ) {
				return rzd_dc_time_window_label( $t, $date );
			}, $times ) );
			$by_label[ $label ][] = $dow;
		}
		if ( ! $by_label ) {
			return '';
		}
		$parts = array();
		foreach ( $by_label as $label => $dows ) {
			$parts[] = '<strong>' . esc_html( implode( ', ', rzd_dc_compress_day_ranges( $dows ) ) ) . ':</strong> ' . esc_html( $label );
		}
		return '<details class="rl2-delivery"><summary>' . esc_html( rzd_dc_delivery_box_title() ) . '</summary><div class="rl2-delivery-body">' . implode( '<br>', $parts ) . '</div></details>';
	}

	$days  = array();
	$times = array();
	foreach ( $cals as $cal ) {
		$days  = array_merge( $days, (array) $cal['days'] );
		$times = array_merge( $times, (array) $cal['times'] );
	}
	$days  = array_values( array_unique( $days ) );
	$times = array_values( array_unique( $times ) );
	sort( $times );
	if ( ! $days || ! $times ) {
		return '';
	}
	$day_ranges = rzd_dc_compress_day_ranges( $days );
	$windows    = array_map( 'rzd_dc_time_window_label', $times );

	ob_start();
	?>
	<details class="rl2-delivery">
		<summary><?php echo esc_html( rzd_dc_delivery_box_title() ); ?></summary>
		<div class="rl2-delivery-body">
			<strong><?php echo esc_html( implode( ', ', $day_ranges ) ); ?>:</strong>
			<?php echo esc_html( implode( ', ', $windows ) ); ?>
		</div>
	</details>
	<?php
	return ob_get_clean();
}

function rzd_dc_date_label( $date ) {
	$ts = rzd_dc_date_ts( $date );
	return $ts ? wp_date( 'l, j F Y', $ts ) : $date;
}

/**
 * Klient widzi PRZEDZIAŁ godzinowy (godzina wyjazdu + 1 godzina), nie
 * dokładną minutę wyjazdu – to wyjazd, nie moment dostawy pod drzwi, a
 * dokładną kolejność w tej godzinie i tak ustala się dopiero w Planowaniu.
 */
function rzd_dc_time_window_label( $time, $date = '' ) {
	if ( ! preg_match( '/^([01]\d|2[0-3]):([0-5]\d)$/', $time ) ) {
		return $time;
	}
	// Tryb okien: prawdziwy koniec okna (okna mają różne długości).
	if ( $date && rzd_dc_windows_on() ) {
		$w = rzd_dc_window_at( $date, $time );
		if ( $w ) {
			return $w['start'] . '–' . $w['end'];
		}
	}
	$end = DateTime::createFromFormat( 'H:i', $time );
	if ( ! $end ) {
		return $time;
	}
	$end->modify( '+1 hour' );
	return $time . '–' . $end->format( 'H:i' );
}

function rzd_dc_slot_label( $slot ) {
	return rzd_dc_date_label( $slot['date'] ) . ', ' . rzd_dc_time_window_label( $slot['time'], $slot['date'] );
}

// Pasek terminu: z miejscowością, gdy działa matryca miejscowości (moduł 20).
function rzd_dc_slot_label_town( $slot ) {
	$town = function_exists( 'rzd_session_town' ) && function_exists( 'rzd_towns_enabled' ) && rzd_towns_enabled() ? rzd_session_town() : '';
	return rzd_dc_slot_label( $slot ) . ( $town ? ' · ' . $town : '' );
}

function rzd_dc_slot_expired( $slot ) {
	$ts = rzd_dc_date_ts( $slot['date'], $slot['time'] );
	return ! $ts || $ts < time();
}

function rzd_dc_product_root_id( $product_id ) {
	$p = wc_get_product( $product_id );
	return ( $p && $p->is_type( 'variation' ) ) ? (int) $p->get_parent_id() : (int) $product_id;
}

// Skonfigurowane grupy produktu: jego kategorie i kategorie nadrzędne (podkategoria dziedziczy kalendarz)
function rzd_dc_group_ids_for_product( $product_id ) {
	// WYDAJNOŚĆ: ta funkcja jest wywoływana RAZ NA KAŻDY DZIEŃ w pętli
	// sprawdzającej dostępne terminy (do kilkudziesięciu razy dla tego
	// samego produktu w jednym żądaniu) – wynik dla danego produktu nie
	// zmienia się w trakcie jednego żądania, więc liczymy go raz.
	static $memo = array();
	$root = rzd_dc_product_root_id( $product_id );
	if ( isset( $memo[ $root ] ) ) {
		return $memo[ $root ];
	}

	$s     = rzd_dc_get_settings();
	$found = array();
	foreach ( (array) wc_get_product_term_ids( $root, 'product_cat' ) as $tid ) {
		$chain = array_merge( array( (int) $tid ), array_map( 'intval', get_ancestors( (int) $tid, 'product_cat', 'taxonomy' ) ) );
		foreach ( $chain as $id ) {
			if ( isset( $s['groups'][ $id ] ) ) {
				$found[ $id ] = true;
			}
		}
	}
	$memo[ $root ] = array_keys( $found );
	return $memo[ $root ];
}

// Kalendarze produktu = kalendarze jego grup. Produkt bez skonfigurowanej grupy nie ma kalendarza.
function rzd_dc_calendars_for_product( $product_id ) {
	$s    = rzd_dc_get_settings();
	$cals = array();
	foreach ( rzd_dc_group_ids_for_product( $product_id ) as $gid ) {
		$cals[] = $s['groups'][ $gid ];
	}
	return $cals;
}

// Godziny dostaw jednego kalendarza w danym dniu (z cutoffem dla "dziś")
function rzd_dc_max_per_slot() {
	$s = rzd_dc_get_settings();
	return isset( $s['max_per_slot'] ) && $s['max_per_slot'] > 0 ? (int) $s['max_per_slot'] : 6;
}

/**
 * Ile OPŁACONYCH zamówień jest już w danym oknie dostawy (data+godzina
 * wyjazdu), niezależnie od kategorii – to jedna fizyczna dostawa/kurs, więc
 * limit liczy się łącznie, nie osobno na każdą kategorię produktów.
 * Cache w pamięci na czas jednego żądania – ta sama godzina bywa sprawdzana
 * wielokrotnie przy budowaniu listy dostępnych godzin.
 */
/**
 * Jedno zapytanie do bazy na cały request, zamiast osobnego na KAŻDĄ
 * kombinację dnia+godziny+grupy przy budowaniu kalendarza (przy horyzoncie
 * 60 dni i kilku godzinach dziennie robiło się to setki zapytań na jedno
 * wejście na stronę – ta wersja liczy wszystko raz, w pamięci).
 */
function rzd_dc_orders_count_map() {
	$maps = rzd_dc_orders_slot_maps();
	return $maps['count'];
}

// Suma punktów zamówień w terminie (tryb okien).
function rzd_dc_orders_points_for_slot( $date, $time ) {
	$maps = rzd_dc_orders_slot_maps();
	$key  = $date . '|' . $time;
	return isset( $maps['points'][ $key ] ) ? (int) $maps['points'][ $key ] : 0;
}

// Liczba zamówień i suma ich punktów na termin – jedno zapytanie na request.
// wynik pamiętany też MIĘDZY wejściami (transient `dc_order_maps`,
// max 10 min) i liczony od nowa dopiero po zmianie zamówienia (nowe, zmiana
// statusu/terminu, usunięcie – rzd_dc_orders_maps_flush()). Wcześniej każde
// wejście na listę przy pustym buforze terminów wczytywało WSZYSTKIE przyszłe
// zamówienia jako pełne obiekty. W kasie (składanie zamówienia) zawsze
// świeże dane – limit miejsc nie może się oprzeć na starej kopii.
function rzd_dc_orders_slot_maps() {
	static $maps = null;
	if ( null !== $maps ) {
		return $maps;
	}
	$uri   = isset( $_SERVER['REQUEST_URI'] ) ? (string) $_SERVER['REQUEST_URI'] : ''; // phpcs:ignore
	$fresh = ( defined( 'WOOCOMMERCE_CHECKOUT' ) && WOOCOMMERCE_CHECKOUT )
		|| ( function_exists( 'is_checkout' ) && did_action( 'wp' ) && is_checkout() )
		|| ( false !== strpos( $uri, 'wc/store' ) && false !== strpos( $uri, 'checkout' ) );
	$sig   = rzd_dc_now()->format( 'Y-m-d' ) . '|' . md5( wp_json_encode( function_exists( 'rzd_order_statuses_active' ) ? rzd_order_statuses_active() : array() ) );
	if ( ! $fresh ) {
		$c = get_transient( 'dc_order_maps' );
		if ( is_array( $c ) && isset( $c['sig'], $c['count'], $c['points'] ) && $c['sig'] === $sig ) {
			$maps = array( 'count' => $c['count'], 'points' => $c['points'] );
			return $maps;
		}
	}
	$maps = rzd_dc_orders_slot_maps_calc();
	set_transient( 'dc_order_maps', array( 'sig' => $sig, 'count' => $maps['count'], 'points' => $maps['points'] ), 10 * MINUTE_IN_SECONDS );
	return $maps;
}

// Zamówienie się zmieniło (albo ustawienia punktów) – licznik terminów od nowa.
function rzd_dc_orders_maps_flush() {
	delete_transient( 'dc_order_maps' );
}
foreach ( array( 'woocommerce_new_order', 'woocommerce_update_order', 'woocommerce_order_status_changed', 'woocommerce_delete_order', 'woocommerce_trash_order', 'woocommerce_untrash_order', 'update_option_rzd_towns', 'update_option_dc_settings' ) as $dc_hook ) {
	add_action( $dc_hook, 'rzd_dc_orders_maps_flush' );
}
unset( $dc_hook );

function rzd_dc_orders_slot_maps_calc() {
	$map    = array();
	$points = array();

	// Ta sama definicja "co się liczy jako realne zamówienie" co w module 12
	// (Kuchnia) – w jednym miejscu, żeby oba liczniki nie mogły się rozjechać
	// tak jak przy poprzednim błędzie z płatnością przy odbiorze.
	if ( function_exists( 'rzd_order_statuses_active' ) ) {
		$statuses = rzd_order_statuses_active();
	} else {
		$statuses = array( 'wc-processing', 'wc-completed', 'wc-on-hold' );
		if ( function_exists( 'rzd_kitchen_statuses' ) ) {
			foreach ( array_keys( rzd_kitchen_statuses() ) as $slug ) {
				$statuses[] = 'wc-' . $slug;
			}
		}
	}

	$orders = wc_get_orders( array(
		'limit'      => -1,
		'status'     => $statuses,
		'return'     => 'objects',
		'meta_query' => array( // phpcs:ignore
			array( 'key' => '_dc_delivery_date', 'value' => rzd_dc_now()->format( 'Y-m-d' ), 'compare' => '>=' ),
		),
	) );
	foreach ( $orders as $o ) {
		$d = $o->get_meta( '_dc_delivery_date' );
		$t = $o->get_meta( '_dc_delivery_time' );
		if ( ! $d || ! $t ) {
			continue;
		}
		$key            = $d . '|' . $t;
		$map[ $key ]    = isset( $map[ $key ] ) ? $map[ $key ] + 1 : 1;
		$points[ $key ] = ( isset( $points[ $key ] ) ? $points[ $key ] : 0 ) + rzd_dc_order_points( $o );
	}
	return array( 'count' => $map, 'points' => $points );
}

function rzd_dc_orders_count_for_slot( $date, $time ) {
	$map = rzd_dc_orders_count_map();
	$key = $date . '|' . $time;
	return isset( $map[ $key ] ) ? $map[ $key ] : 0;
}

/**
 * Efektywny przedział "od–do" godzin dostawy dla grupy w danym dniu (wg dnia
 * tygodnia daty DOSTAWY). Łączy CZTERY komórki matrycy: grupa/ten dzień,
 * grupa/"Wszystkie dni", "Wszystkie grupy"/ten dzień i "Wszystkie grupy"/
 * "Wszystkie dni". Obowiązuje najwęższy – NAJPÓŹNIEJSZY początek
 * i NAJWCZEŚNIEJSZY koniec ze wszystkich wypełnionych.
 * Np. grupa w poniedziałek od 07:00, globalnie od 10:00 → od 10:00.
 * Zwraca [ from, to ]; '' = brak ograniczenia z tej strony.
 */
function rzd_dc_window_for_date( $cal, $date ) {
	$s    = rzd_dc_get_settings();
	$dow  = ( new DateTime( $date, wp_timezone() ) )->format( 'D' );
	$cells = array();
	foreach ( array( (array) ( isset( $cal['window'] ) ? $cal['window'] : array() ), (array) $s['global_window'] ) as $row ) {
		foreach ( array( $dow, 'All' ) as $col ) {
			if ( isset( $row[ $col ] ) && is_array( $row[ $col ] ) ) {
				$cells[] = $row[ $col ];
			}
		}
	}
	$froms = array_filter( array_map( function ( $c ) { return isset( $c['from'] ) ? $c['from'] : ''; }, $cells ) );
	$tos   = array_filter( array_map( function ( $c ) { return isset( $c['to'] ) ? $c['to'] : ''; }, $cells ) );
	return array(
		$froms ? max( $froms ) : '',
		$tos ? min( $tos ) : '',
	);
}

// $ignore_cutoff = true: dla Kuchni ("Nowy termin" przy przeplanowaniu) –
// bez cutoffów, "Min. czasu do wyjazdu" i limitu pojemności; zostają dni,
// daty wyłączone, matryca i to, że wyjazd musi być w przyszłości.
function rzd_dc_calendar_times_for_date( $cal, $date, $ignore_cutoff = false ) {
	// wynik dla tej samej grupy i dnia liczony raz na żądanie – na liście
	// wiele produktów należy do tych samych grup, a liczenie (cutoffy, okna,
	// daty) powtarzało się dla każdego produktu i każdego dnia.
	static $memo = array();
	$mkey = md5( serialize( $cal ) ) . '|' . $date . '|' . ( $ignore_cutoff ? 1 : 0 );
	if ( isset( $memo[ $mkey ] ) ) {
		return $memo[ $mkey ];
	}
	$memo[ $mkey ] = rzd_dc_calendar_times_for_date_calc( $cal, $date, $ignore_cutoff );
	return $memo[ $mkey ];
}

function rzd_dc_calendar_times_for_date_calc( $cal, $date, $ignore_cutoff = false ) {
	if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) || ( ! rzd_dc_windows_on() && empty( $cal['times'] ) ) ) {
		return array();
	}
	$s     = rzd_dc_get_settings();
	$tz    = wp_timezone();
	$now   = rzd_dc_now();
	$today = $now->format( 'Y-m-d' );

	if ( $date < $today ) {
		return array();
	}
	$max_dt = new DateTime( $today, $tz );
	$max_dt->modify( '+' . (int) $cal['horizon'] . ' days' );
	if ( $date > $max_dt->format( 'Y-m-d' ) ) {
		return array();
	}
	if ( ! empty( $cal['valid_from'] ) && $date < $cal['valid_from'] ) {
		return array();
	}
	if ( ! empty( $cal['valid_to'] ) && $date > $cal['valid_to'] ) {
		return array();
	}
	$dow = ( new DateTime( $date, $tz ) )->format( 'D' );
	// Tryb okien: dzień bez dostaw ustawia się na osi dnia (znacznik „dostawa”),
	// dawny wiersz „Dostawy wyłączone” działa tylko w starym trybie.
	if ( ! in_array( $dow, (array) $cal['days'], true ) || ( ! rzd_dc_windows_on() && in_array( $dow, (array) $s['off_days'], true ) ) ) {
		return array();
	}
	if ( in_array( $date, (array) $cal['blocked'], true ) || in_array( $date, (array) $s['global_blocked'], true ) ) {
		return array();
	}

	// Cutoff dzienny: zamówienie na dzień $date trzeba złożyć do godziny
	// 'cutoff' w dniu „N dni dostaw przed $date” (dni bez dostaw i daty
	// wyłączone się nie liczą – rzd_dc_cutoff_deadline_date). 0 dni = w dniu
	// dostawy. Brak godziny przy 1+ dniach = do końca tamtego dnia.
	$cutoff_days = isset( $cal['cutoff_days'] ) ? (int) $cal['cutoff_days'] : 0;
	if ( ! $ignore_cutoff && ( ! empty( $cal['cutoff'] ) || $cutoff_days > 0 ) ) {
		$deadline_str = rzd_dc_cutoff_deadline_date( $cal, $date ) . ' ' . ( ! empty( $cal['cutoff'] ) ? $cal['cutoff'] : '23:59' );
		if ( $now->format( 'Y-m-d H:i' ) > $deadline_str ) {
			return array(); // po cutoffie ten dzień dostawy jest już zamknięty
		}
	}

	// Godziny grupy tego dnia: okna dostaw albo 'times', przycięte matrycą od–do.
	$times = rzd_dc_group_times( $cal, $date );

	// Min. czas do wyjazdu (lead): wyjazd musi być później niż teraz + lead.
	// porównanie pełnej daty, nie tylko dzisiejszej – gdy teraz + lead
	// wypada jutro, jutrzejsze wcześniejsze wyjazdy też odpadają (wcześniej
	// zamówienie o 23:00 przy leadzie 10 h dostawało jutro 7:00).
	// Przy $ignore_cutoff (Nowy termin w Kuchni) lead = 0, czyli „później niż teraz”.
	$min = clone $now;
	$min->modify( '+' . ( $ignore_cutoff ? 0 : (int) $cal['lead'] ) . ' minutes' );
	$min_date = $min->format( 'Y-m-d' );
	if ( $date < $min_date ) {
		return array();
	}
	if ( $date === $min_date ) {
		$min_hi = $min->format( 'H:i' );
		$times  = array_values( array_filter( $times, function ( $t ) use ( $min_hi ) {
			return $t > $min_hi;
		} ) );
	}

	// Limit pojemności: okno, które osiągnęło max zamówień, znika z wyboru –
	// dotyczy każdej daty (nie tylko dzisiejszej), bo pojemność dostawy nie
	// zależy od tego, kiedy klient akurat zamawia.
	// Tryb okien: pojemność w punktach zależy od miejscowości klienta, więc
	// sprawdza się ją później (rzd_dc_filter_slots_by_room), poza buforem terminów.
	if ( $ignore_cutoff || rzd_dc_windows_on() ) {
		return $times;
	}
	$max   = rzd_dc_max_per_slot();
	$times = array_values( array_filter( $times, function ( $t ) use ( $date, $max ) {
		return rzd_dc_orders_count_for_slot( $date, $t ) < $max;
	} ) );

	return $times;
}

