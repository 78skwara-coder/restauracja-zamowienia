<?php
/**
 * Moduł 06-kalendarz – wybrany termin w sesji koszyka i egzekwowanie w koszyku.
 * Część modułu (pliki wczytywane po kolei – kolejność jak w dawnym jednym pliku).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 3. WYBRANY TERMIN W SESJI KOSZYKA
 * ============================================================ */
// Surowy odczyt (bez dotykania koszyka – bezpieczny w filtrach ładujących koszyk)
function rzd_dc_get_slot() {
	if ( ! function_exists( 'WC' ) || ! WC()->session ) {
		return null;
	}
	$slot = WC()->session->get( 'dc_slot' );
	return ( is_array( $slot ) && ! empty( $slot['date'] ) && ! empty( $slot['time'] ) ) ? $slot : null;
}

function rzd_dc_clear_slot() {
	if ( function_exists( 'WC' ) && WC()->session ) {
		WC()->session->set( 'dc_slot', null );
	}
}

// Odczyt do użycia w widokach: nieaktualny termin przy pustym koszyku jest kasowany
function rzd_dc_current_slot() {
	$slot = rzd_dc_get_slot();
	if ( $slot && rzd_dc_slot_expired( $slot ) && WC()->cart && WC()->cart->is_empty() ) {
		rzd_dc_clear_slot();
		return null;
	}
	return $slot;
}

// Data dostawy wybrana przez klienta (używana przez moduł 04 do wyboru składników zestawu)
function rzd_dc_selected_date() {
	if ( ! rzd_dc_enabled() ) {
		return null;
	}
	$slot = rzd_dc_get_slot();
	return $slot ? $slot['date'] : null;
}

function rzd_dc_cart_product_ids() {
	$ids = array();
	if ( function_exists( 'WC' ) && WC()->cart ) {
		foreach ( WC()->cart->get_cart() as $item ) {
			$ids[] = (int) $item['product_id'];
		}
	}
	return array_values( array_unique( $ids ) );
}

// Pierwszy produkt wyznacza termin – opróżniony koszyk zwalnia go
add_action( 'woocommerce_cart_emptied', 'rzd_dc_clear_slot' );
add_action( 'woocommerce_cart_item_removed', function () {
	if ( WC()->cart && WC()->cart->is_empty() ) {
		rzd_dc_clear_slot();
	}
} );

/* ============================================================
 * 4. EGZEKWOWANIE W KOSZYKU
 * ============================================================ */
add_filter( 'woocommerce_add_to_cart_validation', 'rzd_dc_validate_add_to_cart', 10, 4 );
function rzd_dc_validate_add_to_cart( $passed, $product_id, $quantity = 1, $variation_id = 0 ) {
	if ( ! $passed || ! rzd_dc_enabled() ) {
		return $passed;
	}
	$slot = rzd_dc_current_slot();
	if ( ! $slot ) {
		wc_add_notice( 'Najpierw wybierz termin dostawy – od niego zależy, które produkty możesz zamówić.', 'error' );
		return false;
	}
	if ( rzd_dc_slot_expired( $slot ) ) {
		wc_add_notice( 'Wybrany termin dostawy już minął. Wybierz nowy termin (przycisk „Zmień termin”).', 'error' );
		return false;
	}
	$msg = rzd_dc_check_product_for_slot( $product_id, $slot );
	if ( $msg ) {
		wc_add_notice( $msg . ' Produkt nie został dodany do koszyka – jedno zamówienie ma jeden termin dostawy. Zmień termin albo złóż osobne zamówienie.', 'error' );
		return false;
	}
	return $passed;
}

// Ponowna kontrola przed płatnością (mógł minąć cutoff, zmienić się dostępność)
add_action( 'woocommerce_check_cart_items', 'rzd_dc_check_cart_items' );
function rzd_dc_check_cart_items() {
	if ( ! rzd_dc_enabled() || ! WC()->cart || WC()->cart->is_empty() ) {
		return;
	}
	$slot = rzd_dc_get_slot();
	if ( ! $slot ) {
		wc_add_notice( 'Wybierz termin dostawy zamówienia (przycisk „Zmień termin”).', 'error' );
		return;
	}
	if ( rzd_dc_slot_expired( $slot ) ) {
		wc_add_notice( 'Wybrany termin dostawy już minął – wybierz nowy termin.', 'error' );
		return;
	}
	foreach ( rzd_dc_cart_product_ids() as $pid ) {
		$msg = rzd_dc_check_product_for_slot( $pid, $slot );
		if ( $msg ) {
			wc_add_notice( $msg . ' Zmień termin dostawy lub usuń produkt z koszyka.', 'error' );
		}
	}
}

/**
 * Tryb okien: pojemność sprawdzana jeszcze raz przy składaniu zamówienia
 * (dwóch klientów mogło wybrać ostatnie miejsce w tym samym czasie, a klient
 * mógł zmienić miejscowość w kasie). Punkty: miejscowość z kasy, gdy działa
 * dostawa wg miejscowości; inna metoda (np. odbiór) = 0; bez miejscowości 1.
 */
add_action( 'woocommerce_after_checkout_validation', function ( $fields, $errors ) {
	if ( ! rzd_dc_enabled() || ! rzd_dc_windows_on() ) {
		return;
	}
	$slot = rzd_dc_get_slot();
	if ( ! $slot ) {
		return;
	}
	$need = 1;
	if ( function_exists( 'rzd_towns_enabled' ) && rzd_towns_enabled() ) {
		if ( ! rzd_town_check_applies() ) {
			return; // np. odbiór osobisty – nie zajmuje miejsca w kursie
		}
		$use_shipping = ! empty( $fields['ship_to_different_address'] );
		$city         = $use_shipping ? ( isset( $fields['shipping_city'] ) ? $fields['shipping_city'] : '' ) : ( isset( $fields['billing_city'] ) ? $fields['billing_city'] : '' );
		if ( ! rzd_town_find( $city ) ) {
			return; // brak miejscowości na liście – komunikat daje moduł 20
		}
		$need = rzd_town_points( $city );
	}
	if ( ! rzd_dc_slot_has_room( $slot['date'], $slot['time'], $need ) ) {
		$errors->add( 'validation', 'Wybrany termin dostawy (' . rzd_dc_slot_label( $slot ) . ') właśnie się zapełnił. Wybierz inny termin (przycisk „Zmień termin” na górze).' );
	}
}, 25, 2 );

