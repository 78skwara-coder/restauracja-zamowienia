<?php
/**
 * MODUŁ 11: Zestawy – lista zestawów. Od 2.45.0 harmonogram zestawu ustawia się w Panelu
 * restauracji (moduł 34, sekcja Zestawy; zapis rzd_zestaw_save_slots() z modułu 04).
 * Dawna strona kokpitu „Restauracja → Zestawy” (adres rzd-zestawy) przekierowuje do panelu.
 * Zakładka „Zestaw” w edycji produktu WooCommerce działa nadal (te same dane).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** ID produktów, które mają terminy zestawu (_rwz_slots). */
function rzd_all_sets() {
	global $wpdb;
	$ids = $wpdb->get_col( "SELECT DISTINCT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_rwz_slots'" );
	return array_map( 'intval', $ids );
}
