<?php
/**
 * MODUŁ 11: Zestawy dnia – szybki dostęp z głównego menu
 *
 * Nowa pozycja w menu WordPressa: "Zestawy dnia". Wybierasz zestaw z listy
 * (albo dowolny inny produkt, żeby zrobić z niego zestaw) i zarządzasz jego
 * terminami oraz składem bez wchodzenia w pełną edycję produktu.
 *
 * To NIE jest osobny mechanizm – korzysta z tych samych funkcji zapisu i
 * renderowania co zakładka "Zestaw dnia" na karcie produktu (moduł 04),
 * więc zapisuje dokładnie te same dane. Zakładka na karcie produktu
 * działa nadal, jeśli wolisz konfigurować stamtąd – to tylko skrót.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'admin_menu', function () {
	add_menu_page( 'Zestawy dnia', 'Zestawy dnia', 'manage_woocommerce', 'rzd-zestawy', 'rzd_render_zestawy_page', 'dashicons-food', 59 );
} );

add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( 'toplevel_page_rzd-zestawy' === $hook ) {
		wp_enqueue_script( 'wc-enhanced-select' );
		wp_enqueue_style( 'woocommerce_admin_styles' );
	}
} );

function rzd_all_sets() {
	global $wpdb;
	$ids = $wpdb->get_col( "SELECT DISTINCT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_rwz_slots'" );
	return array_map( 'intval', $ids );
}

/* Zapis: dokładnie te same funkcje, których używa zakładka w edycji produktu */
add_action( 'admin_post_rzd_save_zestaw', function () {
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		wp_die( 'Brak uprawnień.' );
	}
	check_admin_referer( 'rzd_save_zestaw' );

	$product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;
	if ( ! $product_id || ! function_exists( 'rwz_save_zestaw_fields' ) ) {
		wp_die( 'Nieprawidłowy produkt albo moduł zestawów nie jest aktywny.' );
	}

	rwz_save_zestaw_fields( $product_id ); // ta sama funkcja co przy zapisie karty produktu
	if ( function_exists( 'rwz_rebuild_component_flags' ) ) {
		rwz_rebuild_component_flags( $product_id ); // przelicz flagi widoczności/blokady zakupu
	}
	if ( function_exists( 'dc_clear_slots_cache' ) ) {
		dc_clear_slots_cache();
	}

	wp_safe_redirect( add_query_arg(
		array( 'page' => 'rzd-zestawy', 'product_id' => $product_id, 'saved' => 1 ),
		admin_url( 'admin.php' )
	) );
	exit;
} );

function rzd_render_zestawy_page() {
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		return;
	}
	$sets     = rzd_all_sets();
	$selected = isset( $_GET['product_id'] ) ? absint( $_GET['product_id'] ) : 0;
	?>
	<div class="wrap">
		<h1>Zestawy dnia</h1>
		<?php if ( isset( $_GET['saved'] ) ) : ?>
			<div class="notice notice-success is-dismissible"><p>Zapisano.</p></div>
		<?php endif; ?>

		<h2>Twoje zestawy</h2>
		<?php if ( ! $sets ) : ?>
			<p>Nie masz jeszcze żadnego skonfigurowanego zestawu. Wybierz produkt niżej, żeby zacząć.</p>
		<?php else : ?>
			<table class="widefat striped" style="max-width:640px">
				<tbody>
				<?php foreach ( $sets as $sid ) : ?>
					<?php
					$p = wc_get_product( $sid );
					if ( ! $p ) {
						continue;
					}
					?>
					<tr>
						<td><?php echo esc_html( $p->get_name() ); ?></td>
						<td style="text-align:right">
							<a class="button<?php echo ( $selected === $sid ) ? ' button-primary' : ''; ?>" href="<?php echo esc_url( add_query_arg( array( 'page' => 'rzd-zestawy', 'product_id' => $sid ), admin_url( 'admin.php' ) ) ); ?>">Zarządzaj</a>
							<a class="button" href="<?php echo esc_url( get_edit_post_link( $sid ) ); ?>">Otwórz w edycji produktu</a>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>

		<h2 style="margin-top:26px">Zarządzaj innym produktem</h2>
		<p class="description">Wybierz dowolny produkt, żeby zrobić z niego zestaw albo poprawić istniejący.</p>
		<form method="get" style="margin-bottom:20px">
			<input type="hidden" name="page" value="rzd-zestawy">
			<select name="product_id" class="wc-product-search" style="width:320px" data-action="woocommerce_json_search_products_and_variations" data-placeholder="Wybierz produkt…">
				<?php
				if ( $selected && ! in_array( $selected, $sets, true ) ) {
					$p = wc_get_product( $selected );
					if ( $p ) {
						echo '<option value="' . esc_attr( $selected ) . '" selected="selected">' . esc_html( $p->get_formatted_name() ) . '</option>';
					}
				}
				?>
			</select>
			<button type="submit" class="button">Zarządzaj</button>
		</form>

		<?php if ( $selected ) : ?>
			<?php $product = wc_get_product( $selected ); ?>
			<?php if ( ! $product ) : ?>
				<p>Nie znaleziono takiego produktu.</p>
			<?php elseif ( ! function_exists( 'rwz_get_slots' ) ) : ?>
				<p>Moduł zestawów nie jest aktywny.</p>
			<?php else : ?>
				<hr>
				<h2>Konfiguracja: <?php echo esc_html( $product->get_name() ); ?></h2>
				<p><a href="<?php echo esc_url( get_edit_post_link( $selected ) ); ?>">Otwórz też w pełnej edycji produktu →</a></p>

				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="rzd_save_zestaw">
					<input type="hidden" name="product_id" value="<?php echo (int) $selected; ?>">
					<?php wp_nonce_field( 'rzd_save_zestaw' ); ?>

					<?php // 2.26.3: pasek przyklejony u góry – „Dodaj pozycję” i „Zapisz” zawsze pod ręką. ?>
					<p class="rwz-toolbar" style="display:flex;gap:8px;padding:10px 0;border-bottom:1px solid #ddd;margin-bottom:14px;position:sticky;top:32px;z-index:20;background:#f0f0f1;">
						<button type="button" class="button rwz-add-slot-btn">+ Dodaj pozycję</button>
						<button type="submit" class="button button-primary">Zapisz zestaw</button>
					</p>

					<?php
					// 2.26.3: najnowszy termin na górze – tak jak w karcie produktu (moduł 04).
					// Zapis (rwz_save_zestaw_fields) odwraca kolejność, więc w bazie zostaje
					// najstarszy pierwszy. Oba ekrany MUSZĄ pokazywać tę samą kolejność.
					$slots = array_values( rwz_get_slots( $selected ) );
					?>
					<p class="description" style="margin:0 0 10px;">Najnowsze terminy są na górze – „+ Dodaj pozycję” wstawia nowy termin na samą górę.</p>
					<div id="rwz-slots">
						<?php foreach ( array_reverse( $slots, true ) as $i => $slot ) : ?>
							<?php echo rwz_render_slot( $i, $slot ); ?>
						<?php endforeach; ?>
					</div>

					<script type="text/html" id="rwz-slot-template"><?php echo rwz_render_slot( '__SLOT__', array() ); ?></script>
					<script type="text/html" id="rwz-item-template"><?php echo rwz_render_item_row( '__SLOT__', '__ITEM__', array() ); ?></script>

					<script>
					jQuery(function ($) {
						var nextSlot = <?php echo (int) count( $slots ); ?>;
						var $slots = $('#rwz-slots');

						$(document).on('click', '.rwz-add-slot-btn', function (e) {
							e.preventDefault();
							$slots.prepend($('#rwz-slot-template').html().split('__SLOT__').join(nextSlot)); // 2.26.3: nowy termin na górze
							nextSlot++;
							$(document.body).trigger('wc-enhanced-select-init');
							$('html, body').animate({ scrollTop: Math.max(0, $slots.offset().top - 110) }, 150);
						});
						$slots.on('click', '.rwz-add-item', function (e) {
							e.preventDefault();
							var $slot = $(this).closest('.rwz-slot');
							var slotIdx = $slot.attr('data-slot');
							var itemIdx = parseInt($slot.attr('data-next-item'), 10) || 0;
							var tpl = $('#rwz-item-template').html().split('__SLOT__').join(slotIdx).split('__ITEM__').join(itemIdx);
							$slot.find('.rwz-items').first().append(tpl);
							$slot.attr('data-next-item', itemIdx + 1);
							$(document.body).trigger('wc-enhanced-select-init');
						});
						$slots.on('click', '.rwz-remove-item', function (e) { e.preventDefault(); $(this).closest('.rwz-item').remove(); });
						$slots.on('click', '.rwz-remove-slot', function (e) { e.preventDefault(); $(this).closest('.rwz-slot').remove(); });
					});
					</script>

					<p><button type="submit" class="button button-primary">Zapisz zestaw</button></p>
				</form>
			<?php endif; ?>
		<?php endif; ?>
	</div>
	<?php
}
