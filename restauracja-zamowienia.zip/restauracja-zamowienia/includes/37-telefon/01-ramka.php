<?php
/**
 * Moduł 37-telefon – zamówienia telefoniczne (2.47.0): w WooCommerce → Zamówienia (nowe albo istniejące)
 * ramka „Termin dostawy” jest edytowalna – sposób (dostawa / odbiór osobisty), data, godzina (wyjazdy
 * albo godziny odbioru, z liczbą zamówień już zapisanych – Kuchnia może świadomie przekroczyć limit),
 * miejscowość. Przy zapisie: meta terminu jak z kasy (`_dc_delivery_date`, `_dc_delivery_time`, `_rzd_pickup`,
 * `_rzd_town`, `_rzd_points`), opcjonalnie pozycja dostawy policzona jak w kasie i skład zestawów na ten dzień,
 * zamówienie dodane w panelu dostaje `_rzd_channel` = phone. Notatka w zamówieniu: kto ustawił termin.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function rzd_phone_can() {
	return current_user_can( 'edit_shop_orders' );
}

function rzd_phone_pickup_on() {
	return function_exists( 'rzd_pickup_settings' ) && ! empty( rzd_pickup_settings()['on'] );
}

/** Wartość produktów zamówienia brutto (jak „przed rabatem” w koszyku). */
function rzd_phone_order_value( $order ) {
	$v = 0.0;
	foreach ( $order->get_items() as $it ) {
		$v += (float) $it->get_subtotal() + (float) $it->get_subtotal_tax();
	}
	return $v;
}

/** Godziny do wyboru: [ data => [ 'label', 'd' => [ HH:MM => opis ], 'p' => [ HH:MM => opis ] ] ] – bez cutoffów (jak „Nowy termin”). */
function rzd_phone_slot_map( $order ) {
	$s    = rzd_dc_get_settings();
	$tz   = wp_timezone();
	$day  = new DateTime( current_time( 'Y-m-d' ), $tz );
	$max  = function_exists( 'rzd_dc_max_horizon' ) ? max( 7, rzd_dc_max_horizon() ) : 14;
	$cur  = (string) $order->get_meta( '_dc_delivery_date' );
	$out  = array();
	$maps = function_exists( 'rzd_dc_orders_slot_maps' ) ? rzd_dc_orders_slot_maps() : array();
	$dates = array();
	for ( $i = 0; $i <= $max; $i++ ) {
		$dates[] = $day->format( 'Y-m-d' );
		$day->modify( '+1 day' );
	}
	if ( $cur && ! in_array( $cur, $dates, true ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $cur ) ) {
		array_unshift( $dates, $cur );
	}
	foreach ( $dates as $d ) {
		$del = array();
		foreach ( $s['groups'] as $cal ) {
			$del = array_merge( $del, rzd_dc_calendar_times_for_date( $cal, $d, true ) );
		}
		$del = array_values( array_unique( $del ) );
		sort( $del );
		$dl = array();
		foreach ( $del as $t ) {
			$k   = $d . '|' . $t;
			$n   = isset( $maps['count'][ $k ] ) ? (int) $maps['count'][ $k ] : 0;
			$txt = rzd_dc_time_window_label( $t, $d );
			if ( function_exists( 'rzd_dc_windows_on' ) && rzd_dc_windows_on() ) {
				$pts = isset( $maps['points'][ $k ] ) ? (int) $maps['points'][ $k ] : 0;
				$cap = rzd_dc_slot_capacity( $d, $t );
				$txt .= ' · ' . $pts . '/' . $cap . ' pkt' . ( $pts >= $cap ? ' ⚠ pełne' : '' );
			} else {
				$mx   = rzd_dc_max_per_slot();
				$txt .= ' · ' . $n . '/' . $mx . ' zam.' . ( $n >= $mx ? ' ⚠ pełne' : '' );
			}
			$dl[ $t ] = $txt;
		}
		$pl = array();
		if ( rzd_phone_pickup_on() ) {
			foreach ( rzd_pickup_times_for_date( $d, true ) as $t ) {
				$n        = isset( $maps['pickup'][ $d . '|' . $t ] ) ? (int) $maps['pickup'][ $d . '|' . $t ] : 0;
				$pl[ $t ] = $t . ( $n ? ' · ' . $n . ' odb.' : '' );
			}
		}
		$out[ $d ] = array( 'label' => ucfirst( rzd_dc_date_label( $d ) ), 'd' => (object) $dl, 'p' => (object) $pl );
	}
	return $out;
}

/** Edytowalna ramka (zamiast samego opisu) – dla osób, które mogą edytować zamówienia. */
function rzd_phone_box_html( $order ) {
	$d     = (string) $order->get_meta( '_dc_delivery_date' );
	$t     = (string) $order->get_meta( '_dc_delivery_time' );
	$pk    = function_exists( 'rzd_order_is_pickup' ) && rzd_order_is_pickup( $order );
	$towns = function_exists( 'rzd_towns' ) ? rzd_towns() : array();
	$town  = (string) $order->get_meta( '_rzd_town' );
	if ( '' === $town && $towns ) {
		$row  = rzd_town_find( $order->get_shipping_city() ? $order->get_shipping_city() : $order->get_billing_city() );
		$town = $row ? $row['name'] : '';
	}
	$tinfo = array();
	foreach ( $towns as $r ) {
		$tinfo[ $r['name'] ] = rzd_town_status_for( $r, rzd_phone_order_value( $order ) );
	}
	$has_ship = (bool) $order->get_items( 'shipping' );
	$cfg      = array(
		'map'   => rzd_phone_slot_map( $order ),
		'date'  => $d,
		'time'  => $t,
		'mode'  => $pk ? 'pickup' : 'delivery',
		'towns' => (object) $tinfo,
	);
	ob_start();
	?>
	<div class="rzd-ph" style="margin-top:10px">
		<?php wp_nonce_field( 'rzd_phone_slot', 'rzd_ph_nonce' ); ?>
		<p class="rzd-ph-row" style="display:flex;flex-wrap:wrap;gap:8px 16px;align-items:center;margin:0 0 8px">
			<label><input type="radio" name="rzd_ph_mode" value="delivery" <?php checked( ! $pk ); ?>> 🚚 Dostawa</label>
			<?php if ( rzd_phone_pickup_on() || $pk ) : ?>
				<label><input type="radio" name="rzd_ph_mode" value="pickup" <?php checked( $pk ); ?>> 🏃 Odbiór osobisty</label>
			<?php endif; ?>
		</p>
		<p class="rzd-ph-row" style="display:flex;flex-wrap:wrap;gap:8px 12px;align-items:flex-end;margin:0 0 8px">
			<label>Data<br><select name="rzd_ph_date" class="rzd-ph-date"><option value=""><?php echo $d ? '— bez zmian —' : '— wybierz —'; ?></option></select></label>
			<label>Godzina<br><select name="rzd_ph_time" class="rzd-ph-time"></select></label>
			<?php if ( $towns ) : ?>
				<label class="rzd-ph-townf">Miejscowość<br><select name="rzd_ph_town" class="rzd-ph-town">
					<option value="">— wybierz —</option>
					<?php foreach ( $towns as $r ) : ?>
						<option value="<?php echo esc_attr( $r['name'] ); ?>" <?php selected( $town, $r['name'] ); ?>><?php echo esc_html( $r['name'] ); ?></option>
					<?php endforeach; ?>
				</select></label>
			<?php endif; ?>
		</p>
		<p class="rzd-ph-cost description" style="margin:0 0 8px"></p>
		<p style="margin:0 0 4px"><label><input type="checkbox" name="rzd_ph_ship" value="1" <?php checked( ! $has_ship ); ?>> Ustaw pozycję dostawy (koszt z Miejscowości albo „Odbiór osobisty”) i przelicz sumę</label></p>
		<p style="margin:0 0 4px"><label><input type="checkbox" name="rzd_ph_sets" value="1" checked> Uzupełnij skład zestawów na wybrany dzień (gdy pozycja go nie ma)</label></p>
		<p class="description" style="margin:6px 0 0">Zamówienie przez telefon: dodaj produkty i dane klienta, wybierz termin, ustaw status „Przetwarzanie” i zapisz – pojawi się w Kuchni. Godziny bez blokad cutoffu; „⚠ pełne” = limit już osiągnięty.</p>
	</div>
	<script>
	(function () {
		var c = <?php echo wp_json_encode( $cfg ); ?>;
		var box = document.currentScript.previousElementSibling;
		var dSel = box.querySelector('.rzd-ph-date'), tSel = box.querySelector('.rzd-ph-time'), town = box.querySelector('.rzd-ph-town'), tf = box.querySelector('.rzd-ph-townf'), cost = box.querySelector('.rzd-ph-cost');
		function mode() { var r = box.querySelector('input[name=rzd_ph_mode]:checked'); return r ? r.value : 'delivery'; }
		function money(v) { return (Math.round(v * 100) / 100).toFixed(2).replace('.', ',') + ' zł'; }
		function fillDates() {
			var keep = dSel.value || c.date, m = mode() === 'pickup' ? 'p' : 'd';
			while (dSel.options.length > 1) { dSel.remove(1); }
			Object.keys(c.map).forEach(function (d) {
				if (!Object.keys(c.map[d][m]).length && d !== c.date) { return; }
				var o = document.createElement('option'); o.value = d; o.textContent = c.map[d].label; dSel.appendChild(o);
			});
			dSel.value = keep && dSel.querySelector('option[value="' + keep + '"]') ? keep : '';
			fillTimes();
		}
		function fillTimes() {
			var keep = tSel.value || c.time, m = mode() === 'pickup' ? 'p' : 'd', d = dSel.value || c.date;
			tSel.textContent = '';
			var list = d && c.map[d] ? c.map[d][m] : {};
			var keys = Object.keys(list);
			if (d === c.date && c.time && keys.indexOf(c.time) < 0 && (mode() === 'pickup') === (c.mode === 'pickup')) { list = Object.assign({}, list); list[c.time] = c.time + ' (obecna)'; keys = Object.keys(list).sort(); }
			if (!keys.length) { var e = document.createElement('option'); e.value = ''; e.textContent = d ? '— brak godzin —' : '—'; tSel.appendChild(e); }
			keys.forEach(function (t) { var o = document.createElement('option'); o.value = t; o.textContent = list[t]; tSel.appendChild(o); });
			if (keep && list[keep]) { tSel.value = keep; }
			if (tf) { tf.style.display = mode() === 'pickup' ? 'none' : ''; }
			showCost();
		}
		function showCost() {
			if (mode() === 'pickup') { cost.textContent = 'Odbiór osobisty – bez kosztu dostawy.'; return; }
			var i = town && town.value ? c.towns[town.value] : null;
			cost.textContent = i ? ('Dostawa do ' + i.town + ': ' + (i.cost_now > 0 ? money(i.cost_now) : 'gratis') + (i.free_from ? ' (darmowa od ' + money(i.free_from) + ')' : '') + (i.state === 'min' ? ' · ⚠ poniżej minimum ' + money(i.min) : '')) : '';
		}
		box.querySelectorAll('input[name=rzd_ph_mode]').forEach(function (r) { r.addEventListener('change', fillDates); });
		dSel.addEventListener('change', fillTimes);
		if (town) { town.addEventListener('change', showCost); }
		fillDates();
	})();
	</script>
	<?php
	return ob_get_clean();
}

/* ---------- zapis ---------- */
add_action( 'woocommerce_process_shop_order_meta', 'rzd_phone_save', 60 );
function rzd_phone_save( $order_id ) {
	if ( ! isset( $_POST['rzd_ph_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['rzd_ph_nonce'] ) ), 'rzd_phone_slot' ) || ! rzd_phone_can() ) {
		return;
	}
	$order = wc_get_order( $order_id );
	if ( ! $order ) {
		return;
	}
	rzd_phone_apply( $order, array(
		'mode' => isset( $_POST['rzd_ph_mode'] ) ? sanitize_key( $_POST['rzd_ph_mode'] ) : 'delivery',
		'date' => isset( $_POST['rzd_ph_date'] ) ? sanitize_text_field( wp_unslash( $_POST['rzd_ph_date'] ) ) : '',
		'time' => isset( $_POST['rzd_ph_time'] ) ? sanitize_text_field( wp_unslash( $_POST['rzd_ph_time'] ) ) : '',
		'town' => isset( $_POST['rzd_ph_town'] ) ? sanitize_text_field( wp_unslash( $_POST['rzd_ph_town'] ) ) : '',
		'ship' => ! empty( $_POST['rzd_ph_ship'] ),
		'sets' => ! empty( $_POST['rzd_ph_sets'] ),
	) );
}

/**
 * Ustawia termin zamówienia z panelu. $in: mode delivery|pickup, date Y-m-d ('' = bez zmian terminu),
 * time HH:MM, town, ship (pozycja dostawy + suma), sets (skład zestawów). Zwraca opis zmiany albo ''.
 */
function rzd_phone_apply( $order, $in ) {
	$pk   = 'pickup' === $in['mode'];
	$date = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $in['date'] ) ? $in['date'] : '';
	$time = function_exists( 'rzd_clean_time' ) ? rzd_clean_time( (string) $in['time'] ) : '';
	$old  = function_exists( 'rzd_dc_order_slot_label' ) ? rzd_dc_order_slot_label( $order ) : '';
	if ( '' === $date ) { // bez zmiany terminu – może zmienić się sposób / miejscowość
		$date = (string) $order->get_meta( '_dc_delivery_date' );
		$time = (string) $order->get_meta( '_dc_delivery_time' );
	}
	if ( $date && $time ) {
		$order->update_meta_data( '_dc_delivery_date', $date );
		$order->update_meta_data( '_dc_delivery_time', $time );
	}
	$row = null;
	if ( $pk ) {
		$order->update_meta_data( '_rzd_pickup', '1' );
		$order->update_meta_data( '_rzd_points', 0 );
		$order->delete_meta_data( '_rzd_town' );
	} else {
		$order->delete_meta_data( '_rzd_pickup' );
		$row = ( '' !== $in['town'] && function_exists( 'rzd_town_find' ) ) ? rzd_town_find( $in['town'] ) : null;
		if ( $row ) {
			$order->update_meta_data( '_rzd_town', $row['name'] );
			$order->update_meta_data( '_rzd_points', rzd_town_points( $row ) );
		}
	}
	if ( 'admin' === $order->get_created_via() && ! $order->get_meta( '_rzd_channel' ) ) {
		$order->update_meta_data( '_rzd_channel', 'phone' );
	}
	// skład zestawów na ten dzień (pozycje dodane w panelu nie mają „W zestawie”)
	if ( ! empty( $in['sets'] ) && $date && function_exists( 'rzd_zestaw_is_set_product' ) && function_exists( 'rzd_zestaw_get_active_components' ) ) {
		foreach ( $order->get_items() as $item ) {
			$pid = (int) $item->get_product_id();
			if ( ! $pid || ! rzd_zestaw_is_set_product( $pid ) || $item->get_meta( 'W zestawie' ) ) {
				continue;
			}
			$active = rzd_zestaw_get_active_components( $pid, $date );
			$mains  = array_values( array_filter( (array) $active['main'], function ( $p ) use ( $pid ) { return (int) $p->get_id() !== $pid; } ) );
			if ( $mains ) {
				$item->add_meta_data( 'W zestawie', implode( ', ', array_map( function ( $p ) { return $p->get_name(); }, $mains ) ), true );
				$item->add_meta_data( '_rwz_component_ids', array_map( function ( $p ) { return (int) $p->get_id(); }, $mains ), true );
				$item->save();
			}
		}
	}
	// pozycja dostawy jak w kasie
	if ( ! empty( $in['ship'] ) && ( $pk || $row ) ) {
		foreach ( $order->get_items( 'shipping' ) as $sid => $s ) {
			$order->remove_item( $sid );
		}
		$ship = new WC_Order_Item_Shipping();
		if ( $pk ) {
			$ship->set_props( array( 'method_title' => 'Odbiór osobisty', 'method_id' => 'rzd_pickup', 'total' => 0 ) );
		} else {
			$st = rzd_town_status_for( $row, rzd_phone_order_value( $order ) );
			$ship->set_props( array( 'method_title' => 'Dostawa – ' . $row['name'] . ( $st['cost_now'] > 0 ? '' : ' (gratis)' ), 'method_id' => 'rzd_town', 'total' => wc_format_decimal( $st['cost_now'] ) ) );
		}
		$order->add_item( $ship );
		$order->calculate_totals( wc_tax_enabled() );
	}
	$order->save();
	if ( function_exists( 'rzd_dc_orders_maps_flush' ) ) {
		rzd_dc_orders_maps_flush();
	}
	$new = function_exists( 'rzd_dc_order_slot_label' ) ? rzd_dc_order_slot_label( $order ) : '';
	if ( $new && $new !== $old ) {
		$who = wp_get_current_user()->display_name;
		$order->add_order_note( ( $old ? 'Zmiana terminu w panelu (' . $who . '): ' . $new . ' (poprzednio ' . $old . ').' : 'Termin ustawiony w panelu (' . $who . '): ' . $new . '.' ) );
		return $new;
	}
	return '';
}
