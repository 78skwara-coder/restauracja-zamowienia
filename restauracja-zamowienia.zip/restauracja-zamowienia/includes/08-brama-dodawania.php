<?php
/**
 * MODUŁ 08: Brama dodawania do koszyka
 *
 * Przechwytuje kliknięcie "Dodaj do koszyka" i przed dodaniem uruchamia
 * kolejne KROKI zgłoszone przez inne moduły:
 *   krok 10 – moduł 06 (DeliveryCalendar): wybór terminu dostawy / kontrola zgodności
 *   krok 20 – moduł 04 (zestawy): wybór dodatków do produktu
 * Dopiero po przejściu wszystkich kroków produkt trafia do koszyka.
 *
 * Ten moduł nic nie robi sam z siebie – jest potrzebny, gdy używasz
 * modułu 06 lub dodatków do produktów (moduł 04).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'wp_enqueue_scripts', function () {
	// jako plik (wcześniej w stopce każdej strony). Kolejność kroków
	// i tak ustala window.kcAddSteps (pole „order”), nie kolejność plików.
	wp_enqueue_script( 'rzd-brama', RZD_PLUGIN_URL . 'assets/js/rzd-brama.js', array(), rzd_asset_ver( 'assets/js/rzd-brama.js' ), array( 'in_footer' => true, 'strategy' => 'defer' ) );
} );
