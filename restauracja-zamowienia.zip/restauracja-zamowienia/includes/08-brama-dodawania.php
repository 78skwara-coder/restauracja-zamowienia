<?php
/**
 * SNIPPET 8: Brama dodawania do koszyka
 * Code Snippets → Run everywhere (pomiń pierwszą linię "<?php")
 *
 * Przechwytuje kliknięcie "Dodaj do koszyka" i przed dodaniem uruchamia
 * kolejne KROKI zgłoszone przez inne snippety:
 *   krok 10 – snippet 6 (DeliveryCalendar): wybór terminu dostawy / kontrola zgodności
 *   krok 20 – snippet 4 (zestawy): wybór dodatków do produktu
 * Dopiero po przejściu wszystkich kroków produkt trafia do koszyka.
 *
 * Ten snippet nic nie robi sam z siebie – jest potrzebny, gdy używasz
 * snippetu 6 lub dodatków do produktów (snippet 4).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'wp_enqueue_scripts', function () {
	// 2.26.13: jako plik (wcześniej w stopce każdej strony). Kolejność kroków
	// i tak ustala window.kcAddSteps (pole „order”), nie kolejność plików.
	wp_enqueue_script( 'rzd-brama', RZD_PLUGIN_URL . 'assets/js/rzd-brama.js', array(), rzd_asset_ver( 'assets/js/rzd-brama.js' ), array( 'in_footer' => true, 'strategy' => 'defer' ) );
} );
