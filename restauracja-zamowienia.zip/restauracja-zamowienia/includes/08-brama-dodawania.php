<?php
/**
 * SNIPPET 8: Brama dodawania do koszyka
 * Code Snippets → Run everywhere (pomiń pierwszą linię "<?php")
 *
 * Przechwytuje kliknięcie "Dodaj do koszyka" i przed dodaniem uruchamia
 * kolejne KROKI zgłoszone przez inne snippety:
 *   krok 10 – snippet 6 (DeliveryCalendar): wybór terminu dostawy / kontrola zgodności
 *   krok 20 – snippet 4 (zestawy): wybór dodatków do produktu
 * Dopiero po przejściu wszystkich kroków produkt trafia do koszyka.
 *
 * Ten snippet nic nie robi sam z siebie – jest potrzebny, gdy używasz
 * snippetu 6 lub dodatków do produktów (snippet 4).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'wp_footer', function () {
	if ( is_admin() ) {
		return;
	}
	?>
	<script>
	window.kcAddSteps = window.kcAddSteps || [];
	(function () {
		function runSteps(ctx, done) {
			var steps = (window.kcAddSteps || []).slice().sort(function (a, b) { return a.order - b.order; });
			var i = 0;
			(function next() {
				if (i >= steps.length) { done(); return; }
				var s = steps[i++];
				s.run(ctx, next);
			})();
		}

		// Formularze "Dodaj do koszyka" (lista zamówień, karta produktu)
		document.addEventListener('submit', function (e) {
			var form = e.target;
			if (!form || form.__kcGo || !window.kcAddSteps || !window.kcAddSteps.length) { return; }
			var btn = (e.submitter && e.submitter.name === 'add-to-cart') ? e.submitter : form.querySelector('[name="add-to-cart"]');
			if (!btn) { return; }
			var pid = parseInt(btn.value, 10);
			if (!pid) { return; }
			e.preventDefault();

			var ctx = { pid: pid, form: form, fields: [] };
			runSteps(ctx, function () {
				var old = form.querySelectorAll('input[data-kc-field]');
				for (var i = 0; i < old.length; i++) { old[i].parentNode.removeChild(old[i]); }
				if (!form.querySelector('input[type="hidden"][name="add-to-cart"]')) {
					var h = document.createElement('input');
					h.type = 'hidden'; h.name = 'add-to-cart'; h.value = pid;
					h.setAttribute('data-kc-field', '1');
					form.appendChild(h);
				}
				ctx.fields.forEach(function (f) {
					var x = document.createElement('input');
					x.type = 'hidden'; x.name = f[0]; x.value = f[1];
					x.setAttribute('data-kc-field', '1');
					form.appendChild(x);
				});
				form.__kcGo = true;
				HTMLFormElement.prototype.submit.call(form);
				form.__kcGo = false;
			});
		}, true);

		// Przyciski AJAX "Dodaj do koszyka" (pętle produktów motywu)
		document.addEventListener('click', function (e) {
			var a = e.target && e.target.closest ? e.target.closest('.add_to_cart_button.ajax_add_to_cart') : null;
			if (!a || a.__kcGo || !window.kcAddSteps || !window.kcAddSteps.length) { return; }
			var pid = parseInt(a.getAttribute('data-product_id'), 10);
			if (!pid) { return; }
			e.preventDefault();
			e.stopImmediatePropagation();

			var ctx = { pid: pid, link: a, fields: [] };
			runSteps(ctx, function () {
				a.__kcGo = true;
				a.click();
				a.__kcGo = false;
			});
		}, true);
	})();
	</script>
	<?php
}, 5 );
