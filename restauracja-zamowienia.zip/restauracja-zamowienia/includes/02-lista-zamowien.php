<?php
/**
 * SNIPPET 2: Lista zamówień (shortcode)
 * Code Snippets → Run everywhere (pomiń pierwszą linię "<?php")
 *
 * Użycie: [lista_zamowien]
 *         [lista_zamowien kategoria="Śniadania"]        (nazwa LUB adres/slug kategorii)
 *         [lista_zamowien kategoria="zupy,dania-glowne"] (kilka kategorii po przecinku)
 *         [lista_zamowien kategoria="Zupy" pasek="nie"]  (bez paska z terminem dostawy)
 * Paska z terminem dostawy nie powtarzamy: pojawia się tylko nad pierwszą listą na stronie.
 * Alergeny wyświetla, jeśli aktywny jest snippet 1 – bez niego lista też działa.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function rest_lista_zamowien_html( $atts ) {
	// Domyślnie BEZ paska z terminem dostawy nad listą – jeśli któryś konkretny
	// blok ma go jednak pokazywać, dopisz w shortcodzie: pasek="tak".
	$a = shortcode_atts( [ 'kategoria' => '', 'limit' => -1, 'pasek' => 'nie' ], $atts );
	static $bar_printed = false;
	static $notices_printed = false; // niezależne od paska – komunikaty mają wyjść tylko raz, nawet gdy pasek jest wyłączony

	$args = [
		'post_type'      => 'product',
		'post_status'    => 'publish',
		'posts_per_page' => (int) $a['limit'],
		'orderby'        => 'menu_order title',
		'order'          => 'ASC',
	];
	$term_names = []; // nazwy rozwiązanych kategorii – do nagłówka nad listą
	if ( $a['kategoria'] ) {
		// kategoria może być podana nazwą albo adresem (slug)
		$term_ids = [];
		foreach ( array_map( 'trim', explode( ',', $a['kategoria'] ) ) as $token ) {
			if ( '' === $token ) {
				continue;
			}
			$t = get_term_by( 'name', $token, 'product_cat' );
			if ( ! $t ) {
				$t = get_term_by( 'slug', sanitize_title( $token ), 'product_cat' );
			}
			if ( ! $t ) {
				$t = get_term_by( 'slug', $token, 'product_cat' );
			}
			if ( $t ) {
				$term_ids[]   = (int) $t->term_id;
				$term_names[] = $t->name;
			}
		}
		$args['tax_query'] = [ [
			'taxonomy' => 'product_cat',
			'field'    => 'term_id',
			'terms'    => $term_ids ? $term_ids : [ 0 ], // nieznana kategoria = pusta lista, nie cały sklep
		] ];
	}

	$q = new WP_Query( $args );
	ob_start();

	/**
	 * KRYTYCZNE: bez tego klient nie widzi ŻADNEGO powodu, dla którego coś
	 * nie dodało się do koszyka (niezgodny termin dostawy, niespełniony
	 * wymóg wyboru dodatku itd.) – WooCommerce zapisuje taki komunikat
	 * w tle, ale nasza własna lista nigdy go nie wyświetlała. Efekt:
	 * strona po prostu "nic nie robi", bez wyjaśnienia. Drukujemy
	 * komunikaty tylko raz na stronie, nad pierwszą listą.
	 */
	// WC()->session nie istnieje w kontekście panelu admina/REST API
	// (np. edytor blokowy "podgrzewający" podgląd treści strony w tle) –
	// bez tego warunku wc_notice_count() rzuca fatal error: "Call to a
	// member function get() on null", co potrafiło uniemożliwić otwarcie
	// strony z tym shortcode'em w edytorze.
	if ( function_exists( 'wc_print_notices' ) && function_exists( 'WC' ) && WC()->session && ! $notices_printed && wc_notice_count() ) {
		wc_print_notices();
		$notices_printed = true;
	}

	echo '<div class="rl">';
	if ( function_exists( 'dc_render_bar' ) && 'tak' === strtolower( $a['pasek'] ) && ! $bar_printed ) {
		echo dc_render_bar(); // termin dostawy (snippet 6) – tylko raz na stronie
		$bar_printed = true;
	}
	if ( $term_names ) {
		// Nagłówek kategorii TĄ SAMĄ czcionką co nazwa produktu (.rl-name) –
		// pod paskiem (jeśli jest), nad listą produktów tej kategorii.
		echo '<h2 class="rl-cat-heading">' . esc_html( implode( ' · ', $term_names ) ) . '</h2>';
	}

	// Pasek filtrowania grup: pokazuje się tylko, gdy wśród wyników TEGO
	// wywołania shortcode'u faktycznie jest więcej niż jedna kategoria –
	// przy jednej kategorii nie ma czego wybierać. Na telefonie same nazwy,
	// na komputerze nazwa + zdjęcie kategorii (jeśli WooCommerce je ma).
	$filter_terms  = [];
	$product_cats  = []; // product_id => [term_id, term_id, ...] – do oznaczenia wierszy
	$q_ids_for_cat = wp_list_pluck( $q->posts, 'ID' );
	if ( $q_ids_for_cat ) {
		$terms = wp_get_object_terms( $q_ids_for_cat, 'product_cat' );
		if ( ! is_wp_error( $terms ) ) {
			foreach ( $terms as $t ) {
				$filter_terms[ $t->term_id ] = $t;
			}
		}
		foreach ( $q_ids_for_cat as $pid ) {
			$product_cats[ $pid ] = wp_get_post_terms( $pid, 'product_cat', [ 'fields' => 'ids' ] );
		}
	}
	if ( count( $filter_terms ) > 1 ) {
		usort( $filter_terms, function ( $x, $y ) { return strcasecmp( $x->name, $y->name ); } );
		echo '<div class="rl-cat-filter">';
		echo '<button type="button" class="rl-cat-filter-btn is-active" data-catf="all"><span>Wszystkie</span></button>';
		foreach ( $filter_terms as $t ) {
			$thumb_id = get_term_meta( $t->term_id, 'thumbnail_id', true );
			$img      = $thumb_id ? wp_get_attachment_image( $thumb_id, 'thumbnail' ) : '';
			echo '<button type="button" class="rl-cat-filter-btn" data-catf="' . esc_attr( $t->term_id ) . '">' . $img . '<span>' . esc_html( $t->name ) . '</span></button>';
		}
		echo '</div>';
	}

	while ( $q->have_posts() ) {
		$q->the_post();
		$p = wc_get_product( get_the_ID() );
		if ( ! $p || ! $p->is_visible() ) {
			continue;
		}
		$row_cats = isset( $product_cats[ $p->get_id() ] ) ? implode( ',', $product_cats[ $p->get_id() ] ) : '';
		?>
		<div class="rl2-row" id="rzd-product-<?php echo (int) $p->get_id(); ?>" data-catf="<?php echo esc_attr( $row_cats ); ?>">
			<?php
			$uwaga = apply_filters( 'rest_lista_uwaga', '', $p->get_id() );
			if ( $uwaga ) :
				?>
				<div class="rl2-conflict">
					<span>Zmień datę dostawy, by dodać do koszyka</span>
					<?php echo function_exists( 'dc_conflict_info_icon_html' ) ? dc_conflict_info_icon_html( $p->get_id() ) : ''; ?>
				</div>
			<?php endif; ?>

			<a class="rl-thumb" href="<?php the_permalink(); ?>"><?php
				$rl_img_id = function_exists( 'rwz_get_display_image_id' ) ? rwz_get_display_image_id( $p->get_id() ) : $p->get_image_id();
				echo $rl_img_id ? wp_get_attachment_image( $rl_img_id, 'woocommerce_thumbnail' ) : wc_placeholder_img( 'woocommerce_thumbnail' );
			?></a>
			<a class="rl-name" href="<?php the_permalink(); ?>"><?php
				$raw_title = get_the_title();
				$rl_name   = function_exists( 'rwz_get_display_name' ) ? rwz_get_display_name( $p->get_id(), $raw_title ) : $raw_title;
				// Tylko dla zestawów (nazwa złożona różni się od surowego tytułu
				// produktu) pokazujemy nad nią nazwę nadrzędną, mniejszą czcionką.
				if ( $rl_name !== $raw_title ) {
					echo '<span class="rl-parent-name">' . esc_html( $raw_title ) . '</span><br>';
				}
				echo function_exists( 'rzd_product_name_with_sklad_html' ) ? rzd_product_name_with_sklad_html( $p->get_id(), $rl_name ) : esc_html( $rl_name );
			?></a>
			<div class="rl-price"><?php echo function_exists( 'rzd_price_split_html' ) ? rzd_price_split_html( $p->get_price_html() ) : $p->get_price_html(); // phpcs:ignore – 2.26.6: części ceny do stylowania ?></div>

			<div class="rl2-rest">
				<?php
				// 2.26.0: plakietki widoczne od razu (komputer) + ta sama treść w ramce
				// rozwijanej „Alergeny (N)” (telefon). Który wariant widać – decyduje CSS.
				$rl_alerg = function_exists( 'rest_alergeny_html' ) ? rest_alergeny_html( get_the_ID() ) : '';
				if ( $rl_alerg ) :
					$rl_alerg_n = function_exists( 'rest_alergeny_terms' ) ? count( (array) rest_alergeny_terms( get_the_ID() ) ) : 0;
					$rl_alerg_t = function_exists( 'rzd_list_label' ) ? rzd_list_label( 'allergen' ) : 'Alergeny';
					?>
					<div class="rl2-allergens rl2-allergens-flat"><?php echo $rl_alerg; // phpcs:ignore ?></div>
					<details class="rl2-allergen-box"><summary><?php echo esc_html( $rl_alerg_t . ( $rl_alerg_n ? ' (' . $rl_alerg_n . ')' : '' ) ); ?></summary><div class="rl2-allergens"><?php echo $rl_alerg; // phpcs:ignore ?></div></details>
				<?php endif; ?>

				<?php
				$harmono = apply_filters( 'rest_zestaw_harmonogram', '', $p->get_id() );
				if ( $harmono ) {
					echo $harmono;
				}
				?>

				<?php
				$skladniki = apply_filters( 'rest_zestaw_skladniki', [], $p->get_id() );
				$obowiazkowe = apply_filters( 'rest_produkt_obowiazkowe_dodatki', '', $p->get_id() );
				if ( $skladniki || $obowiazkowe ) :
					?>
					<div class="rl2-mid">
						<?php
						if ( $skladniki ) {
							$linki = [];
							foreach ( $skladniki as $cid ) {
									$linki[] = function_exists( 'rwz_component_link_or_text' ) ? rwz_component_link_or_text( $cid ) : ( '<a href="' . esc_url( get_permalink( $cid ) ) . '">' . esc_html( get_the_title( $cid ) ) . '</a>' );
							}
							echo '<div class="rl-sklad">' . implode( ', ', $linki ) . '</div>';
						}
						if ( $obowiazkowe ) {
							echo '<div class="rl-mandatory">' . $obowiazkowe . '</div>';
						}
						?>
					</div>
				<?php endif; ?>

				<?php if ( function_exists( 'dc_product_schedule_summary_html' ) ) { echo dc_product_schedule_summary_html( $p->get_id() ); } ?>

				<div class="rl2-order">
					<?php if ( $p->is_type( 'simple' ) && $p->is_purchasable() && $p->is_in_stock() ) : ?>
						<form class="rl-buy" method="post">
							<div class="rl2-qty">
								<button type="button" class="rl2-qty-btn rl2-qty-minus" aria-label="Zmniejsz ilość">−</button>
								<input type="number" name="quantity" value="1" min="1" step="1" aria-label="Ilość">
								<button type="button" class="rl2-qty-btn rl2-qty-plus" aria-label="Zwiększ ilość">+</button>
							</div>
							<button type="submit" name="add-to-cart" value="<?php echo esc_attr( $p->get_id() ); ?>">Dodaj do koszyka</button>
						</form>
					<?php else : ?>
						<a class="rl-buy rl-choose" href="<?php the_permalink(); ?>">Wybierz</a>
					<?php endif; ?>
				</div>
			</div>

			<div class="rl2-bottom">
				<?php
				$krotki = $p->get_short_description();
				if ( $krotki ) {
					echo '<div class="rl-short">' . wpautop( wp_kses_post( $krotki ) ) . '</div>';
				}

				$dodatki = apply_filters( 'rest_zestaw_dodatki', [], $p->get_id() );
				if ( $dodatki ) {
					$wiersze = '';
					foreach ( $dodatki as $did ) {
						$d = wc_get_product( $did );
						if ( ! $d || ! $d->is_purchasable() || ! $d->is_in_stock() ) {
							continue;
						}
						ob_start();
						?>
						<form class="rl-buy rl-addon" method="post">
							<div class="rl-addon-name"><a href="<?php echo esc_url( get_permalink( $did ) ); ?>"><?php echo esc_html( $d->get_name() ); ?></a> &mdash; <?php echo $d->get_price_html(); ?>
								<?php
								if ( function_exists( 'rest_alergeny_html' ) ) {
									echo rest_alergeny_html( $did );
								}
								?>
							</div>
							<input type="number" name="quantity" value="1" min="1" step="1" aria-label="Ilość">
							<button type="submit" name="add-to-cart" value="<?php echo esc_attr( $d->get_id() ); ?>">Dodaj</button>
						</form>
						<?php
						$wiersze .= ob_get_clean();
					}
					if ( $wiersze ) {
						echo '<div class="rl-addons"><div class="rl-addons-title">Dodatki:</div>' . $wiersze . '</div>';
					}
				}

				$opis = $p->get_description();
				if ( $opis ) {
					echo '<details class="rl-more"><summary>' . esc_html( function_exists( 'rzd_list_label' ) ? rzd_list_label( 'more' ) : 'Pełny opis' ) . '</summary><div>' . wpautop( wp_kses_post( $opis ) ) . '</div></details>';
				}
				?>
			</div>
		</div>
		<?php
	}
	wp_reset_postdata();

	echo '</div>';
	return ob_get_clean();
}

/**
 * Osłona wokół powyższej funkcji: gdyby cokolwiek w środku (albo w filtrach
 * z innych modułów, np. przy zestawach/harmonogramie) rzuciło ostrzeżenie
 * PHP albo wyjątek, NIE MA to wyciekać na stronę ani psuć odpowiedzi, którą
 * czyta np. edytor blokowy WordPressa przez REST API (stąd błędy przy
 * otwieraniu strony z tym shortcode'em w edytorze). Prawdziwy błąd nadal
 * trafia do logu (gdy WP_DEBUG_LOG jest włączone), tylko nie jest wyświetlany.
 */
add_shortcode( 'lista_zamowien', function ( $atts ) {
	$prev_display = ini_get( 'display_errors' );
	@ini_set( 'display_errors', '0' );
	$prev_handler = set_error_handler( function ( $errno, $errstr, $errfile, $errline ) {
		if ( defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG ) {
			error_log( '[lista_zamowien] ' . $errstr . ' w ' . $errfile . ':' . $errline );
		}
		return true; // "obsłużone" – nie pokazuj na stronie/w odpowiedzi REST
	} );

	try {
		$html = rest_lista_zamowien_html( $atts );
	} catch ( \Throwable $e ) {
		if ( defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG ) {
			error_log( '[lista_zamowien] wyjątek: ' . $e->getMessage() . ' w ' . $e->getFile() . ':' . $e->getLine() );
		}
		$html = '<p>Nie udało się wczytać listy produktów. Spróbuj odświeżyć stronę.</p>';
	}

	if ( $prev_handler ) {
		set_error_handler( $prev_handler );
	} else {
		restore_error_handler();
	}
	ini_set( 'display_errors', $prev_display );

	return $html;
} );

// Przyciski +/- przy ilości na liście – jeden wspólny skrypt w stopce,
// niezależnie od tego, ile razy shortcode [lista_zamowien] wystąpi na stronie.
add_action( 'wp_footer', function () {
	static $done = false;
	if ( $done || is_admin() ) {
		return;
	}
	$done = true;
	?>
	<script>
	document.addEventListener('click', function (e) {
		var btn = e.target.closest ? e.target.closest('.rl2-qty-btn') : null;
		if (!btn) { return; }
		var input = btn.parentNode.querySelector('input[type=number]');
		if (!input) { return; }
		var min = parseInt(input.getAttribute('min'), 10) || 1;
		var val = parseInt(input.value, 10) || min;
		val = btn.classList.contains('rl2-qty-plus') ? val + 1 : Math.max(min, val - 1);
		input.value = val;
		input.dispatchEvent(new Event('change', { bubbles: true }));
	});

	// Powrót "wstecz" ze strony produktu → przewiń z powrotem do TEGO produktu
	// na liście, zamiast zostawiać klienta na samej górze. Zapamiętujemy, w
	// który produkt kliknięto (dowolny link z wiersza prowadzący na jego
	// stronę – zdjęcie, nazwa albo "Wybierz"), i przy KAŻDYM wejściu na listę
	// sprawdzamy, czy coś jest zapisane – jeśli tak, przewijamy i od razu
	// kasujemy zapis, żeby nie przewijało ponownie przy zwykłej wizycie.
	document.addEventListener('click', function (e) {
		var link = e.target.closest ? e.target.closest('.rl2-row a.rl-thumb, .rl2-row a.rl-name, .rl2-row a.rl-choose') : null;
		if (!link) { return; }
		var row = link.closest('.rl2-row');
		if (row && row.id) {
			try { sessionStorage.setItem('rzd_last_product', row.id); } catch (err) {}
		}
	});
	(function () {
		var lastId;
		try {
			lastId = sessionStorage.getItem('rzd_last_product');
			sessionStorage.removeItem('rzd_last_product');
		} catch (err) { return; }
		if (!lastId) { return; }
		var el = document.getElementById(lastId);
		if (!el) { return; }
		window.requestAnimationFrame(function () {
			window.requestAnimationFrame(function () { el.scrollIntoView( { block: 'center' } ); });
		});
	})();
	// Każdy filtr działa TYLKO w obrębie swojego własnego kontenera ".rl"
	// (jedno wywołanie shortcode'u), więc kilka list na jednej stronie się nie miesza.
	document.addEventListener('click', function (e) {
		var fbtn = e.target.closest ? e.target.closest('.rl-cat-filter-btn') : null;
		if (!fbtn) { return; }
		var wrap = fbtn.closest('.rl');
		if (!wrap) { return; }
		wrap.querySelectorAll('.rl-cat-filter-btn').forEach(function (b) { b.classList.remove('is-active'); });
		fbtn.classList.add('is-active');
		var cat = fbtn.getAttribute('data-catf');
		wrap.querySelectorAll('.rl2-row').forEach(function (row) {
			if ('all' === cat) { row.style.display = ''; return; }
			var cats = (row.getAttribute('data-catf') || '').split(',');
			row.style.display = cats.indexOf(cat) > -1 ? '' : 'none';
		});
	});
	</script>
	<?php
} );
