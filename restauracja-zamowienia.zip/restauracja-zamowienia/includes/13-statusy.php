<?php
/**
 * MODUŁ 13: Własne statusy zamówień — kuchnia i dostawa
 *
 * Dodaje pięć własnych statusów zamówienia: Przyjęte, W przygotowaniu,
 * Gotowe, W dostawie, Wydane. Zarządza się nimi:
 *  - tak jak dotąd: WooCommerce → Zamówienia (rozwijana lista przy
 *    zamówieniu, oraz "Działania zbiorcze" na liście wszystkich zamówień),
 *  - albo "odklikując" je w module 12 (Kuchnia), w widoku "Zamówienia" –
 *    każda karta zamówienia ma rząd przycisków ze statusami, kliknięcie
 *    ustawia status od razu, bez przeładowania strony.
 *
 * Rejestracja statusu w WooCommerce to standardowy mechanizm WordPressa
 * (register_post_status) + dopisanie do listy, którą WooCommerce pokazuje
 * w panelu (filtr "wc_order_statuses").
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Lista naszych statusów: slug (bez prefiksu "wc-") => etykieta widoczna
 * w panelu i w dashboardzie kuchni. Kolejność = kolejność przycisków
 * w dashboardzie i pozycja w rozwijanej liście WooCommerce.
 */
// UWAGA: same pięć identyfikatorów (slugów) statusu co dotąd – zmieniają
// się tylko ETYKIETY i to, KTO/KIEDY je nadaje (moduł 12), żeby nie trzeba
// było migrować już zapisanych zamówień. Nowy przepływ:
//   przyjete → w-przygotowaniu (samo, po zamknięciu cutoffu) →
//   gotowe "Przygotowane" (kuchnia, zbiorczo) →
//   w-dostawie "Spakowane" (pakowanie, pojedynczo) →
//   wydane "Dostarczone" (kurier, z datą dostarczenia)
function rzd_kitchen_statuses() {
	return array(
		'przyjete'        => 'Przyjęte',
		'w-przygotowaniu' => 'W przygotowaniu',
		'gotowe'          => 'Przygotowane',
		'w-dostawie'      => 'Spakowane',
		'wydane'          => 'Dostarczone',
	);
}

add_action( 'init', function () {
	foreach ( rzd_kitchen_statuses() as $slug => $label ) {
		register_post_status( 'wc-' . $slug, array(
			'label'                     => $label,
			'public'                    => true,
			'exclude_from_search'       => false,
			'show_in_admin_all_list'    => true,
			'show_in_admin_status_list' => true,
			// translators: %s: liczba zamówień w tym statusie.
			'label_count'               => _n_noop( $label . ' <span class="count">(%s)</span>', $label . ' <span class="count">(%s)</span>' ),
		) );
	}
} );

// Dopisanie statusów do listy, z której WooCommerce buduje rozwijaną listę
// przy zamówieniu i "Działania zbiorcze" – wstawiamy je zaraz po "Przetwarzanie".
add_filter( 'wc_order_statuses', function ( $statuses ) {
	$ours = rzd_kitchen_statuses();
	$new  = array();
	$done = false;
	foreach ( $statuses as $key => $label ) {
		$new[ $key ] = $label;
		if ( 'wc-processing' === $key ) {
			foreach ( $ours as $slug => $klabel ) {
				$new[ 'wc-' . $slug ] = $klabel;
			}
			$done = true;
		}
	}
	if ( ! $done ) { // gdyby z jakiegoś powodu "wc-processing" nie było na liście
		foreach ( $ours as $slug => $klabel ) {
			$new[ 'wc-' . $slug ] = $klabel;
		}
	}
	return $new;
} );

/**
 * Sprawdzenie dostępu dla endpointów AJAX poniżej: zalogowane konto z choć jedną
 * zakładką Kuchni (2.30.0: konfigurator uprawnień – moduły 25/26) + konkretne
 * uprawnienie akcji (rzd_need). Kurier – tylko „Dostarczone” w kuchnia_set_status.
 * Każdy endpoint sprawdza też nonce (rzd_kitchen_check_nonce).
 */
function rzd_kitchen_authed() {
	return function_exists( 'rzd_kuchnia_frontend_authed' ) && rzd_kuchnia_frontend_authed();
}

/* ============================================================
 * Zamówienia opłacone przez WooCommerce = nasze statusy TEŻ się liczą.
 * Bez tego np. $order->is_paid() zwracałoby false dla zamówienia w
 * statusie "Gotowe", mimo że zapłata już dawno przeszła.
 * ============================================================ */
add_filter( 'woocommerce_order_is_paid_statuses', function ( $statuses ) {
	foreach ( array_keys( rzd_kitchen_statuses() ) as $slug ) {
		$statuses[] = $slug;
	}
	return array_values( array_unique( $statuses ) );
} );

/* ============================================================
 * Pojedynczy status (Kuchnia: "Przygotowane" → gotowe; Pakowanie:
 * "Spakowane" → w-dostawie; Kurier: "Dostarczone" → wydane)
 * ============================================================ */
add_action( 'wc_ajax_kuchnia_set_status', function () {
	rzd_kitchen_check_nonce(); // moduł 25 (CSRF)
	// każdy status ma swoje uprawnienie (konfigurator – moduł 26):
	//  „Przygotowane” (gotowe) – Kuchnia albo Pakowanie, „Spakowane” (w-dostawie) – Pakowanie,
	//  „Dostarczone” (wydane) – Kurier (konto albo awaryjny PIN; tylko zamówienie już Spakowane),
	//  każdy inny – „Nowy termin i anulowanie”.
	$order_id = isset( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0;
	$status   = isset( $_POST['status'] ) ? sanitize_key( $_POST['status'] ) : '';
	$courier  = 'wydane' === $status && function_exists( 'rzd_kurier_frontend_authed' ) && rzd_kurier_frontend_authed();
	if ( 'gotowe' === $status ) {
		$allowed = rzd_can( 'kitchen' ) || rzd_can( 'packing' );
	} elseif ( 'w-dostawie' === $status ) {
		$allowed = rzd_can( 'packing' );
	} elseif ( 'wydane' === $status ) {
		$pk_order = $order_id && function_exists( 'rzd_order_is_pickup' ) ? wc_get_order( $order_id ) : null;
		$pk       = $pk_order && rzd_order_is_pickup( $pk_order );
		// odbiór osobisty – „Odebrane” w Pakowaniu (nie kurier); dostawa – kurier
		$allowed  = rzd_can( 'change' ) || ( $pk ? rzd_can( 'packing' ) : $courier );
	} else {
		$allowed = rzd_can( 'change' );
	}
	if ( ! $allowed ) {
		wp_send_json( array( 'ok' => false, 'message' => 'Brak uprawnienia do tej zmiany statusu.' ), 403 );
	}
	if ( ! $order_id || ! array_key_exists( $status, rzd_kitchen_statuses() ) ) {
		wp_send_json( array( 'ok' => false, 'message' => 'Nieprawidłowe dane.' ) );
	}
	$order = wc_get_order( $order_id );
	if ( ! $order ) {
		wp_send_json( array( 'ok' => false, 'message' => 'Nie znaleziono zamówienia.' ) );
	}
	if ( 'wydane' === $status && ! rzd_can( 'change' ) && 'w-dostawie' !== $order->get_status() ) {
		wp_send_json( array( 'ok' => false, 'message' => 'Zamówienie nie jest jeszcze spakowane.' ) );
	}
	$from = $order->get_status();
	$prev_delivered = (string) $order->get_meta( '_dc_delivered_at' );
	if ( 'wydane' === $status ) {
		// Data i godzina dostarczenia – widoczna potem w widoku kuriera (moduł 19).
		$order->update_meta_data( '_dc_delivered_at', current_time( 'Y-m-d H:i' ) );
	}
	// „Cofnij” (2.39.0): ostatnia zmiana z przycisku – kto, z czego, kiedy. Tylko konto (PIN awaryjny nie ma kogo sprawdzić).
	$undo = is_user_logged_in() && $from !== $status;
	if ( $undo ) {
		$order->update_meta_data( '_rzd_last_change', array( 'from' => $from, 'to' => $status, 'user' => get_current_user_id(), 'ts' => time(), 'delivered' => $prev_delivered ) );
	} else {
		$order->delete_meta_data( '_rzd_last_change' );
	}
	$order->save();
	// kto zmienił status – w notatce zamówienia (konto albo „kurier (PIN awaryjny)”).
	$who = is_user_logged_in() ? wp_get_current_user()->display_name : 'kurier (PIN awaryjny)';
	$label = rzd_kitchen_statuses()[ $status ];
	if ( function_exists( 'rzd_order_is_pickup' ) && rzd_order_is_pickup( $order ) && isset( rzd_pickup_status_labels()[ $status ] ) ) {
		$label = rzd_pickup_status_labels()[ $status ];
	}
	$order->update_status( $status, sprintf( '%s – oznaczył(a): %s.', $label, $who ) );
	wp_send_json( array( 'ok' => true, 'status' => $status, 'label' => $label, 'undo' => $undo ? rzd_status_undo_seconds() : 0, 'number' => (string) $order->get_order_number() ) );
} );

/* ============================================================
 * KOREKTA STATUSU i COFNIJ (2.39.0)
 * Korekta: uprawnienie „Korekta statusu” (moduł 25), dowolny z pięciu statusów
 * Kuchni, powód opcjonalny – wpis w notatce zamówienia (ślad: kto, z czego, na co).
 * Nie wysyła maili do klienta (żaden z tych statusów maila nie wysyła; maile
 * idą tylko przy „Zaplanowane” i „Nowy termin”). Znacznik `_rzd_status_manual`
 * – automat „Auto przygotowanie” nie przepycha takiego zamówienia z powrotem.
 * Cofnij: ta sama osoba, ten sam przycisk, kilka sekund – bez uprawnienia korekty.
 * ============================================================ */
function rzd_status_undo_seconds() {
	return 10; // pasek na ekranie; serwer przyjmuje jeszcze chwilę dłużej (opóźnienie sieci)
}

/** Statusy, z których wolno korygować: pięć statusów Kuchni + natywne „czekające” WooCommerce. */
function rzd_status_correctable( $order ) {
	return in_array( $order->get_status(), array_merge( array_keys( rzd_kitchen_statuses() ), array( 'processing', 'on-hold' ) ), true );
}

/** Zamówienie w zasięgu Historii użytkownika (limit dni roli – moduł 25). Przyszłe – zawsze. */
function rzd_order_in_history_cap( $order, $user = null ) {
	$cap = function_exists( 'rzd_history_days_cap' ) ? rzd_history_days_cap( $user ) : null;
	if ( null === $cap ) {
		return true;
	}
	$d = (string) $order->get_meta( '_dc_delivery_date' );
	if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $d ) ) {
		return true; // bez daty dostawy – nie ma czego liczyć (zakładka Zamówienia i tak je pokazuje)
	}
	$from = new DateTime( current_time( 'Y-m-d' ), wp_timezone() );
	$from->modify( '-' . (int) $cap . ' days' );
	return $d >= $from->format( 'Y-m-d' );
}

/** Czy zalogowany może poprawić status tego zamówienia (przycisk ✎ i serwer – te same warunki). */
function rzd_status_can_correct( $order ) {
	return rzd_can( 'status' ) && rzd_status_correctable( $order ) && rzd_order_in_history_cap( $order );
}

/** Zmiana statusu „poza przyciskami” – wspólne dla korekty i cofnięcia. */
function rzd_status_apply( $order, $to, $note, $delivered = null ) {
	$from = $order->get_status();
	if ( 'wydane' === $to ) {
		$order->update_meta_data( '_dc_delivered_at', null !== $delivered && '' !== $delivered ? $delivered : current_time( 'Y-m-d H:i' ) );
	} elseif ( 'wydane' === $from ) {
		// z „Dostarczone” z powrotem – zamówienie wraca do kuriera, data dostarczenia znika
		if ( null !== $delivered && '' !== $delivered ) {
			$order->update_meta_data( '_dc_delivered_at', $delivered );
		} else {
			$order->delete_meta_data( '_dc_delivered_at' );
		}
	}
	$order->delete_meta_data( '_rzd_last_change' );
	$order->save();
	$order->update_status( $to, $note );
}

add_action( 'wc_ajax_kuchnia_correct_status', function () {
	rzd_kitchen_check_nonce(); // moduł 25 (CSRF)
	rzd_need( 'status' );
	$order_id = isset( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0;
	$status   = isset( $_POST['status'] ) ? sanitize_key( $_POST['status'] ) : '';
	$reason   = isset( $_POST['reason'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['reason'] ) ) ) : '';
	$reason   = function_exists( 'mb_substr' ) ? mb_substr( $reason, 0, 200 ) : substr( $reason, 0, 200 );
	$order    = $order_id ? wc_get_order( $order_id ) : null;
	if ( ! $order || ! array_key_exists( $status, rzd_kitchen_statuses() ) ) {
		wp_send_json( array( 'ok' => false, 'message' => 'Nieprawidłowe dane.' ) );
	}
	if ( ! rzd_status_correctable( $order ) ) {
		wp_send_json( array( 'ok' => false, 'message' => 'Tego zamówienia nie można poprawić w Kuchni (status: ' . wc_get_order_status_name( $order->get_status() ) . ').' ) );
	}
	if ( ! rzd_order_in_history_cap( $order ) ) {
		wp_send_json( array( 'ok' => false, 'message' => 'To zamówienie jest starsze niż zakres Historii dla Twojej roli.' ), 403 );
	}
	$from = $order->get_status();
	if ( $from === $status ) {
		wp_send_json( array( 'ok' => false, 'message' => 'Zamówienie ma już ten status.' ) );
	}
	$labels = rzd_kitchen_statuses();
	$fl     = isset( $labels[ $from ] ) ? $labels[ $from ] : wc_get_order_status_name( $from );
	$note   = sprintf( 'Korekta statusu: %s → %s – zmienił(a): %s.', $fl, $labels[ $status ], wp_get_current_user()->display_name ) . ( '' !== $reason ? ' Powód: ' . $reason : '' );
	$order->update_meta_data( '_rzd_status_manual', time() );
	rzd_status_apply( $order, $status, $note );
	wp_send_json( array( 'ok' => true, 'status' => $status, 'label' => $labels[ $status ] ) );
} );

add_action( 'wc_ajax_kuchnia_undo_status', function () {
	rzd_kitchen_check_nonce(); // moduł 25 (CSRF)
	$order_id = isset( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0;
	$order    = $order_id ? wc_get_order( $order_id ) : null;
	$last     = $order ? $order->get_meta( '_rzd_last_change' ) : null;
	if ( ! is_user_logged_in() || ! $order || ! is_array( $last ) ) {
		wp_send_json( array( 'ok' => false, 'message' => 'Nie ma czego cofnąć.' ) );
	}
	if ( (int) $last['user'] !== get_current_user_id() || $order->get_status() !== $last['to'] || time() - (int) $last['ts'] > rzd_status_undo_seconds() + 20 ) {
		wp_send_json( array( 'ok' => false, 'message' => 'Za późno na cofnięcie – poproś kierownika o korektę statusu.' ) );
	}
	$labels = rzd_kitchen_statuses();
	$fl     = isset( $labels[ $last['from'] ] ) ? $labels[ $last['from'] ] : wc_get_order_status_name( $last['from'] );
	$tl     = isset( $labels[ $last['to'] ] ) ? $labels[ $last['to'] ] : $last['to'];
	rzd_status_apply( $order, $last['from'], sprintf( 'Cofnięto: %s → %s – %s.', $tl, $fl, wp_get_current_user()->display_name ), isset( $last['delivered'] ) ? (string) $last['delivered'] : '' );
	wp_send_json( array( 'ok' => true, 'status' => $last['from'], 'label' => $fl ) );
} );

/* ============================================================
 * Zbiorczo: "Oznacz cały termin jako W przygotowaniu" (zakładka Kuchnia)
 * ============================================================ */
add_action( 'wc_ajax_kuchnia_bulk_status', function () {
	rzd_kitchen_check_nonce(); // moduł 25 (CSRF)
	rzd_need( 'kitchen' ); // uprawnienie z konfiguratora
	if ( ! rzd_kitchen_authed() ) {
		wp_send_json( array( 'ok' => false, 'message' => 'Brak dostępu.' ), 403 );
	}
	$date   = isset( $_POST['date'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $_POST['date'] ) ? $_POST['date'] : '';
	$time   = isset( $_POST['time'] ) ? sanitize_text_field( $_POST['time'] ) : '';
	$status = isset( $_POST['status'] ) ? sanitize_key( $_POST['status'] ) : '';
	if ( $date && function_exists( 'rzd_kitchen_date_allowed' ) && ! rzd_kitchen_date_allowed( $date ) ) {
		wp_send_json( array( 'ok' => false, 'message' => 'Ten dzień jest poza Twoim zakresem. ' . rzd_kitchen_date_cap_text() ) );
	}
	if ( ! $date || ! $time || ! array_key_exists( $status, rzd_kitchen_statuses() ) || ! function_exists( 'rzd_kuchnia_orders_for_slot' ) ) {
		wp_send_json( array( 'ok' => false, 'message' => 'Nieprawidłowe dane.' ) );
	}
	// Tylko DO PRZODU w przepływie: pakować można, zanim kuchnia
	// oznaczy termin, więc zbiorcze "Przygotowane" nie może cofnąć zamówień
	// już Spakowanych/Dostarczonych (ani ruszyć tych już Przygotowanych).
	$flow   = array_keys( rzd_kitchen_statuses() );
	$target = array_search( $status, $flow, true );
	$n      = 0;
	foreach ( rzd_kuchnia_orders_for_slot( $date, $time ) as $order ) {
		$cur = array_search( $order->get_status(), $flow, true );
		if ( false !== $cur && $cur >= $target ) {
			continue;
		}
		$order->update_status( $status );
		$n++;
	}
	wp_send_json( array( 'ok' => true, 'updated' => $n, 'label' => rzd_kitchen_statuses()[ $status ] ) );
} );

/* ============================================================
 * Anulowanie zamówienia (zakładka Zamówienia, z potwierdzeniem po
 * stronie klienta w JS – tu tylko wykonujemy samą zmianę statusu).
 * Nie obsługuje automatycznie zwrotu pieniędzy – to zależy od Twojej
 * polityki zwrotów i bramki płatności, robisz to osobno, ręcznie.
 * ============================================================ */
add_action( 'wc_ajax_kuchnia_cancel_order', function () {
	rzd_kitchen_check_nonce(); // moduł 25 (CSRF)
	rzd_need( 'change' ); // uprawnienie z konfiguratora
	if ( ! rzd_kitchen_authed() ) {
		wp_send_json( array( 'ok' => false, 'message' => 'Brak dostępu.' ), 403 );
	}
	$order_id = isset( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0;
	$order    = $order_id ? wc_get_order( $order_id ) : null;
	if ( ! $order ) {
		wp_send_json( array( 'ok' => false, 'message' => 'Nie znaleziono zamówienia.' ) );
	}
	// Dostarczonego (ani już anulowanego) nie anulujemy – tylko przez panel WooCommerce.
	if ( in_array( $order->get_status(), array( 'wydane', 'completed', 'cancelled' ), true ) ) {
		wp_send_json( array( 'ok' => false, 'message' => 'Tego zamówienia nie można już anulować – zostało dostarczone.' ) );
	}
	$order->update_status( 'cancelled', 'Anulowane z dashboardu kuchni – ' . wp_get_current_user()->display_name . '.' ); // kto
	wp_send_json( array( 'ok' => true ) );
} );

/* ============================================================
 * Planowanie dostawy: kolejność + konkretna godzina (zakładka Planowanie,
 * widoczne potem w widoku kuriera, moduł 19).
 * ============================================================ */
add_action( 'wc_ajax_kuchnia_set_planning', function () {
	rzd_kitchen_check_nonce(); // moduł 25 (CSRF)
	rzd_need( 'planning' ); // uprawnienie z konfiguratora
	if ( ! rzd_kitchen_authed() ) {
		wp_send_json( array( 'ok' => false, 'message' => 'Brak dostępu.' ), 403 );
	}
	$order_id = isset( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0;
	$order    = $order_id ? wc_get_order( $order_id ) : null;
	if ( ! $order ) {
		wp_send_json( array( 'ok' => false, 'message' => 'Nie znaleziono zamówienia.' ) );
	}
	// Plan zatwierdzony ("Zaplanowane") jest zablokowany do edycji – ktoś
	// mógłby ominąć wyłączone pole w przeglądarce, więc sprawdzamy to też
	// tutaj, nie tylko wizualnie w HTML.
	if ( function_exists( 'rzd_kuchnia_is_planning_locked' ) ) {
		$o_date = $order->get_meta( '_dc_delivery_date' );
		$o_time = $order->get_meta( '_dc_delivery_time' );
		if ( rzd_kuchnia_is_planning_locked( $o_date, $o_time ? $o_time : '—' ) ) {
			wp_send_json( array( 'ok' => false, 'message' => 'Plan tego terminu jest zatwierdzony. Kliknij „Edytuj", żeby coś zmienić.' ) );
		}
	}
	$sequence = isset( $_POST['sequence'] ) ? absint( $_POST['sequence'] ) : 0;
	$time     = isset( $_POST['planned_time'] ) ? sanitize_text_field( wp_unslash( $_POST['planned_time'] ) ) : '';
	if ( $time && ! preg_match( '/^([01]\d|2[0-3]):[0-5]\d$/', $time ) ) {
		$time = '';
	}
	// Tryb okien: godzina musi być wolnym slotem siatki okna – dwie
	// osoby planujące naraz nie wstawią dwóch zamówień w to samo miejsce.
	if ( $time && function_exists( 'rzd_dc_plan_grid' ) && function_exists( 'rzd_kuchnia_orders_for_slot' ) ) {
		$s_date = (string) $order->get_meta( '_dc_delivery_date' );
		$s_time = (string) $order->get_meta( '_dc_delivery_time' );
		$grid   = rzd_dc_plan_grid( $s_date, $s_time, rzd_kuchnia_orders_for_slot( $s_date, $s_time ), $order->get_id() );
		$free   = $grid ? rzd_dc_plan_options( $grid, $order ) : array();
		if ( $grid && ! isset( $free[ $time ] ) ) {
			wp_send_json( array( 'ok' => false, 'message' => 'Godzina ' . $time . ' jest już zajęta albo nie mieści tego zamówienia (' . rzd_dc_order_points( $order ) . ' pkt). Wybierz inną z listy.' ) );
		}
	}
	if ( $sequence ) {
		$order->update_meta_data( '_dc_delivery_sequence', $sequence );
	} else {
		$order->delete_meta_data( '_dc_delivery_sequence' );
	}
	if ( $time ) {
		$order->update_meta_data( '_dc_planned_time', $time );
	} else {
		$order->delete_meta_data( '_dc_planned_time' );
	}
	$order->save();
	wp_send_json( array( 'ok' => true ) );
} );

/**
 * "Zaplanowane": sprawdza CAŁY termin (świeże dane z bazy, nie to, co akurat
 * jest w polach na ekranie) pod kątem dwóch rzeczy: tej samej kolejności
 * użytej dwa razy i tej samej godziny dostawy użytej dwa razy. Bez błędów –
 * zamraża plan (moduł 12 wtedy renderuje pola jako disabled).
 */
add_action( 'wc_ajax_kuchnia_confirm_planning', function () {
	rzd_kitchen_check_nonce(); // moduł 25 (CSRF)
	rzd_need( 'planning' ); // uprawnienie z konfiguratora
	if ( ! rzd_kitchen_authed() ) {
		wp_send_json( array( 'ok' => false, 'message' => 'Brak dostępu.' ), 403 );
	}
	$date = isset( $_POST['date'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $_POST['date'] ) ? $_POST['date'] : '';
	$time = isset( $_POST['time'] ) ? sanitize_text_field( wp_unslash( $_POST['time'] ) ) : '';
	if ( $date && function_exists( 'rzd_kitchen_date_allowed' ) && ! rzd_kitchen_date_allowed( $date ) ) {
		wp_send_json( array( 'ok' => false, 'message' => 'Ten dzień jest poza Twoim zakresem. ' . rzd_kitchen_date_cap_text() ) );
	}
	if ( ! $date || ! function_exists( 'rzd_kuchnia_orders_for_slot_pipeline' ) || ! function_exists( 'rzd_kuchnia_planning_lock_key' ) ) {
		wp_send_json( array( 'ok' => false, 'message' => 'Nieprawidłowe dane.' ) );
	}
	$orders = rzd_kuchnia_orders_for_slot_pipeline( $date, $time ? $time : '—' );

	$by_seq  = array();
	$by_time = array();
	foreach ( $orders as $o ) {
		$seq = (int) $o->get_meta( '_dc_delivery_sequence' );
		$pt  = $o->get_meta( '_dc_planned_time' );
		if ( $seq ) {
			$by_seq[ $seq ][] = $o->get_order_number();
		}
		if ( $pt ) {
			$by_time[ $pt ][] = $o->get_order_number();
		}
	}

	$problems = array();
	foreach ( $by_seq as $seq => $numbers ) {
		if ( count( $numbers ) > 1 ) {
			$problems[] = 'kolejność ' . $seq . ' powtarza się w zamówieniach #' . implode( ', #', $numbers );
		}
	}
	foreach ( $by_time as $t => $numbers ) {
		if ( count( $numbers ) > 1 ) {
			$problems[] = 'godzina ' . $t . ' powtarza się w zamówieniach #' . implode( ', #', $numbers );
		}
	}

	// Tryb okien: nakładające się zamówienia wielopunktowe i godziny spoza siatki.
	if ( function_exists( 'rzd_dc_plan_grid' ) && function_exists( 'rzd_kuchnia_orders_for_slot' ) ) {
		$grid = rzd_dc_plan_grid( $date, $time, rzd_kuchnia_orders_for_slot( $date, $time ? $time : '—' ) );
		if ( $grid ) {
			foreach ( $grid['conflicts'] as $c ) {
				$problems[] = $c;
			}
			if ( $grid['offgrid'] ) {
				$problems[] = 'godzina spoza siatki okna w zamówieniach #' . implode( ', #', $grid['offgrid'] ) . ' (wybierz ją z listy od nowa)';
			}
		}
	}

	if ( $problems ) {
		wp_send_json( array(
			'ok'      => false,
			'message' => 'Są błędy w planowaniu: ' . implode( '; ', $problems ) . '. Popraw i zaplanuj ponownie.',
		) );
	}

	update_option( rzd_kuchnia_planning_lock_key( $date, $time ), 1, false );

	// Mail do klientów z godziną dostawy (przedział ±15 min od zaplanowanej).
	$sent = 0;
	foreach ( $orders as $o ) {
		if ( rzd_mail_planned_time( $o ) ) {
			$sent++;
		}
	}
	wp_send_json( array( 'ok' => true, 'sent' => $sent ) );
} );

add_action( 'wc_ajax_kuchnia_unlock_planning', function () {
	rzd_kitchen_check_nonce(); // moduł 25 (CSRF)
	rzd_need( 'planning' ); // uprawnienie z konfiguratora
	if ( ! rzd_kitchen_authed() ) {
		wp_send_json( array( 'ok' => false, 'message' => 'Brak dostępu.' ), 403 );
	}
	$date = isset( $_POST['date'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $_POST['date'] ) ? $_POST['date'] : '';
	$time = isset( $_POST['time'] ) ? sanitize_text_field( wp_unslash( $_POST['time'] ) ) : '';
	if ( $date && function_exists( 'rzd_kitchen_date_allowed' ) && ! rzd_kitchen_date_allowed( $date ) ) {
		wp_send_json( array( 'ok' => false, 'message' => 'Ten dzień jest poza Twoim zakresem. ' . rzd_kitchen_date_cap_text() ) );
	}
	if ( ! $date || ! function_exists( 'rzd_kuchnia_planning_lock_key' ) ) {
		wp_send_json( array( 'ok' => false, 'message' => 'Nieprawidłowe dane.' ) );
	}
	delete_option( rzd_kuchnia_planning_lock_key( $date, $time ) );
	wp_send_json( array( 'ok' => true ) );
} );

/* ============================================================
 * Ustawienia zakładki Zamówienia (moduł 12), wspólne dla wszystkich
 * urządzeń (panel + tablet): ile dni wstecz pokazywać i czy działa
 * automatyczne przejście do "W przygotowaniu" po cutoffie.
 * ============================================================ */
function rzd_kitchen_auto_prep_enabled() {
	return '0' !== (string) get_option( 'kuchnia_auto_prep', '1' );
}

function rzd_kitchen_days_back() {
	return max( 0, min( rzd_history_days_max(), (int) get_option( 'kuchnia_days_back', 3 ) ) );
}

add_action( 'wc_ajax_kuchnia_save_settings', function () {
	rzd_kitchen_check_nonce(); // moduł 25 (CSRF)
	rzd_need( 'settings' ); // uprawnienie z konfiguratora
	if ( ! rzd_kitchen_authed() ) {
		wp_send_json( array( 'ok' => false, 'message' => 'Brak dostępu.' ), 403 );
	}
	if ( isset( $_POST['days_back'] ) ) {
		update_option( 'kuchnia_days_back', max( 0, min( rzd_history_days_max(), absint( $_POST['days_back'] ) ) ), false );
	}
	if ( isset( $_POST['auto_prep'] ) ) {
		update_option( 'kuchnia_auto_prep', '1' === (string) $_POST['auto_prep'] ? '1' : '0', false );
	}
	wp_send_json( array( 'ok' => true ) );
} );

/* ============================================================
 * Automatyczne przejście do "W przygotowaniu" (przełącznik "Auto
 * przygotowanie" w Kuchni): gdy dla danego terminu (data + godzina
 * dostawy) minie cutoff, zamówienia czekające (Przyjęte / natywne
 * WooCommerce "Przetwarzanie"/"Wstrzymane") same przechodzą na
 * "W przygotowaniu". Wywoływane z modułu 12 przy każdym wejściu na
 * dashboard (nie ma tu WP-Cron). Wyłączone → zamówienia zostają
 * w "Przyjęte", aż kuchnia oznaczy termin jako "Przygotowane".
 * ============================================================ */
function rzd_auto_advance_orders( $orders ) {
	if ( ! rzd_kitchen_auto_prep_enabled() || ! function_exists( 'rzd_dc_is_cutoff_passed' ) ) {
		return;
	}
	$waiting = array( 'processing', 'on-hold', 'przyjete' );
	foreach ( $orders as $order ) {
		if ( ! in_array( $order->get_status(), $waiting, true ) ) {
			continue;
		}
		if ( $order->get_meta( '_rzd_status_manual' ) ) {
			continue; // status poprawiony ręcznie (korekta, 2.39.0) – automat go nie przepycha
		}
		$date = $order->get_meta( '_dc_delivery_date' );
		$time = $order->get_meta( '_dc_delivery_time' );
		if ( function_exists( 'rzd_order_is_pickup' ) && rzd_order_is_pickup( $order ) ) { // odbiór: godzina − „ile przed odbiorem”
			$cut = ( $date && $time ) ? rzd_pickup_cutoff_ts( $date, $time ) : 0;
			if ( $cut && time() >= $cut ) {
				$order->update_status( 'w-przygotowaniu' );
			}
			continue;
		}
		if ( $date && rzd_dc_is_cutoff_passed( $date, $time ? $time : '' ) ) {
			$order->update_status( 'w-przygotowaniu' );
		}
	}
}

function rzd_auto_advance_past_cutoff( $date ) {
	if ( function_exists( 'rzd_kuchnia_orders_for_date' ) ) {
		rzd_auto_advance_orders( rzd_kuchnia_orders_for_date( $date ) );
	}
}

/* ============================================================
 * Nowe zamówienia (sygnał w Kuchni, moduł 12): lekkie zapytanie co 20 s.
 * Zwraca ostatnio ZMIENIONE zamówienia widoczne w Kuchni (id, numer,
 * termin, moment opłacenia) + czas serwera. Ekran przy starcie zapamiętuje
 * czas, a alarm daje tylko dla zamówień opłaconych później i jeszcze
 * niewidzianych.
 * Po dacie zmiany, nie po numerze: Przelewy24 potwierdza z opóźnieniem,
 * więc starsze zamówienie może stać się "opłacone" później niż nowsze.
 * ============================================================ */
add_action( 'wc_ajax_kuchnia_new_orders', function () {
	rzd_kitchen_check_nonce(); // moduł 25 (CSRF)
	if ( ! rzd_kitchen_authed() ) {
		wp_send_json( array( 'ok' => false, 'message' => 'Brak dostępu.' ), 403 );
	}
	if ( ! function_exists( 'rzd_order_statuses_active' ) || ! function_exists( 'rzd_kuchnia_filter_paid' ) ) {
		wp_send_json( array( 'ok' => false, 'message' => 'Brak modułu Kuchnia.' ) );
	}
	$orders = rzd_kuchnia_filter_paid( wc_get_orders( array(
		'limit'   => 40,
		'status'  => rzd_order_statuses_active(),
		'orderby' => 'modified',
		'order'   => 'DESC',
		'return'  => 'objects',
	) ) );
	$out = array();
	foreach ( $orders as $o ) {
		// Moment "wpadnięcia" do Kuchni: opłacenie (albo złożenie przy płatności
		// przy odbiorze). Zmiana statusu przez kuchnię go nie rusza, więc stare
		// zamówienie po kliknięciu "Spakowane" nie da fałszywego alarmu.
		if ( 'dine_in' === $o->get_meta( '_rzd_type' ) ) {
			continue; // zamówienia z sali – własne bilety w zakładce „Sala” (moduł 33), nie alarm dostaw
		}
		$d     = $o->get_date_paid() ? $o->get_date_paid() : $o->get_date_created();
		$out[] = array(
			'ts'     => $d ? $d->getTimestamp() : 0,
			'id'     => (int) $o->get_id(),
			'number' => (string) $o->get_order_number(),
			'date'   => (string) $o->get_meta( '_dc_delivery_date' ),
			'time'   => (string) $o->get_meta( '_dc_delivery_time' ),
		);
	}
	wp_send_json( array( 'ok' => true, 'now' => time(), 'orders' => $out ) );
} );

/* ============================================================
 * Maile do klienta (szablon WooCommerce): godzina dostawy po
 * zaplanowaniu, zmiana terminu po przeplanowaniu w Kuchni.
 * ============================================================ */
function rzd_customer_mail( $order, $subject, $heading, $body_html ) {
	$to = $order->get_billing_email();
	if ( ! $to || ! function_exists( 'WC' ) ) {
		return false;
	}
	$mailer = WC()->mailer();
	$html   = $mailer->wrap_message( $heading, $body_html );
	if ( class_exists( 'WC_Email' ) ) {
		$email = new WC_Email();
		$html  = $email->style_inline( $html );
	}
	return (bool) $mailer->send( $to, $subject, $html, "Content-Type: text/html\r\n" );
}

// "12:35" → [ "12:20", "12:50" ] – nie obiecujemy klientowi dokładnej minuty.
function rzd_planned_range( $ptime ) {
	$t = DateTime::createFromFormat( 'H:i', (string) $ptime, wp_timezone() );
	if ( ! $t ) {
		return array( $ptime, $ptime );
	}
	$a = clone $t;
	$b = clone $t;
	$a->modify( '-15 minutes' );
	$b->modify( '+15 minutes' );
	return array( $a->format( 'H:i' ), $b->format( 'H:i' ) );
}

// Wysyła mail z godziną, jeśli jeszcze nie poszedł dla TEJ godziny.
// Druga, inna godzina po ponownym zaplanowaniu = mail "Zmiana godziny".
function rzd_mail_planned_time( $order ) {
	$date = (string) $order->get_meta( '_dc_delivery_date' );
	$pt   = (string) $order->get_meta( '_dc_planned_time' );
	if ( ! $date || ! $pt ) {
		return false;
	}
	$key  = $date . ' ' . $pt;
	$prev = (string) $order->get_meta( '_rzd_mail_planned' );
	if ( $prev === $key ) {
		return false;
	}
	list( $from, $to ) = rzd_planned_range( $pt );
	$num     = $order->get_order_number();
	$day     = function_exists( 'rzd_dc_date_label' ) ? rzd_dc_date_label( $date ) : $date;
	$change  = ( '' !== $prev );
	$subject = ( $change ? 'Zmiana godziny dostawy zamówienia #' : 'Godzina dostawy zamówienia #' ) . $num;
	$body    = '<p>Dzień dobry,</p><p>' . ( $change ? 'zmieniła się godzina dostawy Twojego zamówienia' : 'zaplanowaliśmy dostawę Twojego zamówienia' ) . ' <strong>#' . esc_html( $num ) . '</strong>.</p>'
		. '<p style="font-size:18px;"><strong>' . esc_html( ucfirst( $day ) ) . ', między ' . esc_html( $from ) . ' a ' . esc_html( $to ) . '</strong></p>'
		. '<p>Prosimy o dostępność pod podanym numerem telefonu. Dziękujemy i smacznego!</p>';
	if ( ! rzd_customer_mail( $order, $subject, $change ? 'Zmiana godziny dostawy' : 'Godzina dostawy', $body ) ) {
		return false;
	}
	$order->update_meta_data( '_rzd_mail_planned', $key );
	$order->add_order_note( 'Wysłano klientowi mail z godziną dostawy: ' . $day . ', ' . $from . '–' . $to . '.' );
	$order->save();
	return true;
}

/* ============================================================
 * Przeplanowanie ("Nowy termin" w Kuchni, sekcja "Do przeplanowania").
 * Terminy BEZ cutoffów (decyduje kuchnia), ale z dniami, datami
 * wyłączonymi, matrycą, grupami produktów zamówienia i miejscowością.
 * ============================================================ */
function rzd_resched_slots( $order ) {
	if ( ! function_exists( 'rzd_dc_calendar_times_for_date' ) ) {
		return array();
	}
	// Odbiór osobisty (moduł 36): nowy termin = dni, w które kuchnia przyjmuje te dania, i godziny odbioru (bez limitu i „ile przed”).
	if ( function_exists( 'rzd_order_is_pickup' ) && rzd_order_is_pickup( $order ) ) {
		$ids = array();
		foreach ( $order->get_items() as $item ) {
			if ( $item->get_product_id() && rzd_dc_calendars_for_product( $item->get_product_id() ) ) {
				$ids[] = (int) $item->get_product_id();
			}
		}
		$out = array();
		$day = rzd_dc_now();
		for ( $i = 0; $i <= rzd_dc_max_horizon(); $i++ ) {
			$date = $day->format( 'Y-m-d' );
			$day->modify( '+1 day' );
			$ok = true;
			foreach ( $ids as $pid ) {
				$ok = $ok && rzd_pickup_product_day_ok( $pid, $date );
			}
			$times = $ok ? rzd_pickup_times_for_date( $date, true ) : array();
			if ( $times ) {
				$out[] = array( 'date' => $date, 'label' => rzd_dc_date_label( $date ), 'times' => $times, 'labels' => array_combine( $times, array_map( function ( $t ) { return 'odbiór ' . $t; }, $times ) ) );
			}
		}
		return $out;
	}
	$cals_by_product = array();
	foreach ( $order->get_items() as $item ) {
		$pid  = (int) $item->get_product_id();
		$cals = $pid ? rzd_dc_calendars_for_product( $pid ) : array();
		if ( $cals ) {
			$cals_by_product[ $pid ] = $cals; // produkty bez grupy (np. dodatki) nie zawężają
		}
	}
	$town = null;
	if ( function_exists( 'rzd_town_find' ) && rzd_towns_enabled() ) {
		$name = $order->get_meta( '_rzd_town' );
		$name = $name ? $name : ( $order->get_shipping_city() ? $order->get_shipping_city() : $order->get_billing_city() );
		$town = rzd_town_find( $name );
	}
	$settings = rzd_dc_get_settings();
	$out      = array();
	$day      = rzd_dc_now();
	$max      = rzd_dc_max_horizon();
	for ( $i = 0; $i <= $max; $i++ ) {
		$date  = $day->format( 'Y-m-d' );
		$times = null;
		if ( $cals_by_product ) {
			foreach ( $cals_by_product as $cals ) {
				foreach ( $cals as $cal ) {
					$t     = rzd_dc_calendar_times_for_date( $cal, $date, true );
					$times = ( null === $times ) ? $t : array_values( array_intersect( $times, $t ) );
				}
			}
		} else {
			$times = array();
			foreach ( $settings['groups'] as $cal ) {
				$times = array_merge( $times, rzd_dc_calendar_times_for_date( $cal, $date, true ) );
			}
			$times = array_values( array_unique( $times ) );
		}
		$times = $times ? $times : array();
		if ( $town ) {
			$times = array_values( array_filter( $times, function ( $t ) use ( $town, $date ) {
				return rzd_town_allows_slot( $town, $date, $t );
			} ) );
		}
		sort( $times );
		if ( $times ) {
			// Tryb okien: przy godzinie przedział okna i zajętość,
			// np. „12:00–13:00 · 7/6 pkt ⚠” – Kuchnia może świadomie przeładować.
			$labels = array();
			$need   = function_exists( 'rzd_dc_order_points' ) ? rzd_dc_order_points( $order ) : 1;
			foreach ( $times as $t ) {
				$labels[ $t ] = $t;
				if ( function_exists( 'rzd_dc_windows_on' ) && rzd_dc_windows_on() ) {
					$cap = rzd_dc_slot_capacity( $date, $t );
					$now = rzd_dc_orders_points_for_slot( $date, $t );
					if ( $order->get_meta( '_dc_delivery_date' ) === $date && $order->get_meta( '_dc_delivery_time' ) === $t ) {
						$now = max( 0, $now - $need ); // to zamówienie już tu jest – nie liczymy go dwa razy
					}
					$labels[ $t ] = rzd_dc_time_window_label( $t, $date ) . ' · ' . ( $now + $need ) . '/' . $cap . ' pkt' . ( $now + $need > $cap ? ' ⚠' : '' );
				}
			}
			$out[] = array( 'date' => $date, 'label' => rzd_dc_date_label( $date ), 'times' => $times, 'labels' => $labels );
		}
		$day->modify( '+1 day' );
	}
	return $out;
}

add_action( 'wc_ajax_kuchnia_resched_slots', function () {
	rzd_kitchen_check_nonce(); // moduł 25 (CSRF)
	rzd_need( 'change' ); // uprawnienie z konfiguratora
	if ( ! rzd_kitchen_authed() ) {
		wp_send_json( array( 'ok' => false, 'message' => 'Brak dostępu.' ), 403 );
	}
	$order = wc_get_order( isset( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0 );
	if ( ! $order ) {
		wp_send_json( array( 'ok' => false, 'message' => 'Nie znaleziono zamówienia.' ) );
	}
	$dates = rzd_resched_slots( $order );
	wp_send_json( array(
		'ok'      => true,
		'number'  => $order->get_order_number(),
		'dates'   => $dates,
		'message' => $dates ? '' : 'Brak terminów dla produktów z tego zamówienia w najbliższych dniach.',
	) );
} );

add_action( 'wc_ajax_kuchnia_reschedule', function () {
	rzd_kitchen_check_nonce(); // moduł 25 (CSRF)
	rzd_need( 'change' ); // uprawnienie z konfiguratora
	if ( ! rzd_kitchen_authed() ) {
		wp_send_json( array( 'ok' => false, 'message' => 'Brak dostępu.' ), 403 );
	}
	$order = wc_get_order( isset( $_POST['order_id'] ) ? absint( $_POST['order_id'] ) : 0 );
	$date  = isset( $_POST['date'] ) ? sanitize_text_field( wp_unslash( $_POST['date'] ) ) : '';
	$time  = isset( $_POST['time'] ) && function_exists( 'rzd_clean_time' ) ? rzd_clean_time( wp_unslash( $_POST['time'] ) ) : '';
	if ( ! $order || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) || ! $time ) {
		wp_send_json( array( 'ok' => false, 'message' => 'Nieprawidłowe dane.' ) );
	}
	if ( in_array( $order->get_status(), array( 'wydane', 'completed', 'cancelled' ), true ) ) {
		wp_send_json( array( 'ok' => false, 'message' => 'To zamówienie jest już zamknięte.' ) );
	}
	$allowed = false;
	foreach ( rzd_resched_slots( $order ) as $d ) {
		if ( $d['date'] === $date && in_array( $time, $d['times'], true ) ) {
			$allowed = true;
		}
	}
	if ( ! $allowed ) {
		wp_send_json( array( 'ok' => false, 'message' => 'Ten termin nie jest dostępny dla tego zamówienia.' ) );
	}
	$old = $order->get_meta( '_dc_delivery_date' ) . ' ' . $order->get_meta( '_dc_delivery_time' );
	$order->update_meta_data( '_dc_delivery_date', $date );
	$order->update_meta_data( '_dc_delivery_time', $time );
	$order->delete_meta_data( '_dc_planned_time' );
	$order->delete_meta_data( '_dc_delivery_sequence' );
	$order->delete_meta_data( '_rzd_mail_planned' ); // po nowym zaplanowaniu pójdzie świeży mail z godziną
	$pk    = function_exists( 'rzd_order_is_pickup' ) && rzd_order_is_pickup( $order );
	$label = function_exists( 'rzd_dc_slot_label' ) ? rzd_dc_slot_label( array( 'date' => $date, 'time' => $time, 'mode' => $pk ? 'pickup' : '' ) ) : $date . ' ' . $time;
	$word  = $pk ? 'odbioru' : 'dostawy';
	$order->add_order_note( 'Nowy termin ' . $word . ' (Kuchnia, ' . wp_get_current_user()->display_name . '): ' . $label . ' (poprzednio ' . trim( $old ) . ').' );
	$order->save();

	$mailed = false;
	if ( ! empty( $_POST['notify'] ) ) {
		$num    = $order->get_order_number();
		$body   = '<p>Dzień dobry,</p><p>zmieniliśmy termin ' . $word . ' Twojego zamówienia <strong>#' . esc_html( $num ) . '</strong>. Przepraszamy za kłopot.</p>'
			. '<p style="font-size:18px;"><strong>Nowy termin: ' . esc_html( ucfirst( $label ) ) . '</strong></p>'
			. '<p>Dokładniejszą godzinę podamy w osobnej wiadomości, gdy zaplanujemy trasę.</p>';
		$mailed = rzd_customer_mail( $order, 'Zmiana terminu ' . $word . ' zamówienia #' . $num, 'Zmiana terminu ' . $word, $body );
		if ( $mailed ) {
			$order->add_order_note( 'Wysłano klientowi mail o zmianie terminu ' . $word . '.' );
		}
	}
	wp_send_json( array( 'ok' => true, 'label' => $label, 'mailed' => $mailed ) );
} );
