<?php
/**
 * MODUŁ 10: Możliwe modyfikacje produktu (wersja 3 — Dodatki + Składniki)
 *
 * UWAGA: to jest przebudowa architektury, świadomie BEZ migracji starych
 * danych (stara, płaska konfiguracja modyfikacji przestaje działać —
 * ustawienia trzeba wprowadzić na nowo).
 *
 * Model: GRUPA (nagłówek + opis) → MODYFIKACJE. Każda modyfikacja typu
 * radio/tap/stepper NIE MA własnej nazwy/ceny/ikony – zamiast tego wskazuje
 * na wcześniej zdefiniowany DODATEK (moduł 14: nazwa, cena "przy dodaniu",
 * cena "przy odejmowaniu", ikonka, czy obowiązkowy) i deklaruje swoją ROLĘ
 * wobec niego:
 *  - dodaje       – aktywacja DOLICZA cenę dodatku (np. "Dodatkowe mięso")
 *  - odejmuje     – aktywacja ODEJMUJE cenę "przy odejmowaniu" (np. "Bez mięsa")
 *  - neutralna    – bez wpływu na cenę i bez wpływu na inne modyfikacje
 *  - obowiązkowa  – zawsze aktywna, klient nie może jej wyłączyć/zmienić
 *  - dezaktywuje  – jak "odejmuje", DODATKOWO blokuje w tym samym formularzu
 *                   wszystkie inne modyfikacje tego samego dodatku (np.
 *                   "ani frytki, ani ziemniaki")
 *
 * Ten sam dodatek użyty w kilku miejscach (np. "Mięso" jako "dodaje" w
 * jednym miejscu i jako "odejmuje"/"dezaktywuje" gdzie indziej) wzajemnie
 * się BLOKUJE: aktywacja jednego wyszarza pozostałe, żeby nie dało się
 * jednocześnie dodać i zdjąć to samo. Dodatek oznaczony w katalogu jako
 * "obowiązkowy" jest zawsze zablokowany do edycji, niezależnie od roli –
 * ale nadal POKAZUJE SIĘ w oknie wyboru (klient ma widzieć, za co płaci).
 *
 * SKŁAD I TYP – jak dodatek "wie", jaki dokładnie składnik zmienić:
 * Produkt może mieć zdefiniowany SKŁAD (sekcja niżej w tej samej zakładce)
 * – listę Składników (moduł 14: sama nazwa + typ, bez ceny), wyłącznie do
 * WYŚWIETLANIA ("nazwa produktu + skład" wszędzie, gdzie dotąd sama nazwa).
 * Jeśli Dodatek ma ustawiony TYP, to w chwili użycia system szuka w Składzie
 * TEGO KONKRETNEGO produktu Składnika tego samego typu i pokazuje klientowi
 * JEGO nazwę (np. Dodatek "Mięso" na Schabowym pokaże się jako "Kotlet
 * schabowy", na Sznyclu jako "Kotlet z kurczaka") – ale CENA zawsze
 * pochodzi z Dodatku, nigdy ze Składnika (Składnik ceny nie ma). Dodatek
 * bez typu (np. "Opakowanie") działa wprost, swoją własną nazwą i ceną,
 * niezależnie od Składu. Dodatek z typem, dla którego produkt nie ma w
 * Składzie pasującego Składnika, po prostu nie pokazuje się dla tego
 * produktu (patrz rzd_resolve_addon_name_for_product).
 *
 * Typ "text" (samo pole tekstowe) zostaje BEZ ZMIAN – nie odwołuje się do
 * dodatku, ma własną nazwę/cenę/podpowiedź, bo to wolny tekst (np. grawer
 * imienia), nie policzalna pozycja magazynowa dla kuchni.
 *
 * Wybrane modyfikacje (poza "text") trafiają do zamówienia PODWÓJNIE:
 * jako czytelny opis dla klienta (jak dotąd) ORAZ jako ukryte, maszynowo
 * czytelne dane (_rzd_addon_usage) – to na nich opiera się liczenie
 * dodatków w module 12 (Kuchnia) i module 09 (Raporty), niezależnie od
 * tego, w ilu różnych produktach/modyfikacjach dany dodatek jest użyty.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * RODZAJ modyfikacji (2.24.0) – żeby kuchnia wiedziała, czy frytki to
 * dodatek płatny, czy wybór w ramach ceny zestawu:
 *  - zestaw      "Wybór w zestawie:" – nie zmienia ceny (np. ziemniaki/frytki do ryby)
 *  - dodatki     "Dodatki (płatne):" – dopłata > 0
 *  - obowiazkowe "Obowiązkowe:"      – rola obowiązkowa albo Dodatek obowiązkowy (np. opakowanie), także płatne
 *  - bez         "Bez:"              – odejmuje / dezaktywuje
 * Napis "W zestawie" jest zajęty przez skład zestawu dnia (moduł 04) – stąd "Wybór w zestawie".
 */
function rzd_mod_kind( $role, $price, $mandatory = false ) {
	if ( 'tekst' === $role ) {
		return 'tekst';
	}
	if ( in_array( $role, array( 'odejmuje', 'dezaktywuje' ), true ) ) {
		return 'bez';
	}
	if ( 'obowiazkowa' === $role || $mandatory ) {
		return 'obowiazkowe';
	}
	return ( (float) $price > 0.001 ) ? 'dodatki' : 'zestaw';
}

function rzd_mod_kind_labels() {
	return array(
		'zestaw'      => 'Wybór w zestawie',
		'dodatki'     => 'Dodatki (płatne)',
		'obowiazkowe' => 'Obowiązkowe',
		'bez'         => 'Bez',
	);
}

// Rodzaj wpisu z _rzd_addon_usage; zamówienia sprzed 2.24.0 nie mają 'kind' – zgadujemy z roli.
function rzd_usage_kind( $u ) {
	if ( ! empty( $u['kind'] ) ) {
		return $u['kind'];
	}
	$map = array( 'odejmuje' => 'bez', 'dezaktywuje' => 'bez', 'obowiazkowa' => 'obowiazkowe', 'neutralna' => 'zestaw' );
	$r   = isset( $u['role'] ) ? $u['role'] : 'dodaje';
	return isset( $map[ $r ] ) ? $map[ $r ] : 'dodatki';
}

// Etykieta rodzaju w Kuchni i raportach ('danie' = pozycja/danie, nie modyfikacja).
function rzd_kind_label( $kind ) {
	$l = rzd_mod_kind_labels();
	if ( 'danie' === $kind ) {
		return 'Danie/produkt';
	}
	if ( 'dodatki' === $kind ) {
		return 'Dodatek płatny';
	}
	if ( 'opakowanie' === $kind ) {
		return 'Opakowanie'; // moduł 21
	}
	return isset( $l[ $kind ] ) ? $l[ $kind ] : 'Dodatek';
}

function rzd_modifier_roles() {
	return array(
		'dodaje'      => 'Dodaje (dolicza cenę dodatku)',
		'odejmuje'    => 'Odejmuje (odejmuje cenę dodatku)',
		'neutralna'   => 'Neutralna (bez wpływu na cenę)',
		'obowiazkowa' => 'Obowiązkowa (zawsze aktywna)',
		'dezaktywuje' => 'Dezaktywuje (np. "ani jedno, ani drugie") – odejmuje cenę I blokuje inne modyfikacje tego samego typu',
	);
}

/* ============================================================
 * 0. DANE
 * ============================================================ */
function rzd_get_sections( $product_id ) {
	$data = get_post_meta( $product_id, '_rzd_modifiers', true );
	if ( ! is_array( $data ) ) {
		return array();
	}
	// 2.26.17: miejsce wyboru ustawia się na GRUPIE (sekcji) – każda modyfikacja
	// dostaje je stąd, więc reszta kodu (rzd_group_place) czyta $g['place'] jak wcześniej.
	$data = array_values( $data );
	foreach ( $data as $si => $section ) {
		$place = rzd_section_place( $section );
		if ( isset( $section['items'] ) && is_array( $section['items'] ) ) {
			foreach ( $section['items'] as $mi => $mod ) {
				$data[ $si ]['items'][ $mi ]['place'] = $place;
			}
		}
	}
	return $data;
}

/**
 * 2.26.17: miejsce wyboru grupy – 'before' albo 'cart' (przegląd zamówienia).
 * Grupy zapisane w 2.26.16 nie mają pola – wtedy 'cart', jeśli któraś
 * modyfikacja miała je ustawione pojedynczo (przeniesienie ustawienia).
 */
function rzd_section_place( $section ) {
	if ( isset( $section['place'] ) ) {
		return 'cart' === $section['place'] ? 'cart' : 'before';
	}
	foreach ( ( isset( $section['items'] ) ? (array) $section['items'] : array() ) as $mod ) {
		if ( isset( $mod['place'] ) && 'cart' === $mod['place'] ) {
			return 'cart';
		}
	}
	return 'before';
}

/**
 * Sekcje modyfikacji, które FAKTYCZNIE obowiązują przy dodawaniu produktu do
 * koszyka. Zwykły produkt – jego własne sekcje. ZESTAW – najpierw sekcje
 * dań aktywnych na wybrany dzień (w kolejności z "Roli w zestawie", każda
 * sekcja z nazwą dania w nagłówku), a na końcu własne sekcje samego zestawu
 * (np. torba). Każda sekcja niesie 'src' = ID produktu, od którego pochodzi –
 * to wg jego SKŁADU rozwiązują się nazwy dodatków "po typie".
 * To jedno źródło prawdy: okno wyboru, odczyt wyboru i koszyk czytają ją
 * tak samo, więc numeracja pól (index) zawsze się zgadza.
 */
function rzd_get_effective_sections( $product_id, $depth = 0 ) {
	static $memo = array();
	$sel_date = ( function_exists( 'dc_selected_date' ) && dc_selected_date() ) ? dc_selected_date() : '';
	$key      = $product_id . '|' . $sel_date;
	if ( 0 === $depth && isset( $memo[ $key ] ) ) {
		return $memo[ $key ];
	}

	$out = array();
	if ( $depth < 3 && function_exists( 'rwz_get_slots' ) && rwz_get_slots( $product_id ) ) {
		$active = rwz_get_active_components( $product_id );
		$via    = isset( $active['via'] ) ? $active['via'] : array();

		// Zestawy pośrednie (np. "Zupa dnia" wpięta w "Zestaw dnia"): ich WŁASNE
		// sekcje (np. opakowanie) dokładamy raz, zaraz po ostatnim daniu, które
		// przez nie przyszło. Najpierw najgłębszy zestaw, potem zewnętrzny.
		$via_last  = array(); // id zestawu pośredniego => id ostatniego dania z niego
		$via_count = array(); // id zestawu pośredniego => ile dań przez niego przyszło
		foreach ( $active['main'] as $comp ) {
			$cid = (int) $comp->get_id();
			if ( empty( $via[ $cid ] ) ) {
				continue;
			}
			foreach ( $via[ $cid ] as $mid ) {
				$via_last[ $mid ]  = $cid;
				$via_count[ $mid ] = ( isset( $via_count[ $mid ] ) ? $via_count[ $mid ] : 0 ) + 1;
			}
		}

		foreach ( $active['main'] as $comp ) {
			$cid = (int) $comp->get_id();
			if ( $cid === (int) $product_id ) {
				continue;
			}
			$label = isset( $active['roles'][ $cid ]['label'] ) ? $active['roles'][ $cid ]['label'] : '';
			$dish  = ( $label ? $label . ': ' : '' ) . $comp->get_name();
			foreach ( rzd_get_effective_sections( $cid, $depth + 1 ) as $sec ) {
				$head          = isset( $sec['header'] ) ? trim( $sec['header'] ) : '';
				$sec['header'] = $dish . ( '' !== $head ? ' — ' . $head : '' );
				$out[]         = $sec;
			}

			if ( empty( $via[ $cid ] ) ) {
				continue;
			}
			foreach ( array_reverse( $via[ $cid ] ) as $mid ) {
				if ( $via_last[ $mid ] !== $cid || (int) $mid === (int) $product_id ) {
					continue;
				}
				$single = ( 1 === $via_count[ $mid ] );
				if ( $single ) {
					// Jedno danie z tego zestawu: sekcja występuje pod nazwą dania
					// i rozwiązuje się wg JEGO składu (dodatki z Typem, blokady).
					$m_head = $dish;
					$m_src  = $cid;
				} else {
					$mp     = wc_get_product( $mid );
					$m_head = ( $label ? $label . ': ' : '' ) . ( $mp ? $mp->get_name() : '' );
					$m_src  = (int) $mid;
				}
				foreach ( rzd_get_sections( $mid ) as $sec ) {
					$head          = isset( $sec['header'] ) ? trim( $sec['header'] ) : '';
					$sec['header'] = $m_head . ( '' !== $head ? ' — ' . $head : '' );
					$sec['src']    = $m_src;
					$out[]         = $sec;
				}
			}
		}
	}
	foreach ( rzd_get_sections( $product_id ) as $section ) {
		$section['src'] = (int) $product_id;
		$out[]          = $section;
	}

	if ( 0 === $depth ) {
		$memo[ $key ] = $out;
	}
	return $out;
}

// Spłaszczona lista WSZYSTKICH modyfikacji ze wszystkich obowiązujących sekcji, w kolejności.
// Każda niesie '_src' – produkt, wg którego składu rozwiązują się jej dodatki.
function rzd_get_modifier_groups( $product_id ) {
	$flat = array();
	foreach ( rzd_get_effective_sections( $product_id ) as $section ) {
		foreach ( (array) $section['items'] as $mod ) {
			$mod['_src'] = isset( $section['src'] ) ? (int) $section['src'] : (int) $product_id;
			$flat[]      = $mod;
		}
	}
	return $flat;
}

function rzd_products_with_modifiers() {
	static $ids = null;
	if ( null === $ids ) {
		global $wpdb;
		// Także ZESTAWY (mają harmonogram _rwz_slots): ich okno składa się z modyfikacji
		// dań na wybrany dzień, więc trzeba je zapytać, nawet gdy sam zestaw nie ma własnych.
		$ids = array_map( 'intval', $wpdb->get_col( "SELECT DISTINCT post_id FROM {$wpdb->postmeta} WHERE meta_key IN ( '_rzd_modifiers', '_rwz_slots' )" ) );
	}
	return $ids;
}

/**
 * Dodatki obowiązkowe (rolą "obowiązkowa" albo z flagi w katalogu Dodatki)
 * na typach tap/stepper – klient i tak ich nie wybiera, więc pokazujemy je
 * jako informację, a nie jako coś do skonfigurowania w oknie wyboru.
 * Zwraca: [ ['name','price','qty'], … ]
 */
function rzd_get_mandatory_addons( $product_id ) {
	$out = array();
	foreach ( rzd_get_modifier_groups( $product_id ) as $g ) {
		if ( ! in_array( $g['type'], array( 'tap', 'stepper' ), true ) ) {
			continue; // "obowiązkowa" ma sens tylko dla pojedynczego dodatku, nie dla wyboru/pola tekstowego
		}
		$addon = rzd_get_addon( $g['addon_id'] );
		if ( ! $addon ) {
			continue;
		}
		if ( 'obowiazkowa' === $g['role'] || $addon['mandatory'] ) {
			$qty   = ( 'stepper' === $g['type'] ) ? max( 1, (int) $g['min'] ) : 1;
			$out[] = array( 'name' => $addon['name'], 'price' => (float) $addon['price'], 'qty' => $qty );
		}
	}
	return $out;
}

// Notatka pod nazwą produktu na liście: "(do produktu zostanie dodany X o wartości Y)"
add_filter( 'rest_produkt_obowiazkowe_dodatki', function ( $html, $product_id ) {
	$mandatory = rzd_get_mandatory_addons( $product_id );
	if ( ! $mandatory ) {
		return $html;
	}
	$parts = array();
	foreach ( $mandatory as $m ) {
		$ile     = ( $m['qty'] > 1 ) ? ( $m['qty'] . '× ' ) : '';
		$parts[] = sprintf(
			'do produktu zostanie dodany %s%s o wartości %s',
			esc_html( $ile ),
			esc_html( $m['name'] ),
			esc_html( html_entity_decode( wp_strip_all_tags( wc_price( $m['price'] ) ), ENT_QUOTES, 'UTF-8' ) )
		);
	}
	return '(' . implode( '; ', $parts ) . ')';
}, 10, 2 );

function rzd_format_delta( $delta ) {
	$delta = (float) $delta;
	if ( abs( $delta ) < 0.0001 ) {
		return '';
	}
	$sign = $delta > 0 ? '+' : '';
	// wp_strip_all_tags + html_entity_decode: wc_price() zwraca HTML i encje
	// (np. "&#322;" zamiast "ł") – w polach wypełnianych przez JS przez
	// textContent musi to być zwykły, gotowy do wyświetlenia tekst.
	return ' (' . $sign . html_entity_decode( wp_strip_all_tags( wc_price( $delta ) ), ENT_QUOTES, 'UTF-8' ) . ')';
}

/* ============================================================
 * 1. PANEL: zakładka "Możliwe modyfikacje"
 * ============================================================ */
add_action( 'admin_enqueue_scripts', function ( $hook ) {
	global $post_type;
	if ( 'product' === $post_type && in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
		wp_enqueue_media();
		add_action( 'admin_print_styles', 'rzd_admin_tabs_layout_fix' );
	}
} );

/**
 * Uwaga: funkcja rzd_admin_tabs_layout_fix() (naprawa układu tej zakładki –
 * box-sizing, odstępy między polami) jest zdefiniowana w module 04, bo tam
 * powstała jako pierwsza i obsługuje też zakładkę "Zestaw dnia". Oba moduły
 * ładują się w tym samym żądaniu, więc funkcja jest dostępna, niezależnie
 * od tego, w którym pliku faktycznie siedzi definicja – nie trzeba (i nie
 * wolno) definiować jej drugi raz tutaj, bo PHP nie pozwala na dwie
 * definicje tej samej nazwy funkcji (błąd krytyczny "Cannot redeclare").
 */

/**
 * Wybór dodatku + roli – wspólny fragment formularza dla modyfikacji typu
 * tap/stepper (jeden dodatek) i dla każdej opcji typu radio (jeden dodatek
 * na opcję). $name to pełna nazwa pola (np. "rzd_section[0][items][1]").
 */
function rzd_render_addon_picker( $name, $addon_id, $role ) {
	$addons = function_exists( 'rzd_get_all_addons' ) ? rzd_get_all_addons() : array();
	ob_start();
	?>
	<p class="rzd-field">
		<label><strong>Dodatek</strong> (nazwa, cena i ikonka z katalogu Dodatki):</label>
		<select name="<?php echo esc_attr( $name ); ?>[addon_id]">
			<option value="">— wybierz —</option>
			<?php foreach ( $addons as $a ) : ?>
				<option value="<?php echo esc_attr( $a['id'] ); ?>" <?php selected( (int) $addon_id, $a['id'] ); ?>>
					<?php
					// 2.26.17: obie ceny – „przy dodaniu” i „przy odejmowaniu” (rola Odejmuje/Dezaktywuje bierze tę drugą).
					$pl = number_format( $a['price'], 2, ',', '' );
					$mi = number_format( $a['price_minus'], 2, ',', '' );
					echo esc_html( $a['name'] . ' (' . ( $pl === $mi ? $pl . ' zł' : '+' . $pl . ' zł / −' . $mi . ' zł' ) . ')' . ( $a['mandatory'] ? ' — obowiązkowy' : '' ) );
					?>
				</option>
			<?php endforeach; ?>
		</select>
		<?php if ( ! $addons ) : ?>
			<p class="description">Nie masz jeszcze żadnego dodatku – dodaj go najpierw w menu <strong>Dodatki</strong>.</p>
		<?php endif; ?>
	</p>
	<p class="rzd-field">
		<label><strong>Rola</strong> wobec tego dodatku:</label>
		<select name="<?php echo esc_attr( $name ); ?>[role]">
			<?php foreach ( rzd_modifier_roles() as $slug => $label ) : ?>
				<option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $role, $slug ); ?>><?php echo esc_html( $label ); ?></option>
			<?php endforeach; ?>
		</select>
	</p>
	<?php
	return ob_get_clean();
}

function rzd_render_option_row( $g, $i, $opt ) {
	$addon_id = isset( $opt['addon_id'] ) ? (int) $opt['addon_id'] : 0;
	$role     = isset( $opt['role'] ) ? $opt['role'] : 'dodaje';
	$name     = 'rzd_section[' . $g . '][options][' . $i . ']'; // $g to ścieżka wewnątrz sekcji, np. "0][items][2"
	ob_start();
	?>
	<div class="rzd-opt" style="border:1px solid #ddd;background:#fff;padding:10px;margin:8px 0;position:relative;">
		<a href="#" class="rzd-remove-opt" style="position:absolute;top:8px;right:10px;color:#d63638;font-size:18px;font-weight:bold;text-decoration:none;" title="Usuń opcję">&times;</a>
		<?php echo rzd_render_addon_picker( $name, $addon_id, $role ); ?>
	</div>
	<?php
	return ob_get_clean();
}

function rzd_render_group( $index, $group ) {
	$type        = isset( $group['type'] ) ? $group['type'] : 'tap';
	$addon_id    = isset( $group['addon_id'] ) ? (int) $group['addon_id'] : 0;
	$role        = isset( $group['role'] ) ? $group['role'] : 'dodaje';
	$min         = isset( $group['min'] ) ? $group['min'] : 0;
	$max         = isset( $group['max'] ) ? $group['max'] : 10;
	$name        = isset( $group['name'] ) ? $group['name'] : ''; // tylko typ "text"
	$price       = isset( $group['price'] ) ? $group['price'] : ''; // tylko typ "text"
	$placeholder = isset( $group['placeholder'] ) ? $group['placeholder'] : ''; // tylko typ "text"
	$options     = ( isset( $group['options'] ) && is_array( $group['options'] ) ) ? array_values( $group['options'] ) : array();
	$fname       = 'rzd_section[' . $index . ']'; // $index to ścieżka wewnątrz sekcji, np. "0][items][2"

	ob_start();
	?>
	<div class="rzd-group" data-group="<?php echo esc_attr( $index ); ?>" data-next-opt="<?php echo (int) count( $options ); ?>" style="border:2px solid #b5bfc9;margin:10px 0;padding:12px;background:#f6f7f7;position:relative;">
		<a href="#" class="rzd-remove-group" style="position:absolute;top:10px;right:12px;color:#d63638;text-decoration:none;font-size:20px;font-weight:bold;" title="Usuń modyfikację">&times;</a>

		<p class="rzd-field">
			<label><strong>Sposób wyświetlania:</strong></label>
			<select class="rzd-type" name="<?php echo esc_attr( $fname ); ?>[type]">
				<option value="radio" <?php selected( $type, 'radio' ); ?>>Pojedynczy wybór (lista opcji)</option>
				<option value="tap" <?php selected( $type, 'tap' ); ?>>Duży przycisk włącz/wyłącz</option>
				<option value="text" <?php selected( $type, 'text' ); ?>>Samo pole tekstowe</option>
				<option value="stepper" <?php selected( $type, 'stepper' ); ?>>Licznik ze strzałkami +/-</option>
			</select>
		</p>


		<div class="rzd-only-radio" style="<?php echo ( 'radio' === $type ) ? '' : 'display:none;'; ?>">
			<label><strong>Opcje do wyboru</strong> – każda to osobny dodatek + jego rola:</label>
			<div class="rzd-opts">
				<?php foreach ( $options as $j => $opt ) : ?>
					<?php echo rzd_render_option_row( $index, $j, $opt ); ?>
				<?php endforeach; ?>
			</div>
			<p><button type="button" class="button rzd-add-opt">+ Dodaj opcję</button></p>
		</div>

		<div class="rzd-only-addon" style="<?php echo in_array( $type, array( 'tap', 'stepper' ), true ) ? '' : 'display:none;'; ?>">
			<?php echo rzd_render_addon_picker( $fname, $addon_id, $role ); ?>
			<div class="rzd-only-stepper-range" style="<?php echo ( 'stepper' === $type ) ? '' : 'display:none;'; ?>">
				<p class="rzd-field rzd-field-inline">
					<label style="display:inline;"><strong>Ilość: od</strong></label>
					<input type="number" min="0" step="1" name="<?php echo esc_attr( $fname ); ?>[min]" value="<?php echo esc_attr( $min ); ?>" style="width:70px;">
					<label style="display:inline;"><strong>do</strong></label>
					<input type="number" min="0" step="1" name="<?php echo esc_attr( $fname ); ?>[max]" value="<?php echo esc_attr( $max ); ?>" style="width:70px;">
				</p>
			</div>
		</div>

		<div class="rzd-only-text" style="<?php echo ( 'text' === $type ) ? '' : 'display:none;'; ?>">
			<p class="rzd-field">
				<label><strong>Nazwa</strong> (widoczna dla klienta):</label>
				<input type="text" name="<?php echo esc_attr( $fname ); ?>[name]" value="<?php echo esc_attr( $name ); ?>" style="width:280px;" placeholder="np. Grawer imienia">
			</p>
			<p class="rzd-field">
				<label><strong>Cena</strong> (nalicza się, gdy pole nie jest puste, może być ujemna):</label>
				<input type="number" step="0.01" name="<?php echo esc_attr( $fname ); ?>[price]" value="<?php echo esc_attr( $price ); ?>" style="width:110px;">
			</p>
			<p class="rzd-field">
				<label><strong>Podpowiedź w polu tekstowym</strong> (opcjonalnie):</label>
				<input type="text" name="<?php echo esc_attr( $fname ); ?>[placeholder]" value="<?php echo esc_attr( $placeholder ); ?>" style="width:280px;" placeholder="np. Wpisz imię do grawerunku">
			</p>
		</div>
	</div>
	<?php
	return ob_get_clean();
}

function rzd_render_sklad_row( $i, $ingredient_id, $ingredients ) {
	ob_start();
	?>
	<p class="rzd-sklad-row" style="display:flex;align-items:center;gap:8px;margin:0 0 8px;">
		<select name="rzd_sklad[<?php echo esc_attr( $i ); ?>]" style="min-width:220px;">
			<option value="">— wybierz składnik —</option>
			<?php foreach ( $ingredients as $ing ) : ?>
				<option value="<?php echo esc_attr( $ing['id'] ); ?>" <?php selected( (int) $ingredient_id, $ing['id'] ); ?>><?php echo esc_html( $ing['name'] ); ?></option>
			<?php endforeach; ?>
		</select>
		<a href="#" class="rzd-remove-sklad" style="color:#d63638;text-decoration:none;font-size:16px;font-weight:bold;" title="Usuń">&times;</a>
	</p>
	<?php
	return ob_get_clean();
}

function rzd_render_section( $si, $section ) {
	$header      = isset( $section['header'] ) ? $section['header'] : '';
	$description = isset( $section['description'] ) ? $section['description'] : '';
	$items       = ( isset( $section['items'] ) && is_array( $section['items'] ) ) ? array_values( $section['items'] ) : array();
	$place       = rzd_section_place( $section ); // 2.26.17
	$sname       = 'rzd_section[' . $si . ']';

	ob_start();
	?>
	<div class="rzd-section" data-section="<?php echo esc_attr( $si ); ?>" data-next-item="<?php echo (int) count( $items ); ?>" style="border:2px solid #8a8f99;margin:18px 12px;padding:14px;background:#eef0f3;position:relative;">
		<a href="#" class="rzd-remove-section" style="position:absolute;top:10px;right:12px;color:#d63638;text-decoration:none;font-size:22px;font-weight:bold;" title="Usuń całą grupę">&times;</a>

		<p class="rzd-field">
			<label><strong>Nagłówek grupy</strong> (widoczny dla klienta nad tymi modyfikacjami):</label>
			<input type="text" name="<?php echo esc_attr( $sname ); ?>[header]" value="<?php echo esc_attr( $header ); ?>" style="width:340px;" placeholder="np. Dodaj do zestawu">
		</p>
		<p class="rzd-field">
			<label><strong>Opis grupy</strong> (mniejsza czcionka pod nagłówkiem, opcjonalnie):</label>
			<textarea name="<?php echo esc_attr( $sname ); ?>[description]" rows="2" style="width:100%;max-width:480px;" placeholder="np. Te produkty wchodzą w skład zestawu, ich zmiana nie ma wpływu na cenę"><?php echo esc_textarea( $description ); ?></textarea>
		</p>
		<p class="rzd-field">
			<label><strong>Gdzie klient wybiera modyfikacje z tej grupy:</strong></label>
			<select name="<?php echo esc_attr( $sname ); ?>[place]">
				<option value="before" <?php selected( $place, 'before' ); ?>>Przed dodaniem do koszyka</option>
				<option value="cart" <?php selected( $place, 'cart' ); ?>>W przeglądzie zamówienia (Dodatki płatne)</option>
			</select>
			<span class="description" style="display:block;">„W przeglądzie zamówienia” = klient dobiera je po kliknięciu „Przejdź do koszyka”, przyciskiem „Dodatki płatne”. Pojedynczy wybór (lista opcji) i modyfikacje obowiązkowe z tej grupy i tak pokażą się przed dodaniem do koszyka.</span>
		</p>

		<div class="rzd-items" style="margin-top:10px;">
			<?php foreach ( $items as $mi => $mod ) : ?>
				<?php echo rzd_render_group( $si . '][items][' . $mi, $mod ); ?>
			<?php endforeach; ?>
		</div>
		<p><button type="button" class="button rzd-add-item">+ Dodaj modyfikację do tej grupy</button></p>
	</div>
	<?php
	return ob_get_clean();
}

add_filter( 'woocommerce_product_data_tabs', function ( $tabs ) {
	$tabs['rzd_mods'] = array(
		'label'    => __( 'Możliwe modyfikacje', 'rzd' ),
		'target'   => 'rzd_mods_data',
		'class'    => array(),
		'priority' => 23,
	);
	return $tabs;
} );

add_action( 'woocommerce_product_data_panels', function () {
	global $post;
	$sections    = rzd_get_sections( $post->ID );
	$sklad       = get_post_meta( $post->ID, '_rzd_sklad', true );
	$sklad       = is_array( $sklad ) ? $sklad : array();
	$ingredients = function_exists( 'rzd_get_all_ingredients' ) ? rzd_get_all_ingredients() : array();

	echo '<div id="rzd_mods_data" class="panel woocommerce_options_panel">';

	echo '<div id="rzd-sklad-wrap" style="padding:0 12px;margin-bottom:18px;border-bottom:1px solid #ddd;padding-bottom:14px;">';
	echo '<h4 style="margin-bottom:4px;">Skład</h4>';
	echo '<p class="description" style="margin-top:0;">Z czego faktycznie składa się to danie – WYŁĄCZNIE do wyświetlania (nazwa produktu + ten skład mniejszą czcionką, na liście, w koszyku, w kuchni). Bez zdefiniowanego składu pokazuje się sama nazwa produktu. To jest też miejsce, w którym dodatki "po typie" (niżej) szukają, KTÓRY konkretnie składnik mają zmienić – składniki dodajesz w menu Składniki.</p>';
	echo '<div id="rzd-sklad-rows" data-next="' . (int) count( $sklad ) . '">';
	foreach ( $sklad as $i => $ingredient_id ) {
		echo rzd_render_sklad_row( $i, $ingredient_id, $ingredients );
	}
	echo '</div>';
	echo '<p><button type="button" class="button" id="rzd-add-sklad">+ Dodaj składnik do składu</button></p>';
	echo '<script type="text/html" id="rzd-sklad-template">' . rzd_render_sklad_row( '__I__', 0, $ingredients ) . '</script>';
	echo '</div>';

	echo '<p style="padding:0 12px;color:#555;">' . esc_html__( 'Dodaj grupę (np. "Dodaj do zestawu"), a w środku modyfikacje – każda (poza polem tekstowym) odwołuje się do wcześniej zdefiniowanego składnika (menu "Składniki") i określa swoją rolę wobec niego. Klient zobaczy to w okienku wyboru tuż przed dodaniem produktu do koszyka.', 'rzd' ) . '</p>';

	rzd_render_sections_editor( $sections );
	?>
	<script>
	jQuery(function ($) {
		// Skład: dodawanie/usuwanie wierszy
		var $skladRows = $('#rzd-sklad-rows');
		$('#rzd-add-sklad').on('click', function (e) {
			e.preventDefault();
			var i = parseInt($skladRows.attr('data-next'), 10) || 0;
			$skladRows.append($('#rzd-sklad-template').html().split('__I__').join(i));
			$skladRows.attr('data-next', i + 1);
		});
		$skladRows.on('click', '.rzd-remove-sklad', function (e) { e.preventDefault(); $(this).closest('.rzd-sklad-row').remove(); });
	});
	</script>
	<?php
	echo '</div>';
} );

/**
 * Edytor grup modyfikacji (od 2.19.0 wspólny dla produktu i dla „Wzorów
 * modyfikacji” z modułu 18): lista grup, przycisk „+ Dodaj grupę”, szablony
 * i obsługa w JS. Pola mają nazwy rzd_section[…] – zapis w obu miejscach
 * idzie przez rzd_sanitize_sections().
 * Licznik kolejnej grupy siedzi w atrybucie data-next na #rzd-sections, żeby
 * mógł z niego korzystać także przycisk „Dodaj z predefiniowanych”.
 * $with_presets = true → pod edytorem wybór wzoru (tylko na produkcie).
 */
function rzd_render_sections_editor( $sections, $with_presets = true ) {
	$sections = is_array( $sections ) ? array_values( $sections ) : array();

	echo '<div id="rzd-sections" data-next="' . (int) count( $sections ) . '">';
	foreach ( $sections as $si => $section ) {
		echo rzd_render_section( $si, $section );
	}
	echo '</div>';
	echo '<p style="padding:0 12px;"><button type="button" class="button button-primary" id="rzd-add-section">+ ' . esc_html__( 'Dodaj grupę', 'rzd' ) . '</button></p>';

	if ( $with_presets && function_exists( 'rzd_render_preset_picker' ) ) {
		rzd_render_preset_picker(); // moduł 18
	}

	echo '<script type="text/html" id="rzd-section-template">' . rzd_render_section( '__S__', array() ) . '</script>';
	echo '<script type="text/html" id="rzd-item-template">' . rzd_render_group( '__S__][items][__M__', array() ) . '</script>';
	echo '<script type="text/html" id="rzd-opt-template">' . rzd_render_option_row( '__S____M__', '__I__', array() ) . '</script>';
	?>
	<script>
	jQuery(function ($) {
		var $sections = $('#rzd-sections');

		function toggleFields($g) {
			var type = $g.find('.rzd-type').first().val();
			$g.find('.rzd-only-radio').toggle(type === 'radio');
			$g.find('.rzd-only-addon').toggle(type === 'tap' || type === 'stepper');
			$g.find('.rzd-only-stepper-range').toggle(type === 'stepper');
			$g.find('.rzd-only-text').toggle(type === 'text');
		}

		$('#rzd-add-section').on('click', function (e) {
			e.preventDefault();
			var n = parseInt($sections.attr('data-next'), 10) || 0;
			$sections.append($('#rzd-section-template').html().split('__S__').join(n));
			$sections.attr('data-next', n + 1);
		});
		$sections.on('click', '.rzd-remove-section', function (e) { e.preventDefault(); $(this).closest('.rzd-section').remove(); });

		$sections.on('click', '.rzd-add-item', function (e) {
			e.preventDefault();
			var $sec = $(this).closest('.rzd-section');
			var si = $sec.attr('data-section');
			var mi = parseInt($sec.attr('data-next-item'), 10) || 0;
			var tpl = $('#rzd-item-template').html().split('__S__').join(si).split('__M__').join(mi);
			$sec.find('.rzd-items').first().append(tpl);
			$sec.attr('data-next-item', mi + 1);
		});
		$sections.on('change', '.rzd-type', function () { toggleFields($(this).closest('.rzd-group')); });
		$sections.on('click', '.rzd-remove-group', function (e) { e.preventDefault(); $(this).closest('.rzd-group').remove(); });

		$sections.on('click', '.rzd-add-opt', function (e) {
			e.preventDefault();
			var $g = $(this).closest('.rzd-group');
			var gi = $g.attr('data-group');
			var oi = parseInt($g.attr('data-next-opt'), 10) || 0;
			var tpl = $('#rzd-opt-template').html().split('__S____M__').join(gi).split('__I__').join(oi);
			$g.find('.rzd-opts').first().append(tpl);
			$g.attr('data-next-opt', oi + 1);
		});
		$sections.on('click', '.rzd-remove-opt', function (e) { e.preventDefault(); $(this).closest('.rzd-opt').remove(); });
	});
	</script>
	<?php
}

/* ============================================================
 * 2. ZAPIS
 * ============================================================ */
function rzd_sanitize_modifier( $g ) {
	if ( ! is_array( $g ) ) {
		return null;
	}
	$type = ( isset( $g['type'] ) && in_array( $g['type'], array( 'radio', 'tap', 'text', 'stepper' ), true ) ) ? $g['type'] : 'tap';

	if ( 'text' === $type ) {
		$name = isset( $g['name'] ) ? sanitize_text_field( $g['name'] ) : '';
		if ( '' === $name ) {
			return null; // pole tekstowe bez nazwy jest pomijane
		}
		return array(
			'type'        => 'text',
			'name'        => $name,
			'price'       => isset( $g['price'] ) ? (float) $g['price'] : 0.0,
			'placeholder' => isset( $g['placeholder'] ) ? sanitize_text_field( $g['placeholder'] ) : '',
		);
	}

	if ( 'radio' === $type ) {
		$options = array();
		if ( isset( $g['options'] ) && is_array( $g['options'] ) ) {
			foreach ( $g['options'] as $opt ) {
				$addon_id = isset( $opt['addon_id'] ) ? absint( $opt['addon_id'] ) : 0;
				if ( ! $addon_id || ! rzd_get_addon( $addon_id ) ) {
					continue; // opcja bez wybranego (istniejącego) dodatku jest pomijana
				}
				$role      = ( isset( $opt['role'] ) && array_key_exists( $opt['role'], rzd_modifier_roles() ) ) ? $opt['role'] : 'dodaje';
				$options[] = array( 'addon_id' => $addon_id, 'role' => $role );
			}
		}
		if ( empty( $options ) ) {
			return null; // wybór bez żadnej poprawnej opcji nie ma sensu
		}
		return array( 'type' => 'radio', 'options' => $options );
	}

	// tap / stepper
	$addon_id = isset( $g['addon_id'] ) ? absint( $g['addon_id'] ) : 0;
	if ( ! $addon_id || ! rzd_get_addon( $addon_id ) ) {
		return null; // bez wybranego dodatku modyfikacja nie ma sensu
	}
	$role = ( isset( $g['role'] ) && array_key_exists( $g['role'], rzd_modifier_roles() ) ) ? $g['role'] : 'dodaje';
	$row  = array( 'type' => $type, 'addon_id' => $addon_id, 'role' => $role );

	if ( 'stepper' === $type ) {
		$row['min'] = isset( $g['min'] ) ? max( 0, intval( $g['min'] ) ) : 0;
		$row['max'] = isset( $g['max'] ) ? max( 0, intval( $g['max'] ) ) : 10;
		if ( $row['max'] < $row['min'] ) {
			$row['max'] = $row['min'];
		}
	}
	return $row;
}

add_action( 'woocommerce_process_product_meta', function ( $post_id ) {
	// Skład zapisuje się niezależnie od modyfikacji – jest sensowny nawet na
	// produkcie, który nie ma żadnej modyfikacji do wyboru.
	if ( isset( $_POST['rzd_sklad'] ) && is_array( $_POST['rzd_sklad'] ) ) {
		$sklad = array_values( array_unique( array_filter( array_map( 'absint', $_POST['rzd_sklad'] ) ) ) );
		if ( $sklad ) {
			update_post_meta( $post_id, '_rzd_sklad', $sklad );
		} else {
			delete_post_meta( $post_id, '_rzd_sklad' );
		}
	} else {
		delete_post_meta( $post_id, '_rzd_sklad' );
	}

	$clean = rzd_sanitize_sections( isset( $_POST['rzd_section'] ) ? wp_unslash( $_POST['rzd_section'] ) : array() );
	if ( empty( $clean ) ) {
		delete_post_meta( $post_id, '_rzd_modifiers' );
	} else {
		update_post_meta( $post_id, '_rzd_modifiers', $clean );
	}
}, 20 );

/**
 * Czyści grupy modyfikacji z formularza (pola rzd_section[…]). Wspólne dla
 * produktu i wzorów (moduł 18). Puste grupy i modyfikacje bez dodatku są
 * pomijane. Dane wejściowe już po wp_unslash().
 */
function rzd_sanitize_sections( $raw ) {
	$clean = array();
	if ( ! is_array( $raw ) ) {
		return $clean;
	}
	foreach ( $raw as $section ) {
		if ( ! is_array( $section ) ) {
			continue;
		}
		$items = array();
		if ( isset( $section['items'] ) && is_array( $section['items'] ) ) {
			foreach ( $section['items'] as $g ) {
				$row = rzd_sanitize_modifier( $g );
				if ( null !== $row ) {
					$items[] = $row;
				}
			}
		}
		if ( empty( $items ) ) {
			continue; // pusta grupa jest pomijana
		}
		$clean[] = array(
			'header'      => isset( $section['header'] ) ? sanitize_text_field( $section['header'] ) : '',
			'description' => isset( $section['description'] ) ? sanitize_textarea_field( $section['description'] ) : '',
			'place'       => ( isset( $section['place'] ) && 'cart' === $section['place'] ) ? 'cart' : 'before', // 2.26.17
			'items'       => $items,
		);
	}
	return $clean;
}

/* ============================================================
 * 3. ODCZYT WYBORU KLIENTA (z $_POST['rzd_mod'])
 * ============================================================
 * Zwraca:
 *  'lines' – do wyświetlenia klientowi/w koszyku: [ ['name','label','price'], … ]
 *  'delta' – suma dopłat/odjęć do ceny produktu
 *  'usage' – dane MASZYNOWE dla kuchni/raportów: [ ['addon_id','name','qty','role'], … ]
 *            (bez wpisów o roli "neutralna" – nic nie trzeba dla nich liczyć)
 */
function rzd_role_sign( $role ) {
	if ( 'odejmuje' === $role || 'dezaktywuje' === $role ) {
		return -1;
	}
	if ( 'neutralna' === $role ) {
		return 0;
	}
	return 1; // dodaje, obowiazkowa
}

/**
 * Cena dodatku, jaka faktycznie obowiązuje przy danej roli. Zestaw kilku
 * dodatków zwykle kosztuje MNIEJ niż suma ich cen osobno (np. mięso + frytki
 * + surówka osobno to 50 zł, w zestawie 37 zł) – dlatego dodatek ma DWIE
 * wartości: "przy dodaniu" i "przy odejmowaniu", i to ta druga liczy się
 * dla roli "odejmuje", a nie ta sama wartość co przy dodawaniu.
 */
function rzd_addon_role_price( $addon, $role ) {
	if ( 'odejmuje' === $role || 'dezaktywuje' === $role ) {
		return -1 * (float) $addon['price_minus'];
	}
	if ( 'neutralna' === $role ) {
		return 0.0;
	}
	return (float) $addon['price']; // dodaje, obowiazkowa
}

/**
 * Nazwa, jaką dodatek pokazuje klientowi/kuchni NA TYM KONKRETNYM produkcie.
 * Bez typu – zawsze własna nazwa dodatku. Z typem – szuka w Składzie tego
 * produktu pasującego Składnika i bierze JEGO nazwę (cena i tak zawsze
 * pochodzi z dodatku, to dotyczy wyłącznie tego, jak się to nazywa).
 * Zwraca null, gdy dodatek ma typ, ale w składzie produktu nie ma nic
 * pasującego – to sygnał dla wywołującego kodu, żeby całą modyfikację
 * pominąć (nie dotyczy tego produktu).
 */
function rzd_resolve_addon_name_for_product( $product_id, $addon ) {
	if ( empty( $addon['type_id'] ) ) {
		return $addon['name'];
	}
	if ( ! function_exists( 'rzd_find_ingredient_by_type' ) ) {
		return $addon['name'];
	}
	$ing = rzd_find_ingredient_by_type( $product_id, $addon['type_id'] );
	return $ing ? $ing['name'] : null;
}

/**
 * 2.26.16: gdzie klient wybiera modyfikację – 'before' (okno przed dodaniem)
 * albo 'cart' (przycisk „Modyfikuj” w koszyku). Pojedynczy wybór (radio,
 * w oknie wymagany) i obowiązkowe (rolą albo z katalogu) – zawsze 'before',
 * nawet gdy w ustawieniach zapisano inaczej albo dodatek zmienił się później.
 */
function rzd_group_place( $g ) {
	if ( empty( $g['place'] ) || 'cart' !== $g['place'] || 'radio' === $g['type'] ) {
		return 'before';
	}
	if ( 'text' !== $g['type'] ) {
		if ( 'obowiazkowa' === $g['role'] ) {
			return 'before';
		}
		$addon = rzd_get_addon( $g['addon_id'] );
		if ( ! $addon || ! empty( $addon['mandatory'] ) ) {
			return 'before';
		}
	}
	return 'cart';
}

// 2.26.16: czy produkt (na termin koszyka) ma choć jedną modyfikację „w koszyku”,
// która go dotyczy (dodatek z Typem bez dopasowania w składzie – nie).
function rzd_product_has_cart_groups( $product_id ) {
	static $memo = array();
	$product_id = (int) $product_id;
	if ( isset( $memo[ $product_id ] ) ) {
		return $memo[ $product_id ];
	}
	$has = false;
	foreach ( rzd_get_modifier_groups( $product_id ) as $g ) {
		if ( 'cart' !== rzd_group_place( $g ) ) {
			continue;
		}
		if ( 'text' === $g['type'] ) {
			$has = true;
			break;
		}
		$addon = rzd_get_addon( $g['addon_id'] );
		if ( $addon && null !== rzd_resolve_addon_name_for_product( isset( $g['_src'] ) ? (int) $g['_src'] : $product_id, $addon ) ) {
			$has = true;
			break;
		}
	}
	return $memo[ $product_id ] = $has;
}

// 2.26.16: surowe zaznaczenia z okna ( [ index => [ 'val' => … ] ] ) – zapisywane
// w pozycji koszyka, żeby okno w koszyku otworzyło się z wyborem klienta.
function rzd_sanitize_raw_selection( $posted ) {
	$raw = array();
	foreach ( (array) $posted as $k => $v ) {
		if ( is_array( $v ) && isset( $v['val'] ) && '' !== (string) $v['val'] && ! is_array( $v['val'] ) ) {
			$raw[ absint( $k ) ] = array( 'val' => sanitize_text_field( (string) $v['val'] ) );
		}
	}
	return $raw;
}

function rzd_read_selection( $product_id, $posted = null ) {
	if ( null === $posted ) {
		$posted = ( isset( $_POST['rzd_mod'] ) && is_array( $_POST['rzd_mod'] ) ) ? wp_unslash( $_POST['rzd_mod'] ) : array();
	}
	$lines = array();
	$usage = array();
	$delta = 0.0;

	foreach ( rzd_get_modifier_groups( $product_id ) as $gi => $g ) {
		$posted_g = isset( $posted[ $gi ] ) && is_array( $posted[ $gi ] ) ? $posted[ $gi ] : array();
		$src      = isset( $g['_src'] ) ? (int) $g['_src'] : (int) $product_id; // dla zestawu: danie, z którego pochodzi ta modyfikacja

		if ( 'text' === $g['type'] ) {
			$text = isset( $posted_g['val'] ) ? sanitize_text_field( $posted_g['val'] ) : '';
			if ( '' === $text ) {
				continue;
			}
			$lines[] = array( 'name' => $g['name'], 'label' => $text, 'price' => (float) $g['price'], 'role' => 'tekst', 'qty' => 1 );
			$delta  += (float) $g['price'];
			continue;
		}

		if ( 'radio' === $g['type'] ) {
			if ( ! isset( $posted_g['val'] ) || '' === $posted_g['val'] ) {
				continue;
			}
			$oi = absint( $posted_g['val'] );
			if ( ! isset( $g['options'][ $oi ] ) ) {
				continue;
			}
			$opt   = $g['options'][ $oi ];
			$addon = rzd_get_addon( $opt['addon_id'] );
			if ( ! $addon ) {
				continue;
			}
			$eff_name = rzd_resolve_addon_name_for_product( $src, $addon );
			if ( null === $eff_name ) {
				continue; // dodatek ma typ, ale ten produkt nie ma w składzie pasującego składnika
			}
			$price   = rzd_addon_role_price( $addon, $opt['role'] );
			$kind    = rzd_mod_kind( $opt['role'], $price, ! empty( $addon['mandatory'] ) );
			$lines[] = array( 'name' => $eff_name, 'label' => $eff_name, 'price' => $price, 'role' => $opt['role'], 'qty' => 1, 'kind' => $kind, 'src' => (int) $src, 'pick' => 1 ); // src od 2.26.18 – danie zestawu; pick od 2.26.19 – pojedynczy wybór (przegląd: do składu)
			$delta  += $price;
			// Od 2.24.0 także wybory bez dopłaty – kuchnia musi zsumować np. frytki do zestawów.
			$usage[] = array( 'addon_id' => $addon['id'], 'name' => $eff_name, 'qty' => 1, 'role' => $opt['role'], 'kind' => $kind );
			continue;
		}

		// tap / stepper – wspólna logika, różni się tylko sposobem ustalenia $qty
		$addon = rzd_get_addon( $g['addon_id'] );
		if ( ! $addon ) {
			continue;
		}
		$eff_name = rzd_resolve_addon_name_for_product( $src, $addon );
		if ( null === $eff_name ) {
			continue; // dodatek ma typ, ale ten produkt nie ma w składzie pasującego składnika
		}

		if ( 'obowiazkowa' === $g['role'] || $addon['mandatory'] ) {
			// zawsze aktywna, klient nic tu nie wybiera – niezależnie od tego,
			// co (jeśli cokolwiek) przyszło w $_POST
			$qty = ( 'stepper' === $g['type'] ) ? max( 1, (int) $g['min'] ) : 1;
		} elseif ( 'tap' === $g['type'] ) {
			$qty = empty( $posted_g['val'] ) ? 0 : 1;
		} else { // stepper
			$qty = isset( $posted_g['val'] ) ? intval( $posted_g['val'] ) : 0;
			$qty = max( (int) $g['min'], min( (int) $g['max'], $qty ) );
		}
		if ( $qty <= 0 ) {
			continue;
		}

		$price = rzd_addon_role_price( $addon, $g['role'] ) * $qty;
		$label = ( 'stepper' === $g['type'] && $qty > 1 ) ? ( $eff_name . ' ×' . $qty ) : $eff_name;

		$kind    = rzd_mod_kind( $g['role'], $price, ! empty( $addon['mandatory'] ) );
		$lines[] = array( 'name' => $eff_name, 'label' => $label, 'price' => $price, 'role' => $g['role'], 'qty' => $qty, 'kind' => $kind, 'src' => (int) $src );
		$delta  += $price;
		$usage[] = array( 'addon_id' => $addon['id'], 'name' => $eff_name, 'qty' => $qty, 'role' => $g['role'], 'kind' => $kind );
	}

	// Rola "dezaktywuje" liczy się cenowo dokładnie jak "odejmuje" (patrz
	// rzd_addon_role_price) – dodatkowe BLOKOWANIE innych modyfikacji tego
	// samego typu (np. "ani frytki, ani ziemniaki" gasi osobny licznik
	// "dodatkowe ziemniaki") dzieje się po stronie front-endu, w oknie
	// wyboru, zanim klient w ogóle kliknie "Dodaj do koszyka" – patrz
	// updateExclusions() niżej w tym pliku.

	return array( 'lines' => $lines, 'delta' => $delta, 'usage' => $usage );
}

/* ============================================================
 * 4. KOSZYK: dopłata do ceny pozycji + wyszczególnienie modyfikacji
 * ============================================================ */
add_filter( 'woocommerce_add_cart_item_data', function ( $data, $product_id ) {
	if ( ! rzd_get_modifier_groups( $product_id ) ) {
		return $data;
	}
	$sel = rzd_read_selection( $product_id );
	// 2.26.16: zawsze (także bez wyboru) – podstawa edycji w koszyku.
	$data['rzd_raw'] = rzd_sanitize_raw_selection( ( isset( $_POST['rzd_mod'] ) && is_array( $_POST['rzd_mod'] ) ) ? wp_unslash( $_POST['rzd_mod'] ) : array() );
	if ( $sel['lines'] ) {
		$data['rzd_mods']       = $sel['lines'];
		$data['rzd_mods_delta'] = $sel['delta'];
		$data['rzd_usage']      = $sel['usage']; // maszynowe dane dla kuchni/raportów
		$data['rzd_base_price'] = (float) wc_get_product( $product_id )->get_price();
		// różny wybór modyfikacji = osobna pozycja w koszyku
		$data['unique_key'] = md5( wp_json_encode( $sel['lines'] ) . microtime() );
	}
	return $data;
}, 10, 2 );

add_action( 'woocommerce_before_calculate_totals', function ( $cart ) {
	if ( is_admin() && ! defined( 'DOING_AJAX' ) ) {
		return;
	}
	foreach ( $cart->get_cart() as $item ) {
		if ( isset( $item['rzd_base_price'], $item['rzd_mods_delta'] ) ) {
			$item['data']->set_price( max( 0, (float) $item['rzd_base_price'] + (float) $item['rzd_mods_delta'] ) );
		}
	}
}, 20 );

/**
 * Opis modyfikacji w koszyku, kasie, zamówieniu i mailach – w czterech
 * rodzajach (rzd_mod_kind): "Wybór w zestawie", "Dodatki (płatne)",
 * "Obowiązkowe", "Bez". Pola tekstowe zostają jako własne linijki.
 * Zwraca gotowe pary [ ['key','value'], … ] do wyświetlenia/zapisu.
 */
function rzd_group_mod_lines_for_display( $lines ) {
	$groups = array_fill_keys( array_keys( rzd_mod_kind_labels() ), array() );
	$out    = array();

	foreach ( $lines as $l ) {
		$role = isset( $l['role'] ) ? $l['role'] : 'dodaje';
		$qty  = isset( $l['qty'] ) ? (int) $l['qty'] : 1;

		if ( 'tekst' === $role ) {
			$out[] = array( 'key' => $l['name'], 'value' => $l['label'] . rzd_format_delta( $l['price'] ) );
			continue;
		}
		// Pozycje z koszyka sprzed 2.24.0 nie mają 'kind' – liczymy z roli i ceny.
		$kind = ! empty( $l['kind'] ) ? $l['kind'] : rzd_mod_kind( $role, isset( $l['price'] ) ? $l['price'] : 0 );
		$ile  = ( $qty > 1 ) ? ( $qty . '× ' ) : '';
		// "Wybór w zestawie" nie zmienia ceny – bez kwoty, żeby nie mylić.
		$groups[ $kind ][] = $ile . $l['name'] . ( 'zestaw' === $kind ? '' : rzd_format_delta( $l['price'] ) );
	}

	foreach ( rzd_mod_kind_labels() as $kind => $label ) {
		if ( $groups[ $kind ] ) {
			$out[] = array( 'key' => $label, 'value' => implode( ', ', $groups[ $kind ] ) );
		}
	}
	return $out;
}

add_filter( 'woocommerce_get_item_data', function ( $item_data, $cart_item ) {
	if ( ! empty( $cart_item['rzd_mods'] ) ) {
		$item_data = array_merge( $item_data, rzd_group_mod_lines_for_display( $cart_item['rzd_mods'] ) );
	}
	// 2.26.16: znacznik pod przycisk „Modyfikuj” (JS w koszyku zamienia go na
	// przycisk; wszędzie indziej ukryty CSS-em). Pozycje dodane przed 2.26.16
	// nie mają rzd_raw – bez przycisku.
	// 2.26.16: przycisk w koszyku UKRYTY (decyzja użytkownika – dodatki dobiera się w przeglądzie
	// zamówienia). Włączenie: add_filter( 'rzd_cart_edit_button', '__return_true' ).
	if ( apply_filters( 'rzd_cart_edit_button', false ) && isset( $cart_item['rzd_raw'], $cart_item['key'] ) && rzd_product_has_cart_groups( $cart_item['product_id'] ) ) {
		$item_data[] = array( 'key' => 'rzd-edit', 'value' => $cart_item['key'] );
	}
	return $item_data;
}, 10, 2 );

add_action( 'woocommerce_checkout_create_order_line_item', function ( $item, $cart_item_key, $values, $order ) {
	if ( ! empty( $values['rzd_mods'] ) ) {
		foreach ( rzd_group_mod_lines_for_display( $values['rzd_mods'] ) as $l ) {
			$item->add_meta_data( $l['key'], $l['value'], true );
		}
	}
	// Dane maszynowe dla kuchni/raportów – ukryty meta klucz (prefiks "_"),
	// nie pokazuje się klientowi ani na standardowym widoku zamówienia.
	if ( ! empty( $values['rzd_usage'] ) ) {
		$item->add_meta_data( '_rzd_addon_usage', wp_json_encode( $values['rzd_usage'] ), true );
	}
}, 10, 4 );

// Panel administratora WooCommerce pokazuje w pozycjach także pola z prefiksem
// "_" (ukrywa je tylko przed klientem, w mailach i na stronie zamówienia) –
// dlatego surowy JSON z _rzd_addon_usage wyświetlał się pod każdą pozycją.
// Dopisujemy go do listy pól ukrywanych w tym widoku. Dane nadal są zapisane
// i czytane przez Kuchnię i Raporty – znika tylko wyświetlanie.
add_filter( 'woocommerce_hidden_order_itemmeta', function ( $hidden ) {
	$hidden[] = '_rzd_addon_usage';
	return $hidden;
} );

/**
 * Odczyt maszynowych danych o użytych dodatkach z pozycji zamówienia –
 * używane przez moduł 12 (Kuchnia) i moduł 09 (Raporty).
 * Zwraca: [ ['addon_id','name','qty','role'], … ]
 */
function rzd_item_addon_usage( $item ) {
	$raw = $item->get_meta( '_rzd_addon_usage' );
	if ( ! $raw ) {
		return array();
	}
	$data = json_decode( $raw, true );
	return is_array( $data ) ? $data : array();
}

/* ============================================================
 * 5. OKNO WYBORU (krok 15 bramy dodawania – moduł 08)
 * ============================================================ */
add_action( 'wc_ajax_rzd_mods', function () {
	$pid        = isset( $_GET['product_id'] ) ? absint( $_GET['product_id'] ) : 0;
	$where      = 'before';
	$preset     = array();
	$extra      = array();
	// 2.26.16: okno w koszyku – pozycja koszyka po kluczu, tylko modyfikacje „w koszyku”,
	// zaznaczone tak, jak klient wybrał.
	$cart_key = isset( $_GET['cart_key'] ) ? sanitize_text_field( wp_unslash( $_GET['cart_key'] ) ) : '';
	if ( '' !== $cart_key ) {
		$item = ( function_exists( 'WC' ) && WC()->cart ) ? WC()->cart->get_cart_item( $cart_key ) : null;
		if ( ! $item || ! isset( $item['rzd_raw'] ) ) {
			wp_send_json( array( 'ok' => false, 'sections' => array() ) );
		}
		$pid    = (int) $item['product_id'];
		$where  = 'cart';
		$preset = (array) $item['rzd_raw'];
		$extra  = array( 'qty' => (int) $item['quantity'], 'title' => get_the_title( $pid ) );
	}
	// 2.26.20: w oknie „Dodatki płatne” (koszyk / przegląd) „Zawiera już” obejmuje też to,
	// co klient wybrał PRZED dodaniem do koszyka (np. Frytki z „Wybierz”) – jak „Skład:”
	// w przeglądzie. Liczone z rzd_raw tylko dla grup „przed dodaniem”; bez „Bez …”,
	// obowiązkowych i tekstu. Klucz: danie-źródło (src), jak w sekcjach okna.
	$picked = array();
	if ( 'cart' === $where ) {
		$before_raw = array();
		foreach ( rzd_get_modifier_groups( $pid ) as $gi => $g ) {
			if ( 'cart' !== rzd_group_place( $g ) && isset( $preset[ $gi ] ) ) {
				$before_raw[ $gi ] = $preset[ $gi ];
			}
		}
		$sel = rzd_read_selection( $pid, $before_raw );
		foreach ( $sel['lines'] as $l ) {
			$k = ! empty( $l['kind'] ) ? $l['kind'] : '';
			if ( ! in_array( $k, array( 'zestaw', 'dodatki' ), true ) ) {
				continue;
			}
			$picked[ ! empty( $l['src'] ) ? (int) $l['src'] : $pid ][] = $l['label'];
		}
	}
	$out        = array();
	$flat_index = 0;
	$shown_src  = array();
	foreach ( rzd_get_effective_sections( $pid ) as $section ) {
		$items = array();
		$src   = isset( $section['src'] ) ? (int) $section['src'] : $pid; // produkt, z którego pochodzi sekcja (dla zestawu: konkretne danie)
		foreach ( (array) $section['items'] as $g ) {
			if ( rzd_group_place( $g ) !== $where ) {
				$flat_index++; // modyfikacja z drugiego miejsca – pomijamy, numeracja idzie dalej
				continue;
			}
			$row  = array( 'index' => (int) $flat_index, 'type' => $g['type'], 'scope' => $src );
			$skip = false; // typ bez dopasowania w składzie TEGO produktu – modyfikacja go pomija, ale numeracja (flat_index) musi iść dalej

			if ( 'text' === $g['type'] ) {
				$row['price']       = (float) $g['price'];
				$row['price_html']  = rzd_format_delta( $g['price'] );
				$row['placeholder'] = isset( $g['placeholder'] ) ? $g['placeholder'] : '';
				$row['label']       = $g['name'];
			} elseif ( 'radio' === $g['type'] ) {
				$opts = array();
				foreach ( $g['options'] as $orig_oi => $opt ) {
					$addon = rzd_get_addon( $opt['addon_id'] );
					if ( ! $addon ) {
						continue; // dodatek usunięty z katalogu po skonfigurowaniu modyfikacji
					}
					$eff_name = rzd_resolve_addon_name_for_product( $src, $addon );
					if ( null === $eff_name ) {
						continue; // dodatek ma typ, ale ten produkt nie ma w składzie pasującego składnika – ta OPCJA znika, reszta radia zostaje
					}
					$price   = rzd_addon_role_price( $addon, $opt['role'] );
					$opts[]  = array(
						// 2.26.17 POPRAWKA: numer opcji w USTAWIENIACH. Wcześniej okno wysyłało numer
						// na liście po odfiltrowaniu (dodatek usunięty / Typ bez dopasowania w składzie),
						// a odczyt brał $g['options'][ten numer] – po każdej pominiętej opcji wybór
						// przesuwał się na sąsiednią (np. „Bez dodatków −7 zł” liczyło się jak opcja bez ceny).
						'oi'         => (int) $orig_oi,
						'addon_id'   => $addon['id'],
						'role'       => $opt['role'],
						'label'      => $eff_name,
						'price'      => $price,
						'price_html' => rzd_format_delta( $price ),
						'icon_url'   => $addon['icon_url'],
						'mandatory'  => $addon['mandatory'],
					);
				}
				if ( ! $opts ) {
					$skip = true; // ŻADNA opcja nie pasuje do tego produktu – cała modyfikacja znika
				}
				$row['options'] = $opts;
			} else { // tap / stepper
				$addon = rzd_get_addon( $g['addon_id'] );
				$eff_name = $addon ? rzd_resolve_addon_name_for_product( $src, $addon ) : null;
				if ( ! $addon || null === $eff_name ) {
					$skip = true;
				} else {
					$locked      = ( 'obowiazkowa' === $g['role'] || $addon['mandatory'] );
					$price       = rzd_addon_role_price( $addon, $g['role'] );
					$row['label']      = $eff_name;
					$row['addon_id']   = $addon['id'];
					$row['role']       = $g['role'];
					$row['price']      = $price;
					$row['price_html'] = rzd_format_delta( $price );
					$row['icon_url']   = $addon['icon_url'];
					// Obowiązkowy (rolą albo z katalogu) NADAL pokazuje się w oknie –
					// klient ma widzieć, za co płaci – tylko jest zablokowany do
					// zmiany (JS: przycisk/licznik wyszarzony, "Zawsze dołączone").
					$row['locked']     = $locked;
					// 2.26.16: „to dodatkowa porcja” – dodatek z Typem, którego składnik danie już ma.
					// 2.26.20: także gdy klient wybrał to przed dodaniem do koszyka (np. Frytki).
					$in_picked = false;
					foreach ( isset( $picked[ $src ] ) ? $picked[ $src ] : array() as $pn ) {
						if ( 0 === strpos( mb_strtolower( $pn ), mb_strtolower( $eff_name ) ) ) {
							$in_picked = true;
							break;
						}
					}
					if ( ! $locked && 'dodaje' === $g['role'] && ( $in_picked || ( ! empty( $addon['type_id'] ) && function_exists( 'rzd_find_ingredient_by_type' ) && rzd_find_ingredient_by_type( $src, $addon['type_id'] ) ) ) ) {
						$row['has_note'] = $eff_name . ' jest już w daniu – to dodatkowa porcja';
					}
					if ( 'stepper' === $g['type'] ) {
						$row['min'] = (int) $g['min'];
						$row['max'] = (int) $g['max'];
					}
				}
			}
			if ( ! $skip ) {
				$items[] = $row;
			}
			$flat_index++;
		}
		if ( $items ) {
			// 2.26.16: „Zawiera już: …” – skład dania, raz na danie (pierwsza jego sekcja w oknie).
			$contains = array();
			if ( ! isset( $shown_src[ $src ] ) ) {
				$shown_src[ $src ] = true;
				if ( function_exists( 'rzd_get_product_sklad' ) ) {
					foreach ( rzd_get_product_sklad( $src ) as $ing ) {
						$contains[] = $ing['name'];
					}
				}
				// 2.26.20: + wybory sprzed dodania (bez powtórzeń, wielkość liter bez znaczenia)
				$low = array_map( 'mb_strtolower', $contains );
				foreach ( isset( $picked[ $src ] ) ? $picked[ $src ] : array() as $pn ) {
					if ( ! in_array( mb_strtolower( $pn ), $low, true ) ) {
						$contains[] = $pn;
						$low[]      = mb_strtolower( $pn );
					}
				}
			}
			$out[] = array(
				'header'      => isset( $section['header'] ) ? $section['header'] : '',
				'description' => isset( $section['description'] ) ? $section['description'] : '',
				'contains'    => $contains,
				'items'       => $items,
			);
		}
	}
	wp_send_json( array_merge( array( 'ok' => true, 'where' => $where, 'preset' => (object) $preset, 'sections' => $out ), $extra ) );
} );

/**
 * 2.26.16: zapis zmian z okna w koszyku. Zmienia tylko modyfikacje „w koszyku”
 * (wybory sprzed dodania zostają), przelicza linie/dopłatę/rzd_usage tak jak
 * przy dodawaniu. split = 1 przy ilości > 1: zmiana dotyczy jednej sztuki,
 * która staje się osobną pozycją.
 */
add_action( 'wc_ajax_rzd_mods_save', function () {
	if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'rzd_mods_save' ) ) {
		wp_send_json( array( 'ok' => false, 'msg' => 'Sesja wygasła – odśwież stronę.' ) );
	}
	$cart = ( function_exists( 'WC' ) && WC()->cart ) ? WC()->cart : null;
	$key  = isset( $_POST['cart_key'] ) ? sanitize_text_field( wp_unslash( $_POST['cart_key'] ) ) : '';
	$item = $cart ? $cart->get_cart_item( $key ) : null;
	if ( ! $item || ! isset( $item['rzd_raw'] ) ) {
		wp_send_json( array( 'ok' => false, 'msg' => 'Nie znaleziono pozycji w koszyku.' ) );
	}
	$pid    = (int) $item['product_id'];
	$posted = rzd_sanitize_raw_selection( ( isset( $_POST['rzd_mod'] ) && is_array( $_POST['rzd_mod'] ) ) ? wp_unslash( $_POST['rzd_mod'] ) : array() );
	$raw    = (array) $item['rzd_raw'];
	foreach ( rzd_get_modifier_groups( $pid ) as $gi => $g ) {
		if ( 'cart' !== rzd_group_place( $g ) ) {
			continue;
		}
		unset( $raw[ $gi ] );
		if ( isset( $posted[ $gi ] ) ) {
			$raw[ $gi ] = $posted[ $gi ];
		}
	}
	$sel   = rzd_read_selection( $pid, $raw );
	$apply = function ( $it ) use ( $sel, $raw, $pid ) {
		$it['rzd_raw'] = $raw;
		if ( $sel['lines'] ) {
			$it['rzd_mods']       = $sel['lines'];
			$it['rzd_mods_delta'] = $sel['delta'];
			$it['rzd_usage']      = $sel['usage'];
			if ( ! isset( $it['rzd_base_price'] ) ) {
				$p                    = wc_get_product( $pid );
				$it['rzd_base_price'] = $p ? (float) $p->get_price() : 0;
			}
		} else {
			unset( $it['rzd_mods'], $it['rzd_mods_delta'], $it['rzd_usage'], $it['rzd_base_price'] );
		}
		return $it;
	};

	$qty = (int) $item['quantity'];
	if ( ! empty( $_POST['split'] ) && $qty > 1 ) {
		$new             = $apply( $item );
		$new_key         = md5( $key . '|rzd|' . microtime() );
		$new['key']      = $new_key;
		$new['quantity'] = 1;
		$new['unique_key'] = $new_key;
		$prod            = wc_get_product( ! empty( $item['variation_id'] ) ? (int) $item['variation_id'] : $pid );
		if ( ! $prod ) {
			wp_send_json( array( 'ok' => false, 'msg' => 'Produkt jest niedostępny.' ) );
		}
		$new['data'] = $prod; // osobny obiekt – inaczej obie pozycje dostałyby tę samą cenę
		$cart->set_quantity( $key, $qty - 1, false );
		$cart->cart_contents[ $new_key ] = $new;
	} else {
		$cart->cart_contents[ $key ] = $apply( $item );
	}
	$cart->calculate_totals();
	if ( method_exists( $cart, 'set_session' ) ) {
		$cart->set_session();
	}
	wp_send_json( array( 'ok' => true ) );
} );

/* ============================================================
 * 6. PRZEGLĄD ZAMÓWIENIA (2.26.16) – okno po „Przejdź do koszyka”
 * ============================================================
 * Lista pozycji koszyka: ilość × nazwa, zdjęcie, skład, wybrane modyfikacje,
 * przycisk „Dodatki płatne” (okno w trybie koszyka – modyfikacje z miejscem
 * „w koszyku”). Zestawy: dania z ich składem + ten sam przycisk (grupy dań). Na dole
 * podsumowanie bez dostawy (dostawa liczy się w koszyku).
 */
function rzd_review_names( $product_id ) {
	$out = array();
	if ( function_exists( 'rzd_get_product_sklad' ) ) {
		foreach ( rzd_get_product_sklad( $product_id ) as $ing ) {
			$out[] = $ing['name'];
		}
	}
	return $out;
}

/**
 * 2.26.20: kosz w przeglądzie zamówienia – usunięcie pozycji „w ostatniej chwili”
 * i „Cofnij” (WooCommerce trzyma usuniętą pozycję w sesji: restore_cart_item).
 * Nonce ten sam co zapis dodatków (rzd_mods_save).
 */
function rzd_review_cart_action( $restore ) {
	if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'rzd_mods_save' ) ) {
		wp_send_json( array( 'ok' => false, 'msg' => 'Sesja wygasła – odśwież stronę.' ) );
	}
	$cart = ( function_exists( 'WC' ) && WC()->cart ) ? WC()->cart : null;
	$key  = isset( $_POST['cart_key'] ) ? sanitize_text_field( wp_unslash( $_POST['cart_key'] ) ) : '';
	if ( ! $cart || '' === $key ) {
		wp_send_json( array( 'ok' => false, 'msg' => 'Nie znaleziono pozycji.' ) );
	}
	if ( $restore ) {
		$done = $cart->restore_cart_item( $key );
	} else {
		$done = $cart->get_cart_item( $key ) ? $cart->remove_cart_item( $key ) : false;
	}
	if ( ! $done ) {
		wp_send_json( array( 'ok' => false, 'msg' => $restore ? 'Nie udało się przywrócić pozycji.' : 'Tej pozycji nie ma już w koszyku.' ) );
	}
	$cart->calculate_totals();
	wp_send_json( array( 'ok' => true, 'empty' => $cart->is_empty() ) );
}
add_action( 'wc_ajax_rzd_review_remove', function () { rzd_review_cart_action( false ); } );
add_action( 'wc_ajax_rzd_review_restore', function () { rzd_review_cart_action( true ); } );

add_action( 'wc_ajax_rzd_review', function () {
	$cart = ( function_exists( 'WC' ) && WC()->cart ) ? WC()->cart : null;
	if ( ! $cart || $cart->is_empty() ) {
		wp_send_json( array( 'ok' => true, 'items' => array() ) );
	}
	$cart->calculate_totals();
	$items = array();
	foreach ( $cart->get_cart() as $key => $it ) {
		$pid  = (int) $it['product_id'];
		$prod = $it['data'];
		$img  = $prod ? wp_get_attachment_image_url( $prod->get_image_id(), 'woocommerce_thumbnail' ) : '';
		$is_set = ! empty( $it['rwz_components'] ) || ( function_exists( 'rwz_get_slots' ) && rwz_get_slots( $pid ) );
		if ( $is_set && function_exists( 'rwz_split_image_html' ) ) { // 2.26.22: zdjęcie dzielone zestawu
			$split = rwz_split_image_html( $pid, 'woocommerce_thumbnail', array(), true );
			$img   = $split ? $split : $img;
		}
		$comps  = array();
		if ( $is_set ) {
			$active = function_exists( 'rwz_get_active_components' ) ? rwz_get_active_components( $pid ) : array();
			if ( ! empty( $active['main'] ) ) {
				foreach ( $active['main'] as $c ) {
					if ( (int) $c->get_id() === $pid ) {
						continue;
					}
					$comps[] = array(
						'id'    => (int) $c->get_id(),
						'name'  => $c->get_name(),
						'img'   => wp_get_attachment_image_url( $c->get_image_id(), 'thumbnail' ) ?: '',
						'sklad' => rzd_review_names( $c->get_id() ),
					);
				}
			} elseif ( ! empty( $it['rwz_components'] ) ) {
				foreach ( (array) $it['rwz_components'] as $n ) {
					$comps[] = array( 'name' => wp_strip_all_tags( $n ), 'img' => '', 'sklad' => array() );
				}
			}
		}
		// 2.26.18: „Wybór w zestawie” (wybór bez wpływu na cenę, np. Frytki) dopisujemy do
		// składu – zwykłe danie: do jego składu; zestaw: do składu dania, z którego pochodzi
		// wybór (src w linii; pozycje sprzed 2.26.18 bez src zostają w modyfikacjach).
		// Dopłaty, „Bez” i obowiązkowe zostają jako osobne linie.
		$rest   = array();
		$sk_add = array(); // klucz: 0 = samo danie, id = danie zestawu
		foreach ( ! empty( $it['rzd_mods'] ) ? (array) $it['rzd_mods'] : array() as $l ) {
			$role = isset( $l['role'] ) ? $l['role'] : 'dodaje';
			$kind = ! empty( $l['kind'] ) ? $l['kind'] : ( 'tekst' === $role ? '' : rzd_mod_kind( $role, isset( $l['price'] ) ? $l['price'] : 0 ) );
			// 2.26.19: także KAŻDY pojedynczy wybór (pick), z dopłatą lub odjęciem – np. „Bez dodatków”
			// z wymaganego wyboru to też skład; kwota w nawiasie, żeby klient widział zmianę ceny.
			$pick = ! empty( $l['pick'] );
			if ( 'tekst' === $role || ( 'zestaw' !== $kind && ! $pick ) ) {
				$rest[] = $l;
				continue;
			}
			$q    = isset( $l['qty'] ) ? (int) $l['qty'] : 1;
			$name = ( $q > 1 ? $q . '× ' : '' ) . $l['name'] . ( 'zestaw' === $kind ? '' : rzd_format_delta( isset( $l['price'] ) ? $l['price'] : 0 ) );
			if ( ! $is_set ) {
				$sk_add[0][] = $name;
			} elseif ( ! empty( $l['src'] ) ) {
				$sk_add[ (int) $l['src'] ][] = $name;
			} else {
				$rest[] = $l;
			}
		}
		$add_to = function ( $list, $extra ) {
			$low = array_map( 'mb_strtolower', $list );
			foreach ( $extra as $n ) {
				if ( ! in_array( mb_strtolower( $n ), $low, true ) ) {
					$list[] = $n;
					$low[]  = mb_strtolower( $n );
				}
			}
			return $list;
		};
		$sklad = $is_set ? array() : rzd_review_names( $pid );
		if ( ! empty( $sk_add[0] ) ) {
			$sklad = $add_to( $sklad, $sk_add[0] );
		}
		if ( $is_set ) {
			foreach ( $comps as $ci => $c ) {
				if ( ! empty( $c['id'] ) && ! empty( $sk_add[ $c['id'] ] ) ) {
					$comps[ $ci ]['sklad'] = $add_to( $c['sklad'], $sk_add[ $c['id'] ] );
					unset( $sk_add[ $c['id'] ] );
				}
			}
			// wybór z dania, którego nie ma na liście dań (inny termin) – nie gubimy go
			foreach ( $sk_add as $sid => $names ) {
				if ( $sid ) {
					foreach ( $names as $n ) {
						$rest[] = array( 'name' => $n, 'label' => $n, 'price' => 0, 'role' => 'neutralna', 'qty' => 1, 'kind' => 'zestaw' );
					}
				}
			}
		}
		$mods = array();
		if ( $rest ) {
			foreach ( rzd_group_mod_lines_for_display( $rest ) as $l ) {
				$mods[] = array( 'k' => $l['key'], 'v' => wp_strip_all_tags( html_entity_decode( $l['value'], ENT_QUOTES, 'UTF-8' ) ) );
			}
		}
		$items[] = array(
			'key'     => $key,
			'qty'     => (int) $it['quantity'],
			'name'    => $prod ? $prod->get_name() : get_the_title( $pid ),
			'img'     => $img ?: '',
			'sklad'   => $sklad,
			'comps'   => $comps,
			'mods'    => $mods,
			'total'   => wc_price( (float) $it['line_subtotal'] + (float) $it['line_subtotal_tax'] ),
			// Zestaw też (od decyzji 2.26.16): okno pokazuje grupy „w koszyku” jego dań, każda sekcja
			// pod nazwą dania. Dodatki zestawu jako osobne pozycje (rwz_child_of) – bez przycisku.
			'can_add' => empty( $it['rwz_child_of'] ) && isset( $it['rzd_raw'] ) && rzd_product_has_cart_groups( $pid ),
		);
	}
	$sum   = array();
	$total = (float) $cart->get_subtotal() + (float) $cart->get_subtotal_tax();
	$sum[] = array( 'label' => 'Produkty', 'value' => wc_price( $total ) );
	foreach ( $cart->get_fees() as $fee ) {
		$v      = (float) $fee->total + (float) $fee->tax;
		$total += $v;
		$sum[]  = array( 'label' => $fee->name, 'value' => wc_price( $v ) );
	}
	$disc = (float) $cart->get_discount_total() + (float) $cart->get_discount_tax();
	if ( $disc > 0 ) {
		$total -= $disc;
		$sum[]  = array( 'label' => 'Rabat', 'value' => wc_price( -1 * $disc ) );
	}
	wp_send_json( array(
		'ok'      => true,
		'items'   => $items,
		'summary' => $sum,
		'total'   => wc_price( $total ),
	) );
} );

// 2.26.13: skrypt okienka modyfikacji jako plik (wcześniej w stopce każdej strony).
add_action( 'wp_enqueue_scripts', function () {
	$products = rzd_products_with_modifiers();
	if ( ! $products ) {
		return;
	}
	wp_enqueue_script( 'rzd-modyfikacje', RZD_PLUGIN_URL . 'assets/js/rzd-modyfikacje.js', array(), rzd_asset_ver( 'assets/js/rzd-modyfikacje.js' ), array( 'in_footer' => true, 'strategy' => 'defer' ) );
	wp_add_inline_script( 'rzd-modyfikacje', 'var rzdMods = ' . wp_json_encode( array( 'url' => WC_AJAX::get_endpoint( 'rzd_mods' ), 'save' => WC_AJAX::get_endpoint( 'rzd_mods_save' ), 'nonce' => wp_create_nonce( 'rzd_mods_save' ), 'review' => WC_AJAX::get_endpoint( 'rzd_review' ), 'rvRemove' => WC_AJAX::get_endpoint( 'rzd_review_remove' ), 'rvRestore' => WC_AJAX::get_endpoint( 'rzd_review_restore' ), 'cartUrl' => wc_get_cart_url(), 'cartBtn' => (bool) apply_filters( 'rzd_cart_edit_button', false ), 'products' => array_values( $products ) ) ) . ';', 'before' );
} );

add_action( 'wp_footer', function () {
	if ( is_admin() ) {
		return;
	}
	$products = rzd_products_with_modifiers();
	if ( ! $products ) {
		return;
	}
	?>
	<style>
		#rzd-mods{position:fixed;inset:0;z-index:100001;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.5);padding:16px}
		#rzd-mods[hidden]{display:none}
		#rzd-mods .rzd-panel{color:#222;border:2px solid #000;border-radius:12px;max-width:480px;width:100%;padding:20px;box-shadow:0 10px 40px rgba(0,0,0,.3);max-height:90vh;overflow:auto;position:relative}
		#rzd-mods h3{margin:0 0 10px;color:#222}
		/* 2.26.20: pasek tytułu z ✕ – przyklejony do góry przy przewijaniu (jak w przeglądzie zamówienia) */
		#rzd-mods .rzd-head{position:sticky;top:-20px;z-index:3;display:flex;align-items:center;gap:12px;margin:-20px -20px 12px;padding:14px 14px 10px 20px;background:#fff;border-radius:10px 10px 0 0}
		#rzd-mods .rzd-head h3{flex:1;min-width:0;margin:0 !important}
		#rzd-mods .rzd-x{flex:0 0 36px;width:36px;height:36px;margin:0;padding:0;border:1.5px solid #222;border-radius:50%;background:#fff;color:#2b2b2b;font-size:16px;line-height:1;cursor:pointer;display:flex;align-items:center;justify-content:center;box-shadow:none}
		#rzd-mods .rzd-section-block{margin:0 0 22px;padding-bottom:14px;border-bottom:1px solid #ddd}
		#rzd-mods .rzd-section-header{font-weight:700;font-size:15px;margin-bottom:2px}
		#rzd-mods .rzd-section-desc{font-size:12px;color:#666;margin-bottom:10px}
		#rzd-mods .rzd-g{margin:0 0 18px}
		#rzd-mods .rzd-tap-icon{width:32px;height:32px;object-fit:contain;display:block;margin:0 auto 4px}
		#rzd-mods .rzd-gh{font-weight:700;margin-bottom:6px;color:#222}
		#rzd-mods .rzd-squares{display:flex;flex-wrap:wrap;gap:8px}
		#rzd-mods .rzd-square{min-width:84px;padding:14px 10px;border:2px solid #ccc;border-radius:10px;background:#fff;color:#222;text-align:center;cursor:pointer;font-size:13px;line-height:1.3}
		#rzd-mods .rzd-square-icon{width:36px;height:36px;object-fit:contain;margin-bottom:4px}
		#rzd-mods .rzd-square.rzd-on{border-color:#222;background:#222;color:#fff}
		#rzd-mods .rzd-square small{display:block;opacity:.75;margin-top:4px}
		#rzd-mods .rzd-tap{width:100%;padding:16px;border:2px solid #ccc;border-radius:10px;background:#fff;color:#222;cursor:pointer;font-size:14px;font-weight:600;text-align:center}
		#rzd-mods .rzd-tap.rzd-on{border-color:#222;background:#222;color:#fff}
		#rzd-mods button:disabled, #rzd-mods .rzd-square.rzd-locked, #rzd-mods input:disabled { opacity:.4 !important; cursor:not-allowed !important; }
		#rzd-mods .rzd-lock-note{font-size:11px;color:#888;margin-top:4px}
		#rzd-mods .rzd-row{display:flex;align-items:center;gap:8px}
		#rzd-mods .rzd-row input[type=text]{flex:1;padding:8px;color:#222}
		#rzd-mods .rzd-picked{margin:-8px 0 14px;font-size:13px;line-height:1.5}
		#rzd-mods .rzd-picked div{margin:2px 0}
		#rzd-mods .rzd-summary{background:#f6f6f6;border-top:1px solid #ddd;border-bottom:1px solid #ddd;margin:14px -20px 16px;padding:12px 20px;display:flex;justify-content:space-between;align-items:center;font-weight:700}
		/* Przyciski na dole: wspólny wygląd okienek z panelu „Wygląd listy” (rzd_popup_css, moduł 15) – od 2.25.3. */
		#rzd-mods .rzd-stepper{display:flex;align-items:center;gap:10px;justify-content:space-between}
		#rzd-mods .rzd-stepper-icon{width:40px;height:40px;object-fit:contain;border-radius:8px;flex:0 0 auto}
		#rzd-mods .rzd-stepper-label{flex:1;font-size:14px}
		#rzd-mods .rzd-stepper-ctrl{display:flex;align-items:center;gap:10px;flex:0 0 auto}
		#rzd-mods .rzd-stepper-btn{width:36px;height:36px;border-radius:50%;border:2px solid #222;background:transparent;color:#222;font-size:22px;font-weight:700;line-height:1;padding:0;display:inline-flex;align-items:center;justify-content:center;cursor:pointer}
		#rzd-mods .rzd-stepper-btn:hover{background:#222;color:#fff}
		#rzd-mods .rzd-stepper-qty{min-width:20px;text-align:center;font-weight:700}
		/* 2.26.16: „Zawiera już”, dodatkowa porcja, wybór sztuk, przycisk w koszyku */
		#rzd-mods .rzd-has{margin:-2px 0 10px}
		#rzd-mods .rzd-has strong{font-weight:700}
		#rzd-mods .rzd-has-note{font-size:12px;margin-top:4px}
		#rzd-mods .rzd-split{margin:0 0 14px;font-size:14px}
		#rzd-mods .rzd-split label{display:flex;align-items:center;gap:8px;margin:4px 0;cursor:pointer}
		#rzd-mods .rzd-err{color:#c00;font-size:13px;margin:0 0 10px}
		li[class*="product-details__rzd-edit"],dt.variation-rzd-edit,dd.variation-rzd-edit{display:none!important}
		.rzd-edit-btn{display:inline-block;margin:6px 0 2px;padding:6px 14px;border:1.5px solid currentColor;border-radius:8px;background:transparent;color:inherit;font-size:13px;font-weight:600;line-height:1.3;cursor:pointer}
		.rzd-edit-btn:hover{opacity:.75}
	</style>
	<div id="rzd-mods" hidden>
		<div class="rzd-panel" role="dialog" aria-modal="true">
			<div class="rzd-head"><h3>Dostosuj produkt</h3><button type="button" class="rzd-x" aria-label="Zamknij">✕</button></div>
			<div class="rzd-groups"></div>
			<div class="rzd-summary"><span>Dopłata</span><span class="rzd-total">bez dopłaty</span></div>
			<div class="rzd-picked"></div>
			<div class="rzd-actions">
				<div class="rzd-act"><button type="button" class="rzd-cancel">Anuluj</button></div>
				<div class="rzd-act"><button type="button" class="rzd-ok">Dodaj do koszyka</button></div>
			</div>
		</div>
	</div>
	<?php // 2.26.16: przegląd zamówienia – wygląd w module 15 (rzd_popup_css). ?>
	<div id="rzd-review" hidden>
		<div class="dc-panel" role="dialog" aria-modal="true" aria-labelledby="rzd-rv-title">
			<div class="rzd-rv-head"><h3 id="rzd-rv-title">Sprawdź zamówienie</h3><button type="button" class="rzd-rv-x" aria-label="Zamknij">✕</button></div>
			<div class="rzd-rv-list"></div>
			<div class="rzd-rv-foot">
				<div class="rzd-rv-sum"></div>
				<div class="dc-actions"><div class="dc-act"><button type="button" class="dc-ok rzd-rv-go">Potwierdź i przejdź do koszyka</button></div></div>
			</div>
		</div>
	</div>
	
	<?php
} );
