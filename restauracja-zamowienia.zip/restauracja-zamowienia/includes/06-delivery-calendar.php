<?php
/**
 * SNIPPET 6: DeliveryCalendar – termin dostawy wybierany PRZED zakupem
 * Code Snippets → Run everywhere (pomiń pierwszą linię "<?php")
 *
 * JAK TO DZIAŁA
 * - Nowa pozycja w menu admina: "DeliveryCalendar". Dla każdej grupy (kategorii
 *   produktów) ustawiasz: godziny wyjazdu, cutoff dzienny (godzina + ile dni
 *   przed dostawą), min. czas przed wyjazdem, dni dostaw, horyzont i dni wolne.
 * - Matryca "Godziny dostaw w dniach tygodnia" (od 2.18.0): dla każdej grupy
 *   i dla wszystkich grup naraz przedział "od–do" godzin dostawy w danym dniu
 *   tygodnia. Obowiązuje węższy z nich (późniejszy początek, wcześniejszy
 *   koniec) – patrz dc_window_for_date().
 * - Produkt musi należeć do grupy (kategorii) z zapisanym kalendarzem – bez tego
 *   nie da się go zamówić. Podkategoria dziedziczy kalendarz kategorii nadrzędnej.
 * - Klient klikając PIERWSZY produkt musi wybrać datę i godzinę dostawy.
 *   Domyślnie zaznaczony jest najwcześniejszy możliwy termin dla tego produktu.
 * - Każdy kolejny produkt musi się dać dostarczyć w tym terminie – inaczej
 *   dodanie jest blokowane z komunikatem. Termin można zmienić (przycisk
 *   "Zmień termin") – widać wtedy tylko terminy pasujące do WSZYSTKICH
 *   produktów w koszyku.
 * - Dostępność produktu w dniu dostawy: zestawy (snippet 4) i ich składowe
 *   sprawdzane są po dniu (bez godzin). Dla zwykłych produktów z własną datą
 *   ważności podepnij swój kod pod filtr 'dc_product_available_on'.
 * - Termin zapisuje się w zamówieniu (panel, maile, strona zamówienia).
 *
 * Wymaga snippetu 8 (brama dodawania do koszyka), który uruchamia okno wyboru terminu.
 * Shortcode [wybierz_date_dostawy] wstawia przycisk otwierający wybór daty dostawy.
 *
 * Nic nie działa, dopóki nie zaznaczysz "Włącz wybór terminu dostawy"
 * na stronie DeliveryCalendar – możesz spokojnie wgrać i skonfigurować.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 0. USTAWIENIA
 * ============================================================ */
function dc_days() {
	return array( 'Mon' => 'Pon', 'Tue' => 'Wt', 'Wed' => 'Śr', 'Thu' => 'Czw', 'Fri' => 'Pt', 'Sat' => 'Sob', 'Sun' => 'Ndz' );
}

function dc_default_group() {
	return array(
		'times'   => array(),
		'cutoff'  => '',
		'cutoff_days' => 0, // ile dni PRZED dniem dostawy obowiązuje godzina cutoffu (0 = w dniu dostawy)
		'lead'    => 0,
		'days'    => array_keys( dc_days() ),
		'horizon' => 7,
		'blocked' => array(),
		'valid_from' => '',
		'valid_to'   => '',
		'window'     => array(), // matryca: [ 'Mon' => [ 'from' => 'HH:MM', 'to' => 'HH:MM' ], … ]
	);
}

function dc_get_settings() {
	static $cache = null;
	if ( null !== $cache ) {
		return $cache;
	}
	$s = get_option( 'dc_settings', array() );
	$s = is_array( $s ) ? $s : array();
	$s = wp_parse_args( $s, array( 'enabled' => 0, 'global_blocked' => array(), 'groups' => array(), 'max_per_slot' => 6, 'global_window' => array(), 'off_days' => array(), 'win_on' => 0, 'win_defs' => array(), 'win_days' => array(), 'win_next' => 1 ) );

	$groups = array();
	foreach ( (array) $s['groups'] as $term_id => $g ) {
		$groups[ (int) $term_id ] = wp_parse_args( (array) $g, dc_default_group() );
	}
	$s['groups'] = $groups;

	$cache = $s;
	return $cache;
}

function dc_enabled() {
	if ( is_admin() && ! wp_doing_ajax() ) {
		return false;
	}
	$s = dc_get_settings();
	return ! empty( $s['enabled'] );
}

function dc_max_horizon() {
	$s   = dc_get_settings();
	$max = 0;
	foreach ( $s['groups'] as $g ) {
		$max = max( $max, (int) $g['horizon'] );
	}
	return min( 60, $max );
}

/* --- czyszczenie danych z formularza --- */
function dc_clean_time( $t ) {
	$t = sanitize_text_field( (string) $t );
	return preg_match( '/^([01]\d|2[0-3]):[0-5]\d$/', $t ) ? $t : '';
}

function dc_parse_times( $text ) {
	$out = array();
	foreach ( preg_split( '/[\s,;]+/', (string) $text, -1, PREG_SPLIT_NO_EMPTY ) as $t ) {
		if ( preg_match( '/^(\d{1,2}):(\d{2})$/', $t, $m ) && (int) $m[1] < 24 && (int) $m[2] < 60 ) {
			$out[] = sprintf( '%02d:%02d', $m[1], $m[2] );
		}
	}
	$out = array_values( array_unique( $out ) );
	sort( $out );
	return $out;
}

function dc_parse_dates( $text ) {
	$out = array();
	foreach ( preg_split( '/[\s,;]+/', (string) $text, -1, PREG_SPLIT_NO_EMPTY ) as $d ) {
		if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $d ) ) {
			$out[] = $d;
		}
	}
	$out = array_values( array_unique( $out ) );
	sort( $out );
	return $out;
}

// $g musi być już po wp_unslash()
function dc_sanitize_group( $g ) {
	$g    = is_array( $g ) ? $g : array();
	$days = isset( $g['days'] )
		? array_values( array_intersect( array_map( 'sanitize_text_field', (array) $g['days'] ), array_keys( dc_days() ) ) )
		: array();
	return array(
		'times'   => dc_parse_times( isset( $g['times'] ) ? $g['times'] : '' ),
		'cutoff'  => isset( $g['cutoff'] ) ? dc_clean_time( $g['cutoff'] ) : '',
		'cutoff_days' => isset( $g['cutoff_days'] ) ? max( 0, min( 60, absint( $g['cutoff_days'] ) ) ) : 0,
		'lead'    => isset( $g['lead'] ) ? max( 0, min( 1440, absint( $g['lead'] ) ) ) : 0,
		'days'    => $days,
		'horizon' => isset( $g['horizon'] ) ? max( 0, min( 60, absint( $g['horizon'] ) ) ) : 7,
		'blocked' => dc_parse_dates( isset( $g['blocked'] ) ? $g['blocked'] : '' ),
		'valid_from' => ( isset( $g['valid_from'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $g['valid_from'] ) ) ? $g['valid_from'] : '',
		'valid_to'   => ( isset( $g['valid_to'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $g['valid_to'] ) ) ? $g['valid_to'] : '',
	);
	// 'window' (matryca) celowo NIE jest tu czytane – zapisuje ją osobny
	// formularz matrycy; zapis grupy przenosi starą wartość (dc_save_group).
}

// Matryca "od–do" jednego wiersza: [ 'All' => […], 'Mon' => [ 'from' => '', 'to' => '' ], … ]
// 'All' = kolumna "Wszystkie dni" (dotyczy każdego dnia tygodnia tego wiersza).
function dc_sanitize_window( $w ) {
	$w   = is_array( $w ) ? $w : array();
	$out = array();
	foreach ( array_merge( array( 'All' ), array_keys( dc_days() ) ) as $d ) {
		$from = isset( $w[ $d ]['from'] ) ? dc_clean_time( $w[ $d ]['from'] ) : '';
		$to   = isset( $w[ $d ]['to'] ) ? dc_clean_time( $w[ $d ]['to'] ) : '';
		if ( '' !== $from || '' !== $to ) {
			$out[ $d ] = array( 'from' => $from, 'to' => $to );
		}
	}
	return $out;
}

/* ============================================================
 * 0b. OKNA DOSTAW (2.25.0)
 *
 * Okno = nazwa + długość (min) + pojemność (punkty). Okna są wspólne dla
 * wszystkich grup (jeden kurier, jeden kurs). Każdy dzień tygodnia ma
 * znacznik „dostawa”, godzinę startu i kolejność okien – jedno po drugim,
 * bez przerw. Godzina wyjazdu terminu = start okna, więc zamówienia,
 * Kuchnia, Kurier i maile działają na tych samych danych co wcześniej.
 *
 * Tryb włącza się świadomie (dc_settings['win_on']). Wyłączony albo pusty
 * katalog = wszystko po staremu na godzinach wyjazdu grup ('times').
 *
 * Grupa obsługuje okna w swoim zakresie „od–do” z matrycy: początek
 * zaokrąglany W GÓRĘ do startu okna (okno zaczęte przed grupą odpada),
 * koniec W DÓŁ do końca okna (okno kończące się po grupie odpada).
 *
 * Pojemność: suma punktów zamówień terminu (punkty miejscowości, moduł 20)
 * + punkty klienta ≤ pojemność okna.
 * ============================================================ */
function dc_windows_on() {
	$s = dc_get_settings();
	return ! empty( $s['win_on'] ) && ! empty( $s['win_defs'] ) && is_array( $s['win_defs'] );
}

function dc_win_defs() {
	$s = dc_get_settings();
	return ( isset( $s['win_defs'] ) && is_array( $s['win_defs'] ) ) ? $s['win_defs'] : array();
}

// Ustawienie dnia tygodnia: [ 'on' => 0/1, 'start' => 'HH:MM', 'seq' => [ id, … ] ]
function dc_win_day( $dow ) {
	$s   = dc_get_settings();
	$day = ( isset( $s['win_days'][ $dow ] ) && is_array( $s['win_days'][ $dow ] ) ) ? $s['win_days'][ $dow ] : array();
	return wp_parse_args( $day, array( 'on' => 0, 'start' => '', 'seq' => array() ) );
}

function dc_hm_to_min( $t ) {
	return preg_match( '/^(\d{2}):(\d{2})$/', (string) $t, $m ) ? ( (int) $m[1] * 60 + (int) $m[2] ) : -1;
}

function dc_min_to_hm( $m ) {
	$m = max( 0, (int) $m );
	return sprintf( '%02d:%02d', floor( $m / 60 ), $m % 60 );
}

/**
 * Oś jednego dnia tygodnia: lista okien [ id, name, start, end, len, cap ].
 * Okno, które skończyłoby się po północy, i wszystkie po nim – pomijane
 * (panel ostrzega). Wynik nie zależy od daty, tylko od dnia tygodnia.
 */
function dc_windows_for_dow( $dow ) {
	static $memo = array();
	if ( isset( $memo[ $dow ] ) ) {
		return $memo[ $dow ];
	}
	$out  = array();
	$day  = dc_win_day( $dow );
	$defs = dc_win_defs();
	$cur  = dc_hm_to_min( $day['start'] );
	if ( ! empty( $day['on'] ) && $cur >= 0 ) {
		foreach ( (array) $day['seq'] as $id ) {
			if ( ! isset( $defs[ $id ] ) ) {
				continue;
			}
			$len = max( 5, (int) $defs[ $id ]['len'] );
			if ( $cur + $len > 1440 ) {
				break;
			}
			$out[] = array(
				'id'    => $id,
				'name'  => $defs[ $id ]['name'],
				'start' => dc_min_to_hm( $cur ),
				'end'   => dc_min_to_hm( $cur + $len ),
				'len'   => $len,
				'cap'   => max( 1, (int) $defs[ $id ]['cap'] ),
			);
			$cur += $len;
		}
	}
	$memo[ $dow ] = $out;
	return $out;
}

function dc_windows_for_date( $date ) {
	if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $date ) ) {
		return array();
	}
	return dc_windows_for_dow( ( new DateTime( $date, wp_timezone() ) )->format( 'D' ) );
}

// Okno zaczynające się o $time w dniu $date – albo null.
function dc_window_at( $date, $time ) {
	foreach ( dc_windows_for_date( $date ) as $w ) {
		if ( $w['start'] === $time ) {
			return $w;
		}
	}
	return null;
}

/**
 * Godziny wyjazdu grupy w danym dniu – BEZ cutoffów, horyzontu i pojemności.
 * Tryb okien: starty okien w zakresie grupy z matrycy (zaokrąglanie jak
 * w opisie wyżej). Tryb stary: 'times' grupy przycięte matrycą.
 */
function dc_group_times( $cal, $date ) {
	list( $w_from, $w_to ) = dc_window_for_date( $cal, $date );
	if ( dc_windows_on() ) {
		$times = array();
		foreach ( dc_windows_for_date( $date ) as $w ) {
			if ( ( '' === $w_from || $w['start'] >= $w_from ) && ( '' === $w_to || $w['end'] <= $w_to ) ) {
				$times[] = $w['start'];
			}
		}
		return $times;
	}
	$times = array_values( (array) ( isset( $cal['times'] ) ? $cal['times'] : array() ) );
	if ( '' !== $w_from || '' !== $w_to ) {
		$times = array_values( array_filter( $times, function ( $t ) use ( $w_from, $w_to ) {
			return ( '' === $w_from || $t >= $w_from ) && ( '' === $w_to || $t <= $w_to );
		} ) );
	}
	return $times;
}

// Czy grupa w ogóle ma tę godzinę wyjazdu tego dnia (do cutoffów w Kuchni).
function dc_group_has_time( $cal, $date, $time ) {
	if ( dc_windows_on() ) {
		return in_array( $time, dc_group_times( $cal, $date ), true );
	}
	return ! empty( $cal['times'] ) && in_array( $time, (array) $cal['times'], true );
}

/* --- Punkty i pojemność (tryb okien) --- */

// Punkty zapisanego zamówienia: meta _rzd_points (od 2.25.0), a dla starszych
// zamówień – punkty jego miejscowości z matrycy, a bez niej 1.
function dc_order_points( $order ) {
	$p = $order->get_meta( '_rzd_points' );
	if ( '' !== $p && is_numeric( $p ) ) {
		return max( 0, (int) $p );
	}
	if ( function_exists( 'rzd_town_points' ) ) {
		$town = (string) $order->get_meta( '_rzd_town' );
		if ( '' !== $town ) {
			return rzd_town_points( $town );
		}
	}
	return 1;
}

// Ile punktów zajmie klient: punkty miejscowości (wpisanej albo z sesji), bez miejscowości 1.
function dc_customer_points( $town = null ) {
	if ( function_exists( 'rzd_towns_enabled' ) && rzd_towns_enabled() && function_exists( 'rzd_town_points' ) ) {
		$name = ( null === $town ) ? rzd_session_town() : $town;
		if ( '' !== trim( (string) $name ) ) {
			return rzd_town_points( $name );
		}
	}
	return 1;
}

function dc_slot_capacity( $date, $time ) {
	$w = dc_window_at( $date, $time );
	return $w ? (int) $w['cap'] : 0;
}

// Czy w oknie zmieszczą się jeszcze $need punkty. Stary tryb – zawsze tak
// (tam limit liczy dc_calendar_times_for_date po liczbie zamówień).
function dc_slot_has_room( $date, $time, $need ) {
	if ( ! dc_windows_on() ) {
		return true;
	}
	$w = dc_window_at( $date, $time );
	if ( ! $w ) {
		return false;
	}
	return dc_orders_points_for_slot( $date, $time ) + max( 0, (int) $need ) <= (int) $w['cap'];
}

// Terminy [ 'Y-m-d' => [ 'HH:MM' ] ] bez okien, w których brak miejsca na $need punktów.
function dc_filter_slots_by_room( $slots, $need ) {
	if ( ! dc_windows_on() ) {
		return $slots;
	}
	$out = array();
	foreach ( $slots as $date => $times ) {
		$ok = array_values( array_filter( (array) $times, function ( $t ) use ( $date, $need ) {
			return dc_slot_has_room( $date, $t, $need );
		} ) );
		if ( $ok ) {
			$out[ $date ] = $ok;
		}
	}
	return $out;
}

/* --- Siatka slotów do Planowania (2.25.0, etap 2) ---
 * Okno dzielone na tyle slotów, ile ma punktów: krok = długość / pojemność,
 * godziny zaokrąglane do minuty (60/8 → :00, :08, :15, :23…). Zamówienie za
 * N punktów zajmuje N kolejnych slotów, a jego godzina dostawy = pierwszy
 * slot. Gdy okno jest przeładowane (np. „Nowy termin” z Kuchni), siatka
 * wydłuża się tym samym krokiem za koniec okna, żeby każdy dostał godzinę.
 * Zamówienie za 0 pkt (odbiór) może mieć dowolny slot i niczego nie zajmuje. */
function dc_plan_slot_time( $w, $k ) {
	$step = max( 1, (int) $w['len'] / max( 1, (int) $w['cap'] ) );
	return dc_min_to_hm( dc_hm_to_min( $w['start'] ) + (int) round( $k * $step ) );
}

/**
 * $orders = wszystkie zamówienia terminu. $exclude_id = zamówienie, dla
 * którego liczymy wolne miejsca (jego własny slot nie przeszkadza).
 * Zwraca null poza trybem okien albo dla godziny, która nie jest oknem.
 */
function dc_plan_grid( $date, $time, $orders, $exclude_id = 0 ) {
	if ( ! dc_windows_on() ) {
		return null;
	}
	$w = dc_window_at( $date, $time );
	if ( ! $w ) {
		return null;
	}
	$used = 0;
	foreach ( $orders as $o ) {
		$used += dc_order_points( $o );
	}
	$n     = max( (int) $w['cap'], $used );
	$slots = array();
	for ( $k = 0; $k < $n; $k++ ) {
		$slots[ $k ] = dc_plan_slot_time( $w, $k );
	}
	$occ       = array(); // indeks slotu => id zamówienia
	$conflicts = array(); // opisy nakładań
	$offgrid   = array(); // numery zamówień z godziną spoza siatki
	foreach ( $orders as $o ) {
		if ( (int) $o->get_id() === (int) $exclude_id ) {
			continue;
		}
		$pt = (string) $o->get_meta( '_dc_planned_time' );
		if ( '' === $pt ) {
			continue;
		}
		$idx = array_search( $pt, $slots, true );
		if ( false === $idx ) {
			$offgrid[] = $o->get_order_number();
			continue;
		}
		$p = dc_order_points( $o );
		for ( $j = $idx; $j < $idx + $p; $j++ ) {
			if ( isset( $occ[ $j ] ) && $occ[ $j ] !== (int) $o->get_id() ) {
				$other       = wc_get_order( $occ[ $j ] );
				$conflicts[] = '#' . $o->get_order_number() . ' nachodzi na #' . ( $other ? $other->get_order_number() : $occ[ $j ] );
				break;
			}
			$occ[ $j ] = (int) $o->get_id();
		}
	}
	return array(
		'win'       => $w,
		'cap'       => (int) $w['cap'],
		'used'      => $used,
		'slots'     => $slots,
		'occ'       => $occ,
		'conflicts' => array_values( array_unique( $conflicts ) ),
		'offgrid'   => $offgrid,
	);
}

// Godziny, od których zamówienie się zmieści: [ 'HH:MM' => etykieta ].
function dc_plan_options( $grid, $order ) {
	$out = array();
	if ( ! $grid ) {
		return $out;
	}
	$p = dc_order_points( $order );
	$n = count( $grid['slots'] );
	for ( $i = 0; $i < $n; $i++ ) {
		if ( $p > 0 && $i + $p > $n ) {
			break;
		}
		$free = true;
		for ( $j = $i; $j < $i + $p; $j++ ) {
			if ( isset( $grid['occ'][ $j ] ) ) {
				$free = false;
				break;
			}
		}
		if ( ! $free ) {
			continue;
		}
		$t     = $grid['slots'][ $i ];
		$label = $t;
		if ( $p > 1 ) {
			$label .= '–' . dc_plan_slot_time( $grid['win'], $i + $p );
		}
		if ( $i + max( 1, $p ) > $grid['cap'] ) {
			$label .= ' (po oknie)';
		}
		$out[ $t ] = $label;
	}
	return $out;
}

/* ============================================================
 * 1. PANEL ADMINA: menu "DeliveryCalendar"
 *    Każda grupa ma własny formularz i zapisuje się niezależnie.
 * ============================================================ */
add_action( 'admin_menu', function () {
	add_menu_page( 'DeliveryCalendar', 'DeliveryCalendar', 'manage_woocommerce', 'delivery-calendar', 'dc_render_admin_page', 'dashicons-calendar-alt', 56 );
} );

function dc_raw_settings() {
	$s = get_option( 'dc_settings', array() );
	return is_array( $s ) ? $s : array();
}

function dc_admin_guard() {
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		wp_die( 'Brak uprawnień.' );
	}
	$nonce = isset( $_POST['dc_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['dc_nonce'] ) ) : '';
	if ( ! wp_verify_nonce( $nonce, 'dc_save' ) ) {
		wp_die( 'Formularz wygasł – odśwież stronę DeliveryCalendar i spróbuj ponownie.' );
	}
}

function dc_admin_redirect( $args = array() ) {
	wp_safe_redirect( add_query_arg( array_merge( array( 'page' => 'delivery-calendar' ), $args ), admin_url( 'admin.php' ) ) );
	exit;
}

// Ustawienia ogólne: włączenie + dni bez dostaw dla wszystkich grup
add_action( 'admin_post_dc_save_general', function () {
	dc_admin_guard();
	$post = wp_unslash( $_POST );
	$s    = dc_raw_settings();

	$s['enabled']        = empty( $post['dc_enabled'] ) ? 0 : 1;
	$s['global_blocked'] = dc_parse_dates( isset( $post['dc_global_blocked'] ) ? $post['dc_global_blocked'] : '' );
	$s['max_per_slot']   = isset( $post['dc_max_per_slot'] ) ? max( 1, absint( $post['dc_max_per_slot'] ) ) : 6;
	update_option( 'dc_settings', $s, true );
	dc_clear_slots_cache();

	dc_admin_redirect( array( 'saved' => 'general' ) );
} );

// Zapis JEDNEJ grupy
add_action( 'admin_post_dc_save_group', function () {
	dc_admin_guard();
	$post    = wp_unslash( $_POST );
	$term_id = isset( $post['term_id'] ) ? absint( $post['term_id'] ) : 0;
	if ( ! $term_id || ! term_exists( $term_id, 'product_cat' ) ) {
		wp_die( 'Nieprawidłowa grupa.' );
	}

	$s      = dc_raw_settings();
	$groups = ( isset( $s['groups'] ) && is_array( $s['groups'] ) ) ? $s['groups'] : array();
	$g      = dc_sanitize_group( isset( $post['dc_g'] ) ? $post['dc_g'] : array() );
	// matryca godzin tej grupy zapisuje się osobnym formularzem – nie gubimy jej
	$g['window'] = ( isset( $groups[ $term_id ]['window'] ) && is_array( $groups[ $term_id ]['window'] ) ) ? $groups[ $term_id ]['window'] : array();

	$groups[ $term_id ] = $g;
	$s['groups']        = $groups;
	update_option( 'dc_settings', $s, true );
	dc_clear_slots_cache();

	$args = array( 'saved' => 'group', 'open' => $term_id );
	if ( empty( $g['times'] ) ) {
		$args['empty'] = 1;
	}
	dc_admin_redirect( $args );
} );

// Zapis matrycy "Godziny dostaw w dniach tygodnia" (wszystkie grupy + wiersz globalny)
add_action( 'admin_post_dc_save_matrix', function () {
	dc_admin_guard();
	$post = wp_unslash( $_POST );
	$w    = ( isset( $post['dc_w'] ) && is_array( $post['dc_w'] ) ) ? $post['dc_w'] : array();
	$s    = dc_raw_settings();

	$s['global_window'] = dc_sanitize_window( isset( $w['global'] ) ? $w['global'] : array() );
	// Wiersz "Dostawy wyłączone": dni tygodnia bez dostaw we wszystkich grupach.
	$s['off_days'] = array_values( array_intersect( (array) ( isset( $post['dc_off_days'] ) ? $post['dc_off_days'] : array() ), array_keys( dc_days() ) ) );
	if ( isset( $s['groups'] ) && is_array( $s['groups'] ) ) {
		foreach ( $s['groups'] as $term_id => $g ) {
			// tylko grupy z zapisanym kalendarzem mają wiersz w matrycy
			$s['groups'][ $term_id ]['window'] = dc_sanitize_window( isset( $w[ $term_id ] ) ? $w[ $term_id ] : array() );
		}
	}
	update_option( 'dc_settings', $s, true );
	dc_clear_slots_cache();

	dc_admin_redirect( array( 'saved' => 'matrix' ) );
} );

// Zapis okien dostaw: przełącznik trybu, katalog okien i oś każdego dnia tygodnia.
add_action( 'admin_post_dc_save_windows', function () {
	dc_admin_guard();
	$post = wp_unslash( $_POST );
	$s    = dc_raw_settings();
	$next = isset( $s['win_next'] ) ? max( 1, (int) $s['win_next'] ) : 1;
	$old  = ( isset( $s['win_defs'] ) && is_array( $s['win_defs'] ) ) ? $s['win_defs'] : array();

	$defs = array();
	foreach ( (array) ( isset( $post['dc_win'] ) ? $post['dc_win'] : array() ) as $row ) {
		$name = sanitize_text_field( isset( $row['name'] ) ? $row['name'] : '' );
		$len  = isset( $row['len'] ) ? absint( $row['len'] ) : 0;
		$cap  = isset( $row['cap'] ) ? absint( $row['cap'] ) : 0;
		if ( '' === $name && ! $len && ! $cap ) {
			continue; // pusty wiersz
		}
		$id = isset( $row['id'] ) ? sanitize_key( $row['id'] ) : '';
		if ( '' === $id || ! isset( $old[ $id ] ) || isset( $defs[ $id ] ) ) {
			$id = 'w' . $next++;
		}
		$defs[ $id ] = array(
			'name' => '' !== $name ? $name : 'Okno ' . $id,
			'len'  => max( 5, min( 600, $len ? $len : 60 ) ),
			'cap'  => max( 1, min( 99, $cap ? $cap : 6 ) ),
		);
	}

	$days = array();
	$in   = ( isset( $post['dc_wday'] ) && is_array( $post['dc_wday'] ) ) ? $post['dc_wday'] : array();
	foreach ( array_keys( dc_days() ) as $dow ) {
		$d   = isset( $in[ $dow ] ) && is_array( $in[ $dow ] ) ? $in[ $dow ] : array();
		$seq = array();
		foreach ( (array) ( isset( $d['seq'] ) ? $d['seq'] : array() ) as $id ) {
			$id = sanitize_key( $id );
			if ( '' !== $id && isset( $defs[ $id ] ) ) {
				$seq[] = $id; // to samo okno może wystąpić w dniu kilka razy
			}
		}
		$days[ $dow ] = array(
			'on'    => empty( $d['on'] ) ? 0 : 1,
			'start' => dc_clean_time( isset( $d['start'] ) ? $d['start'] : '' ),
			'seq'   => $seq,
		);
	}

	$s['win_on']   = empty( $post['dc_win_on'] ) ? 0 : 1;
	$s['win_defs'] = $defs;
	$s['win_days'] = $days;
	$s['win_next'] = $next;
	update_option( 'dc_settings', $s, true );
	dc_clear_slots_cache();

	dc_admin_redirect( array( 'saved' => 'windows' ) );
} );

// Usunięcie kalendarza jednej grupy
add_action( 'admin_post_dc_delete_group', function () {
	dc_admin_guard();
	$term_id = isset( $_POST['term_id'] ) ? absint( $_POST['term_id'] ) : 0;
	$s       = dc_raw_settings();
	if ( $term_id && isset( $s['groups'][ $term_id ] ) ) {
		unset( $s['groups'][ $term_id ] );
		update_option( 'dc_settings', $s, true );
		dc_clear_slots_cache();
	}
	dc_admin_redirect( array( 'saved' => 'deleted' ) );
} );

// Produkty, których nie da się zamówić, bo nie należą do żadnej skonfigurowanej grupy
function dc_products_without_group() {
	$ids = get_posts( array(
		'post_type'      => 'product',
		'post_status'    => 'publish',
		'posts_per_page' => 300,
		'fields'         => 'ids',
		'no_found_rows'  => true,
	) );
	$out = array();
	foreach ( $ids as $id ) {
		// dania główne dostępne tylko w zestawie nie są zamawiane osobno
		if ( 'yes' === get_post_meta( $id, '_rwz_hidden_as_component_main', true ) ) {
			continue;
		}
		if ( ! dc_group_ids_for_product( $id ) ) {
			$out[] = $id;
		}
	}
	return $out;
}

function dc_render_group_fields( $name, $g ) {
	?>
	<table class="form-table" role="presentation"><tbody>
		<tr>
			<th scope="row">Godziny wyjazdu</th>
			<td>
				<?php if ( dc_windows_on() ) : ?>
					<p class="description" style="margin-bottom:6px"><strong>Działa tryb okien dostaw</strong> – godziny grupy wynikają z okien w jej zakresie z matrycy „Godziny dostaw w dniach tygodnia”. Poniższe pole jest zachowane na wypadek powrotu do starego trybu.</p>
				<?php endif; ?>
				<input type="text" class="regular-text" name="<?php echo esc_attr( $name ); ?>[times]" value="<?php echo esc_attr( implode( ', ', (array) $g['times'] ) ); ?>" placeholder="08:00, 09:00, 10:00, 11:00">
				<p class="description">Godziny oddzielone przecinkami. To są godziny dostawy do wyboru dla tej grupy. Bez nich produkty z grupy nie mogą być zamówione.</p>
			</td>
		</tr>
		<tr>
			<th scope="row">Cutoff dzienny <span style="font-weight:400;color:#666;">(opcjonalnie)</span></th>
			<td>
				do godz. <input type="time" name="<?php echo esc_attr( $name ); ?>[cutoff]" value="<?php echo esc_attr( $g['cutoff'] ); ?>">
				<input type="number" min="0" max="60" step="1" name="<?php echo esc_attr( $name ); ?>[cutoff_days]" value="<?php echo esc_attr( (int) $g['cutoff_days'] ); ?>" style="width:70px"> dni przed dostawą
				<p class="description">Do której godziny i ile dni wcześniej trzeba złożyć zamówienie na dany dzień dostawy. <strong>0 dni</strong> = w dniu dostawy (po tej godzinie najwcześniejszy termin to następny dzień, niezależnie od tego, jak odległy jest jeszcze jakiś wyjazd). <strong>1 dzień</strong> = na jutro zamawia się do tej godziny dziś, np. ciasta: 10:30 i 1 dzień → do 10:30 można jeszcze zamówić na jutro, później najbliższy termin to pojutrze. <strong>2 dni</strong> = dwa dni wcześniej itd. <strong>Liczą się tylko dni dostaw tej grupy</strong> – dni nieodhaczone w „Dni dostaw” i daty wyłączone (święta) się pomija: przy pon–pt i 1 dniu na poniedziałek zamawia się do piątku, na wtorek do poniedziałku. Puste pole godziny przy 0 dniach = brak cutoffu dziennego; puste pole godziny przy 1+ dniach = do końca tamtego dnia. Zamówienie złożone dokładnie o tej godzinie jest jeszcze przyjęte.</p>
			</td>
		</tr>
		<tr>
			<th scope="row">Min. czas do wyjazdu (min) — cutoff dostawy</th>
			<td>
				<input type="number" name="<?php echo esc_attr( $name ); ?>[lead]" value="<?php echo esc_attr( $g['lead'] ); ?>" style="width:80px">
				<p class="description">O ile minut wcześniej niż konkretny wyjazd trzeba zamówić. To jest właściwy <strong>cutoff dostawy</strong> — liczony osobno dla KAŻDEGO terminu (godzina wyjazdu minus ta wartość), a nie jedna wspólna godzina na cały dzień. To on decyduje, kiedy dany termin znika z wyboru dla klienta i kiedy w module Kuchnia jest oznaczany jako zamknięty (można zaczynać przygotowanie/pakowanie, bo nic nowego już do niego nie dojdzie). 0 = wystarczy, że wyjazd jest później niż teraz.</p>
			</td>
		</tr>
		<tr>
			<th scope="row">Dni dostaw</th>
			<td>
				<?php foreach ( dc_days() as $key => $label ) : ?>
					<label style="margin-right:12px"><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[days][]" value="<?php echo esc_attr( $key ); ?>" <?php checked( in_array( $key, (array) $g['days'], true ) ); ?>> <?php echo esc_html( $label ); ?></label>
				<?php endforeach; ?>
				<p class="description">Zaznacz dni tygodnia, w które dowozisz. Brak zaznaczonych = brak dostaw.</p>
			</td>
		</tr>
		<tr>
			<th scope="row">Ile dni do przodu</th>
			<td>
				<input type="number" name="<?php echo esc_attr( $name ); ?>[horizon]" value="<?php echo esc_attr( $g['horizon'] ); ?>" style="width:80px">
				<p class="description">Maks. liczba dni od dziś, na które klient może zamawiać (0 = tylko dziś, maks. 60).</p>
			</td>
		</tr>
		<tr>
			<th scope="row">Kalendarz ważny od / do</th>
			<td>
				<input type="date" name="<?php echo esc_attr( $name ); ?>[valid_from]" value="<?php echo esc_attr( $g['valid_from'] ); ?>">
				–
				<input type="date" name="<?php echo esc_attr( $name ); ?>[valid_to]" value="<?php echo esc_attr( $g['valid_to'] ); ?>">
				<p class="description">Zakres dat DOSTAWY, w którym produkty tej grupy są dostępne (np. oferta sezonowa). Puste = bez ograniczeń.</p>
			</td>
		</tr>
		<tr>
			<th scope="row">Dni bez dostaw tej grupy</th>
			<td>
				<textarea name="<?php echo esc_attr( $name ); ?>[blocked]" rows="3" cols="30" placeholder="2026-12-24"><?php echo esc_textarea( implode( "\n", (array) $g['blocked'] ) ); ?></textarea>
				<p class="description">Jedna data na linię, format RRRR-MM-DD.</p>
			</td>
		</tr>
	</tbody></table>
	<?php
}

/**
 * Matryca "Godziny dostaw w dniach tygodnia": wiersze = "Wszystkie grupy"
 * + każda grupa z zapisanym kalendarzem, kolumny = dni tygodnia, w komórce
 * "od" i "do". Filtruje godziny wyjazdu grupy w danym dniu tygodnia dostawy.
 */
function dc_render_matrix( $s, $url, $nonce ) {
	$rows = array( 'global' => array( 'name' => 'Wszystkie grupy', 'window' => (array) $s['global_window'], 'days' => array_keys( dc_days() ) ) );
	foreach ( $s['groups'] as $term_id => $g ) {
		$term = get_term( (int) $term_id, 'product_cat' );
		if ( ! $term || is_wp_error( $term ) ) {
			continue;
		}
		$rows[ (int) $term_id ] = array( 'name' => $term->name, 'window' => (array) $g['window'], 'days' => (array) $g['days'] );
	}
	?>
	<h2 style="margin-top:28px">Godziny dostaw w dniach tygodnia</h2>
	<p class="description" style="max-width:820px">W każdej komórce: od której i do której godziny grupa dowozi w danym dniu tygodnia (dzień <strong>dostawy</strong>, nie dzień składania zamówienia). Klient widzi tylko te godziny wyjazdu grupy, które mieszczą się w przedziale (obie granice włącznie). Puste pole = bez ograniczenia z tej strony. Wiersz <strong>Wszystkie grupy</strong> dotyczy każdej grupy, a kolumna <strong>Wszystkie dni</strong> każdego dnia tygodnia (komórka na ich przecięciu – wszystkich grup we wszystkie dni). Gdy dla jednego terminu wypełnionych jest kilka komórek, obowiązuje najwęższy przedział — najpóźniejszy początek i najwcześniejszy koniec. Przykład: grupa w poniedziałek od 07:00, wszystkie grupy od 10:00 → klient zamawiający w piątek na poniedziałek zobaczy pierwszy termin o 10:00. Szare komórki = dzień, w którym grupa w ogóle nie dowozi (zaznaczasz to w „Dni dostaw” grupy).</p>
	<?php if ( dc_windows_on() ) : ?>
		<p class="description" style="max-width:820px"><strong>Tryb okien dostaw:</strong> grupa dostaje okna, które zaczynają się nie wcześniej niż „od” i kończą nie później niż „do” (okno przecięte granicą odpada). Dni bez dostaw ustawiasz w „Okna w dniach tygodnia” (znacznik Dostawa).</p>
	<?php endif; ?>
	<form method="post" action="<?php echo esc_url( $url ); ?>" novalidate>
		<input type="hidden" name="action" value="dc_save_matrix">
		<input type="hidden" name="dc_nonce" value="<?php echo esc_attr( $nonce ); ?>">
		<div style="overflow-x:auto;max-width:100%">
		<table class="widefat striped" style="width:auto">
			<thead><tr>
				<th>Grupa</th>
				<?php foreach ( array_merge( array( 'All' => 'Wszystkie dni' ), dc_days() ) as $label ) : ?>
					<th style="text-align:center"><?php echo esc_html( $label ); ?></th>
				<?php endforeach; ?>
			</tr></thead>
			<tbody>
				<?php if ( dc_windows_on() ) : ?>
					<?php foreach ( (array) $s['off_days'] as $dk ) : ?>
						<input type="hidden" name="dc_off_days[]" value="<?php echo esc_attr( $dk ); ?>">
					<?php endforeach; ?>
				<?php else : ?>
				<tr style="background:#fcf0f1">
					<th scope="row" style="white-space:nowrap"><strong>Dostawy wyłączone</strong></th>
					<td style="border-right:2px solid #c3c4c7;"></td>
					<?php foreach ( dc_days() as $dk => $dl ) : ?>
						<td style="text-align:center"><label title="Brak dostaw w ten dzień tygodnia we wszystkich grupach"><input type="checkbox" name="dc_off_days[]" value="<?php echo esc_attr( $dk ); ?>" <?php checked( in_array( $dk, (array) $s['off_days'], true ) ); ?>> wył.</label></td>
					<?php endforeach; ?>
				</tr>
				<?php endif; ?>
			<?php foreach ( $rows as $key => $row ) : ?>
				<tr<?php echo ( 'global' === $key ) ? ' style="background:#f0f6fc"' : ''; ?>>
					<th scope="row" style="white-space:nowrap"><strong><?php echo esc_html( $row['name'] ); ?></strong></th>
					<?php foreach ( array_merge( array( 'All' ), array_keys( dc_days() ) ) as $d ) :
						$from = isset( $row['window'][ $d ]['from'] ) ? $row['window'][ $d ]['from'] : '';
						$to   = isset( $row['window'][ $d ]['to'] ) ? $row['window'][ $d ]['to'] : '';
						$off  = ( 'All' !== $d ) && ! in_array( $d, $row['days'], true );
						$bad  = ( '' !== $from && '' !== $to && $from > $to );
						$td   = $off ? 'background:#f0f0f1;opacity:.6;' : ( $bad ? 'background:#fcf0f1;' : '' );
						$td  .= ( 'All' === $d ) ? 'border-right:2px solid #c3c4c7;' : '';
						$base = 'dc_w[' . $key . '][' . $d . ']';
						?>
						<td style="white-space:nowrap;<?php echo esc_attr( $td ); ?>" <?php echo $off ? 'title="Grupa nie dowozi w ten dzień"' : ( $bad ? 'title="Początek jest późniejszy niż koniec – w ten dzień nie będzie żadnej godziny"' : '' ); ?>>
							<input type="time" name="<?php echo esc_attr( $base ); ?>[from]" value="<?php echo esc_attr( $from ); ?>" style="width:96px" aria-label="od"><br>
							<input type="time" name="<?php echo esc_attr( $base ); ?>[to]" value="<?php echo esc_attr( $to ); ?>" style="width:96px;margin-top:4px" aria-label="do">
						</td>
					<?php endforeach; ?>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		</div>
		<?php if ( count( $rows ) < 2 ) : ?>
			<p class="description">Wiersze grup pojawią się po zapisaniu kalendarza grupy (niżej).</p>
		<?php endif; ?>
		<p class="description">W każdej komórce: górne pole „od”, dolne „do”. <strong>Dostawy wyłączone</strong> = w ten dzień tygodnia nie dowozimy wcale (wszystkie grupy); już złożone zamówienia zostają. Pojedyncze daty (święta) – „Dni bez dostaw” w ustawieniach ogólnych.</p>
		<p><button type="submit" class="button button-primary">Zapisz godziny dostaw</button></p>
	</form>
	<?php
}

/**
 * Sekcja „Okna dostaw”: przełącznik trybu, katalog okien (nazwa, długość,
 * pojemność) i oś dnia (dostawa tak/nie, start, kolejność okien).
 */
function dc_render_windows( $s, $url, $nonce ) {
	$defs = dc_win_defs();
	?>
	<h2 style="margin-top:28px">Okna dostaw</h2>
	<p class="description" style="max-width:820px">Okno = odcinek pracy kuriera o danej długości i pojemności w <strong>punktach</strong> (punkty zamówienia ustawiasz przy miejscowości, np. Piła 1, Kaczory 3). Okna są wspólne dla wszystkich grup. Dla każdego dnia tygodnia ustawiasz start i kolejność okien – idą jedno po drugim, bez przerw. Godzina wyjazdu terminu = start okna, klient widzi przedział okna (np. 11:00–12:00). Grupa dostaje okna ze swojego zakresu w matrycy „Godziny dostaw w dniach tygodnia”: początek zaokrąglany w górę do startu okna, koniec w dół do jego końca.</p>
	<form method="post" action="<?php echo esc_url( $url ); ?>" novalidate>
		<input type="hidden" name="action" value="dc_save_windows">
		<input type="hidden" name="dc_nonce" value="<?php echo esc_attr( $nonce ); ?>">
		<p><label><input type="checkbox" name="dc_win_on" value="1" <?php checked( ! empty( $s['win_on'] ) ); ?>> <strong>Używaj okien dostaw</strong> (zamiast godzin wyjazdu wpisanych w grupach)</label></p>
		<?php if ( ! empty( $s['win_on'] ) && ! $defs ) : ?>
			<div class="notice notice-warning inline"><p>Tryb okien jest zaznaczony, ale katalog okien jest pusty – dopóki nie dodasz okien, sklep działa po staremu.</p></div>
		<?php endif; ?>

		<h3>Katalog okien</h3>
		<table class="widefat striped" style="width:auto">
			<thead><tr><th>Nazwa</th><th>Długość (min)</th><th>Pojemność (pkt)</th><th>Krok w Planowaniu</th><th></th></tr></thead>
			<tbody id="dc-win-body">
			<?php
			$i = 0;
			foreach ( $defs as $id => $d ) {
				dc_render_window_row( $i++, $id, $d );
			}
			?>
			</tbody>
		</table>
		<p><button type="button" class="button" id="dc-win-add">+ Dodaj okno</button></p>
		<script type="text/template" id="dc-win-tpl"><?php dc_render_window_row( '__i__', '', array( 'name' => '', 'len' => 60, 'cap' => 6 ) ); ?></script>

		<h3>Okna w dniach tygodnia</h3>
		<?php if ( ! $defs ) : ?>
			<p class="description">Najpierw dodaj okna i zapisz – potem ułożysz je w dniach tygodnia.</p>
		<?php else : ?>
			<p class="description">Nowe okna z katalogu pojawią się na listach po zapisaniu. Puste pole listy = koniec dnia; po zapisie zawsze dochodzą trzy puste pola na kolejne okna.</p>
			<div style="overflow-x:auto;max-width:100%">
			<table class="widefat striped" style="width:auto">
				<thead><tr><th>Dzień</th><th>Dostawa</th><th>Start</th><th>Kolejność okien</th><th>Wychodzi</th></tr></thead>
				<tbody>
				<?php foreach ( dc_days() as $dow => $label ) :
					$day  = dc_win_day( $dow );
					$seq  = (array) $day['seq'];
					$base = 'dc_wday[' . $dow . ']';
					$line = dc_windows_for_dow( $dow );
					?>
					<tr<?php echo empty( $day['on'] ) ? ' style="background:#fcf0f1"' : ''; ?>>
						<th scope="row"><?php echo esc_html( $label ); ?></th>
						<td style="text-align:center"><input type="checkbox" name="<?php echo esc_attr( $base ); ?>[on]" value="1" <?php checked( ! empty( $day['on'] ) ); ?>></td>
						<td><input type="time" name="<?php echo esc_attr( $base ); ?>[start]" value="<?php echo esc_attr( $day['start'] ); ?>" style="width:96px"></td>
						<td>
							<?php // 2.26.1: węższe pola, zawijają się zamiast rozpychać tabelę. ?>
							<div style="display:flex;flex-wrap:wrap;align-items:center;gap:4px;max-width:760px">
							<?php for ( $k = 0; $k < count( $seq ) + 3; $k++ ) :
								$cur = isset( $seq[ $k ] ) ? $seq[ $k ] : '';
								?>
								<select name="<?php echo esc_attr( $base ); ?>[seq][]" style="width:auto;min-width:0;max-width:110px;min-height:28px;padding:0 22px 0 6px;font-size:12px;line-height:26px">
									<option value="">–</option>
									<?php foreach ( $defs as $id => $d ) : ?>
										<option value="<?php echo esc_attr( $id ); ?>" <?php selected( $cur, $id ); ?>><?php echo esc_html( $d['name'] ); ?></option>
									<?php endforeach; ?>
								</select><?php echo ( $k < count( $seq ) + 2 ) ? '<span style="color:#888">→</span>' : ''; // phpcs:ignore ?>
							<?php endfor; ?>
							</div>
						</td>
						<td style="font-size:12px;white-space:nowrap">
							<?php
							if ( empty( $day['on'] ) ) {
								echo 'brak dostaw';
							} elseif ( '' === $day['start'] ) {
								echo '<span style="color:#b32d2e">brak godziny startu – brak dostaw</span>';
							} elseif ( ! $line ) {
								echo '<span style="color:#b32d2e">brak okien – brak dostaw</span>';
							} else {
								// 2.26.1: skrót – początek–koniec dnia, liczba okien i suma punktów
								// (okna idą jedno po drugim bez przerw). Pełna lista w dymku.
								$bits = array();
								$pts  = 0;
								foreach ( $line as $w ) {
									$bits[] = $w['start'] . '–' . $w['end'] . ' ' . $w['name'] . ' (' . $w['cap'] . ' pkt)';
									$pts   += (int) $w['cap'];
								}
								$n     = count( $line );
								$okien = ( 1 === $n ) ? 'okno' : ( ( $n % 10 >= 2 && $n % 10 <= 4 && ( $n % 100 < 12 || $n % 100 > 14 ) ) ? 'okna' : 'okien' );
								$first = reset( $line );
								$last  = end( $line );
								echo '<span title="' . esc_attr( implode( "\n", $bits ) ) . '" style="cursor:help"><strong>' . esc_html( $first['start'] . '–' . $last['end'] ) . '</strong><br>'
									. esc_html( $n . ' ' . $okien . ' · ' . $pts . ' pkt' ) . '</span>'; // phpcs:ignore
								if ( count( $line ) < count( array_filter( $seq, function ( $id ) use ( $defs ) { return isset( $defs[ $id ] ); } ) ) ) {
									echo '<br><span style="color:#b32d2e">część okien wychodzi poza północ – pominięte</span>';
								}
							}
							?>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			</div>
		<?php endif; ?>
		<p><button type="submit" class="button button-primary">Zapisz okna dostaw</button></p>
	</form>
	<script>
	(function () {
		var body = document.getElementById('dc-win-body');
		if (!body) { return; }
		var next = body.querySelectorAll('tr').length + 1000;
		document.getElementById('dc-win-add').addEventListener('click', function () {
			body.insertAdjacentHTML('beforeend', document.getElementById('dc-win-tpl').innerHTML.replace(/__i__/g, String(next++)));
		});
		body.addEventListener('click', function (e) {
			if (e.target.classList.contains('dc-win-del')) {
				if (!e.target.closest('tr').querySelector('input[type=hidden]').value || confirm('Usunąć okno? Zniknie też z dni tygodnia.')) { e.target.closest('tr').remove(); }
			}
		});
		body.addEventListener('input', function (e) {
			var tr = e.target.closest('tr'); if (!tr) { return; }
			var len = parseInt(tr.querySelector('.dc-win-len').value, 10) || 0, cap = parseInt(tr.querySelector('.dc-win-cap').value, 10) || 0;
			tr.querySelector('.dc-win-step').textContent = (len && cap) ? (Math.round(len / cap * 10) / 10) + ' min' : '–';
		});
	})();
	</script>
	<?php
}

// Jeden wiersz katalogu okien (także szablon dla „+ Dodaj okno”).
function dc_render_window_row( $i, $id, $d ) {
	$name = 'dc_win[' . $i . ']';
	$len  = (int) $d['len'];
	$cap  = (int) $d['cap'];
	?>
	<tr>
		<td><input type="hidden" name="<?php echo esc_attr( $name ); ?>[id]" value="<?php echo esc_attr( $id ); ?>"><input type="text" name="<?php echo esc_attr( $name ); ?>[name]" value="<?php echo esc_attr( $d['name'] ); ?>" placeholder="np. Godzina" style="width:150px"></td>
		<td><input type="number" class="dc-win-len" min="5" max="600" step="5" name="<?php echo esc_attr( $name ); ?>[len]" value="<?php echo esc_attr( $len ); ?>" style="width:80px"></td>
		<td><input type="number" class="dc-win-cap" min="1" max="99" name="<?php echo esc_attr( $name ); ?>[cap]" value="<?php echo esc_attr( $cap ); ?>" style="width:70px"></td>
		<td class="dc-win-step"><?php echo ( $len && $cap ) ? esc_html( round( $len / $cap, 1 ) . ' min' ) : '–'; ?></td>
		<td><button type="button" class="button-link-delete dc-win-del" title="Usuń">✕</button></td>
	</tr>
	<?php
}

function dc_render_admin_page() {
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		return;
	}
	$s     = dc_get_settings();
	$terms = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false, 'orderby' => 'name' ) );
	if ( is_wp_error( $terms ) ) {
		$terms = array();
	}
	$open  = isset( $_GET['open'] ) ? absint( $_GET['open'] ) : 0;
	$saved = isset( $_GET['saved'] ) ? sanitize_key( wp_unslash( $_GET['saved'] ) ) : '';
	$nonce = wp_create_nonce( 'dc_save' );
	$url   = admin_url( 'admin-post.php' );
	?>
	<div class="wrap">
		<h1>DeliveryCalendar</h1>

		<?php if ( $saved ) : ?>
			<div class="notice notice-success is-dismissible"><p><?php echo esc_html( 'deleted' === $saved ? 'Kalendarz grupy usunięty.' : ( 'matrix' === $saved ? 'Zapisano godziny dostaw w dniach tygodnia.' : ( 'windows' === $saved ? 'Zapisano okna dostaw.' : 'Zapisano.' ) ) ); ?></p></div>
			<?php if ( isset( $_GET['empty'] ) && ! dc_windows_on() ) : ?>
				<div class="notice notice-warning"><p>Ta grupa nie ma godzin wyjazdu – jej produkty nie mogą być zamówione, dopóki ich nie wpiszesz.</p></div>
			<?php endif; ?>
		<?php endif; ?>

		<h2>Ustawienia ogólne</h2>
		<form method="post" action="<?php echo esc_url( $url ); ?>" novalidate>
			<input type="hidden" name="action" value="dc_save_general">
			<input type="hidden" name="dc_nonce" value="<?php echo esc_attr( $nonce ); ?>">
			<p><label><input type="checkbox" name="dc_enabled" value="1" <?php checked( ! empty( $s['enabled'] ) ); ?>> <strong>Włącz wybór terminu dostawy w sklepie</strong></label></p>
			<p>
				<label><strong>Maksymalnie zamówień na jedno okno dostawy</strong></label><br>
				<input type="number" min="1" name="dc_max_per_slot" value="<?php echo esc_attr( isset( $s['max_per_slot'] ) ? $s['max_per_slot'] : 6 ); ?>" style="width:80px;">
			</p>
			<p class="description">Gdy okno osiągnie ten limit, znika z wyboru dla kolejnych klientów – tak jak po zamknięciu cutoffu. Dotyczy każdej godziny wyjazdu z osobna, we wszystkich kategoriach razem (to jedna fizyczna dostawa, nie limit na kategorię).<?php echo dc_windows_on() ? ' <strong>Teraz nieużywane – działa tryb okien dostaw, pojemność w punktach bierze się z okna.</strong>' : ''; ?></p>
			<p><strong>Dni bez dostaw (wszystkie grupy)</strong></p>
			<textarea name="dc_global_blocked" rows="3" cols="30" placeholder="2026-12-25"><?php echo esc_textarea( implode( "\n", (array) $s['global_blocked'] ) ); ?></textarea>
			<p class="description">Święta i dni zamknięcia – jedna data na linię (RRRR-MM-DD).</p>
			<button type="submit" class="button button-primary">Zapisz ustawienia ogólne</button>
		</form>

		<?php if ( ! empty( $s['enabled'] ) && function_exists( 'rzd_towns_enabled' ) && ! rzd_towns_enabled() ) : ?>
			<div class="notice notice-error inline" style="margin-top:20px"><p>
				<?php if ( ! rzd_towns() ) : ?>
					<strong>Lista miejscowości jest pusta.</strong> Dodaj miejscowości w <a href="<?php echo esc_url( admin_url( 'admin.php?page=rzd-towns' ) ); ?>">DeliveryCalendar → Miejscowości</a>.
				<?php else : ?>
					<strong>Metoda „Dostawa wg miejscowości” nie jest włączona w żadnej strefie wysyłki</strong> (WooCommerce → Ustawienia → Wysyłka).
				<?php endif; ?>
				Do tego czasu klient nie wybiera miejscowości w okienku terminu, w adresie można wpisać dowolną, a punkty okien liczą każde zamówienie jako 1.
			</p></div>
		<?php endif; ?>
		<?php $brak = dc_products_without_group(); ?>
		<?php if ( $brak ) : ?>
			<div class="notice notice-warning inline" style="margin-top:20px"><p>
				<strong>Produkty bez skonfigurowanej grupy (<?php echo (int) count( $brak ); ?>) nie mogą być zamówione:</strong>
				<?php
				$nazwy = array_map( 'get_the_title', array_slice( $brak, 0, 15 ) );
				echo esc_html( implode( ', ', $nazwy ) . ( count( $brak ) > 15 ? ' …' : '' ) );
				?>
			</p></div>
		<?php endif; ?>

		<?php dc_render_windows( $s, $url, $nonce ); ?>

		<?php dc_render_matrix( $s, $url, $nonce ); ?>

		<h2>Grupy (kategorie produktów)</h2>
		<p class="description">Każdą grupę zapisujesz osobnym przyciskiem. Kalendarz mają tylko grupy zapisane poniżej – produkt musi należeć do co najmniej jednej z nich (podkategoria dziedziczy kalendarz nadrzędnej). Produkt w kilku grupach musi spełniać kalendarze wszystkich.</p>
		<?php
		foreach ( $terms as $t ) {
			$conf = isset( $s['groups'][ $t->term_id ] );
			$g    = $conf ? $s['groups'][ $t->term_id ] : dc_default_group();
			if ( ! $conf ) {
				$info = 'brak kalendarza';
			} elseif ( dc_windows_on() ) {
				$info = 'okna dostaw' . ( $g['cutoff'] ? ' · cutoff dzienny ' . $g['cutoff'] : '' ) . ( (int) $g['cutoff_days'] > 0 ? ( $g['cutoff'] ? '' : ' · cutoff' ) . ' (' . (int) $g['cutoff_days'] . ' dn. przed dostawą)' : '' );
			} elseif ( empty( $g['times'] ) ) {
				$info = 'brak godzin wyjazdu!';
			} else {
				$info = implode( ', ', $g['times'] ) . ( $g['cutoff'] ? ' · cutoff dzienny ' . $g['cutoff'] : '' ) . ( (int) $g['cutoff_days'] > 0 ? ( $g['cutoff'] ? '' : ' · cutoff' ) . ' (' . (int) $g['cutoff_days'] . ' dn. przed dostawą)' : '' );
			}
			?>
			<details style="background:#fff;border:1px solid #c3c4c7;padding:8px 14px;margin:8px 0;max-width:820px" <?php echo ( (int) $t->term_id === $open ) ? 'open' : ''; ?>>
				<summary style="cursor:pointer"><strong><?php echo esc_html( $t->name ); ?></strong> <span style="color:#666">— <?php echo esc_html( $info ); ?></span></summary>
				<form method="post" action="<?php echo esc_url( $url ); ?>" novalidate>
					<input type="hidden" name="action" value="dc_save_group">
					<input type="hidden" name="dc_nonce" value="<?php echo esc_attr( $nonce ); ?>">
					<input type="hidden" name="term_id" value="<?php echo (int) $t->term_id; ?>">
					<?php dc_render_group_fields( 'dc_g', $g ); ?>
					<button type="submit" class="button button-primary">Zapisz tę grupę</button>
				</form>
				<?php if ( $conf ) : ?>
					<form method="post" action="<?php echo esc_url( $url ); ?>" style="margin-top:8px" onsubmit="return confirm('Usunąć kalendarz tej grupy?');">
						<input type="hidden" name="action" value="dc_delete_group">
						<input type="hidden" name="dc_nonce" value="<?php echo esc_attr( $nonce ); ?>">
						<input type="hidden" name="term_id" value="<?php echo (int) $t->term_id; ?>">
						<button type="submit" class="button-link-delete">Usuń kalendarz tej grupy</button>
					</form>
				<?php endif; ?>
			</details>
			<?php
		}
		?>
	</div>
	<?php
}

/* ============================================================
 * 2. SILNIK: które terminy są możliwe
 * ============================================================ */
function dc_now() {
	return new DateTime( 'now', wp_timezone() );
}

/**
 * Numer domu obowiązkowy przy składaniu zamówienia – bez niego kurier/kuchnia
 * w Planowaniu nie ma z czym pracować. Pole "Adres" WooCommerce (address_1)
 * samo w sobie jest już wymagane, ale nic nie sprawdza, czy klient faktycznie
 * wpisał w nim numer – dopisujemy tę jedną, dodatkową regułę.
 * woocommerce_after_checkout_validation działa zarówno przy klasycznym
 * formularzu kasy, jak i przy nowym, blokowym checkoutcie WooCommerce.
 */
add_action( 'woocommerce_after_checkout_validation', function ( $fields, $errors ) {
	// Sprawdzamy ŁĄCZNIE pole "Adres" (address_1) i "Numer domu/mieszkania"
	// (address_2) – niektóre wtyczki checkoutu (np. Fluid Checkout) trzymają
	// numer domu właśnie w address_2 jako osobnym polu, a nie doklejony do
	// nazwy ulicy w address_1. Sprawdzanie tylko address_1 fałszywie
	// odrzucało zamówienia, w których numer był poprawnie podany, tylko
	// w tym drugim polu.
	$needs_shipping = function_exists( 'WC' ) && WC()->cart && WC()->cart->needs_shipping();
	$use_shipping   = $needs_shipping && ! empty( $fields['ship_to_different_address'] );
	$key1           = $use_shipping ? 'shipping_address_1' : 'billing_address_1';
	$key2           = $use_shipping ? 'shipping_address_2' : 'billing_address_2';
	$val1           = isset( $fields[ $key1 ] ) ? $fields[ $key1 ] : '';
	$val2           = isset( $fields[ $key2 ] ) ? $fields[ $key2 ] : '';
	$combined       = trim( $val1 . ' ' . $val2 );
	if ( '' !== $combined && ! preg_match( '/\d/', $combined ) ) {
		$errors->add( 'validation', 'Podaj numer domu/mieszkania w adresie – bez niego nie da się zaplanować dostawy.' );
	}

	// Numer telefonu obowiązkowy – niezależnie od tego, czy checkout (np.
	// Fluid Checkout) sam pokazuje to pole jako wymagane. Kuchnia i kurier
	// potrzebują telefonu do klienta przy dostawie, więc egzekwujemy to
	// twardo, tu, po stronie serwera – nie tylko oznaczeniem pola gwiazdką.
	if ( '' === trim( (string) ( isset( $fields['billing_phone'] ) ? $fields['billing_phone'] : '' ) ) ) {
		$errors->add( 'validation', 'Podaj numer telefonu – jest potrzebny przy dostawie.' );
	}
}, 10, 2 );

// Druga linia adresu (domyślnie „Nr mieszkania, lokalu, itp.”) obowiązkowa –
// kurier musi wiedzieć, do którego mieszkania. Mieszkający w domu wpisują
// „dom”, co też jest dla kuriera informacją. Numer domu pilnuje reguła
// wyżej (cyfra w adresie).
add_filter( 'woocommerce_default_address_fields', function ( $fields ) {
	if ( isset( $fields['address_2'] ) ) {
		$fields['address_2']['required']    = true;
		$fields['address_2']['label']       = 'Nr mieszkania / lokalu';
		$fields['address_2']['placeholder'] = 'mieszkasz w domu? Wpisz: dom';
		$fields['address_2']['label_class'] = array_diff( (array) ( isset( $fields['address_2']['label_class'] ) ? $fields['address_2']['label_class'] : array() ), array( 'screen-reader-text' ) );
	}
	return $fields;
}, 20 );

// Oznaczenie pola telefonu jako wymagane na klasycznym formularzu kasy –
// dla porządku (gwiazdka, natywny komunikat WooCommerce), choć twarde
// wymuszenie i tak dzieje się wyżej, niezależnie od tego pola.
add_filter( 'woocommerce_billing_fields', function ( $fields ) {
	if ( isset( $fields['billing_phone'] ) ) {
		$fields['billing_phone']['required'] = true;
	}
	return $fields;
} );

// 2.26.11: telefon w kroku „Kontakt” Fluid Checkout (obok e-maila), a nie dopiero
// w adresie. Filtr Fluid Checkout – bez tej wtyczki po prostu nic nie robi.
add_filter( 'fc_checkout_contact_step_field_ids', function ( $ids ) {
	$ids = (array) $ids;
	if ( ! in_array( 'billing_phone', $ids, true ) ) {
		$ids[] = 'billing_phone';
	}
	return $ids;
} );

function dc_date_ts( $date, $time = '12:00' ) {
	$dt = DateTime::createFromFormat( 'Y-m-d H:i', $date . ' ' . $time, wp_timezone() );
	return $dt ? $dt->getTimestamp() : 0;
}

/**
 * Czy dla danego terminu (data + godzina) minął już CUTOFF DOSTAWY –
 * czyli czy ten konkretny wyjazd jest już zamknięty na nowe zamówienia?
 * To jest EFEKTYWNY, połączony wynik dwóch niezależnych ustawień grupy:
 * cutoffu dziennego (jedna godzina na cały dzień, opcjonalna) ORAZ
 * minimalnego czasu do wyjazdu (osobno dla każdego terminu) – którykolwiek
 * z nich zamyka termin wcześniej, ten obowiązuje.
 *
 * Używane w dwóch miejscach: (1) moduł 12 (Kuchnia) – do automatycznego
 * przełączenia zamówienia w status "W przygotowaniu" i do znaczka
 * "Otwarte/Zamknięte" przy każdym oknie dostawy; (2) sam wybór terminu na
 * liście – ten sam warunek decyduje, czy klient może jeszcze coś zamówić.
 * Dzięki jednej wspólnej funkcji klient i kuchnia zawsze widzą to samo.
 *
 * Sprawdzamy WSZYSTKIE grupy (kategorie), które mają tę godzinę w swojej
 * konfiguracji: jeśli choć jedna z nich WCIĄŻ przyjmuje zamówienia na tę
 * godzinę (dc_calendar_times_for_date, który sam w sobie już uwzględnia
 * oba ustawienia), cutoff dostawy jeszcze nie minął.
 */
function dc_is_cutoff_passed( $date, $time ) {
	if ( ! $date || ! $time ) {
		return false; // brak danych – nie zgadujemy
	}
	$s           = dc_get_settings();
	$matched_any = false;
	foreach ( $s['groups'] as $cal ) {
		if ( ! dc_group_has_time( $cal, $date, $time ) ) {
			continue;
		}
		$matched_any = true;
		if ( in_array( $time, dc_calendar_times_for_date( $cal, $date ), true ) ) {
			return false; // co najmniej jedna grupa z tą godziną wciąż przyjmuje zamówienia
		}
	}
	if ( ! $matched_any ) {
		// Żadna skonfigurowana grupa nie ma tej godziny – porównujemy wprost
		// z momentem wyjazdu, zamiast zgadywać.
		$ts = dc_date_ts( $date, $time );
		return $ts && dc_now()->getTimestamp() >= $ts;
	}
	return true; // dopasowano przynajmniej jedną grupę i żadna już nie przyjmuje zamówień na tę godzinę
}

/**
 * KIEDY zamyka się dany termin (data + godzina wyjazdu) – znacznik czasu.
 * Uzupełnienie dc_is_cutoff_passed() (która mówi tylko CZY), potrzebne w
 * Kuchni do grupowania zamówień wg cutoffu (moduł 12, zakładka Zamówienia).
 *
 * Dla jednej grupy: wcześniejszy z dwóch momentów – cutoff dzienny
 * (godzina w dniu D − „dni przed dostawą”; pusta godzina przy 1+ dniach =
 * 23:59) oraz wyjazd minus „Min. czas do wyjazdu”. Gdy tę godzinę ma kilka
 * grup, obowiązuje NAJPÓŹNIEJSZY z ich momentów (tak samo jak w
 * dc_is_cutoff_passed: termin jest otwarty, dopóki przyjmuje go choć jedna
 * grupa). Żadna grupa nie ma tej godziny → sam moment wyjazdu.
 * Limit pojemności i matryca nie mają „momentu”, więc tu ich nie ma.
 */
/**
 * 2.26.4: dzień, do którego trzeba zamówić na dostawę $date przy „N dni przed
 * dostawą”. Liczymy DNI DOSTAW tej grupy wstecz, a nie dni kalendarzowe:
 * dni nieodhaczone w „Dni dostaw”, daty wyłączone (grupy i globalne), w trybie
 * okien dni bez dostawy na osi dnia, a w starym trybie „Dostawy wyłączone” – pomijamy.
 * Przykład: pon–pt, 1 dzień, 10:30 → na poniedziałek do piątku 10:30, na wtorek
 * do poniedziałku 10:30; święto w środę → na czwartek do wtorku.
 * 0 dni = sam dzień dostawy (jak dotąd).
 */
function dc_cutoff_deadline_date( $cal, $date ) {
	$n = isset( $cal['cutoff_days'] ) ? (int) $cal['cutoff_days'] : 0;
	if ( $n <= 0 ) {
		return $date;
	}
	static $memo = array();
	$key = md5( wp_json_encode( array( isset( $cal['days'] ) ? $cal['days'] : array(), isset( $cal['blocked'] ) ? $cal['blocked'] : array() ) ) ) . '|' . $n . '|' . $date;
	if ( isset( $memo[ $key ] ) ) {
		return $memo[ $key ];
	}
	$s     = dc_get_settings();
	$tz    = wp_timezone();
	$win   = dc_windows_on();
	$d     = new DateTime( $date, $tz );
	$count = 0;
	for ( $i = 0; $i < 120; $i++ ) { // bezpiecznik: grupa bez żadnego dnia dostaw
		$d->modify( '-1 day' );
		$ymd = $d->format( 'Y-m-d' );
		$dow = $d->format( 'D' );
		if ( ! in_array( $dow, (array) $cal['days'], true ) ) {
			continue;
		}
		if ( in_array( $ymd, (array) $cal['blocked'], true ) || in_array( $ymd, (array) $s['global_blocked'], true ) ) {
			continue;
		}
		if ( $win ? ! dc_windows_for_dow( $dow ) : in_array( $dow, (array) $s['off_days'], true ) ) {
			continue;
		}
		if ( ++$count >= $n ) {
			return $memo[ $key ] = $ymd;
		}
	}
	// Nie znaleziono (np. brak dni dostaw) – stare liczenie kalendarzowe.
	$d = new DateTime( $date, $tz );
	$d->modify( '-' . $n . ' days' );
	return $memo[ $key ] = $d->format( 'Y-m-d' );
}

function dc_cutoff_ts( $date, $time ) {
	$depart = dc_date_ts( $date, $time );
	if ( ! $depart ) {
		return 0;
	}
	$s     = dc_get_settings();
	$tz    = wp_timezone();
	$found = array();
	foreach ( $s['groups'] as $cal ) {
		if ( ! dc_group_has_time( $cal, $date, $time ) ) {
			continue;
		}
		$ts = $depart - 60 * (int) ( isset( $cal['lead'] ) ? $cal['lead'] : 0 );
		$cutoff_days = isset( $cal['cutoff_days'] ) ? (int) $cal['cutoff_days'] : 0;
		if ( ! empty( $cal['cutoff'] ) || $cutoff_days > 0 ) {
			// 2.26.4: „N dni przed” = N dni dostaw wstecz (dc_cutoff_deadline_date).
			$daily = dc_date_ts( dc_cutoff_deadline_date( $cal, $date ), ! empty( $cal['cutoff'] ) ? $cal['cutoff'] : '23:59' );
			if ( $daily && $daily < $ts ) {
				$ts = $daily;
			}
		}
		$found[] = $ts;
	}
	return $found ? max( $found ) : $depart;
}

/**
 * Harmonogram dostaw DLA PRODUKTU (nie mylić z harmonogramem SKŁADU zestawu
 * z modułu 5) – zwięzłe podsumowanie konfiguracji kalendarza kategorii, do
 * której należy produkt, np. "pn–pt: 8:30–9:30, 9:30–10:30". Dni ze sobą
 * sąsiadujące są kompresowane do zakresu (pn–pt), pojedyncze wypisane osobno.
 */
function dc_compress_day_ranges( $days ) {
	$order = array_keys( dc_days() ); // Mon..Sun w tej kolejności
	$set   = array_values( array_filter( $order, function ( $d ) use ( $days ) {
		return in_array( $d, (array) $days, true );
	} ) );
	if ( ! $set ) {
		return array();
	}
	$labels = dc_days();
	$ranges = array();
	$start  = $set[0];
	$prev   = $set[0];
	for ( $i = 1; $i <= count( $set ); $i++ ) {
		$cur          = isset( $set[ $i ] ) ? $set[ $i ] : null;
		$prev_index   = array_search( $prev, $order, true );
		$is_consecutive = $cur && ( array_search( $cur, $order, true ) === $prev_index + 1 );
		if ( ! $is_consecutive ) {
			$ranges[] = ( $start === $prev ) ? $labels[ $start ] : ( $labels[ $start ] . '–' . $labels[ $prev ] );
			$start    = $cur;
		}
		$prev = $cur;
	}
	return $ranges;
}

// Tytuł ramki z harmonogramem dostaw (do zmiany w „Wygląd listy”, 2.25.3).
function dc_delivery_box_title() {
	return function_exists( 'rzd_list_label' ) ? rzd_list_label( 'delivery' ) : 'Możliwe dostawy';
}

function dc_product_schedule_summary_html( $product_id ) {
	// 2.26.13: treść zależy tylko od grup produktu – produkty z tych samych grup
	// (np. wszystkie bajgle) dostają gotowy wynik zamiast liczenia od nowa.
	static $memo = array();
	$gkey = implode( ',', dc_group_ids_for_product( $product_id ) );
	if ( ! isset( $memo[ $gkey ] ) ) {
		$memo[ $gkey ] = dc_product_schedule_summary_calc( $product_id );
	}
	return $memo[ $gkey ];
}

function dc_product_schedule_summary_calc( $product_id ) {
	$cals = dc_calendars_for_product( $product_id );
	if ( ! $cals ) {
		return '';
	}
	// Tryb okien: godziny różnią się między dniami tygodnia, więc dni z tym
	// samym zestawem okien łączymy („Pon–Pt: 11:00–12:00, …; Sob: …”).
	if ( dc_windows_on() ) {
		$by_label = array();
		$day      = dc_now();
		for ( $i = 0; $i < 7; $i++ ) {
			$date  = $day->format( 'Y-m-d' );
			$dow   = $day->format( 'D' );
			$day->modify( '+1 day' );
			$times = array();
			foreach ( $cals as $cal ) {
				if ( in_array( $dow, (array) $cal['days'], true ) ) {
					$times = array_merge( $times, dc_group_times( $cal, $date ) );
				}
			}
			$times = array_values( array_unique( $times ) );
			sort( $times );
			if ( ! $times ) {
				continue;
			}
			$label = implode( ', ', array_map( function ( $t ) use ( $date ) {
				return dc_time_window_label( $t, $date );
			}, $times ) );
			$by_label[ $label ][] = $dow;
		}
		if ( ! $by_label ) {
			return '';
		}
		$parts = array();
		foreach ( $by_label as $label => $dows ) {
			$parts[] = '<strong>' . esc_html( implode( ', ', dc_compress_day_ranges( $dows ) ) ) . ':</strong> ' . esc_html( $label );
		}
		return '<details class="rl2-delivery"><summary>' . esc_html( dc_delivery_box_title() ) . '</summary><div class="rl2-delivery-body">' . implode( '<br>', $parts ) . '</div></details>';
	}

	$days  = array();
	$times = array();
	foreach ( $cals as $cal ) {
		$days  = array_merge( $days, (array) $cal['days'] );
		$times = array_merge( $times, (array) $cal['times'] );
	}
	$days  = array_values( array_unique( $days ) );
	$times = array_values( array_unique( $times ) );
	sort( $times );
	if ( ! $days || ! $times ) {
		return '';
	}
	$day_ranges = dc_compress_day_ranges( $days );
	$windows    = array_map( 'dc_time_window_label', $times );

	ob_start();
	?>
	<details class="rl2-delivery">
		<summary><?php echo esc_html( dc_delivery_box_title() ); ?></summary>
		<div class="rl2-delivery-body">
			<strong><?php echo esc_html( implode( ', ', $day_ranges ) ); ?>:</strong>
			<?php echo esc_html( implode( ', ', $windows ) ); ?>
		</div>
	</details>
	<?php
	return ob_get_clean();
}

function dc_date_label( $date ) {
	$ts = dc_date_ts( $date );
	return $ts ? wp_date( 'l, j F Y', $ts ) : $date;
}

/**
 * Klient widzi PRZEDZIAŁ godzinowy (godzina wyjazdu + 1 godzina), nie
 * dokładną minutę wyjazdu – to wyjazd, nie moment dostawy pod drzwi, a
 * dokładną kolejność w tej godzinie i tak ustala się dopiero w Planowaniu.
 */
function dc_time_window_label( $time, $date = '' ) {
	if ( ! preg_match( '/^([01]\d|2[0-3]):([0-5]\d)$/', $time ) ) {
		return $time;
	}
	// Tryb okien: prawdziwy koniec okna (okna mają różne długości).
	if ( $date && dc_windows_on() ) {
		$w = dc_window_at( $date, $time );
		if ( $w ) {
			return $w['start'] . '–' . $w['end'];
		}
	}
	$end = DateTime::createFromFormat( 'H:i', $time );
	if ( ! $end ) {
		return $time;
	}
	$end->modify( '+1 hour' );
	return $time . '–' . $end->format( 'H:i' );
}

function dc_slot_label( $slot ) {
	return dc_date_label( $slot['date'] ) . ', ' . dc_time_window_label( $slot['time'], $slot['date'] );
}

// Pasek terminu: z miejscowością, gdy działa matryca miejscowości (moduł 20).
function dc_slot_label_town( $slot ) {
	$town = function_exists( 'rzd_session_town' ) && function_exists( 'rzd_towns_enabled' ) && rzd_towns_enabled() ? rzd_session_town() : '';
	return dc_slot_label( $slot ) . ( $town ? ' · ' . $town : '' );
}

function dc_slot_expired( $slot ) {
	$ts = dc_date_ts( $slot['date'], $slot['time'] );
	return ! $ts || $ts < time();
}

function dc_product_root_id( $product_id ) {
	$p = wc_get_product( $product_id );
	return ( $p && $p->is_type( 'variation' ) ) ? (int) $p->get_parent_id() : (int) $product_id;
}

// Skonfigurowane grupy produktu: jego kategorie i kategorie nadrzędne (podkategoria dziedziczy kalendarz)
function dc_group_ids_for_product( $product_id ) {
	// WYDAJNOŚĆ: ta funkcja jest wywoływana RAZ NA KAŻDY DZIEŃ w pętli
	// sprawdzającej dostępne terminy (do kilkudziesięciu razy dla tego
	// samego produktu w jednym żądaniu) – wynik dla danego produktu nie
	// zmienia się w trakcie jednego żądania, więc liczymy go raz.
	static $memo = array();
	$root = dc_product_root_id( $product_id );
	if ( isset( $memo[ $root ] ) ) {
		return $memo[ $root ];
	}

	$s     = dc_get_settings();
	$found = array();
	foreach ( (array) wc_get_product_term_ids( $root, 'product_cat' ) as $tid ) {
		$chain = array_merge( array( (int) $tid ), array_map( 'intval', get_ancestors( (int) $tid, 'product_cat', 'taxonomy' ) ) );
		foreach ( $chain as $id ) {
			if ( isset( $s['groups'][ $id ] ) ) {
				$found[ $id ] = true;
			}
		}
	}
	$memo[ $root ] = array_keys( $found );
	return $memo[ $root ];
}

// Kalendarze produktu = kalendarze jego grup. Produkt bez skonfigurowanej grupy nie ma kalendarza.
function dc_calendars_for_product( $product_id ) {
	$s    = dc_get_settings();
	$cals = array();
	foreach ( dc_group_ids_for_product( $product_id ) as $gid ) {
		$cals[] = $s['groups'][ $gid ];
	}
	return $cals;
}

// Godziny dostaw jednego kalendarza w danym dniu (z cutoffem dla "dziś")
function dc_max_per_slot() {
	$s = dc_get_settings();
	return isset( $s['max_per_slot'] ) && $s['max_per_slot'] > 0 ? (int) $s['max_per_slot'] : 6;
}

/**
 * Ile OPŁACONYCH zamówień jest już w danym oknie dostawy (data+godzina
 * wyjazdu), niezależnie od kategorii – to jedna fizyczna dostawa/kurs, więc
 * limit liczy się łącznie, nie osobno na każdą kategorię produktów.
 * Cache w pamięci na czas jednego żądania – ta sama godzina bywa sprawdzana
 * wielokrotnie przy budowaniu listy dostępnych godzin.
 */
/**
 * Jedno zapytanie do bazy na cały request, zamiast osobnego na KAŻDĄ
 * kombinację dnia+godziny+grupy przy budowaniu kalendarza (przy horyzoncie
 * 60 dni i kilku godzinach dziennie robiło się to setki zapytań na jedno
 * wejście na stronę – ta wersja liczy wszystko raz, w pamięci).
 */
function dc_orders_count_map() {
	$maps = dc_orders_slot_maps();
	return $maps['count'];
}

// Suma punktów zamówień w terminie (tryb okien, 2.25.0).
function dc_orders_points_for_slot( $date, $time ) {
	$maps = dc_orders_slot_maps();
	$key  = $date . '|' . $time;
	return isset( $maps['points'][ $key ] ) ? (int) $maps['points'][ $key ] : 0;
}

// Liczba zamówień i suma ich punktów na termin – jedno zapytanie na request.
function dc_orders_slot_maps() {
	static $maps = null;
	if ( null !== $maps ) {
		return $maps;
	}
	$map    = array();
	$points = array();

	// Ta sama definicja "co się liczy jako realne zamówienie" co w module 12
	// (Kuchnia) – w jednym miejscu, żeby oba liczniki nie mogły się rozjechać
	// tak jak przy poprzednim błędzie z płatnością przy odbiorze.
	if ( function_exists( 'kuchnia_statuses' ) ) {
		$statuses = kuchnia_statuses();
	} else {
		$statuses = array( 'wc-processing', 'wc-completed', 'wc-on-hold' );
		if ( function_exists( 'rzd_kitchen_statuses' ) ) {
			foreach ( array_keys( rzd_kitchen_statuses() ) as $slug ) {
				$statuses[] = 'wc-' . $slug;
			}
		}
	}

	$orders = wc_get_orders( array(
		'limit'      => -1,
		'status'     => $statuses,
		'return'     => 'objects',
		'meta_query' => array( // phpcs:ignore
			array( 'key' => '_dc_delivery_date', 'value' => dc_now()->format( 'Y-m-d' ), 'compare' => '>=' ),
		),
	) );
	foreach ( $orders as $o ) {
		$d = $o->get_meta( '_dc_delivery_date' );
		$t = $o->get_meta( '_dc_delivery_time' );
		if ( ! $d || ! $t ) {
			continue;
		}
		$key            = $d . '|' . $t;
		$map[ $key ]    = isset( $map[ $key ] ) ? $map[ $key ] + 1 : 1;
		$points[ $key ] = ( isset( $points[ $key ] ) ? $points[ $key ] : 0 ) + dc_order_points( $o );
	}
	$maps = array( 'count' => $map, 'points' => $points );
	return $maps;
}

function dc_orders_count_for_slot( $date, $time ) {
	$map = dc_orders_count_map();
	$key = $date . '|' . $time;
	return isset( $map[ $key ] ) ? $map[ $key ] : 0;
}

/**
 * Efektywny przedział "od–do" godzin dostawy dla grupy w danym dniu (wg dnia
 * tygodnia daty DOSTAWY). Łączy CZTERY komórki matrycy: grupa/ten dzień,
 * grupa/"Wszystkie dni", "Wszystkie grupy"/ten dzień i "Wszystkie grupy"/
 * "Wszystkie dni". Obowiązuje najwęższy – NAJPÓŹNIEJSZY początek
 * i NAJWCZEŚNIEJSZY koniec ze wszystkich wypełnionych.
 * Np. grupa w poniedziałek od 07:00, globalnie od 10:00 → od 10:00.
 * Zwraca [ from, to ]; '' = brak ograniczenia z tej strony.
 */
function dc_window_for_date( $cal, $date ) {
	$s    = dc_get_settings();
	$dow  = ( new DateTime( $date, wp_timezone() ) )->format( 'D' );
	$cells = array();
	foreach ( array( (array) ( isset( $cal['window'] ) ? $cal['window'] : array() ), (array) $s['global_window'] ) as $row ) {
		foreach ( array( $dow, 'All' ) as $col ) {
			if ( isset( $row[ $col ] ) && is_array( $row[ $col ] ) ) {
				$cells[] = $row[ $col ];
			}
		}
	}
	$froms = array_filter( array_map( function ( $c ) { return isset( $c['from'] ) ? $c['from'] : ''; }, $cells ) );
	$tos   = array_filter( array_map( function ( $c ) { return isset( $c['to'] ) ? $c['to'] : ''; }, $cells ) );
	return array(
		$froms ? max( $froms ) : '',
		$tos ? min( $tos ) : '',
	);
}

// $ignore_cutoff = true: dla Kuchni ("Nowy termin" przy przeplanowaniu) –
// bez cutoffów, "Min. czasu do wyjazdu" i limitu pojemności; zostają dni,
// daty wyłączone, matryca i to, że wyjazd musi być w przyszłości.
function dc_calendar_times_for_date( $cal, $date, $ignore_cutoff = false ) {
	// 2.26.13: wynik dla tej samej grupy i dnia liczony raz na żądanie – na liście
	// wiele produktów należy do tych samych grup, a liczenie (cutoffy, okna,
	// daty) powtarzało się dla każdego produktu i każdego dnia.
	static $memo = array();
	$mkey = md5( serialize( $cal ) ) . '|' . $date . '|' . ( $ignore_cutoff ? 1 : 0 );
	if ( isset( $memo[ $mkey ] ) ) {
		return $memo[ $mkey ];
	}
	$memo[ $mkey ] = dc_calendar_times_for_date_calc( $cal, $date, $ignore_cutoff );
	return $memo[ $mkey ];
}

function dc_calendar_times_for_date_calc( $cal, $date, $ignore_cutoff = false ) {
	if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) || ( ! dc_windows_on() && empty( $cal['times'] ) ) ) {
		return array();
	}
	$s     = dc_get_settings();
	$tz    = wp_timezone();
	$now   = dc_now();
	$today = $now->format( 'Y-m-d' );

	if ( $date < $today ) {
		return array();
	}
	$max_dt = new DateTime( $today, $tz );
	$max_dt->modify( '+' . (int) $cal['horizon'] . ' days' );
	if ( $date > $max_dt->format( 'Y-m-d' ) ) {
		return array();
	}
	if ( ! empty( $cal['valid_from'] ) && $date < $cal['valid_from'] ) {
		return array();
	}
	if ( ! empty( $cal['valid_to'] ) && $date > $cal['valid_to'] ) {
		return array();
	}
	$dow = ( new DateTime( $date, $tz ) )->format( 'D' );
	// Tryb okien: dzień bez dostaw ustawia się na osi dnia (znacznik „dostawa”),
	// dawny wiersz „Dostawy wyłączone” działa tylko w starym trybie.
	if ( ! in_array( $dow, (array) $cal['days'], true ) || ( ! dc_windows_on() && in_array( $dow, (array) $s['off_days'], true ) ) ) {
		return array();
	}
	if ( in_array( $date, (array) $cal['blocked'], true ) || in_array( $date, (array) $s['global_blocked'], true ) ) {
		return array();
	}

	// Cutoff dzienny: zamówienie na dzień $date trzeba złożyć do godziny
	// 'cutoff' w dniu „N dni dostaw przed $date” (2.26.4: dni bez dostaw i daty
	// wyłączone się nie liczą – dc_cutoff_deadline_date). 0 dni = w dniu
	// dostawy. Brak godziny przy 1+ dniach = do końca tamtego dnia.
	$cutoff_days = isset( $cal['cutoff_days'] ) ? (int) $cal['cutoff_days'] : 0;
	if ( ! $ignore_cutoff && ( ! empty( $cal['cutoff'] ) || $cutoff_days > 0 ) ) {
		$deadline_str = dc_cutoff_deadline_date( $cal, $date ) . ' ' . ( ! empty( $cal['cutoff'] ) ? $cal['cutoff'] : '23:59' );
		if ( $now->format( 'Y-m-d H:i' ) > $deadline_str ) {
			return array(); // po cutoffie ten dzień dostawy jest już zamknięty
		}
	}

	// Godziny grupy tego dnia: okna dostaw albo 'times', przycięte matrycą od–do.
	$times = dc_group_times( $cal, $date );

	// Min. czas do wyjazdu (lead): wyjazd musi być później niż teraz + lead.
	// 2.26.20: porównanie pełnej daty, nie tylko dzisiejszej – gdy teraz + lead
	// wypada jutro, jutrzejsze wcześniejsze wyjazdy też odpadają (wcześniej
	// zamówienie o 23:00 przy leadzie 10 h dostawało jutro 7:00).
	// Przy $ignore_cutoff (Nowy termin w Kuchni) lead = 0, czyli „później niż teraz”.
	$min = clone $now;
	$min->modify( '+' . ( $ignore_cutoff ? 0 : (int) $cal['lead'] ) . ' minutes' );
	$min_date = $min->format( 'Y-m-d' );
	if ( $date < $min_date ) {
		return array();
	}
	if ( $date === $min_date ) {
		$min_hi = $min->format( 'H:i' );
		$times  = array_values( array_filter( $times, function ( $t ) use ( $min_hi ) {
			return $t > $min_hi;
		} ) );
	}

	// Limit pojemności: okno, które osiągnęło max zamówień, znika z wyboru –
	// dotyczy każdej daty (nie tylko dzisiejszej), bo pojemność dostawy nie
	// zależy od tego, kiedy klient akurat zamawia.
	// Tryb okien: pojemność w punktach zależy od miejscowości klienta, więc
	// sprawdza się ją później (dc_filter_slots_by_room), poza buforem terminów.
	if ( $ignore_cutoff || dc_windows_on() ) {
		return $times;
	}
	$max   = dc_max_per_slot();
	$times = array_values( array_filter( $times, function ( $t ) use ( $date, $max ) {
		return dc_orders_count_for_slot( $date, $t ) < $max;
	} ) );

	return $times;
}

/* --- dostępność produktu w dniu dostawy --- */
function dc_set_ids() {
	static $ids = null;
	if ( null === $ids ) {
		global $wpdb;
		$ids = array_map( 'intval', $wpdb->get_col( "SELECT DISTINCT post_id FROM {$wpdb->postmeta} WHERE meta_key IN ('_rwz_slots', '_rwz_components')" ) );
	}
	return $ids;
}

// Czy produkt jest wystawiony (jako danie lub dodatek) w którymś zestawie w tym dniu
function dc_component_available_on( $product_id, $date ) {
	foreach ( dc_set_ids() as $set_id ) {
		$active = rwz_get_active_components( $set_id, $date );
		foreach ( array_merge( $active['main'], $active['addon'] ) as $p ) {
			if ( (int) $p->get_id() === (int) $product_id ) {
				return true;
			}
		}
	}
	return false;
}

function dc_product_available_on( $product_id, $date ) {
	static $cache = array();
	$key = $product_id . '|' . $date;
	if ( isset( $cache[ $key ] ) ) {
		return $cache[ $key ];
	}

	$ok = true;
	if ( function_exists( 'rwz_get_slots' ) ) {
		if ( rwz_get_slots( $product_id ) ) {
			// zestaw: musi mieć w tym dniu choć jedno PRAWDZIWE danie (tylko zakres dzienny).
			// 2.26.23: sam zestaw pośredni bez dania (np. „Zupa dnia” bez zupy) ani same
			// dodatki już nie wystarczą – decyzja użytkownika „usuń i blokuj”.
			$ok = function_exists( 'rwz_set_has_dish' ) ? rwz_set_has_dish( $product_id, $date ) : true;
		} elseif ( 'yes' === get_post_meta( $product_id, '_rwz_hidden_as_component', true ) ) {
			// składowa zestawu (np. dodatek): tylko w dni, gdy któryś zestaw ją wystawia
			$ok = dc_component_available_on( $product_id, $date );
		}
	}

	/**
	 * Tu podpinasz własną datę ważności zwykłych produktów:
	 * add_filter( 'dc_product_available_on', function ( $ok, $product_id, $date ) { ... }, 10, 3 );
	 */
	$ok = (bool) apply_filters( 'dc_product_available_on', $ok, (int) $product_id, $date );

	$cache[ $key ] = $ok;
	return $ok;
}

// Godziny, o których da się dostarczyć produkt w danym dniu
function dc_times_for_product_date( $product_id, $date ) {
	if ( ! dc_product_available_on( $product_id, $date ) ) {
		return array();
	}
	$times = null;
	foreach ( dc_calendars_for_product( $product_id ) as $cal ) {
		$t     = dc_calendar_times_for_date( $cal, $date );
		$times = ( null === $times ) ? $t : array_values( array_intersect( $times, $t ) );
	}
	return $times ? $times : array();
}

// Terminy wspólne dla wszystkich podanych produktów: [ 'Y-m-d' => [ 'HH:MM', ... ] ]
function dc_slots_for_products( $product_ids ) {
	$product_ids = array_values( array_unique( array_map( 'intval', (array) $product_ids ) ) );
	if ( ! $product_ids ) {
		return array();
	}
	// 2.26.13: terminy kilku produktów = część wspólna terminów każdego z nich
	// (dzień po dniu, godziny wspólne) – dokładnie to samo, co wcześniej liczono
	// w jednej pętli. Dzięki temu bufor trzyma wyniki POJEDYNCZYCH produktów
	// (wspólne dla wszystkich klientów), a nie każdą kombinację koszyka osobno.
	$out = null;
	foreach ( $product_ids as $pid ) {
		$one = dc_slots_for_product( $pid );
		if ( null === $out ) {
			$out = $one;
		} else {
			$next = array();
			foreach ( $out as $date => $times ) {
				if ( isset( $one[ $date ] ) ) {
					$common = array_values( array_intersect( $times, $one[ $date ] ) );
					if ( $common ) {
						$next[ $date ] = $common;
					}
				}
			}
			$out = $next;
		}
		if ( ! $out ) {
			return array();
		}
	}
	return $out;
}

/**
 * Terminy jednego produktu: [ 'Y-m-d' => [ 'HH:MM', … ] ].
 * WYDAJNOŚĆ (2.26.13): pamięć na czas żądania + JEDEN wspólny bufor
 * (transient „dc_slots_bundle”, 2 min) dla wszystkich produktów – wcześniej
 * osobny transient na produkt/kombinację = 2 zapytania SQL na każdy produkt
 * listy, gdy klient miał coś w koszyku.
 */
function dc_slots_for_product( $pid ) {
	static $memo = array();
	$pid = (int) $pid;
	if ( isset( $memo[ $pid ] ) ) {
		return $memo[ $pid ];
	}
	$bundle =& dc_slots_bundle();
	$now    = time();
	if ( isset( $bundle['items'][ $pid ] ) && $bundle['items'][ $pid ][0] > $now ) {
		return $memo[ $pid ] = $bundle['items'][ $pid ][1];
	}
	$out = array();
	$day = dc_now();
	$max = dc_max_horizon();
	for ( $i = 0; $i <= $max; $i++ ) {
		$date = $day->format( 'Y-m-d' );
		$t    = dc_times_for_product_date( $pid, $date );
		if ( $t ) {
			$out[ $date ] = array_values( $t );
		}
		$day->modify( '+1 day' );
	}
	$bundle['items'][ $pid ] = array( $now + 2 * MINUTE_IN_SECONDS, $out );
	$bundle['dirty']         = true;
	return $memo[ $pid ] = $out;
}

// Wspólny bufor terminów produktów – wczytany raz, zapisany raz (na koniec żądania).
function &dc_slots_bundle() {
	static $bundle = null;
	if ( null === $bundle ) {
		$items  = get_transient( 'dc_slots_bundle' );
		$bundle = array( 'items' => is_array( $items ) ? $items : array(), 'dirty' => false );
		add_action( 'shutdown', 'dc_slots_bundle_save' );
	}
	return $bundle;
}

function dc_slots_bundle_save() {
	$bundle =& dc_slots_bundle();
	if ( empty( $bundle['dirty'] ) ) {
		return;
	}
	$now   = time();
	$items = array_filter( $bundle['items'], function ( $e ) use ( $now ) { return is_array( $e ) && $e[0] > $now; } );
	set_transient( 'dc_slots_bundle', $items, 5 * MINUTE_IN_SECONDS );
	$bundle['dirty'] = false;
}

/**
 * Wywołaj po zapisaniu kalendarza albo zestawu, żeby zmiana była widoczna
 * od razu, zamiast czekać do 2 minut na wygaśnięcie bufora.
 */
function dc_clear_slots_cache() {
	global $wpdb;
	// 2.26.13: wspólny bufor (działa też przy Redis/Memcached, gdzie transienty nie leżą w tabeli opcji).
	delete_transient( 'dc_slots_bundle' );
	$bundle          =& dc_slots_bundle();
	$bundle['items'] = array();
	$bundle['dirty'] = false;
	$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_dc_slots_%' OR option_name LIKE '_transient_timeout_dc_slots_%'" );
}

// '' = produkt da się dostarczyć w terminie; w przeciwnym razie komunikat dla klienta
function dc_check_product_for_slot( $product_id, $slot ) {
	// 2.26.13: na liście sprawdzane 2× na produkt (uwaga + ikonka „i”) – raz wystarczy.
	static $memo = array();
	$mkey = (int) $product_id . '|' . ( isset( $slot['date'] ) ? $slot['date'] : '' ) . '|' . ( isset( $slot['time'] ) ? $slot['time'] : '' );
	if ( ! isset( $memo[ $mkey ] ) ) {
		$memo[ $mkey ] = dc_check_product_for_slot_calc( $product_id, $slot );
	}
	return $memo[ $mkey ];
}

function dc_check_product_for_slot_calc( $product_id, $slot ) {
	$name  = get_the_title( dc_product_root_id( $product_id ) );
	$label = dc_slot_label( $slot );

	if ( ! dc_calendars_for_product( $product_id ) ) {
		return sprintf( 'Produkt „%s” nie należy do żadnej grupy z kalendarzem dostaw, więc nie można go teraz zamówić.', $name );
	}
	if ( function_exists( 'rzd_soldout_effective' ) && rzd_soldout_effective( $product_id, $slot['date'] ) ) { // 2.27.0 (moduł 22)
		return sprintf( 'Produkt „%1$s” jest wyprzedany na %2$s.', $name, dc_date_label( $slot['date'] ) );
	}
	if ( ! dc_product_available_on( $product_id, $slot['date'] ) ) {
		return sprintf( 'Produkt „%1$s” nie jest dostępny w dniu dostawy (%2$s).', $name, dc_date_label( $slot['date'] ) );
	}
	if ( ! in_array( $slot['time'], dc_times_for_product_date( $product_id, $slot['date'] ), true ) ) {
		return sprintf( 'Produkt „%1$s” nie może być dostarczony w wybranym terminie (%2$s).', $name, $label );
	}
	return '';
}

/* ============================================================
 * 3. WYBRANY TERMIN W SESJI KOSZYKA
 * ============================================================ */
// Surowy odczyt (bez dotykania koszyka – bezpieczny w filtrach ładujących koszyk)
function dc_get_slot() {
	if ( ! function_exists( 'WC' ) || ! WC()->session ) {
		return null;
	}
	$slot = WC()->session->get( 'dc_slot' );
	return ( is_array( $slot ) && ! empty( $slot['date'] ) && ! empty( $slot['time'] ) ) ? $slot : null;
}

function dc_clear_slot() {
	if ( function_exists( 'WC' ) && WC()->session ) {
		WC()->session->set( 'dc_slot', null );
	}
}

// Odczyt do użycia w widokach: nieaktualny termin przy pustym koszyku jest kasowany
function dc_current_slot() {
	$slot = dc_get_slot();
	if ( $slot && dc_slot_expired( $slot ) && WC()->cart && WC()->cart->is_empty() ) {
		dc_clear_slot();
		return null;
	}
	return $slot;
}

// Data dostawy wybrana przez klienta (używana przez snippet 4 do wyboru składników zestawu)
function dc_selected_date() {
	if ( ! dc_enabled() ) {
		return null;
	}
	$slot = dc_get_slot();
	return $slot ? $slot['date'] : null;
}

function dc_cart_product_ids() {
	$ids = array();
	if ( function_exists( 'WC' ) && WC()->cart ) {
		foreach ( WC()->cart->get_cart() as $item ) {
			if ( ! empty( $item['rwz_child_of'] ) ) {
				continue; // dodatki idą z produktem głównym
			}
			$ids[] = (int) $item['product_id'];
		}
	}
	return array_values( array_unique( $ids ) );
}

// Pierwszy produkt wyznacza termin – opróżniony koszyk zwalnia go
add_action( 'woocommerce_cart_emptied', 'dc_clear_slot' );
add_action( 'woocommerce_cart_item_removed', function () {
	if ( WC()->cart && WC()->cart->is_empty() ) {
		dc_clear_slot();
	}
} );

/* ============================================================
 * 4. EGZEKWOWANIE W KOSZYKU
 * ============================================================ */
add_filter( 'woocommerce_add_to_cart_validation', 'dc_validate_add_to_cart', 10, 4 );
function dc_validate_add_to_cart( $passed, $product_id, $quantity = 1, $variation_id = 0 ) {
	if ( ! $passed || ! dc_enabled() || ! empty( $GLOBALS['rwz_adding_children'] ) ) {
		return $passed;
	}
	$slot = dc_current_slot();
	if ( ! $slot ) {
		wc_add_notice( 'Najpierw wybierz termin dostawy – od niego zależy, które produkty możesz zamówić.', 'error' );
		return false;
	}
	if ( dc_slot_expired( $slot ) ) {
		wc_add_notice( 'Wybrany termin dostawy już minął. Wybierz nowy termin (przycisk „Zmień termin”).', 'error' );
		return false;
	}
	$msg = dc_check_product_for_slot( $product_id, $slot );
	if ( $msg ) {
		wc_add_notice( $msg . ' Produkt nie został dodany do koszyka – jedno zamówienie ma jeden termin dostawy. Zmień termin albo złóż osobne zamówienie.', 'error' );
		return false;
	}
	return $passed;
}

// Ponowna kontrola przed płatnością (mógł minąć cutoff, zmienić się dostępność)
add_action( 'woocommerce_check_cart_items', 'dc_check_cart_items' );
function dc_check_cart_items() {
	if ( ! dc_enabled() || ! WC()->cart || WC()->cart->is_empty() ) {
		return;
	}
	$slot = dc_get_slot();
	if ( ! $slot ) {
		wc_add_notice( 'Wybierz termin dostawy zamówienia (przycisk „Zmień termin”).', 'error' );
		return;
	}
	if ( dc_slot_expired( $slot ) ) {
		wc_add_notice( 'Wybrany termin dostawy już minął – wybierz nowy termin.', 'error' );
		return;
	}
	foreach ( dc_cart_product_ids() as $pid ) {
		$msg = dc_check_product_for_slot( $pid, $slot );
		if ( $msg ) {
			wc_add_notice( $msg . ' Zmień termin dostawy lub usuń produkt z koszyka.', 'error' );
		}
	}
}

/**
 * Tryb okien: pojemność sprawdzana jeszcze raz przy składaniu zamówienia
 * (dwóch klientów mogło wybrać ostatnie miejsce w tym samym czasie, a klient
 * mógł zmienić miejscowość w kasie). Punkty: miejscowość z kasy, gdy działa
 * dostawa wg miejscowości; inna metoda (np. odbiór) = 0; bez miejscowości 1.
 */
add_action( 'woocommerce_after_checkout_validation', function ( $fields, $errors ) {
	if ( ! dc_enabled() || ! dc_windows_on() ) {
		return;
	}
	$slot = dc_get_slot();
	if ( ! $slot ) {
		return;
	}
	$need = 1;
	if ( function_exists( 'rzd_towns_enabled' ) && rzd_towns_enabled() ) {
		if ( ! rzd_town_check_applies() ) {
			return; // np. odbiór osobisty – nie zajmuje miejsca w kursie
		}
		$use_shipping = ! empty( $fields['ship_to_different_address'] );
		$city         = $use_shipping ? ( isset( $fields['shipping_city'] ) ? $fields['shipping_city'] : '' ) : ( isset( $fields['billing_city'] ) ? $fields['billing_city'] : '' );
		if ( ! rzd_town_find( $city ) ) {
			return; // brak miejscowości na liście – komunikat daje moduł 20
		}
		$need = rzd_town_points( $city );
	}
	if ( ! dc_slot_has_room( $slot['date'], $slot['time'], $need ) ) {
		$errors->add( 'validation', 'Wybrany termin dostawy (' . dc_slot_label( $slot ) . ') właśnie się zapełnił. Wybierz inny termin (przycisk „Zmień termin” na górze).' );
	}
}, 25, 2 );

/* ============================================================
 * 5. AJAX (wc-ajax): lista terminów i zapis wyboru
 * ============================================================ */
add_action( 'wc_ajax_dc_slots', 'dc_ajax_slots' );
function dc_ajax_slots() {
	$pid = isset( $_GET['product_id'] ) ? absint( $_GET['product_id'] ) : 0;
	$ids = dc_cart_product_ids();
	if ( $pid ) {
		$ids[] = $pid;
	}

	if ( $ids ) {
		$slots = dc_slots_for_products( $ids );
		$mode  = $pid ? 'product' : 'cart';
		$none  = 'Ten produkt nie jest teraz dostępny w żadnym terminie zgodnym z produktami w Twoim koszyku.';
		if ( ! $pid ) {
			$none = 'Nie ma terminu, który pasuje do wszystkich produktów w koszyku. Usuń któryś produkt i spróbuj ponownie.';
		}
	} else {
		// pusty koszyk i brak produktu: klient wybiera datę z góry – pokazujemy terminy wszystkich grup
		$slots = dc_slots_all_groups();
		$mode  = 'all';
		$none  = 'Żaden termin dostawy nie jest teraz dostępny.';
	}

	// Miejscowość (moduł 20): terminy tylko te, w które jedziemy do niej.
	$town = '';
	if ( function_exists( 'rzd_towns_enabled' ) && rzd_towns_enabled() ) {
		$typed = isset( $_GET['town'] ) ? sanitize_text_field( wp_unslash( $_GET['town'] ) ) : rzd_session_town();
		if ( '' === trim( $typed ) ) {
			wp_send_json( array( 'ok' => true, 'mode' => $mode, 'dates' => array(), 'need_town' => true, 'message' => 'Wybierz miejscowość dostawy z listy – pokażemy terminy, w które do niej dowozimy.' ) );
		}
		$row = rzd_town_find( $typed );
		if ( ! $row ) {
			wp_send_json( array( 'ok' => true, 'mode' => $mode, 'dates' => array(), 'need_town' => true, 'message' => 'Sprawdź nazwę miejscowości – nie ma jej na liście miejscowości, do których dowozimy. Poprawna nazwa gwarantuje bezproblemową dostawę.' ) );
		}
		$town  = $row['name'];
		$slots = rzd_town_filter_slots( $slots, $row );
		if ( ! $slots ) {
			$none = 'Do miejscowości ' . $town . ' dowozimy: ' . rzd_town_schedule_label( $row ) . '. ' . ( 'all' === $mode ? 'W najbliższych dniach nie ma takiego terminu.' : 'Nie ma takiego terminu dla produktów z koszyka.' );
		}
	}

	// Tryb okien: tylko okna, w których zmieszczą się punkty tej miejscowości.
	if ( $slots && dc_windows_on() ) {
		$slots = dc_filter_slots_by_room( $slots, dc_customer_points( $town ) );
		if ( ! $slots ) {
			$none = 'Wszystkie najbliższe terminy dostaw' . ( $town ? ' do miejscowości ' . $town : '' ) . ' są już zajęte.';
		}
	}

	$dates = array();
	foreach ( $slots as $d => $times ) {
		$labels = array();
		foreach ( $times as $t ) {
			$labels[ $t ] = dc_time_window_label( $t, $d );
		}
		$dates[] = array( 'date' => $d, 'label' => dc_date_label( $d ), 'times' => $times, 'labels' => $labels );
	}
	wp_send_json( array(
		'ok'      => true,
		'mode'    => $mode,
		'town'    => $town,
		'dates'   => $dates,
		'message' => $dates ? '' : $none,
	) );
}

add_action( 'wc_ajax_dc_set_slot', 'dc_ajax_set_slot' );
function dc_ajax_set_slot() {
	// Wybór terminu jest tylko preferencją sesji i jest w pełni walidowany po stronie serwera.
	$date = isset( $_POST['date'] ) ? sanitize_text_field( wp_unslash( $_POST['date'] ) ) : '';
	$time = isset( $_POST['time'] ) ? dc_clean_time( wp_unslash( $_POST['time'] ) ) : '';
	$pid  = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;

	if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) || ! $time ) {
		wp_send_json( array( 'ok' => false, 'message' => 'Nieprawidłowy termin.' ) );
	}
	$slot = array( 'date' => $date, 'time' => $time );

	// Miejscowość (moduł 20): musi być na liście i pasować do terminu.
	$town = '';
	if ( function_exists( 'rzd_towns_enabled' ) && rzd_towns_enabled() ) {
		$row = rzd_town_find( isset( $_POST['town'] ) ? sanitize_text_field( wp_unslash( $_POST['town'] ) ) : '' );
		if ( ! $row ) {
			wp_send_json( array( 'ok' => false, 'message' => 'Sprawdź nazwę miejscowości – nie ma jej na liście miejscowości, do których dowozimy.' ) );
		}
		if ( ! rzd_town_allows_slot( $row, $date, $time ) ) {
			wp_send_json( array( 'ok' => false, 'message' => 'Do miejscowości ' . $row['name'] . ' dowozimy: ' . rzd_town_schedule_label( $row ) . '.' ) );
		}
		$town = $row['name'];
	}

	$ids = dc_cart_product_ids();
	if ( $pid ) {
		$ids[] = $pid;
	}
	foreach ( array_unique( $ids ) as $id ) {
		$msg = dc_check_product_for_slot( $id, $slot );
		if ( $msg ) {
			wp_send_json( array( 'ok' => false, 'message' => $msg ) );
		}
	}
	if ( ! $ids ) {
		$all = dc_slots_all_groups();
		if ( empty( $all[ $date ] ) || ! in_array( $time, $all[ $date ], true ) ) {
			wp_send_json( array( 'ok' => false, 'message' => 'Ten termin dostawy nie jest dostępny.' ) );
		}
	}
	if ( ! dc_slot_has_room( $date, $time, dc_customer_points( $town ) ) ) {
		wp_send_json( array( 'ok' => false, 'message' => 'Ten termin dostawy jest już zajęty. Wybierz inny.' ) );
	}

	if ( WC()->session ) {
		WC()->session->set_customer_session_cookie( true );
		WC()->session->set( 'dc_slot', $slot );
		if ( $town ) {
			WC()->session->set( 'rzd_town', $town );
			// Miejscowość sama wpisze się w kasie.
			if ( WC()->customer ) {
				WC()->customer->set_billing_city( $town );
				WC()->customer->set_shipping_city( $town );
				WC()->customer->save();
			}
		}
	}

	// Zestawy w koszyku "zamrażają" listę dań – odśwież ją pod nową datę
	if ( WC()->cart && function_exists( 'rwz_get_active_components' ) ) {
		foreach ( WC()->cart->cart_contents as $key => $item ) {
			if ( isset( $item['rwz_components'] ) ) {
				$active = rwz_get_active_components( $item['product_id'], $date );
				WC()->cart->cart_contents[ $key ]['rwz_components'] = array_map( function ( $p ) {
					return $p->get_name();
				}, $active['main'] );
				if ( function_exists( 'rwz_component_ids' ) ) { // 2.26.23: ID dań – kontrola koszyka (moduł 04)
					WC()->cart->cart_contents[ $key ]['rwz_component_ids'] = rwz_component_ids( $active['main'] );
				}
			}
		}
		WC()->cart->set_session();
	}

	wp_send_json( array( 'ok' => true, 'slot' => $slot, 'town' => $town, 'label' => dc_slot_label_town( $slot ) ) );
}

/* ---------- Terminy wspólne dla wszystkich grup (wybór daty przed produktami) ---------- */
function dc_slots_all_groups() {
	$s   = dc_get_settings();
	$out = array();
	$day = dc_now();
	$max = dc_max_horizon();
	for ( $i = 0; $i <= $max; $i++ ) {
		$date  = $day->format( 'Y-m-d' );
		$times = array();
		foreach ( $s['groups'] as $g ) {
			$times = array_merge( $times, dc_calendar_times_for_date( $g, $date ) );
		}
		$times = array_values( array_unique( $times ) );
		sort( $times );
		if ( $times ) {
			$out[ $date ] = $times;
		}
		$day->modify( '+1 day' );
	}
	return $out;
}

/* ---------- Brak wspólnego terminu z koszykiem (2.25.3) ----------
 * Zmiana daty pomaga tylko wtedy, gdy koszyk + produkt mają jakikolwiek
 * wspólny termin. Gdy nie mają (np. śniadanie i obiad), klient dostaje inne
 * okienko – bez „Zmień datę dostawy”, z informacją o osobnym zamówieniu.
 */
function dc_fits_with_cart( $product_id ) {
	static $memo = array();
	$product_id = (int) $product_id;
	if ( isset( $memo[ $product_id ] ) ) {
		return $memo[ $product_id ];
	}
	$ids = dc_cart_product_ids();
	if ( ! $ids || in_array( $product_id, $ids, true ) ) {
		return $memo[ $product_id ] = true;
	}
	$ids[] = $product_id;
	return $memo[ $product_id ] = (bool) dc_slots_for_products( $ids );
}

// Nazwy grup (kategorii z kalendarzem) dla listy produktów, bez powtórzeń.
function dc_group_names_for_products( $product_ids ) {
	$names = array();
	foreach ( (array) $product_ids as $pid ) {
		foreach ( dc_group_ids_for_product( $pid ) as $gid ) {
			$term = get_term( (int) $gid, 'product_cat' );
			if ( $term && ! is_wp_error( $term ) ) {
				$names[ $term->term_id ] = $term->name;
			}
		}
	}
	return array_values( $names );
}

/* ---------- Kontrola zgodności produktu z terminem w koszyku (okno "nie można dodać") ---------- */
add_action( 'wc_ajax_dc_check', 'dc_ajax_check' );
function dc_ajax_check() {
	$pid  = isset( $_GET['product_id'] ) ? absint( $_GET['product_id'] ) : 0;
	$slot = dc_current_slot();
	if ( ! $pid || ! $slot || ! dc_check_product_for_slot( $pid, $slot ) ) {
		wp_send_json( array( 'ok' => true ) );
	}

	$times = dc_times_for_product_date( $pid, $slot['date'] );
	$alt   = '';
	if ( $times ) {
		$alt = implode( ', ', $times ); // ten sam dzień, inne godziny
	} else {
		$first = dc_slots_for_products( array( $pid ) );
		if ( $first ) {
			$d   = key( $first );
			$alt = dc_date_label( $d ) . ', ' . $first[ $d ][0];
		}
	}
	$cart_ids  = dc_cart_product_ids();
	$no_common = $cart_ids && ! dc_fits_with_cart( $pid );
	$p_groups  = $no_common ? dc_group_names_for_products( array( $pid ) ) : array();
	$c_groups  = $no_common ? array_values( array_diff( dc_group_names_for_products( $cart_ids ), $p_groups ) ) : array();
	wp_send_json( array(
		'ok'             => false,
		'product'        => get_the_title( dc_product_root_id( $pid ) ),
		'cart_label'     => dc_slot_label( $slot ),
		'has_cart'       => (bool) $cart_ids,
		'alt'            => $alt,
		'alt_same_day'   => (bool) $times,
		'no_common'      => $no_common,
		'product_groups' => $p_groups,
		'cart_groups'    => $c_groups,
	) );
}

/* ---------- Czerwona uwaga pod nazwą produktu na liście (snippet 2) ---------- */
add_filter( 'rest_lista_uwaga', function ( $msg, $product_id ) {
	if ( ! dc_enabled() ) {
		return $msg;
	}
	$slot = dc_current_slot();
	if ( $slot && ! dc_slot_expired( $slot ) && dc_check_product_for_slot( $product_id, $slot ) ) {
		if ( ! dc_fits_with_cart( $product_id ) ) {
			return 'Nie da się zamówić razem z produktami z koszyka – dowozimy je w innych godzinach. Zamów osobno.';
		}
		return 'Zmień datę dostawy, by dodać do koszyka — ta data jest niezgodna z terminem dostawy wybranym w koszyku.';
	}
	return $msg;
}, 10, 2 );

// Ikonka "i (więcej)" obok czerwonej uwagi – pokazuje ten sam komunikat, co
// przy próbie dodania do koszyka, ale na żądanie, zanim klient w ogóle spróbuje.
function dc_conflict_info_icon_html( $product_id ) {
	if ( ! dc_enabled() ) {
		return '';
	}
	$slot = dc_current_slot();
	if ( ! $slot || dc_slot_expired( $slot ) || ! dc_check_product_for_slot( $product_id, $slot ) ) {
		return '';
	}
	return '<button type="button" class="rl2-info-icon" data-product="' . esc_attr( $product_id ) . '" aria-label="Więcej informacji">i</button>'
		. '<button type="button" class="rl2-info-icon-label" data-product="' . esc_attr( $product_id ) . '">(więcej)</button>';
}

/* ---------- Shortcode: przycisk "Wybierz datę dostawy" ---------- */
// Użycie: [wybierz_date_dostawy]  albo  [wybierz_date_dostawy tekst="Ustaw dostawę"]
add_shortcode( 'wybierz_date_dostawy', function ( $atts ) {
	if ( ! dc_enabled() ) {
		return '';
	}
	$a    = shortcode_atts( array( 'tekst' => 'Wybierz datę dostawy' ), $atts );
	$slot = dc_current_slot();
	$out  = '<button type="button" class="dc-open-picker">' . esc_html( $a['tekst'] ) . '</button>';
	if ( $slot ) {
		$out .= ' <span class="dc-picker-label">' . esc_html( dc_slot_label( $slot ) ) . '</span>';
	}
	return $out;
} );

/* ============================================================
 * 6. FRONTEND: pasek z terminem, okno wyboru, blokada bez terminu
 * ============================================================ */
function dc_render_bar() {
	if ( ! dc_enabled() ) {
		return '';
	}
	$slot = dc_current_slot();
	ob_start();
	?>
	<div class="dc-bar<?php echo $slot ? '' : ' dc-bar-empty'; ?>">
		<?php if ( $slot ) : ?>
			<span>Dostawa: <strong class="dc-bar-label"><?php echo esc_html( dc_slot_label_town( $slot ) ); ?></strong></span>
			<button type="button" class="dc-change">Zmień termin</button>
		<?php else : ?>
			<span>Termin dostawy wybierzesz przy dodawaniu pierwszego produktu do koszyka.</span>
		<?php endif; ?>
	</div>
	<?php
	return ob_get_clean();
}
add_shortcode( 'dc_termin', 'dc_render_bar' );
add_action( 'woocommerce_before_cart', function () { echo dc_render_bar(); } );
add_action( 'woocommerce_before_checkout_form', function () { echo dc_render_bar(); }, 5 );

add_action( 'wp_head', function () {
	if ( ! dc_enabled() ) {
		return;
	}
	?>
	<style>
		.dc-bar{display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;padding:10px 14px;margin:0 0 12px;border-radius:8px;background:#eef6ee;border:1px solid #bcd9bc;font-size:14px}
		.dc-bar-empty{background:#f6f6f6;border-color:#ddd;color:#555}
		.dc-change,.dc-change:hover,.dc-change:focus{padding:6px 12px;border:0;border-radius:6px;background:#222 !important;color:#fff !important;cursor:pointer}
		/* Wygląd okienek (termin, konflikt, informacja, dodano do koszyka): moduł 15 → rzd_popup_css() */
		.rl2-info-icon{display:inline-flex;align-items:center;justify-content:center;width:20px;height:20px;border-radius:50%;border:1.5px solid currentColor;font-size:12px;font-style:italic;font-family:Georgia,serif;cursor:pointer;background:transparent;color:inherit;flex:0 0 auto;padding:0}
		.rl2-info-icon-label{font-size:11px;text-decoration:underline;margin-left:2px;cursor:pointer;color:inherit;background:none;border:0;padding:0}
		.dc-open-picker,.dc-open-picker:hover,.dc-open-picker:focus{padding:9px 16px;border:0;border-radius:8px;background:#222 !important;color:#fff !important;cursor:pointer}
		.dc-picker-label{margin-left:8px;font-size:13px}
	</style>
	<?php
} );

add_action( 'wp_footer', 'dc_footer', 15 ); // 2.26.13: znaczniki okienek przed skryptami stopki (20)
// 2.26.13: dane dla skryptu okienka terminu (assets/js/rzd-termin.js).
function dc_front_data() {
	$data = array(
		'slotsUrl' => WC_AJAX::get_endpoint( 'dc_slots' ),
		'setUrl'   => WC_AJAX::get_endpoint( 'dc_set_slot' ),
		'slot'     => dc_current_slot(),
		'checkUrl' => WC_AJAX::get_endpoint( 'dc_check' ),
		'cartUrl'  => wc_get_cart_url(),
		'listUrl'  => function_exists( 'kc_list_url' ) && kc_list_url() ? kc_list_url() : wc_get_page_permalink( 'shop' ),
		'town'     => function_exists( 'rzd_session_town' ) ? rzd_session_town() : '',
	);
	// 2.25.3: zalogowany bez wybranej miejscowości – domyślnie miasto z konta
	// (o ile jest na liście). Inne miasto klient wybiera już świadomie.
	if ( '' === $data['town'] && function_exists( 'rzd_account_town' ) && function_exists( 'rzd_towns_enabled' ) && rzd_towns_enabled() ) {
		$acc_row      = rzd_town_find( rzd_account_town() );
		$data['town'] = $acc_row ? $acc_row['name'] : '';
	}
	return $data;
}

add_action( 'wp_enqueue_scripts', function () {
	if ( ! dc_enabled() ) {
		return;
	}
	wp_enqueue_script( 'rzd-termin', RZD_PLUGIN_URL . 'assets/js/rzd-termin.js', array(), rzd_asset_ver( 'assets/js/rzd-termin.js' ), array( 'in_footer' => true, 'strategy' => 'defer' ) );
	wp_add_inline_script( 'rzd-termin', 'var dcData = ' . wp_json_encode( dc_front_data() ) . ';', 'before' );
} );

function dc_footer() {
	if ( ! dc_enabled() || is_admin() ) {
		return;
	}
	$towns_on = function_exists( 'rzd_towns_enabled' ) && rzd_towns_enabled();
	?>
	<div id="dc-modal" hidden>
		<div class="dc-panel" role="dialog" aria-modal="true" aria-labelledby="dc-title">
			<h3 id="dc-title" class="dc-title">Wybierz termin dostawy</h3>
			<p class="dc-msg"></p>
			<?php if ( $towns_on ) : ?>
			<?php // 2.25.2: lista rozwijana zamiast pola z podpowiedziami (datalist po wyborze pokazywał tylko wybrane miasto). ?>
			<label class="dc-field">Miejscowość dostawy<select class="dc-town">
				<option value="">— wybierz miejscowość z listy —</option>
				<?php foreach ( rzd_towns() as $trow ) : ?>
					<option value="<?php echo esc_attr( $trow['name'] ); ?>"><?php echo esc_html( $trow['name'] ); ?></option>
				<?php endforeach; ?>
			</select></label>
			<?php endif; ?>
			<label class="dc-field">Data dostawy<select class="dc-date"></select></label>
			<div class="dc-field">Godzina dostawy<div class="dc-times"></div></div>
			<div class="dc-actions">
				<div class="dc-act"><button type="button" class="dc-cancel">Anuluj</button></div>
				<div class="dc-act"><button type="button" class="dc-ok" disabled>Zatwierdź termin</button></div>
			</div>
		</div>
	</div>
	<div id="dc-conflict" hidden>
		<div class="dc-panel" role="dialog" aria-modal="true">
			<h3 class="dc-title dc-conf-title">Zmień datę, by dodać do koszyka</h3>
			<p class="dc-msg dc-err dc-conflict-msg"></p>
			<div class="dc-actions">
				<div class="dc-act"><button type="button" class="dc-conf-other">Wybierz inny produkt</button></div>
				<div class="dc-act dc-act-change"><button type="button" class="dc-ok dc-conf-change">Zmień datę dostawy</button></div>
				<div class="dc-act dc-act-cart" hidden><button type="button" class="dc-ok dc-conf-cart">Przejdź do koszyka</button></div>
			</div>
		</div>
	</div>

	<!-- Wersja informacyjna tego samego komunikatu (ikonka "i" na liście) –
	     tylko wyjaśnia, dlaczego produkt jest zablokowany, bez akcji zmiany
	     terminu wprost stąd – klient i tak zobaczy je przy próbie dodania. -->
	<div id="dc-info-popup" hidden>
		<div class="dc-panel" role="dialog" aria-modal="true">
			<h3 class="dc-title">Zmień datę, by dodać do koszyka</h3>
			<p class="dc-msg dc-err dc-info-msg"></p>
			<div class="dc-actions">
				<div class="dc-act"><button type="button" class="dc-ok dc-info-close">OK</button></div>
			</div>
		</div>
	</div>
	
	<?php
}

/* ============================================================
 * 7. TERMIN W ZAMÓWIENIU
 * ============================================================ */
function dc_save_slot_to_order( $order ) {
	$slot = dc_get_slot();
	if ( $slot && dc_enabled() ) {
		$order->update_meta_data( '_dc_delivery_date', $slot['date'] );
		$order->update_meta_data( '_dc_delivery_time', $slot['time'] );
	}
}
add_action( 'woocommerce_checkout_create_order', 'dc_save_slot_to_order', 10, 1 );
add_action( 'woocommerce_store_api_checkout_update_order_from_request', 'dc_save_slot_to_order', 10, 1 );

function dc_order_slot_label( $order ) {
	$d = $order->get_meta( '_dc_delivery_date' );
	$t = $order->get_meta( '_dc_delivery_time' );
	return ( $d && $t ) ? dc_slot_label( array( 'date' => $d, 'time' => $t ) ) : '';
}

/* ---------- Termin dostawy: duży, czytelny box NA GÓRZE zamówienia ---------- */
function dc_order_screen_ids() {
	return array( 'shop_order', 'woocommerce_page_wc-orders' );
}

add_action( 'add_meta_boxes', function () {
	foreach ( dc_order_screen_ids() as $screen ) {
		add_meta_box(
			'dc_delivery_slot_box',
			'Termin dostawy',
			'dc_render_order_slot_box',
			$screen,
			'normal',
			'high' // wyżej niż standardowe sekcje WooCommerce
		);
	}
} );

function dc_render_order_slot_box( $post_or_order ) {
	$order = ( $post_or_order instanceof WC_Order ) ? $post_or_order : wc_get_order( $post_or_order->ID );
	if ( ! $order ) {
		return;
	}
	$l = dc_order_slot_label( $order );
	if ( ! $l ) {
		echo '<p style="margin:0;color:#777">Brak wybranego terminu dostawy.</p>';
		return;
	}
	$d = $order->get_meta( '_dc_delivery_date' );
	$t = $order->get_meta( '_dc_delivery_time' );
	echo '<div style="font-size:20px;line-height:1.4">'
		. '<span style="display:inline-block;background:#eef6ee;border:1px solid #bcd9bc;border-radius:6px;padding:6px 14px;font-weight:700;">'
		. esc_html( ucfirst( dc_date_label( $d ) ) ) . ' &middot; godz. ' . esc_html( $t )
		. '</span></div>';
}
add_action( 'woocommerce_order_details_after_order_table', function ( $order ) {
	$l = dc_order_slot_label( $order );
	if ( $l ) {
		echo '<p><strong>Termin dostawy:</strong> ' . esc_html( $l ) . '</p>';
	}
} );
/* ---------- Kolumna z terminem dostawy na liście zamówień (sortowalna) ---------- */
add_filter( 'manage_edit-shop_order_columns', 'dc_add_order_column' );
add_filter( 'woocommerce_shop_order_list_table_columns', 'dc_add_order_column' );
function dc_add_order_column( $columns ) {
	$new = array();
	foreach ( $columns as $key => $label ) {
		$new[ $key ] = $label;
		if ( 'order_status' === $key ) {
			$new['dc_delivery'] = 'Termin dostawy';
		}
	}
	return $new;
}

add_action( 'manage_shop_order_posts_custom_column', 'dc_render_order_column', 10, 2 );
add_action( 'woocommerce_shop_order_list_table_custom_column', 'dc_render_order_column', 10, 2 );
function dc_render_order_column( $column, $post_or_order_id ) {
	if ( 'dc_delivery' !== $column ) {
		return;
	}
	$order = ( $post_or_order_id instanceof WC_Order ) ? $post_or_order_id : wc_get_order( $post_or_order_id );
	$l     = $order ? dc_order_slot_label( $order ) : '';
	echo $l ? esc_html( $l ) : '&mdash;';
}

add_filter( 'manage_edit-shop_order_sortable_columns', 'dc_sortable_order_column' );
add_filter( 'woocommerce_shop_order_list_table_sortable_columns', 'dc_sortable_order_column' );
function dc_sortable_order_column( $columns ) {
	$columns['dc_delivery'] = 'dc_delivery';
	return $columns;
}

add_action( 'pre_get_posts', function ( $query ) {
	if ( is_admin() && $query->is_main_query() && 'dc_delivery' === $query->get( 'orderby' ) ) {
		$query->set( 'meta_key', '_dc_delivery_date' );
		$query->set( 'orderby', 'meta_value' );
	}
} );
add_filter( 'woocommerce_order_query_args', function ( $args ) {
	if ( isset( $args['orderby'] ) && 'dc_delivery' === $args['orderby'] ) {
		$args['meta_key'] = '_dc_delivery_date';
		$args['orderby']  = 'meta_value';
	}
	return $args;
} );

add_filter( 'woocommerce_email_order_meta_fields', function ( $fields, $sent_to_admin, $order ) {
	$l = dc_order_slot_label( $order );
	if ( $l ) {
		$fields['dc_slot'] = array( 'label' => 'Termin dostawy', 'value' => $l );
	}
	return $fields;
}, 10, 3 );
