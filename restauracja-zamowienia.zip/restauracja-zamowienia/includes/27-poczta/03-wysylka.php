<?php
/**
 * Moduł 27-poczta – część 3: wysyłka (połączenie główne → zapasowe → kolejka), dziennik, ponowienia.
 *
 * Jak to działa:
 * - przed wp_mail (filtr pre_wp_mail) wtyczka podstawia swój PHPMailer (klasa w klasa/), w phpmailer_init ustawia Mailer = 'rzdapi';
 * - PHPMailer składa wiadomość (MIME), wysyłkę robi rzd_mail_dispatch(): połączenie główne, a gdy zawiedzie – zapasowe;
 * - gdy zawiodą oba: mail trafia do kolejki (ponowienia po 5 min, 30 min i 2 godz. – Action Scheduler), a wp_mail zwraca „wysłano”,
 *   żeby np. zamówienie nie kończyło się błędem; administrator widzi komunikat w panelu;
 * - dziennik: ostatnie 100 maili (opcja rzd_mail_log); treść (do ponownej wysyłki) w osobnych opcjach rzd_mail_p_{id}, 7 dni.
 *   Maile z linkami do ustawienia/resetu hasła nie zostają w dzienniku po wysłaniu (tylko na czas kolejki).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'RZD_MAIL_LOG_MAX', 100 );
define( 'RZD_MAIL_KEEP_DAYS', 7 );
define( 'RZD_MAIL_PAYLOAD_MAX', 5 * MB_IN_BYTES ); // załączniki większe – mail w dzienniku bez możliwości ponownej wysyłki

/* ============================================================
 * 1. PHPMailer wtyczki
 * ============================================================ */
function rzd_mail_load_class() {
	if ( class_exists( 'RZD_PHPMailer', false ) ) {
		return true;
	}
	if ( ! class_exists( 'PHPMailer\\PHPMailer\\PHPMailer' ) ) {
		require_once ABSPATH . WPINC . '/PHPMailer/PHPMailer.php';
		require_once ABSPATH . WPINC . '/PHPMailer/SMTP.php';
		require_once ABSPATH . WPINC . '/PHPMailer/Exception.php';
	}
	if ( ! class_exists( 'WP_PHPMailer' ) && file_exists( ABSPATH . WPINC . '/class-wp-phpmailer.php' ) ) {
		require_once ABSPATH . WPINC . '/class-wp-phpmailer.php';
	}
	if ( ! class_exists( 'RZD_PHPMailer_Base', false ) ) {
		class_alias( class_exists( 'WP_PHPMailer' ) ? 'WP_PHPMailer' : 'PHPMailer\\PHPMailer\\PHPMailer', 'RZD_PHPMailer_Base' );
	}
	require_once __DIR__ . '/klasa/class-rzd-phpmailer.php';
	return true;
}

// Wtyczka przejmuje wysyłkę (albo test konkretnego połączenia z panelu).
function rzd_mail_takes_over() {
	return ! empty( $GLOBALS['rzd_mail_only'] ) || rzd_mail_active();
}

add_filter( 'pre_wp_mail', 'rzd_mail_pre_wp_mail', 999 );
function rzd_mail_pre_wp_mail( $short ) {
	global $phpmailer;
	if ( null !== $short || ! rzd_mail_takes_over() ) {
		return $short;
	}
	rzd_mail_load_class();
	if ( ! ( $phpmailer instanceof RZD_PHPMailer ) ) {
		$phpmailer = new RZD_PHPMailer( true ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride -- jak wp_mail()
		$phpmailer::$validator = static function ( $email ) {
			return (bool) is_email( $email );
		};
	}
	return $short;
}

// Ustawienia serwera SMTP w PHPMailerze.
function rzd_mail_conf_smtp( $m, $conn, $which ) {
	$m->Host        = trim( (string) $conn['host'] );
	$m->Port        = (int) $conn['port'] > 0 ? (int) $conn['port'] : 587;
	$m->SMTPSecure  = in_array( $conn['enc'], array( 'ssl', 'tls' ), true ) ? $conn['enc'] : '';
	$m->SMTPAutoTLS = 'none' !== $conn['enc']; // „bez szyfrowania” tylko dla serwerów w sieci lokalnej
	$m->SMTPAuth    = ! empty( $conn['auth'] );
	$m->Username    = $m->SMTPAuth ? (string) $conn['user'] : '';
	$m->Password    = $m->SMTPAuth ? rzd_mail_secret( $conn, 'pass', $which ) : '';
	$m->Timeout     = 15;
}

add_action( 'phpmailer_init', 'rzd_mail_phpmailer', 999 );
function rzd_mail_phpmailer( $m ) {
	if ( ! rzd_mail_takes_over() ) {
		return;
	}
	$s = rzd_mail_settings();
	if ( ! empty( $s['force_from'] ) && is_email( $s['from_email'] ) ) {
		$m->setFrom( $s['from_email'], '' !== trim( (string) $s['from_name'] ) ? $s['from_name'] : $m->FromName, false );
	}
	if ( is_email( $m->From ) ) {
		$m->Sender = $m->From; // Return-Path = nadawca (zgodność z SPF)
	}
	if ( $m instanceof RZD_PHPMailer ) {
		$m->Mailer = 'rzdapi';
	} elseif ( 'smtp' === $s['primary']['type'] ) {
		// ktoś podmienił PHPMailer po naszym filtrze – przynajmniej SMTP połączenia głównego (jak w 2.34.0)
		$m->isSMTP();
		rzd_mail_conf_smtp( $m, $s['primary'], 'primary' );
	}
}

/* ============================================================
 * 2. WIADOMOŚĆ W JEDNEJ POSTACI (dla API i dziennika)
 * ============================================================ */
function rzd_mail_msg_from_phpmailer( $pm, $raw = '' ) {
	$list = function ( $arr ) {
		$out = array();
		foreach ( (array) $arr as $a ) {
			$out[] = array( 'email' => (string) $a[0], 'name' => isset( $a[1] ) ? (string) $a[1] : '' );
		}
		return $out;
	};
	$plain = 'text/plain' === strtolower( (string) $pm->ContentType );
	$att   = array();
	foreach ( (array) $pm->getAttachments() as $a ) {
		$data = ! empty( $a[5] ) ? (string) $a[0] : ( is_readable( $a[0] ) ? (string) file_get_contents( $a[0] ) : '' ); // phpcs:ignore
		$att[] = array(
			'name'        => '' !== (string) $a[2] ? (string) $a[2] : basename( (string) $a[1] ),
			'type'        => '' !== (string) $a[4] ? (string) $a[4] : 'application/octet-stream',
			'content'     => base64_encode( $data ), // phpcs:ignore
			'disposition' => 'inline' === $a[6] ? 'inline' : 'attachment',
			'cid'         => 'inline' === $a[6] && is_string( $a[7] ) ? $a[7] : '',
		);
	}
	$headers = array();
	foreach ( (array) $pm->getCustomHeaders() as $h ) {
		$headers[ (string) $h[0] ] = (string) $h[1];
	}
	return array(
		'from'        => array( 'email' => (string) $pm->From, 'name' => (string) $pm->FromName ),
		'to'          => $list( $pm->getToAddresses() ),
		'cc'          => $list( $pm->getCcAddresses() ),
		'bcc'         => $list( $pm->getBccAddresses() ),
		'reply_to'    => $list( array_values( $pm->getReplyToAddresses() ) ),
		'subject'     => (string) $pm->Subject,
		'html'        => $plain ? '' : (string) $pm->Body,
		'text'        => $plain ? (string) $pm->Body : (string) $pm->AltBody,
		'charset'     => (string) $pm->CharSet,
		'headers'     => $headers,
		'attachments' => $att,
		'raw'         => (string) $raw,
	);
}

/* ============================================================
 * 3. WYSYŁKA: główne → zapasowe → kolejka
 * ============================================================ */

// Jedno połączenie. Zwraca true albo tekst błędu.
function rzd_mail_send_via( $pm, $conn, $which, $header, $body, $msg ) {
	try {
		if ( 'smtp' === $conn['type'] ) {
			rzd_mail_conf_smtp( $pm, $conn, $which );
			return $pm->rzd_via_smtp( $header, $body ) ? true : (string) $pm->ErrorInfo;
		}
		if ( 'php' === $conn['type'] ) {
			return $pm->rzd_via_mail() ? true : (string) $pm->ErrorInfo;
		}
		$r = rzd_mail_api_send( $conn, $which, $msg );
		return is_wp_error( $r ) ? $r->get_error_message() : true;
	} catch ( Exception $e ) { // PHPMailer\PHPMailer\Exception i inne
		return $e->getMessage();
	}
}

function rzd_mail_dispatch( $pm, $header, $body ) {
	$s     = rzd_mail_settings();
	$raw   = rtrim( $header ) . "\r\n\r\n" . $body;
	$msg   = rzd_mail_msg_from_phpmailer( $pm, $raw );
	$only  = isset( $GLOBALS['rzd_mail_only'] ) ? (string) $GLOBALS['rzd_mail_only'] : '';
	$order = in_array( $only, array( 'primary', 'fallback' ), true ) ? array( $only ) : array( 'primary', 'fallback' );
	$errs  = array();
	foreach ( $order as $w ) {
		$c = $s[ $w ];
		if ( empty( $c['type'] ) || ! rzd_mail_conn_ready( $c, $w ) ) {
			if ( $only ) {
				$errs[] = 'Połączenie ' . ( 'primary' === $w ? 'główne' : 'zapasowe' ) . ' nie jest ustawione.';
			}
			continue;
		}
		$r = rzd_mail_send_via( $pm, $c, $w, $header, $body, $msg );
		if ( true === $r ) {
			$note = $errs ? 'połączenie główne zawiodło (' . rzd_mail_friendly( $errs[0] ) . ') – wysłano zapasowym' : '';
			$GLOBALS['rzd_mail_handled'] = array( 'status' => $errs ? 'fallback' : 'sent', 'conn' => rzd_mail_conn_label( $c ), 'msg' => $note, 'payload' => $msg );
			return true;
		}
		$errs[] = rzd_mail_conn_label( $c ) . ': ' . $r;
	}
	if ( ! $errs ) {
		$errs[] = 'Żadne połączenie nie jest ustawione.';
	}
	$err = implode( ' | ', $errs );
	// test z panelu, ponowienie z kolejki, ponowna wysyłka z dziennika – bez (kolejnej) kolejki: błąd od razu
	if ( ! empty( $GLOBALS['rzd_mail_no_queue'] ) || ! empty( $GLOBALS['rzd_mail_retry_id'] ) || $only ) {
		throw new PHPMailer\PHPMailer\Exception( $err );
	}
	$GLOBALS['rzd_mail_handled'] = array( 'status' => 'queued', 'conn' => '', 'msg' => $err, 'payload' => $msg );
	return true; // wp_mail: „wysłano” – mail czeka w kolejce
}

/* ============================================================
 * 4. DZIENNIK (ostatnie 100 maili) I TREŚĆ DO PONOWNEJ WYSYŁKI
 * ============================================================ */
function rzd_mail_log_get() {
	$l = get_option( 'rzd_mail_log', array() );
	return is_array( $l ) ? $l : array();
}
function rzd_mail_log_save( $log ) {
	// najnowsze na początku; nadmiar i stara treść – usuwane (wpisów w kolejce nie ruszamy)
	$cut = time() - RZD_MAIL_KEEP_DAYS * DAY_IN_SECONDS;
	$i   = 0;
	foreach ( $log as $id => $e ) {
		++$i;
		$queued = 'queued' === $e['status'];
		if ( $i > RZD_MAIL_LOG_MAX && ! $queued ) {
			delete_option( 'rzd_mail_p_' . $id );
			unset( $log[ $id ] );
		} elseif ( ! empty( $e['payload'] ) && ! $queued && (int) $e['time'] < $cut ) {
			delete_option( 'rzd_mail_p_' . $id );
			$log[ $id ]['payload'] = 0;
		}
	}
	update_option( 'rzd_mail_log', $log, false );
}
function rzd_mail_log_add( $entry, $payload = null ) {
	$id    = strtolower( wp_generate_password( 12, false ) );
	$entry = wp_parse_args( $entry, array( 'time' => time(), 'to' => '', 'subject' => '', 'conn' => '', 'status' => 'sent', 'msg' => '', 'tries' => 0, 'next' => 0, 'payload' => 0 ) );
	if ( null !== $payload ) {
		$entry['payload'] = rzd_mail_payload_store( $id, $payload ) ? 1 : 0;
	}
	rzd_mail_log_save( array( $id => $entry ) + rzd_mail_log_get() );
	return $id;
}
function rzd_mail_log_update( $id, $changes ) {
	$log = rzd_mail_log_get();
	if ( ! isset( $log[ $id ] ) ) {
		return;
	}
	$log[ $id ] = array_merge( $log[ $id ], $changes );
	update_option( 'rzd_mail_log', $log, false );
}
function rzd_mail_payload_store( $id, $msg ) {
	unset( $msg['raw'] );
	$size = 0;
	foreach ( $msg['attachments'] as $a ) {
		$size += strlen( $a['content'] );
	}
	if ( $size > RZD_MAIL_PAYLOAD_MAX ) {
		return false;
	}
	return update_option( 'rzd_mail_p_' . $id, $msg, false );
}
function rzd_mail_payload_get( $id ) {
	$p = get_option( 'rzd_mail_p_' . $id );
	return is_array( $p ) && ! empty( $p['to'] ) ? $p : null;
}
function rzd_mail_short_to( $list ) {
	$e = rzd_mail_emails( $list );
	return implode( ', ', array_slice( $e, 0, 3 ) ) . ( count( $e ) > 3 ? ' +' . ( count( $e ) - 3 ) : '' );
}

// Maile z linkiem do ustawienia / resetu hasła – po wysłaniu bez treści w dzienniku.
add_filter( 'retrieve_password_notification_email', 'rzd_mail_mark_private' );
add_filter( 'wp_new_user_notification_email', 'rzd_mail_mark_private' );
add_filter( 'woocommerce_email_headers', function ( $headers, $email_id ) {
	if ( in_array( $email_id, array( 'customer_reset_password', 'customer_new_account' ), true ) ) {
		$GLOBALS['rzd_mail_private'] = true;
	}
	return $headers;
}, 10, 2 );
function rzd_mail_mark_private( $mail ) {
	$GLOBALS['rzd_mail_private'] = true;
	return $mail;
}

/* ============================================================
 * 5. PO WYSYŁCE: dziennik, ostatni sukces/błąd, kolejka
 * ============================================================ */
function rzd_mail_after( $ok, $data ) {
	$h       = isset( $GLOBALS['rzd_mail_handled'] ) ? $GLOBALS['rzd_mail_handled'] : null;
	$private = ! empty( $GLOBALS['rzd_mail_private'] );
	$retry   = isset( $GLOBALS['rzd_mail_retry_id'] ) ? $GLOBALS['rzd_mail_retry_id'] : '';
	unset( $GLOBALS['rzd_mail_handled'], $GLOBALS['rzd_mail_private'] );
	$s       = rzd_mail_settings();
	$to      = $h ? rzd_mail_short_to( $h['payload']['to'] ) : implode( ', ', array_slice( (array) ( isset( $data['to'] ) ? $data['to'] : array() ), 0, 3 ) );
	$subject = $h ? $h['payload']['subject'] : ( isset( $data['subject'] ) ? (string) $data['subject'] : '' );

	if ( $retry ) {
		return; // ponowienia zapisuje rzd_mail_retry_run (wynik z wp_mail + $GLOBALS['rzd_mail_last_conn'])
	}
	if ( $ok && $h && 'queued' === $h['status'] ) {
		$msg = rzd_mail_friendly( $h['msg'] );
		$id  = rzd_mail_log_add( array( 'to' => $to, 'subject' => $subject, 'status' => 'queued', 'msg' => $msg . ( $msg !== $h['msg'] ? ' [' . $h['msg'] . ']' : '' ), 'next' => time() + rzd_mail_retry_delay( 0 ) ), $h['payload'] );
		if ( rzd_mail_payload_get( $id ) ) {
			rzd_mail_log_update( $id, array( 'private' => $private ? 1 : 0 ) );
			rzd_mail_schedule_retry( $id, rzd_mail_retry_delay( 0 ) );
		} else {
			rzd_mail_log_update( $id, array( 'status' => 'failed', 'msg' => $msg . ' (za duże załączniki, by zapisać mail do ponowienia)' ) );
		}
		rzd_log( 'error', 'Mail w kolejce (ponowienie za 5 min) – do: ' . $to . ' – temat: ' . $subject . ' – ' . $h['msg'], 'restauracja-poczta' );
		update_option( 'rzd_mail_last_error', array( 'time' => time(), 'msg' => $msg . ' Mail czeka w kolejce – wtyczka ponowi wysyłkę.', 'raw' => substr( $h['msg'], 0, 300 ) ), false );
		return;
	}
	if ( $ok ) {
		$keep = $h && ! $private && ! empty( $s['log_body'] );
		$conn = $h ? $h['conn'] : 'serwer strony' . ( rzd_mail_takes_over() ? '' : ' (wysyłka wtyczki wyłączona)' );
		rzd_mail_log_add( array( 'to' => $to, 'subject' => $subject, 'conn' => $conn, 'status' => $h ? $h['status'] : 'sent', 'msg' => $h ? $h['msg'] : '' ), $keep ? $h['payload'] : null );
		rzd_log( $h && 'fallback' === $h['status'] ? 'warning' : 'info', 'Wysłano (' . $conn . ') – do: ' . $to . ' – temat: ' . $subject . ( $h && $h['msg'] ? ' – ' . $h['msg'] : '' ), 'restauracja-poczta' );
		update_option( 'rzd_mail_last_ok', time(), false );
		if ( get_option( 'rzd_mail_last_error' ) && ( ! $h || 'sent' === $h['status'] ) ) {
			delete_option( 'rzd_mail_last_error' );
		}
		return;
	}
	$raw = isset( $data['error'] ) ? (string) $data['error'] : '';
	$msg = rzd_mail_friendly( $raw );
	if ( empty( $GLOBALS['rzd_mail_no_log'] ) ) {
		rzd_mail_log_add( array( 'to' => $to, 'subject' => $subject, 'conn' => rzd_mail_takes_over() ? '' : 'serwer strony', 'status' => 'failed', 'msg' => $msg . ( $msg !== $raw ? ' [' . $raw . ']' : '' ) ) );
	}
	rzd_log( 'error', 'Błąd wysyłki: ' . $msg . ' [' . $raw . '] – do: ' . $to . ' – temat: ' . $subject, 'restauracja-poczta' );
	update_option( 'rzd_mail_last_error', array( 'time' => time(), 'msg' => $msg, 'raw' => substr( $raw, 0, 300 ) ), false );
}
add_action( 'wp_mail_succeeded', function ( $data ) {
	if ( isset( $GLOBALS['rzd_mail_handled'] ) ) {
		$GLOBALS['rzd_mail_last_conn'] = $GLOBALS['rzd_mail_handled']['conn'];
	}
	rzd_mail_after( true, (array) $data );
} );
add_action( 'wp_mail_failed', function ( $error ) {
	$data          = is_wp_error( $error ) ? (array) $error->get_error_data() : array();
	$data['error'] = is_wp_error( $error ) ? $error->get_error_message() : '';
	$GLOBALS['rzd_mail_last_fail'] = $data['error'];
	rzd_mail_after( false, $data );
} );

/* ============================================================
 * 6. KOLEJKA – ponowienia (Action Scheduler WooCommerce, awaryjnie WP-Cron)
 * ============================================================ */
function rzd_mail_retry_delay( $tries ) {
	$d = apply_filters( 'rzd_mail_retry_delays', array( 5 * MINUTE_IN_SECONDS, 30 * MINUTE_IN_SECONDS, 2 * HOUR_IN_SECONDS ) );
	return isset( $d[ $tries ] ) ? (int) $d[ $tries ] : 0; // 0 = koniec prób
}
function rzd_mail_schedule_retry( $id, $delay ) {
	if ( function_exists( 'as_schedule_single_action' ) ) {
		as_schedule_single_action( time() + $delay, 'rzd_mail_retry', array( $id ), 'restauracja' );
	} else {
		wp_schedule_single_event( time() + $delay, 'rzd_mail_retry', array( $id ) );
	}
}
function rzd_mail_unschedule_retry( $id ) {
	if ( function_exists( 'as_unschedule_all_actions' ) ) {
		as_unschedule_all_actions( 'rzd_mail_retry', array( $id ), 'restauracja' );
	}
	wp_clear_scheduled_hook( 'rzd_mail_retry', array( $id ) );
}

/**
 * Wysyłka zapisanej wiadomości przez wp_mail (z całym łańcuchem połączeń).
 * phpmailer_init (priorytet 1, przed ustawieniami wtyczki) odtwarza wiadomość 1:1 – adresy, HTML i tekst, załączniki, obrazki.
 */
function rzd_mail_send_payload( $p ) {
	$rebuild = function ( $m ) use ( $p ) {
		$m->clearAllRecipients();
		$m->clearAttachments();
		$m->clearCustomHeaders();
		$m->clearReplyTos();
		foreach ( array( 'to' => 'addAddress', 'cc' => 'addCC', 'bcc' => 'addBCC', 'reply_to' => 'addReplyTo' ) as $k => $fn ) {
			foreach ( (array) $p[ $k ] as $a ) {
				$m->$fn( $a['email'], $a['name'] );
			}
		}
		if ( is_email( $p['from']['email'] ) ) {
			$m->setFrom( $p['from']['email'], $p['from']['name'], false );
		}
		$m->Subject = $p['subject'];
		$m->CharSet = '' !== $p['charset'] ? $p['charset'] : 'UTF-8';
		if ( '' !== $p['html'] ) {
			$m->isHTML( true );
			$m->Body    = $p['html'];
			$m->AltBody = $p['text'];
		} else {
			$m->isHTML( false );
			$m->Body    = $p['text'];
			$m->AltBody = '';
		}
		foreach ( (array) $p['headers'] as $n => $v ) {
			$m->addCustomHeader( $n, $v );
		}
		foreach ( (array) $p['attachments'] as $a ) {
			$data = base64_decode( $a['content'] ); // phpcs:ignore
			if ( 'inline' === $a['disposition'] && '' !== $a['cid'] ) {
				$m->addStringEmbeddedImage( $data, $a['cid'], $a['name'], 'base64', $a['type'] );
			} else {
				$m->addStringAttachment( $data, $a['name'], 'base64', $a['type'] );
			}
		}
	};
	add_action( 'phpmailer_init', $rebuild, 1 );
	$ok = wp_mail( rzd_mail_emails( $p['to'] ), $p['subject'], '' !== $p['text'] ? $p['text'] : wp_strip_all_tags( $p['html'] ) );
	remove_action( 'phpmailer_init', $rebuild, 1 );
	return $ok;
}

add_action( 'rzd_mail_retry', 'rzd_mail_retry_run' );
function rzd_mail_retry_run( $id, $manual = false ) {
	$log = rzd_mail_log_get();
	$p   = rzd_mail_payload_get( $id );
	if ( ! isset( $log[ $id ] ) || 'queued' !== $log[ $id ]['status'] || ! $p ) {
		return null;
	}
	$e     = $log[ $id ];
	$tries = (int) $e['tries'] + 1;
	$GLOBALS['rzd_mail_retry_id']  = $id;
	$GLOBALS['rzd_mail_last_conn'] = '';
	$GLOBALS['rzd_mail_last_fail'] = '';
	$ok   = rzd_mail_send_payload( $p );
	$conn = $GLOBALS['rzd_mail_last_conn'];
	$fail = $GLOBALS['rzd_mail_last_fail'];
	unset( $GLOBALS['rzd_mail_retry_id'] );
	if ( $ok ) {
		$keep = empty( $e['private'] ) && ! empty( rzd_mail_settings()['log_body'] );
		if ( ! $keep ) {
			delete_option( 'rzd_mail_p_' . $id );
		}
		rzd_mail_log_update( $id, array( 'status' => 'sent', 'conn' => '' !== $conn ? $conn : 'serwer strony', 'tries' => $tries, 'next' => 0, 'payload' => $keep ? 1 : 0, 'msg' => 'wysłano ' . ( $manual ? 'ręcznie z dziennika' : 'przy ponowieniu nr ' . $tries ) . ' (wcześniej: ' . $e['msg'] . ')' ) );
		rzd_log( 'info', 'Wysłano z kolejki (próba ' . $tries . ') – do: ' . $e['to'] . ' – temat: ' . $e['subject'], 'restauracja-poczta' );
		update_option( 'rzd_mail_last_ok', time(), false );
		delete_option( 'rzd_mail_last_error' );
		return true;
	}
	$msg   = rzd_mail_friendly( $fail );
	$delay = rzd_mail_retry_delay( $tries );
	if ( $delay > 0 ) {
		rzd_mail_log_update( $id, array( 'tries' => $tries, 'next' => time() + $delay, 'msg' => $msg . ( $msg !== $fail ? ' [' . $fail . ']' : '' ) ) );
		rzd_mail_schedule_retry( $id, $delay );
		update_option( 'rzd_mail_last_error', array( 'time' => time(), 'msg' => $msg . ' Mail czeka w kolejce – kolejna próba za ' . human_time_diff( time(), time() + $delay ) . '.', 'raw' => substr( $fail, 0, 300 ) ), false );
	} else {
		rzd_mail_log_update( $id, array( 'status' => 'failed', 'tries' => $tries, 'next' => 0, 'msg' => $msg . ( $msg !== $fail ? ' [' . $fail . ']' : '' ) . ' – koniec ponowień, wyślij ręcznie z dziennika po naprawie poczty' ) );
		update_option( 'rzd_mail_last_error', array( 'time' => time(), 'msg' => $msg . ' Mail do ' . $e['to'] . ' („' . $e['subject'] . '”) nie wyszedł mimo ponowień – wyślij go ponownie z dziennika (Restauracja → Stan i poczta).', 'raw' => substr( $fail, 0, 300 ) ), false );
	}
	rzd_log( 'error', 'Ponowienie ' . $tries . ' nieudane – do: ' . $e['to'] . ' – ' . $fail, 'restauracja-poczta' );
	return false;
}

// Ręczna ponowna wysyłka z dziennika (także maili już wysłanych – np. klient nie dostał potwierdzenia).
function rzd_mail_resend( $id ) {
	$log = rzd_mail_log_get();
	if ( ! isset( $log[ $id ] ) ) {
		return new WP_Error( 'rzd_mail', 'Nie ma takiego wpisu w dzienniku.' );
	}
	if ( 'queued' === $log[ $id ]['status'] ) {
		rzd_mail_unschedule_retry( $id );
		$r = rzd_mail_retry_run( $id, true );
		if ( false === $r ) {
			$e = rzd_mail_log_get()[ $id ];
			return new WP_Error( 'rzd_mail', $e['msg'] );
		}
		return true;
	}
	$p = rzd_mail_payload_get( $id );
	if ( ! $p ) {
		return new WP_Error( 'rzd_mail', 'Treść tego maila nie jest już przechowywana (starszy niż ' . RZD_MAIL_KEEP_DAYS . ' dni, mail z linkiem do hasła albo za duże załączniki).' );
	}
	$GLOBALS['rzd_mail_no_queue'] = true;
	$GLOBALS['rzd_mail_last_fail'] = '';
	$ok = rzd_mail_send_payload( $p );
	unset( $GLOBALS['rzd_mail_no_queue'] );
	if ( $ok && 'failed' === $log[ $id ]['status'] ) {
		rzd_mail_log_update( $id, array( 'status' => 'resent', 'msg' => 'wysłano ponownie ' . wp_date( 'j.m H:i' ) . ' (wcześniej: ' . $log[ $id ]['msg'] . ')' ) );
	}
	return $ok ? true : new WP_Error( 'rzd_mail', rzd_mail_friendly( $GLOBALS['rzd_mail_last_fail'] ) );
}

/* ============================================================
 * 7. CZYTELNE KOMUNIKATY BŁĘDÓW
 * ============================================================ */
function rzd_mail_friendly( $raw ) {
	$r = strtolower( (string) $raw );
	// Komunikaty PHPMailera WordPress tłumaczy na język sklepu – porównujemy z oryginałem I tłumaczeniem
	// (te same teksty co w wp-includes/class-wp-phpmailer.php), więc działa w każdym języku.
	$has = function ( $texts ) use ( $r ) {
		foreach ( (array) $texts as $t ) {
			foreach ( array( $t, __( $t ) ) as $v ) { // phpcs:ignore -- celowo teksty WordPressa
				$v = strtolower( trim( $v, " :.\t" ) );
				if ( '' !== $v && false !== strpos( $r, $v ) ) {
					return true;
				}
			}
		}
		return false;
	};
	if ( preg_match( '/\(http 40[13]\)/', $r ) ) {
		return 'Dostawca odrzucił klucz API – sprawdź klucz i jego uprawnienia do wysyłki.';
	}
	if ( false !== strpos( $r, 'brak połączenia z serwerem dostawcy' ) ) {
		return 'Nie udało się połączyć z serwerem dostawcy poczty (API) – sprawdź, czy hosting nie blokuje połączeń wychodzących.';
	}
	if ( false !== strpos( $r, 'odrzucił wiadomość' ) ) {
		return (string) $raw; // komunikat dostawcy jest już czytelny (np. niezweryfikowany nadawca)
	}
	if ( $has( 'SMTP Error: Could not authenticate.' ) || false !== strpos( $r, '535' ) ) {
		return 'Serwer poczty odrzucił login lub hasło.';
	}
	if ( $has( array( 'SMTP Error: Could not connect to SMTP host.', 'SMTP connect() failed.', 'Invalid host: ' ) ) || false !== strpos( $r, 'timed out' ) || false !== strpos( $r, 'refused' ) ) {
		return 'Nie udało się połączyć z serwerem poczty – sprawdź adres serwera i port (hosting może blokować port; spróbuj 465 SSL albo 587 TLS, albo wysyłki przez API).';
	}
	if ( false !== strpos( $r, 'certificate' ) || false !== strpos( $r, 'starttls' ) || false !== strpos( $r, 'ssl' ) ) {
		return 'Problem z szyfrowaniem połączenia – spróbuj innego ustawienia (465 + SSL albo 587 + TLS).';
	}
	if ( $has( 'The following From address failed: ' ) || false !== strpos( $r, '553' ) || false !== strpos( $r, 'sender' ) ) {
		return 'Serwer nie pozwala wysyłać z tego adresu nadawcy – adres nadawcy musi należeć do konta pocztowego.';
	}
	if ( $has( array( 'Invalid address: ', 'SMTP Error: The following recipients failed: ', 'You must provide at least one recipient email address.' ) ) ) {
		return 'Nieprawidłowy adres e-mail odbiorcy.';
	}
	if ( $has( 'Could not instantiate mail function.' ) ) {
		return 'Serwer strony nie wysyła poczty – ustaw wysyłkę przez SMTP albo API.';
	}
	return (string) $raw;
}

/* ============================================================
 * 8. DNS DOMENY NADAWCY (SPF, DMARC) – podpowiedź, nie blokada
 * ============================================================ */
function rzd_mail_dns_report( $from ) {
	$dom = strtolower( (string) substr( (string) strrchr( (string) $from, '@' ), 1 ) );
	if ( '' === $dom || ! function_exists( 'dns_get_record' ) ) {
		return array();
	}
	$key = 'rzd_mail_dns_' . md5( $dom );
	$rep = get_transient( $key );
	if ( is_array( $rep ) ) {
		return $rep;
	}
	$txt = function ( $name, $prefix ) {
		$rows = @dns_get_record( $name, DNS_TXT ); // phpcs:ignore
		if ( false === $rows ) {
			return null; // DNS niedostępny
		}
		foreach ( (array) $rows as $r ) {
			$t = isset( $r['txt'] ) ? $r['txt'] : ( isset( $r['entries'] ) ? implode( '', (array) $r['entries'] ) : '' );
			if ( 0 === stripos( $t, $prefix ) ) {
				return $t;
			}
		}
		return '';
	};
	$rep = array( 'domain' => $dom, 'spf' => $txt( $dom, 'v=spf1' ), 'dmarc' => $txt( '_dmarc.' . $dom, 'v=DMARC1' ) );
	set_transient( $key, $rep, HOUR_IN_SECONDS );
	return $rep;
}
