<?php
/**
 * Moduł 27-poczta – PHPMailer wtyczki (ładowany dopiero przy pierwszym mailu, z części 3).
 * Dziedziczy po WP_PHPMailer (WordPress 6.8+: przetłumaczone komunikaty) albo po zwykłym PHPMailerze.
 * Mailer „rzdapi”: PHPMailer składa wiadomość jak dla SMTP (pełny MIME, końce linii CRLF),
 * a wysyłkę przejmuje rzd_mail_dispatch() – połączenie główne, zapasowe, kolejka.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class RZD_PHPMailer extends RZD_PHPMailer_Base { // phpcs:ignore Generic.Files.OneObjectStructurePerFile

	public function preSend() {
		if ( 'rzdapi' !== $this->Mailer ) {
			return parent::preSend();
		}
		$this->Mailer = 'smtp'; // nagłówki i końce linii jak dla SMTP – taki MIME przyjmują też API
		try {
			return parent::preSend();
		} finally {
			$this->Mailer = 'rzdapi';
		}
	}

	// Wywoływane przez PHPMailer::postSend() dla Mailer = 'rzdapi'.
	public function rzdapiSend( $header, $body ) {
		return rzd_mail_dispatch( $this, $header, $body );
	}

	// Wysyłka gotowej wiadomości przez SMTP (ustawienia serwera nadaje rzd_mail_conf_smtp).
	public function rzd_via_smtp( $header, $body ) {
		try {
			return $this->smtpSend( $header, $body );
		} finally {
			$this->smtpClose();
		}
	}

	// Wysyłka funkcją mail() serwera – wiadomość składana od nowa (inne nagłówki niż dla SMTP).
	public function rzd_via_mail() {
		$this->Mailer = 'mail';
		try {
			if ( ! parent::preSend() ) {
				throw new PHPMailer\PHPMailer\Exception( $this->ErrorInfo );
			}
			return $this->mailSend( $this->MIMEHeader, $this->MIMEBody );
		} finally {
			$this->Mailer = 'rzdapi';
		}
	}
}
