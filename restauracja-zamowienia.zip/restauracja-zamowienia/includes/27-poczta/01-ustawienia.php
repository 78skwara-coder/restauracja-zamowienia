<?php
/**
 * MODUŁ 27: Poczta – wszystkie maile sklepu przez wybrane połączenie, bez osobnej wtyczki.
 * Część 1: ustawienia, połączenia (główne + zapasowe), sposoby wysyłki, gotowe ustawienia dostawców, hasła.
 *
 * Sposoby wysyłki (jak WP Mail SMTP / FluentSMTP):
 * - SMTP – dowolny serwer poczty (hosting, Gmail, Microsoft 365, Zoho…, też SMTP dostawców transakcyjnych);
 * - API dostawcy (HTTPS – działa, gdy hosting blokuje porty SMTP): Brevo, SendGrid, Mailgun, Postmark,
 *   SparkPost, SMTP2GO, Mailjet, Elastic Email, MailerSend, Resend, Mandrill, Amazon SES;
 * - serwer strony (funkcja mail PHP) – np. jako połączenie zapasowe.
 * Połączenie zapasowe przejmuje mail, gdy główne zawiedzie; gdy zawiodą oba – kolejka z ponowieniami (część 3).
 *
 * Hasła i klucze: najlepiej stałe w wp-config.php (nie ma ich w bazie): RZD_SMTP_PASS (hasło SMTP),
 * RZD_MAIL_KEY / RZD_MAIL_SECRET (klucz / sekret API połączenia głównego). Wpisane w panelu – szyfrowane
 * libsodium kluczem z wp-config.php (RZD_SMTP_KEY albo LOGGED_IN_KEY+SALT). Pola nigdy nie pokazują zapisanych wartości.
 * Inne stałe połączenia głównego (SMTP): RZD_SMTP_HOST, RZD_SMTP_PORT, RZD_SMTP_ENC, RZD_SMTP_USER; nadawca: RZD_SMTP_FROM, RZD_SMTP_FROM_NAME.
 * Gdy działa inna wtyczka SMTP (albo coś podmienia wp_mail) – moduł się nie włącza (dwie wtyczki = problemy).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 1. SPOSOBY WYSYŁKI I GOTOWE USTAWIENIA
 * ============================================================ */

// Sposoby wysyłki: pola = co trzeba podać. key/secret szyfrowane.
function rzd_mail_types() {
	return array(
		'smtp'       => array( 'label' => 'SMTP – serwer poczty', 'group' => 'smtp', 'fields' => array( 'preset', 'host', 'port', 'enc', 'auth', 'user', 'pass' ) ),
		'brevo'      => array( 'label' => 'Brevo (API)', 'group' => 'api', 'fields' => array( 'key' ), 'key' => 'Klucz API (v3)', 'hint' => 'Brevo → SMTP & API → Klucze API. Nadawca musi być zweryfikowany w Brevo.' ),
		'sendgrid'   => array( 'label' => 'SendGrid (API)', 'group' => 'api', 'fields' => array( 'key', 'region' ), 'key' => 'Klucz API', 'regions' => array( 'global' => 'globalny', 'eu' => 'UE (konto EU)' ), 'hint' => 'SendGrid → Settings → API Keys (uprawnienie Mail Send). Nadawca zweryfikowany (Sender Authentication).' ),
		'mailgun'    => array( 'label' => 'Mailgun (API)', 'group' => 'api', 'fields' => array( 'key', 'domain', 'region' ), 'key' => 'Klucz API (Sending key)', 'regions' => array( 'eu' => 'UE', 'us' => 'USA' ), 'hint' => 'Mailgun → Sending → Domain settings: domena wysyłkowa i klucz. Region jak przy zakładaniu domeny.' ),
		'postmark'   => array( 'label' => 'Postmark (API)', 'group' => 'api', 'fields' => array( 'key' ), 'key' => 'Server API Token', 'hint' => 'Postmark → Servers → (serwer) → API Tokens. Nadawca zweryfikowany (Sender Signatures).' ),
		'sparkpost'  => array( 'label' => 'SparkPost (API)', 'group' => 'api', 'fields' => array( 'key', 'region' ), 'key' => 'Klucz API', 'regions' => array( 'us' => 'USA', 'eu' => 'UE' ), 'hint' => 'SparkPost → Configuration → API Keys (Transmissions: Read/Write).' ),
		'smtp2go'    => array( 'label' => 'SMTP2GO (API)', 'group' => 'api', 'fields' => array( 'key' ), 'key' => 'Klucz API', 'hint' => 'SMTP2GO → Sending → API Keys (uprawnienie Emails).' ),
		'mailjet'    => array( 'label' => 'Mailjet (API)', 'group' => 'api', 'fields' => array( 'key', 'secret' ), 'key' => 'API Key', 'secret' => 'Secret Key', 'hint' => 'Mailjet → Account settings → API Key Management.' ),
		'elastic'    => array( 'label' => 'Elastic Email (API)', 'group' => 'api', 'fields' => array( 'key' ), 'key' => 'Klucz API', 'hint' => 'Elastic Email → Settings → Manage API Keys (Send Email).' ),
		'mailersend' => array( 'label' => 'MailerSend (API)', 'group' => 'api', 'fields' => array( 'key' ), 'key' => 'API token', 'hint' => 'MailerSend → Integrations → API tokens. Domena nadawcy zweryfikowana.' ),
		'resend'     => array( 'label' => 'Resend (API)', 'group' => 'api', 'fields' => array( 'key' ), 'key' => 'Klucz API', 'hint' => 'Resend → API Keys (Sending access). Domena nadawcy zweryfikowana.' ),
		'mandrill'   => array( 'label' => 'Mailchimp Transactional / Mandrill (API)', 'group' => 'api', 'fields' => array( 'key' ), 'key' => 'Klucz API', 'hint' => 'Mailchimp Transactional → Settings → SMTP & API Info → API Keys.' ),
		'ses'        => array( 'label' => 'Amazon SES (API)', 'group' => 'api', 'fields' => array( 'key', 'secret', 'region' ), 'key' => 'Access Key ID', 'secret' => 'Secret Access Key', 'regions' => array( 'eu-central-1' => 'Frankfurt (eu-central-1)', 'eu-west-1' => 'Irlandia (eu-west-1)', 'eu-west-2' => 'Londyn (eu-west-2)', 'eu-west-3' => 'Paryż (eu-west-3)', 'eu-north-1' => 'Sztokholm (eu-north-1)', 'eu-south-1' => 'Mediolan (eu-south-1)', 'us-east-1' => 'N. Virginia (us-east-1)', 'us-east-2' => 'Ohio (us-east-2)', 'us-west-2' => 'Oregon (us-west-2)' ), 'hint' => 'AWS IAM: użytkownik z uprawnieniem ses:SendRawEmail / ses:SendEmail; region, w którym zweryfikowano domenę.' ),
		'php'        => array( 'label' => 'Serwer strony (funkcja mail PHP)', 'group' => 'other', 'fields' => array(), 'hint' => 'Jak WordPress bez wtyczek – zwykle gorsza dostarczalność. Przydaje się jako połączenie zapasowe.' ),
	);
}

/**
 * Gotowe ustawienia SMTP. Puste host = serwer indywidualny dla konta (podpowiedź mówi, gdzie go znaleźć).
 * Wartości z dokumentacji dostawców (2026-10). user = podpowiedź do pola login (np. stały login „apikey”).
 */
function rzd_mail_presets() {
	$p = array(
		'custom'      => array( 'label' => 'Własny serwer', 'group' => 'Inne', 'host' => '', 'port' => 587, 'enc' => 'tls', 'hint' => 'Dane serwera SMTP od dostawcy poczty.' ),
		// hostingi (serwer zależny od konta)
		'lhpl'        => array( 'label' => 'LH.pl', 'group' => 'Hosting w Polsce', 'host' => '', 'port' => 465, 'enc' => 'ssl', 'hint' => 'Serwer: nazwa serwera z Panelu Klienta LH.pl (np. serwer123456.lh.pl). Login: pełny adres e-mail skrzynki.' ),
		'homepl'      => array( 'label' => 'home.pl', 'group' => 'Hosting w Polsce', 'host' => '', 'port' => 465, 'enc' => 'ssl', 'hint' => 'Serwer: z panelu home.pl (Poczta → konfiguracja programu pocztowego). Login: pełny adres e-mail.' ),
		'nazwapl'     => array( 'label' => 'nazwa.pl', 'group' => 'Hosting w Polsce', 'host' => '', 'port' => 465, 'enc' => 'ssl', 'hint' => 'Serwer: z Panelu Klienta nazwa.pl (ustawienia programu pocztowego). Login: pełny adres e-mail.' ),
		'cyberfolks'  => array( 'label' => 'cyber_Folks', 'group' => 'Hosting w Polsce', 'host' => '', 'port' => 465, 'enc' => 'ssl', 'hint' => 'Serwer: z panelu cyber_Folks (DirectAdmin → konta e-mail → konfiguracja). Login: pełny adres e-mail.' ),
		'dhosting'    => array( 'label' => 'dhosting', 'group' => 'Hosting w Polsce', 'host' => '', 'port' => 465, 'enc' => 'ssl', 'hint' => 'Serwer: z panelu dhosting (Poczta → dane do konfiguracji). Login: pełny adres e-mail.' ),
		'zenbox'      => array( 'label' => 'Zenbox', 'group' => 'Hosting w Polsce', 'host' => '', 'port' => 465, 'enc' => 'ssl', 'hint' => 'Serwer: z panelu Zenbox (Poczta → konfiguracja klienta poczty). Login: pełny adres e-mail.' ),
		'hostinger'   => array( 'label' => 'Hostinger', 'group' => 'Hosting za granicą', 'host' => 'smtp.hostinger.com', 'port' => 465, 'enc' => 'ssl', 'hint' => 'Login: pełny adres e-mail skrzynki w Hostinger.' ),
		'ovh'         => array( 'label' => 'OVHcloud', 'group' => 'Hosting za granicą', 'host' => 'ssl0.ovh.net', 'port' => 465, 'enc' => 'ssl', 'hint' => 'Login: pełny adres e-mail skrzynki OVH.' ),
		// skrzynki
		'gmail'       => array( 'label' => 'Gmail / Google Workspace', 'group' => 'Skrzynki', 'host' => 'smtp.gmail.com', 'port' => 587, 'enc' => 'tls', 'hint' => 'Hasło: hasło aplikacji (Konto Google → Bezpieczeństwo → Hasła aplikacji; wymaga weryfikacji dwuetapowej), nie zwykłe hasło. Limit Gmaila: ok. 500 maili dziennie.' ),
		'm365'        => array( 'label' => 'Microsoft 365 (firmowy)', 'group' => 'Skrzynki', 'host' => 'smtp.office365.com', 'port' => 587, 'enc' => 'tls', 'hint' => 'Skrzynka musi mieć włączone „Uwierzytelnione SMTP”. UWAGA: Microsoft od końca 2026 domyślnie wyłącza logowanie hasłem do SMTP – na przyszłość lepiej połączenie przez API dostawcy transakcyjnego.' ),
		'zoho'        => array( 'label' => 'Zoho Mail (UE)', 'group' => 'Skrzynki', 'host' => 'smtp.zoho.eu', 'port' => 465, 'enc' => 'ssl', 'hint' => 'Konto w centrum danych UE (zoho.eu). Przy weryfikacji dwuetapowej: hasło aplikacji.' ),
		'yahoo'       => array( 'label' => 'Yahoo Mail', 'group' => 'Skrzynki', 'host' => 'smtp.mail.yahoo.com', 'port' => 465, 'enc' => 'ssl', 'hint' => 'Hasło: hasło aplikacji (Yahoo → Bezpieczeństwo konta).' ),
		'icloud'      => array( 'label' => 'iCloud Mail', 'group' => 'Skrzynki', 'host' => 'smtp.mail.me.com', 'port' => 587, 'enc' => 'tls', 'hint' => 'Hasło: hasło dla aplikacji (appleid.apple.com). Login: adres @icloud.com.' ),
		// SMTP dostawców transakcyjnych (gdy wolisz SMTP niż API)
		'brevo_smtp'  => array( 'label' => 'Brevo (SMTP)', 'group' => 'Dostawcy transakcyjni – SMTP', 'host' => 'smtp-relay.brevo.com', 'port' => 587, 'enc' => 'tls', 'hint' => 'Login i klucz SMTP z Brevo → SMTP & API → SMTP.' ),
		'sendgrid_smtp' => array( 'label' => 'SendGrid (SMTP)', 'group' => 'Dostawcy transakcyjni – SMTP', 'host' => 'smtp.sendgrid.net', 'port' => 587, 'enc' => 'tls', 'user' => 'apikey', 'hint' => 'Login: dosłownie „apikey”, hasło: klucz API.' ),
		'mailgun_smtp' => array( 'label' => 'Mailgun UE (SMTP)', 'group' => 'Dostawcy transakcyjni – SMTP', 'host' => 'smtp.eu.mailgun.org', 'port' => 587, 'enc' => 'tls', 'hint' => 'Login i hasło SMTP domeny (Sending → Domain settings → SMTP credentials). Konto USA: smtp.mailgun.org.' ),
		'postmark_smtp' => array( 'label' => 'Postmark (SMTP)', 'group' => 'Dostawcy transakcyjni – SMTP', 'host' => 'smtp.postmarkapp.com', 'port' => 587, 'enc' => 'tls', 'hint' => 'Login i hasło: Server API Token.' ),
		'sparkpost_smtp' => array( 'label' => 'SparkPost (SMTP)', 'group' => 'Dostawcy transakcyjni – SMTP', 'host' => 'smtp.sparkpostmail.com', 'port' => 587, 'enc' => 'tls', 'user' => 'SMTP_Injection', 'hint' => 'Login: „SMTP_Injection”, hasło: klucz API. Konto UE: smtp.eu.sparkpostmail.com.' ),
		'smtp2go_smtp' => array( 'label' => 'SMTP2GO (SMTP)', 'group' => 'Dostawcy transakcyjni – SMTP', 'host' => 'mail.smtp2go.com', 'port' => 587, 'enc' => 'tls', 'hint' => 'Login i hasło użytkownika SMTP z SMTP2GO → Sending → SMTP Users. Gdy port 587 zablokowany: 2525.' ),
		'mailjet_smtp' => array( 'label' => 'Mailjet (SMTP)', 'group' => 'Dostawcy transakcyjni – SMTP', 'host' => 'in-v3.mailjet.com', 'port' => 587, 'enc' => 'tls', 'hint' => 'Login: API Key, hasło: Secret Key.' ),
		'elastic_smtp' => array( 'label' => 'Elastic Email (SMTP)', 'group' => 'Dostawcy transakcyjni – SMTP', 'host' => 'smtp.elasticemail.com', 'port' => 2525, 'enc' => 'tls', 'hint' => 'Login i hasło SMTP z Elastic Email → Settings → SMTP.' ),
		'mailersend_smtp' => array( 'label' => 'MailerSend (SMTP)', 'group' => 'Dostawcy transakcyjni – SMTP', 'host' => 'smtp.mailersend.net', 'port' => 587, 'enc' => 'tls', 'hint' => 'Login i hasło użytkownika SMTP z MailerSend (Domains → SMTP).' ),
		'resend_smtp' => array( 'label' => 'Resend (SMTP)', 'group' => 'Dostawcy transakcyjni – SMTP', 'host' => 'smtp.resend.com', 'port' => 465, 'enc' => 'ssl', 'user' => 'resend', 'hint' => 'Login: „resend”, hasło: klucz API.' ),
		'mandrill_smtp' => array( 'label' => 'Mandrill (SMTP)', 'group' => 'Dostawcy transakcyjni – SMTP', 'host' => 'smtp.mandrillapp.com', 'port' => 587, 'enc' => 'tls', 'hint' => 'Login: dowolny (np. nazwa firmy), hasło: klucz API.' ),
		'ses_smtp'    => array( 'label' => 'Amazon SES Frankfurt (SMTP)', 'group' => 'Dostawcy transakcyjni – SMTP', 'host' => 'email-smtp.eu-central-1.amazonaws.com', 'port' => 587, 'enc' => 'tls', 'hint' => 'Dane logowania SMTP z konsoli SES (SMTP settings → Create SMTP credentials). Inny region: email-smtp.<region>.amazonaws.com.' ),
	);
	return apply_filters( 'rzd_mail_presets', $p );
}

/* ============================================================
 * 2. USTAWIENIA (połączenie główne i zapasowe)
 * ============================================================ */
function rzd_mail_conn_defaults() {
	return array( 'type' => 'smtp', 'preset' => 'custom', 'host' => '', 'port' => 587, 'enc' => 'tls', 'auth' => 1, 'user' => '', 'pass' => '', 'key' => '', 'secret' => '', 'region' => '', 'domain' => '' );
}
function rzd_mail_constants() {
	return array( 'host' => 'RZD_SMTP_HOST', 'port' => 'RZD_SMTP_PORT', 'enc' => 'RZD_SMTP_ENC', 'user' => 'RZD_SMTP_USER', 'from_email' => 'RZD_SMTP_FROM', 'from_name' => 'RZD_SMTP_FROM_NAME' );
}

/**
 * Ustawienia poczty. Zgodność wstecz (2.34.0): płaskie pola host/port/… = połączenie główne SMTP.
 * Zwraca: enabled, from_email, from_name, force_from, primary (połączenie), fallback (połączenie albo type '').
 */
function rzd_mail_settings() {
	$raw = get_option( 'rzd_mail', array() );
	$raw = is_array( $raw ) ? $raw : array();
	$s   = wp_parse_args( $raw, array( 'enabled' => 0, 'from_email' => '', 'from_name' => '', 'force_from' => 1, 'log_body' => 1 ) );
	if ( empty( $raw['primary'] ) || ! is_array( $raw['primary'] ) ) {
		$legacy = array_intersect_key( $raw, rzd_mail_conn_defaults() );
		$s['primary'] = wp_parse_args( array_merge( array( 'type' => 'smtp' ), $legacy ), rzd_mail_conn_defaults() );
	} else {
		$s['primary'] = wp_parse_args( $raw['primary'], rzd_mail_conn_defaults() );
	}
	$s['fallback'] = ! empty( $raw['fallback'] ) && is_array( $raw['fallback'] ) && ! empty( $raw['fallback']['type'] ) ? wp_parse_args( $raw['fallback'], rzd_mail_conn_defaults() ) : array( 'type' => '' );
	// stałe z wp-config.php – połączenie główne i nadawca
	foreach ( rzd_mail_constants() as $k => $c ) {
		if ( defined( $c ) ) {
			if ( in_array( $k, array( 'from_email', 'from_name' ), true ) ) {
				$s[ $k ] = constant( $c );
			} elseif ( 'smtp' === $s['primary']['type'] ) {
				$s['primary'][ $k ] = constant( $c );
			}
		}
	}
	if ( defined( 'RZD_SMTP_HOST' ) ) {
		$s['enabled']         = 1; // serwer w wp-config.php = włączone
		$s['primary']['type'] = 'smtp';
	}
	$s['primary']['port'] = (int) $s['primary']['port'];
	if ( ! empty( $s['fallback']['type'] ) ) {
		$s['fallback']['port'] = (int) $s['fallback']['port'];
	}
	// zgodność: stare odwołania $s['host'] itd. = połączenie główne
	foreach ( array( 'host', 'port', 'enc', 'auth', 'user', 'preset' ) as $k ) {
		$s[ $k ] = $s['primary'][ $k ];
	}
	return $s;
}

/* --- szyfrowanie haseł i kluczy w bazie (libsodium) --- */
function rzd_mail_key() {
	$k = defined( 'RZD_SMTP_KEY' ) ? (string) RZD_SMTP_KEY : ( ( defined( 'LOGGED_IN_KEY' ) ? LOGGED_IN_KEY : '' ) . ( defined( 'LOGGED_IN_SALT' ) ? LOGGED_IN_SALT : '' ) );
	return hash( 'sha256', 'rzd-smtp|' . $k, true );
}
function rzd_mail_encrypt( $plain ) {
	if ( '' === (string) $plain || ! function_exists( 'sodium_crypto_secretbox' ) ) {
		return '';
	}
	$nonce = random_bytes( SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
	return 'v1:' . base64_encode( $nonce . sodium_crypto_secretbox( (string) $plain, $nonce, rzd_mail_key() ) ); // phpcs:ignore
}
function rzd_mail_decrypt( $value ) {
	if ( ! is_string( $value ) || 0 !== strpos( $value, 'v1:' ) || ! function_exists( 'sodium_crypto_secretbox_open' ) ) {
		return '';
	}
	$raw = base64_decode( substr( $value, 3 ), true ); // phpcs:ignore
	if ( false === $raw || strlen( $raw ) <= SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ) {
		return '';
	}
	$plain = sodium_crypto_secretbox_open( substr( $raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ), substr( $raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ), rzd_mail_key() );
	return false === $plain ? '' : $plain;
}

/**
 * Sekret połączenia (pass / key / secret) – stała z wp-config.php dla połączenia głównego, inaczej odszyfrowany z bazy.
 * $which: 'primary' / 'fallback'.
 */
function rzd_mail_secret( $conn, $field, $which = 'primary' ) {
	if ( 'primary' === $which ) {
		$const = array( 'pass' => 'RZD_SMTP_PASS', 'key' => 'RZD_MAIL_KEY', 'secret' => 'RZD_MAIL_SECRET' );
		if ( isset( $const[ $field ] ) && defined( $const[ $field ] ) ) {
			return (string) constant( $const[ $field ] );
		}
	}
	return isset( $conn[ $field ] ) ? rzd_mail_decrypt( $conn[ $field ] ) : '';
}
function rzd_mail_password() { // zgodność (2.34.0): hasło SMTP połączenia głównego
	$s = rzd_mail_settings();
	return rzd_mail_secret( $s['primary'], 'pass', 'primary' );
}
// Zapisany sekret, którego nie da się odczytać (zmienione klucze w wp-config.php).
function rzd_mail_password_lost() {
	$s = rzd_mail_settings();
	foreach ( array( 'primary', 'fallback' ) as $w ) {
		foreach ( array( 'pass', 'key', 'secret' ) as $f ) {
			if ( ! empty( $s[ $w ][ $f ] ) && '' === rzd_mail_decrypt( $s[ $w ][ $f ] ) ) {
				return true;
			}
		}
	}
	return false;
}

// Czy połączenie ma wszystko, czego potrzebuje.
function rzd_mail_conn_ready( $conn, $which = 'primary' ) {
	$types = rzd_mail_types();
	if ( empty( $conn['type'] ) || ! isset( $types[ $conn['type'] ] ) ) {
		return false;
	}
	$f = $types[ $conn['type'] ]['fields'];
	if ( 'smtp' === $conn['type'] ) {
		return '' !== trim( (string) $conn['host'] );
	}
	foreach ( array( 'key', 'secret', 'domain' ) as $need ) {
		if ( in_array( $need, $f, true ) ) {
			$v = 'domain' === $need ? trim( (string) $conn['domain'] ) : rzd_mail_secret( $conn, $need, $which );
			if ( '' === $v ) {
				return false;
			}
		}
	}
	return true;
}
function rzd_mail_conn_label( $conn ) {
	$types = rzd_mail_types();
	if ( empty( $conn['type'] ) || ! isset( $types[ $conn['type'] ] ) ) {
		return '–';
	}
	if ( 'smtp' === $conn['type'] ) {
		return 'SMTP ' . trim( (string) $conn['host'] ) . ':' . (int) $conn['port'];
	}
	return $types[ $conn['type'] ]['label'];
}

/* --- inna wtyczka SMTP / podmieniona funkcja wp_mail --- */
function rzd_mail_conflict() {
	static $res = null;
	if ( null !== $res ) {
		return $res;
	}
	$known  = array(
		'wp-mail-smtp/wp_mail_smtp.php'     => 'WP Mail SMTP',
		'wp-mail-smtp-pro/wp_mail_smtp.php' => 'WP Mail SMTP Pro',
		'fluent-smtp/fluent-smtp.php'       => 'FluentSMTP',
		'post-smtp/postman-smtp.php'        => 'Post SMTP',
		'easy-wp-smtp/easy-wp-smtp.php'     => 'Easy WP SMTP',
		'wp-smtp/wp-smtp.php'               => 'WP SMTP',
		'gmail-smtp/main.php'               => 'Gmail SMTP',
		'smtp-mailer/main.php'              => 'SMTP Mailer',
		'suremails/suremails.php'           => 'SureMail',
		'site-mailer/site-mailer.php'       => 'Site Mailer',
	);
	$active = (array) get_option( 'active_plugins', array() );
	if ( is_multisite() ) {
		$active = array_merge( $active, array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) ) );
	}
	foreach ( $known as $file => $name ) {
		if ( in_array( $file, $active, true ) ) {
			return $res = 'wtyczka ' . $name; // phpcs:ignore
		}
	}
	if ( function_exists( 'wp_mail' ) ) {
		try {
			$rf   = new ReflectionFunction( 'wp_mail' );
			$file = wp_normalize_path( (string) $rf->getFileName() );
			if ( $file && false === strpos( $file, wp_normalize_path( ABSPATH . WPINC ) ) ) {
				return $res = 'inny dodatek podmienia funkcję wysyłki (' . basename( dirname( $file ) ) . '/' . basename( $file ) . ')'; // phpcs:ignore
			}
		} catch ( ReflectionException $e ) { // phpcs:ignore
		}
	}
	return $res = ''; // phpcs:ignore
}

// Moduł przejmuje wysyłkę: włączony, połączenie główne gotowe, brak innej wtyczki SMTP.
function rzd_mail_active() {
	$s = rzd_mail_settings();
	return ! empty( $s['enabled'] ) && rzd_mail_conn_ready( $s['primary'], 'primary' ) && '' === rzd_mail_conflict();
}
