<?php
/**
 * Moduł 27-poczta – część 4: panel (Restauracja → Stan i poczta): połączenia, wysyłka testowa, dziennik z ponowną wysyłką.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 1. ZAPIS USTAWIEŃ
 * ============================================================ */
function rzd_mail_conn_from_post( $p, $old, $allow_none ) {
	$types = rzd_mail_types();
	$type  = isset( $p['type'] ) ? sanitize_key( $p['type'] ) : 'smtp';
	if ( ! isset( $types[ $type ] ) ) {
		if ( $allow_none ) {
			return array( 'type' => '' );
		}
		$type = 'smtp';
	}
	$old     = is_array( $old ) ? wp_parse_args( $old, rzd_mail_conn_defaults() ) : rzd_mail_conn_defaults();
	$presets = rzd_mail_presets();
	$host    = preg_replace( '#^[a-z]+://#i', '', trim( sanitize_text_field( isset( $p['host'] ) ? $p['host'] : '' ) ) );
	$regions = isset( $types[ $type ]['regions'] ) ? $types[ $type ]['regions'] : array();
	$region  = isset( $p[ 'region_' . $type ] ) ? sanitize_key( $p[ 'region_' . $type ] ) : '';
	$c       = array(
		'type'   => $type,
		'preset' => isset( $p['preset'], $presets[ $p['preset'] ] ) ? $p['preset'] : 'custom',
		'host'   => preg_replace( '#[/\s].*$#', '', $host ),
		'port'   => max( 1, min( 65535, absint( isset( $p['port'] ) ? $p['port'] : 587 ) ) ),
		'enc'    => isset( $p['enc'] ) && in_array( $p['enc'], array( 'ssl', 'tls', 'none' ), true ) ? $p['enc'] : 'tls',
		'auth'   => empty( $p['auth'] ) ? 0 : 1,
		'user'   => sanitize_text_field( isset( $p['user'] ) ? $p['user'] : '' ),
		'region' => isset( $regions[ $region ] ) ? $region : (string) key( $regions ),
		'domain' => preg_replace( '/[^a-z0-9.-]/', '', strtolower( sanitize_text_field( isset( $p['domain'] ) ? $p['domain'] : '' ) ) ),
	);
	$same = $type === $old['type'];
	foreach ( array( 'pass', 'key', 'secret' ) as $f ) {
		$keep = 'pass' === $f ? ( 'smtp' === $type && 'smtp' === $old['type'] ) : $same; // klucz innego dostawcy nie ma sensu
		$c[ $f ] = $keep ? $old[ $f ] : '';
		if ( ! empty( $p[ $f . '_clear' ] ) ) {
			$c[ $f ] = '';
		} elseif ( isset( $p[ $f ] ) && '' !== (string) $p[ $f ] ) {
			$c[ $f ] = rzd_mail_encrypt( trim( (string) $p[ $f ] ) ); // bez czyszczenia znaków – hasło może mieć dowolne
		}
	}
	return $c;
}

add_action( 'admin_post_rzd_mail_save', function () {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Brak uprawnień.' );
	}
	check_admin_referer( 'rzd_mail_save' );
	$p   = wp_unslash( $_POST ); // phpcs:ignore -- poszczególne pola czyszczone niżej
	$old = rzd_mail_settings();
	$s   = array(
		'enabled'    => empty( $p['enabled'] ) ? 0 : 1,
		'from_email' => sanitize_email( isset( $p['from_email'] ) ? $p['from_email'] : '' ),
		'from_name'  => sanitize_text_field( isset( $p['from_name'] ) ? $p['from_name'] : '' ),
		'force_from' => empty( $p['force_from'] ) ? 0 : 1,
		'log_body'   => empty( $p['log_body'] ) ? 0 : 1,
		'primary'    => rzd_mail_conn_from_post( isset( $p['primary'] ) ? (array) $p['primary'] : array(), $old['primary'], false ),
		'fallback'   => rzd_mail_conn_from_post( isset( $p['fallback'] ) ? (array) $p['fallback'] : array(), $old['fallback'], true ),
	);
	if ( ! $s['log_body'] ) { // wyłączone przechowywanie treści – usuń zapisane (poza kolejką)
		$log = rzd_mail_log_get();
		foreach ( $log as $id => $e ) {
			if ( 'queued' !== $e['status'] && ! empty( $e['payload'] ) ) {
				delete_option( 'rzd_mail_p_' . $id );
				$log[ $id ]['payload'] = 0;
			}
		}
		update_option( 'rzd_mail_log', $log, false );
	}
	update_option( 'rzd_mail', $s, false );
	wp_safe_redirect( admin_url( 'admin.php?page=rzd-stan&rzd_msg=mail_saved#poczta' ) );
	exit;
} );

/* ============================================================
 * 2. WYSYŁKA TESTOWA (wybrane połączenie, bez kolejki)
 * ============================================================ */
add_action( 'admin_post_rzd_mail_test', function () {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Brak uprawnień.' );
	}
	check_admin_referer( 'rzd_mail_test' );
	$to   = sanitize_email( wp_unslash( isset( $_POST['to'] ) ? $_POST['to'] : '' ) ); // phpcs:ignore
	$conn = isset( $_POST['conn'] ) ? sanitize_key( wp_unslash( $_POST['conn'] ) ) : 'all'; // phpcs:ignore
	$res  = array( 'ok' => false, 'msg' => 'Podaj poprawny adres e-mail.' );
	if ( is_email( $to ) ) {
		$s    = rzd_mail_settings();
		$name = array( 'primary' => 'połączenie główne', 'fallback' => 'połączenie zapasowe' );
		if ( isset( $name[ $conn ] ) ) {
			$GLOBALS['rzd_mail_only'] = $conn; // test konkretnego połączenia – także przed włączeniem wysyłki
			$how = $name[ $conn ] . ' (' . rzd_mail_conn_label( $s[ $conn ] ) . ')';
		} else {
			$GLOBALS['rzd_mail_no_queue'] = true;
			$how = rzd_mail_active() ? 'ustawienia wtyczki (główne, w razie błędu zapasowe)' : 'serwer strony (wysyłka wtyczki wyłączona)';
		}
		$GLOBALS['rzd_mail_last_fail'] = '';
		$GLOBALS['rzd_mail_last_conn'] = '';
		$site = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		$ok   = wp_mail( $to, 'Test poczty – ' . $site, "To jest wiadomość testowa z wtyczki Restauracja (Stan i poczta).\n\nJeśli ją widzisz, wysyłka działa.\nSprawdzane: " . $how . '.' );
		$fail = $GLOBALS['rzd_mail_last_fail'];
		$used = $GLOBALS['rzd_mail_last_conn'];
		unset( $GLOBALS['rzd_mail_only'], $GLOBALS['rzd_mail_no_queue'] );
		$res = $ok
			? array( 'ok' => true, 'msg' => 'Wysłano na ' . $to . ( $used ? ' przez: ' . $used : '' ) . '. Sprawdź skrzynkę (także folder spam).' )
			: array( 'ok' => false, 'msg' => 'Test (' . $how . ') nieudany: ' . rzd_mail_friendly( $fail ) . ( $fail && rzd_mail_friendly( $fail ) !== $fail ? ' [' . $fail . ']' : '' ) );
	}
	set_transient( 'rzd_mail_test_' . get_current_user_id(), $res, 300 );
	wp_safe_redirect( admin_url( 'admin.php?page=rzd-stan&rzd_msg=mail_test#poczta' ) );
	exit;
} );

/* ============================================================
 * 3. DZIENNIK: ponowna wysyłka, czyszczenie
 * ============================================================ */
add_action( 'admin_post_rzd_mail_resend', function () {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Brak uprawnień.' );
	}
	check_admin_referer( 'rzd_mail_resend' );
	$id  = isset( $_POST['id'] ) ? sanitize_key( wp_unslash( $_POST['id'] ) ) : ''; // phpcs:ignore
	$r   = rzd_mail_resend( $id );
	$res = true === $r ? array( 'ok' => true, 'msg' => 'Wysłano ponownie.' ) : array( 'ok' => false, 'msg' => 'Nie udało się wysłać ponownie: ' . $r->get_error_message() );
	set_transient( 'rzd_mail_test_' . get_current_user_id(), $res, 300 );
	wp_safe_redirect( admin_url( 'admin.php?page=rzd-stan&rzd_msg=mail_test#rzd-mail-log' ) );
	exit;
} );
add_action( 'admin_post_rzd_mail_log_clear', function () {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Brak uprawnień.' );
	}
	check_admin_referer( 'rzd_mail_log_clear' );
	$keep = array();
	foreach ( rzd_mail_log_get() as $id => $e ) {
		if ( 'queued' === $e['status'] ) {
			$keep[ $id ] = $e; // kolejka zostaje
		} else {
			delete_option( 'rzd_mail_p_' . $id );
		}
	}
	update_option( 'rzd_mail_log', $keep, false );
	wp_safe_redirect( admin_url( 'admin.php?page=rzd-stan#rzd-mail-log' ) );
	exit;
} );

/* ============================================================
 * 4. SEKCJA „POCZTA” STRONY STAN I POCZTA (strona – moduł 28)
 * ============================================================ */

// Pola jednego połączenia. $which: primary / fallback.
function rzd_mail_conn_fields_html( $which, $c ) {
	$types   = rzd_mail_types();
	$presets = rzd_mail_presets();
	$primary = 'primary' === $which;
	$n       = function ( $f ) use ( $which ) {
		return esc_attr( $which . '[' . $f . ']' );
	};
	$idp     = 'rzd-mail-' . $which . '-';
	$consts  = array();
	if ( $primary ) {
		foreach ( rzd_mail_constants() + array( 'pass' => 'RZD_SMTP_PASS', 'key' => 'RZD_MAIL_KEY', 'secret' => 'RZD_MAIL_SECRET' ) as $k => $cn ) {
			if ( defined( $cn ) ) {
				$consts[ $k ] = $cn;
			}
		}
	}
	$ro     = function ( $k ) use ( $consts ) {
		return isset( $consts[ $k ] ) ? ' readonly title="Ustawione w wp-config.php"' : '';
	};
	$groups = array( 'smtp' => 'Serwer poczty', 'api' => 'API dostawcy (HTTPS – działa też, gdy hosting blokuje porty poczty)', 'other' => 'Inne' );
	$type   = (string) $c['type'];
	$secret_row = function ( $f, $label_default ) use ( $c, $which, $n, $idp, $consts ) {
		$stored = '' !== rzd_mail_secret( $c, $f, $which ) || ! empty( $c[ $f ] );
		?>
		<tr data-rzd-field="<?php echo esc_attr( $f ); ?>"><th><label for="<?php echo esc_attr( $idp . $f ); ?>" data-rzd-label="<?php echo esc_attr( $f ); ?>"><?php echo esc_html( $label_default ); ?></label></th><td>
			<?php if ( isset( $consts[ $f ] ) ) : ?>
				<em>ustawione w wp-config.php (<?php echo esc_html( $consts[ $f ] ); ?>)</em>
			<?php else : ?>
				<input type="password" class="regular-text" name="<?php echo $n( $f ); // phpcs:ignore ?>" id="<?php echo esc_attr( $idp . $f ); ?>" value="" autocomplete="new-password" placeholder="<?php echo $stored ? 'zapisane – wpisz, aby zmienić' : ''; ?>">
				<?php if ( $stored ) : ?><label style="margin-left:8px"><input type="checkbox" name="<?php echo $n( $f . '_clear' ); // phpcs:ignore ?>" value="1"> usuń zapisane</label><?php endif; ?>
			<?php endif; ?>
		</td></tr>
		<?php
	};
	?>
	<table class="form-table rzd-mail-conn" role="presentation" data-rzd-conn="<?php echo esc_attr( $which ); ?>">
		<tr><th><label for="<?php echo esc_attr( $idp . 'type' ); ?>">Sposób wysyłki</label></th><td>
			<select name="<?php echo $n( 'type' ); // phpcs:ignore ?>" id="<?php echo esc_attr( $idp . 'type' ); ?>" class="rzd-mail-type"<?php echo isset( $consts['host'] ) ? ' disabled' : ''; ?>>
				<?php if ( ! $primary ) : ?><option value="" <?php selected( $type, '' ); ?>>brak – bez połączenia zapasowego</option><?php endif; ?>
				<?php foreach ( $groups as $g => $glabel ) : ?>
					<optgroup label="<?php echo esc_attr( $glabel ); ?>">
						<?php foreach ( $types as $k => $t ) : ?>
							<?php if ( $t['group'] === $g ) : ?>
								<option value="<?php echo esc_attr( $k ); ?>" data-fields="<?php echo esc_attr( implode( ',', $t['fields'] ) ); ?>" data-key="<?php echo esc_attr( isset( $t['key'] ) ? $t['key'] : '' ); ?>" data-secret="<?php echo esc_attr( isset( $t['secret'] ) ? $t['secret'] : '' ); ?>" data-hint="<?php echo esc_attr( isset( $t['hint'] ) ? $t['hint'] : '' ); ?>" <?php selected( $type, $k ); ?>><?php echo esc_html( $t['label'] ); ?></option>
							<?php endif; ?>
						<?php endforeach; ?>
					</optgroup>
				<?php endforeach; ?>
			</select>
			<?php if ( isset( $consts['host'] ) ) : ?><input type="hidden" name="<?php echo $n( 'type' ); // phpcs:ignore ?>" value="smtp"><?php endif; ?>
			<p class="description rzd-mail-type-hint"><?php echo esc_html( isset( $types[ $type ]['hint'] ) ? $types[ $type ]['hint'] : '' ); ?></p>
		</td></tr>
		<tr data-rzd-field="preset"><th><label for="<?php echo esc_attr( $idp . 'preset' ); ?>">Dostawca poczty</label></th><td>
			<select name="<?php echo $n( 'preset' ); // phpcs:ignore ?>" id="<?php echo esc_attr( $idp . 'preset' ); ?>" class="rzd-mail-preset">
				<?php
				$last = null;
				foreach ( $presets as $k => $pr ) :
					$g = isset( $pr['group'] ) ? $pr['group'] : 'Inne';
					if ( $g !== $last ) {
						echo ( null !== $last ? '</optgroup>' : '' ) . '<optgroup label="' . esc_attr( $g ) . '">';
						$last = $g;
					}
					?>
					<option value="<?php echo esc_attr( $k ); ?>" data-host="<?php echo esc_attr( $pr['host'] ); ?>" data-port="<?php echo esc_attr( $pr['port'] ); ?>" data-enc="<?php echo esc_attr( $pr['enc'] ); ?>" data-user="<?php echo esc_attr( isset( $pr['user'] ) ? $pr['user'] : '' ); ?>" data-hint="<?php echo esc_attr( $pr['hint'] ); ?>" <?php selected( $c['preset'], $k ); ?>><?php echo esc_html( $pr['label'] ); ?></option>
				<?php endforeach; ?>
				<?php echo null !== $last ? '</optgroup>' : ''; ?>
			</select>
			<p class="description rzd-mail-preset-hint"><?php echo esc_html( isset( $presets[ $c['preset'] ] ) ? $presets[ $c['preset'] ]['hint'] : '' ); ?></p>
		</td></tr>
		<tr data-rzd-field="host"><th><label for="<?php echo esc_attr( $idp . 'host' ); ?>">Serwer</label></th><td><input type="text" class="regular-text rzd-mail-host" name="<?php echo $n( 'host' ); // phpcs:ignore ?>" id="<?php echo esc_attr( $idp . 'host' ); ?>" value="<?php echo esc_attr( $c['host'] ); ?>"<?php echo $ro( 'host' ); // phpcs:ignore ?> placeholder="np. serwer123456.lh.pl"></td></tr>
		<tr data-rzd-field="port"><th><label for="<?php echo esc_attr( $idp . 'port' ); ?>">Port i szyfrowanie</label></th><td>
			<input type="number" min="1" max="65535" style="width:90px" class="rzd-mail-port" name="<?php echo $n( 'port' ); // phpcs:ignore ?>" id="<?php echo esc_attr( $idp . 'port' ); ?>" value="<?php echo esc_attr( $c['port'] ); ?>"<?php echo $ro( 'port' ); // phpcs:ignore ?>>
			<select name="<?php echo $n( 'enc' ); // phpcs:ignore ?>" class="rzd-mail-enc" aria-label="Szyfrowanie">
				<option value="ssl" <?php selected( $c['enc'], 'ssl' ); ?>>SSL (zwykle port 465)</option>
				<option value="tls" <?php selected( $c['enc'], 'tls' ); ?>>TLS / STARTTLS (zwykle port 587)</option>
				<option value="none" <?php selected( $c['enc'], 'none' ); ?>>bez szyfrowania (tylko serwer lokalny)</option>
			</select>
		</td></tr>
		<tr data-rzd-field="auth"><th>Logowanie</th><td><label><input type="checkbox" name="<?php echo $n( 'auth' ); // phpcs:ignore ?>" value="1" <?php checked( ! empty( $c['auth'] ) ); ?>> serwer wymaga loginu i hasła</label></td></tr>
		<tr data-rzd-field="user"><th><label for="<?php echo esc_attr( $idp . 'user' ); ?>">Login</label></th><td><input type="text" class="regular-text rzd-mail-user" name="<?php echo $n( 'user' ); // phpcs:ignore ?>" id="<?php echo esc_attr( $idp . 'user' ); ?>" value="<?php echo esc_attr( $c['user'] ); ?>"<?php echo $ro( 'user' ); // phpcs:ignore ?> autocomplete="off"></td></tr>
		<?php $secret_row( 'pass', 'Hasło' ); ?>
		<?php $secret_row( 'key', 'Klucz API' ); ?>
		<?php $secret_row( 'secret', 'Sekret' ); ?>
		<tr data-rzd-field="domain"><th><label for="<?php echo esc_attr( $idp . 'domain' ); ?>">Domena wysyłkowa</label></th><td><input type="text" class="regular-text" name="<?php echo $n( 'domain' ); // phpcs:ignore ?>" id="<?php echo esc_attr( $idp . 'domain' ); ?>" value="<?php echo esc_attr( $c['domain'] ); ?>" placeholder="np. mg.twoja-domena.pl"></td></tr>
		<?php foreach ( $types as $k => $t ) : ?>
			<?php if ( ! empty( $t['regions'] ) ) : ?>
				<tr data-rzd-field="region" data-rzd-type="<?php echo esc_attr( $k ); ?>"><th>Region konta</th><td>
					<select name="<?php echo $n( 'region_' . $k ); // phpcs:ignore ?>" aria-label="Region konta">
						<?php foreach ( $t['regions'] as $rk => $rl ) : ?>
							<option value="<?php echo esc_attr( $rk ); ?>" <?php selected( $type === $k ? $c['region'] : '', $rk ); ?>><?php echo esc_html( $rl ); ?></option>
						<?php endforeach; ?>
					</select>
				</td></tr>
			<?php endif; ?>
		<?php endforeach; ?>
	</table>
	<?php if ( $primary && $consts ) : ?>
		<p class="description">Część ustawień pochodzi z wp-config.php (<?php echo esc_html( implode( ', ', $consts ) ); ?>) – w panelu tylko do odczytu.</p>
	<?php endif; ?>
	<?php
}

function rzd_mail_status_html( $e ) {
	switch ( $e['status'] ) {
		case 'sent':
			return '✅ wysłano';
		case 'resent':
			return '✅ wysłano ponownie';
		case 'fallback':
			return '⚠️ wysłano zapasowym';
		case 'queued':
			return '⏳ w kolejce' . ( $e['next'] ? ' – próba ' . ( (int) $e['tries'] + 1 ) . ' o ' . wp_date( 'H:i', (int) $e['next'] ) : '' );
	}
	return '<span style="color:#b32d2e">❌ nie wysłano</span>';
}

function rzd_mail_section_html() {
	$s        = rzd_mail_settings();
	$conflict = rzd_mail_conflict();
	$err      = get_option( 'rzd_mail_last_error' );
	$ok_at    = (int) get_option( 'rzd_mail_last_ok' );
	$test     = get_transient( 'rzd_mail_test_' . get_current_user_id() );
	if ( $test ) {
		delete_transient( 'rzd_mail_test_' . get_current_user_id() );
	}
	$fmt  = function ( $ts ) {
		return wp_date( 'j.m.Y H:i', $ts );
	};
	$log  = rzd_mail_log_get();
	$fb   = ! empty( $s['fallback']['type'] );
	$ro_f = function ( $k ) {
		$c = rzd_mail_constants();
		return defined( $c[ $k ] ) ? ' readonly title="Ustawione w wp-config.php"' : '';
	};
	?>
	<h2 id="poczta">Poczta</h2>
	<p style="max-width:900px">Wszystkie maile sklepu (zamówienia WooCommerce, zmiany terminu, resety haseł, alarmy wtyczki) mogą iść przez serwer poczty z logowaniem albo przez API dostawcy maili zamiast przez serwer strony – rzadziej trafiają do spamu i wiadomo, czy doszły. Gdy połączenie główne zawiedzie, mail idzie zapasowym; gdy oba – czeka w kolejce i wtyczka ponawia wysyłkę (po 5 min, 30 min i 2 godz.).</p>
	<?php if ( $conflict ) : ?>
		<div class="notice notice-warning inline"><p><strong>Moduł poczty jest wyłączony:</strong> wysyłką zarządza już <?php echo esc_html( $conflict ); ?>. Ustaw pocztę tam albo wyłącz tamtą wtyczkę.</p></div>
	<?php endif; ?>
	<?php if ( $test ) : ?>
		<div class="notice <?php echo $test['ok'] ? 'notice-success' : 'notice-error'; ?> inline"><p><?php echo esc_html( $test['msg'] ); ?></p></div>
	<?php endif; ?>
	<?php if ( rzd_mail_password_lost() ) : ?>
		<div class="notice notice-error inline"><p>Zapisanego hasła lub klucza nie da się odczytać (zmieniły się klucze w wp-config.php). Wpisz je ponownie.</p></div>
	<?php endif; ?>
	<p>
		Stan: <strong><?php echo rzd_mail_active() ? 'wysyłka przez ' . esc_html( rzd_mail_conn_label( $s['primary'] ) ) . ( $fb ? ', zapasowo: ' . esc_html( rzd_mail_conn_label( $s['fallback'] ) ) : '' ) : 'wysyłka przez serwer strony'; ?></strong>
		<?php if ( $ok_at ) : ?> · ostatni wysłany mail: <?php echo esc_html( $fmt( $ok_at ) ); ?><?php endif; ?>
		<?php if ( is_array( $err ) ) : ?><br><span style="color:#b32d2e">Ostatni błąd (<?php echo esc_html( $fmt( (int) $err['time'] ) ); ?>): <?php echo esc_html( $err['msg'] ); ?></span><?php endif; ?>
	</p>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="rzd-mail-form" autocomplete="off">
		<input type="hidden" name="action" value="rzd_mail_save">
		<?php wp_nonce_field( 'rzd_mail_save' ); ?>
		<table class="form-table" role="presentation">
			<tr><th>Wysyłka przez wtyczkę</th><td><label><input type="checkbox" name="enabled" value="1" <?php checked( ! empty( $s['enabled'] ) ); ?>> włączona</label>
				<p class="description">Przed włączeniem możesz sprawdzić połączenie wysyłką testową (niżej).</p></td></tr>
			<tr><th><label for="rzd-mail-from">Nadawca</label></th><td>
				<input type="email" class="regular-text" name="from_email" id="rzd-mail-from" value="<?php echo esc_attr( $s['from_email'] ); ?>"<?php echo $ro_f( 'from_email' ); // phpcs:ignore ?> placeholder="np. zamowienia@twoja-domena.pl">
				<input type="text" name="from_name" value="<?php echo esc_attr( $s['from_name'] ); ?>"<?php echo $ro_f( 'from_name' ); // phpcs:ignore ?> placeholder="nazwa nadawcy" aria-label="Nazwa nadawcy">
				<p><label><input type="checkbox" name="force_from" value="1" <?php checked( ! empty( $s['force_from'] ) ); ?>> ten nadawca dla wszystkich maili (zalecane – serwer i dostawcy API zwykle pozwalają wysyłać tylko z adresu konta / zweryfikowanej domeny)</label></p>
			</td></tr>
			<tr><th>Dziennik</th><td><label><input type="checkbox" name="log_body" value="1" <?php checked( ! empty( $s['log_body'] ) ); ?>> przechowuj treść maili przez <?php echo (int) RZD_MAIL_KEEP_DAYS; ?> dni – do ponownej wysyłki z dziennika</label>
				<p class="description">Treść zawiera dane klientów (adresy, zamówienia) – po <?php echo (int) RZD_MAIL_KEEP_DAYS; ?> dniach jest usuwana. Maili z linkiem do ustawienia hasła wtyczka nie przechowuje.</p></td></tr>
		</table>
		<h3>Połączenie główne</h3>
		<?php rzd_mail_conn_fields_html( 'primary', $s['primary'] ); ?>
		<h3>Połączenie zapasowe <span style="font-weight:normal;font-size:13px">(opcjonalne – przejmuje maile, gdy główne nie działa)</span></h3>
		<?php rzd_mail_conn_fields_html( 'fallback', $fb ? $s['fallback'] : wp_parse_args( array( 'type' => '' ), rzd_mail_conn_defaults() ) ); ?>
		<p class="description" style="max-width:900px">Hasła i klucze zapisywane są zaszyfrowane. Bezpieczniej: w wp-config.php <code>define( 'RZD_SMTP_PASS', '…' );</code> (hasło SMTP) albo <code>RZD_MAIL_KEY</code> / <code>RZD_MAIL_SECRET</code> (klucz / sekret API) – wtedy nie ma ich w bazie (dotyczy połączenia głównego).</p>
		<?php submit_button( 'Zapisz ustawienia poczty' ); ?>
	</form>
	<h3>Wysyłka testowa</h3>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin:0 0 18px">
		<input type="hidden" name="action" value="rzd_mail_test">
		<?php wp_nonce_field( 'rzd_mail_test' ); ?>
		<input type="email" name="to" class="regular-text" value="<?php echo esc_attr( wp_get_current_user()->user_email ); ?>" aria-label="Adres testowy">
		<select name="conn" aria-label="Co sprawdzić">
			<option value="all">tak jak wysyłają się maile sklepu</option>
			<option value="primary">tylko połączenie główne</option>
			<?php if ( $fb ) : ?><option value="fallback">tylko połączenie zapasowe</option><?php endif; ?>
		</select>
		<button type="submit" class="button">Wyślij mail testowy</button>
		<p class="description">Test zapisanych ustawień (najpierw zapisz zmiany). Mail testowy nie trafia do kolejki – błąd widać od razu.</p>
	</form>

	<h3 id="rzd-mail-log">Dziennik wysyłek <span style="font-weight:normal;font-size:13px">(ostatnie <?php echo (int) RZD_MAIL_LOG_MAX; ?>; szczegóły techniczne: <a href="<?php echo esc_url( admin_url( 'admin.php?page=wc-status&tab=logs&source=restauracja-poczta' ) ); ?>">WooCommerce → Status → Logi</a>)</span></h3>
	<?php if ( ! $log ) : ?>
		<p>Jeszcze nie ma wpisów.</p>
	<?php else : ?>
		<div style="max-height:480px;overflow:auto;max-width:1200px">
		<table class="widefat striped rzd-mail-log">
			<thead><tr><th style="width:110px">Kiedy</th><th>Do</th><th>Temat</th><th>Którędy</th><th>Wynik</th><th style="width:120px"></th></tr></thead>
			<tbody>
			<?php foreach ( $log as $id => $e ) : ?>
				<tr data-rzd-status="<?php echo esc_attr( $e['status'] ); ?>">
					<td><?php echo esc_html( wp_date( 'j.m H:i', (int) $e['time'] ) ); ?></td>
					<td><?php echo esc_html( $e['to'] ); ?></td>
					<td><?php echo esc_html( $e['subject'] ); ?></td>
					<td><?php echo esc_html( $e['conn'] ); ?></td>
					<td><?php echo rzd_mail_status_html( $e ); // phpcs:ignore -- stałe teksty ?><?php if ( '' !== (string) $e['msg'] ) : ?><br><small><?php echo esc_html( $e['msg'] ); ?></small><?php endif; ?></td>
					<td>
						<?php if ( ! empty( $e['payload'] ) ) : ?>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
								<input type="hidden" name="action" value="rzd_mail_resend"><input type="hidden" name="id" value="<?php echo esc_attr( $id ); ?>">
								<?php wp_nonce_field( 'rzd_mail_resend' ); ?>
								<button type="submit" class="button button-small"><?php echo 'queued' === $e['status'] ? 'Wyślij teraz' : 'Wyślij ponownie'; ?></button>
							</form>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		</div>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:8px">
			<input type="hidden" name="action" value="rzd_mail_log_clear"><?php wp_nonce_field( 'rzd_mail_log_clear' ); ?>
			<button type="submit" class="button-link" onclick="return confirm('Wyczyścić dziennik? Maile w kolejce zostają.');">Wyczyść dziennik</button>
		</form>
	<?php endif; ?>
	<?php
	$from = is_email( $s['from_email'] ) ? $s['from_email'] : get_option( 'admin_email' );
	$dns  = rzd_mail_dns_report( $from );
	if ( $dns ) :
		?>
		<h3>Domena nadawcy: <?php echo esc_html( $dns['domain'] ); ?></h3>
		<p style="max-width:900px" class="description">Najczęstsza przyczyna maili w spamie to brak wpisów w DNS domeny – ustawia się je u dostawcy domeny (np. w panelu LH.pl), nie w WordPressie. Dostawcy API (Brevo, SendGrid…) podają w swoim panelu wpisy do dodania.</p>
		<ul style="list-style:disc;margin-left:20px">
			<?php if ( null === $dns['spf'] ) : ?>
				<li>Nie udało się sprawdzić DNS z serwera strony.</li>
			<?php else : ?>
				<li><strong>SPF</strong> (kto może wysyłać w imieniu domeny): <?php echo '' !== $dns['spf'] ? '✅ <code>' . esc_html( $dns['spf'] ) . '</code> – sprawdź, czy obejmuje serwer poczty / dostawcę' : '❌ brak – dopisz rekord TXT <code>v=spf1 …</code> (dostawca poczty podaje treść)'; ?></li>
				<li><strong>DMARC</strong> (co robić z mailami, które nie przejdą SPF/DKIM): <?php echo '' !== (string) $dns['dmarc'] ? '✅ <code>' . esc_html( $dns['dmarc'] ) . '</code>' : '❌ brak – zalecany rekord TXT <code>_dmarc</code>, np. <code>v=DMARC1; p=none; rua=mailto:…</code>'; ?></li>
				<li><strong>DKIM</strong> (podpis maili): włącza się u dostawcy poczty (np. w panelu LH.pl / Google / Brevo) – wtyczka nie sprawdzi go bez nazwy selektora.</li>
			<?php endif; ?>
		</ul>
	<?php endif; ?>
	<?php
	echo rzd_js_tag( 'assets/js/admin/rzd-poczta.js' ); // phpcs:ignore
}
