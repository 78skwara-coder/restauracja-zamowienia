<?php
/**
 * Moduł 27-poczta – wysyłka przez API dostawców (HTTPS).
 * Wiadomość w jednej postaci (rzd_mail_msg_from_phpmailer w części 3), każdy dostawca wg swojej dokumentacji:
 * from{email,name}, to/cc/bcc/reply_to [{email,name}], subject, html, text, headers{nazwa:wartość},
 * attachments [{name,type,content(base64),disposition,cid}], raw (pełny MIME – gdzie dostawca go przyjmuje).
 * Każda funkcja zwraca true albo WP_Error z czytelnym komunikatem dostawcy.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function rzd_mail_addr_str( $a ) {
	$name = trim( (string) ( isset( $a['name'] ) ? $a['name'] : '' ) );
	if ( '' === $name ) {
		return $a['email'];
	}
	return ( preg_match( '/[,;:<>@"()\[\]\\\\]/', $name ) ? '"' . str_replace( array( '\\', '"' ), array( '\\\\', '\\"' ), $name ) . '"' : $name ) . ' <' . $a['email'] . '>';
}
function rzd_mail_emails( $list ) {
	return array_values( array_map( function ( $a ) {
		return $a['email'];
	}, (array) $list ) );
}

// Żądanie HTTP do dostawcy. Zwraca [code, body, json] albo WP_Error (brak połączenia).
function rzd_mail_http( $url, $args ) {
	$args = wp_parse_args( $args, array( 'method' => 'POST', 'timeout' => 20, 'headers' => array() ) );
	$args['headers'] = array_merge( array( 'User-Agent' => 'Restauracja-Zamowienia/' . RZD_PLUGIN_VERSION ), $args['headers'] );
	$r = wp_remote_request( $url, $args );
	if ( is_wp_error( $r ) ) {
		return new WP_Error( 'rzd_mail', 'Brak połączenia z serwerem dostawcy: ' . $r->get_error_message() );
	}
	$body = (string) wp_remote_retrieve_body( $r );
	return array( 'code' => (int) wp_remote_retrieve_response_code( $r ), 'body' => $body, 'json' => json_decode( $body, true ), 'headers' => wp_remote_retrieve_headers( $r ) );
}
function rzd_mail_http_error( $label, $res, $msg ) {
	$msg = rtrim( trim( (string) $msg ), '.' );
	return new WP_Error( 'rzd_mail', 'dostawca odrzucił wiadomość (HTTP ' . $res['code'] . ')' . ( '' !== $msg ? ': ' . $msg : '' ) . '.', array( 'code' => $res['code'], 'provider' => $label ) );
}
function rzd_mail_json_post( $url, $headers, $payload ) {
	return rzd_mail_http( $url, array( 'headers' => array_merge( array( 'Content-Type' => 'application/json', 'Accept' => 'application/json' ), $headers ), 'body' => wp_json_encode( $payload ) ) );
}

/* ============================================================
 * DOSTAWCY
 * ============================================================ */

// Brevo – POST /v3/smtp/email, nagłówek api-key, 201 {messageId}.
function rzd_mail_send_brevo( $m, $key ) {
	$map = function ( $l ) {
		return array_map( function ( $a ) {
			return array_filter( array( 'email' => $a['email'], 'name' => $a['name'] ) );
		}, (array) $l );
	};
	$p = array( 'sender' => array_filter( array( 'email' => $m['from']['email'], 'name' => $m['from']['name'] ) ), 'to' => $map( $m['to'] ), 'subject' => $m['subject'] );
	if ( $m['cc'] ) {
		$p['cc'] = $map( $m['cc'] );
	}
	if ( $m['bcc'] ) {
		$p['bcc'] = $map( $m['bcc'] );
	}
	if ( $m['reply_to'] ) {
		$p['replyTo'] = array_filter( array( 'email' => $m['reply_to'][0]['email'], 'name' => $m['reply_to'][0]['name'] ) );
	}
	if ( '' !== $m['html'] ) {
		$p['htmlContent'] = $m['html'];
	}
	if ( '' !== $m['text'] ) {
		$p['textContent'] = $m['text'];
	}
	if ( $m['headers'] ) {
		$p['headers'] = $m['headers'];
	}
	if ( $m['attachments'] ) {
		$p['attachment'] = array_map( function ( $a ) {
			return array( 'content' => $a['content'], 'name' => $a['name'] );
		}, $m['attachments'] );
	}
	$r = rzd_mail_json_post( 'https://api.brevo.com/v3/smtp/email', array( 'api-key' => $key ), $p );
	if ( is_wp_error( $r ) ) {
		return $r;
	}
	return ( $r['code'] >= 200 && $r['code'] < 300 ) ? true : rzd_mail_http_error( 'Brevo', $r, isset( $r['json']['message'] ) ? $r['json']['message'] : $r['body'] );
}

// SendGrid – POST /v3/mail/send, Bearer, 202 (pusta odpowiedź).
function rzd_mail_send_sendgrid( $m, $key, $region ) {
	$map = function ( $l ) {
		return array_map( function ( $a ) {
			return array_filter( array( 'email' => $a['email'], 'name' => $a['name'] ) );
		}, (array) $l );
	};
	$pers = array( 'to' => $map( $m['to'] ) );
	if ( $m['cc'] ) {
		$pers['cc'] = $map( $m['cc'] );
	}
	if ( $m['bcc'] ) {
		$pers['bcc'] = $map( $m['bcc'] );
	}
	$content = array();
	if ( '' !== $m['text'] ) {
		$content[] = array( 'type' => 'text/plain', 'value' => $m['text'] ); // text/plain musi być pierwszy
	}
	if ( '' !== $m['html'] ) {
		$content[] = array( 'type' => 'text/html', 'value' => $m['html'] );
	}
	$p = array( 'personalizations' => array( $pers ), 'from' => array_filter( array( 'email' => $m['from']['email'], 'name' => $m['from']['name'] ) ), 'subject' => $m['subject'], 'content' => $content );
	if ( $m['reply_to'] ) {
		$p['reply_to'] = array_filter( array( 'email' => $m['reply_to'][0]['email'], 'name' => $m['reply_to'][0]['name'] ) );
	}
	if ( $m['headers'] ) {
		$p['headers'] = $m['headers'];
	}
	if ( $m['attachments'] ) {
		$p['attachments'] = array_map( function ( $a ) {
			return array_filter( array( 'content' => $a['content'], 'filename' => $a['name'], 'type' => $a['type'], 'disposition' => $a['disposition'], 'content_id' => $a['cid'] ) );
		}, $m['attachments'] );
	}
	$host = 'eu' === $region ? 'https://api.eu.sendgrid.com' : 'https://api.sendgrid.com';
	$r    = rzd_mail_json_post( $host . '/v3/mail/send', array( 'Authorization' => 'Bearer ' . $key ), $p );
	if ( is_wp_error( $r ) ) {
		return $r;
	}
	if ( $r['code'] >= 200 && $r['code'] < 300 ) {
		return true;
	}
	$e = isset( $r['json']['errors'] ) ? implode( '; ', wp_list_pluck( (array) $r['json']['errors'], 'message' ) ) : $r['body'];
	return rzd_mail_http_error( 'SendGrid', $r, $e );
}

// Mailgun – POST /v3/{domena}/messages.mime (gotowy MIME + lista odbiorców, także UDW), Basic api:klucz, 200 {id,message}.
function rzd_mail_send_mailgun( $m, $key, $domain, $region ) {
	$host     = 'us' === $region ? 'https://api.mailgun.net' : 'https://api.eu.mailgun.net';
	$boundary = 'rzd' . wp_generate_password( 24, false );
	$body     = '';
	foreach ( array_merge( rzd_mail_emails( $m['to'] ), rzd_mail_emails( $m['cc'] ), rzd_mail_emails( $m['bcc'] ) ) as $to ) {
		$body .= '--' . $boundary . "\r\nContent-Disposition: form-data; name=\"to\"\r\n\r\n" . $to . "\r\n";
	}
	$body .= '--' . $boundary . "\r\nContent-Disposition: form-data; name=\"message\"; filename=\"message.mime\"\r\nContent-Type: message/rfc822\r\n\r\n" . $m['raw'] . "\r\n--" . $boundary . "--\r\n";
	$r = rzd_mail_http( $host . '/v3/' . rawurlencode( trim( (string) $domain ) ) . '/messages.mime', array( 'headers' => array( 'Authorization' => 'Basic ' . base64_encode( 'api:' . $key ), 'Content-Type' => 'multipart/form-data; boundary=' . $boundary ), 'body' => $body ) ); // phpcs:ignore
	if ( is_wp_error( $r ) ) {
		return $r;
	}
	return ( 200 === $r['code'] ) ? true : rzd_mail_http_error( 'Mailgun', $r, isset( $r['json']['message'] ) ? $r['json']['message'] : $r['body'] );
}

// Postmark – POST /email, X-Postmark-Server-Token, 200 {ErrorCode:0}.
function rzd_mail_send_postmark( $m, $key ) {
	$p = array( 'From' => rzd_mail_addr_str( $m['from'] ), 'To' => implode( ',', array_map( 'rzd_mail_addr_str', $m['to'] ) ), 'Subject' => $m['subject'], 'MessageStream' => 'outbound' );
	if ( $m['cc'] ) {
		$p['Cc'] = implode( ',', array_map( 'rzd_mail_addr_str', $m['cc'] ) );
	}
	if ( $m['bcc'] ) {
		$p['Bcc'] = implode( ',', array_map( 'rzd_mail_addr_str', $m['bcc'] ) );
	}
	if ( $m['reply_to'] ) {
		$p['ReplyTo'] = implode( ',', array_map( 'rzd_mail_addr_str', $m['reply_to'] ) );
	}
	if ( '' !== $m['html'] ) {
		$p['HtmlBody'] = $m['html'];
	}
	if ( '' !== $m['text'] ) {
		$p['TextBody'] = $m['text'];
	}
	if ( $m['headers'] ) {
		$p['Headers'] = array();
		foreach ( $m['headers'] as $n => $v ) {
			$p['Headers'][] = array( 'Name' => $n, 'Value' => $v );
		}
	}
	if ( $m['attachments'] ) {
		$p['Attachments'] = array_map( function ( $a ) {
			return array_filter( array( 'Name' => $a['name'], 'Content' => $a['content'], 'ContentType' => $a['type'], 'ContentID' => $a['cid'] ? 'cid:' . $a['cid'] : '' ) );
		}, $m['attachments'] );
	}
	$r = rzd_mail_json_post( 'https://api.postmarkapp.com/email', array( 'X-Postmark-Server-Token' => $key ), $p );
	if ( is_wp_error( $r ) ) {
		return $r;
	}
	return ( 200 === $r['code'] && isset( $r['json']['ErrorCode'] ) && 0 === (int) $r['json']['ErrorCode'] ) ? true : rzd_mail_http_error( 'Postmark', $r, isset( $r['json']['Message'] ) ? $r['json']['Message'] : $r['body'] );
}

// SparkPost – POST /api/v1/transmissions z gotowym MIME (content.email_rfc822), nagłówek Authorization: klucz.
function rzd_mail_send_sparkpost( $m, $key, $region ) {
	$host = 'eu' === $region ? 'https://api.eu.sparkpost.com' : 'https://api.sparkpost.com';
	$hdr  = implode( ',', rzd_mail_emails( $m['to'] ) );
	$rcpt = array();
	foreach ( array_merge( rzd_mail_emails( $m['to'] ), rzd_mail_emails( $m['cc'] ), rzd_mail_emails( $m['bcc'] ) ) as $e ) {
		$rcpt[] = array( 'address' => array( 'email' => $e, 'header_to' => $hdr ) );
	}
	$r = rzd_mail_json_post( $host . '/api/v1/transmissions', array( 'Authorization' => $key ), array( 'recipients' => $rcpt, 'content' => array( 'email_rfc822' => $m['raw'] ) ) );
	if ( is_wp_error( $r ) ) {
		return $r;
	}
	if ( 200 === $r['code'] && ! empty( $r['json']['results']['total_accepted_recipients'] ) ) {
		return true;
	}
	$e = isset( $r['json']['errors'] ) ? implode( '; ', array_map( function ( $x ) {
		return trim( ( isset( $x['message'] ) ? $x['message'] : '' ) . ' ' . ( isset( $x['description'] ) ? $x['description'] : '' ) );
	}, (array) $r['json']['errors'] ) ) : $r['body'];
	return rzd_mail_http_error( 'SparkPost', $r, $e );
}

// SMTP2GO – POST /v3/email/send, X-Smtp2go-Api-Key; 200 nawet przy błędach – liczy się data.succeeded / data.failures.
function rzd_mail_send_smtp2go( $m, $key ) {
	$p = array( 'sender' => rzd_mail_addr_str( $m['from'] ), 'to' => array_map( 'rzd_mail_addr_str', $m['to'] ), 'subject' => $m['subject'] );
	if ( $m['cc'] ) {
		$p['cc'] = array_map( 'rzd_mail_addr_str', $m['cc'] );
	}
	if ( $m['bcc'] ) {
		$p['bcc'] = array_map( 'rzd_mail_addr_str', $m['bcc'] );
	}
	if ( '' !== $m['html'] ) {
		$p['html_body'] = $m['html'];
	}
	if ( '' !== $m['text'] ) {
		$p['text_body'] = $m['text'];
	}
	$custom = array();
	if ( $m['reply_to'] ) {
		$custom[] = array( 'header' => 'Reply-To', 'value' => implode( ', ', array_map( 'rzd_mail_addr_str', $m['reply_to'] ) ) );
	}
	foreach ( $m['headers'] as $n => $v ) {
		$custom[] = array( 'header' => $n, 'value' => $v );
	}
	if ( $custom ) {
		$p['custom_headers'] = $custom;
	}
	if ( $m['attachments'] ) {
		$p['attachments'] = array_map( function ( $a ) {
			return array( 'filename' => $a['name'], 'fileblob' => $a['content'], 'mimetype' => $a['type'] );
		}, $m['attachments'] );
	}
	$r = rzd_mail_json_post( 'https://api.smtp2go.com/v3/email/send', array( 'X-Smtp2go-Api-Key' => $key ), $p );
	if ( is_wp_error( $r ) ) {
		return $r;
	}
	$d = isset( $r['json']['data'] ) && is_array( $r['json']['data'] ) ? $r['json']['data'] : (array) $r['json'];
	if ( 200 === $r['code'] && ! empty( $d['succeeded'] ) && empty( $d['failed'] ) ) {
		return true;
	}
	$e = ! empty( $d['failures'] ) ? implode( '; ', array_map( function ( $x ) {
		return is_scalar( $x ) ? (string) $x : wp_json_encode( $x );
	}, (array) $d['failures'] ) ) : ( isset( $d['error'] ) ? $d['error'] : $r['body'] );
	return rzd_mail_http_error( 'SMTP2GO', $r, $e );
}

// Mailjet – POST /v3.1/send, Basic klucz:sekret, 200 {Messages:[{Status:'success'}]}.
function rzd_mail_send_mailjet( $m, $key, $secret ) {
	$map = function ( $l ) {
		return array_map( function ( $a ) {
			return array_filter( array( 'Email' => $a['email'], 'Name' => $a['name'] ) );
		}, (array) $l );
	};
	$msg = array( 'From' => array_filter( array( 'Email' => $m['from']['email'], 'Name' => $m['from']['name'] ) ), 'To' => $map( $m['to'] ), 'Subject' => $m['subject'] );
	if ( $m['cc'] ) {
		$msg['Cc'] = $map( $m['cc'] );
	}
	if ( $m['bcc'] ) {
		$msg['Bcc'] = $map( $m['bcc'] );
	}
	if ( $m['reply_to'] ) {
		$msg['ReplyTo'] = array_filter( array( 'Email' => $m['reply_to'][0]['email'], 'Name' => $m['reply_to'][0]['name'] ) );
	}
	if ( '' !== $m['html'] ) {
		$msg['HTMLPart'] = $m['html'];
	}
	if ( '' !== $m['text'] ) {
		$msg['TextPart'] = $m['text'];
	}
	if ( $m['headers'] ) {
		$msg['Headers'] = $m['headers'];
	}
	if ( $m['attachments'] ) {
		$msg['Attachments'] = array_map( function ( $a ) {
			return array( 'ContentType' => $a['type'], 'Filename' => $a['name'], 'Base64Content' => $a['content'] );
		}, $m['attachments'] );
	}
	$r = rzd_mail_json_post( 'https://api.mailjet.com/v3.1/send', array( 'Authorization' => 'Basic ' . base64_encode( $key . ':' . $secret ) ), array( 'Messages' => array( $msg ) ) ); // phpcs:ignore
	if ( is_wp_error( $r ) ) {
		return $r;
	}
	$st = isset( $r['json']['Messages'][0]['Status'] ) ? $r['json']['Messages'][0]['Status'] : '';
	if ( 200 === $r['code'] && 'success' === $st ) {
		return true;
	}
	$e = '';
	if ( isset( $r['json']['Messages'][0]['Errors'] ) ) {
		$e = implode( '; ', wp_list_pluck( (array) $r['json']['Messages'][0]['Errors'], 'ErrorMessage' ) );
	} elseif ( isset( $r['json']['ErrorMessage'] ) ) {
		$e = $r['json']['ErrorMessage'];
	}
	return rzd_mail_http_error( 'Mailjet', $r, $e ? $e : $r['body'] );
}

// Elastic Email – POST /v4/emails/transactional, X-ElasticEmail-ApiKey.
function rzd_mail_send_elastic( $m, $key ) {
	$body = array();
	if ( '' !== $m['html'] ) {
		$body[] = array( 'ContentType' => 'HTML', 'Charset' => 'utf-8', 'Content' => $m['html'] );
	}
	if ( '' !== $m['text'] ) {
		$body[] = array( 'ContentType' => 'PlainText', 'Charset' => 'utf-8', 'Content' => $m['text'] );
	}
	$content = array( 'Body' => $body, 'From' => rzd_mail_addr_str( $m['from'] ), 'Subject' => $m['subject'] );
	if ( $m['reply_to'] ) {
		$content['ReplyTo'] = rzd_mail_addr_str( $m['reply_to'][0] );
	}
	if ( $m['headers'] ) {
		$content['Headers'] = $m['headers'];
	}
	if ( $m['attachments'] ) {
		$content['Attachments'] = array_map( function ( $a ) {
			return array( 'BinaryContent' => $a['content'], 'Name' => $a['name'], 'ContentType' => $a['type'] );
		}, $m['attachments'] );
	}
	$rcpt = array( 'To' => array_map( 'rzd_mail_addr_str', $m['to'] ) );
	if ( $m['cc'] ) {
		$rcpt['CC'] = array_map( 'rzd_mail_addr_str', $m['cc'] );
	}
	if ( $m['bcc'] ) {
		$rcpt['BCC'] = array_map( 'rzd_mail_addr_str', $m['bcc'] );
	}
	$r = rzd_mail_json_post( 'https://api.elasticemail.com/v4/emails/transactional', array( 'X-ElasticEmail-ApiKey' => $key ), array( 'Recipients' => $rcpt, 'Content' => $content ) );
	if ( is_wp_error( $r ) ) {
		return $r;
	}
	return ( $r['code'] >= 200 && $r['code'] < 300 ) ? true : rzd_mail_http_error( 'Elastic Email', $r, isset( $r['json']['Error'] ) ? $r['json']['Error'] : $r['body'] );
}

// MailerSend – POST /v1/email, Bearer, 202; błąd 422 {message, errors{pole:[…]}}.
function rzd_mail_send_mailersend( $m, $key ) {
	$map = function ( $l ) {
		return array_map( function ( $a ) {
			return array_filter( array( 'email' => $a['email'], 'name' => $a['name'] ) );
		}, (array) $l );
	};
	$p = array( 'from' => array_filter( array( 'email' => $m['from']['email'], 'name' => $m['from']['name'] ) ), 'to' => $map( $m['to'] ), 'subject' => $m['subject'] );
	if ( $m['cc'] ) {
		$p['cc'] = $map( $m['cc'] );
	}
	if ( $m['bcc'] ) {
		$p['bcc'] = $map( $m['bcc'] );
	}
	if ( $m['reply_to'] ) {
		$p['reply_to'] = array_filter( array( 'email' => $m['reply_to'][0]['email'], 'name' => $m['reply_to'][0]['name'] ) );
	}
	if ( '' !== $m['html'] ) {
		$p['html'] = $m['html'];
	}
	if ( '' !== $m['text'] ) {
		$p['text'] = $m['text'];
	}
	if ( $m['attachments'] ) {
		$p['attachments'] = array_map( function ( $a ) {
			return array_filter( array( 'content' => $a['content'], 'filename' => $a['name'], 'disposition' => $a['cid'] ? 'inline' : 'attachment', 'id' => $a['cid'] ) );
		}, $m['attachments'] );
	}
	$r = rzd_mail_json_post( 'https://api.mailersend.com/v1/email', array( 'Authorization' => 'Bearer ' . $key ), $p );
	if ( is_wp_error( $r ) ) {
		return $r;
	}
	if ( $r['code'] >= 200 && $r['code'] < 300 ) {
		return true;
	}
	$e = isset( $r['json']['message'] ) ? $r['json']['message'] : $r['body'];
	if ( ! empty( $r['json']['errors'] ) && is_array( $r['json']['errors'] ) ) {
		$e .= ' ' . implode( ' ', array_map( function ( $x ) {
			return implode( ' ', (array) $x );
		}, $r['json']['errors'] ) );
	}
	return rzd_mail_http_error( 'MailerSend', $r, $e );
}

// Resend – POST /emails, Bearer, 200 {id}.
function rzd_mail_send_resend( $m, $key ) {
	$p = array( 'from' => rzd_mail_addr_str( $m['from'] ), 'to' => array_map( 'rzd_mail_addr_str', $m['to'] ), 'subject' => $m['subject'] );
	if ( $m['cc'] ) {
		$p['cc'] = array_map( 'rzd_mail_addr_str', $m['cc'] );
	}
	if ( $m['bcc'] ) {
		$p['bcc'] = array_map( 'rzd_mail_addr_str', $m['bcc'] );
	}
	if ( $m['reply_to'] ) {
		$p['reply_to'] = array_map( 'rzd_mail_addr_str', $m['reply_to'] );
	}
	if ( '' !== $m['html'] ) {
		$p['html'] = $m['html'];
	}
	if ( '' !== $m['text'] ) {
		$p['text'] = $m['text'];
	}
	if ( $m['headers'] ) {
		$p['headers'] = $m['headers'];
	}
	if ( $m['attachments'] ) {
		$p['attachments'] = array_map( function ( $a ) {
			return array_filter( array( 'filename' => $a['name'], 'content' => $a['content'], 'content_type' => $a['type'], 'content_id' => $a['cid'] ) );
		}, $m['attachments'] );
	}
	$r = rzd_mail_json_post( 'https://api.resend.com/emails', array( 'Authorization' => 'Bearer ' . $key ), $p );
	if ( is_wp_error( $r ) ) {
		return $r;
	}
	return ( $r['code'] >= 200 && $r['code'] < 300 && ! empty( $r['json']['id'] ) ) ? true : rzd_mail_http_error( 'Resend', $r, isset( $r['json']['message'] ) ? $r['json']['message'] : $r['body'] );
}

// Mandrill – POST /api/1.4/messages/send-raw z gotowym MIME; odpowiedź: lista {email,status,reject_reason}.
function rzd_mail_send_mandrill( $m, $key ) {
	$p = array( 'key' => $key, 'raw_message' => $m['raw'], 'from_email' => $m['from']['email'], 'from_name' => $m['from']['name'], 'to' => array_merge( rzd_mail_emails( $m['to'] ), rzd_mail_emails( $m['cc'] ), rzd_mail_emails( $m['bcc'] ) ) );
	$r = rzd_mail_json_post( 'https://mandrillapp.com/api/1.4/messages/send-raw', array(), $p );
	if ( is_wp_error( $r ) ) {
		return $r;
	}
	if ( 200 === $r['code'] && is_array( $r['json'] ) && isset( $r['json'][0] ) ) {
		$bad = array();
		foreach ( $r['json'] as $x ) {
			if ( ! in_array( isset( $x['status'] ) ? $x['status'] : '', array( 'sent', 'queued', 'scheduled' ), true ) ) {
				$bad[] = ( isset( $x['email'] ) ? $x['email'] : '?' ) . ': ' . ( isset( $x['status'] ) ? $x['status'] : '?' ) . ( ! empty( $x['reject_reason'] ) ? ' (' . $x['reject_reason'] . ')' : '' );
			}
		}
		return $bad ? rzd_mail_http_error( 'Mandrill', $r, implode( '; ', $bad ) ) : true;
	}
	return rzd_mail_http_error( 'Mandrill', $r, isset( $r['json']['message'] ) ? $r['json']['message'] : $r['body'] );
}

/**
 * Podpis AWS Signature Version 4 (nagłówek Authorization). $headers: nazwa(małe litery) => wartość, muszą zawierać host i x-amz-date.
 * Sprawdzony na przykładzie z dokumentacji AWS (test w tests/nz).
 */
function rzd_mail_sigv4( $method, $path, $query, $headers, $payload, $key, $secret, $region, $service ) {
	ksort( $headers );
	$canon_h = '';
	foreach ( $headers as $n => $v ) {
		$canon_h .= strtolower( $n ) . ':' . trim( preg_replace( '/\s+/', ' ', (string) $v ) ) . "\n";
	}
	$signed  = implode( ';', array_map( 'strtolower', array_keys( $headers ) ) );
	$amzdate = $headers['x-amz-date'];
	$date    = substr( $amzdate, 0, 8 );
	$creq    = $method . "\n" . $path . "\n" . $query . "\n" . $canon_h . "\n" . $signed . "\n" . hash( 'sha256', $payload );
	$scope   = $date . '/' . $region . '/' . $service . '/aws4_request';
	$sts     = "AWS4-HMAC-SHA256\n" . $amzdate . "\n" . $scope . "\n" . hash( 'sha256', $creq );
	$k       = hash_hmac( 'sha256', 'aws4_request', hash_hmac( 'sha256', $service, hash_hmac( 'sha256', $region, hash_hmac( 'sha256', $date, 'AWS4' . $secret, true ), true ), true ), true );
	return 'AWS4-HMAC-SHA256 Credential=' . $key . '/' . $scope . ', SignedHeaders=' . $signed . ', Signature=' . hash_hmac( 'sha256', $sts, $k );
}

// Amazon SES (API v2) – POST /v2/email/outbound-emails z gotowym MIME (Content.Raw.Data, base64), podpis SigV4 (usługa „ses”).
function rzd_mail_send_ses( $m, $key, $secret, $region ) {
	$region  = preg_replace( '/[^a-z0-9-]/', '', (string) $region );
	$region  = '' !== $region ? $region : 'eu-central-1';
	$host    = 'email.' . $region . '.amazonaws.com';
	$path    = '/v2/email/outbound-emails';
	$payload = wp_json_encode( array(
		'Content'     => array( 'Raw' => array( 'Data' => base64_encode( $m['raw'] ) ) ), // phpcs:ignore
		'Destination' => array_filter( array( 'ToAddresses' => rzd_mail_emails( $m['to'] ), 'CcAddresses' => rzd_mail_emails( $m['cc'] ), 'BccAddresses' => rzd_mail_emails( $m['bcc'] ) ) ),
	) );
	$amzdate = gmdate( 'Ymd\THis\Z' );
	$h       = array( 'content-type' => 'application/json', 'host' => $host, 'x-amz-date' => $amzdate );
	$auth    = rzd_mail_sigv4( 'POST', $path, '', $h, $payload, $key, $secret, $region, 'ses' );
	$r       = rzd_mail_http( 'https://' . $host . $path, array( 'headers' => array( 'Content-Type' => 'application/json', 'X-Amz-Date' => $amzdate, 'Authorization' => $auth ), 'body' => $payload ) );
	if ( is_wp_error( $r ) ) {
		return $r;
	}
	return ( 200 === $r['code'] && ! empty( $r['json']['MessageId'] ) ) ? true : rzd_mail_http_error( 'Amazon SES', $r, isset( $r['json']['message'] ) ? $r['json']['message'] : ( isset( $r['json']['Message'] ) ? $r['json']['Message'] : $r['body'] ) );
}

// Wysyłka przez API wybranego połączenia.
function rzd_mail_api_send( $conn, $which, $m ) {
	$k = rzd_mail_secret( $conn, 'key', $which );
	$s = rzd_mail_secret( $conn, 'secret', $which );
	switch ( $conn['type'] ) {
		case 'brevo':
			return rzd_mail_send_brevo( $m, $k );
		case 'sendgrid':
			return rzd_mail_send_sendgrid( $m, $k, $conn['region'] );
		case 'mailgun':
			return rzd_mail_send_mailgun( $m, $k, $conn['domain'], $conn['region'] );
		case 'postmark':
			return rzd_mail_send_postmark( $m, $k );
		case 'sparkpost':
			return rzd_mail_send_sparkpost( $m, $k, $conn['region'] );
		case 'smtp2go':
			return rzd_mail_send_smtp2go( $m, $k );
		case 'mailjet':
			return rzd_mail_send_mailjet( $m, $k, $s );
		case 'elastic':
			return rzd_mail_send_elastic( $m, $k );
		case 'mailersend':
			return rzd_mail_send_mailersend( $m, $k );
		case 'resend':
			return rzd_mail_send_resend( $m, $k );
		case 'mandrill':
			return rzd_mail_send_mandrill( $m, $k );
		case 'ses':
			return rzd_mail_send_ses( $m, $k, $s, $conn['region'] );
	}
	return new WP_Error( 'rzd_mail', 'Nieznany sposób wysyłki: ' . $conn['type'] );
}
