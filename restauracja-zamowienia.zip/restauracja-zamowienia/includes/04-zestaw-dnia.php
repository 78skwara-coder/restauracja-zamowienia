<?php
/**
 * Snippet: "Zestaw dnia" — wersja z TERMINAMI
 * (pomiń pierwszą linię "<?php" wklejając do Code Snippets, "Run everywhere")
 *
 * Jeden stały produkt (ten sam link/SKU), którego tytuł, zdjęcie i opis
 * podmieniają się wg harmonogramu, plus opcjonalne "dodatki" (np. zupa).
 *
 * CO SIĘ ZMIENIŁO wobec poprzedniej wersji:
 * - "+ Dodaj pozycję" dodaje teraz TERMIN: dni tygodnia i/lub konkretną datę
 *   oraz zakres godzin (od–do).
 * - W każdym terminie własnym plusem "+ Dodaj produkt" dodajesz kolejne
 *   produkty; każdy jest "daniem głównym" albo "dodatkiem opcjonalnym".
 * - Reszta mechaniki bez zmian (podmiana tytułu/zdjęcia/opisu, dodatki
 *   z osobnym przyciskiem, lista składników w koszyku i zamówieniu,
 *   ukrywanie składników w katalogu, blokada zakupu dań głównych,
 *   znikanie pustego zestawu).
 * - Stare dane (pojedyncze pozycje z poprzedniej wersji) są odczytywane
 *   automatycznie jako terminy i zapiszą się w nowym formacie przy pierwszym
 *   zapisie produktu.
 *
 * Godziny: puste "od" i "do" = cały dzień; samo "od" = od tej godziny do
 * końca dnia; samo "do" = od początku dnia do tej godziny. Zakres dotyczy
 * jednego dnia (nie przechodzi przez północ).
 *
 * Prefiks funkcji rwz_ – nie koliduje z innymi snippetami.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// 0) Załaduj select2 do wyszukiwania produktów na ekranie edycji produktu
add_action( 'admin_enqueue_scripts', 'rwz_enqueue_admin_assets' );
function rwz_enqueue_admin_assets( $hook ) {
	global $post_type;
	if ( 'product' === $post_type && in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
		wp_enqueue_script( 'wc-enhanced-select' );
		wp_enqueue_style( 'woocommerce_admin_styles' );
		add_action( 'admin_print_styles', 'rzd_admin_tabs_layout_fix' );
	}
}

/**
 * NAPRAWA UKŁADU trzech naszych zakładek w edycji produktu: "Zestaw dnia",
 * i "Możliwe modyfikacje" (moduł 10 – tam też teraz mieszkają dodatki,
 * patrz typ modyfikacji "radio" z ikonką).
 *
 * Przyczyna problemu z poprzedniej wiadomości ("rozjeżdżający się" formularz,
 * pola nachodzące na siebie): pola i etykiety mają sztywną szerokość podaną
 * w pikselach (np. width:300px), ale BEZ box-sizing:border-box. Domyślnie
 * przeglądarka dolicza do tej szerokości jeszcze obramowanie i wypełnienie,
 * więc realna szerokość pola jest WIĘKSZA, niż zakładaliśmy. W węższym oknie
 * admina (bo po lewej jest jeszcze kolumna zakładek Ogólne/Magazyn/Wysyłka…)
 * sumaryczna szerokość kilku takich pól obok siebie zaczyna przekraczać
 * dostępne miejsce – stąd nachodzenie na siebie.
 *
 * Naprawa: wymuszamy border-box na wszystkich naszych polach we wszystkich
 * trzech zakładkach, ograniczamy im maksymalną szerokość do 100% dostępnego
 * miejsca (żeby się zwężały zamiast wychodzić poza kontener) i porządkujemy
 * odstępy, żeby kolejne pola nie stykały się ze sobą.
 */
function rzd_admin_tabs_layout_fix() {
	?>
	<style>
		#rwz_zestaw_data, #rzd_mods_data { overflow: hidden; }
		#rwz_zestaw_data *, #rzd_mods_data * { box-sizing: border-box; }

		#rwz_zestaw_data input[type=text], #rwz_zestaw_data input[type=number],
		#rwz_zestaw_data input[type=date], #rwz_zestaw_data input[type=time], #rwz_zestaw_data select,
		#rzd_mods_data input[type=text], #rzd_mods_data select {
			max-width: 100%;
		}
		#rzd_mods_data input[type=number] { width: 90px; min-width: 70px; max-width: 100%; }

		.rwz-slot, .rwz-item, .rzd-section, .rzd-group, .rzd-opt {
			max-width: 100%;
		}

		/* Każde pole w "Możliwe modyfikacje" (cena, ilość, ikona) ma WŁASNY,
		   jednoznaczny wiersz – etykieta zawsze nad polem, każdy wiersz
		   oddzielony odstępem. To eliminuje przyczynę nachodzenia na siebie:
		   długa etykieta i pole obok niej w tej samej linii tekstu. */
		#rzd_mods_data .rzd-field { margin: 0 0 12px; }
		#rzd_mods_data .rzd-field label { display: block; margin-bottom: 4px; }
		/* 2.26.17: WooCommerce dla etykiet w panelu produktu ustawia float + margin-left: -150px
		   (etykieta „wysunięta” w lewo) – u nas ucinało to początek etykiet grupy. */
		#woocommerce-product-data #rzd_mods_data .rzd-field label, #rzd_mods_data .rzd-field label { float: none; width: auto; margin: 0 0 4px; padding: 0; }
		#woocommerce-product-data #rzd_mods_data .rzd-field-inline label, #rzd_mods_data .rzd-field-inline label { display: inline-block; margin: 0 6px 0 0; }

		/* Wyjątek: wiersz "Ilość: od [pole] do [pole]" ma zostać w jednej
		   linii (do póki starczy miejsca), więc jego etykiety są liniowe. */
		#rzd_mods_data .rzd-field-inline label { display: inline-block; margin: 0 6px 0 0; }
		#rzd_mods_data .rzd-field-inline input[type=number] { margin-right: 14px; }

		#rzd_mods_data .rzd-icon-row { display: inline-flex; align-items: center; gap: 8px; flex-wrap: wrap; margin-top: 2px; }
		#rzd_mods_data .rzd-icon-preview { display: inline-block; line-height: 0; }
		#rzd_mods_data .rzd-icon-preview img { display: block; }
	</style>
	<?php
}

// 1) Nowa zakładka "Zestaw dnia" w danych produktu
add_filter( 'woocommerce_product_data_tabs', 'rwz_add_zestaw_tab' );
function rwz_add_zestaw_tab( $tabs ) {
	$tabs['rwz_zestaw'] = array(
		'label'    => __( 'Zestaw dnia', 'woocommerce' ),
		'target'   => 'rwz_zestaw_data',
		'class'    => array(),
		'priority' => 21,
	);
	return $tabs;
}

// Lista dni używana i w renderze terminów
function rwz_days_labels() {
	return array(
		'Mon' => 'Pon',
		'Tue' => 'Wt',
		'Wed' => 'Śr',
		'Thu' => 'Czw',
		'Fri' => 'Pt',
		'Sat' => 'Sob',
		'Sun' => 'Ndz',
	);
}

// Poprawna godzina "HH:MM" albo pusty ciąg
function rwz_clean_time( $t ) {
	$t = sanitize_text_field( (string) $t );
	return preg_match( '/^([01]\d|2[0-3]):[0-5]\d$/', $t ) ? $t : '';
}

// Terminy zestawu. Jeśli produkt ma jeszcze STARE dane (_rwz_components
// z poprzedniej wersji), zamieniamy je w locie na terminy.
function rwz_get_slots( $product_id ) {
	$slots = get_post_meta( $product_id, '_rwz_slots', true );
	if ( is_array( $slots ) ) {
		return $slots;
	}

	$slots  = array();
	$legacy = get_post_meta( $product_id, '_rwz_components', true );
	if ( is_array( $legacy ) ) {
		foreach ( $legacy as $row ) {
			if ( empty( $row['product_id'] ) ) {
				continue;
			}
			$slots[] = array(
				'days'  => ( isset( $row['days'] ) && is_array( $row['days'] ) ) ? $row['days'] : array(),
				'date'  => isset( $row['date'] ) ? $row['date'] : '',
				'from'  => '',
				'to'    => '',
				'items' => array(
					array(
						'product_id' => absint( $row['product_id'] ),
						'type'       => ( isset( $row['type'] ) && 'addon' === $row['type'] ) ? 'addon' : 'main',
					),
				),
			);
		}
	}
	return $slots;
}

// Funkcja pomocnicza: czy dzień/data pasuje do DZISIAJ
function rwz_matches_today( $days, $date ) {
	$current_day  = current_time( 'D' );
	$current_date = current_time( 'Y-m-d' );

	if ( ! empty( $date ) ) {
		return $current_date === $date;
	}
	if ( empty( $days ) ) {
		return true;
	}
	return in_array( $current_day, (array) $days, true );
}

// Zakres dat terminu (od 2.22.0): "Od dnia" / "Do dnia", oba włącznie, każde
// może być puste (= bez ograniczenia z tej strony). Działa RAZEM z dniami
// tygodnia; "konkretna data" jest nadrzędna i wtedy zakres się pomija.
function rwz_in_date_range( $slot, $date ) {
	$df = isset( $slot['date_from'] ) ? (string) $slot['date_from'] : '';
	$dt = isset( $slot['date_to'] ) ? (string) $slot['date_to'] : '';
	if ( '' !== $df && $date < $df ) {
		return false;
	}
	if ( '' !== $dt && $date > $dt ) {
		return false;
	}
	return true;
}

// Funkcja pomocnicza: czy termin jest aktywny TERAZ (dzień/data + zakres + godziny)
function rwz_slot_matches_now( $slot ) {
	$days = ( isset( $slot['days'] ) && is_array( $slot['days'] ) ) ? $slot['days'] : array();
	$date = isset( $slot['date'] ) ? $slot['date'] : '';
	$from = isset( $slot['from'] ) ? $slot['from'] : '';
	$to   = isset( $slot['to'] ) ? $slot['to'] : '';

	if ( ! rwz_matches_today( $days, $date ) ) {
		return false;
	}
	if ( '' === $date && ! rwz_in_date_range( $slot, current_time( 'Y-m-d' ) ) ) {
		return false;
	}

	$now = current_time( 'H:i' );
	if ( $from && $now < $from ) {
		return false;
	}
	if ( $to && $now > $to ) {
		return false;
	}
	return true;
}

// Renderuje jeden wiersz produktu wewnątrz terminu
// (dla szablonu JS: $slot_index = '__SLOT__', $item_index = '__ITEM__', $item = array())
function rwz_render_item_row( $slot_index, $item_index, $item ) {
	$product_id = isset( $item['product_id'] ) ? absint( $item['product_id'] ) : 0;
	$type       = ( isset( $item['type'] ) && 'addon' === $item['type'] ) ? 'addon' : 'main';
	$name       = 'rwz_slot[' . $slot_index . '][items][' . $item_index . ']';

	ob_start();
	?>
	<div class="rwz-item" style="border:1px solid #ddd; margin:8px 0; padding:10px 34px 10px 10px; background:#fff; position:relative;">
		<a href="#" class="rwz-remove-item" style="position:absolute; top:6px; right:10px; color:#d63638; text-decoration:none; font-size:18px; font-weight:bold;" title="<?php esc_attr_e( 'Usuń produkt', 'woocommerce' ); ?>">&times;</a>

		<select name="<?php echo esc_attr( $name ); ?>[product_id]" class="wc-product-search" style="width:300px;" data-action="woocommerce_json_search_products_and_variations" data-placeholder="<?php esc_attr_e( 'Wybierz produkt…', 'woocommerce' ); ?>">
			<?php
			if ( $product_id ) {
				$p = wc_get_product( $product_id );
				if ( $p ) {
					echo '<option value="' . esc_attr( $product_id ) . '" selected="selected">' . esc_html( $p->get_formatted_name() ) . '</option>';
				}
			}
			?>
		</select>
		&nbsp;
		<select name="<?php echo esc_attr( $name ); ?>[type]">
			<option value="main" <?php selected( $type, 'main' ); ?>><?php esc_html_e( 'Danie główne (podmienia tytuł / zdjęcie / opis)', 'woocommerce' ); ?></option>
			<option value="addon" <?php selected( $type, 'addon' ); ?>><?php esc_html_e( 'Dodatek opcjonalny (osobny przycisk „Dodaj do koszyka”)', 'woocommerce' ); ?></option>
		</select>
		&nbsp;
		<label style="white-space:nowrap;" title="Zdjęcie tego dania będzie zdjęciem zestawu na liście (tam jest tylko jedno zdjęcie).">
			<input type="checkbox" name="<?php echo esc_attr( $name ); ?>[photo]" value="1" <?php checked( ! empty( $item['photo'] ) ); ?>> Zdjęcie
		</label>
	</div>
	<?php
	return ob_get_clean();
}

// Renderuje jeden TERMIN (dla szablonu JS: $index = '__SLOT__', $slot = array())
function rwz_render_slot( $index, $slot ) {
	$days_labels = rwz_days_labels();

	$row_days = ( isset( $slot['days'] ) && is_array( $slot['days'] ) ) ? $slot['days'] : array();
	$row_date = isset( $slot['date'] ) ? $slot['date'] : '';
	$row_df   = isset( $slot['date_from'] ) ? $slot['date_from'] : '';
	$row_dt   = isset( $slot['date_to'] ) ? $slot['date_to'] : '';
	$row_from = isset( $slot['from'] ) ? $slot['from'] : '';
	$row_to   = isset( $slot['to'] ) ? $slot['to'] : '';
	$items    = ( isset( $slot['items'] ) && is_array( $slot['items'] ) ) ? array_values( $slot['items'] ) : array();
	$name     = 'rwz_slot[' . $index . ']';

	ob_start();
	?>
	<div class="rwz-slot" data-slot="<?php echo esc_attr( $index ); ?>" data-next-item="<?php echo (int) count( $items ); ?>" style="border:2px solid #b5bfc9; margin:14px 12px; padding:12px; background:#f6f7f7; position:relative;">
		<a href="#" class="rwz-remove-slot" style="position:absolute; top:8px; right:10px; color:#d63638; text-decoration:none; font-size:20px; font-weight:bold;" title="<?php esc_attr_e( 'Usuń cały termin', 'woocommerce' ); ?>">&times;</a>

		<strong><?php esc_html_e( 'Termin', 'woocommerce' ); ?></strong><br><br>

		<label><?php esc_html_e( 'Dni tygodnia:', 'woocommerce' ); ?></label><br>
		<?php foreach ( $days_labels as $key => $label ) : ?>
			<label style="margin-right:10px;"><input type="checkbox" name="<?php echo esc_attr( $name ); ?>[days][]" value="<?php echo esc_attr( $key ); ?>" <?php checked( in_array( $key, $row_days, true ) ); ?> /> <?php echo esc_html( $label ); ?></label>
		<?php endforeach; ?>
		<br><small style="color:#777;"><?php esc_html_e( 'Brak zaznaczonych dni = codziennie (chyba że ustawisz konkretną datę).', 'woocommerce' ); ?></small><br><br>

		<label><?php esc_html_e( 'Zakres dat: od', 'woocommerce' ); ?></label>
		<input type="date" name="<?php echo esc_attr( $name ); ?>[date_from]" value="<?php echo esc_attr( $row_df ); ?>" />
		<label><?php esc_html_e( 'do', 'woocommerce' ); ?></label>
		<input type="date" name="<?php echo esc_attr( $name ); ?>[date_to]" value="<?php echo esc_attr( $row_dt ); ?>" /><br>
		<small style="color:#777;"><?php esc_html_e( 'Oba dni włącznie. Działa razem z dniami tygodnia (np. piątki od 1.10 do 31.10). Puste = bez ograniczenia.', 'woocommerce' ); ?></small><br><br>

		<label><?php esc_html_e( 'Lub konkretna data (nadrzędna wobec dni powyżej):', 'woocommerce' ); ?></label><br>
		<input type="date" name="<?php echo esc_attr( $name ); ?>[date]" value="<?php echo esc_attr( $row_date ); ?>" /><br><br>

		<label><?php esc_html_e( 'Godziny: od', 'woocommerce' ); ?></label>
		<input type="time" name="<?php echo esc_attr( $name ); ?>[from]" value="<?php echo esc_attr( $row_from ); ?>" />
		<label><?php esc_html_e( 'do', 'woocommerce' ); ?></label>
		<input type="time" name="<?php echo esc_attr( $name ); ?>[to]" value="<?php echo esc_attr( $row_to ); ?>" /><br>
		<small style="color:#777;"><?php esc_html_e( 'Puste = cały dzień. Zakres dotyczy jednego dnia (np. 11:00–15:00).', 'woocommerce' ); ?></small>

		<div class="rwz-items" style="margin-top:12px;">
			<?php
			foreach ( $items as $j => $item ) {
				echo rwz_render_item_row( $index, $j, $item );
			}
			?>
		</div>
		<p style="margin:8px 0 0;"><button type="button" class="button rwz-add-item">+ <?php esc_html_e( 'Dodaj produkt', 'woocommerce' ); ?></button></p>

		<?php if ( ! empty( $items ) ) : ?>
			<?php $is_active = rwz_slot_matches_now( $slot ); ?>
			<p style="margin-top:10px; padding:6px 10px; background:#f0f6fc; border-left:3px solid #72aee6;"><em>
				<?php
				echo esc_html( sprintf( __( 'Aktywny teraz (%s)? ', 'woocommerce' ), wp_date( 'l Y-m-d H:i' ) ) );
				echo $is_active
					? '<strong style="color:#008a20;">' . esc_html__( 'TAK', 'woocommerce' ) . '</strong>'
					: '<strong style="color:#d63638;">' . esc_html__( 'NIE', 'woocommerce' ) . '</strong>';
				?>
			</em></p>
		<?php endif; ?>
	</div>
	<?php
	return ob_get_clean();
}

// 2) Renderuj zawartość zakładki: istniejące terminy + przycisk "+ Dodaj pozycję"
add_action( 'woocommerce_product_data_panels', 'rwz_render_zestaw_panel' );
function rwz_render_zestaw_panel() {
	global $post;

	$slots = array_values( rwz_get_slots( $post->ID ) );

	// WooCommerce w panelach produktu przesuwa każdy <label> 150 px w lewo (float + ujemny
	// margines, pod kolumnę etykiet p.form-field). Nasze terminy nie używają p.form-field,
	// więc etykiety – a z nimi checkboxy dni tygodnia – lądowały poza ekranem. Reset tylko tu.
	echo '<style>#woocommerce-product-data #rwz_zestaw_data .rwz-slot label{float:none;width:auto;margin-left:0;padding:0;display:inline;}</style>';
	echo '<div id="rwz_zestaw_data" class="panel woocommerce_options_panel">';
	echo '<p style="padding:0 12px; color:#555;">' . esc_html__( 'Dodaj pozycję = termin (dni/data + godziny). W terminie dodajesz produkty: "Danie główne" podmienia tytuł, zdjęcie i opis TEGO produktu w czasie trwania terminu, "Dodatek opcjonalny" pokazuje się jako osobna pozycja z przyciskiem zakupu. Podpięte produkty automatycznie znikają z katalogu/wyszukiwarki sklepu. Najnowsze terminy są na górze.', 'woocommerce' ) . '</p>';
	echo '<p style="padding:0 12px;"><button type="button" class="button button-primary" id="rwz-add-slot">+ ' . esc_html__( 'Dodaj pozycję', 'woocommerce' ) . '</button></p>';

	// 2.26.1: kolejka – najnowszy termin na górze. Indeksy pól zostają te same,
	// a zapis (rwz_save_zestaw_fields) odwraca kolejność z powrotem, więc w bazie
	// nadal najstarszy jest pierwszy i rwz_get_active_components() działa jak dawniej.
	echo '<div id="rwz-slots">';
	foreach ( array_reverse( $slots, true ) as $i => $slot ) {
		echo rwz_render_slot( $i, $slot );
	}
	echo '</div>';

	// Szablony (przeglądarka ich nie renderuje — type="text/html")
	echo '<script type="text/html" id="rwz-slot-template">';
	echo rwz_render_slot( '__SLOT__', array() );
	echo '</script>';
	echo '<script type="text/html" id="rwz-item-template">';
	echo rwz_render_item_row( '__SLOT__', '__ITEM__', array() );
	echo '</script>';

	$next_slot = count( $slots );
	?>
	<script>
	jQuery(function ($) {
		var nextSlot = <?php echo (int) $next_slot; ?>;
		var $slots = $('#rwz-slots');

		$('#rwz-add-slot').on('click', function (e) {
			e.preventDefault();
			var tpl = $('#rwz-slot-template').html().split('__SLOT__').join(nextSlot);
			$slots.prepend(tpl); // 2.26.1: nowy termin na górze
			nextSlot++;
		});

		$slots.on('click', '.rwz-add-item', function (e) {
			e.preventDefault();
			var $slot = $(this).closest('.rwz-slot');
			var slotIdx = $slot.attr('data-slot');
			var itemIdx = parseInt($slot.attr('data-next-item'), 10) || 0;
			var tpl = $('#rwz-item-template').html()
				.split('__SLOT__').join(slotIdx)
				.split('__ITEM__').join(itemIdx);
			$slot.find('.rwz-items').first().append(tpl);
			$slot.attr('data-next-item', itemIdx + 1);
			// zainicjuj select2 na nowo dodanym polu wyszukiwania produktu
			$(document.body).trigger('wc-enhanced-select-init');
		});

		$slots.on('click', '.rwz-remove-item', function (e) {
			e.preventDefault();
			$(this).closest('.rwz-item').remove();
		});

		$slots.on('click', '.rwz-remove-slot', function (e) {
			e.preventDefault();
			$(this).closest('.rwz-slot').remove();
		});
	});
	</script>
	<?php

	echo '</div>';
}

// 3) Zapisz konfigurację (indeksy przepisywane sekwencyjnie od 0)
add_action( 'woocommerce_process_product_meta', 'rwz_save_zestaw_fields', 10 );
function rwz_save_zestaw_fields( $post_id ) {
	// Stare dane z poprzedniej wersji zawsze kasujemy — od teraz żyje tylko _rwz_slots
	delete_post_meta( $post_id, '_rwz_components' );

	if ( ! isset( $_POST['rwz_slot'] ) || ! is_array( $_POST['rwz_slot'] ) ) {
		delete_post_meta( $post_id, '_rwz_slots' );
		return;
	}

	$valid_days = array_keys( rwz_days_labels() );
	$clean      = array();

	foreach ( $_POST['rwz_slot'] as $slot ) {
		if ( ! is_array( $slot ) ) {
			continue;
		}

		$items = array();
		if ( isset( $slot['items'] ) && is_array( $slot['items'] ) ) {
			foreach ( $slot['items'] as $item ) {
				$product_id = isset( $item['product_id'] ) ? absint( $item['product_id'] ) : 0;
				if ( ! $product_id ) {
					continue; // pomiń puste/usunięte produkty
				}
				$row_item = array(
					'product_id' => $product_id,
					'type'       => ( isset( $item['type'] ) && 'addon' === $item['type'] ) ? 'addon' : 'main',
				);
				if ( ! empty( $item['photo'] ) ) {
					$row_item['photo'] = 1; // "to zdjęcie pokaż na liście" (na liście jest tylko jedno zdjęcie)
				}
				$items[] = $row_item;
			}
		}

		$days = isset( $slot['days'] )
			? array_values( array_intersect( array_map( 'sanitize_text_field', (array) $slot['days'] ), $valid_days ) )
			: array();

		$date = isset( $slot['date'] ) ? sanitize_text_field( $slot['date'] ) : '';
		if ( $date && ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
			$date = '';
		}

		$from = isset( $slot['from'] ) ? rwz_clean_time( $slot['from'] ) : '';
		$to   = isset( $slot['to'] ) ? rwz_clean_time( $slot['to'] ) : '';

		$date_from = isset( $slot['date_from'] ) ? sanitize_text_field( $slot['date_from'] ) : '';
		$date_to   = isset( $slot['date_to'] ) ? sanitize_text_field( $slot['date_to'] ) : '';
		if ( $date_from && ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date_from ) ) {
			$date_from = '';
		}
		if ( $date_to && ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date_to ) ) {
			$date_to = '';
		}
		if ( $date_from && $date_to && $date_to < $date_from ) { // odwrotnie wpisane – zamieniamy
			list( $date_from, $date_to ) = array( $date_to, $date_from );
		}

		// Całkiem pusty termin (bez produktów, dni, dat i godzin) pomijamy
		if ( empty( $items ) && empty( $days ) && '' === $date && '' === $date_from && '' === $date_to && '' === $from && '' === $to ) {
			continue;
		}

		$clean[] = array(
			'days'      => $days,
			'date'      => $date,
			'date_from' => $date_from,
			'date_to'   => $date_to,
			'from'  => $from,
			'to'    => $to,
			'items' => $items,
		);
	}

	// 2.26.1: formularz pokazuje najnowszy termin na górze – w bazie z powrotem
	// najstarszy pierwszy (od tej kolejności zależy składanie dań w zestawie).
	$clean = array_reverse( $clean );

	if ( empty( $clean ) ) {
		delete_post_meta( $post_id, '_rwz_slots' );
	} else {
		update_post_meta( $post_id, '_rwz_slots', $clean );
	}
}

// 4) Po zapisaniu — przelicz globalnie, które produkty są "składowymi"
//    (żeby móc je ukryć/zablokować), na podstawie WSZYSTKICH "zestawów"
add_action( 'woocommerce_process_product_meta', 'rwz_rebuild_component_flags', 20 );

// Zmiana składu/terminów zestawu wpływa na to, co pokazuje bufor terminów
// dostawy (moduł 06) – wyczyść go, żeby zmiana była widoczna od razu.
add_action( 'woocommerce_process_product_meta', function () {
	if ( function_exists( 'dc_clear_slots_cache' ) ) {
		dc_clear_slots_cache();
	}
}, 21 );
function rwz_rebuild_component_flags( $post_id ) {
	global $wpdb;

	$all_used   = array();
	$addon_used = array();
	$main_used  = array();

	$zestaw_posts = $wpdb->get_col(
		"SELECT DISTINCT post_id FROM {$wpdb->postmeta} WHERE meta_key IN ('_rwz_slots', '_rwz_components')"
	);

	foreach ( $zestaw_posts as $zestaw_id ) {
		foreach ( rwz_get_slots( $zestaw_id ) as $slot ) {
			if ( empty( $slot['items'] ) || ! is_array( $slot['items'] ) ) {
				continue;
			}
			foreach ( $slot['items'] as $row ) {
				if ( empty( $row['product_id'] ) ) {
					continue;
				}
				$pid        = absint( $row['product_id'] );
				$all_used[] = $pid;
				if ( isset( $row['type'] ) && 'addon' === $row['type'] ) {
					$addon_used[] = $pid;
				} else {
					$main_used[] = $pid;
				}
			}
		}
	}

	$all_used   = array_unique( $all_used );
	$addon_used = array_unique( $addon_used );
	// "tylko danie główne" = użyty jako główne i NIGDZIE jako dodatek
	$main_only = array_diff( array_unique( $main_used ), $addon_used );

	// Flaga "ukryty z katalogu/wyszukiwarki" — dla WSZYSTKICH składowych
	$previously_hidden = $wpdb->get_col(
		"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_rwz_hidden_as_component' AND meta_value = 'yes'"
	);
	foreach ( array_diff( $previously_hidden, $all_used ) as $pid ) {
		delete_post_meta( $pid, '_rwz_hidden_as_component' );
	}
	foreach ( $all_used as $pid ) {
		update_post_meta( $pid, '_rwz_hidden_as_component', 'yes' );
	}

	// Flaga "zablokuj samodzielny zakup" — TYLKO dla dań głównych,
	// które nigdzie nie są jednocześnie użyte jako dodatek
	$previously_blocked = $wpdb->get_col(
		"SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_rwz_hidden_as_component_main' AND meta_value = 'yes'"
	);
	foreach ( array_diff( $previously_blocked, $main_only ) as $pid ) {
		delete_post_meta( $pid, '_rwz_hidden_as_component_main' );
	}
	foreach ( $main_only as $pid ) {
		update_post_meta( $pid, '_rwz_hidden_as_component_main', 'yes' );
	}
}

// Czy termin obejmuje podany dzień (tylko zakres dzienny – godziny pomijane)
function rwz_slot_matches_date( $slot, $date ) {
	if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $date ) ) {
		return false;
	}
	$days      = ( isset( $slot['days'] ) && is_array( $slot['days'] ) ) ? $slot['days'] : array();
	$slot_date = isset( $slot['date'] ) ? $slot['date'] : '';

	if ( ! empty( $slot_date ) ) {
		return $slot_date === $date;
	}
	if ( ! rwz_in_date_range( $slot, $date ) ) {
		return false;
	}
	if ( empty( $days ) ) {
		return true;
	}
	$dow = ( new DateTime( $date, wp_timezone() ) )->format( 'D' );
	return in_array( $dow, $days, true );
}

/**
 * WYDAJNOŚĆ (2.26.1): terminy z konkretną datą przybywają codziennie i zostają
 * w zestawie na zawsze. Zamiast przy każdym dniu harmonogramu (i każdym zestawie
 * zagnieżdżonym) sprawdzać wszystkie, indeksujemy je raz na żądanie po dacie:
 * do sprawdzenia trafiają tylko terminy z TĄ datą + terminy bez konkretnej daty.
 * Klucze = pozycje w bazie, więc kolejność terminów zostaje bez zmian.
 */
function rwz_slots_for_date( $product_id, $date ) {
	static $idx = array();
	$product_id = (int) $product_id;
	if ( ! isset( $idx[ $product_id ] ) ) {
		$by  = array();
		$gen = array();
		foreach ( rwz_get_slots( $product_id ) as $i => $slot ) {
			$d = isset( $slot['date'] ) ? (string) $slot['date'] : '';
			if ( '' !== $d ) {
				$by[ $d ][ $i ] = $slot;
			} else {
				$gen[ $i ] = $slot;
			}
		}
		$idx[ $product_id ] = array( $by, $gen );
	}
	list( $by, $gen ) = $idx[ $product_id ];
	if ( empty( $by[ $date ] ) ) {
		return $gen;
	}
	$out = $by[ $date ] + $gen;
	ksort( $out );
	return $out;
}

// Funkcja pomocnicza: aktywne "dania główne" i "dodatki".
// $date = null    → data dostawy wybrana przez klienta (snippet DeliveryCalendar);
//                   gdy jej nie ma – to, co aktywne TERAZ (dni/data + godziny).
// $date = Y-m-d   → to, co aktywne w tym dniu (tylko zakres dzienny, bez godzin).
// Składnik, który sam jest zestawem (np. "Zupa dnia" w "Zestawie dnia"), jest
// rozwijany: zwracamy to, co aktywne NA KOŃCU zagnieżdżenia (np. konkretną zupę).
// Gdy klient jeszcze nie wybrał terminu dostawy, domyślnie pokazujemy skład
// z NAJBLIŻSZEJ możliwej daty dostawy tego zestawu (a nie z "teraz") – dzięki
// temu w niedzielę widać już np. poniedziałkowe danie, a nie pustkę.
function rwz_default_delivery_date( $product_id ) {
	static $cache = array();
	if ( isset( $cache[ $product_id ] ) ) {
		return $cache[ $product_id ];
	}
	$date = null;
	if ( function_exists( 'dc_enabled' ) && dc_enabled() && function_exists( 'dc_slots_for_products' ) ) {
		$slots = dc_slots_for_products( array( $product_id ) );
		if ( $slots ) {
			$dates = array_keys( $slots );
			$date  = $dates[0]; // dc_slots_for_products zwraca daty rosnąco
		}
	}
	$cache[ $product_id ] = $date;
	return $date;
}

/* ============================================================
 * ROLA PRODUKTU W ZESTAWIE: etykieta + kolejność
 *
 * Etykieta ("Pierwsze danie", "Drugie danie"…) wybierana z listy zarządzanej
 * w Produkty → Etykiety na zestawie; kolejność to liczba. Obie należą do
 * PRODUKTU (Schabowy jest zawsze "drugim daniem"), nie do konkretnego zestawu.
 * Kolejność steruje kolejnością zdjęć, nazw w sklejonej nazwie zestawu,
 * krótkiego opisu i listy składników; bez kolejności produkt ląduje na końcu.
 * ============================================================ */
add_action( 'init', function () {
	register_taxonomy( 'rzd_set_label', 'product', array(
		'labels'            => array(
			'name'          => 'Etykiety na zestawie',
			'singular_name' => 'Etykieta na zestawie',
			'menu_name'     => 'Etykiety na zestawie',
			'add_new_item'  => 'Dodaj etykietę',
			'edit_item'     => 'Edytuj etykietę',
			'search_items'  => 'Szukaj etykiet',
			'all_items'     => 'Wszystkie etykiety',
		),
		'public'            => false,
		'show_ui'           => true,
		'show_in_menu'      => true,
		'show_in_nav_menus' => false,
		'show_admin_column' => false,
		'hierarchical'      => false,
		'rewrite'           => false,
		'meta_box_cb'       => false, // własne pole w ramce "Rola w zestawie" (dokładnie jedna etykieta)
	) );
} );

function rwz_get_set_role( $product_id ) {
	static $cache = array();
	$product_id = (int) $product_id;
	if ( isset( $cache[ $product_id ] ) ) {
		return $cache[ $product_id ];
	}
	$names = wp_get_object_terms( $product_id, 'rzd_set_label', array( 'fields' => 'names' ) );
	$raw   = get_post_meta( $product_id, '_rwz_set_order', true );
	return $cache[ $product_id ] = array(
		'label' => ( ! is_wp_error( $names ) && $names ) ? $names[0] : '',
		'order' => ( '' === $raw || false === $raw ) ? null : (int) $raw,
	);
}

// Rola składnika WZGLĘDEM tego zestawu (dla zagnieżdżonego – rola pozycji wpiętej w zestaw).
function rwz_get_component_role( $set_id, $component_id ) {
	$active = rwz_get_active_components( $set_id );
	return isset( $active['roles'][ $component_id ] ) ? $active['roles'][ $component_id ] : array( 'label' => '', 'order' => null );
}

add_action( 'add_meta_boxes', function () {
	add_meta_box( 'rwz_set_role', 'Rola w zestawie', 'rwz_set_role_box_html', 'product', 'side', 'default' );
} );

function rwz_set_role_box_html( $post ) {
	wp_nonce_field( 'rwz_set_role', 'rwz_set_role_nonce' );
	$role   = rwz_get_set_role( $post->ID );
	$labels = get_terms( array( 'taxonomy' => 'rzd_set_label', 'hide_empty' => false ) );
	?>
	<p>
		<label for="rwz_set_label"><strong>Etykieta</strong></label><br>
		<select name="rwz_set_label" id="rwz_set_label" style="width:100%;">
			<option value="">— bez etykiety —</option>
			<?php if ( ! is_wp_error( $labels ) ) : foreach ( $labels as $t ) : ?>
				<option value="<?php echo esc_attr( $t->term_id ); ?>" <?php selected( $role['label'], $t->name ); ?>><?php echo esc_html( $t->name ); ?></option>
			<?php endforeach; endif; ?>
		</select>
	</p>
	<p>
		<label for="rwz_set_order"><strong>Kolejność na zestawie</strong></label><br>
		<input type="number" min="0" step="1" name="rwz_set_order" id="rwz_set_order" value="<?php echo null === $role['order'] ? '' : (int) $role['order']; ?>" style="width:100%;" placeholder="np. 1">
	</p>
	<p class="description">Dotyczy tego produktu, gdy jest daniem w zestawie: najmniejsza liczba idzie pierwsza (zdjęcia, sklejona nazwa). Bez liczby – na końcu. Nowe etykiety dodasz w Produkty → Etykiety na zestawie.</p>
	<?php
}

add_action( 'save_post_product', function ( $post_id ) {
	if ( ! isset( $_POST['rwz_set_role_nonce'] ) || ! wp_verify_nonce( $_POST['rwz_set_role_nonce'], 'rwz_set_role' ) ) {
		return;
	}
	if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$term_id = isset( $_POST['rwz_set_label'] ) ? absint( $_POST['rwz_set_label'] ) : 0;
	wp_set_object_terms( $post_id, $term_id ? array( $term_id ) : array(), 'rzd_set_label', false );
	$order = isset( $_POST['rwz_set_order'] ) ? trim( $_POST['rwz_set_order'] ) : '';
	if ( '' === $order ) {
		delete_post_meta( $post_id, '_rwz_set_order' );
	} else {
		update_post_meta( $post_id, '_rwz_set_order', max( 0, (int) $order ) );
	}
} );

function rwz_get_active_components( $product_id, $date = null, $depth = 0 ) {
	if ( null === $date ) {
		if ( function_exists( 'dc_selected_date' ) && dc_selected_date() ) {
			$date = dc_selected_date(); // klient już wybrał termin – liczy się jego data dostawy
		} else {
			$date = rwz_default_delivery_date( $product_id ); // brak wyboru – najbliższa możliwa data
		}
	}

	// WYDAJNOŚĆ: ten sam zestaw dla tej samej daty jest odpytywany wielokrotnie
	// na jednym wczytaniu strony (raz dla linków do dań, raz dla dodatków, raz
	// dla alergenów) – zapamiętujemy wynik zamiast liczyć go za każdym razem.
	static $memo = array();
	$memo_key = $product_id . '|' . ( $date ? $date : 'teraz' );
	if ( 0 === $depth && isset( $memo[ $memo_key ] ) ) {
		return $memo[ $memo_key ];
	}

	// 'via' = [ id dania => [ id zestawu pośredniego, … ] ] – przez jakie zagnieżdżone
	// zestawy danie trafiło do tego zestawu (od zewnętrznego do najgłębszego).
	// Skład ich nie pokazuje (zasada najgłębszego zagnieżdżenia), ale modyfikacje
	// tak: np. opakowanie ustawione na "Zupie dnia" (moduł 10).
	$result = array( 'main' => array(), 'addon' => array(), 'roles' => array(), 'via' => array() );
	if ( $depth > 5 ) {
		return $result; // ochrona przed pętlą zestaw → zestaw → …
	}

	$cands = $date ? rwz_slots_for_date( $product_id, $date ) : rwz_get_slots( $product_id );
	foreach ( $cands as $slot ) {
		$match = $date ? rwz_slot_matches_date( $slot, $date ) : rwz_slot_matches_now( $slot );
		if ( ! $match ) {
			continue;
		}
		$items = ( isset( $slot['items'] ) && is_array( $slot['items'] ) ) ? $slot['items'] : array();
		foreach ( $items as $row ) {
			if ( empty( $row['product_id'] ) ) {
				continue;
			}
			$p = wc_get_product( $row['product_id'] );
			if ( ! $p ) {
				continue;
			}
			$bucket = ( isset( $row['type'] ) && 'addon' === $row['type'] ) ? 'addon' : 'main';
			// Rola liczy się dla pozycji wpiętej BEZPOŚREDNIO w ten zestaw – także wtedy, gdy
			// pod nią rozwija się zagnieżdżony zestaw (Zupa dnia → Grochówka dziedziczy rolę Zupy dnia).
			$role   = rwz_get_set_role( $p->get_id() );
			$role['photo'] = ! empty( $row['photo'] ); // to danie jest "zdjęciem zestawu" na liście

			// Zagnieżdżony zestaw → schodzimy głębiej. Dania z niego trafiają tam, gdzie
			// był sam zestaw (danie główne / dodatek), jego dodatki zostają dodatkami.
			if ( (int) $p->get_id() !== (int) $product_id && rwz_get_slots( $p->get_id() ) ) {
				$inner = rwz_get_active_components( $p->get_id(), $date, $depth + 1 );
				if ( $inner['main'] ) {
					// Zasada najgłębszego zagnieżdżenia: zagnieżdżony zestaw MA coś
					// zaplanowane na dziś (choćby przez kolejny poziom zagnieżdżenia)
					// – bierzemy to, a nie sam zestaw pośredni.
					foreach ( $inner['main'] as $ip ) {
						$result[ $bucket ][ $ip->get_id() ] = $ip;
						$result['roles'][ $ip->get_id() ]   = $role;
						$deeper = isset( $inner['via'][ $ip->get_id() ] ) ? $inner['via'][ $ip->get_id() ] : array();
						$result['via'][ $ip->get_id() ] = array_merge( array( (int) $p->get_id() ), $deeper );
					}
				} else {
					// Zagnieżdżony zestaw nie ma DZIŚ żadnego dopasowanego terminu –
					// zamiast pustki (i przez to zniknięcia tej pozycji ze składu),
					// pokazujemy nazwę samego zestawu pośredniego (np. "Zupa dnia").
					$result[ $bucket ][ $p->get_id() ] = $p;
					$result['roles'][ $p->get_id() ]   = $role;
				}
				foreach ( $inner['addon'] as $ip ) {
					$result['addon'][ $ip->get_id() ] = $ip;
				}
				continue;
			}

			// klucz = ID, żeby ten sam produkt z nakładających się terminów nie dublował się
			$result[ $bucket ][ $p->get_id() ] = $p;
			$result['roles'][ $p->get_id() ]   = $role;
		}
	}

	// Dania główne wg "kolejności na zestawie": najmniejsza liczba pierwsza,
	// bez liczby – na końcu; przy remisie zostaje dotychczasowa kolejność.
	$mains = array_values( $result['main'] );
	$pos   = array();
	foreach ( $mains as $i => $m ) {
		$pos[ $m->get_id() ] = $i;
	}
	usort( $mains, function ( $a, $b ) use ( $result, $pos ) {
		$oa = isset( $result['roles'][ $a->get_id() ] ) ? $result['roles'][ $a->get_id() ]['order'] : null;
		$ob = isset( $result['roles'][ $b->get_id() ] ) ? $result['roles'][ $b->get_id() ]['order'] : null;
		if ( $oa === $ob ) {
			return $pos[ $a->get_id() ] - $pos[ $b->get_id() ];
		}
		if ( null === $oa ) {
			return 1;
		}
		if ( null === $ob ) {
			return -1;
		}
		return $oa - $ob;
	} );
	$result['main']  = $mains;
	$result['addon'] = array_values( $result['addon'] );

	if ( 0 === $depth ) {
		$memo[ $memo_key ] = $result;
	}
	return $result;
}

// 4b) Nad tytułem: pasek terminu dostawy – klient może zmienić datę, żeby
//     podejrzeć, jaki będzie skład zestawu tego dnia (ta sama mechanika co na liście)
add_action( 'woocommerce_single_product_summary', function () {
	global $product;
	if ( $product && function_exists( 'rwz_get_slots' ) && rwz_get_slots( $product->get_id() ) && function_exists( 'dc_render_bar' ) ) {
		echo dc_render_bar();
	}
}, 4 );

// 5) Podmień tytuł na stronie produktu na dzisiejsze "danie główne"
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_title', 5 );
add_action( 'woocommerce_single_product_summary', 'rwz_render_single_title', 5 );
/**
 * Złożona nazwa zestawu (np. "Tradycyjny Schab z Kością + Zupa dnia") –
 * ta sama logika, co na stronie pojedynczego produktu (rwz_render_single_title),
 * tylko jako zwykła funkcja do użycia gdzie indziej (np. na liście zamówień).
 * Zwraca $default_name bez zmian, jeśli to nie jest zestaw (albo nie ma
 * dziś żadnych aktywnych dań głównych).
 */
/**
 * ID zdjęcia do pokazania dla zestawu: w pierwszej kolejności zdjęcie
 * PODPIĘTEGO na dziś dania głównego (jeśli jest i faktycznie ma zdjęcie),
 * dopiero gdy nic nie jest podpięte (albo podpięty produkt nie ma własnego
 * zdjęcia) – zdjęcie produktu NADRZĘDNEGO (samego zestawu). Używane zarówno
 * na liście (moduł 2), jak i na stronie pojedynczego produktu.
 */
function rwz_get_display_image_id( $product_id ) {
	$fallback = get_post_thumbnail_id( $product_id );
	if ( ! function_exists( 'rwz_get_active_components' ) ) {
		return $fallback;
	}
	$active = rwz_get_active_components( $product_id );
	// 1) danie oznaczone w zestawie checkboxem "Zdjęcie" (jeśli ma własne zdjęcie)
	foreach ( $active['main'] as $p ) {
		if ( (int) $p->get_id() !== (int) $product_id && ! empty( $active['roles'][ $p->get_id() ]['photo'] ) && $p->get_image_id() ) {
			return $p->get_image_id();
		}
	}
	// 2) inaczej pierwsze (wg kolejności na zestawie) danie, które ma zdjęcie
	foreach ( $active['main'] as $p ) {
		if ( (int) $p->get_id() === (int) $product_id ) {
			continue; // to sam zestaw (brak podpiętego dania na dziś) – pomijamy, licz się fallback
		}
		if ( $p->get_image_id() ) {
			return $p->get_image_id();
		}
	}
	return $fallback;
}

/**
 * 2.26.21: zdjęcie zestawu poza naszą listą (strona kategorii / sklepu motywu,
 * bloki produktów, mini-koszyk) = to samo co na liście: zdjęcie podpiętego dziś
 * dania (rwz_get_display_image_id). Tylko front; strona pojedynczego produktu ma
 * własną podmianę (rwz_override_main_image), więc tam nie ruszamy.
 */
add_filter( 'woocommerce_product_get_image_id', 'rwz_loop_image_id', 10, 2 );
function rwz_loop_image_id( $image_id, $product ) {
	static $busy = false;
	if ( $busy || ( is_admin() && ! wp_doing_ajax() ) || ! $product || ( function_exists( 'is_product' ) && is_product() ) ) {
		return $image_id;
	}
	$pid = $product->get_id();
	if ( ! get_post_meta( $pid, '_rwz_slots', true ) && ! get_post_meta( $pid, '_rwz_components', true ) ) {
		return $image_id; // nie zestaw
	}
	$busy = true; // ochrona: get_image_id() dań w środku znów wywołuje ten filtr
	$id   = rwz_get_display_image_id( $pid );
	$busy = false;
	return $id ? $id : $image_id;
}

function rwz_get_display_name( $product_id, $default_name ) {
	if ( ! function_exists( 'rwz_get_active_components' ) ) {
		return $default_name;
	}
	$active = rwz_get_active_components( $product_id );
	if ( empty( $active['main'] ) ) {
		return $default_name;
	}
	$names = array_map( function ( $p ) { return $p->get_name(); }, $active['main'] );
	return implode( ' + ', $names );
}

function rwz_render_single_title() {
	global $product;
	$title = get_the_title();

	if ( $product ) {
		$title = rwz_get_display_name( $product->get_id(), $title );
	}

	echo '<h1 class="product_title entry-title rwz-title">' . esc_html( $title ) . '</h1>'; // 2.26.6: rwz-title – moduł 15 chowa zdublowany tytuł motywu
}

// 6) Podmień główne zdjęcie produktu na zdjęcie dzisiejszego dania
add_filter( 'woocommerce_single_product_image_thumbnail_html', 'rwz_override_main_image', 10, 2 );
function rwz_override_main_image( $html, $post_thumbnail_id ) {
	global $product;
	if ( ! $product ) {
		return $html;
	}

	$active = rwz_get_active_components( $product->get_id() );
	$dania  = array_values( array_filter( $active['main'], function ( $p ) use ( $product ) {
		return $p->get_id() !== $product->get_id() && $p->get_image_id();
	} ) );
	if ( empty( $dania ) ) {
		return $html; // brak dania z własnym zdjęciem – zostaje zdjęcie "Zestawu dnia"
	}

	// Jedno danie główne: pełne zdjęcie produktu, tak jak zwykłe zdjęcie produktu
	if ( 1 === count( $dania ) ) {
		return wp_get_attachment_image( $dania[0]->get_image_id(), 'woocommerce_single', false, array( 'class' => 'wp-post-image' ) );
	}

	// Kilka dań głównych naraz (np. danie + zupa): rząd zdjęć, każde podpisane
	// nazwą dania i klikalne do pełnego rozmiaru (tak jak zoom przy zwykłym
	// produkcie) – wcześniej były to małe, niepowiększalne miniatury.
	$out = '<div class="rwz-multi-images">';
	foreach ( $dania as $mp ) {
		$full_url = wp_get_attachment_image_url( $mp->get_image_id(), 'full' );
		$out .= '<div class="rwz-multi-img">'
			. '<a href="' . esc_url( $full_url ? $full_url : '#' ) . '" target="_blank" rel="noopener">'
			. wp_get_attachment_image( $mp->get_image_id(), 'woocommerce_single', false, array( 'alt' => $mp->get_name() ) )
			. '</a>'
			. '<span>' . ( ! empty( $active['roles'][ $mp->get_id() ]['label'] ) ? '<em class="rwz-role">' . esc_html( $active['roles'][ $mp->get_id() ]['label'] ) . '</em>' : '' ) . esc_html( $mp->get_name() ) . '</span></div>';
	}
	return $out . '</div>';
}

// 7) Podmień krótki opis na opis dzisiejszego dania
add_filter( 'woocommerce_short_description', 'rwz_override_short_description' );
function rwz_override_short_description( $description ) {
	global $product;
	if ( ! $product ) {
		return $description;
	}

	$active = rwz_get_active_components( $product->get_id() );
	if ( empty( $active['main'] ) ) {
		return $description;
	}

	$parts = array();
	foreach ( $active['main'] as $main_product ) {
		if ( $main_product->get_id() === $product->get_id() ) {
			continue;
		}
		$desc    = $main_product->get_short_description();
		$parts[] = $desc
			? '<strong>' . esc_html( $main_product->get_name() ) . ':</strong> ' . $desc
			: '<strong>' . esc_html( $main_product->get_name() ) . '</strong>';
	}

	if ( empty( $parts ) ) {
		return $description;
	}

	return implode( '</p><p>', $parts );
}

// 8) Pokaż dostępne dziś dodatki (np. zupę) z osobnym przyciskiem zakupu
add_action( 'woocommerce_single_product_summary', 'rwz_render_addons', 35 );
function rwz_render_addons() {
	global $product;
	if ( ! $product ) {
		return;
	}

	$active = rwz_get_active_components( $product->get_id() );
	if ( empty( $active['addon'] ) ) {
		return;
	}

	echo '<div class="rwz-addons" style="margin-top:15px;">';
	echo '<h4>' . esc_html__( 'Dodatki dostępne dziś:', 'woocommerce' ) . '</h4>';
	echo '<ul style="list-style:none; padding-left:0;">';
	foreach ( $active['addon'] as $addon ) {
		echo '<li style="margin-bottom:8px; display:flex; align-items:center; gap:8px;">';
		echo '<span>' . esc_html( $addon->get_name() ) . ' &mdash; ' . wp_kses_post( wc_price( wc_get_price_to_display( $addon ) ) ) . '</span>';
		echo do_shortcode( '[add_to_cart id="' . $addon->get_id() . '" show_price="false"]' );
		echo '</li>';
	}
	echo '</ul>';
	echo '</div>';
}

// 8b) Przy dodaniu "Zestawu dnia" do koszyka — zapisz w koszyku listę
//     WSZYSTKICH aktywnych dań głównych. "Zamrażamy" listę w tym momencie,
//     żeby to, co widać w koszyku/zamówieniu, nie zmieniło się, gdyby klient
//     trzymał produkt w koszyku do następnego terminu.
add_filter( 'woocommerce_add_cart_item_data', 'rwz_add_cart_item_data', 10, 2 );
function rwz_add_cart_item_data( $cart_item_data, $product_id ) {
	$active = rwz_get_active_components( $product_id );
	if ( empty( $active['main'] ) ) {
		return $cart_item_data;
	}

	$names = array_map(
		function ( $p ) {
			return $p->get_name();
		},
		$active['main']
	);

	$cart_item_data['rwz_components'] = $names;
	// Unikalny klucz — żeby WooCommerce nie łączył tej pozycji z inną,
	// dodaną w innym terminie z inną zawartością zestawu
	$cart_item_data['unique_key'] = md5( wp_json_encode( $names ) . microtime() );

	return $cart_item_data;
}

// 8c) Pokaż zapisaną listę składników w koszyku i na stronie checkout
add_filter( 'woocommerce_get_item_data', 'rwz_display_cart_item_components', 10, 2 );
function rwz_display_cart_item_components( $item_data, $cart_item ) {
	if ( ! empty( $cart_item['rwz_components'] ) ) {
		$item_data[] = array(
			'key'   => __( 'W zestawie', 'woocommerce' ),
			'value' => implode( ', ', array_map( 'wc_clean', $cart_item['rwz_components'] ) ),
		);
	}
	return $item_data;
}

// 8d) Zapisz tę samą listę jako metadane pozycji ZAMÓWIENIA — widać ją
//     w panelu admina, mailach i na koncie klienta. Cena pozycji zamówienia
//     pozostaje ceną samego "Zestawu dnia".
add_action( 'woocommerce_checkout_create_order_line_item', 'rwz_add_order_line_item_meta', 10, 4 );
function rwz_add_order_line_item_meta( $item, $cart_item_key, $values, $order ) {
	if ( ! empty( $values['rwz_components'] ) ) {
		$item->add_meta_data( __( 'W zestawie', 'woocommerce' ), implode( ', ', $values['rwz_components'] ), true );
	}
}

// 9) Widoczność w katalogu: NIE ukrywamy już automatycznie składowych.
//    Widoczność w sklepie ustawia się teraz ręcznie, na poziomie kategorii
//    produktów, flagą "Nie wyświetlaj w sklepie" (patrz sekcja "KATEGORIE:
//    widoczność w sklepie" niżej).

// 10) Zablokuj samodzielny zakup produktów, które są WYŁĄCZNIE
//     "daniem głównym" (nigdzie nie pełnią roli dodatku).
//     Dwie warstwy blokady, bo różne ścieżki dodawania do koszyka
//     (klasyczny formularz, AJAX, Store API/blokowy koszyk) sprawdzają je
//     różnie – żeby nie dało się ominąć blokady, sprawdzamy w obu miejscach.
add_filter( 'woocommerce_is_purchasable', 'rwz_block_main_only_purchase', 10, 2 );
function rwz_block_main_only_purchase( $purchasable, $product ) {
	if ( 'yes' === get_post_meta( $product->get_id(), '_rwz_hidden_as_component_main', true ) ) {
		return false;
	}
	return $purchasable;
}

add_filter( 'woocommerce_add_to_cart_validation', 'rwz_block_main_only_validation', 5, 2 );
function rwz_block_main_only_validation( $passed, $product_id ) {
	if ( empty( $GLOBALS['rwz_adding_children'] ) && 'yes' === get_post_meta( $product_id, '_rwz_hidden_as_component_main', true ) ) {
		wc_add_notice( 'Ten produkt jest dostępny wyłącznie w ramach zestawu i nie można go dodać do koszyka osobno.', 'error' );
		return false;
	}
	return $passed;
}

// 11) Komunikat na stronie zablokowanego produktu, gdyby ktoś na nią trafił
add_action( 'woocommerce_single_product_summary', 'rwz_show_component_only_notice', 6 );
function rwz_show_component_only_notice() {
	global $product;
	if ( $product && 'yes' === get_post_meta( $product->get_id(), '_rwz_hidden_as_component_main', true ) ) {
		echo '<p class="woocommerce-info">' . esc_html__( 'Ten produkt jest dostępny wyłącznie w ramach "Zestawu dnia".', 'woocommerce' ) . '</p>';
	}
}

// (Dawna reguła 12 – ukrywanie zestawu bez aktywnych składników – została usunięta.
//  O dostępności zestawu w dniu dostawy decyduje kalendarz dostaw, snippet 6.)


/* ============================================================
 * KATEGORIE: widoczność w sklepie ("Nie wyświetlaj w sklepie")
 * ============================================================
 * Kategoria z tą flagą: produkty w niej NIE pokazują się na liście/w
 * wyszukiwarce sklepu i NIE da się ich kupić samodzielnie z listy –
 * ale ich strona produktu jest dostępna pod bezpośrednim linkiem,
 * a same produkty widać normalnie w koszyku, zamówieniu i w zestawach
 * (tam dodawanie do koszyka odbywa się "obok" tej blokady, przez snippet
 * 4/5, więc jej to nie dotyczy).
 * Użyj tej flagi np. dla produktów z puli dodatków.
 */
add_action( 'product_cat_add_form_fields', function () {
	echo '<div class="form-field"><label><input type="checkbox" name="rwz_hide_in_shop" value="1"> Nie wyświetlaj w sklepie</label>'
		. '<p class="description">Produkty z tej kategorii znikają z listy/wyszukiwarki sklepu (strona produktu nadal działa).</p></div>';
} );
add_action( 'product_cat_edit_form_fields', function ( $term ) {
	$checked = get_term_meta( $term->term_id, 'rwz_hide_in_shop', true );
	echo '<tr class="form-field"><th scope="row"><label>Widoczność</label></th><td>'
		. '<label><input type="checkbox" name="rwz_hide_in_shop" value="1" ' . checked( $checked, '1', false ) . '> Nie wyświetlaj w sklepie</label>'
		. '<p class="description">Produkty z tej kategorii znikają z listy/wyszukiwarki sklepu (strona produktu nadal działa).</p></td></tr>';
} );
add_action( 'created_product_cat', 'rwz_save_hide_in_shop' );
add_action( 'edited_product_cat', 'rwz_save_hide_in_shop' );
function rwz_save_hide_in_shop( $term_id ) {
	if ( isset( $_POST['rwz_hide_in_shop'] ) ) {
		update_term_meta( $term_id, 'rwz_hide_in_shop', '1' );
	} else {
		delete_term_meta( $term_id, 'rwz_hide_in_shop' );
	}
}

function rwz_product_in_hidden_category( $product_id ) {
	static $cache = array();
	if ( isset( $cache[ $product_id ] ) ) {
		return $cache[ $product_id ];
	}
	$hidden = false;
	foreach ( (array) wc_get_product_term_ids( $product_id, 'product_cat' ) as $tid ) {
		if ( get_term_meta( $tid, 'rwz_hide_in_shop', true ) ) {
			$hidden = true;
			break;
		}
	}
	$cache[ $product_id ] = $hidden;
	return $hidden;
}

add_filter( 'woocommerce_product_is_visible', function ( $visible, $product_id ) {
	return rwz_product_in_hidden_category( $product_id ) ? false : $visible;
}, 10, 2 );
