<?php
/**
 * MODUŁ 23: Dashboard sprzedaży
 *
 * Zakładka „📊 Dashboard” w Kuchni (moduł 12) – TYLKO dla zalogowanych
 * dla ról z uprawnieniem „📊 Dashboard” (konfigurator: Użytkownicy → Uprawnienia).
 * Osoba z samym PIN-em Kuchni ani Kurier jej nie widzą.
 *
 * - Sprzedaż = zamówienia wg DATY ZŁOŻENIA, statusy jak w Kuchni
 *   (kuchnia_statuses() – bez anulowanych i nieopłaconych), kwota brutto
 *   minus zwroty.
 * - Kafelki: dziś (zł, zamówienia) vs ten sam dzień tydzień temu, średnia
 *   wartość zamówienia w okresie, dostawy dziś (wg daty dostawy) i kursy,
 *   rekord dnia (ostatnie ~13 mies.) z „🏆 Nowy rekord!”.
 * - Wykresy dzienne (12 mies. → miesięcznie): wartość i liczba zamówień –
 *   DWA osobne wykresy (jedna oś na wykres), SVG rysowane tutaj, dymki
 *   w rzd-kuchnia.js (zakładki przełączają się bez przeładowania, więc
 *   skrypt w treści by nie ruszył).
 * - Listy: top produkty, top dodatki płatne, godziny dostaw, miejscowości,
 *   nowi/powracający klienci (wg e-maila/telefonu), zestaw vs reszta menu.
 * - Dane: jedno zapytanie po zamówienia z ~400 dni, spłaszczone do małych
 *   tablic i zapamiętane (transient rzd_dash_rows, 15 min; czyszczony przy
 *   każdej zmianie zamówienia).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function rzd_dash_allowed() {
	return function_exists( 'rzd_can' ) ? rzd_can( 'dashboard' ) : current_user_can( 'manage_options' ); // uprawnienie z konfiguratora
}

function rzd_dash_periods() {
	return array( 7 => '7 dni', 30 => '30 dni', 90 => '90 dni', 365 => '12 miesięcy' );
}

foreach ( array( 'woocommerce_new_order', 'woocommerce_update_order', 'woocommerce_order_status_changed', 'woocommerce_delete_order', 'woocommerce_trash_order', 'woocommerce_untrash_order', 'woocommerce_order_refunded' ) as $rzd_dash_hook ) {
	add_action( $rzd_dash_hook, 'rzd_dash_flush' );
}
unset( $rzd_dash_hook );
function rzd_dash_flush() {
	delete_transient( 'rzd_dash_rows' );
}

/**
 * Zamówienia z ~400 dni jako małe tablice:
 * [ id, day (Y-m-d złożenia), hour, total, cust, town, ddate, dtime, items[[name,qty,value,set]], addons[[name,qty]] ]
 */
function rzd_dash_rows() {
	$today = current_time( 'Y-m-d' );
	$c     = get_transient( 'rzd_dash_rows' );
	if ( is_array( $c ) && isset( $c['day'], $c['rows'] ) && $c['day'] === $today ) {
		return $c['rows'];
	}
	$statuses = function_exists( 'kuchnia_statuses' ) ? kuchnia_statuses() : array( 'wc-processing', 'wc-completed', 'wc-on-hold' );
	$from     = new DateTime( $today, wp_timezone() );
	$from->modify( '-400 days' );
	$orders = wc_get_orders( array(
		'limit'        => -1,
		'type'         => 'shop_order',
		'status'       => $statuses,
		'date_created' => '>=' . $from->getTimestamp(),
		'orderby'      => 'date',
		'order'        => 'ASC',
	) );
	$rows = array();
	foreach ( $orders as $o ) {
		$d = $o->get_date_created();
		if ( ! $d ) {
			continue;
		}
		$items  = array();
		$addons = array();
		foreach ( $o->get_items() as $it ) {
			$pid     = (int) $it->get_product_id();
			$items[] = array(
				'name'  => $it->get_name(),
				'qty'   => (int) $it->get_quantity(),
				'value' => round( (float) $it->get_total() + (float) $it->get_total_tax(), 2 ),
				'set'   => ( $pid && function_exists( 'rwz_is_set_product' ) && rwz_is_set_product( $pid ) ) ? 1 : 0,
			);
			$usage = json_decode( (string) $it->get_meta( '_rzd_addon_usage' ), true );
			foreach ( (array) $usage as $u ) {
				if ( ! is_array( $u ) || empty( $u['name'] ) ) {
					continue;
				}
				$kind = function_exists( 'rzd_usage_kind' ) ? rzd_usage_kind( $u ) : ( isset( $u['role'] ) && 'dodaje' === $u['role'] ? 'dodatki' : '' );
				if ( 'dodatki' !== $kind ) {
					continue; // tylko dodatki płatne (bez „Bez …”, zamian w zestawie i obowiązkowych)
				}
				$addons[] = array( 'name' => (string) $u['name'], 'qty' => max( 1, (int) ( isset( $u['qty'] ) ? $u['qty'] : 1 ) ) * max( 1, (int) $it->get_quantity() ) );
			}
		}
		$cust = strtolower( trim( (string) $o->get_billing_email() ) );
		if ( '' === $cust ) {
			$cust = preg_replace( '/\D+/', '', (string) $o->get_billing_phone() );
		}
		$rows[] = array(
			'id'     => (int) $o->get_id(),
			'day'    => $d->date( 'Y-m-d' ),
			'hour'   => (int) $d->date( 'G' ),
			'total'  => round( (float) $o->get_total() - (float) $o->get_total_refunded(), 2 ),
			'cust'   => $cust,
			'town'   => trim( (string) $o->get_meta( '_rzd_town' ) ),
			'ddate'  => (string) $o->get_meta( '_dc_delivery_date' ),
			'dtime'  => (string) $o->get_meta( '_dc_delivery_time' ),
			'items'  => $items,
			'addons' => $addons,
		);
	}
	set_transient( 'rzd_dash_rows', array( 'day' => $today, 'rows' => $rows ), 15 * MINUTE_IN_SECONDS );
	return $rows;
}

/** Liczenie wszystkiego, co pokazuje dashboard (bez HTML – łatwe do sprawdzenia). */
function rzd_dash_stats( $rows, $period, $today ) {
	$tz      = wp_timezone();
	$t       = new DateTime( $today, $tz );
	$week    = ( clone $t )->modify( '-7 days' )->format( 'Y-m-d' );
	$start   = ( clone $t )->modify( '-' . ( $period - 1 ) . ' days' )->format( 'Y-m-d' );
	$monthly = $period >= 365;
	if ( $monthly ) {
		$start = ( clone $t )->modify( 'first day of this month' )->modify( '-11 months' )->format( 'Y-m-d' );
	}

	// Kubełki wykresu – także puste dni/miesiące.
	$buckets = array();
	$cur     = new DateTime( $start, $tz );
	while ( $cur->format( 'Y-m-d' ) <= $today ) {
		$k = $monthly ? $cur->format( 'Y-m' ) : $cur->format( 'Y-m-d' );
		if ( ! isset( $buckets[ $k ] ) ) {
			$buckets[ $k ] = array( 'value' => 0.0, 'count' => 0 );
		}
		$cur->modify( $monthly ? 'first day of next month' : '+1 day' );
	}

	$by_day = array(); // wszystkie dni z danych – rekord
	$s      = array(
		'today'    => array( 'value' => 0.0, 'count' => 0 ),
		'week'     => array( 'value' => 0.0, 'count' => 0 ),
		'period'   => array( 'value' => 0.0, 'count' => 0 ),
		'deliv'    => 0,
		'runs'     => array(),
		'products' => array(),
		'addons'   => array(),
		'hours'    => array(),
		'towns'    => array(),
		'new'      => 0,
		'back'     => 0,
		'setval'   => 0.0,
		'restval'  => 0.0,
	);
	$seen = array();
	foreach ( $rows as $r ) {
		$day = $r['day'];
		if ( ! isset( $by_day[ $day ] ) ) {
			$by_day[ $day ] = array( 'value' => 0.0, 'count' => 0 );
		}
		$by_day[ $day ]['value'] += $r['total'];
		$by_day[ $day ]['count']++;
		$returning = ( '' !== $r['cust'] && isset( $seen[ $r['cust'] ] ) );
		if ( '' !== $r['cust'] ) {
			$seen[ $r['cust'] ] = true;
		}
		if ( $day === $today ) {
			$s['today']['value'] += $r['total'];
			$s['today']['count']++;
		}
		if ( $day === $week ) {
			$s['week']['value'] += $r['total'];
			$s['week']['count']++;
		}
		if ( $r['ddate'] === $today ) {
			$s['deliv']++;
			$s['runs'][ $r['dtime'] ] = true;
		}
		if ( $day < $start || $day > $today ) {
			continue;
		}
		$k = $monthly ? substr( $day, 0, 7 ) : $day;
		if ( isset( $buckets[ $k ] ) ) {
			$buckets[ $k ]['value'] += $r['total'];
			$buckets[ $k ]['count']++;
		}
		$s['period']['value'] += $r['total'];
		$s['period']['count']++;
		$s[ $returning ? 'back' : 'new' ]++;
		foreach ( $r['items'] as $it ) {
			$n = $it['name'];
			if ( ! isset( $s['products'][ $n ] ) ) {
				$s['products'][ $n ] = array( 'qty' => 0, 'value' => 0.0 );
			}
			$s['products'][ $n ]['qty']   += $it['qty'];
			$s['products'][ $n ]['value'] += $it['value'];
			if ( $it['set'] ) {
				$s['setval'] += $it['value'];
			} else {
				$s['restval'] += $it['value'];
			}
		}
		foreach ( $r['addons'] as $a ) {
			$s['addons'][ $a['name'] ] = ( isset( $s['addons'][ $a['name'] ] ) ? $s['addons'][ $a['name'] ] : 0 ) + $a['qty'];
		}
		if ( '' !== $r['dtime'] ) {
			$s['hours'][ $r['dtime'] ] = ( isset( $s['hours'][ $r['dtime'] ] ) ? $s['hours'][ $r['dtime'] ] : 0 ) + 1;
		}
		$town                 = '' !== $r['town'] ? $r['town'] : 'Bez miejscowości';
		$s['towns'][ $town ] = ( isset( $s['towns'][ $town ] ) ? $s['towns'][ $town ] : 0 ) + 1;
	}

	// Rekord dnia: najwięcej zamówień (przy remisie – wyższa kwota) i najwyższa kwota.
	$rec_c = array( 'day' => '', 'count' => 0, 'value' => 0.0 );
	$rec_v = array( 'day' => '', 'count' => 0, 'value' => 0.0 );
	$prev_c = 0;
	$prev_v = 0.0;
	foreach ( $by_day as $day => $v ) {
		if ( $v['count'] > $rec_c['count'] || ( $v['count'] === $rec_c['count'] && $v['value'] > $rec_c['value'] ) ) {
			$rec_c = array( 'day' => $day, 'count' => $v['count'], 'value' => $v['value'] );
		}
		if ( $v['value'] > $rec_v['value'] ) {
			$rec_v = array( 'day' => $day, 'count' => $v['count'], 'value' => $v['value'] );
		}
		if ( $day < $today ) {
			$prev_c = max( $prev_c, $v['count'] );
			$prev_v = max( $prev_v, $v['value'] );
		}
	}
	$s['record_count'] = $rec_c;
	$s['record_value'] = $rec_v;
	// Nowy rekord = dziś więcej niż w KAŻDYM wcześniejszym dniu (remis = wyrównany).
	$s['new_record']   = ( $s['today']['count'] > 0 && $s['today']['count'] > $prev_c ) ? 'count' : ( ( $s['today']['value'] > 0 && $s['today']['value'] > $prev_v ) ? 'value' : '' );
	$s['tie_record']   = ( '' === $s['new_record'] && $s['today']['count'] > 0 && $s['today']['count'] === $prev_c );

	uasort( $s['products'], function ( $a, $b ) {
		return array( $b['qty'], $b['value'] ) <=> array( $a['qty'], $a['value'] );
	} );
	arsort( $s['addons'] );
	ksort( $s['hours'] );
	arsort( $s['towns'] );
	$s['runs']    = count( array_filter( array_keys( $s['runs'] ), 'strlen' ) );
	$s['buckets'] = $buckets;
	$s['monthly'] = $monthly;
	$s['start']   = $start;
	$s['days']    = $monthly ? max( 1, ( new DateTime( $start, $tz ) )->diff( $t )->days + 1 ) : $period;
	return $s;
}

function rzd_dash_money( $v, $dec = 2 ) {
	return number_format( (float) $v, $dec, ',', "\xc2\xa0" ) . "\xc2\xa0zł";
}

function rzd_dash_daylabel( $ymd, $long = false ) {
	$dt   = DateTime::createFromFormat( 'Y-m-d', $ymd, wp_timezone() );
	if ( ! $dt ) {
		return $ymd;
	}
	$dows = array( 'nd.', 'pn.', 'wt.', 'śr.', 'czw.', 'pt.', 'sob.' );
	return ( $long ? $dows[ (int) $dt->format( 'w' ) ] . ' ' : '' ) . $dt->format( 'j.m' );
}

function rzd_dash_monthlabel( $ym ) {
	$m = array( '', 'sty', 'lut', 'mar', 'kwi', 'maj', 'cze', 'lip', 'sie', 'wrz', 'paź', 'lis', 'gru' );
	return $m[ (int) substr( $ym, 5, 2 ) ] . ' ' . substr( $ym, 2, 2 );
}

/** Zmiana względem tygodnia wcześniej – strzałka + tekst (nie sam kolor). */
function rzd_dash_delta( $now, $before, $money ) {
	$diff = $now - $before;
	if ( abs( $diff ) < 0.005 ) {
		return '<span class="rd-delta rd-flat">= tyle samo co tydzień temu</span>';
	}
	$txt = $money ? rzd_dash_money( abs( $diff ) ) : (string) abs( (int) $diff );
	return '<span class="rd-delta ' . ( $diff > 0 ? 'rd-up">▲ +' : 'rd-down">▼ −' ) . esc_html( $txt ) . ' vs tydzień temu</span>';
}

/** Ładne maksimum osi (1/2/2,5/5 × 10^n). */
function rzd_dash_nice_max( $v ) {
	if ( $v <= 0 ) {
		return 1;
	}
	$p = pow( 10, floor( log10( $v ) ) );
	foreach ( array( 1, 2, 2.5, 5, 10 ) as $m ) {
		if ( $v <= $m * $p ) {
			return $m * $p;
		}
	}
	return 10 * $p;
}

/**
 * Wykres słupkowy jednej serii (SVG). $points: [ ['label','tip','v','today'] ].
 */
function rzd_dash_bar_chart( $title, $points, $money ) {
	$w    = 720;
	$h    = 210;
	$padl = 78;
	$padr = 8;
	$padt = 12;
	$padb = 26;
	$n    = max( 1, count( $points ) );
	$max  = 0;
	foreach ( $points as $p ) {
		$max = max( $max, $p['v'] );
	}
	$top   = rzd_dash_nice_max( $max );
	if ( ! $money ) { // liczba zamówień – całe liczby na osi (połowa też całkowita)
		$top = max( 2, (int) ceil( $max ) );
		$top = $top + ( $top % 2 );
	}
	$ph    = $h - $padt - $padb;
	$step  = ( $w - $padl - $padr ) / $n;
	$gap   = $step > 8 ? 2 : 1;
	$bw    = max( 1, $step - $gap );
	$every = max( 1, (int) ceil( $n / 10 ) );

	$svg  = '<svg class="rd-chart" viewBox="0 0 ' . $w . ' ' . $h . '" role="img" aria-label="' . esc_attr( $title ) . '">';
	// Siatka: 0, 1/2, max – cienka, wycofana.
	foreach ( array( 0, 0.5, 1 ) as $f ) {
		$y    = $padt + $ph - $ph * $f;
		$val  = $top * $f;
		$lab  = $money ? number_format( $val, 0, ',', ' ' ) : ( floor( $val ) == $val ? (string) (int) $val : number_format( $val, 1, ',', '' ) );
		$svg .= '<line x1="' . $padl . '" x2="' . ( $w - $padr ) . '" y1="' . round( $y, 1 ) . '" y2="' . round( $y, 1 ) . '" class="rd-grid' . ( 0 === $f ? ' rd-base' : '' ) . '"/>';
		$svg .= '<text x="' . ( $padl - 6 ) . '" y="' . round( $y + 4, 1 ) . '" class="rd-ylab">' . esc_html( $lab ) . '</text>';
	}
	foreach ( array_values( $points ) as $i => $p ) {
		$x  = $padl + $i * $step + $gap / 2;
		$bh = $top > 0 ? $ph * $p['v'] / $top : 0;
		$y  = $padt + $ph - $bh;
		if ( $bh > 0.5 ) {
			$r    = min( 4, $bw / 2, $bh );
			$svg .= '<path class="rd-bar' . ( $p['today'] ? ' rd-today' : '' ) . '" d="M' . round( $x, 2 ) . ',' . round( $padt + $ph, 2 ) . 'V' . round( $y + $r, 2 ) . 'Q' . round( $x, 2 ) . ',' . round( $y, 2 ) . ' ' . round( $x + $r, 2 ) . ',' . round( $y, 2 ) . 'H' . round( $x + $bw - $r, 2 ) . 'Q' . round( $x + $bw, 2 ) . ',' . round( $y, 2 ) . ' ' . round( $x + $bw, 2 ) . ',' . round( $y + $r, 2 ) . 'V' . round( $padt + $ph, 2 ) . 'Z"/>';
		}
		// Pole do najechania/dotknięcia – cała wysokość, szersze niż słupek.
		$svg .= '<rect class="rd-hit" x="' . round( $padl + $i * $step, 2 ) . '" y="' . $padt . '" width="' . round( $step, 2 ) . '" height="' . $ph . '" data-tip="' . esc_attr( $p['tip'] ) . '"><title>' . esc_html( $p['tip'] ) . '</title></rect>';
		$from_end = $n - 1 - $i;
		if ( 0 === $from_end % $every ) {
			// co drugi podpis znika na telefonie (rd-xlab-alt), żeby się nie zlewały
			$svg .= '<text x="' . round( $x + $bw / 2, 2 ) . '" y="' . ( $h - 8 ) . '" class="rd-xlab' . ( 0 !== ( $from_end / $every ) % 2 ? ' rd-xlab-alt' : '' ) . '">' . esc_html( $p['label'] ) . '</text>';
		}
	}
	$svg .= '</svg>';
	return '<div class="rd-card rd-chart-card"><h3>' . esc_html( $title ) . '</h3><div class="rd-chart-wrap">' . $svg . '<div class="rd-tip" hidden></div></div></div>';
}

/** Lista z poziomymi paskami (top produkty itp.). $rows: [ label => value ] */
function rzd_dash_bar_list( $title, $rows, $fmt, $limit = 5, $empty = 'Brak danych w tym okresie.' ) {
	$out = '<div class="rd-card"><h3>' . esc_html( $title ) . '</h3>';
	if ( ! $rows ) {
		return $out . '<p class="rd-empty">' . esc_html( $empty ) . '</p></div>';
	}
	$rows = array_slice( $rows, 0, $limit, true );
	$max  = max( $rows );
	$out .= '<ul class="rd-list">';
	foreach ( $rows as $label => $v ) {
		$pct  = $max > 0 ? max( 2, round( 100 * $v / $max ) ) : 0;
		$out .= '<li><span class="rd-l-name">' . esc_html( (string) $label ) . '</span><span class="rd-l-val">' . esc_html( call_user_func( $fmt, $v ) ) . '</span><span class="rd-l-bar"><i style="width:' . (int) $pct . '%"></i></span></li>';
	}
	return $out . '</ul></div>';
}

/** Cała treść zakładki. */
function rzd_dash_html( $base ) {
	if ( ! rzd_dash_allowed() ) {
		return '<p class="kuchnia-empty">Dashboard jest dostępny tylko dla administratora i kierownika sklepu.</p>';
	}
	$periods = rzd_dash_periods();
	$period  = isset( $_GET['period'] ) ? (int) $_GET['period'] : 30; // phpcs:ignore
	$period  = isset( $periods[ $period ] ) ? $period : 30;
	$today   = current_time( 'Y-m-d' );
	$s       = rzd_dash_stats( rzd_dash_rows(), $period, $today );

	ob_start();
	echo '<div class="rd-wrap">';
	rzd_dash_css();

	// Okres
	echo '<div class="rd-periods">';
	foreach ( $periods as $p => $lab ) {
		$url = esc_url( add_query_arg( array( 'date' => $today, 'time' => '', 'view' => 'dashboard', 'period' => $p ), $base ) );
		echo '<a class="kuchnia-tab' . ( $p === $period ? ' is-active' : '' ) . '" href="' . $url . '">' . esc_html( $lab ) . '</a>';
	}
	echo '</div>';

	// Kafelki
	$dname = rzd_dash_daylabel( $today, true );
	echo '<div class="rd-kpis">';
	echo '<div class="rd-kpi"><div class="rd-k-lab">Sprzedaż dziś</div><div class="rd-k-val">' . esc_html( rzd_dash_money( $s['today']['value'] ) ) . '</div>' . rzd_dash_delta( $s['today']['value'], $s['week']['value'], true ) . '</div>'; // phpcs:ignore
	echo '<div class="rd-kpi"><div class="rd-k-lab">Zamówienia dziś</div><div class="rd-k-val">' . (int) $s['today']['count'] . '</div>' . rzd_dash_delta( $s['today']['count'], $s['week']['count'], false ) . '</div>'; // phpcs:ignore
	$aov = $s['period']['count'] ? $s['period']['value'] / $s['period']['count'] : 0;
	echo '<div class="rd-kpi"><div class="rd-k-lab">Średnie zamówienie (' . esc_html( $periods[ $period ] ) . ')</div><div class="rd-k-val">' . esc_html( rzd_dash_money( $aov ) ) . '</div><span class="rd-delta rd-flat">' . (int) $s['period']['count'] . ' zamówień · ' . esc_html( rzd_dash_money( $s['period']['value'], 0 ) ) . '</span></div>';
	echo '<div class="rd-kpi"><div class="rd-k-lab">Dostawy dziś</div><div class="rd-k-val">' . (int) $s['deliv'] . '</div><span class="rd-delta rd-flat">' . ( $s['runs'] ? (int) $s['runs'] . ' ' . ( 1 === $s['runs'] ? 'kurs' : ( $s['runs'] < 5 ? 'kursy' : 'kursów' ) ) : 'brak kursów' ) . '</span></div>';
	$rc = $s['record_count'];
	echo '<div class="rd-kpi rd-record' . ( $s['new_record'] ? ' is-new' : '' ) . '"><div class="rd-k-lab">🏆 Rekord dnia</div>';
	if ( $rc['count'] ) {
		echo '<div class="rd-k-val">' . (int) $rc['count'] . ' <small>zam.</small></div><span class="rd-delta rd-flat">' . esc_html( rzd_dash_daylabel( $rc['day'], true ) . ' · ' . rzd_dash_money( $rc['value'], 0 ) ) . '</span>';
		$rv = $s['record_value'];
		if ( $rv['day'] && $rv['day'] !== $rc['day'] ) {
			echo '<span class="rd-delta rd-flat">najwyższa kwota: ' . esc_html( rzd_dash_money( $rv['value'], 0 ) . ' (' . rzd_dash_daylabel( $rv['day'] ) . ')' ) . '</span>';
		}
		if ( $s['new_record'] ) {
			echo '<span class="rd-badge">🎉 Nowy rekord dziś!</span>';
		} elseif ( $s['tie_record'] ) {
			echo '<span class="rd-badge rd-badge-tie">Dziś wyrównany rekord</span>';
		}
	} else {
		echo '<div class="rd-k-val">—</div>';
	}
	echo '</div>';
	echo '</div>';

	// Wykresy (osobno kwota i liczba – jedna oś na wykres)
	$pv = array();
	$pc = array();
	$table = '';
	foreach ( $s['buckets'] as $k => $b ) {
		$lab   = $s['monthly'] ? rzd_dash_monthlabel( $k ) : rzd_dash_daylabel( $k );
		$long  = $s['monthly'] ? rzd_dash_monthlabel( $k ) : rzd_dash_daylabel( $k, true );
		$tip   = $long . ' · ' . rzd_dash_money( $b['value'] ) . ' · ' . $b['count'] . ' zam.';
		$is_t  = $s['monthly'] ? ( substr( $today, 0, 7 ) === $k ) : ( $today === $k );
		$pv[]  = array( 'label' => $lab, 'tip' => $tip, 'v' => $b['value'], 'today' => $is_t );
		$pc[]  = array( 'label' => $lab, 'tip' => $tip, 'v' => $b['count'], 'today' => $is_t );
		$table = '<tr><td>' . esc_html( $long ) . '</td><td>' . esc_html( rzd_dash_money( $b['value'] ) ) . '</td><td>' . (int) $b['count'] . '</td></tr>' . $table;
	}
	$unit = $s['monthly'] ? 'miesięczna' : 'dzienna';
	echo '<div class="rd-charts">';
	echo rzd_dash_bar_chart( 'Sprzedaż ' . $unit . ' (zł brutto)', $pv, true ); // phpcs:ignore
	echo rzd_dash_bar_chart( 'Liczba zamówień – ' . ( $s['monthly'] ? 'miesięcznie' : 'dziennie' ), $pc, false ); // phpcs:ignore
	echo '</div>';
	echo '<details class="rd-table"><summary>Pokaż dane w tabeli</summary><table class="kuchnia-table"><thead><tr><th>' . ( $s['monthly'] ? 'Miesiąc' : 'Dzień' ) . '</th><th>Sprzedaż</th><th>Zamówienia</th></tr></thead><tbody>' . $table . '</tbody></table></details>'; // phpcs:ignore

	// Listy
	$qty   = function ( $v ) {
		return $v . ' szt.';
	};
	$cnt   = function ( $v ) {
		return $v . ' zam.';
	};
	$prod  = array();
	foreach ( $s['products'] as $n => $v ) {
		$prod[ $n ] = $v['qty'];
	}
	echo '<div class="rd-cards">';
	echo rzd_dash_bar_list( 'Najczęściej zamawiane', $prod, $qty ); // phpcs:ignore
	echo rzd_dash_bar_list( 'Dodatki płatne', $s['addons'], $qty, 5, 'Brak dodatków płatnych w tym okresie.' ); // phpcs:ignore
	echo rzd_dash_bar_list( 'Godziny dostaw', $s['hours'], $cnt, 8 ); // phpcs:ignore
	echo rzd_dash_bar_list( 'Miejscowości', $s['towns'], $cnt, 6 ); // phpcs:ignore

	// Klienci i zestaw – udział (pasek 100%)
	$tot_c = $s['new'] + $s['back'];
	$tot_v = $s['setval'] + $s['restval'];
	echo '<div class="rd-card"><h3>Klienci</h3>';
	if ( $tot_c ) {
		$pn = round( 100 * $s['new'] / $tot_c );
		echo '<div class="rd-split"><i style="width:' . (int) $pn . '%"></i></div>';
		echo '<p class="rd-split-lab"><span><b>' . (int) $s['new'] . '</b> nowi (' . (int) $pn . '%)</span><span><b>' . (int) $s['back'] . '</b> powracający (' . (int) ( 100 - $pn ) . '%)</span></p>';
		echo '<p class="rd-note">Zamówienia w okresie; „powracający” = ten sam e-mail lub telefon zamawiał już wcześniej (dane z ok. 13 mies.).</p>';
	} else {
		echo '<p class="rd-empty">Brak danych w tym okresie.</p>';
	}
	echo '</div>';
	echo '<div class="rd-card"><h3>Zestaw dnia a reszta menu</h3>';
	if ( $tot_v > 0 ) {
		$ps = round( 100 * $s['setval'] / $tot_v );
		echo '<div class="rd-split"><i style="width:' . (int) $ps . '%"></i></div>';
		echo '<p class="rd-split-lab"><span><b>' . esc_html( rzd_dash_money( $s['setval'], 0 ) ) . '</b> zestawy (' . (int) $ps . '%)</span><span><b>' . esc_html( rzd_dash_money( $s['restval'], 0 ) ) . '</b> reszta (' . (int) ( 100 - $ps ) . '%)</span></p>';
		echo '<p class="rd-note">Wartość pozycji (bez dostawy i opakowań).</p>';
	} else {
		echo '<p class="rd-empty">Brak danych w tym okresie.</p>';
	}
	echo '</div>';
	echo '</div>';

	echo '<p class="rd-note">Sprzedaż wg daty złożenia zamówienia, kwoty brutto po zwrotach, bez anulowanych i nieopłaconych. Dane odświeżają się przy każdym nowym lub zmienionym zamówieniu.</p>';
	echo '</div>';
	return ob_get_clean();
}

function rzd_dash_css() {
	echo rzd_css_tag( 'assets/css/rzd-dashboard.css', 'rzd-dash-css' ); // phpcs:ignore
}
