<?php
/**
 * MODUŁ 30: Formularze kontaktowe – wstawiane shortcodem [rzd_kontakt id="…" styl="…"].
 * Część 1: dane – formularze (pola definiowane w panelu, nic na sztywno), typy pól, style, ustawienia wspólne.
 *
 * Opcje:
 * - rzd_kf_forms    – formularze: id => { title, fields[], to, subject, body, reply_to, autoreply…, style, look{}, css }
 * - rzd_kf_settings – wspólne: limit wiadomości z adresu IP, captcha (Turnstile / hCaptcha), czas przechowywania, wspólny CSS
 * Wiadomości – typ wpisu rzd_kf_msg (niepubliczny), część 3.
 * Uprawnienie: rzd_p_forms („Formularze kontaktowe” w Panel restauracji → Zespół → Uprawnienia); antyspam – tylko Administrator.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 1. TYPY PÓL I STYLE
 * ============================================================ */
function rzd_kf_field_types() {
	return array(
		'text'     => 'Tekst (jedna linia)',
		'textarea' => 'Tekst (kilka linii)',
		'email'    => 'E-mail',
		'tel'      => 'Telefon',
		'number'   => 'Liczba',
		'date'     => 'Data',
		'time'     => 'Godzina',
		'select'   => 'Lista rozwijana',
		'radio'    => 'Wybór jednej opcji',
		'checkbox' => 'Wybór kilku opcji',
		'consent'  => 'Zgoda (pole do zaznaczenia)',
		'heading'  => 'Nagłówek / tekst informacyjny',
	);
}
function rzd_kf_has_options( $type ) {
	return in_array( $type, array( 'select', 'radio', 'checkbox' ), true );
}

function rzd_kf_styles() {
	return array(
		'klasyczny' => array( 'label' => 'Klasyczny', 'desc' => 'etykiety nad polami, jak reszta strony', 'labels' => 'above' ),
		'karta'     => array( 'label' => 'Karta', 'desc' => 'formularz w ramce z cieniem, duży przycisk', 'labels' => 'above' ),
		'minimalny' => array( 'label' => 'Minimalny', 'desc' => 'same linie pod polami, etykiety w polu', 'labels' => 'inside' ),
		'ciemny'    => array( 'label' => 'Ciemny', 'desc' => 'na ciemne tło lub zdjęcie, jasny tekst', 'labels' => 'above' ),
	);
}

/* ============================================================
 * 2. FORMULARZE STARTOWE (do edycji i usunięcia – tylko punkt wyjścia)
 * ============================================================ */
function rzd_kf_field( $key, $label, $type, $extra = array() ) {
	return array_merge( rzd_kf_field_defaults(), array( 'key' => $key, 'label' => $label, 'type' => $type ), $extra );
}
function rzd_kf_field_defaults() {
	return array( 'key' => '', 'label' => '', 'type' => 'text', 'required' => 0, 'placeholder' => '', 'help' => '', 'width' => 'full', 'options' => array(), 'min' => '', 'max' => '', 'future' => 0 );
}
function rzd_kf_form_defaults() {
	return array(
		'id'          => '',
		'title'       => '',
		'fields'      => array(),
		'to'          => '',
		'subject'     => 'Wiadomość ze strony – {formularz}',
		'body'        => "Nowa wiadomość z formularza „{formularz}” ({strona}):\n\n{wszystkie_pola}",
		'reply_to'    => '',
		'autoreply'   => 0,
		'ar_subject'  => 'Dziękujemy za wiadomość – {sklep}',
		'ar_body'     => "Dzień dobry,\n\notrzymaliśmy Twoją wiadomość i odpowiemy najszybciej, jak to możliwe.\n\nTwoja wiadomość:\n{wszystkie_pola}\n\nPozdrawiamy\n{sklep}",
		'success'     => 'Dziękujemy! Wiadomość została wysłana – odpowiemy najszybciej, jak to możliwe.',
		'redirect'    => 0,
		'button'      => 'Wyślij',
		'privacy'     => 'Dane z formularza wykorzystamy wyłącznie do odpowiedzi na wiadomość. Administratorem danych jest {sklep}. Szczegóły: [privacy_policy].',
		'style'       => 'klasyczny',
		'look'        => array( 'accent' => '', 'bg' => '', 'radius' => '', 'spacing' => 'normal', 'labels' => '' ),
		'css'         => '',
	);
}
function rzd_kf_starter_forms() {
	$kontakt = array_merge( rzd_kf_form_defaults(), array(
		'id'       => 'kontakt',
		'title'    => 'Kontakt',
		'reply_to' => 'email',
		'subject'  => 'Wiadomość ze strony: {temat}',
		'fields'   => array(
			rzd_kf_field( 'imie', 'Imię i nazwisko', 'text', array( 'required' => 1, 'width' => 'half' ) ),
			rzd_kf_field( 'email', 'E-mail', 'email', array( 'required' => 1, 'width' => 'half' ) ),
			rzd_kf_field( 'telefon', 'Telefon', 'tel', array( 'width' => 'half' ) ),
			rzd_kf_field( 'temat', 'Temat', 'text', array( 'width' => 'half' ) ),
			rzd_kf_field( 'wiadomosc', 'Wiadomość', 'textarea', array( 'required' => 1 ) ),
		),
	) );
	$catering = array_merge( rzd_kf_form_defaults(), array(
		'id'       => 'catering',
		'title'    => 'Zapytanie o catering / imprezę',
		'reply_to' => 'email',
		'button'   => 'Wyślij zapytanie',
		'subject'  => 'Zapytanie o catering: {rodzaj}, {data_wydarzenia}, {liczba_osob} os.',
		'success'  => 'Dziękujemy za zapytanie! Przygotujemy propozycję i odezwiemy się najszybciej, jak to możliwe.',
		'style'    => 'karta',
		'fields'   => array(
			rzd_kf_field( 'h_wydarzenie', 'Wydarzenie', 'heading', array( 'help' => 'Kilka informacji, żebyśmy mogli przygotować propozycję menu i wycenę.' ) ),
			rzd_kf_field( 'rodzaj', 'Rodzaj wydarzenia', 'select', array( 'required' => 1, 'width' => 'half', 'options' => array( 'Urodziny / imieniny', 'Komunia / chrzciny', 'Wesele', 'Spotkanie firmowe', 'Stypa', 'Inne' ) ) ),
			rzd_kf_field( 'data_wydarzenia', 'Data', 'date', array( 'required' => 1, 'width' => 'half', 'future' => 1 ) ),
			rzd_kf_field( 'liczba_osob', 'Liczba osób', 'number', array( 'required' => 1, 'width' => 'half', 'min' => '1', 'max' => '1000' ) ),
			rzd_kf_field( 'godzina', 'Godzina podania', 'time', array( 'width' => 'half' ) ),
			rzd_kf_field( 'miejsce', 'Miejsce (miejscowość, adres)', 'text', array( 'width' => 'half' ) ),
			rzd_kf_field( 'budzet', 'Budżet na osobę (zł)', 'number', array( 'width' => 'half', 'min' => '0' ) ),
			rzd_kf_field( 'szczegoly', 'Szczegóły', 'textarea', array( 'placeholder' => 'np. ciepłe dania czy przekąski, alergie, dowóz i obsługa' ) ),
			rzd_kf_field( 'h_kontakt', 'Kontakt', 'heading' ),
			rzd_kf_field( 'imie', 'Imię i nazwisko', 'text', array( 'required' => 1 ) ),
			rzd_kf_field( 'telefon', 'Telefon', 'tel', array( 'required' => 1, 'width' => 'half' ) ),
			rzd_kf_field( 'email', 'E-mail', 'email', array( 'required' => 1, 'width' => 'half' ) ),
		),
	) );
	return array( 'kontakt' => $kontakt, 'catering' => $catering );
}

/* ============================================================
 * 3. ODCZYT I ZAPIS
 * ============================================================ */
function rzd_kf_forms() {
	if ( isset( $GLOBALS['rzd_kf_forms_cache'] ) ) {
		return $GLOBALS['rzd_kf_forms_cache'];
	}
	$f = get_option( 'rzd_kf_forms', null );
	if ( null === $f ) { // pierwsze uruchomienie – formularze startowe (usunięte już nie wracają)
		$f = rzd_kf_starter_forms();
		update_option( 'rzd_kf_forms', $f, false );
	}
	$out = array();
	foreach ( (array) $f as $id => $form ) {
		if ( is_array( $form ) ) {
			$out[ $id ] = rzd_kf_form_normalize( $form, $id );
		}
	}
	$GLOBALS['rzd_kf_forms_cache'] = $out;
	return $out;
}
function rzd_kf_form( $id ) {
	$f = rzd_kf_forms();
	return isset( $f[ $id ] ) ? $f[ $id ] : null;
}
function rzd_kf_save_forms( $forms ) {
	unset( $GLOBALS['rzd_kf_forms_cache'] );
	update_option( 'rzd_kf_forms', $forms, false );
}
function rzd_kf_form_normalize( $form, $id ) {
	$form         = array_merge( rzd_kf_form_defaults(), $form );
	$form['id']   = $id;
	$form['look'] = array_merge( rzd_kf_form_defaults()['look'], (array) $form['look'] );
	$fields       = array();
	foreach ( (array) $form['fields'] as $fl ) {
		$fields[] = array_merge( rzd_kf_field_defaults(), (array) $fl );
	}
	$form['fields'] = $fields;
	return $form;
}

// Identyfikator formularza / klucz pola: małe litery, cyfry, _ i -; polskie znaki zamieniane.
function rzd_kf_slug( $s, $sep = '_' ) {
	$s = strtolower( remove_accents( (string) $s ) );
	$s = preg_replace( '/[^a-z0-9]+/', $sep, $s );
	return substr( trim( $s, $sep ), 0, 40 );
}

/**
 * Czyszczenie formularza z panelu (kreator wysyła JSON). Zwraca formularz albo WP_Error.
 * Pola: klucze unikalne, typy ze słownika, opcje list – tekst bez HTML; zgoda – dozwolone linki.
 */
function rzd_kf_sanitize_form( $in, $id ) {
	$d     = rzd_kf_form_defaults();
	$types = rzd_kf_field_types();
	$f     = array( 'id' => $id );
	$f['title'] = sanitize_text_field( isset( $in['title'] ) ? $in['title'] : '' );
	if ( '' === $f['title'] ) {
		return new WP_Error( 'rzd_kf', 'Podaj nazwę formularza.' );
	}
	$fields = array();
	$keys   = array();
	foreach ( array_slice( (array) ( isset( $in['fields'] ) ? $in['fields'] : array() ), 0, 60 ) as $fl ) {
		if ( ! is_array( $fl ) ) {
			continue;
		}
		$type = isset( $fl['type'], $types[ $fl['type'] ] ) ? $fl['type'] : 'text';
		$label = 'consent' === $type
			? wp_kses( (string) ( isset( $fl['label'] ) ? $fl['label'] : '' ), array( 'a' => array( 'href' => true, 'target' => true, 'rel' => true ), 'strong' => array(), 'em' => array() ) )
			: sanitize_text_field( isset( $fl['label'] ) ? $fl['label'] : '' );
		if ( '' === trim( wp_strip_all_tags( $label ) ) ) {
			continue; // pole bez etykiety – pomijamy
		}
		$key = rzd_kf_slug( isset( $fl['key'] ) && '' !== $fl['key'] ? $fl['key'] : wp_strip_all_tags( $label ) );
		if ( '' === $key || is_numeric( $key[0] ) ) {
			$key = 'pole_' . $key;
		}
		$base = $key;
		for ( $i = 2; isset( $keys[ $key ] ); $i++ ) {
			$key = $base . '_' . $i;
		}
		$keys[ $key ] = true;
		$opts = array();
		if ( rzd_kf_has_options( $type ) ) {
			$raw  = isset( $fl['options'] ) ? $fl['options'] : array();
			$raw  = is_array( $raw ) ? $raw : preg_split( '/\r\n|\r|\n/', (string) $raw );
			$opts = array_values( array_unique( array_filter( array_map( 'sanitize_text_field', $raw ), 'strlen' ) ) );
			if ( ! $opts ) {
				return new WP_Error( 'rzd_kf', 'Pole „' . wp_strip_all_tags( $label ) . '” potrzebuje co najmniej jednej opcji do wyboru.' );
			}
		}
		$num = function ( $v ) {
			$v = str_replace( ',', '.', trim( (string) $v ) );
			return is_numeric( $v ) ? $v : '';
		};
		$fields[] = array(
			'key'         => $key,
			'label'       => $label,
			'type'        => $type,
			'required'    => 'heading' === $type ? 0 : ( empty( $fl['required'] ) ? 0 : 1 ),
			'placeholder' => sanitize_text_field( isset( $fl['placeholder'] ) ? $fl['placeholder'] : '' ),
			'help'        => sanitize_textarea_field( isset( $fl['help'] ) ? $fl['help'] : '' ),
			'width'       => isset( $fl['width'] ) && 'half' === $fl['width'] && ! in_array( $type, array( 'heading', 'textarea', 'consent' ), true ) ? 'half' : 'full',
			'options'     => $opts,
			'min'         => 'number' === $type ? $num( isset( $fl['min'] ) ? $fl['min'] : '' ) : '',
			'max'         => 'number' === $type ? $num( isset( $fl['max'] ) ? $fl['max'] : '' ) : '',
			'future'      => 'date' === $type && ! empty( $fl['future'] ) ? 1 : 0,
		);
	}
	if ( ! array_filter( $fields, function ( $x ) {
		return 'heading' !== $x['type'];
	} ) ) {
		return new WP_Error( 'rzd_kf', 'Formularz musi mieć co najmniej jedno pole do wypełnienia.' );
	}
	$f['fields'] = $fields;
	// adresaci
	$to = array();
	foreach ( preg_split( '/[,;\s]+/', (string) ( isset( $in['to'] ) ? $in['to'] : '' ) ) as $e ) {
		$e = sanitize_email( $e );
		if ( is_email( $e ) ) {
			$to[] = $e;
		}
	}
	$f['to']         = implode( ', ', array_unique( $to ) );
	$f['subject']    = sanitize_text_field( isset( $in['subject'] ) && '' !== trim( $in['subject'] ) ? $in['subject'] : $d['subject'] );
	$f['body']       = sanitize_textarea_field( isset( $in['body'] ) && '' !== trim( $in['body'] ) ? $in['body'] : $d['body'] );
	$emails          = wp_list_pluck( array_filter( $fields, function ( $x ) {
		return 'email' === $x['type'];
	} ), 'key' );
	$f['reply_to']   = isset( $in['reply_to'] ) && in_array( $in['reply_to'], $emails, true ) ? $in['reply_to'] : ( $emails ? reset( $emails ) : '' );
	$f['autoreply']  = ! empty( $in['autoreply'] ) && $f['reply_to'] ? 1 : 0;
	$f['ar_subject'] = sanitize_text_field( isset( $in['ar_subject'] ) && '' !== trim( $in['ar_subject'] ) ? $in['ar_subject'] : $d['ar_subject'] );
	$f['ar_body']    = sanitize_textarea_field( isset( $in['ar_body'] ) && '' !== trim( $in['ar_body'] ) ? $in['ar_body'] : $d['ar_body'] );
	$f['success']    = sanitize_textarea_field( isset( $in['success'] ) && '' !== trim( $in['success'] ) ? $in['success'] : $d['success'] );
	$f['redirect']   = isset( $in['redirect'] ) ? absint( $in['redirect'] ) : 0;
	$f['button']     = sanitize_text_field( isset( $in['button'] ) && '' !== trim( $in['button'] ) ? $in['button'] : $d['button'] );
	$f['privacy']    = sanitize_textarea_field( isset( $in['privacy'] ) ? $in['privacy'] : $d['privacy'] );
	$f['style']      = isset( $in['style'] ) && isset( rzd_kf_styles()[ $in['style'] ] ) ? $in['style'] : 'klasyczny';
	$look            = isset( $in['look'] ) && is_array( $in['look'] ) ? $in['look'] : array();
	$f['look']       = array(
		'accent'  => (string) sanitize_hex_color( isset( $look['accent'] ) ? $look['accent'] : '' ),
		'bg'      => (string) sanitize_hex_color( isset( $look['bg'] ) ? $look['bg'] : '' ),
		'radius'  => isset( $look['radius'] ) && '' !== (string) $look['radius'] ? (string) max( 0, min( 40, (int) $look['radius'] ) ) : '',
		'spacing' => isset( $look['spacing'] ) && in_array( $look['spacing'], array( 'compact', 'normal', 'airy' ), true ) ? $look['spacing'] : 'normal',
		'labels'  => isset( $look['labels'] ) && in_array( $look['labels'], array( 'above', 'inside' ), true ) ? $look['labels'] : '',
	);
	$f['css']        = rzd_kf_sanitize_css( isset( $in['css'] ) ? $in['css'] : '' );
	return array_merge( $d, $f );
}

/**
 * Własny CSS od użytkownika: bez znaczników (nie da się zamknąć <style> i wstawić skryptu), do 20 000 znaków.
 * To nadal CSS całej strony – reguła poza klasą formularza zadziała na całej stronie (opis w panelu).
 */
function rzd_kf_sanitize_css( $css ) {
	$css = wp_strip_all_tags( (string) $css );
	$css = str_replace( array( '<', '\\3c', '\\3C', '\\00003c' ), '', $css );
	$css = preg_replace( '/@import[^;]*;?/i', '', $css ); // bez ładowania obcych arkuszy
	return substr( trim( $css ), 0, 20000 );
}

/* ============================================================
 * 4. USTAWIENIA WSPÓLNE
 * ============================================================ */
function rzd_kf_settings() {
	$s = get_option( 'rzd_kf_settings', array() );
	return wp_parse_args( is_array( $s ) ? $s : array(), array(
		'rate'       => 5,   // wiadomości z jednego adresu IP na godzinę (0 = bez limitu)
		'captcha'    => '',  // '' / turnstile / hcaptcha
		'site_key'   => '',
		'secret'     => '',  // zaszyfrowany (jak hasła poczty)
		'keep'       => 12,  // miesiące przechowywania wiadomości (0 = bez usuwania)
		'css'        => '',  // wspólny CSS wszystkich formularzy
		'spam_count' => 0,
	) );
}
function rzd_kf_captcha_on() {
	$s = rzd_kf_settings();
	return in_array( $s['captcha'], array( 'turnstile', 'hcaptcha' ), true ) && '' !== $s['site_key'] && '' !== rzd_mail_decrypt( $s['secret'] );
}

/* ============================================================
 * 5. UPRAWNIENIE (konfigurator ról – moduł 25)
 * ============================================================ */
function rzd_kf_can() {
	return current_user_can( 'manage_options' ) || current_user_can( 'rzd_p_forms' );
}
