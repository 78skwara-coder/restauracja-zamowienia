<?php
/**
 * Moduł 30 – część 3: wysłanie formularza – sprawdzenie, ochrona przed spamem, zapis w Wiadomościach, maile.
 *
 * Ochrona (bez zewnętrznych usług): pochodzenie żądania (Origin/Referer – jak akcje sklepu od 2.33.1), ukryte pole
 * (pułapka na roboty), podpisany czas wyświetlenia (wysłanie w < 3 s = robot), limit wiadomości z adresu IP na godzinę.
 * Opcjonalnie Cloudflare Turnstile / hCaptcha. Bez nonce WordPressa – strona z formularzem bywa w pamięci podręcznej
 * (cache), a nonce w zapisanej kopii po kilkunastu godzinach przestaje działać.
 * Wiadomość zapisuje się ZANIM pójdzie mail – nawet gdy poczta zawiedzie, zapytanie zostaje w panelu.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'RZD_KF_MIN_SECONDS', 3 );

/* ============================================================
 * 1. TYP WPISU „Wiadomość” (niepubliczny – lista w panelu, część 4)
 * ============================================================ */
add_action( 'init', function () {
	register_post_type( 'rzd_kf_msg', array(
		'label'           => 'Wiadomości',
		'public'          => false,
		'show_ui'         => false,
		'show_in_rest'    => false,
		'rewrite'         => false,
		'query_var'       => false,
		'supports'        => array( 'title' ),
		'capability_type' => 'post',
	) );
} );

/* ============================================================
 * 2. SPRAWDZENIE PÓL
 * ============================================================ */
function rzd_kf_len( $s ) {
	return function_exists( 'mb_strlen' ) ? mb_strlen( $s ) : strlen( $s );
}
function rzd_kf_cut( $s, $n ) {
	return function_exists( 'mb_substr' ) ? mb_substr( $s, 0, $n ) : substr( $s, 0, $n );
}

/**
 * Zwraca [ values (do ponownego pokazania), display (tekst do maila/zapisu), errors ].
 */
function rzd_kf_validate( $form, $input ) {
	$values = array();
	$disp   = array();
	$errors = array();
	foreach ( $form['fields'] as $f ) {
		$k = $f['key'];
		$t = $f['type'];
		if ( 'heading' === $t ) {
			continue;
		}
		$raw = isset( $input[ $k ] ) ? $input[ $k ] : '';
		$err = '';
		if ( 'checkbox' === $t ) {
			$v   = array_values( array_intersect( $f['options'], array_map( 'strval', (array) $raw ) ) );
			$out = implode( ', ', $v );
			if ( $f['required'] && ! $v ) {
				$err = 'Wybierz co najmniej jedną opcję.';
			}
		} elseif ( 'consent' === $t ) {
			$v   = is_scalar( $raw ) && '1' === (string) $raw ? '1' : '';
			$out = $v ? 'tak' : 'nie';
			if ( $f['required'] && ! $v ) {
				$err = 'Zaznacz to pole, aby wysłać.';
			}
		} else {
			$v = is_scalar( $raw ) ? (string) $raw : '';
			$v = 'textarea' === $t ? sanitize_textarea_field( $v ) : sanitize_text_field( $v );
			$v = rzd_kf_cut( trim( $v ), 'textarea' === $t ? 5000 : 200 );
			$out = $v;
			if ( '' === $v ) {
				if ( $f['required'] ) {
					$err = in_array( $t, array( 'select', 'radio' ), true ) ? 'Wybierz jedną z opcji.' : 'To pole jest wymagane.';
				}
			} else {
				switch ( $t ) {
					case 'email':
						$v = sanitize_email( $v );
						if ( ! is_email( $v ) ) {
							$err = 'Podaj poprawny adres e-mail.';
						}
						$out = $v;
						break;
					case 'tel':
						$d = preg_replace( '/\D/', '', $v );
						if ( preg_match( '/[^0-9 +()\-.\/]/', $v ) || strlen( $d ) < 7 || strlen( $d ) > 15 ) {
							$err = 'Podaj poprawny numer telefonu.';
						}
						break;
					case 'number':
						$n = str_replace( array( ',', ' ' ), array( '.', '' ), $v );
						if ( ! is_numeric( $n ) ) {
							$err = 'Podaj liczbę.';
						} elseif ( '' !== $f['min'] && (float) $n < (float) $f['min'] ) {
							$err = 'Najmniej ' . $f['min'] . '.';
						} elseif ( '' !== $f['max'] && (float) $n > (float) $f['max'] ) {
							$err = 'Najwięcej ' . $f['max'] . '.';
						}
						$v = $out = $n; // phpcs:ignore
						break;
					case 'date':
						$p = explode( '-', $v );
						if ( 3 !== count( $p ) || ! checkdate( (int) $p[1], (int) $p[2], (int) $p[0] ) ) {
							$err = 'Podaj poprawną datę.';
						} elseif ( ! empty( $f['future'] ) && $v < wp_date( 'Y-m-d' ) ) {
							$err = 'Data nie może być wcześniejsza niż dziś.';
						} else {
							$out = sprintf( '%02d.%02d.%04d', $p[2], $p[1], $p[0] );
						}
						break;
					case 'time':
						if ( ! preg_match( '/^([01]\d|2[0-3]):[0-5]\d$/', $v ) ) {
							$err = 'Podaj godzinę, np. 14:30.';
						}
						break;
					case 'select':
					case 'radio':
						if ( ! in_array( $v, $f['options'], true ) ) {
							$err = 'Wybierz jedną z opcji.';
						}
						break;
				}
			}
		}
		$values[ $k ] = $v;
		$disp[ $k ]   = array( 'label' => wp_strip_all_tags( $f['label'] ), 'type' => $t, 'value' => $out );
		if ( '' !== $err ) {
			$errors[ $k ] = $err;
		}
	}
	return array( $values, $disp, $errors );
}

/* ============================================================
 * 3. OCHRONA PRZED SPAMEM
 * ============================================================ */
function rzd_kf_ip() {
	return (string) apply_filters( 'rzd_kf_ip', isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '' ); // phpcs:ignore
}
function rzd_kf_rate_key() {
	return 'rzd_kf_rl_' . substr( hash_hmac( 'sha256', rzd_kf_ip(), wp_salt( 'nonce' ) ), 0, 20 ); // adres IP nie trafia do bazy
}
function rzd_kf_spam_hit( $why ) {
	$s = get_option( 'rzd_kf_settings', array() );
	$s = is_array( $s ) ? $s : array();
	$s['spam_count'] = ( isset( $s['spam_count'] ) ? (int) $s['spam_count'] : 0 ) + 1;
	update_option( 'rzd_kf_settings', $s, false );
	rzd_log( 'info', 'Formularz kontaktowy: zatrzymano spam (' . $why . ')', 'restauracja-kontakt' );
}
// Sprawdzenie Cloudflare Turnstile / hCaptcha po stronie serwera.
function rzd_kf_captcha_ok( $input ) {
	$s      = rzd_kf_settings();
	$turn   = 'turnstile' === $s['captcha'];
	$field  = $turn ? 'cf-turnstile-response' : 'h-captcha-response';
	$tok    = isset( $input[ $field ] ) && is_scalar( $input[ $field ] ) ? (string) $input[ $field ] : '';
	if ( '' === $tok ) {
		return false;
	}
	$url  = $turn ? 'https://challenges.cloudflare.com/turnstile/v0/siteverify' : 'https://api.hcaptcha.com/siteverify';
	$body = array( 'secret' => rzd_mail_decrypt( $s['secret'] ), 'response' => $tok, 'remoteip' => rzd_kf_ip() );
	if ( ! $turn ) {
		$body['sitekey'] = $s['site_key'];
	}
	$r = wp_remote_post( $url, array( 'timeout' => 10, 'body' => $body ) );
	if ( is_wp_error( $r ) ) {
		rzd_log( 'warning', 'Formularz kontaktowy: brak połączenia z usługą captcha – ' . $r->get_error_message(), 'restauracja-kontakt' );
		return true; // awaria usługi nie może blokować klientów – zostają pozostałe zabezpieczenia
	}
	$j = json_decode( (string) wp_remote_retrieve_body( $r ), true );
	return ! empty( $j['success'] );
}

/* ============================================================
 * 4. WYSŁANIE – jedna funkcja dla AJAX i zwykłego wysłania
 * ============================================================ */
function rzd_kf_process( $input ) {
	$id   = isset( $input['rzd_kf_form'] ) ? sanitize_key( $input['rzd_kf_form'] ) : '';
	$form = rzd_kf_form( $id );
	$res  = array( 'ok' => false, 'id' => $id, 'values' => array(), 'errors' => array(), 'message' => '', 'redirect' => '' );
	if ( ! $form ) {
		$res['errors']['_form'] = 'Ten formularz nie istnieje – odśwież stronę.';
		return $res;
	}
	$fake_ok = array_merge( $res, array( 'ok' => true, 'message' => $form['success'] ) ); // roboty widzą „wysłano”
	if ( ! rzd_request_same_origin() ) {
		$res['errors']['_form'] = 'Nie udało się wysłać z tej strony – odśwież ją i spróbuj ponownie.';
		return $res;
	}
	if ( isset( $input['rzd_kf_www'] ) && '' !== trim( (string) $input['rzd_kf_www'] ) ) {
		rzd_kf_spam_hit( 'ukryte pole' );
		return $fake_ok;
	}
	list( $values, $disp, $errors ) = rzd_kf_validate( $form, isset( $input['f'] ) && is_array( $input['f'] ) ? $input['f'] : array() );
	$res['values'] = $values;
	$tok = explode( '.', isset( $input['rzd_kf_t'] ) ? (string) $input['rzd_kf_t'] : '' );
	$age = 2 === count( $tok ) ? time() - (int) $tok[0] : -1;
	if ( 2 !== count( $tok ) || ! hash_equals( substr( hash_hmac( 'sha256', (int) $tok[0] . '|' . $id, wp_salt( 'nonce' ) ), 0, 24 ), $tok[1] ) || $age > 60 * DAY_IN_SECONDS ) {
		$res['errors']['_form'] = 'Strona była otwarta zbyt długo – odśwież ją i wyślij ponownie (wpisane dane skopiuj).';
		return $res;
	}
	if ( $errors ) { // błędy pól najpierw – człowiek, który od razu kliknie „Wyślij”, widzi, co uzupełnić
		$res['errors'] = $errors;
		return $res;
	}
	if ( $age < (int) apply_filters( 'rzd_kf_min_seconds', RZD_KF_MIN_SECONDS ) ) {
		rzd_kf_spam_hit( 'za szybko: ' . $age . ' s' );
		return $fake_ok;
	}
	$s     = rzd_kf_settings();
	$limit = (int) $s['rate'];
	$rk    = rzd_kf_rate_key();
	$cnt   = (int) get_transient( $rk );
	if ( $limit > 0 && $cnt >= $limit && ! rzd_kf_can() ) {
		$res['errors']['_form'] = 'Wysłano już kilka wiadomości z tego połączenia – spróbuj ponownie za godzinę albo zadzwoń do nas.';
		rzd_log( 'info', 'Formularz kontaktowy: limit wiadomości z adresu IP', 'restauracja-kontakt' );
		return $res;
	}
	if ( rzd_kf_captcha_on() && ! rzd_kf_captcha_ok( $input ) ) {
		$res['errors']['_form'] = 'Potwierdź, że nie jesteś robotem (pole nad przyciskiem), i wyślij ponownie.';
		return $res;
	}
	set_transient( $rk, $cnt + 1, HOUR_IN_SECONDS );

	$page   = isset( $input['rzd_kf_page'] ) ? absint( $input['rzd_kf_page'] ) : 0;
	$msg_id = rzd_kf_store( $form, $disp, $values, $page );
	$sent   = rzd_kf_send_mails( $form, $disp, $values, $page );
	if ( $msg_id ) {
		update_post_meta( $msg_id, '_rzd_kf_mail', $sent ? 'ok' : 'fail' );
	}
	rzd_kf_cleanup();
	$res['ok']       = true;
	$res['message']  = $form['success'];
	$res['redirect'] = $form['redirect'] && 'publish' === get_post_status( $form['redirect'] ) ? get_permalink( $form['redirect'] ) : '';
	do_action( 'rzd_kf_submitted', $form, $disp, $msg_id );
	return $res;
}

add_action( 'wp_ajax_rzd_kf_send', 'rzd_kf_ajax' );
add_action( 'wp_ajax_nopriv_rzd_kf_send', 'rzd_kf_ajax' );
function rzd_kf_ajax() {
	$r = rzd_kf_process( wp_unslash( $_POST ) ); // phpcs:ignore -- ochrona: pochodzenie + podpisany czas + pułapka; pola czyszczone w rzd_kf_validate
	$d = array( 'message' => $r['message'], 'errors' => (object) $r['errors'], 'redirect' => $r['redirect'] );
	if ( $r['ok'] ) {
		wp_send_json_success( $d );
	}
	wp_send_json_error( $d );
}

// Bez JavaScriptu: formularz wysyła się na tę samą stronę.
add_action( 'template_redirect', function () {
	if ( 'POST' !== ( isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : '' ) || empty( $_POST['rzd_kf_form'] ) || wp_doing_ajax() ) { // phpcs:ignore
		return;
	}
	$r = rzd_kf_process( wp_unslash( $_POST ) ); // phpcs:ignore -- jak wyżej
	if ( $r['ok'] ) {
		$here = set_url_scheme( 'http://' . ( isset( $_SERVER['HTTP_HOST'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) ) : '' ) . ( isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '/' ) ); // phpcs:ignore
		$to   = $r['redirect'] ? $r['redirect'] : add_query_arg( 'rzd_kf_ok', $r['id'], remove_query_arg( 'rzd_kf_ok', $here ) ) . '#rzd-kf-' . $r['id'];
		wp_safe_redirect( $to, 303 );
		exit;
	}
	$GLOBALS['rzd_kf_state'][ $r['id'] ] = array( 'values' => $r['values'], 'errors' => $r['errors'] );
} );

/* ============================================================
 * 5. ZAPIS WIADOMOŚCI
 * ============================================================ */
function rzd_kf_reply_email( $form, $values ) {
	return $form['reply_to'] && isset( $values[ $form['reply_to'] ] ) && is_email( $values[ $form['reply_to'] ] ) ? $values[ $form['reply_to'] ] : '';
}
function rzd_kf_sender_name( $form, $values ) {
	foreach ( $form['fields'] as $f ) {
		if ( 'text' === $f['type'] && 'name' === rzd_kf_autocomplete( $f ) && ! empty( $values[ $f['key'] ] ) ) {
			return $values[ $f['key'] ];
		}
	}
	return '';
}
function rzd_kf_store( $form, $disp, $values, $page ) {
	$email = rzd_kf_reply_email( $form, $values );
	$who   = rzd_kf_sender_name( $form, $values );
	$id    = wp_insert_post( array(
		'post_type'   => 'rzd_kf_msg',
		'post_status' => 'publish',
		'post_title'  => rzd_kf_cut( $form['title'] . ' – ' . ( $who ? $who : ( $email ? $email : 'bez podpisu' ) ), 190 ),
		'post_author' => get_current_user_id(),
	), true );
	if ( is_wp_error( $id ) ) {
		rzd_log( 'error', 'Formularz kontaktowy: nie zapisano wiadomości – ' . $id->get_error_message(), 'restauracja-kontakt' );
		return 0;
	}
	update_post_meta( $id, '_rzd_kf_form', $form['id'] );
	update_post_meta( $id, '_rzd_kf_form_title', $form['title'] );
	update_post_meta( $id, '_rzd_kf_fields', array_values( $disp ) ); // etykiety z chwili wysłania – zmiana formularza nie psuje starych
	update_post_meta( $id, '_rzd_kf_email', $email );
	update_post_meta( $id, '_rzd_kf_name', $who );
	update_post_meta( $id, '_rzd_kf_status', 'new' );
	update_post_meta( $id, '_rzd_kf_page', $page );
	rzd_kf_recount();
	return $id;
}
function rzd_kf_recount() {
	$q = new WP_Query( array( 'post_type' => 'rzd_kf_msg', 'post_status' => 'publish', 'fields' => 'ids', 'posts_per_page' => 1, 'no_found_rows' => false, 'meta_key' => '_rzd_kf_status', 'meta_value' => 'new' ) ); // phpcs:ignore
	update_option( 'rzd_kf_new', (int) $q->found_posts, true );
}
// Usuwanie starszych niż ustawiona liczba miesięcy (porcjami, przy wysłaniu i wejściu w Wiadomości).
function rzd_kf_cleanup() {
	$m = (int) rzd_kf_settings()['keep'];
	if ( $m <= 0 ) {
		return 0;
	}
	$old = get_posts( array( 'post_type' => 'rzd_kf_msg', 'post_status' => 'any', 'fields' => 'ids', 'numberposts' => 50, 'date_query' => array( array( 'before' => gmdate( 'Y-m-d H:i:s', strtotime( '-' . $m . ' months' ) ), 'column' => 'post_date_gmt' ) ) ) );
	foreach ( $old as $pid ) {
		wp_delete_post( $pid, true );
	}
	if ( $old ) {
		rzd_kf_recount();
	}
	return count( $old );
}

/* ============================================================
 * 6. MAILE (przez moduł poczty – dziennik, kolejka, połączenie zapasowe)
 * ============================================================ */
function rzd_kf_vars( $form, $disp, $page ) {
	$v = array(
		'{formularz}' => $form['title'],
		'{sklep}'     => rzd_kf_shop_name(),
		'{strona}'    => $page ? get_permalink( $page ) : home_url( '/' ),
		'{data}'      => wp_date( 'j.m.Y H:i' ),
	);
	foreach ( $disp as $k => $d ) {
		$v[ '{' . $k . '}' ] = $d['value'];
	}
	return $v;
}
function rzd_kf_table_html( $disp ) {
	$h = '<table cellpadding="6" cellspacing="0" style="border-collapse:collapse;border:1px solid #ddd;font-family:Arial,sans-serif;font-size:14px">';
	foreach ( $disp as $d ) {
		$h .= '<tr><th align="left" valign="top" style="border:1px solid #ddd;background:#f6f6f6;white-space:nowrap">' . esc_html( $d['label'] ) . '</th><td style="border:1px solid #ddd">' . ( '' !== (string) $d['value'] ? nl2br( esc_html( $d['value'] ) ) : '<span style="color:#999">–</span>' ) . '</td></tr>';
	}
	return $h . '</table>';
}
// Wzór (tekst ze znacznikami) → HTML maila; wartości od klienta zawsze escapowane.
function rzd_kf_render_template( $tpl, $vars, $disp ) {
	$parts = explode( '{wszystkie_pola}', (string) $tpl );
	$out   = array();
	foreach ( $parts as $p ) {
		$out[] = nl2br( esc_html( strtr( $p, $vars ) ) );
	}
	return '<div style="font-family:Arial,sans-serif;font-size:15px;line-height:1.5">' . implode( rzd_kf_table_html( $disp ), $out ) . '</div>';
}
function rzd_kf_subject( $tpl, $vars ) {
	return rzd_kf_cut( trim( preg_replace( '/[\r\n\t]+/', ' ', strtr( str_replace( '{wszystkie_pola}', '', (string) $tpl ), $vars ) ) ), 200 );
}
function rzd_kf_header_name( $s ) {
	return trim( str_replace( array( "\r", "\n", '"', '<', '>', ',' ), ' ', (string) $s ) );
}
// Maile do wysłania: [ [to, subject, body, headers], … ] – osobno, żeby dało się sprawdzić bez wysyłania.
function rzd_kf_mail_args( $form, $disp, $values, $page ) {
	$vars  = rzd_kf_vars( $form, $disp, $page );
	$to    = '' !== $form['to'] ? array_map( 'trim', explode( ',', $form['to'] ) ) : array( get_option( 'admin_email' ) );
	$email = rzd_kf_reply_email( $form, $values );
	$who   = rzd_kf_header_name( rzd_kf_sender_name( $form, $values ) );
	$h     = array( 'Content-Type: text/html; charset=UTF-8' );
	if ( $email ) {
		$h[] = 'Reply-To: ' . ( '' !== $who ? '"' . $who . '" ' : '' ) . '<' . $email . '>';
	}
	$out = array( array( $to, rzd_kf_subject( $form['subject'], $vars ), rzd_kf_render_template( $form['body'], $vars, $disp ), $h ) );
	if ( ! empty( $form['autoreply'] ) && $email ) {
		$out[] = array( $email, rzd_kf_subject( $form['ar_subject'], $vars ), rzd_kf_render_template( $form['ar_body'], $vars, $disp ), array( 'Content-Type: text/html; charset=UTF-8', 'Reply-To: <' . $to[0] . '>' ) );
	}
	return $out;
}
function rzd_kf_send_mails( $form, $disp, $values, $page ) {
	$ok = false;
	foreach ( rzd_kf_mail_args( $form, $disp, $values, $page ) as $i => $m ) {
		$r = wp_mail( $m[0], $m[1], $m[2], $m[3] );
		if ( 0 === $i ) {
			$ok = $r;
		}
	}
	if ( ! $ok ) {
		rzd_log( 'error', 'Formularz kontaktowy „' . $form['title'] . '”: mail do restauracji nie wyszedł – wiadomość jest w Panelu restauracji → Wiadomości.', 'restauracja-kontakt' );
	}
	return $ok;
}

/* ============================================================
 * 7. RODO: eksport i usuwanie danych (Narzędzia → Eksportuj / Usuń dane osobowe)
 * ============================================================ */
function rzd_kf_posts_by_email( $email, $page = 1 ) {
	return get_posts( array( 'post_type' => 'rzd_kf_msg', 'post_status' => 'any', 'numberposts' => 50, 'paged' => $page, 'meta_key' => '_rzd_kf_email', 'meta_value' => $email ) ); // phpcs:ignore
}
add_filter( 'wp_privacy_personal_data_exporters', function ( $ex ) {
	$ex['rzd-kontakt'] = array(
		'exporter_friendly_name' => 'Formularze kontaktowe (Restauracja)',
		'callback'               => function ( $email, $page = 1 ) {
			$items = array();
			$posts = rzd_kf_posts_by_email( $email, $page );
			foreach ( $posts as $p ) {
				$data = array( array( 'name' => 'Formularz', 'value' => get_post_meta( $p->ID, '_rzd_kf_form_title', true ) ), array( 'name' => 'Data', 'value' => get_the_date( 'j.m.Y H:i', $p ) ) );
				foreach ( (array) get_post_meta( $p->ID, '_rzd_kf_fields', true ) as $d ) {
					$data[] = array( 'name' => $d['label'], 'value' => (string) $d['value'] );
				}
				$items[] = array( 'group_id' => 'rzd-kontakt', 'group_label' => 'Wiadomości z formularzy kontaktowych', 'item_id' => 'rzd-kf-' . $p->ID, 'data' => $data );
			}
			return array( 'data' => $items, 'done' => count( $posts ) < 50 );
		},
	);
	return $ex;
} );
add_filter( 'wp_privacy_personal_data_erasers', function ( $er ) {
	$er['rzd-kontakt'] = array(
		'eraser_friendly_name' => 'Formularze kontaktowe (Restauracja)',
		'callback'             => function ( $email ) {
			$posts = rzd_kf_posts_by_email( $email );
			foreach ( $posts as $p ) {
				wp_delete_post( $p->ID, true );
			}
			rzd_kf_recount();
			return array( 'items_removed' => count( $posts ), 'items_retained' => false, 'messages' => array(), 'done' => count( $posts ) < 50 );
		},
	);
	return $er;
} );
