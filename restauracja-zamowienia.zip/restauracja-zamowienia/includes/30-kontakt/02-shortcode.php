<?php
/**
 * Moduł 30 – część 2: shortcode [rzd_kontakt id="kontakt" styl="karta"] – wyświetlenie formularza.
 * Style: klasyczny, karta, minimalny, ciemny (assets/css/rzd-kontakt.css) + dopasowanie z panelu (kolor, tło, rogi,
 * odstępy, etykiety) jako zmienne CSS + własny CSS formularza i wspólny. Wysyłka bez przeładowania (rzd-kontakt.js),
 * a bez JavaScriptu – zwykłe wysłanie formularza (część 3).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_shortcode( 'rzd_kontakt', 'rzd_kf_shortcode' );

/* ============================================================
 * 1. ZASOBY (CSS, JS, captcha) – tylko na stronach z formularzem
 * ============================================================ */
function rzd_kf_register_assets() {
	if ( wp_style_is( 'rzd-kontakt', 'registered' ) ) {
		return;
	}
	wp_register_style( 'rzd-kontakt', RZD_PLUGIN_URL . 'assets/css/rzd-kontakt.css', array(), rzd_asset_ver( 'assets/css/rzd-kontakt.css' ) );
	wp_register_script( 'rzd-kontakt', RZD_PLUGIN_URL . 'assets/js/rzd-kontakt.js', array(), rzd_asset_ver( 'assets/js/rzd-kontakt.js' ), true );
	wp_add_inline_script( 'rzd-kontakt', 'var rzdKf = ' . wp_json_encode( array(
		'ajax'    => admin_url( 'admin-ajax.php' ),
		'sending' => 'Wysyłanie…',
		'error'   => 'Nie udało się wysłać – sprawdź połączenie z internetem i spróbuj ponownie.',
	) ) . ';', 'before' );
	$s = rzd_kf_settings();
	if ( rzd_kf_captcha_on() ) {
		$src = 'turnstile' === $s['captcha'] ? 'https://challenges.cloudflare.com/turnstile/v0/api.js' : 'https://js.hcaptcha.com/1/api.js';
		wp_register_script( 'rzd-kf-captcha', $src, array(), null, true ); // phpcs:ignore -- skrypt dostawcy, bez wersji
	}
}
function rzd_kf_enqueue() {
	rzd_kf_register_assets();
	wp_enqueue_style( 'rzd-kontakt' );
	wp_enqueue_script( 'rzd-kontakt' );
	if ( wp_script_is( 'rzd-kf-captcha', 'registered' ) ) {
		wp_enqueue_script( 'rzd-kf-captcha' );
	}
	$css = rzd_kf_sanitize_css( rzd_kf_settings()['css'] );
	if ( '' !== $css && empty( $GLOBALS['rzd_kf_global_css'] ) ) {
		$GLOBALS['rzd_kf_global_css'] = 1;
		rzd_kf_add_css( 'wspolny', $css );
	}
}
// Arkusz w <head>, gdy shortcode jest w treści strony (bez „mrugnięcia” niestylowanego formularza).
add_action( 'wp_enqueue_scripts', function () {
	$p = get_post();
	if ( is_singular() && $p && has_shortcode( (string) $p->post_content, 'rzd_kontakt' ) ) {
		rzd_kf_enqueue();
	}
} );
// CSS: przed <head> – do arkusza; po (motywy klasyczne renderują treść później) – <style> obok formularza.
function rzd_kf_add_css( $key, $css ) {
	if ( did_action( 'wp_head' ) ) {
		$GLOBALS['rzd_kf_late_css'][ $key ] = $css;
		return;
	}
	wp_add_inline_style( 'rzd-kontakt', $css );
}
function rzd_kf_late_css_html() {
	$out = '';
	foreach ( isset( $GLOBALS['rzd_kf_late_css'] ) ? (array) $GLOBALS['rzd_kf_late_css'] : array() as $k => $css ) {
		$out .= '<style id="rzd-kf-css-' . esc_attr( $k ) . '">' . $css . '</style>'; // CSS oczyszczony (rzd_kf_sanitize_css)
	}
	$GLOBALS['rzd_kf_late_css'] = array();
	return $out;
}

/* ============================================================
 * 2. WYGLĄD: zmienne CSS formularza
 * ============================================================ */
function rzd_kf_contrast( $hex ) {
	$h = ltrim( (string) $hex, '#' );
	if ( 3 === strlen( $h ) ) {
		$h = $h[0] . $h[0] . $h[1] . $h[1] . $h[2] . $h[2];
	}
	if ( 6 !== strlen( $h ) ) {
		return '#ffffff';
	}
	$l = ( 0.299 * hexdec( substr( $h, 0, 2 ) ) + 0.587 * hexdec( substr( $h, 2, 2 ) ) + 0.114 * hexdec( substr( $h, 4, 2 ) ) ) / 255;
	return $l > 0.6 ? '#1d1d1f' : '#ffffff';
}
function rzd_kf_css_vars( $form, $style ) {
	$st   = function_exists( 'rzd_list_style_get' ) ? rzd_list_style_get() : array();
	$get  = function ( $k ) use ( $st ) {
		return isset( $st[ $k ] ) ? (string) $st[ $k ] : '';
	};
	$look = $form['look'];
	$acc  = $look['accent'] ? $look['accent'] : ( sanitize_hex_color( $get( 'button_border_color' ) ) ? sanitize_hex_color( $get( 'button_border_color' ) ) : '#c08a2e' );
	$rad  = '' !== (string) $look['radius'] ? (int) $look['radius'] : max( 0, min( 24, '' !== $get( 'button_radius' ) ? (int) $get( 'button_radius' ) : 8 ) );
	$gap  = array( 'compact' => 10, 'normal' => 16, 'airy' => 24 );
	$v    = array(
		'--rzd-kf-accent'      => $acc,
		'--rzd-kf-accent-text' => rzd_kf_contrast( $acc ),
		'--rzd-kf-radius'      => $rad . 'px',
		'--rzd-kf-gap'         => ( isset( $gap[ $look['spacing'] ] ) ? $gap[ $look['spacing'] ] : 16 ) . 'px',
	);
	if ( $look['bg'] ) {
		$v['--rzd-kf-bg']   = $look['bg'];
		$v['--rzd-kf-text'] = rzd_kf_contrast( $look['bg'] );
	}
	$font = preg_replace( '/[^A-Za-z0-9 \-]/', '', $get( 'body_font' ) );
	if ( $font ) {
		$v['--rzd-kf-font'] = '"' . $font . '",sans-serif';
	}
	$out = '';
	foreach ( $v as $k => $x ) {
		$out .= $k . ':' . $x . ';';
	}
	return $out;
}

/* ============================================================
 * 3. SHORTCODE
 * ============================================================ */
function rzd_kf_shortcode( $atts ) {
	$atts  = shortcode_atts( array( 'id' => '', 'styl' => '' ), $atts, 'rzd_kontakt' );
	$forms = rzd_kf_forms();
	$id    = sanitize_key( $atts['id'] );
	if ( '' === $id && $forms ) {
		$id = (string) key( $forms );
	}
	$form = isset( $forms[ $id ] ) ? $forms[ $id ] : null;
	if ( ! $form ) {
		return rzd_kf_can() ? '<p class="rzd-kf-missing"><strong>Formularz kontaktowy:</strong> nie ma formularza „' . esc_html( $atts['id'] ) . '” (Panel restauracji → Formularze). Ten komunikat widzą tylko osoby z dostępem do formularzy.</p>' : '';
	}
	$style = sanitize_key( $atts['styl'] );
	if ( ! isset( rzd_kf_styles()[ $style ] ) ) {
		$style = $form['style'];
	}
	rzd_kf_enqueue();
	return rzd_kf_render( $form, $style );
}

function rzd_kf_shop_name() {
	return wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
}
function rzd_kf_privacy_html( $text ) {
	$text = str_replace( '{sklep}', rzd_kf_shop_name(), (string) $text );
	$html = nl2br( esc_html( $text ) );
	$lp   = function_exists( 'rzd_co_legal_pages' ) ? rzd_co_legal_pages() : array( 'privacy' => (int) get_option( 'wp_page_for_privacy_policy' ) );
	$link = ! empty( $lp['privacy'] ) ? '<a href="' . esc_url( get_permalink( $lp['privacy'] ) ) . '" target="_blank" rel="noopener">polityka prywatności</a>' : 'polityka prywatności';
	return str_replace( '[privacy_policy]', $link, $html );
}

// Podpisany znacznik czasu wyświetlenia (antyspam: zbyt szybkie wysłanie = robot). Działa z pamięcią podręczną stron.
function rzd_kf_token( $form_id ) {
	$t = time();
	return $t . '.' . substr( hash_hmac( 'sha256', $t . '|' . $form_id, wp_salt( 'nonce' ) ), 0, 24 );
}

/**
 * HTML formularza. $state (wysłanie bez JavaScriptu): values, errors, ok.
 * $preview – podgląd w panelu (bez wysyłki).
 */
function rzd_kf_render( $form, $style, $state = null, $preview = false ) {
	static $n = 0;
	++$n;
	$id     = $form['id'];
	$uid    = 'rzd-kf-' . $id . '-' . $n;
	$styles = rzd_kf_styles();
	$labels = '' !== $form['look']['labels'] ? $form['look']['labels'] : $styles[ $style ]['labels'];
	if ( null === $state ) {
		$state = isset( $GLOBALS['rzd_kf_state'][ $id ] ) ? $GLOBALS['rzd_kf_state'][ $id ] : array();
		if ( ! $state && isset( $_GET['rzd_kf_ok'] ) && $id === sanitize_key( wp_unslash( $_GET['rzd_kf_ok'] ) ) ) { // phpcs:ignore -- tylko komunikat
			$state = array( 'ok' => true );
		}
	}
	$state  = wp_parse_args( $state, array( 'values' => array(), 'errors' => array(), 'ok' => false, 'msg' => '' ) );
	$errors = $state['errors'];
	$vals   = $state['values'];

	$css = '';
	if ( '' !== trim( $form['css'] ) && ( $preview || empty( $GLOBALS['rzd_kf_form_css'][ $id ] ) ) ) {
		$GLOBALS['rzd_kf_form_css'][ $id ] = 1;
		if ( $preview ) {
			$css = '<style>' . rzd_kf_sanitize_css( $form['css'] ) . '</style>';
		} else {
			rzd_kf_add_css( 'f-' . $id, rzd_kf_sanitize_css( $form['css'] ) );
		}
	}
	$cls = 'rzd-kf rzd-kf--' . $style . ' rzd-kf--labels-' . $labels . ' rzd-kf-id-' . $id . ( $preview ? ' rzd-kf--preview' : '' );
	ob_start();
	echo rzd_kf_late_css_html() . $css; // phpcs:ignore -- CSS oczyszczony
	?>
	<div class="<?php echo esc_attr( $cls ); ?>" id="<?php echo esc_attr( 'rzd-kf-' . $id ); ?>" style="<?php echo esc_attr( rzd_kf_css_vars( $form, $style ) ); ?>" data-rzd-kf="<?php echo esc_attr( $id ); ?>">
		<?php if ( $state['ok'] ) : ?>
			<div class="rzd-kf-success" role="status" tabindex="-1"><?php echo nl2br( esc_html( $form['success'] ) ); // phpcs:ignore ?></div>
		<?php else : ?>
		<form class="rzd-kf-form" method="post" action="<?php echo esc_url( '#rzd-kf-' . $id ); ?>" novalidate<?php echo $preview ? ' onsubmit="return false"' : ''; ?>>
			<input type="hidden" name="rzd_kf_form" value="<?php echo esc_attr( $id ); ?>">
			<input type="hidden" name="rzd_kf_t" value="<?php echo esc_attr( rzd_kf_token( $id ) ); ?>">
			<input type="hidden" name="rzd_kf_page" value="<?php echo esc_attr( $preview ? '' : (string) get_queried_object_id() ); ?>">
			<div class="rzd-kf-hp" aria-hidden="true"><label>Zostaw to pole puste <input type="text" name="rzd_kf_www" value="" tabindex="-1" autocomplete="off"></label></div>
			<div class="rzd-kf-alert" role="alert"<?php echo $errors ? '' : ' hidden'; ?>><?php echo $errors ? esc_html( isset( $errors['_form'] ) ? $errors['_form'] : 'Popraw zaznaczone pola.' ) : ''; ?></div>
			<div class="rzd-kf-grid">
				<?php foreach ( $form['fields'] as $f ) : ?>
					<?php echo rzd_kf_field_html( $f, $uid, isset( $vals[ $f['key'] ] ) ? $vals[ $f['key'] ] : null, isset( $errors[ $f['key'] ] ) ? $errors[ $f['key'] ] : '', $labels ); // phpcs:ignore -- budowane z esc_* ?>
				<?php endforeach; ?>
			</div>
			<?php if ( '' !== trim( $form['privacy'] ) ) : ?>
				<p class="rzd-kf-privacy"><?php echo rzd_kf_privacy_html( $form['privacy'] ); // phpcs:ignore -- esc_html + link ?></p>
			<?php endif; ?>
			<?php if ( ! $preview && rzd_kf_captcha_on() ) : $s = rzd_kf_settings(); ?>
				<div class="rzd-kf-captcha <?php echo 'turnstile' === $s['captcha'] ? 'cf-turnstile' : 'h-captcha'; ?>" data-sitekey="<?php echo esc_attr( $s['site_key'] ); ?>"<?php echo 'ciemny' === $style ? ' data-theme="dark"' : ''; ?>></div>
			<?php endif; ?>
			<div class="rzd-kf-actions"><button type="submit" class="rzd-kf-btn"><?php echo esc_html( $form['button'] ); ?></button></div>
		</form>
		<?php endif; ?>
	</div>
	<?php
	return ob_get_clean();
}

function rzd_kf_autocomplete( $f ) {
	$map = array( 'email' => 'email', 'tel' => 'tel' );
	if ( isset( $map[ $f['type'] ] ) ) {
		return $map[ $f['type'] ];
	}
	if ( 'text' === $f['type'] && preg_match( '/imie|nazwisk|name/', $f['key'] ) ) {
		return 'name';
	}
	return 'text' === $f['type'] || 'textarea' === $f['type'] ? 'off' : '';
}

function rzd_kf_field_html( $f, $uid, $val, $err, $labels ) {
	$type = $f['type'];
	$fid  = $uid . '-' . $f['key'];
	$name = 'f[' . $f['key'] . ']';
	$req  = ! empty( $f['required'] );
	$mark = $req ? ' <span class="rzd-kf-req" aria-hidden="true">*</span>' : '';
	$desc = array();
	if ( '' !== $f['help'] ) {
		$desc[] = $fid . '-help';
	}
	if ( '' !== $err ) {
		$desc[] = $fid . '-err';
	}
	$aria = ( $desc ? ' aria-describedby="' . esc_attr( implode( ' ', $desc ) ) . '"' : '' ) . ( '' !== $err ? ' aria-invalid="true"' : '' ) . ( $req ? ' required aria-required="true"' : '' );
	$help = '' !== $f['help'] ? '<p class="rzd-kf-help" id="' . esc_attr( $fid . '-help' ) . '">' . nl2br( esc_html( $f['help'] ) ) . '</p>' : '';
	$erro = '<p class="rzd-kf-err" id="' . esc_attr( $fid . '-err' ) . '"' . ( '' === $err ? ' hidden' : '' ) . '>' . esc_html( $err ) . '</p>';
	$cls  = 'rzd-kf-field rzd-kf-field--' . $type . ' rzd-kf-w-' . $f['width'] . ( '' !== $err ? ' rzd-kf-has-err' : '' );
	$data = ' data-key="' . esc_attr( $f['key'] ) . '"';

	if ( 'heading' === $type ) {
		return '<div class="rzd-kf-field rzd-kf-field--heading rzd-kf-w-full"><h3 class="rzd-kf-h">' . esc_html( $f['label'] ) . '</h3>' . ( '' !== $f['help'] ? '<p class="rzd-kf-help">' . nl2br( esc_html( $f['help'] ) ) . '</p>' : '' ) . '</div>';
	}
	if ( 'consent' === $type ) {
		$label = wp_kses( $f['label'], array( 'a' => array( 'href' => true, 'target' => true, 'rel' => true ), 'strong' => array(), 'em' => array() ) );
		return '<div class="' . esc_attr( $cls ) . '"' . $data . '><label class="rzd-kf-check"><input type="checkbox" class="rzd-kf-box" id="' . esc_attr( $fid ) . '" name="' . esc_attr( $name ) . '" value="1"' . ( $val ? ' checked' : '' ) . $aria . '> <span>' . $label . $mark . '</span></label>' . $help . $erro . '</div>';
	}
	if ( 'radio' === $type || 'checkbox' === $type ) {
		$sel = (array) $val;
		$h   = '<fieldset class="' . esc_attr( $cls ) . '"' . $data . ( $desc ? ' aria-describedby="' . esc_attr( implode( ' ', $desc ) ) . '"' : '' ) . '><legend class="rzd-kf-label">' . esc_html( $f['label'] ) . $mark . '</legend><div class="rzd-kf-opts">';
		foreach ( $f['options'] as $i => $o ) {
			$h .= '<label class="rzd-kf-check"><input type="' . $type . '" class="rzd-kf-box" name="' . esc_attr( $name . ( 'checkbox' === $type ? '[]' : '' ) ) . '" value="' . esc_attr( $o ) . '"' . ( in_array( $o, $sel, true ) ? ' checked' : '' ) . ( 'radio' === $type && $req && 0 === $i ? ' required' : '' ) . '> <span>' . esc_html( $o ) . '</span></label>';
		}
		return $h . '</div>' . $help . $erro . '</fieldset>';
	}
	$val   = is_scalar( $val ) ? (string) $val : '';
	$fixed = in_array( $type, array( 'select', 'date', 'time' ), true ) ? ' rzd-kf-fixed' : '';
	$ph    = 'inside' === $labels ? ( '' !== $f['placeholder'] ? $f['placeholder'] : ' ' ) : $f['placeholder'];
	$ac    = rzd_kf_autocomplete( $f );
	$attrs = ' class="rzd-kf-input" id="' . esc_attr( $fid ) . '" name="' . esc_attr( $name ) . '"' . ( '' !== $ac ? ' autocomplete="' . esc_attr( $ac ) . '"' : '' ) . $aria;
	if ( 'select' === $type ) {
		$ctl = '<select' . $attrs . '><option value="">' . esc_html( '' !== $f['placeholder'] ? $f['placeholder'] : '– wybierz –' ) . '</option>';
		foreach ( $f['options'] as $o ) {
			$ctl .= '<option value="' . esc_attr( $o ) . '"' . selected( $val, $o, false ) . '>' . esc_html( $o ) . '</option>';
		}
		$ctl .= '</select>';
	} elseif ( 'textarea' === $type ) {
		$ctl = '<textarea rows="5" maxlength="5000"' . $attrs . ' placeholder="' . esc_attr( $ph ) . '">' . esc_textarea( $val ) . '</textarea>';
	} else {
		$extra = '';
		if ( 'number' === $type ) {
			$extra .= ' step="any" inputmode="decimal"' . ( '' !== $f['min'] ? ' min="' . esc_attr( $f['min'] ) . '"' : '' ) . ( '' !== $f['max'] ? ' max="' . esc_attr( $f['max'] ) . '"' : '' );
		} elseif ( 'date' === $type && ! empty( $f['future'] ) ) {
			$extra .= ' min="' . esc_attr( wp_date( 'Y-m-d' ) ) . '"';
		} elseif ( 'text' === $type || 'tel' === $type ) {
			$extra .= ' maxlength="200"';
		}
		$ctl = '<input type="' . esc_attr( $type ) . '"' . $attrs . ' value="' . esc_attr( $val ) . '" placeholder="' . esc_attr( 'date' === $type || 'time' === $type ? '' : $ph ) . '"' . $extra . '>';
	}
	return '<div class="' . esc_attr( $cls . $fixed . ' rzd-kf-fl' ) . '"' . $data . '><label class="rzd-kf-label" for="' . esc_attr( $fid ) . '">' . esc_html( $f['label'] ) . $mark . '</label>' . $ctl . $help . $erro . '</div>';
}
