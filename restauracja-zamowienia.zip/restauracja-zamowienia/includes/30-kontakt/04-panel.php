<?php
/**
 * Moduł 30 – część 4: zapis formularzy i wiadomości (ekrany: Panel restauracji, moduł 34).
 * - Panel → Formularze: lista (shortcode do skopiowania), kreator (pola, wygląd, własny CSS, maile, podgląd na żywo),
 *   wspólny CSS; ochrona przed spamem i czas przechowywania – tylko Administrator (2.45.0; wcześniej kokpit);
 * - Panel → Wiadomości: lista z filtrami, podgląd, statusy (nowa / przeczytana / odpowiedziana), eksport CSV.
 * Dostęp: uprawnienie „Formularze kontaktowe” (rzd_p_forms) albo Administrator.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function rzd_kf_cap() {
	return current_user_can( 'manage_options' ) ? 'manage_options' : 'rzd_p_forms';
}
function rzd_kf_guard( $nonce ) {
	if ( ! rzd_kf_can() ) {
		wp_die( 'Brak uprawnień.' );
	}
	check_admin_referer( $nonce );
}
/* ============================================================
 * 1. FORMULARZE: nowy, zapis, usunięcie (Panel restauracji → Formularze, moduł 34)
 * ============================================================ */
function rzd_kf_unique_id( $title ) {
	$base = rzd_kf_slug( $title, '-' );
	$base = '' !== $base ? substr( $base, 0, 30 ) : 'formularz';
	$id   = $base;
	$f    = rzd_kf_forms();
	for ( $i = 2; isset( $f[ $id ] ); $i++ ) {
		$id = $base . '-' . $i;
	}
	return $id;
}

/** Nowy formularz: $from = id istniejącego (kopia) | starter_kontakt | starter_catering | blank. Zwraca id. */
function rzd_kf_form_new( $from ) {
	$from    = sanitize_key( (string) $from );
	$forms   = rzd_kf_forms();
	$starter = rzd_kf_starter_forms();
	if ( isset( $forms[ $from ] ) ) {
		$f          = $forms[ $from ];
		$f['title'] = $f['title'] . ' (kopia)';
	} elseif ( 0 === strpos( $from, 'starter_' ) && isset( $starter[ substr( $from, 8 ) ] ) ) {
		$f = $starter[ substr( $from, 8 ) ];
	} else {
		$f = array_merge( rzd_kf_form_defaults(), array(
			'title'    => 'Nowy formularz',
			'fields'   => array( rzd_kf_field( 'imie', 'Imię', 'text', array( 'required' => 1 ) ), rzd_kf_field( 'email', 'E-mail', 'email', array( 'required' => 1 ) ), rzd_kf_field( 'wiadomosc', 'Wiadomość', 'textarea', array( 'required' => 1 ) ) ),
			'reply_to' => 'email',
		) );
	}
	$id           = rzd_kf_unique_id( $f['title'] );
	$f['id']      = $id;
	$forms[ $id ] = $f;
	rzd_kf_save_forms( $forms );
	return $id;
}

/** Zapis formularza z kreatora ($in: title, fields[], look{}, maile…). Formularz albo WP_Error. */
function rzd_kf_form_save( $id, $in ) {
	$forms = rzd_kf_forms();
	if ( ! isset( $forms[ $id ] ) ) {
		return new WP_Error( 'rzd_kf', 'Nie ma takiego formularza.' );
	}
	$f = rzd_kf_sanitize_form( is_array( $in ) ? $in : array(), $id );
	if ( is_wp_error( $f ) ) {
		return $f;
	}
	$forms[ $id ] = $f;
	rzd_kf_save_forms( $forms );
	return $f;
}

/** Usunięcie – wiadomości z formularza zostają; zwraca nazwę albo ''. */
function rzd_kf_form_delete( $id ) {
	$forms = rzd_kf_forms();
	if ( ! isset( $forms[ $id ] ) ) {
		return '';
	}
	$t = $forms[ $id ]['title'];
	unset( $forms[ $id ] );
	rzd_kf_save_forms( $forms );
	return $t;
}

/** Wspólny CSS wszystkich formularzy. */
function rzd_kf_css_save( $css ) {
	$s        = get_option( 'rzd_kf_settings', array() );
	$s        = is_array( $s ) ? $s : array();
	$s['css'] = rzd_kf_sanitize_css( $css );
	update_option( 'rzd_kf_settings', $s, false );
	return $s['css'];
}

/**
 * Ochrona przed spamem i przechowywanie – TYLKO Administrator (sprawdza wywołujący).
 * $p: rate, keep, captcha, site_key, secret (puste = bez zmiany), secret_clear.
 */
function rzd_kf_settings_save( $p ) {
	$p   = is_array( $p ) ? $p : array();
	$old = rzd_kf_settings();
	$s   = get_option( 'rzd_kf_settings', array() );
	$s   = is_array( $s ) ? $s : array();
	$s['rate']     = max( 0, min( 100, absint( isset( $p['rate'] ) ? $p['rate'] : 5 ) ) );
	$s['keep']     = max( 0, min( 120, absint( isset( $p['keep'] ) ? $p['keep'] : 12 ) ) );
	$s['captcha']  = isset( $p['captcha'] ) && in_array( $p['captcha'], array( 'turnstile', 'hcaptcha' ), true ) ? $p['captcha'] : '';
	$s['site_key'] = sanitize_text_field( isset( $p['site_key'] ) ? (string) $p['site_key'] : '' );
	$s['secret']   = $old['captcha'] === $s['captcha'] ? $old['secret'] : '';
	if ( ! empty( $p['secret_clear'] ) ) {
		$s['secret'] = '';
	} elseif ( isset( $p['secret'] ) && '' !== trim( (string) $p['secret'] ) ) {
		$s['secret'] = rzd_mail_encrypt( trim( (string) $p['secret'] ) );
	}
	update_option( 'rzd_kf_settings', $s, false );
	return rzd_kf_settings();
}

/**
 * Podgląd formularza (także niezapisanego) – osobny dokument do <iframe>: arkusz formularzy, wspólny CSS,
 * własny CSS formularza. Bez skryptu wysyłki (przycisk nic nie robi).
 */
function rzd_kf_preview_doc( $form ) {
	$css  = rzd_kf_sanitize_css( rzd_kf_settings()['css'] );
	$href = RZD_PLUGIN_URL . 'assets/css/rzd-kontakt.css?v=' . rawurlencode( rzd_asset_ver( 'assets/css/rzd-kontakt.css' ) );
	$font = function_exists( 'rzd_fonts_href' ) ? '<link rel="stylesheet" href="' . esc_url( rzd_fonts_href() ) . '">' : '';
	$dark = 'ciemny' === $form['style'] ? 'background:#2A2522;' : '';
	return '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">' . $font
		. '<link rel="stylesheet" href="' . esc_url( $href ) . '">'
		. ( '' !== $css ? '<style>' . $css . '</style>' : '' )
		. '<style>body{margin:0;padding:18px;font-family:Lato,sans-serif;' . $dark . '}</style></head><body>'
		. rzd_kf_render( $form, $form['style'], array(), true ) . '</body></html>';
}

/* ============================================================
 * 4. WIADOMOŚCI
 * ============================================================ */
function rzd_kf_counts_by_form() {
	global $wpdb;
	$rows = $wpdb->get_results( "SELECT pm.meta_value AS f, COUNT(*) AS n FROM {$wpdb->postmeta} pm JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE p.post_type = 'rzd_kf_msg' AND pm.meta_key = '_rzd_kf_form' GROUP BY pm.meta_value" ); // phpcs:ignore
	$out  = array();
	foreach ( (array) $rows as $r ) {
		$out[ $r->f ] = (int) $r->n;
	}
	return $out;
}
function rzd_kf_statuses() {
	return array( 'new' => 'nowa', 'read' => 'przeczytana', 'answered' => 'odpowiedziana' );
}
function rzd_kf_set_status( $ids, $status ) {
	if ( ! isset( rzd_kf_statuses()[ $status ] ) ) {
		return;
	}
	foreach ( (array) $ids as $id ) {
		if ( 'rzd_kf_msg' === get_post_type( $id ) ) {
			update_post_meta( $id, '_rzd_kf_status', $status );
		}
	}
	rzd_kf_recount();
}
function rzd_kf_query_args( $req ) {
	$a    = array( 'post_type' => 'rzd_kf_msg', 'post_status' => 'publish', 'orderby' => 'date', 'order' => 'DESC' );
	$meta = array();
	if ( ! empty( $req['form'] ) ) {
		$meta[] = array( 'key' => '_rzd_kf_form', 'value' => sanitize_key( $req['form'] ) );
	}
	if ( ! empty( $req['status'] ) && isset( rzd_kf_statuses()[ $req['status'] ] ) ) {
		$meta[] = array( 'key' => '_rzd_kf_status', 'value' => $req['status'] );
	}
	if ( $meta ) {
		$a['meta_query'] = $meta; // phpcs:ignore
	}
	if ( ! empty( $req['s'] ) ) {
		$a['rzd_kf_search'] = sanitize_text_field( $req['s'] );
	}
	return $a;
}
// Szukanie także w treści pól (meta _rzd_kf_fields), nie tylko w tytule.
add_filter( 'posts_where', function ( $where, $q ) {
	$s = $q->get( 'rzd_kf_search' );
	if ( $s ) {
		global $wpdb;
		$like   = '%' . $wpdb->esc_like( $s ) . '%';
		$where .= $wpdb->prepare( " AND ( {$wpdb->posts}.post_title LIKE %s OR EXISTS ( SELECT 1 FROM {$wpdb->postmeta} m WHERE m.post_id = {$wpdb->posts}.ID AND m.meta_key IN ('_rzd_kf_fields','_rzd_kf_email') AND m.meta_value LIKE %s ) )", $like, $like ); // phpcs:ignore
	}
	return $where;
}, 10, 2 );

// Eksport CSV (jak raporty: ochrona przed formułami w Excelu).
add_action( 'admin_post_rzd_kf_csv', function () {
	rzd_kf_guard( 'rzd_kf_csv' );
	$req   = wp_unslash( $_GET ); // phpcs:ignore -- czyszczone w rzd_kf_query_args
	$a     = rzd_kf_query_args( $req );
	$a['posts_per_page'] = 5000;
	$posts = get_posts( $a + array( 'suppress_filters' => false ) );
	$one   = ! empty( $req['form'] );
	$labels = array();
	foreach ( $posts as $p ) {
		foreach ( (array) get_post_meta( $p->ID, '_rzd_kf_fields', true ) as $d ) {
			$labels[ $d['label'] ] = true;
		}
	}
	$labels = array_keys( $labels );
	$head   = array_merge( array( 'Data', 'Formularz', 'Status' ), $one ? $labels : array( 'Treść' ) );
	$rows   = array();
	$st     = rzd_kf_statuses();
	foreach ( $posts as $p ) {
		$f   = (array) get_post_meta( $p->ID, '_rzd_kf_fields', true );
		$s   = (string) get_post_meta( $p->ID, '_rzd_kf_status', true );
		$row = array( get_the_date( 'Y-m-d H:i', $p ), (string) get_post_meta( $p->ID, '_rzd_kf_form_title', true ), isset( $st[ $s ] ) ? $st[ $s ] : $s );
		if ( $one ) {
			$by = array();
			foreach ( $f as $d ) {
				$by[ $d['label'] ] = $d['value'];
			}
			foreach ( $labels as $l ) {
				$row[] = isset( $by[ $l ] ) ? $by[ $l ] : '';
			}
		} else {
			$row[] = implode( '; ', array_map( function ( $d ) {
				return $d['label'] . ': ' . $d['value'];
			}, $f ) );
		}
		$rows[] = array_map( 'rzd_raport_csv_cell', $row );
	}
	rzd_raport_output_csv( 'wiadomosci-' . wp_date( 'Y-m-d' ) . '.csv', $head, $rows );
	exit;
} );

/**
 * Wiadomość do Panelu restauracji (moduł 34). $full = false – skrót do listy.
 * Telefon i dłuższa treść wyciągane z pól (etykiety z chwili wysłania).
 */
function rzd_kf_msg_data( $p, $full = false ) {
	$s     = (string) get_post_meta( $p->ID, '_rzd_kf_status', true );
	$f     = (array) get_post_meta( $p->ID, '_rzd_kf_fields', true );
	$tel   = '';
	$long  = '';
	foreach ( $f as $d ) {
		if ( 'tel' === $d['type'] && '' === $tel ) {
			$tel = (string) $d['value'];
		}
		if ( 'textarea' === $d['type'] && '' === $long ) {
			$long = (string) $d['value'];
		}
	}
	if ( '' === $long ) {
		$long = implode( ' · ', array_filter( array_map( function ( $d ) {
			return in_array( $d['type'], array( 'email', 'tel', 'consent' ), true ) || '' === (string) $d['value'] ? '' : $d['label'] . ': ' . $d['value'];
		}, $f ) ) );
	}
	$out = array(
		'id'     => (int) $p->ID,
		'date'   => get_the_date( 'j.m.Y H:i', $p ),
		'form'   => (string) get_post_meta( $p->ID, '_rzd_kf_form_title', true ),
		'formId' => (string) get_post_meta( $p->ID, '_rzd_kf_form', true ),
		'name'   => (string) get_post_meta( $p->ID, '_rzd_kf_name', true ),
		'email'  => (string) get_post_meta( $p->ID, '_rzd_kf_email', true ),
		'tel'    => $tel,
		'short'  => wp_trim_words( $long, 18, '…' ),
		'status' => $s,
		'fail'   => 'fail' === get_post_meta( $p->ID, '_rzd_kf_mail', true ),
	);
	if ( $full ) {
		$page          = (int) get_post_meta( $p->ID, '_rzd_kf_page', true );
		$out['fields'] = array_values( array_map( function ( $d ) {
			return array( 'label' => (string) $d['label'], 'type' => (string) $d['type'], 'value' => (string) $d['value'] );
		}, $f ) );
		$out['page']   = $page ? array( 'title' => get_the_title( $page ), 'url' => get_permalink( $page ) ) : null;
	}
	return $out;
}
