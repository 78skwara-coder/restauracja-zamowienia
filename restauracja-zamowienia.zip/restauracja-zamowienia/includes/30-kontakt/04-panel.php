<?php
/**
 * Moduł 30 – część 4: panel.
 * - Restauracja → Formularze kontaktowe: lista formularzy (shortcode do skopiowania), kreator (pola, wygląd, własny CSS,
 *   maile, podgląd na żywo), wspólny CSS; ochrona przed spamem i czas przechowywania – tylko Administrator;
 * - Restauracja → Wiadomości: lista z filtrami, podgląd, statusy (nowa / przeczytana / odpowiedziana), eksport CSV.
 * Dostęp: uprawnienie „Formularze kontaktowe” (rzd_p_forms) albo Administrator.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function rzd_kf_cap() {
	return current_user_can( 'manage_options' ) ? 'manage_options' : 'rzd_p_forms';
}
function rzd_kf_guard( $nonce ) {
	if ( ! rzd_kf_can() ) {
		wp_die( 'Brak uprawnień.' );
	}
	check_admin_referer( $nonce );
}
function rzd_kf_back( $args = array(), $page = 'rzd-formularze' ) {
	wp_safe_redirect( add_query_arg( $args, admin_url( 'admin.php?page=' . $page ) ) );
	exit;
}
function rzd_kf_msg_flash( $text, $type = 'success' ) {
	set_transient( 'rzd_kf_flash_' . get_current_user_id(), array( 'text' => $text, 'type' => $type ), 120 );
}
function rzd_kf_flash_html() {
	$f = get_transient( 'rzd_kf_flash_' . get_current_user_id() );
	if ( ! $f ) {
		return '';
	}
	delete_transient( 'rzd_kf_flash_' . get_current_user_id() );
	return '<div class="notice notice-' . esc_attr( $f['type'] ) . ' is-dismissible"><p>' . esc_html( $f['text'] ) . '</p></div>';
}

/* ============================================================
 * 1. ZASOBY PANELU
 * ============================================================ */
add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( ! rzd_is_admin_page( $hook, 'rzd-formularze' ) ) {
		return;
	}
	rzd_kf_register_assets();
	wp_enqueue_style( 'rzd-kontakt' );
	wp_enqueue_script( 'rzd-kontakt' );
	wp_enqueue_script( 'jquery-ui-sortable' );
	wp_enqueue_script( 'rzd-kontakt-admin', RZD_PLUGIN_URL . 'assets/js/admin/rzd-kontakt-admin.js', array( 'jquery', 'jquery-ui-sortable' ), rzd_asset_ver( 'assets/js/admin/rzd-kontakt-admin.js' ), true );
	wp_add_inline_script( 'rzd-kontakt-admin', 'var rzdKfAdmin = ' . wp_json_encode( array(
		'ajax'    => admin_url( 'admin-ajax.php' ),
		'nonce'   => wp_create_nonce( 'rzd_kf_preview' ),
		'types'   => rzd_kf_field_types(),
		'options' => array( 'select', 'radio', 'checkbox' ),
	) ) . ';', 'before' );
	$css = rzd_kf_sanitize_css( rzd_kf_settings()['css'] );
	if ( '' !== $css ) {
		wp_add_inline_style( 'rzd-kontakt', $css );
	}
} );

/* ============================================================
 * 2. AKCJE: formularze
 * ============================================================ */
function rzd_kf_unique_id( $title ) {
	$base = rzd_kf_slug( $title, '-' );
	$base = '' !== $base ? substr( $base, 0, 30 ) : 'formularz';
	$id   = $base;
	$f    = rzd_kf_forms();
	for ( $i = 2; isset( $f[ $id ] ); $i++ ) {
		$id = $base . '-' . $i;
	}
	return $id;
}

// Formularz z panelu (pola formularza edytora) → tablica do rzd_kf_sanitize_form.
function rzd_kf_input_from_post( $p ) {
	$in           = array_intersect_key( $p, array_flip( array( 'title', 'to', 'subject', 'body', 'reply_to', 'autoreply', 'ar_subject', 'ar_body', 'success', 'redirect', 'button', 'privacy', 'style', 'look', 'css' ) ) );
	$fields       = json_decode( isset( $p['fields_json'] ) ? (string) $p['fields_json'] : '[]', true );
	$in['fields'] = is_array( $fields ) ? $fields : array();
	return $in;
}

add_action( 'admin_post_rzd_kf_save', function () {
	rzd_kf_guard( 'rzd_kf_save' );
	$p     = wp_unslash( $_POST ); // phpcs:ignore -- czyszczone w rzd_kf_sanitize_form
	$id    = isset( $p['id'] ) ? sanitize_key( $p['id'] ) : '';
	$forms = rzd_kf_forms();
	if ( ! isset( $forms[ $id ] ) ) {
		rzd_kf_msg_flash( 'Nie ma takiego formularza.', 'error' );
		rzd_kf_back();
	}
	$f = rzd_kf_sanitize_form( rzd_kf_input_from_post( $p ), $id );
	if ( is_wp_error( $f ) ) {
		set_transient( 'rzd_kf_draft_' . get_current_user_id(), array( 'id' => $id, 'input' => rzd_kf_input_from_post( $p ) ), 600 );
		rzd_kf_msg_flash( 'Nie zapisano: ' . $f->get_error_message(), 'error' );
		rzd_kf_back( array( 'edit' => $id ) );
	}
	$forms[ $id ] = $f;
	rzd_kf_save_forms( $forms );
	rzd_kf_msg_flash( 'Zapisano formularz „' . $f['title'] . '”.' );
	rzd_kf_back( array( 'edit' => $id ) );
} );

add_action( 'admin_post_rzd_kf_new', function () {
	rzd_kf_guard( 'rzd_kf_new' );
	$from    = isset( $_POST['from'] ) ? sanitize_key( wp_unslash( $_POST['from'] ) ) : 'blank'; // phpcs:ignore
	$forms   = rzd_kf_forms();
	$starter = rzd_kf_starter_forms();
	if ( isset( $forms[ $from ] ) ) {
		$f          = $forms[ $from ];
		$f['title'] = $f['title'] . ' (kopia)';
	} elseif ( 0 === strpos( $from, 'starter_' ) && isset( $starter[ substr( $from, 8 ) ] ) ) {
		$f = $starter[ substr( $from, 8 ) ];
	} else {
		$f = array_merge( rzd_kf_form_defaults(), array(
			'title'  => 'Nowy formularz',
			'fields' => array( rzd_kf_field( 'imie', 'Imię', 'text', array( 'required' => 1 ) ), rzd_kf_field( 'email', 'E-mail', 'email', array( 'required' => 1 ) ), rzd_kf_field( 'wiadomosc', 'Wiadomość', 'textarea', array( 'required' => 1 ) ) ),
			'reply_to' => 'email',
		) );
	}
	$id          = rzd_kf_unique_id( $f['title'] );
	$f['id']     = $id;
	$forms[ $id ] = $f;
	rzd_kf_save_forms( $forms );
	rzd_kf_msg_flash( 'Utworzono formularz „' . $f['title'] . '” – ustaw pola i zapisz.' );
	rzd_kf_back( array( 'edit' => $id ) );
} );

add_action( 'admin_post_rzd_kf_delete', function () {
	rzd_kf_guard( 'rzd_kf_delete' );
	$id    = isset( $_POST['id'] ) ? sanitize_key( wp_unslash( $_POST['id'] ) ) : ''; // phpcs:ignore
	$forms = rzd_kf_forms();
	if ( isset( $forms[ $id ] ) ) {
		$t = $forms[ $id ]['title'];
		unset( $forms[ $id ] );
		rzd_kf_save_forms( $forms );
		rzd_kf_msg_flash( 'Usunięto formularz „' . $t . '”. Wiadomości z niego zostają w Wiadomościach; shortcode z tym formularzem przestaje się wyświetlać.' );
	}
	rzd_kf_back();
} );

add_action( 'admin_post_rzd_kf_css', function () {
	rzd_kf_guard( 'rzd_kf_css' );
	$s        = get_option( 'rzd_kf_settings', array() );
	$s        = is_array( $s ) ? $s : array();
	$s['css'] = rzd_kf_sanitize_css( isset( $_POST['css'] ) ? wp_unslash( $_POST['css'] ) : '' ); // phpcs:ignore -- czyszczone
	update_option( 'rzd_kf_settings', $s, false );
	rzd_kf_msg_flash( 'Zapisano wspólny CSS formularzy.' );
	rzd_kf_back( array(), 'rzd-formularze#rzd-kf-css' );
} );

add_action( 'admin_post_rzd_kf_settings', function () {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Brak uprawnień.' );
	}
	check_admin_referer( 'rzd_kf_settings' );
	$p   = wp_unslash( $_POST ); // phpcs:ignore -- pola czyszczone niżej
	$old = rzd_kf_settings();
	$s   = get_option( 'rzd_kf_settings', array() );
	$s   = is_array( $s ) ? $s : array();
	$s['rate']     = max( 0, min( 100, absint( isset( $p['rate'] ) ? $p['rate'] : 5 ) ) );
	$s['keep']     = max( 0, min( 120, absint( isset( $p['keep'] ) ? $p['keep'] : 12 ) ) );
	$s['captcha']  = isset( $p['captcha'] ) && in_array( $p['captcha'], array( 'turnstile', 'hcaptcha' ), true ) ? $p['captcha'] : '';
	$s['site_key'] = sanitize_text_field( isset( $p['site_key'] ) ? $p['site_key'] : '' );
	$s['secret']   = $old['captcha'] === $s['captcha'] ? $old['secret'] : '';
	if ( ! empty( $p['secret_clear'] ) ) {
		$s['secret'] = '';
	} elseif ( isset( $p['secret'] ) && '' !== trim( (string) $p['secret'] ) ) {
		$s['secret'] = rzd_mail_encrypt( trim( (string) $p['secret'] ) );
	}
	update_option( 'rzd_kf_settings', $s, false );
	rzd_kf_msg_flash( 'Zapisano ustawienia ochrony i przechowywania.' . ( $s['captcha'] && ! rzd_kf_captcha_on() ? ' Uwaga: captcha nie działa, dopóki nie podasz obu kluczy.' : '' ) );
	rzd_kf_back( array(), 'rzd-formularze#rzd-kf-ochrona' );
} );

// Podgląd na żywo w kreatorze (formularz niezapisany).
add_action( 'wp_ajax_rzd_kf_preview', function () {
	if ( ! rzd_kf_can() || ! check_ajax_referer( 'rzd_kf_preview', '_ajax_nonce', false ) ) {
		wp_send_json_error( array( 'message' => 'Brak uprawnień – odśwież stronę.' ) );
	}
	$p  = wp_unslash( $_POST ); // phpcs:ignore -- czyszczone w rzd_kf_sanitize_form
	$id = isset( $p['id'] ) ? sanitize_key( $p['id'] ) : 'podglad';
	$f  = rzd_kf_sanitize_form( rzd_kf_input_from_post( $p ), $id );
	if ( is_wp_error( $f ) ) {
		wp_send_json_error( array( 'message' => $f->get_error_message() ) );
	}
	wp_send_json_success( array( 'html' => rzd_kf_render( $f, $f['style'], array(), true ) ) );
} );

/* ============================================================
 * 3. STRONA: Formularze kontaktowe
 * ============================================================ */
function rzd_kf_admin_page() {
	if ( ! rzd_kf_can() ) {
		wp_die( 'Brak uprawnień.' );
	}
	$edit = isset( $_GET['edit'] ) ? sanitize_key( wp_unslash( $_GET['edit'] ) ) : ''; // phpcs:ignore -- tylko odczyt
	if ( '' !== $edit && rzd_kf_form( $edit ) ) {
		rzd_kf_editor_page( rzd_kf_form( $edit ) );
		return;
	}
	$forms  = rzd_kf_forms();
	$styles = rzd_kf_styles();
	$counts = rzd_kf_counts_by_form();
	$s      = rzd_kf_settings();
	?>
	<div class="wrap rzd-kf-admin">
		<h1 class="wp-heading-inline">Formularze kontaktowe</h1>
		<?php echo rzd_kf_flash_html(); // phpcs:ignore ?>
		<p style="max-width:900px">Formularz wstawiasz na dowolnej stronie <strong>shortcodem</strong> (krótkim kodem w nawiasach kwadratowych) – w edytorze strony blok „Kod skrócony” albo zwykły tekst. Styl możesz zmienić w kodzie: <code>[rzd_kontakt id="kontakt" styl="karta"]</code> – style: <?php echo esc_html( implode( ', ', array_keys( $styles ) ) ); ?>. Wiadomości trafiają mailem na podany adres i do <a href="<?php echo esc_url( admin_url( 'admin.php?page=rzd-wiadomosci' ) ); ?>">Restauracja → Wiadomości</a>.</p>
		<table class="widefat striped" style="max-width:1100px">
			<thead><tr><th>Formularz</th><th>Shortcode</th><th>Styl</th><th>Pola</th><th>Wiadomości</th><th></th></tr></thead>
			<tbody>
			<?php if ( ! $forms ) : ?>
				<tr><td colspan="6">Nie ma formularzy – dodaj pierwszy poniżej.</td></tr>
			<?php endif; ?>
			<?php foreach ( $forms as $id => $f ) : $sc = '[rzd_kontakt id="' . $id . '"]'; ?>
				<tr>
					<td><strong><a href="<?php echo esc_url( admin_url( 'admin.php?page=rzd-formularze&edit=' . $id ) ); ?>"><?php echo esc_html( $f['title'] ); ?></a></strong></td>
					<td><input type="text" readonly value="<?php echo esc_attr( $sc ); ?>" class="rzd-kf-sc" style="width:260px;font-family:monospace" onfocus="this.select()" aria-label="Shortcode"> <button type="button" class="button button-small rzd-kf-copy" data-copy="<?php echo esc_attr( $sc ); ?>">Kopiuj</button></td>
					<td><?php echo esc_html( $styles[ $f['style'] ]['label'] ); ?></td>
					<td><?php echo (int) count( array_filter( $f['fields'], function ( $x ) { return 'heading' !== $x['type']; } ) ); ?></td>
					<td><a href="<?php echo esc_url( admin_url( 'admin.php?page=rzd-wiadomosci&form=' . $id ) ); ?>"><?php echo (int) ( isset( $counts[ $id ] ) ? $counts[ $id ] : 0 ); ?></a></td>
					<td style="white-space:nowrap">
						<a class="button button-small" href="<?php echo esc_url( admin_url( 'admin.php?page=rzd-formularze&edit=' . $id ) ); ?>">Edytuj</a>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline"><input type="hidden" name="action" value="rzd_kf_new"><input type="hidden" name="from" value="<?php echo esc_attr( $id ); ?>"><?php wp_nonce_field( 'rzd_kf_new' ); ?><button class="button button-small">Duplikuj</button></form>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline" onsubmit="return confirm('Usunąć formularz? Shortcode z nim przestanie się wyświetlać. Wiadomości zostają.');"><input type="hidden" name="action" value="rzd_kf_delete"><input type="hidden" name="id" value="<?php echo esc_attr( $id ); ?>"><?php wp_nonce_field( 'rzd_kf_delete' ); ?><button class="button button-small button-link-delete">Usuń</button></form>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin:14px 0 28px">
			<input type="hidden" name="action" value="rzd_kf_new"><?php wp_nonce_field( 'rzd_kf_new' ); ?>
			<label for="rzd-kf-from"><strong>Nowy formularz:</strong></label>
			<select name="from" id="rzd-kf-from">
				<option value="blank">pusty (imię, e-mail, wiadomość)</option>
				<option value="starter_kontakt">wzór „Kontakt”</option>
				<option value="starter_catering">wzór „Zapytanie o catering / imprezę”</option>
			</select>
			<button class="button button-primary">Dodaj formularz</button>
		</form>

		<h2 id="rzd-kf-css">Wspólny CSS (wszystkie formularze)</h2>
		<p class="description" style="max-width:900px">Własne poprawki wyglądu dla wszystkich formularzy. Klasy: <code>.rzd-kf</code> (cały formularz), <code>.rzd-kf--karta</code> (styl), <code>.rzd-kf-id-kontakt</code> (konkretny formularz), <code>.rzd-kf-input</code>, <code>.rzd-kf-label</code>, <code>.rzd-kf-btn</code>, <code>.rzd-kf-field--email</code> (pole danego typu). Zmienne: <code>--rzd-kf-accent</code>, <code>--rzd-kf-radius</code>, <code>--rzd-kf-gap</code>. Reguła bez klasy formularza (np. <code>body {…}</code>) zmieni całą stronę.</p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="rzd_kf_css"><?php wp_nonce_field( 'rzd_kf_css' ); ?>
			<textarea name="css" rows="7" class="large-text code" spellcheck="false" placeholder=".rzd-kf .rzd-kf-btn { text-transform: uppercase; }" style="max-width:900px"><?php echo esc_textarea( $s['css'] ); ?></textarea>
			<p><button class="button">Zapisz wspólny CSS</button></p>
		</form>

		<?php if ( current_user_can( 'manage_options' ) ) : $sec = '' !== rzd_mail_decrypt( $s['secret'] ); ?>
		<h2 id="rzd-kf-ochrona">Ochrona przed spamem i przechowywanie <span style="font-weight:normal;font-size:13px">(tylko Administrator)</span></h2>
		<p class="description" style="max-width:900px">Zawsze działają: ukryte pole – pułapka na roboty, odrzucanie wysłań szybszych niż <?php echo (int) RZD_KF_MIN_SECONDS; ?> s, sprawdzenie, czy wysłano z tej strony. Zatrzymanych prób spamu: <strong><?php echo (int) $s['spam_count']; ?></strong>.</p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" autocomplete="off">
			<input type="hidden" name="action" value="rzd_kf_settings"><?php wp_nonce_field( 'rzd_kf_settings' ); ?>
			<table class="form-table" role="presentation">
				<tr><th><label for="rzd-kf-rate">Limit wiadomości</label></th><td><input type="number" min="0" max="100" id="rzd-kf-rate" name="rate" value="<?php echo (int) $s['rate']; ?>" style="width:80px"> z jednego adresu IP na godzinę <span class="description">(0 = bez limitu)</span></td></tr>
				<tr><th><label for="rzd-kf-captcha">Sprawdzenie „nie jestem robotem”</label></th><td>
					<select name="captcha" id="rzd-kf-captcha">
						<option value="" <?php selected( $s['captcha'], '' ); ?>>wyłączone (wystarcza przy małym ruchu)</option>
						<option value="turnstile" <?php selected( $s['captcha'], 'turnstile' ); ?>>Cloudflare Turnstile (zwykle niewidoczne, darmowe)</option>
						<option value="hcaptcha" <?php selected( $s['captcha'], 'hcaptcha' ); ?>>hCaptcha (darmowe)</option>
					</select>
					<p class="description">Klucze: Cloudflare → Turnstile → Add site, albo hCaptcha → Sites. Usługa ładuje swój skrypt na stronie formularza – warto wspomnieć o tym w polityce prywatności.</p>
				</td></tr>
				<tr><th><label for="rzd-kf-sk">Klucz witryny (site key)</label></th><td><input type="text" class="regular-text" id="rzd-kf-sk" name="site_key" value="<?php echo esc_attr( $s['site_key'] ); ?>"></td></tr>
				<tr><th><label for="rzd-kf-sec">Klucz tajny (secret)</label></th><td><input type="password" class="regular-text" id="rzd-kf-sec" name="secret" value="" autocomplete="new-password" placeholder="<?php echo $sec ? 'zapisany – wpisz, aby zmienić' : ''; ?>"><?php if ( $sec ) : ?> <label><input type="checkbox" name="secret_clear" value="1"> usuń zapisany</label><?php endif; ?></td></tr>
				<tr><th><label for="rzd-kf-keep">Przechowywanie wiadomości</label></th><td><input type="number" min="0" max="120" id="rzd-kf-keep" name="keep" value="<?php echo (int) $s['keep']; ?>" style="width:80px"> miesięcy, potem usuwane automatycznie <span class="description">(0 = nie usuwaj; RODO: nie dłużej, niż potrzeba)</span></td></tr>
			</table>
			<p><button class="button button-primary">Zapisz</button></p>
		</form>
		<?php endif; ?>
	</div>
	<?php
}

/* --- kreator jednego formularza --- */
function rzd_kf_editor_page( $form ) {
	$draft = get_transient( 'rzd_kf_draft_' . get_current_user_id() );
	if ( is_array( $draft ) && $draft['id'] === $form['id'] ) { // po błędzie zapisu – to, co wpisano
		delete_transient( 'rzd_kf_draft_' . get_current_user_id() );
		$form = rzd_kf_form_normalize( array_merge( $form, $draft['input'] ), $form['id'] );
	}
	$styles = rzd_kf_styles();
	$look   = $form['look'];
	$sc     = '[rzd_kontakt id="' . $form['id'] . '"]';
	$fields = array_map( function ( $f ) {
		$f['options'] = implode( "\n", (array) $f['options'] );
		return $f;
	}, $form['fields'] );
	?>
	<div class="wrap rzd-kf-admin rzd-kf-editor">
		<h1 class="wp-heading-inline">Formularz: <?php echo esc_html( $form['title'] ); ?></h1>
		<a href="<?php echo esc_url( admin_url( 'admin.php?page=rzd-formularze' ) ); ?>" class="page-title-action">← Wszystkie formularze</a>
		<?php echo rzd_kf_flash_html(); // phpcs:ignore ?>
		<p>Shortcode: <input type="text" readonly value="<?php echo esc_attr( $sc ); ?>" style="width:280px;font-family:monospace" onfocus="this.select()" aria-label="Shortcode"> <button type="button" class="button button-small rzd-kf-copy" data-copy="<?php echo esc_attr( $sc ); ?>">Kopiuj</button></p>
		<div class="rzd-kfe-cols">
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="rzd-kfe-form" class="rzd-kfe-main">
			<input type="hidden" name="action" value="rzd_kf_save">
			<input type="hidden" name="id" value="<?php echo esc_attr( $form['id'] ); ?>">
			<?php wp_nonce_field( 'rzd_kf_save' ); ?>
			<input type="hidden" name="fields_json" id="rzd-kfe-json" value="<?php echo esc_attr( wp_json_encode( $fields ) ); ?>">

			<div class="rzd-kfe-box">
				<h2>Nazwa</h2>
				<input type="text" name="title" class="large-text" value="<?php echo esc_attr( $form['title'] ); ?>" required aria-label="Nazwa formularza">
				<p class="description">Widzisz ją w panelu, w Wiadomościach i (jako {formularz}) w mailach.</p>
			</div>

			<div class="rzd-kfe-box">
				<h2>Pola</h2>
				<ul id="rzd-kfb-list" class="rzd-kfb-list"></ul>
				<p class="rzd-kfb-add">
					<select id="rzd-kfb-type" aria-label="Typ nowego pola">
						<?php foreach ( rzd_kf_field_types() as $t => $l ) : ?><option value="<?php echo esc_attr( $t ); ?>"><?php echo esc_html( $l ); ?></option><?php endforeach; ?>
					</select>
					<button type="button" class="button" id="rzd-kfb-add">+ Dodaj pole</button>
					<span class="description">Kolejność zmieniasz, przeciągając za ☰ albo strzałkami.</span>
				</p>
			</div>

			<div class="rzd-kfe-box">
				<h2>Wygląd</h2>
				<div class="rzd-kfe-styles">
					<?php foreach ( $styles as $k => $st ) : ?>
						<label class="rzd-kfe-style"><input type="radio" name="style" value="<?php echo esc_attr( $k ); ?>" <?php checked( $form['style'], $k ); ?>> <strong><?php echo esc_html( $st['label'] ); ?></strong><br><small><?php echo esc_html( $st['desc'] ); ?></small></label>
					<?php endforeach; ?>
				</div>
				<table class="form-table" role="presentation">
					<tr><th>Kolor akcentu</th><td><label><input type="checkbox" class="rzd-kfe-own" data-for="rzd-kfe-accent" <?php checked( '' !== $look['accent'] ); ?>> własny</label> <input type="color" id="rzd-kfe-accent" name="look[accent]" value="<?php echo esc_attr( $look['accent'] ? $look['accent'] : '#c08a2e' ); ?>" <?php disabled( '' === $look['accent'] ); ?>> <span class="description">bez zaznaczenia – kolor przycisków z „Wyglądu listy”</span></td></tr>
					<tr><th>Tło formularza</th><td><label><input type="checkbox" class="rzd-kfe-own" data-for="rzd-kfe-bg" <?php checked( '' !== $look['bg'] ); ?>> własne</label> <input type="color" id="rzd-kfe-bg" name="look[bg]" value="<?php echo esc_attr( $look['bg'] ? $look['bg'] : '#ffffff' ); ?>" <?php disabled( '' === $look['bg'] ); ?>> <span class="description">dla stylów Karta i Ciemny (kolor tekstu dobiera się sam)</span></td></tr>
					<tr><th><label for="rzd-kfe-radius">Zaokrąglenie rogów</label></th><td><input type="number" min="0" max="40" id="rzd-kfe-radius" name="look[radius]" value="<?php echo esc_attr( $look['radius'] ); ?>" style="width:80px" placeholder="auto"> px <span class="description">puste – jak przyciski z „Wyglądu listy”</span></td></tr>
					<tr><th><label for="rzd-kfe-spacing">Odstępy</label></th><td><select id="rzd-kfe-spacing" name="look[spacing]"><option value="compact" <?php selected( $look['spacing'], 'compact' ); ?>>ciasne</option><option value="normal" <?php selected( $look['spacing'], 'normal' ); ?>>normalne</option><option value="airy" <?php selected( $look['spacing'], 'airy' ); ?>>przestronne</option></select></td></tr>
					<tr><th><label for="rzd-kfe-labels">Etykiety</label></th><td><select id="rzd-kfe-labels" name="look[labels]"><option value="" <?php selected( $look['labels'], '' ); ?>>jak w stylu</option><option value="above" <?php selected( $look['labels'], 'above' ); ?>>nad polem</option><option value="inside" <?php selected( $look['labels'], 'inside' ); ?>>w polu (unoszą się przy wpisywaniu)</option></select></td></tr>
					<tr><th><label for="rzd-kfe-button">Napis na przycisku</label></th><td><input type="text" id="rzd-kfe-button" name="button" value="<?php echo esc_attr( $form['button'] ); ?>"></td></tr>
					<tr><th><label for="rzd-kfe-css">Własny CSS</label></th><td>
						<textarea id="rzd-kfe-css" name="css" rows="6" class="large-text code" spellcheck="false" placeholder="<?php echo esc_attr( '.rzd-kf-id-' . $form['id'] . ' .rzd-kf-btn { border-radius: 999px; }' ); ?>"><?php echo esc_textarea( $form['css'] ); ?></textarea>
						<p class="description">Tylko dla tego formularza – zaczynaj reguły od <code>.rzd-kf-id-<?php echo esc_html( $form['id'] ); ?></code>. Klasy: <code>.rzd-kf-input</code>, <code>.rzd-kf-label</code>, <code>.rzd-kf-btn</code>, <code>.rzd-kf-field--textarea</code>, <code>.rzd-kf-h</code> (nagłówek), <code>.rzd-kf-privacy</code>. Podgląd obok pokazuje zmiany od razu.</p>
					</td></tr>
				</table>
			</div>

			<div class="rzd-kfe-box">
				<h2>Maile</h2>
				<table class="form-table" role="presentation">
					<tr><th><label for="rzd-kfe-to">Do kogo</label></th><td><input type="text" class="large-text" id="rzd-kfe-to" name="to" value="<?php echo esc_attr( $form['to'] ); ?>" placeholder="<?php echo esc_attr( get_option( 'admin_email' ) ); ?>"><p class="description">Jeden lub kilka adresów oddzielonych przecinkiem. Puste – adres administratora strony.</p></td></tr>
					<tr><th><label for="rzd-kfe-subject">Temat</label></th><td><input type="text" class="large-text" id="rzd-kfe-subject" name="subject" value="<?php echo esc_attr( $form['subject'] ); ?>"></td></tr>
					<tr><th><label for="rzd-kfe-body">Treść</label></th><td><textarea id="rzd-kfe-body" name="body" rows="5" class="large-text"><?php echo esc_textarea( $form['body'] ); ?></textarea>
						<p class="description">Znaczniki (kliknij, aby wstawić w ostatnio wybrane pole): <span id="rzd-kfe-tags"></span></p></td></tr>
					<tr><th><label for="rzd-kfe-reply">„Odpowiedz” do</label></th><td><select id="rzd-kfe-reply" name="reply_to" data-value="<?php echo esc_attr( $form['reply_to'] ); ?>"></select><p class="description">Pole z adresem klienta – „Odpowiedz” w poczcie napisze prosto do niego.</p></td></tr>
					<tr><th>Potwierdzenie dla klienta</th><td><label><input type="checkbox" name="autoreply" value="1" id="rzd-kfe-ar" <?php checked( ! empty( $form['autoreply'] ) ); ?>> wyślij klientowi potwierdzenie na adres z pola wyżej</label>
						<div id="rzd-kfe-ar-box" style="margin-top:8px">
							<input type="text" class="large-text" name="ar_subject" value="<?php echo esc_attr( $form['ar_subject'] ); ?>" aria-label="Temat potwierdzenia" style="margin-bottom:6px">
							<textarea name="ar_body" rows="6" class="large-text" aria-label="Treść potwierdzenia"><?php echo esc_textarea( $form['ar_body'] ); ?></textarea>
							<p class="description">Uwaga: potwierdzenie idzie na adres wpisany w formularzu – przy dużym spamie lepiej wyłączyć albo włączyć captchę.</p>
						</div></td></tr>
				</table>
			</div>

			<div class="rzd-kfe-box">
				<h2>Po wysłaniu i informacja o danych</h2>
				<table class="form-table" role="presentation">
					<tr><th><label for="rzd-kfe-success">Komunikat</label></th><td><textarea id="rzd-kfe-success" name="success" rows="2" class="large-text"><?php echo esc_textarea( $form['success'] ); ?></textarea></td></tr>
					<tr><th><label for="rzd-kfe-redirect">albo przejście na stronę</label></th><td><?php wp_dropdown_pages( array( 'name' => 'redirect', 'id' => 'rzd-kfe-redirect', 'selected' => (int) $form['redirect'], 'show_option_none' => '– zostań na stronie, pokaż komunikat –', 'option_none_value' => '0' ) ); ?></td></tr>
					<tr><th><label for="rzd-kfe-privacy">Informacja o danych (RODO)</label></th><td><textarea id="rzd-kfe-privacy" name="privacy" rows="3" class="large-text"><?php echo esc_textarea( $form['privacy'] ); ?></textarea>
						<p class="description">Pod formularzem. <code>[privacy_policy]</code> = link do polityki prywatności (Ustawienia → Prywatność), <code>{sklep}</code> = nazwa strony. Pole zgody nie jest wymagane przy odpowiedzi na zapytanie – w razie potrzeby dodaj pole typu „Zgoda”.</p></td></tr>
				</table>
			</div>
			<p class="submit"><button type="submit" class="button button-primary button-large">Zapisz formularz</button></p>
		</form>
		<div class="rzd-kfe-side">
			<div class="rzd-kfe-preview-head"><strong>Podgląd</strong> <span class="description" id="rzd-kfe-pstate"></span>
				<span class="rzd-kfe-pw"><button type="button" class="button button-small" data-w="390">telefon</button> <button type="button" class="button button-small" data-w="">szeroko</button></span></div>
			<div class="rzd-kfe-preview-wrap"><div id="rzd-kf-preview"><?php echo rzd_kf_render( $form, $form['style'], array(), true ); // phpcs:ignore ?></div></div>
		</div>
		</div>
	</div>
	<style>
		.rzd-kfe-cols{display:flex;gap:24px;align-items:flex-start;flex-wrap:wrap}
		.rzd-kfe-main{flex:1 1 560px;max-width:900px;min-width:0}
		.rzd-kfe-side{flex:1 1 380px;position:sticky;top:46px;min-width:0}
		.rzd-kfe-preview-wrap{background:#fff;border:1px solid #dcdcde;border-radius:6px;padding:18px;max-height:calc(100vh - 120px);overflow:auto}
		#rzd-kf-preview{margin:0 auto;transition:max-width .2s}
		.rzd-kfe-preview-head{display:flex;gap:10px;align-items:center;margin-bottom:8px}.rzd-kfe-pw{margin-left:auto}
		.rzd-kfe-box{background:#fff;border:1px solid #dcdcde;border-radius:6px;padding:4px 18px 14px;margin:0 0 16px}
		.rzd-kfe-box h2{font-size:15px;margin:14px 0 10px}
		.rzd-kfe-styles{display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:8px}
		.rzd-kfe-style{border:1px solid #dcdcde;border-radius:6px;padding:8px 10px;cursor:pointer}
		.rzd-kfe-style:has(input:checked){border-color:#2271b1;box-shadow:0 0 0 1px #2271b1}
		.rzd-kfb-list{margin:0}.rzd-kfb-item{border:1px solid #dcdcde;border-radius:6px;margin:0 0 6px;background:#f9f9f9}
		.rzd-kfb-head{display:flex;align-items:center;gap:8px;padding:6px 8px;cursor:pointer}
		.rzd-kfb-handle{cursor:move;font-size:16px;color:#787c82;padding:0 4px}
		.rzd-kfb-title{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
		.rzd-kfb-type{color:#646970;font-size:12px}.rzd-kfb-badge{font-size:11px;background:#fcf0f1;color:#b32d2e;border-radius:3px;padding:0 5px}
		.rzd-kfb-body{padding:6px 12px 12px;border-top:1px solid #e4e4e7;background:#fff;display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:8px 16px}
		.rzd-kfb-body label{display:block;font-size:12px;color:#50575e}.rzd-kfb-body input[type=text],.rzd-kfb-body textarea,.rzd-kfb-body select{width:100%}
		.rzd-kfb-body .rzd-kfb-wide{grid-column:1/-1}
		.rzd-kfb-placeholder{height:38px;border:2px dashed #2271b1;border-radius:6px;margin:0 0 6px}
		#rzd-kfe-tags code{cursor:pointer;margin:0 4px 4px 0;display:inline-block}
		#rzd-kfe-tags code:hover{background:#dcdcde}
	</style>
	<?php
}

/* ============================================================
 * 4. WIADOMOŚCI
 * ============================================================ */
function rzd_kf_counts_by_form() {
	global $wpdb;
	$rows = $wpdb->get_results( "SELECT pm.meta_value AS f, COUNT(*) AS n FROM {$wpdb->postmeta} pm JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE p.post_type = 'rzd_kf_msg' AND pm.meta_key = '_rzd_kf_form' GROUP BY pm.meta_value" ); // phpcs:ignore
	$out  = array();
	foreach ( (array) $rows as $r ) {
		$out[ $r->f ] = (int) $r->n;
	}
	return $out;
}
function rzd_kf_statuses() {
	return array( 'new' => 'nowa', 'read' => 'przeczytana', 'answered' => 'odpowiedziana' );
}
function rzd_kf_set_status( $ids, $status ) {
	if ( ! isset( rzd_kf_statuses()[ $status ] ) ) {
		return;
	}
	foreach ( (array) $ids as $id ) {
		if ( 'rzd_kf_msg' === get_post_type( $id ) ) {
			update_post_meta( $id, '_rzd_kf_status', $status );
		}
	}
	rzd_kf_recount();
}
function rzd_kf_query_args( $req ) {
	$a    = array( 'post_type' => 'rzd_kf_msg', 'post_status' => 'publish', 'orderby' => 'date', 'order' => 'DESC' );
	$meta = array();
	if ( ! empty( $req['form'] ) ) {
		$meta[] = array( 'key' => '_rzd_kf_form', 'value' => sanitize_key( $req['form'] ) );
	}
	if ( ! empty( $req['status'] ) && isset( rzd_kf_statuses()[ $req['status'] ] ) ) {
		$meta[] = array( 'key' => '_rzd_kf_status', 'value' => $req['status'] );
	}
	if ( $meta ) {
		$a['meta_query'] = $meta; // phpcs:ignore
	}
	if ( ! empty( $req['s'] ) ) {
		$a['rzd_kf_search'] = sanitize_text_field( $req['s'] );
	}
	return $a;
}
// Szukanie także w treści pól (meta _rzd_kf_fields), nie tylko w tytule.
add_filter( 'posts_where', function ( $where, $q ) {
	$s = $q->get( 'rzd_kf_search' );
	if ( $s ) {
		global $wpdb;
		$like   = '%' . $wpdb->esc_like( $s ) . '%';
		$where .= $wpdb->prepare( " AND ( {$wpdb->posts}.post_title LIKE %s OR EXISTS ( SELECT 1 FROM {$wpdb->postmeta} m WHERE m.post_id = {$wpdb->posts}.ID AND m.meta_key IN ('_rzd_kf_fields','_rzd_kf_email') AND m.meta_value LIKE %s ) )", $like, $like ); // phpcs:ignore
	}
	return $where;
}, 10, 2 );

add_action( 'admin_post_rzd_kf_msg_action', function () {
	rzd_kf_guard( 'rzd_kf_msg_action' );
	$ids  = array_map( 'absint', (array) ( isset( $_POST['ids'] ) ? wp_unslash( $_POST['ids'] ) : array() ) ); // phpcs:ignore
	$do   = isset( $_POST['do'] ) ? sanitize_key( wp_unslash( $_POST['do'] ) ) : ''; // phpcs:ignore
	$back = isset( $_POST['back'] ) ? esc_url_raw( wp_unslash( $_POST['back'] ) ) : admin_url( 'admin.php?page=rzd-wiadomosci' ); // phpcs:ignore
	$ids  = array_filter( $ids, function ( $id ) {
		return 'rzd_kf_msg' === get_post_type( $id );
	} );
	if ( 'delete' === $do ) {
		foreach ( $ids as $id ) {
			wp_delete_post( $id, true );
		}
		rzd_kf_recount();
		rzd_kf_msg_flash( 'Usunięto: ' . count( $ids ) . '.' );
		$back = remove_query_arg( 'msg', $back );
	} elseif ( isset( rzd_kf_statuses()[ $do ] ) ) {
		rzd_kf_set_status( $ids, $do );
		rzd_kf_msg_flash( 'Oznaczono jako „' . rzd_kf_statuses()[ $do ] . '”: ' . count( $ids ) . '.' );
	}
	wp_safe_redirect( $back );
	exit;
} );

// Eksport CSV (jak raporty: ochrona przed formułami w Excelu).
add_action( 'admin_post_rzd_kf_csv', function () {
	rzd_kf_guard( 'rzd_kf_csv' );
	$req   = wp_unslash( $_GET ); // phpcs:ignore -- czyszczone w rzd_kf_query_args
	$a     = rzd_kf_query_args( $req );
	$a['posts_per_page'] = 5000;
	$posts = get_posts( $a + array( 'suppress_filters' => false ) );
	$one   = ! empty( $req['form'] );
	$labels = array();
	foreach ( $posts as $p ) {
		foreach ( (array) get_post_meta( $p->ID, '_rzd_kf_fields', true ) as $d ) {
			$labels[ $d['label'] ] = true;
		}
	}
	$labels = array_keys( $labels );
	$head   = array_merge( array( 'Data', 'Formularz', 'Status' ), $one ? $labels : array( 'Treść' ) );
	$rows   = array();
	$st     = rzd_kf_statuses();
	foreach ( $posts as $p ) {
		$f   = (array) get_post_meta( $p->ID, '_rzd_kf_fields', true );
		$s   = (string) get_post_meta( $p->ID, '_rzd_kf_status', true );
		$row = array( get_the_date( 'Y-m-d H:i', $p ), (string) get_post_meta( $p->ID, '_rzd_kf_form_title', true ), isset( $st[ $s ] ) ? $st[ $s ] : $s );
		if ( $one ) {
			$by = array();
			foreach ( $f as $d ) {
				$by[ $d['label'] ] = $d['value'];
			}
			foreach ( $labels as $l ) {
				$row[] = isset( $by[ $l ] ) ? $by[ $l ] : '';
			}
		} else {
			$row[] = implode( '; ', array_map( function ( $d ) {
				return $d['label'] . ': ' . $d['value'];
			}, $f ) );
		}
		$rows[] = array_map( 'rzd_raport_csv_cell', $row );
	}
	rzd_raport_output_csv( 'wiadomosci-' . wp_date( 'Y-m-d' ) . '.csv', $head, $rows );
	exit;
} );

function rzd_kf_messages_page() {
	if ( ! rzd_kf_can() ) {
		wp_die( 'Brak uprawnień.' );
	}
	rzd_kf_cleanup();
	$req = wp_unslash( $_GET ); // phpcs:ignore -- tylko filtr listy
	$one = isset( $req['msg'] ) ? absint( $req['msg'] ) : 0;
	if ( $one && 'rzd_kf_msg' === get_post_type( $one ) ) {
		rzd_kf_message_view( get_post( $one ) );
		return;
	}
	$paged = max( 1, isset( $req['paged'] ) ? absint( $req['paged'] ) : 1 );
	$q     = new WP_Query( rzd_kf_query_args( $req ) + array( 'posts_per_page' => 30, 'paged' => $paged ) );
	$forms = rzd_kf_forms();
	$st    = rzd_kf_statuses();
	$self  = admin_url( 'admin.php?page=rzd-wiadomosci' );
	$cur   = add_query_arg( array_filter( array( 'form' => isset( $req['form'] ) ? sanitize_key( $req['form'] ) : '', 'status' => isset( $req['status'] ) ? sanitize_key( $req['status'] ) : '', 's' => isset( $req['s'] ) ? sanitize_text_field( $req['s'] ) : '', 'paged' => $paged > 1 ? $paged : '' ) ), $self );
	$csv   = wp_nonce_url( add_query_arg( array_filter( array( 'action' => 'rzd_kf_csv', 'form' => isset( $req['form'] ) ? sanitize_key( $req['form'] ) : '', 'status' => isset( $req['status'] ) ? sanitize_key( $req['status'] ) : '', 's' => isset( $req['s'] ) ? sanitize_text_field( $req['s'] ) : '' ) ), admin_url( 'admin-post.php' ) ), 'rzd_kf_csv' );
	?>
	<div class="wrap rzd-kf-admin">
		<h1 class="wp-heading-inline">Wiadomości</h1>
		<a class="page-title-action" href="<?php echo esc_url( $csv ); ?>">Eksport CSV</a>
		<?php echo rzd_kf_flash_html(); // phpcs:ignore ?>
		<form method="get" style="margin:12px 0">
			<input type="hidden" name="page" value="rzd-wiadomosci">
			<select name="form" aria-label="Formularz"><option value="">wszystkie formularze</option>
				<?php foreach ( $forms as $id => $f ) : ?><option value="<?php echo esc_attr( $id ); ?>" <?php selected( isset( $req['form'] ) ? $req['form'] : '', $id ); ?>><?php echo esc_html( $f['title'] ); ?></option><?php endforeach; ?>
			</select>
			<select name="status" aria-label="Status"><option value="">każdy status</option>
				<?php foreach ( $st as $k => $l ) : ?><option value="<?php echo esc_attr( $k ); ?>" <?php selected( isset( $req['status'] ) ? $req['status'] : '', $k ); ?>><?php echo esc_html( $l ); ?></option><?php endforeach; ?>
			</select>
			<input type="search" name="s" value="<?php echo esc_attr( isset( $req['s'] ) ? $req['s'] : '' ); ?>" placeholder="szukaj (nazwisko, e-mail, treść)">
			<button class="button">Filtruj</button>
		</form>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="rzd_kf_msg_action"><input type="hidden" name="back" value="<?php echo esc_attr( $cur ); ?>"><?php wp_nonce_field( 'rzd_kf_msg_action' ); ?>
			<table class="widefat striped rzd-kf-msgs">
				<thead><tr><td class="check-column"><input type="checkbox" onclick="document.querySelectorAll('.rzd-kf-msgs tbody input[type=checkbox]').forEach(function(c){c.checked=this.checked}.bind(this))" aria-label="Zaznacz wszystkie"></td><th style="width:110px">Kiedy</th><th>Formularz</th><th>Od</th><th>Treść</th><th style="width:120px">Status</th></tr></thead>
				<tbody>
				<?php if ( ! $q->posts ) : ?><tr><td colspan="6">Brak wiadomości.</td></tr><?php endif; ?>
				<?php foreach ( $q->posts as $p ) :
					$s     = (string) get_post_meta( $p->ID, '_rzd_kf_status', true );
					$f     = (array) get_post_meta( $p->ID, '_rzd_kf_fields', true );
					$email = (string) get_post_meta( $p->ID, '_rzd_kf_email', true );
					$name  = (string) get_post_meta( $p->ID, '_rzd_kf_name', true );
					$tel   = '';
					$long  = '';
					foreach ( $f as $d ) {
						if ( 'tel' === $d['type'] && '' === $tel ) {
							$tel = $d['value'];
						}
						if ( 'textarea' === $d['type'] && '' === $long ) {
							$long = $d['value'];
						}
					}
					if ( '' === $long ) {
						$long = implode( ' · ', array_filter( array_map( function ( $d ) {
							return in_array( $d['type'], array( 'email', 'tel', 'consent' ), true ) || '' === (string) $d['value'] ? '' : $d['label'] . ': ' . $d['value'];
						}, $f ) ) );
					}
					$link = add_query_arg( 'msg', $p->ID, $self );
					?>
					<tr<?php echo 'new' === $s ? ' style="font-weight:600"' : ''; ?>>
						<th class="check-column"><input type="checkbox" name="ids[]" value="<?php echo (int) $p->ID; ?>" aria-label="Zaznacz"></th>
						<td><a href="<?php echo esc_url( $link ); ?>"><?php echo esc_html( get_the_date( 'j.m.Y H:i', $p ) ); ?></a></td>
						<td><?php echo esc_html( (string) get_post_meta( $p->ID, '_rzd_kf_form_title', true ) ); ?></td>
						<td><?php echo esc_html( $name ); ?><?php echo $email ? '<br><small>' . esc_html( $email ) . '</small>' : ''; ?><?php echo $tel ? '<br><small>' . esc_html( $tel ) . '</small>' : ''; ?></td>
						<td><a href="<?php echo esc_url( $link ); ?>" style="font-weight:inherit"><?php echo esc_html( wp_trim_words( $long, 18, '…' ) ); ?></a></td>
						<td><?php echo esc_html( isset( $st[ $s ] ) ? $st[ $s ] : $s ); ?><?php echo 'fail' === get_post_meta( $p->ID, '_rzd_kf_mail', true ) ? '<br><small style="color:#b32d2e">mail nie wyszedł</small>' : ''; ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
			<p>
				<select name="do" aria-label="Akcja"><option value="answered">oznacz jako odpowiedziane</option><option value="read">oznacz jako przeczytane</option><option value="new">oznacz jako nowe</option><option value="delete">usuń</option></select>
				<button class="button" onclick="return this.form.do.value!=='delete'||confirm('Usunąć zaznaczone wiadomości?');">Wykonaj dla zaznaczonych</button>
			</p>
		</form>
		<?php if ( $q->max_num_pages > 1 ) : ?>
			<p><?php echo paginate_links( array( 'base' => add_query_arg( 'paged', '%#%', $cur ), 'format' => '', 'current' => $paged, 'total' => $q->max_num_pages ) ); // phpcs:ignore ?></p>
		<?php endif; ?>
		<p class="description">Wiadomości starsze niż <?php echo (int) rzd_kf_settings()['keep']; ?> mies. usuwają się automatycznie<?php echo 0 === (int) rzd_kf_settings()['keep'] ? ' (wyłączone)' : ''; ?>. Dane konkretnej osoby wyeksportujesz lub usuniesz też w Narzędzia → Eksportuj / Usuń dane osobowe.</p>
	</div>
	<?php
}

function rzd_kf_message_view( $p ) {
	if ( 'new' === get_post_meta( $p->ID, '_rzd_kf_status', true ) ) {
		rzd_kf_set_status( array( $p->ID ), 'read' );
	}
	$s     = (string) get_post_meta( $p->ID, '_rzd_kf_status', true );
	$f     = (array) get_post_meta( $p->ID, '_rzd_kf_fields', true );
	$email = (string) get_post_meta( $p->ID, '_rzd_kf_email', true );
	$page  = (int) get_post_meta( $p->ID, '_rzd_kf_page', true );
	$ftit  = (string) get_post_meta( $p->ID, '_rzd_kf_form_title', true );
	$self  = admin_url( 'admin.php?page=rzd-wiadomosci&msg=' . $p->ID );
	$st    = rzd_kf_statuses();
	$act   = function ( $do, $label, $cls = 'button' ) use ( $p, $self ) {
		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" style="display:inline"' . ( 'delete' === $do ? ' onsubmit="return confirm(\'Usunąć wiadomość?\');"' : '' ) . '><input type="hidden" name="action" value="rzd_kf_msg_action"><input type="hidden" name="do" value="' . esc_attr( $do ) . '"><input type="hidden" name="ids[]" value="' . (int) $p->ID . '"><input type="hidden" name="back" value="' . esc_attr( 'delete' === $do ? admin_url( 'admin.php?page=rzd-wiadomosci' ) : $self ) . '">';
		wp_nonce_field( 'rzd_kf_msg_action' );
		echo '<button class="' . esc_attr( $cls ) . '">' . esc_html( $label ) . '</button></form> ';
	};
	?>
	<div class="wrap rzd-kf-admin">
		<h1 class="wp-heading-inline"><?php echo esc_html( $ftit ); ?> – <?php echo esc_html( get_the_date( 'j.m.Y H:i', $p ) ); ?></h1>
		<a class="page-title-action" href="<?php echo esc_url( admin_url( 'admin.php?page=rzd-wiadomosci' ) ); ?>">← Wszystkie wiadomości</a>
		<?php echo rzd_kf_flash_html(); // phpcs:ignore ?>
		<p>Status: <strong><?php echo esc_html( isset( $st[ $s ] ) ? $st[ $s ] : $s ); ?></strong>
			<?php if ( $page ) : ?> · wysłano ze strony: <a href="<?php echo esc_url( get_permalink( $page ) ); ?>" target="_blank"><?php echo esc_html( get_the_title( $page ) ); ?></a><?php endif; ?>
			<?php if ( 'fail' === get_post_meta( $p->ID, '_rzd_kf_mail', true ) ) : ?> · <span style="color:#b32d2e">mail do restauracji nie wyszedł (szczegóły: Stan i poczta → Dziennik)</span><?php endif; ?></p>
		<table class="widefat striped" style="max-width:900px">
			<tbody>
			<?php foreach ( $f as $d ) : ?>
				<tr><th style="width:220px"><?php echo esc_html( $d['label'] ); ?></th><td>
					<?php
					$v = (string) $d['value'];
					if ( '' === $v ) {
						echo '<span style="color:#999">–</span>';
					} elseif ( 'email' === $d['type'] && is_email( $v ) ) {
						echo '<a href="' . esc_url( 'mailto:' . $v ) . '">' . esc_html( $v ) . '</a>';
					} elseif ( 'tel' === $d['type'] ) {
						echo '<a href="' . esc_url( 'tel:' . preg_replace( '/[^0-9+]/', '', $v ) ) . '">' . esc_html( $v ) . '</a>';
					} else {
						echo nl2br( esc_html( $v ) );
					}
					?>
				</td></tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<p style="margin-top:16px">
			<?php if ( $email ) : ?><a class="button button-primary" href="<?php echo esc_url( 'mailto:' . $email . '?subject=' . rawurlencode( 'Re: ' . $ftit ) ); ?>">Odpowiedz e-mailem</a> <?php endif; ?>
			<?php
			if ( 'answered' !== $s ) {
				$act( 'answered', 'Oznacz jako odpowiedzianą' );
			} else {
				$act( 'new', 'Oznacz jako nową' );
			}
			$act( 'delete', 'Usuń', 'button button-link-delete' );
			?>
		</p>
	</div>
	<?php
}
