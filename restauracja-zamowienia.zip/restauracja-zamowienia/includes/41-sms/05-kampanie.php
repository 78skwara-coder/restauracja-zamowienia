<?php
/**
 * Moduł 41-sms – kampanie marketingowe: wysyłka do numerów z aktywną zgodą, partiami po 25 (Action Scheduler,
 * zadanie rzd_sms_campaign_batch [id]). Treść ze zmiennymi ({imie}, {restauracja}, {telefon_restauracji}); każdy
 * SMS dostaje automatycznie dopisek z osobistym linkiem rezygnacji. Wysyłka tylko w godzinach dozwolonych
 * (domyślnie 8:00–20:00) – partia poza nimi czeka do najbliższej dozwolonej godziny. Historia: opcja
 * rzd_sms_campaigns (ostatnie 50): id, at, send_at, text, total, sent, failed, status (plan|run|done|cancel), last_id, by.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'RZD_SMS_BATCH', 25 );

function rzd_sms_campaigns() {
	$c = get_option( 'rzd_sms_campaigns', array() );
	return is_array( $c ) ? $c : array();
}

function rzd_sms_campaign( $id ) {
	foreach ( rzd_sms_campaigns() as $c ) {
		if ( (int) $c['id'] === (int) $id ) {
			return $c;
		}
	}
	return null;
}

function rzd_sms_campaign_put( $camp ) {
	$all = rzd_sms_campaigns();
	$hit = false;
	foreach ( $all as $i => $c ) {
		if ( (int) $c['id'] === (int) $camp['id'] ) {
			$all[ $i ] = $camp;
			$hit       = true;
		}
	}
	if ( ! $hit ) {
		array_unshift( $all, $camp );
	}
	update_option( 'rzd_sms_campaigns', array_slice( $all, 0, 50 ), false );
}

/** Pierwsza dozwolona chwila >= $ts (godziny ciszy wg ustawień, czas strony). */
function rzd_sms_allowed_ts( $ts ) {
	$m  = rzd_sms_settings()['mkt'];
	$tz = wp_timezone();
	$d  = ( new DateTime( '@' . (int) $ts ) )->setTimezone( $tz );
	$hm = $d->format( 'H:i' );
	if ( $hm >= $m['quiet_from'] && $hm < $m['quiet_to'] ) {
		return (int) $ts;
	}
	if ( $hm >= $m['quiet_to'] ) {
		$d->modify( '+1 day' );
	}
	list( $h, $i ) = array_map( 'intval', explode( ':', $m['quiet_from'] ) );
	$d->setTime( $h, $i );
	return $d->getTimestamp();
}

/** Pełna treść dla jednego odbiorcy (z dopiskiem rezygnacji). */
function rzd_sms_campaign_text( $text, $name, $token ) {
	$s    = rzd_sms_settings();
	$vars = array( 'restauracja' => rzd_sms_name(), 'telefon_restauracji' => $s['phone'], 'imie' => (string) $name );
	$body = rzd_sms_render( $text, $vars );
	$stop = rzd_sms_render( $s['mkt']['optout'], array( 'link_rezygnacji' => rzd_sms_stop_url( $token ) ) );
	return trim( $body . ' ' . $stop );
}

/** Podgląd: odbiorcy, części, szacowany koszt. */
function rzd_sms_campaign_preview( $text ) {
	$s     = rzd_sms_settings();
	$full  = rzd_sms_final( rzd_sms_campaign_text( $text, 'Katarzyna', 'abcd1234ef' ) ); // dłuższe imię – bezpieczniejszy szacunek
	list( $parts, $len, $uni ) = rzd_sms_parts( $full );
	$n     = rzd_sms_consent_count();
	return array(
		'sample'     => $full,
		'parts'      => $parts,
		'len'        => $len,
		'unicode'    => $uni,
		'recipients' => $n,
		'sms'        => $n * $parts,
		'cost'       => round( $n * $parts * (float) $s['mkt']['price'], 2 ),
		'price'      => (float) $s['mkt']['price'],
		'tooLong'    => $parts > (int) $s['max_parts'],
		'maxParts'   => (int) $s['max_parts'],
	);
}

function rzd_sms_schedule_batch( $ts, $id ) {
	if ( function_exists( 'as_schedule_single_action' ) ) {
		as_schedule_single_action( $ts, 'rzd_sms_campaign_batch', array( (int) $id ), 'restauracja' );
	} else {
		wp_schedule_single_event( $ts, 'rzd_sms_campaign_batch', array( (int) $id ) );
	}
}

/** Utworzenie kampanii. $at – znacznik czasu (0 = teraz). [ ok, kampania | komunikat ]. */
function rzd_sms_campaign_create( $text, $at = 0 ) {
	$text = trim( sanitize_textarea_field( (string) $text ) );
	if ( '' === $text ) {
		return array( false, 'Wpisz treść SMS-a.' );
	}
	if ( false !== strpos( $text, '{link_rezygnacji}' ) ) {
		return array( false, 'Link rezygnacji dopisujemy sami na końcu – usuń {link_rezygnacji} z treści.' );
	}
	if ( ! rzd_sms_ready() ) {
		return array( false, 'SMS nie jest połączony (Połączenia API → SMS).' );
	}
	$p = rzd_sms_campaign_preview( $text );
	if ( ! $p['recipients'] ) {
		return array( false, 'Nikt jeszcze nie wyraził zgody na SMS-y marketingowe.' );
	}
	if ( $p['tooLong'] ) {
		return array( false, 'SMS z dopiskiem rezygnacji ma ' . $p['parts'] . ' części – limit w ustawieniach to ' . $p['maxParts'] . '.' );
	}
	$now  = time();
	$at   = (int) $at > $now ? (int) $at : $now;
	$run  = rzd_sms_allowed_ts( $at );
	$user = wp_get_current_user();
	$camp = array(
		'id'      => (int) round( microtime( true ) * 1000 ) % 2000000000,
		'at'      => $now,
		'send_at' => $run,
		'text'    => $text,
		'total'   => $p['recipients'],
		'sent'    => 0,
		'failed'  => 0,
		'status'  => 'plan',
		'last_id' => 0,
		'by'      => $user && $user->exists() ? $user->display_name : '',
		'err'     => '',
	);
	rzd_sms_campaign_put( $camp );
	rzd_sms_schedule_batch( $run, $camp['id'] );
	return array( true, $camp );
}

function rzd_sms_campaign_cancel( $id ) {
	$c = rzd_sms_campaign( $id );
	if ( ! $c || ! in_array( $c['status'], array( 'plan', 'run' ), true ) ) {
		return false;
	}
	$c['status'] = 'cancel';
	rzd_sms_campaign_put( $c );
	if ( function_exists( 'as_unschedule_all_actions' ) ) {
		as_unschedule_all_actions( 'rzd_sms_campaign_batch', array( (int) $id ), 'restauracja' );
	}
	wp_clear_scheduled_hook( 'rzd_sms_campaign_batch', array( (int) $id ) );
	return true;
}

/** Jedna partia kampanii. */
function rzd_sms_campaign_batch( $id ) {
	$c = rzd_sms_campaign( $id );
	if ( ! $c || in_array( $c['status'], array( 'done', 'cancel' ), true ) ) {
		return;
	}
	$now = time();
	$ok  = rzd_sms_allowed_ts( $now );
	if ( $ok > $now ) { // godziny ciszy – dokończ jutro rano
		rzd_sms_schedule_batch( $ok, $id );
		return;
	}
	$c['status'] = 'run';
	rzd_sms_campaign_put( $c );
	$rows = rzd_sms_consent_batch( $c['last_id'], RZD_SMS_BATCH );
	foreach ( $rows as $r ) {
		$c = rzd_sms_campaign( $id ); // anulowanie w trakcie partii
		if ( ! $c || 'cancel' === $c['status'] ) {
			return;
		}
		list( $sent, $msg ) = rzd_sms_send( $r['phone'], rzd_sms_campaign_text( $c['text'], $r['name'], $r['token'] ), array( 'kind' => 'mkt', 'ref' => $id ) );
		$c['last_id'] = (int) $r['id'];
		if ( $sent ) {
			$c['sent']++;
		} else {
			$c['failed']++;
			$c['err'] = (string) $msg;
		}
		rzd_sms_campaign_put( $c );
		if ( ! $sent && ( false !== strpos( (string) $msg, 'punktów' ) || false !== strpos( (string) $msg, 'token' ) ) ) {
			$c['status'] = 'done'; // brak punktów / zły token – dalsza wysyłka nie ma sensu
			rzd_sms_campaign_put( $c );
			return;
		}
	}
	if ( count( $rows ) < RZD_SMS_BATCH ) {
		$c['status'] = 'done';
		rzd_sms_campaign_put( $c );
		return;
	}
	rzd_sms_schedule_batch( time() + 5, $id );
}
add_action( 'rzd_sms_campaign_batch', 'rzd_sms_campaign_batch' );
