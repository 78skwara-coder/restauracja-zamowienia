<?php
/**
 * Moduł 41-sms – zdarzenia: SMS-y o zamówieniu (złożone → klient „przyjęte” + obsługa „nowe”; status „W dostawie” →
 * „kurier w drodze”, a przy odbiorze osobistym „gotowe do odbioru”), pole zgody marketingowej w kasie (klasyczna),
 * link rezygnacji ?sms-stop=TOKEN. Każdy SMS zamówienia tylko raz (meta _rzd_sms_{rodzaj}).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** SMS danego rodzaju do zamówienia (raz). */
function rzd_sms_for_order( $order, $kind ) {
	$order = is_object( $order ) ? $order : wc_get_order( $order );
	$s     = rzd_sms_settings();
	if ( ! $order || ! isset( $s['events'][ $kind ] ) || ! $s['events'][ $kind ]['on'] || ! rzd_sms_ready() ) {
		return false;
	}
	if ( 'dine_in' === (string) $order->get_meta( '_rzd_channel' ) || $order->get_meta( '_rzd_sms_' . $kind ) ) { // sala – bez SMS
		return false;
	}
	$vars = rzd_sms_order_data( $order );
	if ( 'staff' === $kind ) {
		if ( $s['events']['staff']['today'] && (string) $order->get_meta( '_dc_delivery_date' ) !== current_time( 'Y-m-d' ) ) {
			return false;
		}
		$to = preg_split( '/[\s,;]+/', $s['events']['staff']['to'] );
	} else {
		$to = array( $order->get_billing_phone() );
	}
	$order->update_meta_data( '_rzd_sms_' . $kind, time() ); // przed wysyłką – bez podwójnego SMS-a przy równoległych żądaniach
	$order->save_meta_data();
	list( $ok, $r ) = rzd_sms_send( $to, rzd_sms_render( $s['events'][ $kind ]['text'], $vars ), array( 'kind' => $kind, 'ref' => $order->get_id() ) );
	if ( ! $ok ) {
		$order->add_order_note( 'SMS „' . rzd_sms_events()[ $kind ][0] . '” nie wyszedł: ' . $r );
	}
	return $ok;
}

/** Złożone zamówienie: zgoda marketingowa, SMS „przyjęte” do klienta i „nowe” do obsługi. */
function rzd_sms_on_new_order( $order ) {
	$order = is_object( $order ) ? $order : wc_get_order( $order );
	if ( ! $order ) {
		return;
	}
	$phone = $order->get_billing_phone();
	if ( $order->get_meta( '_rzd_sms_mkt' ) && ! $order->get_meta( '_rzd_sms_mkt_saved' ) ) {
		rzd_sms_consent_add( $phone, array(
			'name'     => $order->get_billing_first_name(),
			'user_id'  => $order->get_customer_id(),
			'order_id' => $order->get_id(),
			'source'   => 'kasa',
			'ip'       => $order->get_customer_ip_address(),
			'text'     => (string) $order->get_meta( '_rzd_sms_mkt_text' ),
		) );
		$order->update_meta_data( '_rzd_sms_mkt_saved', 1 );
		$order->save_meta_data();
	} elseif ( '' !== rzd_sms_phone( $phone ) ) {
		rzd_sms_consent_touch( $phone, $order->get_id(), $order->get_billing_first_name() );
	}
	rzd_sms_for_order( $order, 'order' );
	rzd_sms_for_order( $order, 'staff' );
}
add_action( 'woocommerce_checkout_order_processed', function ( $order_id ) {
	rzd_sms_on_new_order( $order_id );
}, 30 );
add_action( 'woocommerce_store_api_checkout_order_processed', 'rzd_sms_on_new_order', 30 );

/** Status „W dostawie”: dostawa → „kurier w drodze”, odbiór osobisty → „gotowe do odbioru”. */
add_action( 'woocommerce_order_status_w-dostawie', function ( $order_id ) {
	$order = wc_get_order( $order_id );
	if ( $order ) {
		rzd_sms_for_order( $order, '1' === (string) $order->get_meta( '_rzd_pickup' ) ? 'ready' : 'way' );
	}
}, 20 );

/* ---------- zgoda marketingowa w kasie (pole nieobowiązkowe, domyślnie odznaczone) ---------- */
function rzd_sms_consent_label() {
	return rzd_sms_render( rzd_sms_settings()['mkt']['consent'], array( 'restauracja' => rzd_sms_name(), 'telefon_restauracji' => rzd_sms_settings()['phone'] ) );
}
add_action( 'woocommerce_checkout_after_terms_and_conditions', function () {
	if ( ! rzd_sms_settings()['mkt']['on'] ) {
		return;
	}
	$checked = ! empty( $_POST['rzd_sms_mkt'] ); // phpcs:ignore -- ponowne wyświetlenie po błędzie
	echo '<p class="form-row rzd-sms-consent"><label class="woocommerce-form__label woocommerce-form__label-for-checkbox checkbox">'
		. '<input type="checkbox" class="woocommerce-form__input woocommerce-form__input-checkbox input-checkbox" name="rzd_sms_mkt" id="rzd_sms_mkt" value="1"' . checked( $checked, true, false ) . '> '
		. '<span>' . esc_html( rzd_sms_consent_label() ) . '</span></label></p>';
}, 20 );
add_action( 'woocommerce_checkout_create_order', function ( $order ) {
	if ( rzd_sms_settings()['mkt']['on'] && ! empty( $_POST['rzd_sms_mkt'] ) ) { // phpcs:ignore -- nonce kasy sprawdził WooCommerce
		$order->update_meta_data( '_rzd_sms_mkt', time() );
		$order->update_meta_data( '_rzd_sms_mkt_text', rzd_sms_consent_label() ); // dowód: treść, którą klient zaznaczył
	}
} );

/* ---------- rezygnacja z SMS-ów marketingowych ---------- */
function rzd_sms_stop_url( $token ) {
	return add_query_arg( 'sms-stop', rawurlencode( $token ), home_url( '/' ) );
}
add_action( 'template_redirect', function () {
	if ( ! isset( $_GET['sms-stop'] ) ) { // phpcs:ignore
		return;
	}
	$phone = rzd_sms_consent_withdraw( 0, sanitize_text_field( wp_unslash( $_GET['sms-stop'] ) ) ); // phpcs:ignore
	$name  = esc_html( rzd_sms_name() );
	$body  = '' !== $phone
		? '<p>Numer ' . esc_html( rzd_sms_mask( $phone ) ) . ' nie będzie już dostawać SMS-ów z ofertami ' . $name . '.</p><p>SMS-y o Twoich zamówieniach nadal przyjdą.</p>'
		: '<p>Ten link jest nieaktualny albo numer został już wypisany.</p>';
	wp_die( $body . '<p><a href="' . esc_url( home_url( '/' ) ) . '">← Wróć do ' . $name . '</a></p>', esc_html( 'Rezygnacja z SMS-ów – ' . rzd_sms_name() ), array( 'response' => 200 ) ); // phpcs:ignore
} );
