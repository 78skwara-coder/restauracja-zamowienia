<?php
/**
 * Moduł 41-sms – własne tabele (decyzja użytkownika 2026-11-07): {prefix}rzd_sms_consent – zgody marketingowe
 * (dowód: data, źródło, zamówienie, IP, treść zgody; wycofanie – withdrawn_at; token linku rezygnacji),
 * {prefix}rzd_sms_log – dziennik wysyłek (90 dni). Schemat przez dbDelta, wersja w opcji rzd_sms_db.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'RZD_SMS_DB', '1' );

function rzd_sms_t( $name ) {
	global $wpdb;
	return $wpdb->prefix . 'rzd_sms_' . $name;
}

function rzd_sms_db_install() {
	global $wpdb;
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	$c = $wpdb->get_charset_collate();
	dbDelta( 'CREATE TABLE ' . rzd_sms_t( 'consent' ) . " (
		id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
		phone varchar(20) NOT NULL,
		name varchar(100) NOT NULL DEFAULT '',
		user_id bigint(20) unsigned NOT NULL DEFAULT 0,
		order_id bigint(20) unsigned NOT NULL DEFAULT 0,
		last_order bigint(20) unsigned NOT NULL DEFAULT 0,
		consent_at datetime NOT NULL,
		source varchar(30) NOT NULL DEFAULT '',
		ip varchar(45) NOT NULL DEFAULT '',
		text varchar(300) NOT NULL DEFAULT '',
		withdrawn_at datetime NULL DEFAULT NULL,
		token varchar(16) NOT NULL DEFAULT '',
		PRIMARY KEY  (id),
		UNIQUE KEY phone (phone),
		KEY token (token)
	) $c;" );
	dbDelta( 'CREATE TABLE ' . rzd_sms_t( 'log' ) . " (
		id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
		at datetime NOT NULL,
		phone varchar(20) NOT NULL DEFAULT '',
		kind varchar(10) NOT NULL DEFAULT '',
		ref bigint(20) unsigned NOT NULL DEFAULT 0,
		parts tinyint(3) unsigned NOT NULL DEFAULT 0,
		status varchar(10) NOT NULL DEFAULT '',
		err varchar(255) NOT NULL DEFAULT '',
		sms_id varchar(40) NOT NULL DEFAULT '',
		text text NULL,
		PRIMARY KEY  (id),
		KEY at (at),
		KEY kind_ref (kind,ref)
	) $c;" );
	update_option( 'rzd_sms_db', RZD_SMS_DB, false );
}

/** Tabele gotowe (instalacja przy pierwszej potrzebie i po zmianie schematu). */
function rzd_sms_db_ready() {
	static $ok = null;
	if ( null === $ok ) {
		if ( get_option( 'rzd_sms_db' ) !== RZD_SMS_DB ) {
			rzd_sms_db_install();
		}
		$ok = true;
	}
	return $ok;
}
add_action( 'admin_init', 'rzd_sms_db_ready' );

/* ---------- dziennik ---------- */
function rzd_sms_log( $phone, $kind, $ref, $parts, $status, $err = '', $sms_id = '', $text = '' ) {
	global $wpdb;
	rzd_sms_db_ready();
	$wpdb->insert( rzd_sms_t( 'log' ), array( // phpcs:ignore
		'at'     => current_time( 'mysql' ),
		'phone'  => substr( (string) $phone, 0, 20 ),
		'kind'   => substr( (string) $kind, 0, 10 ),
		'ref'    => (int) $ref,
		'parts'  => (int) $parts,
		'status' => substr( (string) $status, 0, 10 ),
		'err'    => mb_substr( (string) $err, 0, 255 ),
		'sms_id' => substr( (string) $sms_id, 0, 40 ),
		'text'   => (string) $text,
	) );
}

/** Ostatnie wpisy dziennika (numery zamaskowane). */
function rzd_sms_log_list( $kind = '', $limit = 100, $offset = 0 ) {
	global $wpdb;
	rzd_sms_db_ready();
	$t     = rzd_sms_t( 'log' );
	$where = '' !== $kind ? $wpdb->prepare( 'WHERE kind = %s', $kind ) : '';
	$rows  = $wpdb->get_results( "SELECT * FROM $t $where ORDER BY id DESC LIMIT " . (int) $offset . ', ' . (int) $limit, ARRAY_A ); // phpcs:ignore
	return array_map( function ( $r ) {
		$r['phone'] = rzd_sms_mask( $r['phone'] );
		return $r;
	}, (array) $rows );
}

/* ---------- zgody ---------- */
function rzd_sms_token() {
	return substr( strtolower( preg_replace( '/[^a-z0-9]/i', '', wp_generate_password( 24, false ) ) ), 0, 10 );
}

/** Zapis / odnowienie zgody (numer jest kluczem). $d: name, user_id, order_id, source, ip, text. */
function rzd_sms_consent_add( $phone, $d = array() ) {
	global $wpdb;
	rzd_sms_db_ready();
	$phone = rzd_sms_phone( $phone );
	if ( '' === $phone ) {
		return false;
	}
	$t   = rzd_sms_t( 'consent' );
	$row = $wpdb->get_row( $wpdb->prepare( "SELECT id, token FROM $t WHERE phone = %s", $phone ), ARRAY_A ); // phpcs:ignore
	$data = array(
		'name'         => mb_substr( isset( $d['name'] ) ? (string) $d['name'] : '', 0, 100 ),
		'user_id'      => isset( $d['user_id'] ) ? (int) $d['user_id'] : 0,
		'order_id'     => isset( $d['order_id'] ) ? (int) $d['order_id'] : 0,
		'last_order'   => isset( $d['order_id'] ) ? (int) $d['order_id'] : 0,
		'consent_at'   => current_time( 'mysql' ),
		'source'       => mb_substr( isset( $d['source'] ) ? (string) $d['source'] : 'checkout', 0, 30 ),
		'ip'           => mb_substr( isset( $d['ip'] ) ? (string) $d['ip'] : '', 0, 45 ),
		'text'         => mb_substr( isset( $d['text'] ) ? (string) $d['text'] : '', 0, 300 ),
		'withdrawn_at' => null,
	);
	if ( $row ) {
		$wpdb->update( $t, $data, array( 'id' => (int) $row['id'] ) ); // phpcs:ignore
		return (int) $row['id'];
	}
	$data['phone'] = $phone;
	$data['token'] = rzd_sms_token();
	$wpdb->insert( $t, $data ); // phpcs:ignore
	return (int) $wpdb->insert_id;
}

/** Ostatnie zamówienie numeru ze zgodą (bez zmiany zgody). */
function rzd_sms_consent_touch( $phone, $order_id, $name = '' ) {
	global $wpdb;
	rzd_sms_db_ready();
	$phone = rzd_sms_phone( $phone );
	if ( '' === $phone ) {
		return;
	}
	$set = array( 'last_order' => (int) $order_id );
	if ( '' !== $name ) {
		$set['name'] = mb_substr( $name, 0, 100 );
	}
	$wpdb->update( rzd_sms_t( 'consent' ), $set, array( 'phone' => $phone ) ); // phpcs:ignore
}

/** Wycofanie zgody: po id albo tokenie linku rezygnacji. Zwraca numer albo ''. */
function rzd_sms_consent_withdraw( $id = 0, $token = '' ) {
	global $wpdb;
	rzd_sms_db_ready();
	$t   = rzd_sms_t( 'consent' );
	$row = $id ? $wpdb->get_row( $wpdb->prepare( "SELECT id, phone FROM $t WHERE id = %d", (int) $id ), ARRAY_A ) // phpcs:ignore
		: ( '' !== $token ? $wpdb->get_row( $wpdb->prepare( "SELECT id, phone FROM $t WHERE token = %s", substr( preg_replace( '/[^a-z0-9]/', '', strtolower( $token ) ), 0, 16 ) ), ARRAY_A ) : null ); // phpcs:ignore
	if ( ! $row ) {
		return '';
	}
	$wpdb->update( $t, array( 'withdrawn_at' => current_time( 'mysql' ) ), array( 'id' => (int) $row['id'] ) ); // phpcs:ignore
	return (string) $row['phone'];
}

/** Lista zgód: $active – tylko aktywne; $q – szukaj w numerze / imieniu. [ wiersze, łącznie ]. */
function rzd_sms_consent_list( $q = '', $active = true, $limit = 50, $offset = 0, $mask = true ) {
	global $wpdb;
	rzd_sms_db_ready();
	$t     = rzd_sms_t( 'consent' );
	$where = array( $active ? 'withdrawn_at IS NULL' : '1=1' );
	$q     = trim( (string) $q );
	if ( '' !== $q ) {
		$like    = '%' . $wpdb->esc_like( $q ) . '%';
		$digits  = preg_replace( '/\D/', '', $q );
		$where[] = '' !== $digits ? $wpdb->prepare( '(name LIKE %s OR phone LIKE %s)', $like, '%' . $wpdb->esc_like( $digits ) . '%' ) : $wpdb->prepare( 'name LIKE %s', $like );
	}
	$w     = 'WHERE ' . implode( ' AND ', $where );
	$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $t $w" ); // phpcs:ignore
	$rows  = (array) $wpdb->get_results( "SELECT * FROM $t $w ORDER BY consent_at DESC LIMIT " . (int) $offset . ', ' . (int) $limit, ARRAY_A ); // phpcs:ignore
	if ( $mask ) {
		foreach ( $rows as $i => $r ) {
			$rows[ $i ]['phone_masked'] = rzd_sms_mask( $r['phone'] );
			unset( $rows[ $i ]['token'], $rows[ $i ]['ip'] );
		}
	}
	return array( $rows, $total );
}

/** Aktywne zgody od id (kampania – partiami). */
function rzd_sms_consent_batch( $after_id, $limit ) {
	global $wpdb;
	rzd_sms_db_ready();
	$t = rzd_sms_t( 'consent' );
	return (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, phone, name, token FROM $t WHERE withdrawn_at IS NULL AND id > %d ORDER BY id ASC LIMIT %d", (int) $after_id, (int) $limit ), ARRAY_A ); // phpcs:ignore
}

function rzd_sms_consent_count() {
	global $wpdb;
	rzd_sms_db_ready();
	return (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . rzd_sms_t( 'consent' ) . ' WHERE withdrawn_at IS NULL' ); // phpcs:ignore
}

/* ---------- sprzątanie dziennika: 90 dni, raz dziennie ---------- */
add_action( 'init', function () {
	if ( ! wp_next_scheduled( 'rzd_sms_daily' ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'rzd_sms_daily' );
	}
} );
add_action( 'rzd_sms_daily', function () {
	global $wpdb;
	rzd_sms_db_ready();
	$wpdb->query( $wpdb->prepare( 'DELETE FROM ' . rzd_sms_t( 'log' ) . ' WHERE at < %s', gmdate( 'Y-m-d H:i:s', current_time( 'timestamp' ) - 90 * DAY_IN_SECONDS ) ) ); // phpcs:ignore
} );
