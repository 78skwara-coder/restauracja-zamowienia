<?php
/**
 * Moduł 41-sms (2.58.0) – SMS-y przez SMSAPI: powiadomienia o zamówieniach, zgody marketingowe, kampanie, dziennik.
 * Połączenie (token, nadawca, tryb testowy) – Połączenia API (rzd_api: sms_token, sms_from, sms_test).
 * Ustawienia – opcja `rzd_sms`: name (nazwa restauracji w SMS-ach, '' = nazwa sklepu), phone (telefon restauracji),
 * normalize (zamiana polskich liter), max_parts, events { order | way | ready | staff: { on, text [, to, today] } },
 * mkt { on – pole zgody w zamówieniu, consent – treść zgody, optout – dopisek z linkiem rezygnacji, quiet_from/to,
 * price – cena 1 SMS-a w punktach (szacowanie kosztu) }.
 * Treści bez stałych nazw – tylko zmienne {restauracja}, {telefon_restauracji} itd.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Rodzaje powiadomień: klucz => [ nazwa, do kogo, kiedy ]. */
function rzd_sms_events() {
	return array(
		'order' => array( 'Zamówienie przyjęte', 'klient', 'po złożeniu zamówienia' ),
		'way'   => array( 'Kurier w drodze', 'klient', 'status „W dostawie” (dostawa)' ),
		'ready' => array( 'Gotowe do odbioru', 'klient', 'status „W dostawie” przy odbiorze osobistym' ),
		'staff' => array( 'Nowe zamówienie', 'obsługa', 'po złożeniu zamówienia' ),
	);
}

function rzd_sms_default_texts() {
	return array(
		'order'   => '{restauracja}: dziękujemy, {imie}! Zamówienie nr {numer} przyjęte – {termin}. Kwota: {kwota}.',
		'way'     => '{restauracja}: zamówienie nr {numer} jest już w drodze. Tel. {telefon_restauracji}',
		'ready'   => '{restauracja}: zamówienie nr {numer} czeka na odbiór. Do zobaczenia!',
		'staff'   => 'Nowe zamówienie nr {numer}: {kwota}, {termin}, {miejscowosc}. {imie}, tel. {telefon_klienta}',
		'consent' => 'Chcę otrzymywać SMS-y z ofertami i promocjami {restauracja}. Zgodę mogę wycofać w każdej chwili.',
		'optout'  => 'Rezygnacja: {link_rezygnacji}',
	);
}

/** Zmienne powiadomień o zamówieniu: klucz => opis. */
function rzd_sms_order_vars() {
	return array(
		'restauracja'         => 'nazwa restauracji (ustawienia SMS)',
		'telefon_restauracji' => 'telefon restauracji (ustawienia SMS)',
		'imie'                => 'imię klienta',
		'numer'               => 'numer zamówienia',
		'termin'              => '„dostawa śr. 12.11, 12:00–12:30” albo „odbiór …”',
		'data'                => 'dzień dostawy / odbioru',
		'godzina'             => 'godzina / okno',
		'kwota'               => 'kwota zamówienia (brutto)',
		'adres'               => 'adres dostawy',
		'miejscowosc'         => 'miejscowość',
		'telefon_klienta'     => 'telefon klienta',
		'link'                => 'link do podglądu zamówienia',
	);
}

function rzd_sms_mkt_vars() {
	return array( 'restauracja' => 'nazwa restauracji', 'telefon_restauracji' => 'telefon restauracji', 'imie' => 'imię (z ostatniego zamówienia)' );
}

function rzd_sms_settings( $reset = false ) {
	static $s = null;
	if ( $reset ) {
		$s = null;
	}
	if ( null !== $s ) {
		return $s;
	}
	$d   = rzd_sms_default_texts();
	$def = array(
		'name'      => '',
		'phone'     => '',
		'normalize' => 1,
		'max_parts' => 2,
		'events'    => array(
			'order' => array( 'on' => 0, 'text' => $d['order'] ),
			'way'   => array( 'on' => 0, 'text' => $d['way'] ),
			'ready' => array( 'on' => 0, 'text' => $d['ready'] ),
			'staff' => array( 'on' => 0, 'text' => $d['staff'], 'to' => '', 'today' => 0 ),
		),
		'mkt'       => array( 'on' => 0, 'consent' => $d['consent'], 'optout' => $d['optout'], 'quiet_from' => '08:00', 'quiet_to' => '20:00', 'price' => 0.17 ),
	);
	$o = get_option( 'rzd_sms', array() );
	$o = is_array( $o ) ? $o : array();
	$s = array_merge( $def, array_intersect_key( $o, $def ) );
	foreach ( $def['events'] as $k => $e ) {
		$s['events'][ $k ] = array_merge( $e, isset( $o['events'][ $k ] ) && is_array( $o['events'][ $k ] ) ? array_intersect_key( $o['events'][ $k ], $e ) : array() );
	}
	$s['mkt'] = array_merge( $def['mkt'], isset( $o['mkt'] ) && is_array( $o['mkt'] ) ? array_intersect_key( $o['mkt'], $def['mkt'] ) : array() );
	return $s;
}

/** Zapis z panelu (częściowy). [ ok, komunikat ]. */
function rzd_sms_save( $in ) {
	$in = is_array( $in ) ? $in : array();
	$s  = rzd_sms_settings();
	if ( isset( $in['name'] ) ) {
		$s['name'] = mb_substr( sanitize_text_field( (string) $in['name'] ), 0, 40 );
	}
	if ( isset( $in['phone'] ) ) {
		$s['phone'] = mb_substr( preg_replace( '/[^0-9+ \-]/', '', (string) $in['phone'] ), 0, 20 );
	}
	if ( array_key_exists( 'normalize', $in ) ) {
		$s['normalize'] = empty( $in['normalize'] ) ? 0 : 1;
	}
	if ( isset( $in['max_parts'] ) ) {
		$s['max_parts'] = max( 1, min( 6, (int) $in['max_parts'] ) );
	}
	foreach ( array_keys( rzd_sms_events() ) as $k ) {
		if ( ! isset( $in['events'][ $k ] ) || ! is_array( $in['events'][ $k ] ) ) {
			continue;
		}
		$e = $in['events'][ $k ];
		$s['events'][ $k ]['on']   = empty( $e['on'] ) ? 0 : 1;
		$s['events'][ $k ]['text'] = isset( $e['text'] ) ? mb_substr( sanitize_textarea_field( (string) $e['text'] ), 0, 900 ) : $s['events'][ $k ]['text'];
		if ( 'staff' === $k ) {
			$nums = array_filter( array_map( 'rzd_sms_phone', preg_split( '/[\s,;]+/', isset( $e['to'] ) ? (string) $e['to'] : '' ) ) );
			$s['events'][ $k ]['to']    = implode( ', ', array_unique( $nums ) );
			$s['events'][ $k ]['today'] = empty( $e['today'] ) ? 0 : 1;
			if ( $s['events'][ $k ]['on'] && ! $nums ) {
				return array( false, 'Wpisz numer obsługi dla SMS-a „Nowe zamówienie” albo go wyłącz.' );
			}
		}
		if ( $s['events'][ $k ]['on'] && '' === trim( $s['events'][ $k ]['text'] ) ) {
			return array( false, 'Włączony SMS „' . rzd_sms_events()[ $k ][0] . '” nie ma treści.' );
		}
	}
	if ( isset( $in['mkt'] ) && is_array( $in['mkt'] ) ) {
		$m = $in['mkt'];
		$s['mkt']['on']         = empty( $m['on'] ) ? 0 : 1;
		$s['mkt']['consent']    = isset( $m['consent'] ) ? mb_substr( sanitize_textarea_field( (string) $m['consent'] ), 0, 300 ) : $s['mkt']['consent'];
		$s['mkt']['optout']     = isset( $m['optout'] ) ? mb_substr( sanitize_text_field( (string) $m['optout'] ), 0, 80 ) : $s['mkt']['optout'];
		$s['mkt']['quiet_from'] = function_exists( 'rzd_posts_hm' ) ? rzd_posts_hm( isset( $m['quiet_from'] ) ? $m['quiet_from'] : '', $s['mkt']['quiet_from'] ) : $s['mkt']['quiet_from'];
		$s['mkt']['quiet_to']   = function_exists( 'rzd_posts_hm' ) ? rzd_posts_hm( isset( $m['quiet_to'] ) ? $m['quiet_to'] : '', $s['mkt']['quiet_to'] ) : $s['mkt']['quiet_to'];
		if ( isset( $m['price'] ) ) { // cena 1 SMS-a w punktach SMSAPI – tylko do szacowania kosztu kampanii
			$s['mkt']['price'] = max( 0, min( 5, round( (float) str_replace( ',', '.', (string) $m['price'] ), 4 ) ) );
		}
		if ( false === strpos( $s['mkt']['optout'], '{link_rezygnacji}' ) ) {
			return array( false, 'Dopisek o rezygnacji musi zawierać {link_rezygnacji} – każdy SMS marketingowy musi dawać możliwość wypisania się.' );
		}
		if ( $s['mkt']['quiet_to'] <= $s['mkt']['quiet_from'] ) {
			return array( false, 'Godzina „do” musi być późniejsza niż „od”.' );
		}
	}
	update_option( 'rzd_sms', $s, false );
	rzd_sms_settings( true );
	return array( true, 'Zapisano ustawienia SMS.' );
}

/** Nazwa restauracji w SMS-ach – z ustawień, inaczej nazwa sklepu (nigdy wpisana na stałe w kodzie). */
function rzd_sms_name() {
	$n = trim( rzd_sms_settings()['name'] );
	return '' !== $n ? $n : html_entity_decode( get_bloginfo( 'name' ), ENT_QUOTES, 'UTF-8' );
}

/** Numer w formacie 48XXXXXXXXX (Polska domyślnie) albo '' gdy niepoprawny. */
function rzd_sms_phone( $p ) {
	$p = trim( (string) $p );
	$plus = 0 === strpos( $p, '+' );
	$d = preg_replace( '/\D/', '', $p );
	if ( 0 === strpos( $d, '00' ) ) {
		$d    = substr( $d, 2 );
		$plus = true;
	}
	if ( 9 === strlen( $d ) && ! $plus ) {
		$d = '48' . $d;
	}
	return strlen( $d ) >= 11 && strlen( $d ) <= 15 ? $d : '';
}

/** Numer do pokazania (zamaskowany): 48 600 *** 789. */
function rzd_sms_mask( $p ) {
	$p = (string) $p;
	return strlen( $p ) >= 11 ? substr( $p, 0, 2 ) . ' ' . substr( $p, 2, 3 ) . ' *** ' . substr( $p, -3 ) : $p;
}

/** Podstawienie zmiennych {klucz}. Nieznane zmienne znikają. */
function rzd_sms_render( $text, $vars ) {
	return trim( preg_replace( '/\s{2,}/', ' ', preg_replace_callback( '/\{([a-z_]+)\}/', function ( $m ) use ( $vars ) {
		return isset( $vars[ $m[1] ] ) ? (string) $vars[ $m[1] ] : '';
	}, (string) $text ) ) );
}

/** Zamiana polskich liter i typograficznych znaków na zwykłe (SMS 160 znaków zamiast 70). */
function rzd_sms_plain( $t ) {
	$t = strtr( (string) $t, array( '„' => '"', '”' => '"', '“' => '"', '‘' => "'", '’' => "'", '–' => '-', '—' => '-', '…' => '...', "\u{00A0}" => ' ' ) );
	return function_exists( 'remove_accents' ) ? remove_accents( $t ) : $t;
}

/** Tekst gotowy do wysyłki (z normalizacją wg ustawień). */
function rzd_sms_final( $t ) {
	return rzd_sms_settings()['normalize'] ? rzd_sms_plain( $t ) : trim( (string) $t );
}

/** Liczba części SMS: GSM-7 160/153, z polskimi literami (UCS-2) 70/67. [ części, znaki, unicode ]. */
function rzd_sms_parts( $t ) {
	$t   = (string) $t;
	$gsm = "@£\$¥èéùìòÇ\nØø\rÅåΔ_ΦΓΛΩΠΨΣΘΞÆæßÉ !\"#¤%&'()*+,-./0123456789:;<=>?¡ABCDEFGHIJKLMNOPQRSTUVWXYZÄÖÑÜ§¿abcdefghijklmnopqrstuvwxyzäöñüà";
	$ext = '^{}\\[~]|€';
	$uni = false;
	$len = 0;
	foreach ( preg_split( '//u', $t, -1, PREG_SPLIT_NO_EMPTY ) as $ch ) {
		if ( false !== mb_strpos( $ext, $ch ) ) {
			$len += 2;
		} elseif ( false !== mb_strpos( $gsm, $ch ) ) {
			$len += 1;
		} else {
			$uni = true;
			break;
		}
	}
	if ( $uni ) {
		$len = mb_strlen( $t );
		return array( $len <= 70 ? 1 : (int) ceil( $len / 67 ), $len, true );
	}
	return array( $len <= 160 ? 1 : (int) ceil( $len / 153 ), $len, false );
}

/** Zmienne zamówienia. */
function rzd_sms_order_data( $order ) {
	$s      = rzd_sms_settings();
	$pickup = '1' === (string) $order->get_meta( '_rzd_pickup' );
	$date   = (string) $order->get_meta( '_dc_delivery_date' );
	$time   = (string) $order->get_meta( '_dc_delivery_time' );
	$dl     = $date && function_exists( 'rzd_dc_date_label' ) ? rzd_dc_date_label( $date ) : $date;
	$tl     = $time && function_exists( 'rzd_dc_time_window_label' ) ? rzd_dc_time_window_label( $time, $date ) : $time;
	$when   = trim( $dl . ( $tl ? ', ' . $tl : '' ) );
	$addr   = trim( $order->get_shipping_address_1() ? $order->get_shipping_address_1() . ' ' . $order->get_shipping_address_2() : $order->get_billing_address_1() . ' ' . $order->get_billing_address_2() );
	$city   = $order->get_shipping_city() ? $order->get_shipping_city() : $order->get_billing_city();
	return array(
		'restauracja'         => rzd_sms_name(),
		'telefon_restauracji' => $s['phone'],
		'imie'                => $order->get_billing_first_name(),
		'numer'               => $order->get_order_number(),
		'termin'              => '' !== $when ? ( $pickup ? 'odbiór ' : 'dostawa ' ) . $when : '',
		'data'                => $dl,
		'godzina'             => $tl,
		'kwota'               => number_format( (float) $order->get_total(), 2, ',', ' ' ) . ' zł',
		'adres'               => $pickup ? 'odbiór osobisty' : $addr,
		'miejscowosc'         => $pickup ? '' : $city,
		'telefon_klienta'     => $order->get_billing_phone(),
		'link'                => $order->get_checkout_order_received_url(),
	);
}

/** Przykładowe zmienne do podglądu i SMS-a testowego. */
function rzd_sms_sample_vars() {
	$s = rzd_sms_settings();
	return array(
		'restauracja' => rzd_sms_name(), 'telefon_restauracji' => $s['phone'], 'imie' => 'Anna', 'numer' => '1234',
		'termin' => 'dostawa śr. 12.11, 12:00–12:30', 'data' => 'śr. 12.11', 'godzina' => '12:00–12:30', 'kwota' => '47,00 zł',
		'adres' => 'ul. Przykładowa 5/2', 'miejscowosc' => 'Piła', 'telefon_klienta' => '600 100 200', 'link' => home_url( '/z/1234' ),
		'link_rezygnacji' => home_url( '/?sms-stop=abcd1234' ),
	);
}
