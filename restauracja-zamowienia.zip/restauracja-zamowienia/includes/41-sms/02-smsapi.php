<?php
/**
 * Moduł 41-sms – połączenie z SMSAPI (REST, token OAuth „Bearer”). Wysyłka: POST https://api.smsapi.pl/sms.do
 * (to, message, from, format=json, encoding=utf-8, test=1 w trybie testowym); przy błędzie połączenia zapasowy
 * api2.smsapi.pl. Konto: GET /profile (punkty), GET /sms/sendernames (nazwy nadawcy). Każda wysyłka → dziennik.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function rzd_sms_bases() {
	return apply_filters( 'rzd_sms_bases', array( 'https://api.smsapi.pl/', 'https://api2.smsapi.pl/' ) );
}

function rzd_sms_ready() {
	return '' !== rzd_api_secret( 'sms_token' );
}

/** Zapytanie do SMSAPI z zapasowym adresem. [ ok, tablica JSON | komunikat ]. */
function rzd_sms_http( $method, $path, $params = array() ) {
	$tok = rzd_api_secret( 'sms_token' );
	if ( '' === $tok ) {
		return array( false, 'SMS nie jest połączony (Panel → Połączenia API → SMS).' );
	}
	$last = 'Brak odpowiedzi z SMSAPI.';
	foreach ( rzd_sms_bases() as $base ) {
		$args = array( 'timeout' => 20, 'headers' => array( 'Authorization' => 'Bearer ' . $tok, 'Accept' => 'application/json' ) );
		if ( 'POST' === $method ) {
			$args['body'] = $params;
			$r = wp_remote_post( $base . ltrim( $path, '/' ), $args );
		} else {
			$r = wp_remote_get( add_query_arg( $params, $base . ltrim( $path, '/' ) ), $args );
		}
		if ( is_wp_error( $r ) ) {
			$last = 'Nie udało się połączyć z SMSAPI (' . $r->get_error_message() . ').';
			continue; // zapasowy serwer
		}
		$code = (int) wp_remote_retrieve_response_code( $r );
		$j    = json_decode( (string) wp_remote_retrieve_body( $r ), true );
		if ( 401 === $code || ( is_array( $j ) && isset( $j['error'] ) && in_array( (int) $j['error'], array( 101, 123 ), true ) ) ) {
			return array( false, 'SMSAPI: nieprawidłowy token – wygeneruj nowy w panelu SMSAPI (Ustawienia API → Tokeny API).' );
		}
		if ( is_array( $j ) && isset( $j['error'] ) && ! isset( $j['count'] ) && ! isset( $j['collection'] ) ) {
			return array( false, rzd_sms_error_text( (int) $j['error'], isset( $j['message'] ) ? (string) $j['message'] : '' ) );
		}
		if ( $code >= 500 ) {
			$last = 'SMSAPI chwilowo nie odpowiada (' . $code . ').';
			continue;
		}
		if ( ! is_array( $j ) ) {
			return array( false, 'SMSAPI: nieczytelna odpowiedź (' . $code . ').' );
		}
		return array( true, $j );
	}
	return array( false, $last );
}

function rzd_sms_error_text( $code, $msg ) {
	$map = array(
		103 => 'brak punktów na koncie SMSAPI – doładuj konto',
		13  => 'brak poprawnych numerów odbiorców',
		14  => 'nazwa nadawcy nie jest zatwierdzona w SMSAPI – sprawdź w Połączeniach API',
		11  => 'wiadomość za długa albo pusta',
		102 => 'konto SMSAPI zablokowane lub nieaktywne',
	);
	return 'SMSAPI: ' . ( isset( $map[ $code ] ) ? $map[ $code ] : $msg ) . ' (kod ' . $code . ').';
}

/**
 * Wysłanie jednej treści do jednego lub kilku numerów. $o: kind (order|way|ready|staff|mkt|test), ref (zamówienie /
 * kampania), date (znacznik – wysyłka zaplanowana w SMSAPI). [ ok, liczba wysłanych | komunikat ].
 */
function rzd_sms_send( $to, $text, $o = array() ) {
	$nums = array_values( array_unique( array_filter( array_map( 'rzd_sms_phone', (array) $to ) ) ) );
	$kind = isset( $o['kind'] ) ? (string) $o['kind'] : 'test';
	$ref  = isset( $o['ref'] ) ? (int) $o['ref'] : 0;
	$msg  = rzd_sms_final( $text );
	if ( ! $nums ) {
		rzd_sms_log( '', $kind, $ref, 0, 'error', 'Brak poprawnego numeru.', '', $msg );
		return array( false, 'Brak poprawnego numeru telefonu.' );
	}
	if ( '' === $msg ) {
		return array( false, 'Pusta treść SMS-a.' );
	}
	list( $parts ) = rzd_sms_parts( $msg );
	$max           = (int) rzd_sms_settings()['max_parts'];
	if ( $parts > $max ) {
		foreach ( $nums as $n ) {
			rzd_sms_log( $n, $kind, $ref, $parts, 'error', 'Za długi: ' . $parts . ' SMS-y (limit ' . $max . ').', '', $msg );
		}
		return array( false, 'SMS za długi: ' . $parts . ' części, limit w ustawieniach ' . $max . '. Skróć treść albo podnieś limit.' );
	}
	$api = rzd_api_settings();
	$p   = array( 'to' => implode( ',', $nums ), 'message' => $msg, 'format' => 'json', 'encoding' => 'utf-8' );
	if ( '' !== $api['sms_from'] ) {
		$p['from'] = $api['sms_from'];
	}
	if ( '1' === $api['sms_test'] ) {
		$p['test'] = 1; // SMSAPI przyjmuje, ale nie wysyła i nie pobiera opłat
	}
	if ( ! empty( $o['date'] ) ) {
		$p['date'] = (int) $o['date'];
	}
	list( $ok, $j ) = rzd_sms_http( 'POST', 'sms.do', $p );
	if ( ! $ok ) {
		foreach ( $nums as $n ) {
			rzd_sms_log( $n, $kind, $ref, $parts, 'error', $j, '', $msg );
		}
		return array( false, $j );
	}
	$sent = 0;
	foreach ( isset( $j['list'] ) ? (array) $j['list'] : array() as $it ) {
		$n = isset( $it['number'] ) ? (string) $it['number'] : '';
		rzd_sms_log( $n, $kind, $ref, $parts, '1' === $api['sms_test'] ? 'test' : 'sent', '', isset( $it['id'] ) ? (string) $it['id'] : '', $msg );
		$sent++;
	}
	if ( ! $sent ) {
		foreach ( $nums as $n ) {
			rzd_sms_log( $n, $kind, $ref, $parts, 'sent', '', '', $msg );
		}
		$sent = count( $nums );
	}
	return array( true, $sent );
}

/** Konto: punkty i nazwy nadawcy. [ ok, { points, senders [ {name, def, status} ] } | komunikat ]. */
function rzd_sms_account() {
	list( $ok, $j ) = rzd_sms_http( 'GET', 'profile' );
	if ( ! $ok ) {
		return array( false, $j );
	}
	$out = array( 'points' => isset( $j['points'] ) ? (float) $j['points'] : 0, 'name' => isset( $j['name'] ) ? (string) $j['name'] : '', 'senders' => array() );
	list( $ok2, $sn ) = rzd_sms_http( 'GET', 'sms/sendernames' );
	if ( $ok2 ) {
		foreach ( isset( $sn['collection'] ) ? (array) $sn['collection'] : array() as $x ) {
			$out['senders'][] = array( 'name' => isset( $x['sender'] ) ? (string) $x['sender'] : '', 'def' => ! empty( $x['is_default'] ), 'status' => isset( $x['status'] ) ? (string) $x['status'] : '' );
		}
	}
	return array( true, $out );
}
