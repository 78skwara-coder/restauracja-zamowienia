<?php
/**
 * Moduł 38-posty – „Post dnia” na Facebooka (2.48.0): ustawienia, posty (typ treści `rzd_fbpost`) i dane zestawu
 * na dzień. Przepływ: zestaw + dzień → dania i zdjęcia → Gemini pisze sekcje „AI” wg wskazówek → stałe sekcje
 * doklejane → podgląd / poprawki → zatwierdzenie → Facebook publikuje o wybranej godzinie (domyślnie dzień
 * wcześniej o 20:00). Automat o 19:00 przygotowuje SZKIC na jutro, gdy posta jeszcze nie ma – bez zatwierdzenia
 * nic nie idzie na Facebooka.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ---------- ustawienia ---------- */
function rzd_posts_default_sections() {
	return array(
		array( 'k' => 'tytul', 'n' => 'Tytuł', 'm' => 'ai', 't' => '' ),
		array( 'k' => 'wstep', 'n' => 'Wstęp', 'm' => 'ai', 't' => '' ),
		array( 'k' => 'menu', 'n' => 'Menu', 'm' => 'ai', 't' => '' ),
		array( 'k' => 'rozwiniecie', 'n' => 'Rozwinięcie', 'm' => 'ai', 't' => '' ),
		array( 'k' => 'zaproszenie', 'n' => 'Zaproszenie', 'm' => 'ai', 't' => '' ),
		array( 'k' => 'link', 'n' => 'Link', 'm' => 'static', 't' => '🛵 Zamówienia z dostawą – link znajdziesz w naszym profilu.' ),
		array( 'k' => 'kontakt', 'n' => 'Kontakt', 'm' => 'static', 't' => rzd_posts_default_contact() ),
		array( 'k' => 'hashtagi', 'n' => 'Hashtagi', 'm' => 'ai', 't' => '' ),
	);
}

/** Kontakt z wizytówki (Panel → SEO): nazwa, adres, telefon, e-mail – każde w osobnej linii. */
function rzd_posts_default_contact() {
	$s = function_exists( 'rzd_seo_settings' ) ? rzd_seo_settings() : array();
	$l = array();
	$l[] = '📍 ' . trim( ( function_exists( 'rzd_seo_name' ) ? rzd_seo_name() : get_bloginfo( 'name' ) ) );
	$a = trim( implode( ', ', array_filter( array( isset( $s['street'] ) ? $s['street'] : '', trim( ( isset( $s['postcode'] ) ? $s['postcode'] : '' ) . ' ' . ( isset( $s['city'] ) ? $s['city'] : '' ) ) ) ) ) );
	if ( '' !== $a ) {
		$l[] = $a;
	}
	if ( ! empty( $s['phone'] ) ) {
		$l[] = '📞 ' . $s['phone'];
	}
	if ( ! empty( $s['email'] ) ) {
		$l[] = '✉️ ' . $s['email'];
	}
	return implode( "\n", $l );
}

function rzd_posts_default_instructions() {
	return implode( "\n", array(
		'Piszesz post na Facebooka restauracji z zapowiedzią obiadu dnia na jutro. Post publikujemy wieczorem dzień wcześniej.',
		'Pisz po polsku, ciepło i apetycznie, w stylu lokalnej restauracji stawiającej na jakość.',
		'Emoji używaj kreatywnie i różnorodnie – nie powtarzaj w każdym poście tego samego zestawu.',
		'Nawiązania do pory roku tylko czasem (np. gdy zmienia się sezon), nie w każdym poście.',
		'Zawsze poprawiaj nazwy dań na właściwą pisownię (np. „devolay” → „de volaille”).',
		'Nigdy nie wstawiaj linków i nie pisz „link w pierwszym komentarzu” – o zamówieniach odsyłaj do profilu (bio).',
		'Nie opisuj zdjęć – to tylko ilustracja posta.',
		'Nigdy nie pisz, że jest tanio – podkreślaj jakość i smak, to nasza największa siła.',
		'Nie podawaj cen.',
	) );
}

function rzd_posts_defaults() {
	return array(
		'gemini_key'   => '',
		'model'        => '',
		'ai_images'    => 0,
		'instructions' => rzd_posts_default_instructions(),
		'sections'     => rzd_posts_default_sections(),
		'fb_page'      => '',
		'fb_token'     => '',
		'gen_time'     => '19:00',
		'pub_time'     => '20:00',
		'auto'         => 1,
		'mail_to'      => '',
	);
}

function rzd_posts_settings( $reset = false ) {
	static $s = null;
	if ( $reset ) {
		$s = null;
	}
	if ( null !== $s ) {
		return $s;
	}
	$o = get_option( 'rzd_posts', array() );
	$s = wp_parse_args( is_array( $o ) ? $o : array(), rzd_posts_defaults() );
	if ( ! is_array( $s['sections'] ) || ! $s['sections'] ) {
		$s['sections'] = rzd_posts_default_sections();
	}
	return $s;
}

/** Sekrety: stała w wp-config.php (RZD_GEMINI_KEY, RZD_FB_TOKEN) albo zaszyfrowane w bazie (jak hasło poczty). */
function rzd_posts_secret( $field ) {
	$const = array( 'gemini_key' => 'RZD_GEMINI_KEY', 'fb_token' => 'RZD_FB_TOKEN' );
	if ( isset( $const[ $field ] ) && defined( $const[ $field ] ) ) {
		return (string) constant( $const[ $field ] );
	}
	$s = rzd_posts_settings();
	return function_exists( 'rzd_mail_decrypt' ) ? rzd_mail_decrypt( (string) $s[ $field ] ) : '';
}

function rzd_posts_hm( $v, $def ) {
	$v = trim( (string) $v );
	return preg_match( '/^([01]?\d|2[0-3]):[0-5]\d$/', $v ) ? str_pad( $v, 5, '0', STR_PAD_LEFT ) : $def;
}

/** Zapis ustawień z panelu. Sekret pusty = bez zmian; „-” = usuń. Zwraca [ ok, komunikat ]. */
function rzd_posts_save_settings( $in ) {
	$in  = is_array( $in ) ? $in : array();
	$old = rzd_posts_settings();
	$s   = $old;
	foreach ( array( 'gemini_key', 'fb_token' ) as $f ) {
		$v = isset( $in[ $f ] ) ? trim( (string) $in[ $f ] ) : '';
		if ( '-' === $v ) {
			$s[ $f ] = '';
		} elseif ( '' !== $v ) {
			$s[ $f ] = function_exists( 'rzd_mail_encrypt' ) ? rzd_mail_encrypt( $v ) : '';
		}
	}
	$s['model']        = isset( $in['model'] ) ? preg_replace( '/[^a-z0-9._\-\/]/i', '', (string) $in['model'] ) : $old['model'];
	$s['ai_images']    = array_key_exists( 'ai_images', $in ) ? ( empty( $in['ai_images'] ) ? 0 : 1 ) : $old['ai_images']; // zapis częściowy – bez zmian
	$s['instructions'] = isset( $in['instructions'] ) ? mb_substr( sanitize_textarea_field( (string) $in['instructions'] ), 0, 4000 ) : $old['instructions'];
	$s['fb_page']      = isset( $in['fb_page'] ) ? preg_replace( '/\D/', '', (string) $in['fb_page'] ) : $old['fb_page'];
	$s['gen_time']     = rzd_posts_hm( isset( $in['gen_time'] ) ? $in['gen_time'] : '', $old['gen_time'] );
	$s['pub_time']     = rzd_posts_hm( isset( $in['pub_time'] ) ? $in['pub_time'] : '', $old['pub_time'] );
	$s['auto']         = array_key_exists( 'auto', $in ) ? ( empty( $in['auto'] ) ? 0 : 1 ) : $old['auto'];
	$s['mail_to']      = isset( $in['mail_to'] ) ? implode( ', ', array_filter( array_map( 'sanitize_email', array_map( 'trim', explode( ',', (string) $in['mail_to'] ) ) ) ) ) : $old['mail_to'];
	if ( isset( $in['sections'] ) && is_array( $in['sections'] ) ) {
		$secs = array();
		$keys = array();
		foreach ( $in['sections'] as $i => $r ) {
			$n = mb_substr( sanitize_text_field( isset( $r['n'] ) ? (string) $r['n'] : '' ), 0, 40 );
			if ( '' === $n ) {
				continue;
			}
			$k = sanitize_key( isset( $r['k'] ) && '' !== $r['k'] ? $r['k'] : remove_accents( $n ) );
			$k = '' === $k || isset( $keys[ $k ] ) ? 's' . $i : $k;
			$keys[ $k ] = 1;
			$secs[]     = array(
				'k' => $k,
				'n' => $n,
				'm' => isset( $r['m'] ) && 'static' === $r['m'] ? 'static' : 'ai',
				't' => mb_substr( sanitize_textarea_field( isset( $r['t'] ) ? (string) $r['t'] : '' ), 0, 1000 ),
			);
		}
		if ( ! $secs ) {
			return array( false, 'Post musi mieć choć jedną sekcję.' );
		}
		if ( ! array_filter( $secs, function ( $x ) { return 'ai' === $x['m']; } ) ) {
			return array( false, 'Choć jedna sekcja musi być pisana przez AI.' );
		}
		$s['sections'] = $secs;
	}
	if ( $s['pub_time'] <= $s['gen_time'] ) {
		return array( false, 'Godzina publikacji musi być późniejsza niż godzina przygotowania szkicu.' );
	}
	update_option( 'rzd_posts', $s, false );
	rzd_posts_settings( true );
	if ( function_exists( 'rzd_posts_schedule_ensure' ) ) {
		rzd_posts_schedule_ensure( true );
	}
	return array( true, 'Zapisano ustawienia postów.' );
}

/* ---------- posty (historia) ---------- */
add_action( 'init', function () {
	register_post_type( 'rzd_fbpost', array(
		'label'           => 'Posty dnia',
		'public'          => false,
		'show_ui'         => false,
		'show_in_rest'    => false,
		'supports'        => array( 'title', 'editor' ),
		'capability_type' => 'post',
	) );
} );

function rzd_posts_status_labels() {
	return array( 'draft' => 'Szkic – czeka na zatwierdzenie', 'scheduled' => 'Zaplanowany na Facebooku', 'published' => 'Opublikowany', 'error' => 'Błąd' );
}

/** Post jako tablica dla panelu. */
function rzd_posts_get( $id ) {
	$p = get_post( (int) $id );
	if ( ! $p || 'rzd_fbpost' !== $p->post_type ) {
		return null;
	}
	$photos = get_post_meta( $p->ID, '_photos', true );
	return array(
		'id'     => (int) $p->ID,
		'day'    => (string) get_post_meta( $p->ID, '_day', true ),
		'set'    => (int) get_post_meta( $p->ID, '_set', true ),
		'status' => (string) get_post_meta( $p->ID, '_status', true ),
		'text'   => (string) $p->post_content,
		'photos' => is_array( $photos ) ? array_values( $photos ) : array(),
		'when'   => (int) get_post_meta( $p->ID, '_when', true ),
		'fb'     => (string) get_post_meta( $p->ID, '_fb_id', true ),
		'err'    => (string) get_post_meta( $p->ID, '_err', true ),
		'src'    => (string) get_post_meta( $p->ID, '_src', true ),
		'extra'  => (string) get_post_meta( $p->ID, '_extra', true ),
		'by'     => (string) get_post_meta( $p->ID, '_by', true ),
		'date'   => get_post_time( 'U', true, $p ),
	);
}

/** Posty na dzień dania (bez błędnych i usuniętych). */
function rzd_posts_for_day( $day, $with_errors = false ) {
	$ids = get_posts( array(
		'post_type'   => 'rzd_fbpost',
		'post_status' => 'publish',
		'numberposts' => 20,
		'fields'      => 'ids',
		'meta_query'  => array( array( 'key' => '_day', 'value' => $day ) ), // phpcs:ignore
	) );
	$out = array();
	foreach ( $ids as $id ) {
		$p = rzd_posts_get( $id );
		if ( $p && ( $with_errors || 'error' !== $p['status'] ) ) {
			$out[] = $p;
		}
	}
	return $out;
}

function rzd_posts_save_post( $data ) {
	$id = isset( $data['id'] ) ? (int) $data['id'] : 0;
	$arr = array(
		'post_type'    => 'rzd_fbpost',
		'post_status'  => 'publish',
		'post_title'   => 'Post dnia ' . $data['day'],
		'post_content' => (string) $data['text'],
	);
	if ( $id ) {
		$arr['ID'] = $id;
		wp_update_post( wp_slash( $arr ) );
	} else {
		$id = wp_insert_post( wp_slash( $arr ) );
	}
	foreach ( array( 'day', 'set', 'status', 'photos', 'when', 'fb_id', 'err', 'src', 'extra', 'by' ) as $k ) {
		if ( array_key_exists( $k, $data ) ) {
			update_post_meta( $id, '_' . $k, $data[ $k ] );
		}
	}
	return (int) $id;
}

/* ---------- zestaw na dzień ---------- */
function rzd_posts_sets() {
	$out = array();
	foreach ( wc_get_products( array( 'status' => 'publish', 'limit' => 50, 'return' => 'ids' ) ) as $pid ) {
		if ( function_exists( 'rzd_zestaw_is_set_product' ) && rzd_zestaw_is_set_product( $pid ) && ! ( function_exists( 'rzd_seo_hidden_product' ) && rzd_seo_hidden_product( $pid ) ) ) {
			$out[] = array( 'id' => (int) $pid, 'name' => get_the_title( $pid ) );
		}
	}
	return $out;
}

/** Zdjęcie do posta: [ id załącznika (0 = plik zestawu), url do podglądu, path pliku do wysłania ]. */
function rzd_posts_photo( $att_id ) {
	$att_id = (int) $att_id;
	$path   = $att_id ? get_attached_file( $att_id ) : '';
	$url    = $att_id ? wp_get_attachment_image_url( $att_id, 'large' ) : '';
	return ( $path && $url ) ? array( 'id' => $att_id, 'url' => $url ) : null;
}

/**
 * Dania zestawu na dzień (najgłębszy składnik – jak lista zamówień) + podpowiedź zdjęć.
 * [ set, setName, day, dishes [ [id, name, desc, role] ], photos [ [id, url] ] ].
 */
function rzd_posts_day_data( $set_id, $day ) {
	$set_id = (int) $set_id;
	$dishes = array();
	$photos = array();
	if ( function_exists( 'rzd_zestaw_get_active_components' ) ) {
		$active = rzd_zestaw_get_active_components( $set_id, $day );
		foreach ( (array) $active['main'] as $p ) {
			if ( (int) $p->get_id() === $set_id ) {
				continue;
			}
			$role     = isset( $active['roles'][ $p->get_id() ] ) ? (array) $active['roles'][ $p->get_id() ] : array();
			$dishes[] = array(
				'id'   => (int) $p->get_id(),
				'name' => $p->get_name(),
				'desc' => trim( wp_strip_all_tags( $p->get_short_description() ? $p->get_short_description() : $p->get_description() ) ),
				'role' => isset( $role['label'] ) ? (string) $role['label'] : '',
			);
			$ph = rzd_posts_photo( $p->get_image_id() );
			if ( $ph ) {
				$photos[] = $ph;
			}
		}
	}
	if ( ! $photos ) {
		$ph = rzd_posts_photo( get_post_thumbnail_id( $set_id ) );
		if ( $ph ) {
			$photos[] = $ph;
		}
	}
	return array( 'set' => $set_id, 'setName' => get_the_title( $set_id ), 'day' => $day, 'dishes' => $dishes, 'photos' => $photos );
}

/** Domyślny moment publikacji posta na dzień $day: dzień wcześniej o godzinie publikacji. */
function rzd_posts_default_when( $day ) {
	$s  = rzd_posts_settings();
	$dt = DateTime::createFromFormat( 'Y-m-d H:i', $day . ' ' . $s['pub_time'], wp_timezone() );
	if ( ! $dt ) {
		return 0;
	}
	$dt->modify( '-1 day' );
	return $dt->getTimestamp();
}

/** Najbliższe dni (od jutra), w które zestaw ma dania – plan tygodnia. */
function rzd_posts_week( $days = 7 ) {
	$sets = rzd_posts_sets();
	$out  = array();
	$d    = new DateTime( current_time( 'Y-m-d' ), wp_timezone() );
	for ( $i = 1; $i <= $days; $i++ ) {
		$d->modify( '+1 day' );
		$day = $d->format( 'Y-m-d' );
		foreach ( $sets as $set ) {
			$dd = rzd_posts_day_data( $set['id'], $day );
			if ( ! $dd['dishes'] ) {
				continue;
			}
			$posts = rzd_posts_for_day( $day, true );
			$out[] = array(
				'day'    => $day,
				'label'  => ucfirst( rzd_dc_date_label( $day ) ),
				'set'    => $set['id'],
				'setName' => $set['name'],
				'dishes' => array_map( function ( $x ) { return $x['name']; }, $dd['dishes'] ),
				'posts'  => $posts,
				'when'   => rzd_posts_default_when( $day ),
			);
			break; // jeden zestaw dnia na dzień – pierwszy z daniami
		}
	}
	return $out;
}
