<?php
/**
 * Moduł 38-posty – „Post dnia” na Facebooka (2.48.0): ustawienia, posty (typ treści `rzd_fbpost`) i dane zestawu
 * na dzień. Przepływ: zestaw + dzień → dania i zdjęcia → Gemini pisze sekcje „AI” wg wskazówek → stałe sekcje
 * doklejane → podgląd / poprawki → zatwierdzenie → Facebook publikuje o wybranej godzinie (domyślnie dzień
 * wcześniej o 20:00). Automat o 19:00 przygotowuje SZKIC na jutro, gdy posta jeszcze nie ma – bez zatwierdzenia
 * nic nie idzie na Facebooka.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ---------- ustawienia ---------- */
/**
 * Sekcje posta (2.48.2): k – klucz, n – nazwa, m – ai|static, t – stały tekst (tryb static), h – wskazówki dla AI
 * do tej sekcji (tryb ai; puste = AI pisze według ogólnych wskazówek), on – aktywna (nieaktywna nie idzie do AI
 * i nie trafia do posta). t i h są osobno, więc zmiana trybu nie gubi tekstu. (2.49.0) ty – w jakich postach jest
 * sekcja: set (zestaw dnia), product (post o produkcie), topic (dowolny temat); „Menu” domyślnie tylko w zestawie.
 * (2.49.1) sb / sa – puste linie nad / pod sekcją (0–3; domyślnie 0 / 1 = jak wcześniej: jedna pusta linia między
 * sekcjami). Między dwiema sekcjami liczy się większa z wartości (pod wyższą, nad niższą) – jak marginesy w CSS.
 */
function rzd_posts_kinds() {
	return array( 'set' => 'Zestaw dnia', 'product' => 'Produkt', 'topic' => 'Dowolny temat' );
}

function rzd_posts_default_sections() {
	return array(
		array( 'k' => 'tytul', 'n' => 'Tytuł', 'm' => 'ai', 't' => '', 'h' => '', 'on' => 1, 'ty' => array( 'set', 'product', 'topic' ) ),
		array( 'k' => 'wstep', 'n' => 'Wstęp', 'm' => 'ai', 't' => '', 'h' => '', 'on' => 1, 'ty' => array( 'set', 'product', 'topic' ) ),
		array( 'k' => 'menu', 'n' => 'Menu', 'm' => 'ai', 't' => '', 'h' => '', 'on' => 1, 'ty' => array( 'set' ) ),
		array( 'k' => 'rozwiniecie', 'n' => 'Rozwinięcie', 'm' => 'ai', 't' => '', 'h' => '', 'on' => 1, 'ty' => array( 'set', 'product', 'topic' ) ),
		array( 'k' => 'zaproszenie', 'n' => 'Zaproszenie', 'm' => 'ai', 't' => '', 'h' => '', 'on' => 1, 'ty' => array( 'set', 'product', 'topic' ) ),
		array( 'k' => 'link', 'n' => 'Link', 'm' => 'static', 't' => '🛵 Zamówienia z dostawą – link znajdziesz w naszym profilu.', 'h' => '', 'on' => 1, 'ty' => array( 'set', 'product', 'topic' ) ),
		array( 'k' => 'kontakt', 'n' => 'Kontakt', 'm' => 'static', 't' => rzd_posts_default_contact(), 'h' => '', 'on' => 1, 'ty' => array( 'set', 'product', 'topic' ) ),
		array( 'k' => 'hashtagi', 'n' => 'Hashtagi', 'm' => 'ai', 't' => '', 'h' => '', 'on' => 1, 'ty' => array( 'set', 'product', 'topic' ) ),
	);
}

/** Kontakt z wizytówki (Panel → SEO): nazwa, adres, telefon, e-mail – każde w osobnej linii. */
function rzd_posts_default_contact() {
	$s = function_exists( 'rzd_seo_settings' ) ? rzd_seo_settings() : array();
	$l = array();
	$l[] = '📍 ' . trim( ( function_exists( 'rzd_seo_name' ) ? rzd_seo_name() : get_bloginfo( 'name' ) ) );
	$a = trim( implode( ', ', array_filter( array( isset( $s['street'] ) ? $s['street'] : '', trim( ( isset( $s['postcode'] ) ? $s['postcode'] : '' ) . ' ' . ( isset( $s['city'] ) ? $s['city'] : '' ) ) ) ) ) );
	if ( '' !== $a ) {
		$l[] = $a;
	}
	if ( ! empty( $s['phone'] ) ) {
		$l[] = '📞 ' . $s['phone'];
	}
	if ( ! empty( $s['email'] ) ) {
		$l[] = '✉️ ' . $s['email'];
	}
	return implode( "\n", $l );
}

function rzd_posts_default_instructions() {
	return implode( "\n", array(
		'Piszesz posty na Facebooka restauracji.',
		'Pisz po polsku, ciepło i apetycznie, w stylu lokalnej restauracji stawiającej na jakość.',
		'Emoji używaj kreatywnie i różnorodnie – nie powtarzaj w każdym poście tego samego zestawu.',
		'Nawiązania do pory roku tylko czasem (np. gdy zmienia się sezon), nie w każdym poście.',
		'Zawsze poprawiaj nazwy dań na właściwą pisownię (np. „devolay” → „de volaille”).',
		'Nigdy nie wstawiaj linków i nie pisz „link w pierwszym komentarzu” – o zamówieniach odsyłaj do profilu (bio).',
		'Nie opisuj zdjęć – to tylko ilustracja posta.',
		'Nigdy nie pisz, że jest tanio – podkreślaj jakość i smak, to nasza największa siła.',
		'Nie podawaj cen.',
	) );
}

/**
 * (2.49.1) „O czym jest post” – osobno dla każdego rodzaju; do AI idą zasady wspólne (instructions) + tylko opis
 * rodzaju tworzonego posta. Wcześniej zasady wspólne zaczynały się od zdania o obiedzie dnia na jutro i szły też
 * do postów o produkcie i na dowolny temat (sprzeczne polecenia).
 */
function rzd_posts_default_about() {
	return array(
		'set'     => 'Zapowiedź obiadu dnia na jutro. Post publikujemy wieczorem dzień wcześniej, więc piszesz o „jutrze”.',
		'product' => 'Post o jednej pozycji z naszej karty – zachęć do zamówienia. Nie zapowiadaj obiadu dnia.',
		'topic'   => 'Post na temat podany przez restaurację – trzymaj się tematu. Nie zapowiadaj obiadu dnia, jeśli temat go nie dotyczy.',
	);
}

/** Pierwsze zdanie domyślnych zasad sprzed 2.49.1 – przy migracji przenoszone do „O czym jest post” → Zestaw. */
function rzd_posts_old_first_line() {
	return 'Piszesz post na Facebooka restauracji z zapowiedzią obiadu dnia na jutro. Post publikujemy wieczorem dzień wcześniej.';
}

/** Uwaga w Ustawieniach: zasady wspólne idą do każdego rodzaju posta, a wyglądają na pisane pod obiad dnia. */
function rzd_posts_instructions_warn( $s = null ) {
	$s = $s ? $s : rzd_posts_settings();
	return preg_match( '/obiad|jutr|zestaw\w* dnia/iu', (string) $s['instructions'] )
		? 'Zasady wspólne idą do wszystkich rodzajów postów (też o produkcie i na dowolny temat), a wspominają obiad / zestaw / jutro. Przenieś takie zdania do „O czym jest post” → Zestaw dnia.'
		: '';
}

/** Puste linie nad / pod sekcją: 0–3. */
function rzd_posts_gap( $v, $def ) {
	return is_numeric( $v ) ? max( 0, min( 3, (int) $v ) ) : $def;
}

function rzd_posts_defaults() {
	return array(
		'gemini_key'   => '',
		'model'        => '',
		'ai_images'    => 0,
		'instructions' => rzd_posts_default_instructions(),
		'about'        => rzd_posts_default_about(),
		'sections'     => rzd_posts_default_sections(),
		'fb_page'      => '',
		'fb_token'     => '',
		'gen_time'     => '19:00',
		'pub_time'     => '20:00',
		'auto'         => 1,
		'mail_to'      => '',
		'place'        => '', // (2.49.0) ID strony-lokalizacji do oznaczenia; puste = ID strony
		'place_def'    => 1,  // nowe posty z lokalizacją
		'ratio'        => '4:5', // (2.50.0) format zdjęć: 4:5 | 1:1 | 1.91:1 | orig (05-zdjecia)
	);
}

function rzd_posts_settings( $reset = false ) {
	static $s = null;
	if ( $reset ) {
		$s = null;
	}
	if ( null !== $s ) {
		return $s;
	}
	$o = get_option( 'rzd_posts', array() );
	$o = is_array( $o ) ? $o : array();
	$s = wp_parse_args( $o, rzd_posts_defaults() );
	if ( $o && ! isset( $o['about'] ) ) { // sprzed 2.49.1: domyślne zdanie o obiedzie dnia – z zasad wspólnych do „Zestaw”
		$lines = preg_split( '/\r\n|\n/', (string) $s['instructions'] );
		$rest  = array_filter( $lines, function ( $l ) { return trim( $l ) !== rzd_posts_old_first_line(); } );
		if ( count( $rest ) < count( $lines ) ) {
			$s['instructions'] = trim( implode( "\n", $rest ) );
		}
	}
	$s['about'] = array_merge( rzd_posts_default_about(), is_array( $s['about'] ) ? array_intersect_key( $s['about'], rzd_posts_kinds() ) : array() );
	if ( ! is_array( $s['sections'] ) || ! $s['sections'] ) {
		$s['sections'] = rzd_posts_default_sections();
	}
	foreach ( $s['sections'] as $i => $sec ) { // ustawienia sprzed 2.48.2: bez h i on → aktywna, bez wskazówek
		$s['sections'][ $i ] = array_merge( array( 'k' => 's' . $i, 'n' => '', 'm' => 'ai', 't' => '', 'h' => '', 'on' => 1 ), (array) $sec );
		$s['sections'][ $i ]['on'] = empty( $s['sections'][ $i ]['on'] ) ? 0 : 1;
		if ( ! isset( $s['sections'][ $i ]['ty'] ) || ! is_array( $s['sections'][ $i ]['ty'] ) ) { // sprzed 2.49.0
			$s['sections'][ $i ]['ty'] = 'menu' === $s['sections'][ $i ]['k'] ? array( 'set' ) : array_keys( rzd_posts_kinds() );
		}
		$s['sections'][ $i ]['sb'] = rzd_posts_gap( isset( $sec['sb'] ) ? $sec['sb'] : null, 0 ); // sprzed 2.49.1 – jak dawniej
		$s['sections'][ $i ]['sa'] = rzd_posts_gap( isset( $sec['sa'] ) ? $sec['sa'] : null, 1 );
	}
	if ( function_exists( 'rzd_api_settings' ) ) { // (2.51.0) klucz, model, strona i token – z Połączeń API
		foreach ( rzd_api_settings() as $f => $v ) {
			$s[ $f ] = $v;
		}
	}
	return $s;
}

/** Sekrety: stała w wp-config.php (RZD_GEMINI_KEY, RZD_FB_TOKEN) albo zaszyfrowane w bazie – od 2.51.0 Połączenia API. */
function rzd_posts_secret( $field ) {
	if ( function_exists( 'rzd_api_secret' ) ) {
		return rzd_api_secret( $field );
	}
	$const = array( 'gemini_key' => 'RZD_GEMINI_KEY', 'fb_token' => 'RZD_FB_TOKEN' );
	if ( isset( $const[ $field ] ) && defined( $const[ $field ] ) ) {
		return (string) constant( $const[ $field ] );
	}
	$s = rzd_posts_settings();
	return function_exists( 'rzd_mail_decrypt' ) ? rzd_mail_decrypt( (string) $s[ $field ] ) : '';
}

function rzd_posts_hm( $v, $def ) {
	$v = trim( (string) $v );
	return preg_match( '/^([01]?\d|2[0-3]):[0-5]\d$/', $v ) ? str_pad( $v, 5, '0', STR_PAD_LEFT ) : $def;
}

/** Zapis ustawień z panelu. Sekret pusty = bez zmian; „-” = usuń. Zwraca [ ok, komunikat ]. */
function rzd_posts_save_settings( $in ) {
	$in  = is_array( $in ) ? $in : array();
	$old = rzd_posts_settings();
	$s   = $old;
	if ( function_exists( 'rzd_api_save' ) ) { // (2.51.0) pola połączeń zapisują się w Połączeniach API
		$api = array_intersect_key( $in, array_flip( rzd_api_fields() ) );
		if ( $api ) {
			rzd_api_save( $api );
		}
		$in = array_diff_key( $in, $api );
	}
	foreach ( array( 'gemini_key', 'fb_token' ) as $f ) {
		$v = isset( $in[ $f ] ) ? trim( (string) $in[ $f ] ) : '';
		if ( '-' === $v ) {
			$s[ $f ] = '';
		} elseif ( '' !== $v ) {
			$s[ $f ] = function_exists( 'rzd_mail_encrypt' ) ? rzd_mail_encrypt( $v ) : '';
		}
	}
	$s['model']        = isset( $in['model'] ) ? preg_replace( '/[^a-z0-9._\-\/]/i', '', (string) $in['model'] ) : $old['model'];
	$s['ai_images']    = array_key_exists( 'ai_images', $in ) ? ( empty( $in['ai_images'] ) ? 0 : 1 ) : $old['ai_images']; // zapis częściowy – bez zmian
	$s['instructions'] = isset( $in['instructions'] ) ? mb_substr( sanitize_textarea_field( (string) $in['instructions'] ), 0, 4000 ) : $old['instructions'];
	if ( isset( $in['about'] ) && is_array( $in['about'] ) ) {
		foreach ( array_keys( rzd_posts_kinds() ) as $k ) {
			$s['about'][ $k ] = isset( $in['about'][ $k ] ) ? mb_substr( sanitize_textarea_field( (string) $in['about'][ $k ] ), 0, 1000 ) : $old['about'][ $k ];
		}
	}
	$s['fb_page']      = isset( $in['fb_page'] ) ? preg_replace( '/\D/', '', (string) $in['fb_page'] ) : $old['fb_page'];
	$s['gen_time']     = rzd_posts_hm( isset( $in['gen_time'] ) ? $in['gen_time'] : '', $old['gen_time'] );
	$s['pub_time']     = rzd_posts_hm( isset( $in['pub_time'] ) ? $in['pub_time'] : '', $old['pub_time'] );
	$s['auto']         = array_key_exists( 'auto', $in ) ? ( empty( $in['auto'] ) ? 0 : 1 ) : $old['auto'];
	$s['place']        = isset( $in['place'] ) ? preg_replace( '/\D+/', '', (string) $in['place'] ) : $old['place'];
	$s['ratio']        = isset( $in['ratio'] ) && function_exists( 'rzd_posts_ratio_key' ) ? rzd_posts_ratio_key( $in['ratio'], $old['ratio'] ) : $old['ratio'];
	$s['place_def']    = array_key_exists( 'place_def', $in ) ? ( empty( $in['place_def'] ) ? 0 : 1 ) : $old['place_def'];
	$s['mail_to']      = isset( $in['mail_to'] ) ? implode( ', ', array_filter( array_map( 'sanitize_email', array_map( 'trim', explode( ',', (string) $in['mail_to'] ) ) ) ) ) : $old['mail_to'];
	if ( isset( $in['sections'] ) && is_array( $in['sections'] ) ) {
		$secs = array();
		$keys = array();
		foreach ( $in['sections'] as $i => $r ) {
			$n = mb_substr( sanitize_text_field( isset( $r['n'] ) ? (string) $r['n'] : '' ), 0, 40 );
			if ( '' === $n ) {
				continue;
			}
			$k = sanitize_key( isset( $r['k'] ) && '' !== $r['k'] ? $r['k'] : remove_accents( $n ) );
			$k = '' === $k || isset( $keys[ $k ] ) ? 's' . $i : $k;
			$keys[ $k ] = 1;
			$secs[]     = array(
				'k' => $k,
				'n' => $n,
				'm' => isset( $r['m'] ) && 'static' === $r['m'] ? 'static' : 'ai',
				't'  => mb_substr( sanitize_textarea_field( isset( $r['t'] ) ? (string) $r['t'] : '' ), 0, 1000 ),
				'h'  => mb_substr( sanitize_textarea_field( isset( $r['h'] ) ? (string) $r['h'] : '' ), 0, 1000 ),
				'on' => ! array_key_exists( 'on', (array) $r ) || ! empty( $r['on'] ) ? 1 : 0,
				'ty' => isset( $r['ty'] ) && is_array( $r['ty'] ) ? array_values( array_intersect( array_keys( rzd_posts_kinds() ), $r['ty'] ) ) : ( 'menu' === $k ? array( 'set' ) : array_keys( rzd_posts_kinds() ) ),
				'sb' => rzd_posts_gap( isset( $r['sb'] ) ? $r['sb'] : null, 0 ),
				'sa' => rzd_posts_gap( isset( $r['sa'] ) ? $r['sa'] : null, 1 ),
			);
		}
		if ( ! $secs ) {
			return array( false, 'Post musi mieć choć jedną sekcję.' );
		}
		if ( ! array_filter( $secs, function ( $x ) { return 'ai' === $x['m'] && $x['on'] && in_array( 'set', $x['ty'], true ); } ) ) {
			return array( false, 'Choć jedna aktywna sekcja w postach o zestawie musi być pisana przez AI.' );
		}
		$s['sections'] = $secs;
	}
	if ( $s['pub_time'] <= $s['gen_time'] ) {
		return array( false, 'Godzina publikacji musi być późniejsza niż godzina przygotowania szkicu.' );
	}
	if ( function_exists( 'rzd_api_fields' ) ) { // w rzd_posts zostają wartości sprzed 2.51.0 (zapas), nie kopie z rzd_api
		$raw = get_option( 'rzd_posts', array() );
		foreach ( rzd_api_fields() as $f ) {
			$s[ $f ] = is_array( $raw ) && isset( $raw[ $f ] ) ? $raw[ $f ] : '';
		}
	}
	update_option( 'rzd_posts', $s, false );
	rzd_posts_settings( true );
	if ( function_exists( 'rzd_posts_schedule_ensure' ) ) {
		rzd_posts_schedule_ensure( true );
	}
	return array( true, 'Zapisano ustawienia postów.' );
}

/* ---------- posty (historia) ---------- */
add_action( 'init', function () {
	register_post_type( 'rzd_fbpost', array(
		'label'           => 'Posty dnia',
		'public'          => false,
		'show_ui'         => false,
		'show_in_rest'    => false,
		'supports'        => array( 'title', 'editor' ),
		'capability_type' => 'post',
	) );
} );

function rzd_posts_status_labels() {
	return array( 'draft' => 'Szkic – czeka na zatwierdzenie', 'scheduled' => 'Zaplanowany na Facebooku', 'published' => 'Opublikowany', 'error' => 'Błąd' );
}

/** Post jako tablica dla panelu. */
function rzd_posts_get( $id ) {
	$p = get_post( (int) $id );
	if ( ! $p || 'rzd_fbpost' !== $p->post_type ) {
		return null;
	}
	$photos = get_post_meta( $p->ID, '_photos', true );
	return array(
		'id'     => (int) $p->ID,
		'day'    => (string) get_post_meta( $p->ID, '_day', true ),
		'set'    => (int) get_post_meta( $p->ID, '_set', true ),
		'status' => (string) get_post_meta( $p->ID, '_status', true ),
		'text'   => (string) $p->post_content,
		'photos' => is_array( $photos ) ? array_values( $photos ) : array(),
		'when'   => (int) get_post_meta( $p->ID, '_when', true ),
		'fb'     => (string) get_post_meta( $p->ID, '_fb_id', true ),
		'err'    => (string) get_post_meta( $p->ID, '_err', true ),
		'src'    => (string) get_post_meta( $p->ID, '_src', true ),
		'extra'  => (string) get_post_meta( $p->ID, '_extra', true ),
		'by'     => (string) get_post_meta( $p->ID, '_by', true ),
		'date'   => get_post_time( 'U', true, $p ),
		'kind'   => get_post_meta( $p->ID, '_kind', true ) ? (string) get_post_meta( $p->ID, '_kind', true ) : 'set',
		'product' => (int) get_post_meta( $p->ID, '_product', true ),
		'topic'  => (string) get_post_meta( $p->ID, '_topic', true ),
		'place'  => '' === get_post_meta( $p->ID, '_place', true ) ? (int) rzd_posts_settings()['place_def'] : (int) get_post_meta( $p->ID, '_place', true ),
		'ratio'  => (string) get_post_meta( $p->ID, '_ratio', true ), // (2.50.0) '' = domyślny z ustawień
		'parked' => (int) get_post_meta( $p->ID, '_parked', true ), // (2.50.0) odłożony na potem (zakładka „Odłożone”)
	);
}

/** Posty na dzień dania (bez błędnych i usuniętych; bez odłożonych – automat i Plan tygodnia ich nie liczą). */
function rzd_posts_for_day( $day, $with_errors = false ) {
	$ids = get_posts( array(
		'post_type'   => 'rzd_fbpost',
		'post_status' => 'publish',
		'numberposts' => 20,
		'fields'      => 'ids',
		'meta_query'  => array( array( 'key' => '_day', 'value' => $day ) ), // phpcs:ignore
	) );
	$out = array();
	foreach ( $ids as $id ) {
		$p = rzd_posts_get( $id );
		if ( $p && ! $p['parked'] && ( $with_errors || 'error' !== $p['status'] ) ) {
			$out[] = $p;
		}
	}
	return $out;
}

function rzd_posts_save_post( $data ) {
	$id = isset( $data['id'] ) ? (int) $data['id'] : 0;
	$arr = array(
		'post_type'    => 'rzd_fbpost',
		'post_status'  => 'publish',
		'post_title'   => 'Post ' . ( isset( $data['day'] ) ? $data['day'] : '' ),
		'post_content' => (string) $data['text'],
	);
	if ( $id ) {
		$arr['ID'] = $id;
		wp_update_post( wp_slash( $arr ) );
	} else {
		$id = wp_insert_post( wp_slash( $arr ) );
	}
	foreach ( array( 'day', 'set', 'status', 'photos', 'when', 'fb_id', 'err', 'src', 'extra', 'by', 'kind', 'product', 'topic', 'place', 'ratio', 'parked' ) as $k ) {
		if ( array_key_exists( $k, $data ) ) {
			update_post_meta( $id, '_' . $k, $data[ $k ] );
		}
	}
	return (int) $id;
}

/**
 * (2.50.0) Bank postów „Odłożone”: szkice odłożone na potem (znacznik _parked, bez godziny publikacji). Nie liczą się
 * jako post dnia (automat 19:00, Plan tygodnia), nie ma ich w Historii. Znacznik znika przy publikacji / planowaniu.
 */
function rzd_posts_parked_list() {
	$out = array();
	foreach ( get_posts( array( 'post_type' => 'rzd_fbpost', 'post_status' => 'publish', 'numberposts' => 200, 'fields' => 'ids', 'orderby' => 'modified', 'order' => 'DESC', 'meta_query' => array( array( 'key' => '_parked', 'value' => '1' ) ) ) ) as $id ) { // phpcs:ignore
		$p = rzd_posts_get( $id );
		if ( $p && 'draft' === $p['status'] ) {
			$p['modified'] = (int) get_post_modified_time( 'U', true, $id );
			$out[]         = $p;
		}
	}
	return $out;
}

/**
 * „Użyj ponownie”: kopia posta jako nowy szkic (oryginał zostaje). Zestaw – ten sam dzień, gdy jeszcze nie minął
 * (inaczej dzień i godzina do ustawienia w edytorze); produkt / temat – najbliższa godzina publikacji. [ ok, post | komunikat ].
 */
function rzd_posts_copy( $id, $parked = 0 ) {
	$p = rzd_posts_get( $id );
	if ( ! $p ) {
		return array( false, 'Nie znaleziono posta.' );
	}
	$today = current_time( 'Y-m-d' );
	$when  = 'set' === $p['kind'] ? ( '' !== $p['day'] && $p['day'] > $today ? rzd_posts_default_when( $p['day'] ) : 0 ) : rzd_posts_next_pub_time();
	$nid   = rzd_posts_save_post( array(
		'day'     => $p['day'],
		'set'     => $p['set'],
		'kind'    => $p['kind'],
		'product' => $p['product'],
		'topic'   => $p['topic'],
		'status'  => 'draft',
		'text'    => $p['text'],
		'photos'  => $p['photos'],
		'when'    => $parked ? 0 : $when,
		'extra'   => $p['extra'],
		'place'   => $p['place'],
		'ratio'   => $p['ratio'],
		'parked'  => $parked ? 1 : 0,
		'fb_id'   => '',
		'err'     => '',
		'src'     => 'manual',
		'by'      => is_user_logged_in() ? wp_get_current_user()->display_name : '',
	) );
	return $nid ? array( true, rzd_posts_get( $nid ) ) : array( false, 'Nie udało się skopiować posta.' );
}

/* ---------- zestaw na dzień ---------- */
function rzd_posts_sets() {
	$out    = array();
	$ids    = array();
	$nested = array(); // zestawy wpięte w inne zestawy (np. „Zupa dnia”) – nie są osobnym zestawem dnia (2.49.0)
	foreach ( wc_get_products( array( 'status' => 'publish', 'limit' => 100, 'return' => 'ids' ) ) as $pid ) {
		if ( function_exists( 'rzd_zestaw_is_set_product' ) && rzd_zestaw_is_set_product( $pid ) && ! ( function_exists( 'rzd_seo_hidden_product' ) && rzd_seo_hidden_product( $pid ) ) ) {
			$ids[] = (int) $pid;
		}
	}
	foreach ( $ids as $pid ) {
		foreach ( (array) rzd_zestaw_get_slots( $pid ) as $slot ) {
			foreach ( isset( $slot['items'] ) ? (array) $slot['items'] : array() as $row ) {
				if ( ! empty( $row['product_id'] ) && (int) $row['product_id'] !== $pid ) {
					$nested[ (int) $row['product_id'] ] = 1;
				}
			}
		}
	}
	foreach ( $ids as $pid ) {
		if ( ! isset( $nested[ $pid ] ) ) {
			$out[] = array( 'id' => $pid, 'name' => get_the_title( $pid ) );
		}
	}
	return $out;
}

/** Produkty do posta „o produkcie” (2.49.0): widoczne w sklepie, bez zestawów pośrednich. [ [id, name, cat, img] ]. */
function rzd_posts_products() {
	$sets   = wp_list_pluck( rzd_posts_sets(), 'id' );
	$out    = array();
	foreach ( wc_get_products( array( 'status' => 'publish', 'limit' => 400, 'orderby' => 'title', 'order' => 'ASC' ) ) as $p ) {
		$pid    = (int) $p->get_id();
		$is_set = function_exists( 'rzd_zestaw_is_set_product' ) && rzd_zestaw_is_set_product( $pid );
		if ( ( $is_set && ! in_array( $pid, $sets, true ) ) || ( function_exists( 'rzd_seo_hidden_product' ) && rzd_seo_hidden_product( $pid ) ) ) {
			continue;
		}
		$cats  = wp_get_post_terms( $pid, 'product_cat', array( 'fields' => 'names' ) );
		$out[] = array( 'id' => $pid, 'name' => $p->get_name(), 'cat' => is_array( $cats ) && $cats ? (string) $cats[0] : '', 'img' => $p->get_image_id() ? (string) wp_get_attachment_image_url( $p->get_image_id(), 'thumbnail' ) : '' );
	}
	return $out;
}

/** Dane produktu dla AI i podpowiedź zdjęć (zdjęcie główne + galeria, maks. 4). */
function rzd_posts_product_data( $pid ) {
	$p = wc_get_product( (int) $pid );
	if ( ! $p ) {
		return null;
	}
	$photos = array();
	foreach ( array_slice( array_merge( array( $p->get_image_id() ), $p->get_gallery_image_ids() ), 0, 4 ) as $aid ) {
		$ph = $aid ? rzd_posts_photo( $aid ) : null;
		if ( $ph ) {
			$photos[] = $ph;
		}
	}
	$cats = wp_get_post_terms( $p->get_id(), 'product_cat', array( 'fields' => 'names' ) );
	return array(
		'kind'    => 'product',
		'product' => (int) $p->get_id(),
		'setName' => $p->get_name(),
		'day'     => '',
		'cat'     => is_array( $cats ) && $cats ? implode( ', ', $cats ) : '',
		'desc'    => trim( wp_strip_all_tags( $p->get_short_description() ? $p->get_short_description() : $p->get_description() ) ),
		'dishes'  => array(),
		'photos'  => $photos,
	);
}

/** Domyślny moment publikacji posta o produkcie / temacie: najbliższa godzina publikacji (min. 15 min naprzód). */
function rzd_posts_next_pub_time() {
	$s  = rzd_posts_settings();
	$dt = DateTime::createFromFormat( 'Y-m-d H:i', current_time( 'Y-m-d' ) . ' ' . $s['pub_time'], wp_timezone() );
	if ( ! $dt ) {
		return 0;
	}
	if ( $dt->getTimestamp() < time() + 15 * MINUTE_IN_SECONDS ) {
		$dt->modify( '+1 day' );
	}
	return $dt->getTimestamp();
}

/** Zdjęcie do posta: [ id załącznika (0 = plik zestawu), url do podglądu, path pliku do wysłania ]. */
function rzd_posts_photo( $att_id ) {
	$att_id = (int) $att_id;
	$path   = $att_id ? get_attached_file( $att_id ) : '';
	$url    = $att_id ? wp_get_attachment_image_url( $att_id, 'large' ) : '';
	return ( $path && $url ) ? array( 'id' => $att_id, 'url' => $url ) : null;
}

/**
 * Dania zestawu na dzień (najgłębszy składnik – jak lista zamówień) + podpowiedź zdjęć.
 * [ set, setName, day, dishes [ [id, name, desc, role] ], photos [ [id, url] ] ].
 */
function rzd_posts_day_data( $set_id, $day ) {
	$set_id = (int) $set_id;
	$dishes  = array();
	$photos  = array();
	$missing = array();
	if ( function_exists( 'rzd_zestaw_get_active_components' ) ) {
		$active = rzd_zestaw_get_active_components( $set_id, $day );
		foreach ( (array) $active['main'] as $p ) {
			if ( (int) $p->get_id() === $set_id ) {
				continue;
			}
			// Zestaw pośredni (np. „Zupa dnia”) bez dania na ten dzień – silnik pokazuje wtedy jego nazwę; do posta
			// idą tylko prawdziwe dania (najgłębsze), a brak trafia do ostrzeżenia (2.49.0).
			if ( rzd_zestaw_get_slots( $p->get_id() ) ) {
				$missing[] = $p->get_name();
				continue;
			}
			$role     = isset( $active['roles'][ $p->get_id() ] ) ? (array) $active['roles'][ $p->get_id() ] : array();
			$dishes[] = array(
				'id'   => (int) $p->get_id(),
				'name' => $p->get_name(),
				'desc' => trim( wp_strip_all_tags( $p->get_short_description() ? $p->get_short_description() : $p->get_description() ) ),
				'role' => isset( $role['label'] ) ? (string) $role['label'] : '',
			);
			$ph = rzd_posts_photo( $p->get_image_id() );
			if ( $ph ) {
				$photos[] = $ph;
			}
		}
	}
	if ( ! $photos ) {
		$ph = rzd_posts_photo( get_post_thumbnail_id( $set_id ) );
		if ( $ph ) {
			$photos[] = $ph;
		}
	}
	return array( 'kind' => 'set', 'set' => $set_id, 'setName' => get_the_title( $set_id ), 'day' => $day, 'dishes' => $dishes, 'photos' => $photos, 'missing' => $missing );
}

/** Domyślny moment publikacji posta na dzień $day: dzień wcześniej o godzinie publikacji. */
function rzd_posts_default_when( $day ) {
	$s  = rzd_posts_settings();
	$dt = DateTime::createFromFormat( 'Y-m-d H:i', $day . ' ' . $s['pub_time'], wp_timezone() );
	if ( ! $dt ) {
		return 0;
	}
	$dt->modify( '-1 day' );
	return $dt->getTimestamp();
}

/** Najbliższe dni (od jutra), w które zestaw ma dania – plan tygodnia. */
function rzd_posts_week( $days = 7 ) {
	$sets = rzd_posts_sets();
	$out  = array();
	$d    = new DateTime( current_time( 'Y-m-d' ), wp_timezone() );
	for ( $i = 1; $i <= $days; $i++ ) {
		$d->modify( '+1 day' );
		$day = $d->format( 'Y-m-d' );
		foreach ( $sets as $set ) {
			$dd = rzd_posts_day_data( $set['id'], $day );
			if ( ! $dd['dishes'] ) {
				continue;
			}
			$posts = rzd_posts_for_day( $day, true );
			$out[] = array(
				'day'    => $day,
				'label'  => ucfirst( rzd_dc_date_label( $day ) ),
				'set'    => $set['id'],
				'setName' => $set['name'],
				'dishes' => array_map( function ( $x ) { return $x['name']; }, $dd['dishes'] ),
				'missing' => $dd['missing'],
				'posts'  => $posts,
				'when'   => rzd_posts_default_when( $day ),
			);
			break; // jeden zestaw dnia na dzień – pierwszy z daniami
		}
	}
	return $out;
}
