<?php
/**
 * Moduł 38-posty – automaty dla zestawów (2.57.0) i dni bez dostaw (2.56.2).
 * Ustawienie `autos` w rzd_posts: lista automatów, każdy przypięty do jednego zestawu:
 * { k – klucz (argument zadania), set, on, gen – „szkic gotowy o”, pub – „publikacja o”, for – next (na jutro) |
 *   today (na dziś), dow – dni tygodnia celu (1 = pn … 7 = nd), ai – dostawca ('' = domyślny), mail – adresy,
 *   pub_auto – publikuj bez zatwierdzania }.
 * Migracja: brak `autos` w bazie → jeden automat z dawnych pól (week_set, auto, gen_time, pub_time, auto_ai, mail_to).
 * Dni bez dostaw: Terminy → „Dni wolne” dla wszystkich grup albo wszystkie kalendarze (grupy) zestawu zamknięte
 * w tym dniu (data zablokowana albo dzień tygodnia bez dostaw).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function rzd_posts_auto_blank() {
	return array( 'k' => '', 'set' => 0, 'on' => 1, 'gen' => '19:00', 'pub' => '20:00', 'for' => 'next', 'dow' => array( 1, 2, 3, 4, 5, 6, 7 ), 'ai' => '', 'mail' => '', 'pub_auto' => 0 );
}

/** Jeden automat po sprzątnięciu (z bazy albo z panelu). */
function rzd_posts_auto_clean( $r ) {
	$b = rzd_posts_auto_blank();
	$r = is_array( $r ) ? $r : array();
	$k = isset( $r['k'] ) ? preg_replace( '/[^a-z0-9]/', '', strtolower( (string) $r['k'] ) ) : '';
	$dow = isset( $r['dow'] ) && is_array( $r['dow'] ) ? array_values( array_unique( array_filter( array_map( 'intval', $r['dow'] ), function ( $x ) { return $x >= 1 && $x <= 7; } ) ) ) : $b['dow'];
	sort( $dow );
	$ai = isset( $r['ai'] ) ? (string) $r['ai'] : '';
	return array(
		'k'        => '' !== $k ? substr( $k, 0, 12 ) : 'a' . substr( md5( uniqid( '', true ) ), 0, 8 ),
		'set'      => isset( $r['set'] ) ? max( 0, (int) $r['set'] ) : 0,
		'on'       => ! isset( $r['on'] ) || ! empty( $r['on'] ) ? 1 : 0,
		'gen'      => rzd_posts_hm( isset( $r['gen'] ) ? $r['gen'] : '', $b['gen'] ),
		'pub'      => rzd_posts_hm( isset( $r['pub'] ) ? $r['pub'] : '', $b['pub'] ),
		'for'      => isset( $r['for'] ) && 'today' === $r['for'] ? 'today' : 'next',
		'dow'      => $dow,
		'ai'       => '' !== $ai && function_exists( 'rzd_ai_providers' ) && isset( rzd_ai_providers()[ $ai ] ) ? $ai : '',
		'mail'     => isset( $r['mail'] ) ? implode( ', ', array_filter( array_map( 'sanitize_email', array_map( 'trim', explode( ',', (string) $r['mail'] ) ) ) ) ) : '',
		'pub_auto' => ! empty( $r['pub_auto'] ) ? 1 : 0,
	);
}

/** Automat z ustawień sprzed 2.57.0 (jeden, „na jutro”). */
function rzd_posts_autos_migrate( $s ) {
	return array( rzd_posts_auto_clean( array(
		'k'    => 'a1',
		'set'  => isset( $s['week_set'] ) ? (int) $s['week_set'] : 0,
		'on'   => ! empty( $s['auto'] ) ? 1 : 0,
		'gen'  => isset( $s['gen_time'] ) ? $s['gen_time'] : '19:00',
		'pub'  => isset( $s['pub_time'] ) ? $s['pub_time'] : '20:00',
		'ai'   => isset( $s['auto_ai'] ) ? $s['auto_ai'] : '',
		'mail' => isset( $s['mail_to'] ) ? $s['mail_to'] : '',
	) ) );
}

/** Walidacja listy z panelu: [ ok, lista | komunikat ]. */
function rzd_posts_autos_from_input( $list ) {
	$out  = array();
	$sets = array();
	$keys = array();
	foreach ( (array) $list as $r ) {
		$a = rzd_posts_auto_clean( $r );
		if ( ! $a['set'] ) {
			return array( false, 'Wybierz zestaw w każdym automacie.' );
		}
		if ( isset( $sets[ $a['set'] ] ) ) {
			return array( false, 'Każdy zestaw może mieć jeden automat – ten sam zestaw jest wybrany dwa razy.' );
		}
		if ( $a['pub'] <= $a['gen'] ) {
			return array( false, 'W automacie godzina publikacji musi być późniejsza niż godzina szkicu.' );
		}
		if ( ! $a['dow'] ) {
			return array( false, 'Zaznacz w automacie choć jeden dzień tygodnia.' );
		}
		while ( isset( $keys[ $a['k'] ] ) ) {
			$a['k'] = 'a' . substr( md5( uniqid( '', true ) ), 0, 8 );
		}
		$keys[ $a['k'] ] = 1;
		$sets[ $a['set'] ] = 1;
		$out[]             = $a;
	}
	return array( true, $out );
}

function rzd_posts_autos() {
	$a = rzd_posts_settings()['autos'];
	return is_array( $a ) ? $a : array();
}

function rzd_posts_auto_by_key( $k ) {
	foreach ( rzd_posts_autos() as $a ) {
		if ( $a['k'] === (string) $k ) {
			return $a;
		}
	}
	return null;
}

/** Automat zestawu (także wyłączony – jego godziny są domyślne dla postów tego zestawu). */
function rzd_posts_auto_for_set( $set ) {
	foreach ( rzd_posts_autos() as $a ) {
		if ( (int) $a['set'] === (int) $set && $set ) {
			return $a;
		}
	}
	return null;
}

/** Dzień, na który pisze automat uruchomiony dziś: na jutro / na dziś. */
function rzd_posts_auto_target_day( $a ) {
	$d = new DateTime( current_time( 'Y-m-d' ), wp_timezone() );
	if ( 'today' !== $a['for'] ) {
		$d->modify( '+1 day' );
	}
	return $d->format( 'Y-m-d' );
}

/**
 * (2.56.2) Dzień bez dostaw dla zestawu: data w „Dni wolne” wszystkich grup albo każda grupa (kalendarz)
 * zestawu ma w tym dniu przerwę – zablokowana data lub dzień tygodnia bez dostaw.
 */
function rzd_posts_day_closed( $set, $day ) {
	if ( ! function_exists( 'rzd_dc_get_settings' ) || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $day ) ) {
		return false;
	}
	$s = rzd_dc_get_settings();
	if ( in_array( $day, (array) $s['global_blocked'], true ) ) {
		return true;
	}
	$cals = $set && function_exists( 'rzd_dc_calendars_for_product' ) ? rzd_dc_calendars_for_product( (int) $set ) : array();
	if ( ! $cals ) {
		return false;
	}
	$dow = ( new DateTime( $day, wp_timezone() ) )->format( 'D' );
	foreach ( $cals as $cal ) {
		$blocked = in_array( $day, isset( $cal['blocked'] ) ? (array) $cal['blocked'] : array(), true );
		$no_dow  = isset( $cal['days'] ) && is_array( $cal['days'] ) && $cal['days'] && ! in_array( $dow, $cal['days'], true );
		if ( ! $blocked && ! $no_dow ) {
			return false; // choć jedna grupa zestawu dowozi
		}
	}
	return true;
}
