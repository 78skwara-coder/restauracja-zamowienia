<?php
/**
 * Moduł 38-posty – automat: codziennie o godzinie „przygotuj szkic” (domyślnie 19:00), gdy na JUTRO nie ma
 * jeszcze posta (szkicu, zaplanowanego ani opublikowanego), Gemini przygotowuje szkic, a wtyczka wysyła mail
 * „zatwierdź”. Publikacja zawsze dopiero po zatwierdzeniu w panelu (domyślnie o 20:00). Zadanie pojedyncze,
 * planowane na najbliższą godzinę (jak samotest – bez przesuwania godziny przy braku crona).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function rzd_posts_next_run() {
	$s  = rzd_posts_settings();
	$tz = wp_timezone();
	$t  = DateTime::createFromFormat( 'Y-m-d H:i', current_time( 'Y-m-d' ) . ' ' . $s['gen_time'], $tz );
	if ( ! $t || $t->getTimestamp() <= time() ) {
		$t = DateTime::createFromFormat( 'Y-m-d H:i', current_time( 'Y-m-d' ) . ' ' . $s['gen_time'], $tz );
		$t->modify( '+1 day' );
	}
	return $t->getTimestamp();
}

/** Zadanie w kolejce na najbliższą godzinę szkicu (po zmianie godziny w ustawieniach – od nowa). */
add_action( 'action_scheduler_init', function () {
	rzd_posts_schedule_ensure( false );
} );
function rzd_posts_schedule_ensure( $reset ) {
	if ( ! function_exists( 'as_next_scheduled_action' ) ) {
		return;
	}
	$s    = rzd_posts_settings();
	$next = as_next_scheduled_action( 'rzd_posts_auto', array(), 'restauracja' );
	if ( true === $next ) {
		return;
	}
	if ( ! $s['auto'] ) {
		if ( false !== $next ) {
			as_unschedule_all_actions( 'rzd_posts_auto', array(), 'restauracja' );
		}
		return;
	}
	if ( false !== $next && ( $reset || wp_date( 'H:i', (int) $next ) !== $s['gen_time'] ) ) {
		as_unschedule_all_actions( 'rzd_posts_auto', array(), 'restauracja' );
		$next = false;
	}
	if ( false === $next ) {
		as_schedule_single_action( rzd_posts_next_run(), 'rzd_posts_auto', array(), 'restauracja' );
	}
}

add_action( 'rzd_posts_auto', 'rzd_posts_auto_run' );

/** Przebieg automatu. Zwraca opis (testy, dziennik). */
function rzd_posts_auto_run() {
	if ( function_exists( 'rzd_posts_photos_cleanup' ) ) { // (2.50.0) stare docięte kopie zdjęć
		rzd_posts_photos_cleanup();
	}
	$s = rzd_posts_settings();
	if ( ! $s['auto'] ) {
		return 'wyłączony';
	}
	$day = ( new DateTime( current_time( 'Y-m-d' ), wp_timezone() ) )->modify( '+1 day' )->format( 'Y-m-d' );
	if ( rzd_posts_for_day( $day ) ) {
		return 'jest już post na ' . $day;
	}
	$week = rzd_posts_week( 1 );
	if ( ! $week ) {
		return 'brak zestawu z daniami na ' . $day;
	}
	if ( '' === rzd_posts_secret( 'gemini_key' ) || '' === $s['model'] ) {
		return 'brak ustawień Gemini';
	}
	list( $ok, $p ) = rzd_posts_generate( $week[0]['set'], $day, '', null, 0, 'auto' );
	$url = function_exists( 'rzd_panel_url' ) ? rzd_panel_url( 'posty', array( 'tab' => 'nowy', 'post' => $ok ? $p['id'] : '' ) ) : admin_url();
	if ( $ok ) {
		rzd_posts_mail(
			'Post dnia na jutro czeka na zatwierdzenie',
			'Przygotowałem szkic posta na ' . rzd_dc_date_label( $day ) . ' (' . $week[0]['setName'] . ').' . ( $week[0]['missing'] ? "\n\n" . 'UWAGA: bez dania na ten dzień: ' . implode( ', ', $week[0]['missing'] ) . ' – uzupełnij zestaw i wygeneruj post ponownie.' : '' ) . "\n\n" . $p['text'] . "\n\n" . 'Sprawdź i zatwierdź – opublikuje się o ' . $s['pub_time'] . ': ' . $url
		);
		return 'szkic #' . $p['id'];
	}
	rzd_posts_save_post( array( 'day' => $day, 'set' => $week[0]['set'], 'status' => 'error', 'text' => '', 'photos' => array(), 'err' => $p, 'src' => 'auto', 'by' => 'automat' ) );
	rzd_posts_mail( 'Nie udało się przygotować posta dnia', 'Automat nie przygotował posta na ' . rzd_dc_date_label( $day ) . ': ' . $p . "\n\nPrzygotuj go ręcznie: " . $url );
	return 'błąd: ' . $p;
}

function rzd_posts_mail( $subject, $body ) {
	$s  = rzd_posts_settings();
	$to = '' !== trim( $s['mail_to'] ) ? $s['mail_to'] : get_option( 'admin_email' );
	return wp_mail( $to, '[' . wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) . '] ' . $subject, $body );
}
