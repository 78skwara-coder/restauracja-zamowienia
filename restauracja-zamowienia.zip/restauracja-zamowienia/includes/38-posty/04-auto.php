<?php
/**
 * Moduł 38-posty – automaty (2.57.0; dawniej jeden automat „na jutro”). Każdy automat (07-automaty) ma własne
 * zadanie Action Scheduler `rzd_posts_auto` z argumentem [ klucz ] na godzinę „szkic gotowy o”. Przebieg: dzień
 * celu (na jutro / na dziś), dzień tygodnia z listy automatu, zestaw ma dania, dzień nie jest wolny (2.56.2),
 * nie ma jeszcze posta TEGO zestawu na ten dzień → AI pisze szkic → mail „zatwierdź”. Z „Publikuj bez
 * zatwierdzania” szkic idzie od razu do planowania na Facebooku (i Instagramie), chyba że w zestawie brakuje dania
 * albo godzina publikacji jest za blisko – wtedy zostaje szkicem z mailem. Po przebiegu zadanie planuje się samo na
 * następny dzień. Sprzątanie (zdjęcia, historia) – osobne zadanie dzienne `rzd_posts_daily` o 3:15.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Najbliższy moment HH:MM (dziś, a gdy minął – jutro). */
function rzd_posts_next_run( $hm = '' ) {
	$hm = '' !== $hm ? $hm : '19:00';
	$tz = wp_timezone();
	$t  = DateTime::createFromFormat( 'Y-m-d H:i', current_time( 'Y-m-d' ) . ' ' . $hm, $tz );
	if ( ! $t || $t->getTimestamp() <= time() ) {
		$t = DateTime::createFromFormat( 'Y-m-d H:i', current_time( 'Y-m-d' ) . ' ' . $hm, $tz );
		$t->modify( '+1 day' );
	}
	return $t->getTimestamp();
}

/** Odcisk harmonogramu (klucz → godzina) – pełne sprawdzenie kolejki tylko po zmianie ustawień. */
function rzd_posts_autos_sig() {
	$w = array();
	foreach ( rzd_posts_autos() as $a ) {
		if ( $a['on'] ) {
			$w[ $a['k'] ] = $a['gen'];
		}
	}
	return $w;
}

add_action( 'action_scheduler_init', function () {
	rzd_posts_schedule_ensure( false );
} );

/** Zadania w kolejce: po jednym na każdy włączony automat + dzienne sprzątanie. $reset – sprawdź kolejkę od nowa. */
function rzd_posts_schedule_ensure( $reset ) {
	if ( ! function_exists( 'as_next_scheduled_action' ) ) {
		return;
	}
	$want = rzd_posts_autos_sig();
	$sig  = md5( wp_json_encode( $want ) );
	if ( ! $reset && get_option( 'rzd_posts_sched_sig' ) === $sig ) {
		return;
	}
	if ( false === as_next_scheduled_action( 'rzd_posts_daily', array(), 'restauracja' ) ) {
		as_schedule_single_action( rzd_posts_next_run( '03:15' ), 'rzd_posts_daily', array(), 'restauracja' );
	}
	if ( false !== as_next_scheduled_action( 'rzd_posts_auto', array(), 'restauracja' ) ) { // zadanie sprzed 2.57.0 (bez argumentu)
		as_unschedule_all_actions( 'rzd_posts_auto', array(), 'restauracja' );
	}
	if ( function_exists( 'as_get_scheduled_actions' ) ) {
		foreach ( (array) as_get_scheduled_actions( array( 'hook' => 'rzd_posts_auto', 'status' => 'pending', 'group' => 'restauracja', 'per_page' => 50 ) ) as $act ) {
			$args = is_object( $act ) && method_exists( $act, 'get_args' ) ? (array) $act->get_args() : array();
			$k    = isset( $args[0] ) ? (string) $args[0] : '';
			$at   = is_object( $act ) && method_exists( $act, 'get_schedule' ) && $act->get_schedule() && method_exists( $act->get_schedule(), 'get_date' ) && $act->get_schedule()->get_date() ? $act->get_schedule()->get_date()->getTimestamp() : 0;
			if ( '' !== $k && ( ! isset( $want[ $k ] ) || ( $at && wp_date( 'H:i', $at ) !== $want[ $k ] ) ) ) {
				as_unschedule_all_actions( 'rzd_posts_auto', array( $k ), 'restauracja' );
			}
		}
	}
	foreach ( $want as $k => $hm ) {
		if ( false === as_next_scheduled_action( 'rzd_posts_auto', array( $k ), 'restauracja' ) ) {
			as_schedule_single_action( rzd_posts_next_run( $hm ), 'rzd_posts_auto', array( $k ), 'restauracja' );
		}
	}
	update_option( 'rzd_posts_sched_sig', $sig, false );
}

add_action( 'rzd_posts_daily', function () {
	if ( function_exists( 'rzd_posts_photos_cleanup' ) ) { // (2.50.0) stare docięte kopie zdjęć
		rzd_posts_photos_cleanup();
	}
	if ( function_exists( 'rzd_posts_history_cleanup' ) ) { // (2.56.1) retencja historii (keep_days)
		rzd_posts_history_cleanup();
	}
	if ( function_exists( 'as_schedule_single_action' ) ) {
		as_schedule_single_action( rzd_posts_next_run( '03:15' ), 'rzd_posts_daily', array(), 'restauracja' );
	}
	rzd_posts_schedule_ensure( true ); // raz dziennie pełne sprawdzenie kolejki automatów
} );

add_action( 'rzd_posts_auto', function ( $k = '' ) {
	$r = rzd_posts_auto_run( (string) $k );
	$a = rzd_posts_auto_by_key( (string) $k );
	if ( $a && $a['on'] && function_exists( 'as_schedule_single_action' ) ) { // następny dzień tego automatu
		as_schedule_single_action( rzd_posts_next_run( $a['gen'] ), 'rzd_posts_auto', array( $a['k'] ), 'restauracja' );
	}
	return $r;
} );

/** Przebieg jednego automatu ('' = pierwszy – zgodność i testy). Zwraca opis (testy, dziennik). */
function rzd_posts_auto_run( $k = '' ) {
	$autos = rzd_posts_autos();
	$a     = '' !== $k ? rzd_posts_auto_by_key( $k ) : ( $autos ? $autos[0] : null );
	if ( ! $a || ! $a['on'] ) {
		return 'wyłączony';
	}
	$day = rzd_posts_auto_target_day( $a );
	if ( ! in_array( (int) ( new DateTime( $day, wp_timezone() ) )->format( 'N' ), $a['dow'], true ) ) {
		return 'poza dniami automatu: ' . $day;
	}
	$set = (int) $a['set'];
	if ( ! $set ) { // automat z migracji „pierwszy zestaw z daniami”
		foreach ( rzd_posts_sets() as $x ) {
			if ( rzd_posts_day_data( $x['id'], $day )['dishes'] && ! rzd_posts_day_closed( $x['id'], $day ) ) {
				$set = (int) $x['id'];
				break;
			}
		}
		if ( ! $set ) {
			return 'brak zestawu z daniami na ' . $day;
		}
	}
	$dd = rzd_posts_day_data( $set, $day );
	if ( ! $dd['dishes'] ) {
		return 'zestaw nie ma dań na ' . $day;
	}
	if ( rzd_posts_day_closed( $set, $day ) ) {
		return 'dzień bez dostaw: ' . $day;
	}
	foreach ( rzd_posts_for_day( $day ) as $p ) {
		if ( (int) $p['set'] === $set ) {
			return 'jest już post zestawu na ' . $day;
		}
	}
	if ( ! rzd_ai_ready() ) {
		return 'brak połączenia z AI';
	}
	rzd_ai_use( '' !== $a['ai'] && rzd_ai_provider_ready( $a['ai'] ) ? $a['ai'] : '' ); // nieskonfigurowany → domyślny
	$name = isset( $dd['setName'] ) ? $dd['setName'] : '';
	list( $ok, $p ) = rzd_posts_generate( $set, $day, '', null, 0, 'auto' );
	$url = function_exists( 'rzd_panel_url' ) ? rzd_panel_url( 'posty', array( 'tab' => 'nowy', 'post' => $ok ? $p['id'] : '' ) ) : admin_url();
	$lbl = rzd_dc_date_label( $day );
	if ( ! $ok ) {
		rzd_posts_save_post( array( 'day' => $day, 'set' => $set, 'status' => 'error', 'text' => '', 'photos' => array(), 'err' => $p, 'src' => 'auto', 'by' => 'automat' ) );
		rzd_posts_mail( 'Nie udało się przygotować posta', 'Automat nie przygotował posta na ' . $lbl . ': ' . $p . "\n\nPrzygotuj go ręcznie: " . $url, $a['mail'] );
		return 'błąd: ' . $p;
	}
	$miss = $dd['missing'] ? "\n\n" . 'UWAGA: bez dania na ten dzień: ' . implode( ', ', $dd['missing'] ) . ' – uzupełnij zestaw i wygeneruj post ponownie.' : '';
	// (2.57.0) „Publikuj bez zatwierdzania” – tylko pełny zestaw i godzina co najmniej 15 min po teraz
	if ( $a['pub_auto'] && ! $dd['missing'] && $p['when'] >= time() + 15 * MINUTE_IN_SECONDS ) {
		list( $okp, $pp ) = rzd_posts_fb_publish( $p['id'], $p['when'] );
		if ( $okp ) {
			$ig = function_exists( 'rzd_posts_ig_after_fb' ) ? rzd_posts_ig_after_fb( $p['id'], $p['when'] ) : '';
			rzd_posts_mail(
				'Post zaplanowany automatycznie',
				'Automat przygotował i zaplanował post na ' . $lbl . ' (' . $name . ') – wyjdzie ' . wp_date( 'j.m H:i', $p['when'] ) . '.' . ( '' !== $ig ? ' ' . $ig : '' ) . "\n\n" . $p['text'] . "\n\n" . 'Coś nie tak? Do ' . wp_date( 'H:i', $p['when'] ) . ' możesz go poprawić albo „Cofnij planowanie”: ' . $url,
				$a['mail']
			);
			return 'zaplanowany #' . $p['id'];
		}
		$miss .= "\n\n" . 'Automatyczne zaplanowanie nie wyszło (' . $pp . ') – zatwierdź ręcznie.';
	} elseif ( $a['pub_auto'] ) {
		$miss .= "\n\n" . 'Nie zaplanowałem sam – ' . ( $dd['missing'] ? 'w zestawie brakuje dania' : 'godzina publikacji jest za blisko' ) . '.';
	}
	rzd_posts_mail(
		'Post czeka na zatwierdzenie',
		'Przygotowałem szkic posta na ' . $lbl . ' (' . $name . ').' . $miss . "\n\n" . $p['text'] . "\n\n" . 'Sprawdź i zatwierdź – opublikuje się ' . ( $p['when'] ? wp_date( 'j.m H:i', $p['when'] ) : 'o wybranej godzinie' ) . ': ' . $url,
		$a['mail']
	);
	return 'szkic #' . $p['id'];
}

/** Mail z postów: $to – adresy automatu; puste → „Mail o szkicu do” z ustawień → e-mail administratora. */
function rzd_posts_mail( $subject, $body, $to = '' ) {
	$s  = rzd_posts_settings();
	$to = '' !== trim( (string) $to ) ? $to : ( '' !== trim( $s['mail_to'] ) ? $s['mail_to'] : get_option( 'admin_email' ) );
	return wp_mail( $to, '[' . wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) . '] ' . $subject, $body );
}
