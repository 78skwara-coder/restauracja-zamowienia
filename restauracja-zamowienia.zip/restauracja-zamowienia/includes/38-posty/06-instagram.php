<?php
/**
 * Moduł 38-posty – Instagram (2.55.0). Konto profesjonalne połączone ze stroną Facebooka; ten sam token strony
 * (Graph API, graph.facebook.com) z uprawnieniami instagram_basic i instagram_content_publish.
 * Konto: „Sprawdź Instagram” (Połączenia API) – strona → instagram_business_account {id, username} → rzd_api
 * (ig_id, ig_user). Publikacja: kontener (/{ig}/media, image_url – Instagram sam pobiera plik, więc musi być
 * publiczny; kilka zdjęć – karuzela, do 10), oczekiwanie na status FINISHED, /{ig}/media_publish, permalink.
 * Zdjęcia: JPEG w proporcjach 4:5 – 1,91:1 (wymóg Instagrama) – docięta kopia posta (05-zdjecia); format
 * „oryginał” → najbliższy z 4:5 / 1:1 / 1,91:1. Instagram przez API nie planuje – o godzinie publikacji wysyła
 * zdarzenie WP-Cron rzd_posts_ig_cron (Facebook planuje sam). Stan Instagrama osobno od Facebooka (meta _ig_*).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Instagram połączony (ID konta zapisane). */
function rzd_posts_ig_on() {
	return '' !== rzd_posts_settings()['ig_id'];
}

/** „Sprawdź Instagram”: konto połączone ze stroną. [ ok, @nazwa | komunikat ]. */
function rzd_posts_ig_check() {
	$page = rzd_posts_settings()['fb_page'];
	if ( '' === $page || '' === rzd_posts_secret( 'fb_token' ) ) {
		return array( false, 'Najpierw połącz stronę Facebooka (ID strony i token, „Sprawdź połączenie”).' );
	}
	list( $ok, $j ) = rzd_posts_fb_call( 'GET', $page, array( 'fields' => 'instagram_business_account{id,username}' ) );
	if ( ! $ok ) {
		return array( false, $j );
	}
	if ( empty( $j['instagram_business_account']['id'] ) ) {
		rzd_api_save( array( 'ig_id' => '', 'ig_user' => '' ) );
		return array( false, 'Strona nie ma połączonego konta firmowego na Instagramie albo token nie ma uprawnienia instagram_basic. Sprawdź: Instagram → konto profesjonalne połączone z tą stroną; w aplikacji Meta uprawnienia instagram_basic i instagram_content_publish – potem nowy token strony.' );
	}
	$ig = $j['instagram_business_account'];
	rzd_api_save( array( 'ig_id' => (string) $ig['id'], 'ig_user' => isset( $ig['username'] ) ? (string) $ig['username'] : '' ) );
	return array( true, '@' . ( isset( $ig['username'] ) ? $ig['username'] : $ig['id'] ) );
}

/** Format zdjęcia na Instagram: format posta; „oryginał” → najbliższy dozwolony (4:5 … 1,91:1). */
function rzd_posts_ig_ratio( $p, $ph ) {
	$r = rzd_posts_ratio_for( $p );
	if ( 'orig' !== $r ) {
		return $r;
	}
	$m = ! empty( $ph['id'] ) ? wp_get_attachment_metadata( (int) $ph['id'] ) : array();
	$x = ! empty( $m['width'] ) && ! empty( $m['height'] ) ? $m['width'] / $m['height'] : 0.8;
	$best = '4:5';
	foreach ( array( '4:5' => 0.8, '1:1' => 1.0, '1.91:1' => 1.91 ) as $k => $v ) {
		if ( abs( $x - $v ) < abs( $x - rzd_posts_ratios()[ $best ][1] ) ) {
			$best = $k;
		}
	}
	return $best;
}

/** Publiczny adres pliku z katalogu uploads ('' – plik spoza uploads). */
function rzd_posts_file_url( $path ) {
	$u    = wp_upload_dir();
	$base = wp_normalize_path( trailingslashit( $u['basedir'] ) );
	$path = wp_normalize_path( (string) $path );
	return 0 === strpos( $path, $base ) ? trailingslashit( $u['baseurl'] ) . str_replace( '%2F', '/', rawurlencode( substr( $path, strlen( $base ) ) ) ) : '';
}

/** Podpis: Instagram przyjmuje do 2200 znaków. */
function rzd_posts_ig_caption( $text ) {
	$text = trim( (string) $text );
	return mb_strlen( $text ) > 2200 ? rtrim( mb_substr( $text, 0, 2199 ) ) . '…' : $text;
}

/** Czeka, aż Instagram przetworzy kontener (zdjęcia zwykle od razu). [ ok, '' | komunikat ]. */
function rzd_posts_ig_wait( $cid ) {
	$tries = (int) apply_filters( 'rzd_posts_ig_wait_tries', 8 );
	for ( $i = 0; $i < $tries; $i++ ) {
		list( $ok, $j ) = rzd_posts_fb_call( 'GET', $cid, array( 'fields' => 'status_code,status' ) );
		if ( ! $ok ) {
			return array( false, $j );
		}
		$st = isset( $j['status_code'] ) ? (string) $j['status_code'] : 'FINISHED';
		if ( 'FINISHED' === $st || 'PUBLISHED' === $st ) {
			return array( true, '' );
		}
		if ( in_array( $st, array( 'ERROR', 'EXPIRED' ), true ) ) {
			return array( false, 'Instagram nie przyjął zdjęcia (' . ( isset( $j['status'] ) ? $j['status'] : $st ) . ').' );
		}
		if ( $i < $tries - 1 ) {
			sleep( (int) apply_filters( 'rzd_posts_ig_wait_secs', 2 ) );
		}
	}
	return array( false, 'Instagram długo przetwarza zdjęcie – spróbuj „Ponów na Instagramie” za chwilę.' );
}

function rzd_posts_ig_fail( $post_id, $msg ) {
	update_post_meta( $post_id, '_ig_status', 'error' );
	update_post_meta( $post_id, '_ig_err', $msg );
	return array( false, $msg );
}

/** Publikacja na Instagramie teraz. [ ok, post | komunikat ]. */
function rzd_posts_ig_publish( $post_id ) {
	$p = rzd_posts_get( $post_id );
	if ( ! $p ) {
		return array( false, 'Nie znaleziono posta.' );
	}
	if ( 'published' === $p['ig_status'] ) {
		return array( false, 'Ten post jest już na Instagramie.' );
	}
	$ig = rzd_posts_settings()['ig_id'];
	if ( '' === $ig ) {
		return rzd_posts_ig_fail( $post_id, 'Instagram nie jest połączony (Panel → Połączenia API → Sprawdź Instagram).' );
	}
	if ( ! $p['photos'] ) {
		return rzd_posts_ig_fail( $post_id, 'Instagram wymaga zdjęcia – post bez zdjęcia poszedł tylko na Facebooka.' );
	}
	if ( function_exists( 'set_time_limit' ) ) {
		@set_time_limit( 180 ); // phpcs:ignore
	}
	$urls  = array();
	$ratio = rzd_posts_ig_ratio( $p, $p['photos'][0] ); // karuzela: jeden format dla wszystkich (Instagram tnie wg pierwszego)
	foreach ( array_slice( $p['photos'], 0, 10 ) as $ph ) {
		list( $path ) = rzd_posts_photo_file( $ph, $ratio );
		$url = $path ? rzd_posts_file_url( $path ) : '';
		if ( '' === $url ) {
			return rzd_posts_ig_fail( $post_id, 'Nie udało się przygotować zdjęcia z publicznym adresem dla Instagrama.' );
		}
		$urls[] = $url;
	}
	$cap = rzd_posts_ig_caption( $p['text'] );
	if ( 1 === count( $urls ) ) {
		list( $ok, $j ) = rzd_posts_fb_call( 'POST', $ig . '/media', array( 'image_url' => $urls[0], 'caption' => $cap ) );
	} else {
		$kids = array();
		foreach ( $urls as $u ) {
			list( $okc, $jc ) = rzd_posts_fb_call( 'POST', $ig . '/media', array( 'image_url' => $u, 'is_carousel_item' => 'true' ) );
			if ( ! $okc ) {
				return rzd_posts_ig_fail( $post_id, str_replace( 'Facebook: ', 'Instagram: ', $jc ) );
			}
			$kids[] = $jc['id'];
		}
		foreach ( $kids as $k ) {
			list( $okw, $mw ) = rzd_posts_ig_wait( $k );
			if ( ! $okw ) {
				return rzd_posts_ig_fail( $post_id, $mw );
			}
		}
		list( $ok, $j ) = rzd_posts_fb_call( 'POST', $ig . '/media', array( 'media_type' => 'CAROUSEL', 'children' => implode( ',', $kids ), 'caption' => $cap ) );
	}
	if ( ! $ok ) {
		return rzd_posts_ig_fail( $post_id, str_replace( 'Facebook: ', 'Instagram: ', $j ) );
	}
	list( $okw, $mw ) = rzd_posts_ig_wait( $j['id'] );
	if ( ! $okw ) {
		return rzd_posts_ig_fail( $post_id, $mw );
	}
	list( $okp, $jp ) = rzd_posts_fb_call( 'POST', $ig . '/media_publish', array( 'creation_id' => $j['id'] ) );
	if ( ! $okp ) {
		return rzd_posts_ig_fail( $post_id, str_replace( 'Facebook: ', 'Instagram: ', $jp ) );
	}
	$mid = isset( $jp['id'] ) ? (string) $jp['id'] : '';
	$url = '';
	if ( '' !== $mid ) {
		list( $okl, $jl ) = rzd_posts_fb_call( 'GET', $mid, array( 'fields' => 'permalink' ) );
		$url = $okl && ! empty( $jl['permalink'] ) ? (string) $jl['permalink'] : '';
	}
	rzd_posts_save_post( array( 'id' => $post_id, 'day' => $p['day'], 'text' => $p['text'], 'ig_status' => 'published', 'ig_id' => $mid, 'ig_url' => $url, 'ig_err' => '', 'ig_when' => time() ) );
	return array( true, rzd_posts_get( $post_id ) );
}

/**
 * Po publikacji / zaplanowaniu na Facebooku: Instagram teraz albo zdarzenie WP-Cron o tej samej godzinie.
 * Zwraca dopisek do komunikatu ('' – Instagram nie dotyczy).
 */
function rzd_posts_ig_after_fb( $post_id, $when ) {
	$p = rzd_posts_get( $post_id );
	if ( ! $p || ! $p['ig'] || ! rzd_posts_ig_on() || 'published' === $p['ig_status'] ) {
		return '';
	}
	if ( ! $p['photos'] ) {
		rzd_posts_ig_fail( $post_id, 'Instagram wymaga zdjęcia – post bez zdjęcia poszedł tylko na Facebooka.' );
		return 'Instagram pominięty – post nie ma zdjęcia.';
	}
	if ( $when ) {
		wp_clear_scheduled_hook( 'rzd_posts_ig_cron', array( (int) $post_id ) );
		wp_schedule_single_event( (int) $when, 'rzd_posts_ig_cron', array( (int) $post_id ) );
		rzd_posts_save_post( array( 'id' => $post_id, 'day' => $p['day'], 'text' => $p['text'], 'ig_status' => 'scheduled', 'ig_when' => (int) $when, 'ig_err' => '' ) );
		return 'Instagram – o tej samej godzinie.';
	}
	list( $ok, $r ) = rzd_posts_ig_publish( $post_id );
	return $ok ? 'Opublikowano też na Instagramie.' : 'Instagram: nie udało się – ' . $r;
}

/** Cofnięcie zaplanowanego Instagrama (razem z cofnięciem Facebooka). */
function rzd_posts_ig_unschedule( $post_id ) {
	wp_clear_scheduled_hook( 'rzd_posts_ig_cron', array( (int) $post_id ) );
	if ( 'scheduled' === get_post_meta( $post_id, '_ig_status', true ) ) {
		update_post_meta( $post_id, '_ig_status', '' );
		update_post_meta( $post_id, '_ig_when', 0 );
	}
}

/** Zdarzenie WP-Cron o godzinie publikacji: tylko gdy post nadal zaplanowany / opublikowany na Facebooku. */
add_action( 'rzd_posts_ig_cron', function ( $post_id ) {
	$p = rzd_posts_get( (int) $post_id );
	if ( ! $p || 'scheduled' !== $p['ig_status'] || ! in_array( $p['status'], array( 'scheduled', 'published' ), true ) ) {
		return;
	}
	list( $ok, $r ) = rzd_posts_ig_publish( (int) $post_id );
	if ( ! $ok && function_exists( 'rzd_posts_mail' ) ) {
		rzd_posts_mail( 'Post nie wyszedł na Instagramie', 'Post na ' . ( $p['day'] ? rzd_dc_date_label( $p['day'] ) : 'Facebooka' ) . ' jest na Facebooku, ale Instagram go nie przyjął: ' . $r . "\n\nPonów w Panelu → Post dnia (przycisk „Ponów na Instagramie”)." );
	}
} );
