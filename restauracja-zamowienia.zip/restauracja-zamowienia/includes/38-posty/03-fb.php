<?php
/**
 * Moduł 38-posty – Facebook (Graph API): sprawdzenie połączenia, publikacja teraz albo o godzinie
 * (Facebook sam publikuje – scheduled_publish_time, 10 min – 30 dni naprzód), usunięcie zaplanowanego.
 * Zdjęcia wysyłane jako pliki (multipart) – działa też na sklepie bez publicznego adresu; najpierw każde zdjęcie
 * jako niepublikowane (przy planowaniu temporary=true), potem jeden post z attached_media.
 * Wymaga tokenu STRONY z uprawnieniem pages_manage_posts (aplikacja Meta, Facebook Login).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function rzd_posts_fb_base() {
	return apply_filters( 'rzd_posts_fb_base', 'https://graph.facebook.com/v26.0/' );
}

/** Zapytanie do Graph API. $files = [ pole => ścieżka ]. [ ok, odpowiedź | komunikat ]. */
function rzd_posts_fb_call( $method, $path, $params = array(), $files = array() ) {
	$token = rzd_posts_secret( 'fb_token' );
	if ( '' === $token ) {
		return array( false, 'Brak tokenu strony Facebooka (Post dnia → Ustawienia).' );
	}
	$params['access_token'] = $token;
	$args = array( 'timeout' => 60, 'method' => $method );
	if ( 'GET' === $method || 'DELETE' === $method ) {
		$url = rzd_posts_fb_base() . $path . '?' . http_build_query( $params );
	} else {
		$url = rzd_posts_fb_base() . $path;
		if ( $files ) {
			$b    = 'rzd' . wp_generate_password( 24, false );
			$body = '';
			foreach ( $params as $k => $v ) {
				$body .= "--$b\r\nContent-Disposition: form-data; name=\"$k\"\r\n\r\n$v\r\n";
			}
			foreach ( $files as $k => $p ) {
				$mime  = wp_check_filetype( $p )['type'];
				$body .= "--$b\r\nContent-Disposition: form-data; name=\"$k\"; filename=\"" . basename( $p ) . "\"\r\nContent-Type: " . ( $mime ? $mime : 'image/jpeg' ) . "\r\n\r\n" . file_get_contents( $p ) . "\r\n"; // phpcs:ignore
			}
			$body .= "--$b--\r\n";
			$args['headers'] = array( 'Content-Type' => 'multipart/form-data; boundary=' . $b );
			$args['body']    = $body;
		} else {
			$args['body'] = $params;
		}
	}
	$r = wp_remote_request( $url, $args );
	if ( is_wp_error( $r ) ) {
		return array( false, 'Brak połączenia z Facebookiem: ' . $r->get_error_message() );
	}
	$j = json_decode( wp_remote_retrieve_body( $r ), true );
	if ( (int) wp_remote_retrieve_response_code( $r ) >= 400 || isset( $j['error'] ) ) {
		$m = isset( $j['error']['message'] ) ? $j['error']['message'] : 'HTTP ' . wp_remote_retrieve_response_code( $r );
		if ( isset( $j['error']['code'] ) && 190 === (int) $j['error']['code'] ) {
			$m = 'Token strony wygasł albo jest nieprawidłowy – wygeneruj nowy (' . $m . ').';
		}
		return array( false, 'Facebook: ' . $m );
	}
	return array( true, is_array( $j ) ? $j : array() );
}

/** Sprawdzenie: czy token pasuje do strony. [ ok, nazwa strony | komunikat ]. */
function rzd_posts_fb_check() {
	$page = rzd_posts_settings()['fb_page'];
	if ( '' === $page ) {
		return array( false, 'Wpisz ID strony Facebooka.' );
	}
	list( $ok, $j ) = rzd_posts_fb_call( 'GET', $page, array( 'fields' => 'id,name' ) );
	if ( ! $ok ) {
		return array( false, $j );
	}
	return array( true, isset( $j['name'] ) ? $j['name'] : $page );
}

/**
 * Publikuje post z panelu. $when = 0 → teraz; inaczej znacznik czasu (Facebook opublikuje sam).
 * Zapisuje status, id posta, błąd. [ ok, post | komunikat ].
 */
function rzd_posts_fb_publish( $post_id, $when = 0 ) {
	$p = rzd_posts_get( $post_id );
	if ( ! $p ) {
		return array( false, 'Nie znaleziono posta.' );
	}
	if ( in_array( $p['status'], array( 'scheduled', 'published' ), true ) ) {
		return array( false, 'Ten post jest już ' . ( 'published' === $p['status'] ? 'opublikowany' : 'zaplanowany' ) . ' na Facebooku.' );
	}
	if ( '' === trim( $p['text'] ) ) {
		return array( false, 'Post nie ma tekstu.' );
	}
	$when = (int) $when;
	if ( $when && ( $when < time() + 10 * MINUTE_IN_SECONDS || $when > time() + 30 * DAY_IN_SECONDS ) ) {
		return array( false, 'Facebook planuje posty od 10 minut do 30 dni naprzód. Wybierz inną godzinę albo „Opublikuj teraz”.' );
	}
	$page = rzd_posts_settings()['fb_page'];
	if ( '' === $page ) {
		return array( false, 'Wpisz ID strony Facebooka (Post dnia → Ustawienia).' );
	}
	$media = array();
	foreach ( $p['photos'] as $ph ) {
		$path = ! empty( $ph['id'] ) ? get_attached_file( (int) $ph['id'] ) : '';
		if ( ! $path || ! is_readable( $path ) ) {
			continue;
		}
		$args = array( 'published' => 'false' );
		if ( $when ) {
			$args['temporary'] = 'true'; // zdjęcia do posta zaplanowanego
		}
		list( $ok, $j ) = rzd_posts_fb_call( 'POST', $page . '/photos', $args, array( 'source' => $path ) );
		if ( ! $ok ) {
			return rzd_posts_fb_fail( $post_id, $j );
		}
		$media[] = $j['id'];
	}
	$args = array( 'message' => $p['text'] );
	foreach ( $media as $i => $mid ) {
		$args[ 'attached_media[' . $i . ']' ] = wp_json_encode( array( 'media_fbid' => (string) $mid ) );
	}
	if ( $when ) {
		$args['published']              = 'false';
		$args['scheduled_publish_time'] = (string) $when;
	}
	list( $ok, $j ) = rzd_posts_fb_call( 'POST', $page . '/feed', $args );
	if ( ! $ok ) {
		return rzd_posts_fb_fail( $post_id, $j );
	}
	rzd_posts_save_post( array(
		'id'     => $post_id,
		'day'    => $p['day'],
		'text'   => $p['text'],
		'status' => $when ? 'scheduled' : 'published',
		'when'   => $when ? $when : time(),
		'fb_id'  => isset( $j['id'] ) ? (string) $j['id'] : '',
		'err'    => '',
		'by'     => is_user_logged_in() ? wp_get_current_user()->display_name : $p['by'],
	) );
	return array( true, rzd_posts_get( $post_id ) );
}

function rzd_posts_fb_fail( $post_id, $msg ) {
	update_post_meta( $post_id, '_err', $msg );
	return array( false, $msg );
}

/** Usuwa zaplanowany post z Facebooka (wraca do szkicu). */
function rzd_posts_fb_unschedule( $post_id ) {
	$p = rzd_posts_get( $post_id );
	if ( ! $p || 'scheduled' !== $p['status'] ) {
		return array( false, 'Ten post nie jest zaplanowany.' );
	}
	if ( '' !== $p['fb'] ) {
		list( $ok, $j ) = rzd_posts_fb_call( 'DELETE', $p['fb'] );
		if ( ! $ok ) {
			return array( false, $j );
		}
	}
	update_post_meta( $post_id, '_status', 'draft' );
	update_post_meta( $post_id, '_fb_id', '' );
	return array( true, rzd_posts_get( $post_id ) );
}

/** Link do posta na Facebooku (id „strona_post”). */
function rzd_posts_fb_url( $fb_id ) {
	return '' !== (string) $fb_id ? 'https://www.facebook.com/' . rawurlencode( (string) $fb_id ) : '';
}
