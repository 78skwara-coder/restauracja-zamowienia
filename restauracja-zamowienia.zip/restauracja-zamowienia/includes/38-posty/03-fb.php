<?php
/**
 * Moduł 38-posty – Facebook (Graph API): sprawdzenie połączenia, publikacja teraz albo o godzinie
 * (Facebook sam publikuje – scheduled_publish_time, 10 min – 30 dni naprzód), usunięcie zaplanowanego.
 * Zdjęcia wysyłane jako pliki (multipart) – działa też na sklepie bez publicznego adresu; najpierw każde zdjęcie
 * jako niepublikowane (przy planowaniu temporary=true), potem jeden post z attached_media.
 * Wymaga tokenu STRONY z uprawnieniem pages_manage_posts (aplikacja Meta, Facebook Login).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function rzd_posts_fb_base() {
	return apply_filters( 'rzd_posts_fb_base', 'https://graph.facebook.com/v26.0/' );
}

/** Zapytanie do Graph API. $files = [ pole => ścieżka ]. [ ok, odpowiedź | komunikat ]. */
function rzd_posts_fb_call( $method, $path, $params = array(), $files = array(), $token = null ) {
	$token = null === $token ? rzd_posts_secret( 'fb_token' ) : $token;
	if ( '' === $token ) {
		return array( false, 'Brak tokenu strony Facebooka (Panel → Połączenia API).' );
	}
	$params['access_token'] = $token;
	$args = array( 'timeout' => 60, 'method' => $method );
	if ( 'GET' === $method || 'DELETE' === $method ) {
		$url = rzd_posts_fb_base() . $path . '?' . http_build_query( $params );
	} else {
		$url = rzd_posts_fb_base() . $path;
		if ( $files ) {
			$b    = 'rzd' . wp_generate_password( 24, false );
			$body = '';
			foreach ( $params as $k => $v ) {
				$body .= "--$b\r\nContent-Disposition: form-data; name=\"$k\"\r\n\r\n$v\r\n";
			}
			foreach ( $files as $k => $p ) {
				$mime  = wp_check_filetype( $p )['type'];
				$body .= "--$b\r\nContent-Disposition: form-data; name=\"$k\"; filename=\"" . basename( $p ) . "\"\r\nContent-Type: " . ( $mime ? $mime : 'image/jpeg' ) . "\r\n\r\n" . file_get_contents( $p ) . "\r\n"; // phpcs:ignore
			}
			$body .= "--$b--\r\n";
			$args['headers'] = array( 'Content-Type' => 'multipart/form-data; boundary=' . $b );
			$args['body']    = $body;
		} else {
			$args['body'] = $params;
		}
	}
	$r = wp_remote_request( $url, $args );
	if ( is_wp_error( $r ) ) {
		return array( false, 'Brak połączenia z Facebookiem: ' . $r->get_error_message() );
	}
	$j = json_decode( wp_remote_retrieve_body( $r ), true );
	$GLOBALS['rzd_posts_fb_err'] = null;
	if ( (int) wp_remote_retrieve_response_code( $r ) >= 400 || isset( $j['error'] ) ) {
		$m = isset( $j['error']['message'] ) ? $j['error']['message'] : 'HTTP ' . wp_remote_retrieve_response_code( $r );
		$c = isset( $j['error']['code'] ) ? (int) $j['error']['code'] : 0;
		$GLOBALS['rzd_posts_fb_err'] = array( 'code' => $c, 'sub' => isset( $j['error']['error_subcode'] ) ? (int) $j['error']['error_subcode'] : 0, 'msg' => (string) $m ); // (2.58.0)
		if ( 190 === $c ) {
			$m = 'Token strony wygasł albo jest nieprawidłowy – wygeneruj nowy (' . $m . ').';
		} elseif ( false !== stripos( $m, 'publish_actions' ) ) {
			$m = 'Facebook dostał token Twojego konta zamiast tokenu strony. Kliknij „Sprawdź połączenie” w Ustawieniach – wtyczka spróbuje sama pobrać token strony.';
		} elseif ( false !== stripos( $m, 'instagram' ) && ( 10 === $c || 200 === $c || false !== stripos( $m, 'permission' ) ) ) {
			$m = 'Tokenowi brakuje uprawnień Instagrama (instagram_basic, instagram_content_publish) – dopisz je w aplikacji Meta i wygeneruj token strony jeszcze raz (' . $m . ').';
		} elseif ( false !== stripos( $m, 'pages_manage_posts' ) || false !== stripos( $m, 'pages_read_engagement' ) ) {
			$m = 'Tokenowi brakuje uprawnień do publikowania (pages_manage_posts, pages_read_engagement) – wygeneruj token z tymi uprawnieniami (' . $m . ').';
		}
		return array( false, 'Facebook: ' . $m );
	}
	return array( true, is_array( $j ) ? $j : array() );
}

/**
 * Sprawdzenie połączenia (2.48.2): czyj jest token (me + metadata.type). Token strony tej strony → OK. Token
 * konta (użytkownika) → wtyczka pobiera z niego token strony ({strona}?fields=access_token) i zapisuje go
 * zamiast wklejonego; z długoterminowego tokenu konta Facebook daje token strony bez wygasania. Gdy się nie da –
 * mówi, czego brakuje (uprawnienia, administrator strony, ID profilu zamiast strony).
 * [ ok, nazwa strony | komunikat, uwaga (pusta albo opis zamiany tokenu) ].
 */
function rzd_posts_fb_check() {
	$page = rzd_posts_settings()['fb_page'];
	if ( '' === $page ) {
		return array( false, 'Wpisz ID strony Facebooka.', '' );
	}
	list( $okM, $me ) = rzd_posts_fb_call( 'GET', 'me', array( 'fields' => 'id,name', 'metadata' => '1' ) );
	$type = $okM && isset( $me['metadata']['type'] ) ? (string) $me['metadata']['type'] : '';
	if ( 'user' === $type ) {
		if ( isset( $me['id'] ) && (string) $me['id'] === $page ) {
			return array( false, 'W polu „ID strony” jest ID Twojego profilu (' . $me['name'] . '), a nie strony. Wpisz ID strony – np. w Graph API Explorer: me/accounts.', '' );
		}
		list( $okP, $pj ) = rzd_posts_fb_call( 'GET', $page, array( 'fields' => 'id,name,access_token' ) );
		if ( $okP && ! empty( $pj['access_token'] ) ) {
			list( $okS ) = rzd_posts_save_settings( array( 'fb_token' => $pj['access_token'] ) );
			if ( $okS ) {
				return array( true, isset( $pj['name'] ) ? $pj['name'] : $page, 'Wklejony był token Twojego konta (' . $me['name'] . ') – wtyczka pobrała z niego token strony „' . ( isset( $pj['name'] ) ? $pj['name'] : $page ) . '” i zapisała go. Połączono.' );
			}
		}
		$miss = array();
		list( $okR, $pr ) = rzd_posts_fb_call( 'GET', 'me/permissions' );
		if ( $okR && isset( $pr['data'] ) ) {
			$granted = array();
			foreach ( (array) $pr['data'] as $x ) {
				if ( isset( $x['permission'], $x['status'] ) && 'granted' === $x['status'] ) {
					$granted[] = $x['permission'];
				}
			}
			$miss = array_values( array_diff( array( 'pages_show_list', 'pages_read_engagement', 'pages_manage_posts' ), $granted ) );
		}
		return array( false, 'To token Twojego konta (' . $me['name'] . '), a nie strony, i nie udało się pobrać z niego tokenu strony. ' . ( $miss ? 'Brakuje uprawnień: ' . implode( ', ', $miss ) . '.' : 'Sprawdź, czy jesteś administratorem strony i czy przy „Generate Access Token” zaznaczyłeś tę stronę.' ) . ' W Graph API Explorer wybierz w „User or Page” swoją stronę i wklej token strony.', '' );
	}
	if ( 'page' === $type && isset( $me['id'] ) && (string) $me['id'] !== $page ) {
		return array( false, 'Token jest od innej strony: „' . $me['name'] . '” (ID ' . $me['id'] . '), a w ustawieniach jest ID ' . $page . '. Popraw ID strony albo token.', '' );
	}
	list( $ok, $j ) = rzd_posts_fb_call( 'GET', $page, array( 'fields' => 'id,name' ) );
	if ( ! $ok ) {
		return array( false, $j, '' );
	}
	return array( true, isset( $j['name'] ) ? $j['name'] : $page, '' );
}

/**
 * Publikuje post z panelu. $when = 0 → teraz; inaczej znacznik czasu (Facebook opublikuje sam).
 * Zapisuje status, id posta, błąd. [ ok, post | komunikat ].
 */
function rzd_posts_fb_publish( $post_id, $when = 0 ) {
	$p = rzd_posts_get( $post_id );
	if ( ! $p ) {
		return array( false, 'Nie znaleziono posta.' );
	}
	if ( in_array( $p['status'], array( 'scheduled', 'published' ), true ) ) {
		return array( false, 'Ten post jest już ' . ( 'published' === $p['status'] ? 'opublikowany' : 'zaplanowany' ) . ' na Facebooku.' );
	}
	if ( '' === trim( $p['text'] ) ) {
		return array( false, 'Post nie ma tekstu.' );
	}
	$when = (int) $when;
	if ( $when && ( $when < time() + 10 * MINUTE_IN_SECONDS || $when > time() + 30 * DAY_IN_SECONDS ) ) {
		return array( false, 'Facebook planuje posty od 10 minut do 30 dni naprzód. Wybierz inną godzinę albo „Opublikuj teraz”.' );
	}
	$page = rzd_posts_settings()['fb_page'];
	if ( '' === $page ) {
		return array( false, 'Wpisz ID strony Facebooka (Panel → Połączenia API).' );
	}
	$media  = array();
	$ratio  = function_exists( 'rzd_posts_ratio_for' ) ? rzd_posts_ratio_for( $p ) : 'orig';
	$pnotes = array();
	foreach ( $p['photos'] as $ph ) { // (2.50.0) docięta kopia JPEG w formacie posta (05-zdjecia); „oryginał” – plik z biblioteki
		list( $path, $pn ) = function_exists( 'rzd_posts_photo_file' ) ? rzd_posts_photo_file( $ph, $ratio ) : array( ! empty( $ph['id'] ) ? get_attached_file( (int) $ph['id'] ) : '', '' );
		if ( '' !== $pn ) {
			$pnotes[ $pn ] = 1;
		}
		if ( ! $path || ! is_readable( $path ) ) {
			continue;
		}
		$args = array( 'published' => 'false' );
		if ( $when ) {
			$args['temporary'] = 'true'; // zdjęcia do posta zaplanowanego
		}
		list( $ok, $j ) = rzd_posts_fb_call( 'POST', $page . '/photos', $args, array( 'source' => $path ) );
		if ( ! $ok ) {
			return rzd_posts_fb_fail( $post_id, $j );
		}
		$media[] = $j['id'];
	}
	$args = array( 'message' => $p['text'] );
	foreach ( $media as $i => $mid ) {
		$args[ 'attached_media[' . $i . ']' ] = wp_json_encode( array( 'media_fbid' => (string) $mid ) );
	}
	if ( $when ) {
		$args['published']              = 'false';
		$args['scheduled_publish_time'] = (string) $when;
	}
	// (2.49.0) lokalizacja: ID strony z adresem (Ustawienia; puste = ta strona). Gdy Facebook jej nie przyjmie
	// (np. strona bez adresu) – ponownie bez lokalizacji, z uwagą przy poście.
	$s     = rzd_posts_settings();
	$place = ! empty( $p['place'] ) ? ( '' !== $s['place'] ? $s['place'] : $page ) : '';
	$note  = '';
	if ( '' !== $place ) {
		$args['place'] = $place;
	}
	list( $ok, $j ) = rzd_posts_fb_call( 'POST', $page . '/feed', $args );
	if ( ! $ok && '' !== $place ) {
		unset( $args['place'] );
		list( $ok, $j2 ) = rzd_posts_fb_call( 'POST', $page . '/feed', $args );
		if ( $ok ) {
			$note = 'Opublikowano bez lokalizacji – Facebook jej nie przyjął (' . preg_replace( '/^Facebook: /', '', $j ) . '). Sprawdź, czy strona-lokalizacja ma adres.';
		}
		$j = $j2;
	}
	if ( ! $ok ) {
		return rzd_posts_fb_fail( $post_id, $j );
	}
	rzd_posts_save_post( array(
		'id'     => $post_id,
		'day'    => $p['day'],
		'text'   => $p['text'],
		'status' => $when ? 'scheduled' : 'published',
		'when'   => $when ? $when : time(),
		'fb_id'  => isset( $j['id'] ) ? (string) $j['id'] : '',
		'err'    => trim( $note . ' ' . implode( ' ', array_keys( $pnotes ) ) ),
		'by'     => is_user_logged_in() ? wp_get_current_user()->display_name : $p['by'],
		'parked' => 0, // (2.50.0) z banku „Odłożone” na Facebooka
	) );
	return array( true, rzd_posts_get( $post_id ) );
}

function rzd_posts_fb_fail( $post_id, $msg ) {
	update_post_meta( $post_id, '_err', $msg );
	return array( false, $msg );
}

/**
 * (2.58.0) Ostatni błąd Facebooka to „tego obiektu nie ma” (post usunięty ręcznie na Facebooku): kod 100 z podkodem 33
 * albo komunikat „does not exist”. Uwaga: Facebook tym samym błędem odpowiada przy braku uprawnień do obiektu – dlatego
 * wywołujemy to tylko dla posta, który sami opublikowaliśmy tym tokenem.
 */
function rzd_posts_fb_err_gone() {
	$e = isset( $GLOBALS['rzd_posts_fb_err'] ) ? $GLOBALS['rzd_posts_fb_err'] : null;
	return $e && ( ( 100 === $e['code'] && 33 === $e['sub'] ) || false !== stripos( $e['msg'], 'does not exist' ) );
}

/** (2.58.0) Post nie istnieje już na Facebooku: znacznik _fb_gone, zaplanowany Instagram – cofnięty. */
function rzd_posts_fb_mark_gone( $post_id ) {
	update_post_meta( $post_id, '_fb_gone', time() );
	if ( function_exists( 'rzd_posts_ig_unschedule' ) ) {
		rzd_posts_ig_unschedule( $post_id );
	}
}

/** (2.58.0) „Sprawdź na Facebooku”: [ ok, true – jest | false – usunięty | komunikat błędu ]. */
function rzd_posts_fb_exists( $post_id ) {
	$p = rzd_posts_get( $post_id );
	if ( ! $p || '' === $p['fb'] ) {
		return array( false, 'Ten post nie był wysłany na Facebooka.' );
	}
	list( $ok, $j ) = rzd_posts_fb_call( 'GET', $p['fb'], array( 'fields' => 'id' ) );
	if ( $ok ) {
		delete_post_meta( $post_id, '_fb_gone' );
		return array( true, true );
	}
	if ( rzd_posts_fb_err_gone() ) {
		rzd_posts_fb_mark_gone( $post_id );
		return array( true, false );
	}
	return array( false, $j );
}

/** Usuwa zaplanowany post z Facebooka (wraca do szkicu). [ ok, post | komunikat, true gdy na Facebooku już go nie było ]. */
function rzd_posts_fb_unschedule( $post_id ) {
	$p = rzd_posts_get( $post_id );
	if ( ! $p || 'scheduled' !== $p['status'] ) {
		return array( false, 'Ten post nie jest zaplanowany.' );
	}
	$gone = false;
	if ( '' !== $p['fb'] ) {
		list( $ok, $j ) = rzd_posts_fb_call( 'DELETE', $p['fb'] );
		if ( ! $ok && ! rzd_posts_fb_err_gone() ) {
			return array( false, $j );
		}
		$gone = ! $ok; // (2.58.0) usunięty ręcznie na Facebooku – efekt ten sam, wracamy do szkicu
	}
	update_post_meta( $post_id, '_status', 'draft' );
	update_post_meta( $post_id, '_fb_id', '' );
	delete_post_meta( $post_id, '_fb_gone' );
	if ( function_exists( 'rzd_posts_ig_unschedule' ) ) { // (2.55.0) zaplanowany Instagram – też cofnięty
		rzd_posts_ig_unschedule( $post_id );
	}
	return array( true, rzd_posts_get( $post_id ), $gone );
}

/** Link do posta na Facebooku (id „strona_post”). */
function rzd_posts_fb_url( $fb_id ) {
	return '' !== (string) $fb_id ? 'https://www.facebook.com/' . rawurlencode( (string) $fb_id ) : '';
}
