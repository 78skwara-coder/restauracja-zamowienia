<?php
/**
 * Moduł 38-posty – Gemini: lista modeli i pisanie sekcji posta (2.48.2: aktywne sekcje, wskazówki do sekcji,
 * Interactions API z zapasem generateContent – rzd_posts_gemini_ask). Do AI idą: wskazówki z ustawień, nazwy i opisy
 * dań, dzień, dopisek; zdjęcia tylko przy włączonym „AI widzi zdjęcia”. Odpowiedź – JSON { klucz sekcji: tekst }
 * (tylko sekcje „AI”); stałe sekcje dokleja wtyczka (rzd_posts_assemble), z pustą linią między sekcjami.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ---------- Gemini – od 2.51.0 w module 39-api (dawne nazwy zostają dla zgodności) ---------- */
function rzd_posts_gemini_base() {
	return rzd_ai_gemini_base();
}

function rzd_posts_gemini_models( $key = null ) {
	return rzd_ai_gemini_models( $key );
}

function rzd_posts_gemini_ask( $model, $key, $req, $what, $timeout = 0 ) {
	return rzd_ai_gemini_ask( $model, $key, $req, $what, $timeout );
}

function rzd_posts_gemini_test() {
	return rzd_ai_gemini_test();
}

/** Sekcje użyte w poście danego rodzaju (aktywne i przypisane do rodzaju). */
function rzd_posts_sections_for( $kind ) {
	return array_values( array_filter( rzd_posts_settings()['sections'], function ( $x ) use ( $kind ) {
		return ! empty( $x['on'] ) && in_array( $kind, (array) $x['ty'], true );
	} ) );
}

/** Treść zapytania – osobno, żeby dało się ją sprawdzić w testach. $dd['kind']: set | product | topic. */
function rzd_posts_prompt( $dd, $extra ) {
	$s    = rzd_posts_settings();
	$kind = isset( $dd['kind'] ) ? $dd['kind'] : 'set';
	$on   = rzd_posts_sections_for( $kind ); // nieaktywne i z innych rodzajów postów nie idą do AI
	$ai   = array_values( array_filter( $on, function ( $x ) { return 'ai' === $x['m']; } ) );
	$all  = array_map( function ( $x ) { return $x['n'] . ( 'ai' === $x['m'] ? '' : ' (stały tekst – dopiszemy sami, nie pisz go)' ); }, $on );
	$lines = array();
	if ( 'product' === $kind ) {
		$lines[] = 'Post o jednej pozycji z naszej karty (nie o zestawie dnia): ' . $dd['setName'] . '.';
		if ( '' !== $dd['cat'] ) {
			$lines[] = 'Kategoria: ' . $dd['cat'] . '.';
		}
		if ( '' !== $dd['desc'] ) {
			$lines[] = 'Opis z karty: ' . mb_substr( $dd['desc'], 0, 600 );
		}
	} elseif ( 'topic' === $kind ) {
		$lines[] = 'Post na dowolny temat (nie o zestawie dnia). Temat od restauracji:';
		$lines[] = trim( $dd['topic'] );
	} else {
		$lines[] = 'Zapowiedź na: ' . rzd_dc_date_label( $dd['day'] ) . ' (post publikujemy wieczorem dzień wcześniej, więc to „jutro”).';
		$lines[] = 'Zestaw: ' . $dd['setName'] . '.';
		$lines[] = 'Dania w zestawie:';
		foreach ( $dd['dishes'] as $d ) {
			$lines[] = '- ' . $d['name'] . ( '' !== $d['role'] ? ' (' . $d['role'] . ')' : '' ) . ( '' !== $d['desc'] ? ': ' . mb_substr( $d['desc'], 0, 300 ) : '' );
		}
	}
	if ( '' !== trim( (string) $extra ) ) {
		$lines[] = 'Dopisek od restauracji: ' . trim( $extra );
	}
	$lines[] = '';
	$lines[] = 'Układ całego posta (kolejność sekcji): ' . implode( ' → ', $all ) . '.';
	$lines[] = 'Napisz TYLKO te sekcje (przy każdej jej wskazówki – mają pierwszeństwo przed ogólnymi):';
	foreach ( $ai as $x ) {
		$h       = trim( preg_replace( '/\s*\n\s*/', ' ', (string) $x['h'] ) );
		$lines[] = '* ' . $x['n'] . ' (klucz „' . $x['k'] . '”) – ' . ( '' !== $h ? 'wskazówki: ' . $h : 'bez dodatkowych wskazówek, pisz według ogólnych zasad' );
	}
	if ( 'set' !== $kind ) { // zasady i wskazówki sekcji bywają pisane pod obiad dnia – tu nie pasują
		$lines[] = 'Jeśli zasady ogólne albo wskazówki sekcji dotyczą obiadu dnia, zestawu lub „jutra”, a ten post jest o czymś innym – pomiń je.';
	}
	$lines[] = 'Zwróć JSON z tymi kluczami; wartości to gotowy tekst sekcji (może mieć kilka linii, bez nagłówka z nazwą sekcji, bez markdown).';
	$about   = isset( $s['about'][ $kind ] ) ? trim( (string) $s['about'][ $kind ] ) : '';
	return array( // (2.49.1) zasady wspólne + „O czym jest post” tylko dla tego rodzaju
		'system' => trim( trim( $s['instructions'] ) . ( '' !== $about ? "\n\nO czym jest ten post: " . $about : '' ) ),
		'user'   => implode( "\n", $lines ),
		'keys'   => array_map( function ( $x ) { return $x['k']; }, $ai ),
	);
}

/** Zapytanie do Gemini. [ ok, [ klucz => tekst ] | komunikat ]. */
function rzd_posts_gemini_write( $dd, $extra, $photos = array() ) {
	$s = rzd_posts_settings();
	if ( ! rzd_ai_ready() ) {
		return array( false, 'Nie ma połączenia z AI – uzupełnij klucz i model w Panel → Połączenia API.' );
	}
	$pr   = rzd_posts_prompt( $dd, $extra );
	$imgs = array();
	if ( ! empty( $s['ai_images'] ) ) {
		foreach ( array_slice( (array) $photos, 0, 4 ) as $ph ) {
			$file = ! empty( $ph['id'] ) ? image_get_intermediate_size( (int) $ph['id'], 'medium' ) : null;
			$path = $file && ! empty( $file['path'] ) ? path_join( wp_upload_dir()['basedir'], $file['path'] ) : ( ! empty( $ph['id'] ) ? get_attached_file( (int) $ph['id'] ) : '' );
			if ( $path && is_readable( $path ) && filesize( $path ) < 4 * MB_IN_BYTES ) {
				$mime   = wp_check_filetype( $path )['type'];
				$imgs[] = array( 'mime' => $mime ? $mime : 'image/jpeg', 'data' => base64_encode( file_get_contents( $path ) ) ); // phpcs:ignore
			}
		}
	}
	list( $ok, $txt ) = rzd_ai_ask( array( // (2.53.0) wybrany dostawca (rzd_ai_use) albo domyślny
		'system' => $pr['system'],
		'text'   => $pr['user'],
		'images' => $imgs,
		'keys'   => $pr['keys'],
		'temp'   => 0.9,
	), 'post' );
	if ( ! $ok ) {
		return array( false, $txt );
	}
	$txt = trim( preg_replace( '/^```(?:json)?|```$/m', '', $txt ) );
	$out = json_decode( $txt, true );
	if ( ! is_array( $out ) ) {
		return array( false, 'AI nie zwróciło tekstu posta. Spróbuj ponownie albo wybierz inny model / dostawcę.' );
	}
	$res = array();
	foreach ( $pr['keys'] as $k ) {
		$res[ $k ] = isset( $out[ $k ] ) && is_scalar( $out[ $k ] ) ? trim( (string) $out[ $k ] ) : '';
	}
	return array( true, $res );
}

/**
 * Cały tekst posta: sekcje w kolejności z ustawień; w stałych {zestaw}, {dzien}, {dania}. (2.49.1) Odstęp między
 * sekcjami = większa z wartości „pod” wyższej i „nad” niższej (puste linie 0–3); pusta sekcja znika razem
 * z odstępami, nad pierwszą i pod ostatnią nic. Druga i trzecia pusta linia to znak U+2800 (wygląda jak pusta) –
 * Facebook skleja kilka pustych linii w jedną.
 */
function rzd_posts_assemble( $ai, $dd ) {
	$kind = isset( $dd['kind'] ) ? $dd['kind'] : 'set';
	$rep  = array( // w poście o produkcie {zestaw} i {dania} = nazwa produktu; w temacie – puste
		'{zestaw}' => (string) $dd['setName'],
		'{dzien}'  => '' !== (string) $dd['day'] ? rzd_dc_date_label( $dd['day'] ) : '',
		'{dania}'  => 'product' === $kind ? (string) $dd['setName'] : implode( ', ', array_map( function ( $x ) { return $x['name']; }, (array) $dd['dishes'] ) ),
	);
	$out  = '';
	$prev = null;
	foreach ( rzd_posts_sections_for( $kind ) as $sec ) { // nieaktywne i z innych rodzajów – nie trafiają do posta
		$t = 'ai' === $sec['m'] ? ( isset( $ai[ $sec['k'] ] ) ? $ai[ $sec['k'] ] : '' ) : strtr( $sec['t'], $rep );
		$t = trim( preg_replace( "/\n{3,}/", "\n\n", str_replace( "\r", '', $t ) ) );
		if ( '' === $t ) {
			continue;
		}
		if ( null !== $prev ) {
			$out .= rzd_posts_gap_text( max( (int) $prev['sa'], isset( $sec['sb'] ) ? (int) $sec['sb'] : 0 ) );
		}
		$out .= $t;
		$prev = $sec + array( 'sa' => 1 );
	}
	return $out;
}

/** Przejście między sekcjami: $n pustych linii (0 = następna linia); od drugiej – U+2800, żeby FB ich nie skleił. */
function rzd_posts_gap_text( $n ) {
	$n = max( 0, min( 3, (int) $n ) );
	if ( ! $n ) {
		return "\n";
	}
	return "\n" . implode( "\n", array_merge( array( '' ), array_fill( 0, $n - 1, "\u{2800}" ) ) ) . "\n";
}

/** Generuje szkic: nowy albo nadpisuje tekst istniejącego (bez zmiany zdjęć). [ ok, post | komunikat ]. */
function rzd_posts_generate( $set_id, $day, $extra = '', $photos = null, $post_id = 0, $src = 'manual' ) {
	$dd = rzd_posts_day_data( $set_id, $day );
	if ( ! $dd['dishes'] ) {
		return array( false, 'Zestaw „' . $dd['setName'] . '” nie ma dań na ' . rzd_dc_date_label( $day ) . ' – uzupełnij harmonogram zestawu.' );
	}
	$photos = null === $photos ? $dd['photos'] : $photos;
	if ( ! array_filter( rzd_posts_sections_for( 'set' ), function ( $x ) { return 'ai' === $x['m']; } ) ) {
		return array( false, 'Brak aktywnej sekcji AI w postach o zestawie (Ustawienia → Sekcje posta).' );
	}
	list( $ok, $ai ) = rzd_posts_gemini_write( $dd, $extra, $photos );
	if ( ! $ok ) {
		return array( false, $ai );
	}
	$id = rzd_posts_save_post( array(
		'id'     => $post_id,
		'day'    => $day,
		'set'    => (int) $set_id,
		'status' => 'draft',
		'text'   => rzd_posts_assemble( $ai, $dd ),
		'photos' => array_values( $photos ),
		'when'   => $post_id ? (int) get_post_meta( $post_id, '_when', true ) : rzd_posts_default_when( $day, $set_id ),
		'extra'  => (string) $extra,
		'src'    => $src,
		'err'    => '',
		'by'     => is_user_logged_in() ? wp_get_current_user()->display_name : 'automat',
		'kind'   => 'set',
	) );
	return array( true, rzd_posts_get( $id ) );
}

/**
 * (2.49.0) Post o produkcie albo na dowolny temat. Bez dnia (nie liczy się do „posta na jutro” automatu),
 * publikacja domyślnie o najbliższej godzinie publikacji. [ ok, post | komunikat ].
 */
function rzd_posts_generate_other( $kind, $product_id, $topic, $extra = '', $photos = null, $post_id = 0 ) {
	$kinds = rzd_posts_kinds();
	if ( 'product' === $kind ) {
		$dd = rzd_posts_product_data( $product_id );
		if ( ! $dd ) {
			return array( false, 'Wybierz produkt.' );
		}
	} elseif ( 'topic' === $kind ) {
		$topic = trim( (string) $topic );
		if ( '' === $topic ) {
			return array( false, 'Napisz, o czym ma być post.' );
		}
		$dd = array( 'kind' => 'topic', 'topic' => $topic, 'setName' => '', 'day' => '', 'dishes' => array(), 'photos' => array() );
	} else {
		return array( false, 'Nieznany rodzaj posta.' );
	}
	if ( ! array_filter( rzd_posts_sections_for( $kind ), function ( $x ) { return 'ai' === $x['m']; } ) ) {
		return array( false, 'Brak aktywnej sekcji AI w postach „' . $kinds[ $kind ] . '” (Ustawienia → Sekcje posta).' );
	}
	$photos = null === $photos ? $dd['photos'] : $photos;
	list( $ok, $ai ) = rzd_posts_gemini_write( $dd, $extra, $photos );
	if ( ! $ok ) {
		return array( false, $ai );
	}
	$id = rzd_posts_save_post( array(
		'id'      => $post_id,
		'day'     => '',
		'set'     => 0,
		'kind'    => $kind,
		'product' => 'product' === $kind ? (int) $dd['product'] : 0,
		'topic'   => 'topic' === $kind ? $topic : '',
		'status'  => 'draft',
		'text'    => rzd_posts_assemble( $ai, $dd ),
		'photos'  => array_values( $photos ),
		'when'    => $post_id && (int) get_post_meta( $post_id, '_when', true ) > time() ? (int) get_post_meta( $post_id, '_when', true ) : rzd_posts_next_pub_time(),
		'extra'   => (string) $extra,
		'src'     => 'manual',
		'err'     => '',
		'by'      => is_user_logged_in() ? wp_get_current_user()->display_name : '',
	) );
	return array( true, rzd_posts_get( $id ) );
}

