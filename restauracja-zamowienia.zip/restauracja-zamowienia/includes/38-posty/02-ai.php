<?php
/**
 * Moduł 38-posty – Gemini: lista modeli i pisanie sekcji posta. Do AI idą: wskazówki z ustawień, nazwy i opisy
 * dań, dzień, dopisek; zdjęcia tylko przy włączonym „AI widzi zdjęcia”. Odpowiedź – JSON { klucz sekcji: tekst }
 * (tylko sekcje „AI”); stałe sekcje dokleja wtyczka (rzd_posts_assemble), z pustą linią między sekcjami.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function rzd_posts_gemini_base() {
	return apply_filters( 'rzd_posts_gemini_base', 'https://generativelanguage.googleapis.com/v1beta/' );
}

/** Modele, które piszą tekst (generateContent). [ ok, lista | komunikat ]. */
function rzd_posts_gemini_models( $key = null ) {
	$key = null === $key ? rzd_posts_secret( 'gemini_key' ) : $key;
	if ( '' === $key ) {
		return array( false, 'Najpierw wpisz klucz API Gemini.' );
	}
	$r = wp_remote_get( rzd_posts_gemini_base() . 'models?pageSize=200', array( 'timeout' => 20, 'headers' => array( 'x-goog-api-key' => $key ) ) );
	if ( is_wp_error( $r ) ) {
		return array( false, 'Brak połączenia z Gemini: ' . $r->get_error_message() );
	}
	$j = json_decode( wp_remote_retrieve_body( $r ), true );
	if ( 200 !== (int) wp_remote_retrieve_response_code( $r ) ) {
		return array( false, 'Gemini odrzucił klucz: ' . ( isset( $j['error']['message'] ) ? $j['error']['message'] : 'HTTP ' . wp_remote_retrieve_response_code( $r ) ) );
	}
	$out = array();
	foreach ( isset( $j['models'] ) ? (array) $j['models'] : array() as $m ) {
		if ( empty( $m['name'] ) || ! in_array( 'generateContent', isset( $m['supportedGenerationMethods'] ) ? (array) $m['supportedGenerationMethods'] : array(), true ) ) {
			continue;
		}
		$id = preg_replace( '#^models/#', '', $m['name'] );
		if ( preg_match( '/embedding|aqa|imagen|tts|audio|image-generation|live/i', $id ) ) {
			continue;
		}
		$out[] = array( 'id' => $id, 'name' => isset( $m['displayName'] ) ? $m['displayName'] : $id );
	}
	return array( true, $out );
}

/** Treść zapytania – osobno, żeby dało się ją sprawdzić w testach. */
function rzd_posts_prompt( $dd, $extra ) {
	$s    = rzd_posts_settings();
	$ai   = array_values( array_filter( $s['sections'], function ( $x ) { return 'ai' === $x['m']; } ) );
	$all  = array_map( function ( $x ) { return $x['n'] . ( 'ai' === $x['m'] ? '' : ' (stały tekst – dopiszemy sami, nie pisz go)' ); }, $s['sections'] );
	$lines = array();
	$lines[] = 'Zapowiedź na: ' . rzd_dc_date_label( $dd['day'] ) . ' (post publikujemy wieczorem dzień wcześniej, więc to „jutro”).';
	$lines[] = 'Zestaw: ' . $dd['setName'] . '.';
	$lines[] = 'Dania w zestawie:';
	foreach ( $dd['dishes'] as $d ) {
		$lines[] = '- ' . $d['name'] . ( '' !== $d['role'] ? ' (' . $d['role'] . ')' : '' ) . ( '' !== $d['desc'] ? ': ' . mb_substr( $d['desc'], 0, 300 ) : '' );
	}
	if ( '' !== trim( (string) $extra ) ) {
		$lines[] = 'Dopisek od restauracji: ' . trim( $extra );
	}
	$lines[] = '';
	$lines[] = 'Układ całego posta (kolejność sekcji): ' . implode( ' → ', $all ) . '.';
	$lines[] = 'Napisz TYLKO sekcje: ' . implode( ', ', array_map( function ( $x ) { return $x['n'] . ' (klucz „' . $x['k'] . '”)'; }, $ai ) ) . '.';
	$lines[] = 'Zwróć JSON z tymi kluczami; wartości to gotowy tekst sekcji (może mieć kilka linii, bez nagłówka z nazwą sekcji, bez markdown).';
	return array(
		'system' => trim( $s['instructions'] ),
		'user'   => implode( "\n", $lines ),
		'keys'   => array_map( function ( $x ) { return $x['k']; }, $ai ),
	);
}

/** Zapytanie do Gemini. [ ok, [ klucz => tekst ] | komunikat ]. */
function rzd_posts_gemini_write( $dd, $extra, $photos = array() ) {
	$s   = rzd_posts_settings();
	$key = rzd_posts_secret( 'gemini_key' );
	if ( '' === $key || '' === $s['model'] ) {
		return array( false, 'Uzupełnij klucz API Gemini i wybierz model (Post dnia → Ustawienia).' );
	}
	$pr    = rzd_posts_prompt( $dd, $extra );
	$parts = array( array( 'text' => $pr['user'] ) );
	if ( ! empty( $s['ai_images'] ) ) {
		foreach ( array_slice( (array) $photos, 0, 4 ) as $ph ) {
			$file = ! empty( $ph['id'] ) ? image_get_intermediate_size( (int) $ph['id'], 'medium' ) : null;
			$path = $file && ! empty( $file['path'] ) ? path_join( wp_upload_dir()['basedir'], $file['path'] ) : ( ! empty( $ph['id'] ) ? get_attached_file( (int) $ph['id'] ) : '' );
			if ( $path && is_readable( $path ) && filesize( $path ) < 4 * MB_IN_BYTES ) {
				$parts[] = array( 'inline_data' => array( 'mime_type' => wp_check_filetype( $path )['type'] ? wp_check_filetype( $path )['type'] : 'image/jpeg', 'data' => base64_encode( file_get_contents( $path ) ) ) ); // phpcs:ignore
			}
		}
	}
	$props = array();
	foreach ( $pr['keys'] as $k ) {
		$props[ $k ] = array( 'type' => 'STRING' );
	}
	$body = array(
		'systemInstruction' => array( 'parts' => array( array( 'text' => $pr['system'] ) ) ),
		'contents'          => array( array( 'role' => 'user', 'parts' => $parts ) ),
		'generationConfig'  => array(
			'temperature'      => 0.9,
			'responseMimeType' => 'application/json',
			'responseSchema'   => array( 'type' => 'OBJECT', 'properties' => $props, 'required' => $pr['keys'] ),
		),
	);
	$r = wp_remote_post( rzd_posts_gemini_base() . 'models/' . rawurlencode( $s['model'] ) . ':generateContent', array(
		'timeout' => 60,
		'headers' => array( 'x-goog-api-key' => $key, 'Content-Type' => 'application/json' ),
		'body'    => wp_json_encode( $body ),
	) );
	if ( is_wp_error( $r ) ) {
		return array( false, 'Brak połączenia z Gemini: ' . $r->get_error_message() );
	}
	$j = json_decode( wp_remote_retrieve_body( $r ), true );
	if ( 200 !== (int) wp_remote_retrieve_response_code( $r ) ) {
		return array( false, 'Gemini: ' . ( isset( $j['error']['message'] ) ? $j['error']['message'] : 'HTTP ' . wp_remote_retrieve_response_code( $r ) ) );
	}
	$txt = '';
	foreach ( isset( $j['candidates'][0]['content']['parts'] ) ? (array) $j['candidates'][0]['content']['parts'] : array() as $p ) {
		$txt .= isset( $p['text'] ) ? $p['text'] : '';
	}
	$txt = trim( preg_replace( '/^```(?:json)?|```$/m', '', $txt ) );
	$out = json_decode( $txt, true );
	if ( ! is_array( $out ) ) {
		$why = isset( $j['candidates'][0]['finishReason'] ) ? ' (' . $j['candidates'][0]['finishReason'] . ')' : '';
		return array( false, 'Gemini nie zwrócił tekstu posta' . $why . '. Spróbuj ponownie albo wybierz inny model.' );
	}
	$res = array();
	foreach ( $pr['keys'] as $k ) {
		$res[ $k ] = isset( $out[ $k ] ) && is_scalar( $out[ $k ] ) ? trim( (string) $out[ $k ] ) : '';
	}
	return array( true, $res );
}

/** Cały tekst posta: sekcje w kolejności z ustawień, pusta linia między nimi; w stałych {zestaw}, {dzien}, {dania}. */
function rzd_posts_assemble( $ai, $dd ) {
	$s   = rzd_posts_settings();
	$rep = array(
		'{zestaw}' => $dd['setName'],
		'{dzien}'  => rzd_dc_date_label( $dd['day'] ),
		'{dania}'  => implode( ', ', array_map( function ( $x ) { return $x['name']; }, $dd['dishes'] ) ),
	);
	$out = array();
	foreach ( $s['sections'] as $sec ) {
		$t = 'ai' === $sec['m'] ? ( isset( $ai[ $sec['k'] ] ) ? $ai[ $sec['k'] ] : '' ) : strtr( $sec['t'], $rep );
		$t = trim( preg_replace( "/\n{3,}/", "\n\n", str_replace( "\r", '', $t ) ) );
		if ( '' !== $t ) {
			$out[] = $t;
		}
	}
	return implode( "\n\n", $out );
}

/** Generuje szkic: nowy albo nadpisuje tekst istniejącego (bez zmiany zdjęć). [ ok, post | komunikat ]. */
function rzd_posts_generate( $set_id, $day, $extra = '', $photos = null, $post_id = 0, $src = 'manual' ) {
	$dd = rzd_posts_day_data( $set_id, $day );
	if ( ! $dd['dishes'] ) {
		return array( false, 'Zestaw „' . $dd['setName'] . '” nie ma dań na ' . rzd_dc_date_label( $day ) . ' – uzupełnij harmonogram zestawu.' );
	}
	$photos = null === $photos ? $dd['photos'] : $photos;
	list( $ok, $ai ) = rzd_posts_gemini_write( $dd, $extra, $photos );
	if ( ! $ok ) {
		return array( false, $ai );
	}
	$id = rzd_posts_save_post( array(
		'id'     => $post_id,
		'day'    => $day,
		'set'    => (int) $set_id,
		'status' => 'draft',
		'text'   => rzd_posts_assemble( $ai, $dd ),
		'photos' => array_values( $photos ),
		'when'   => $post_id ? (int) get_post_meta( $post_id, '_when', true ) : rzd_posts_default_when( $day ),
		'extra'  => (string) $extra,
		'src'    => $src,
		'err'    => '',
		'by'     => is_user_logged_in() ? wp_get_current_user()->display_name : 'automat',
	) );
	return array( true, rzd_posts_get( $id ) );
}
