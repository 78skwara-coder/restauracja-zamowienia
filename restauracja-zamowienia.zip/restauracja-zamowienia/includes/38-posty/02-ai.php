<?php
/**
 * Moduł 38-posty – Gemini: lista modeli i pisanie sekcji posta (2.48.2: aktywne sekcje, wskazówki do sekcji,
 * Interactions API z zapasem generateContent – rzd_posts_gemini_ask). Do AI idą: wskazówki z ustawień, nazwy i opisy
 * dań, dzień, dopisek; zdjęcia tylko przy włączonym „AI widzi zdjęcia”. Odpowiedź – JSON { klucz sekcji: tekst }
 * (tylko sekcje „AI”); stałe sekcje dokleja wtyczka (rzd_posts_assemble), z pustą linią między sekcjami.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function rzd_posts_gemini_base() {
	return apply_filters( 'rzd_posts_gemini_base', 'https://generativelanguage.googleapis.com/v1beta/' );
}

/** Modele, które piszą tekst (generateContent). [ ok, lista | komunikat ]. */
function rzd_posts_gemini_models( $key = null ) {
	$key = null === $key ? rzd_posts_secret( 'gemini_key' ) : $key;
	if ( '' === $key ) {
		return array( false, 'Najpierw wpisz klucz API Gemini.' );
	}
	$r = wp_remote_get( rzd_posts_gemini_base() . 'models?pageSize=200', array( 'timeout' => 20, 'headers' => array( 'x-goog-api-key' => $key ) ) );
	if ( is_wp_error( $r ) ) {
		return array( false, 'Brak połączenia z Gemini: ' . $r->get_error_message() );
	}
	$j = json_decode( wp_remote_retrieve_body( $r ), true );
	if ( 200 !== (int) wp_remote_retrieve_response_code( $r ) ) {
		return array( false, 'Gemini odrzucił klucz: ' . ( isset( $j['error']['message'] ) ? $j['error']['message'] : 'HTTP ' . wp_remote_retrieve_response_code( $r ) ) );
	}
	$out = array();
	foreach ( isset( $j['models'] ) ? (array) $j['models'] : array() as $m ) {
		if ( empty( $m['name'] ) || ! in_array( 'generateContent', isset( $m['supportedGenerationMethods'] ) ? (array) $m['supportedGenerationMethods'] : array(), true ) ) {
			continue;
		}
		$id = preg_replace( '#^models/#', '', $m['name'] );
		if ( preg_match( '/embedding|aqa|imagen|tts|audio|image-generation|live/i', $id ) ) {
			continue;
		}
		$out[] = array( 'id' => $id, 'name' => isset( $m['displayName'] ) ? $m['displayName'] : $id );
	}
	return array( true, $out );
}

/** Sekcje użyte w poście danego rodzaju (aktywne i przypisane do rodzaju). */
function rzd_posts_sections_for( $kind ) {
	return array_values( array_filter( rzd_posts_settings()['sections'], function ( $x ) use ( $kind ) {
		return ! empty( $x['on'] ) && in_array( $kind, (array) $x['ty'], true );
	} ) );
}

/** Treść zapytania – osobno, żeby dało się ją sprawdzić w testach. $dd['kind']: set | product | topic. */
function rzd_posts_prompt( $dd, $extra ) {
	$s    = rzd_posts_settings();
	$kind = isset( $dd['kind'] ) ? $dd['kind'] : 'set';
	$on   = rzd_posts_sections_for( $kind ); // nieaktywne i z innych rodzajów postów nie idą do AI
	$ai   = array_values( array_filter( $on, function ( $x ) { return 'ai' === $x['m']; } ) );
	$all  = array_map( function ( $x ) { return $x['n'] . ( 'ai' === $x['m'] ? '' : ' (stały tekst – dopiszemy sami, nie pisz go)' ); }, $on );
	$lines = array();
	if ( 'product' === $kind ) {
		$lines[] = 'Post o jednej pozycji z naszej karty (nie o zestawie dnia): ' . $dd['setName'] . '.';
		if ( '' !== $dd['cat'] ) {
			$lines[] = 'Kategoria: ' . $dd['cat'] . '.';
		}
		if ( '' !== $dd['desc'] ) {
			$lines[] = 'Opis z karty: ' . mb_substr( $dd['desc'], 0, 600 );
		}
	} elseif ( 'topic' === $kind ) {
		$lines[] = 'Post na dowolny temat (nie o zestawie dnia). Temat od restauracji:';
		$lines[] = trim( $dd['topic'] );
	} else {
		$lines[] = 'Zapowiedź na: ' . rzd_dc_date_label( $dd['day'] ) . ' (post publikujemy wieczorem dzień wcześniej, więc to „jutro”).';
		$lines[] = 'Zestaw: ' . $dd['setName'] . '.';
		$lines[] = 'Dania w zestawie:';
		foreach ( $dd['dishes'] as $d ) {
			$lines[] = '- ' . $d['name'] . ( '' !== $d['role'] ? ' (' . $d['role'] . ')' : '' ) . ( '' !== $d['desc'] ? ': ' . mb_substr( $d['desc'], 0, 300 ) : '' );
		}
	}
	if ( '' !== trim( (string) $extra ) ) {
		$lines[] = 'Dopisek od restauracji: ' . trim( $extra );
	}
	$lines[] = '';
	$lines[] = 'Układ całego posta (kolejność sekcji): ' . implode( ' → ', $all ) . '.';
	$lines[] = 'Napisz TYLKO te sekcje (przy każdej jej wskazówki – mają pierwszeństwo przed ogólnymi):';
	foreach ( $ai as $x ) {
		$h       = trim( preg_replace( '/\s*\n\s*/', ' ', (string) $x['h'] ) );
		$lines[] = '* ' . $x['n'] . ' (klucz „' . $x['k'] . '”) – ' . ( '' !== $h ? 'wskazówki: ' . $h : 'bez dodatkowych wskazówek, pisz według ogólnych zasad' );
	}
	$lines[] = 'Zwróć JSON z tymi kluczami; wartości to gotowy tekst sekcji (może mieć kilka linii, bez nagłówka z nazwą sekcji, bez markdown).';
	return array(
		'system' => trim( $s['instructions'] ),
		'user'   => implode( "\n", $lines ),
		'keys'   => array_map( function ( $x ) { return $x['k']; }, $ai ),
	);
}

/** Zapytanie do Gemini. [ ok, [ klucz => tekst ] | komunikat ]. */
function rzd_posts_gemini_write( $dd, $extra, $photos = array() ) {
	$s   = rzd_posts_settings();
	$key = rzd_posts_secret( 'gemini_key' );
	if ( '' === $key || '' === $s['model'] ) {
		return array( false, 'Uzupełnij klucz API Gemini i wybierz model (Post dnia → Ustawienia).' );
	}
	$pr   = rzd_posts_prompt( $dd, $extra );
	$imgs = array();
	if ( ! empty( $s['ai_images'] ) ) {
		foreach ( array_slice( (array) $photos, 0, 4 ) as $ph ) {
			$file = ! empty( $ph['id'] ) ? image_get_intermediate_size( (int) $ph['id'], 'medium' ) : null;
			$path = $file && ! empty( $file['path'] ) ? path_join( wp_upload_dir()['basedir'], $file['path'] ) : ( ! empty( $ph['id'] ) ? get_attached_file( (int) $ph['id'] ) : '' );
			if ( $path && is_readable( $path ) && filesize( $path ) < 4 * MB_IN_BYTES ) {
				$mime   = wp_check_filetype( $path )['type'];
				$imgs[] = array( 'mime' => $mime ? $mime : 'image/jpeg', 'data' => base64_encode( file_get_contents( $path ) ) ); // phpcs:ignore
			}
		}
	}
	list( $ok, $txt ) = rzd_posts_gemini_ask( $s['model'], $key, array(
		'system' => $pr['system'],
		'text'   => $pr['user'],
		'images' => $imgs,
		'keys'   => $pr['keys'],
		'temp'   => 0.9,
	), 'post' );
	if ( ! $ok ) {
		return array( false, $txt );
	}
	$txt = trim( preg_replace( '/^```(?:json)?|```$/m', '', $txt ) );
	$out = json_decode( $txt, true );
	if ( ! is_array( $out ) ) {
		return array( false, 'Gemini nie zwrócił tekstu posta. Spróbuj ponownie albo wybierz inny model.' );
	}
	$res = array();
	foreach ( $pr['keys'] as $k ) {
		$res[ $k ] = isset( $out[ $k ] ) && is_scalar( $out[ $k ] ) ? trim( (string) $out[ $k ] ) : '';
	}
	return array( true, $res );
}

/** Cały tekst posta: sekcje w kolejności z ustawień, pusta linia między nimi; w stałych {zestaw}, {dzien}, {dania}. */
function rzd_posts_assemble( $ai, $dd ) {
	$kind = isset( $dd['kind'] ) ? $dd['kind'] : 'set';
	$rep  = array( // w poście o produkcie {zestaw} i {dania} = nazwa produktu; w temacie – puste
		'{zestaw}' => (string) $dd['setName'],
		'{dzien}'  => '' !== (string) $dd['day'] ? rzd_dc_date_label( $dd['day'] ) : '',
		'{dania}'  => 'product' === $kind ? (string) $dd['setName'] : implode( ', ', array_map( function ( $x ) { return $x['name']; }, (array) $dd['dishes'] ) ),
	);
	$out = array();
	foreach ( rzd_posts_sections_for( $kind ) as $sec ) { // nieaktywne i z innych rodzajów – nie trafiają do posta
		$t = 'ai' === $sec['m'] ? ( isset( $ai[ $sec['k'] ] ) ? $ai[ $sec['k'] ] : '' ) : strtr( $sec['t'], $rep );
		$t = trim( preg_replace( "/\n{3,}/", "\n\n", str_replace( "\r", '', $t ) ) );
		if ( '' !== $t ) {
			$out[] = $t;
		}
	}
	return implode( "\n\n", $out );
}

/** Generuje szkic: nowy albo nadpisuje tekst istniejącego (bez zmiany zdjęć). [ ok, post | komunikat ]. */
function rzd_posts_generate( $set_id, $day, $extra = '', $photos = null, $post_id = 0, $src = 'manual' ) {
	$dd = rzd_posts_day_data( $set_id, $day );
	if ( ! $dd['dishes'] ) {
		return array( false, 'Zestaw „' . $dd['setName'] . '” nie ma dań na ' . rzd_dc_date_label( $day ) . ' – uzupełnij harmonogram zestawu.' );
	}
	$photos = null === $photos ? $dd['photos'] : $photos;
	if ( ! array_filter( rzd_posts_sections_for( 'set' ), function ( $x ) { return 'ai' === $x['m']; } ) ) {
		return array( false, 'Brak aktywnej sekcji AI w postach o zestawie (Ustawienia → Sekcje posta).' );
	}
	list( $ok, $ai ) = rzd_posts_gemini_write( $dd, $extra, $photos );
	if ( ! $ok ) {
		return array( false, $ai );
	}
	$id = rzd_posts_save_post( array(
		'id'     => $post_id,
		'day'    => $day,
		'set'    => (int) $set_id,
		'status' => 'draft',
		'text'   => rzd_posts_assemble( $ai, $dd ),
		'photos' => array_values( $photos ),
		'when'   => $post_id ? (int) get_post_meta( $post_id, '_when', true ) : rzd_posts_default_when( $day ),
		'extra'  => (string) $extra,
		'src'    => $src,
		'err'    => '',
		'by'     => is_user_logged_in() ? wp_get_current_user()->display_name : 'automat',
		'kind'   => 'set',
	) );
	return array( true, rzd_posts_get( $id ) );
}

/**
 * (2.49.0) Post o produkcie albo na dowolny temat. Bez dnia (nie liczy się do „posta na jutro” automatu),
 * publikacja domyślnie o najbliższej godzinie publikacji. [ ok, post | komunikat ].
 */
function rzd_posts_generate_other( $kind, $product_id, $topic, $extra = '', $photos = null, $post_id = 0 ) {
	$kinds = rzd_posts_kinds();
	if ( 'product' === $kind ) {
		$dd = rzd_posts_product_data( $product_id );
		if ( ! $dd ) {
			return array( false, 'Wybierz produkt.' );
		}
	} elseif ( 'topic' === $kind ) {
		$topic = trim( (string) $topic );
		if ( '' === $topic ) {
			return array( false, 'Napisz, o czym ma być post.' );
		}
		$dd = array( 'kind' => 'topic', 'topic' => $topic, 'setName' => '', 'day' => '', 'dishes' => array(), 'photos' => array() );
	} else {
		return array( false, 'Nieznany rodzaj posta.' );
	}
	if ( ! array_filter( rzd_posts_sections_for( $kind ), function ( $x ) { return 'ai' === $x['m']; } ) ) {
		return array( false, 'Brak aktywnej sekcji AI w postach „' . $kinds[ $kind ] . '” (Ustawienia → Sekcje posta).' );
	}
	$photos = null === $photos ? $dd['photos'] : $photos;
	list( $ok, $ai ) = rzd_posts_gemini_write( $dd, $extra, $photos );
	if ( ! $ok ) {
		return array( false, $ai );
	}
	$id = rzd_posts_save_post( array(
		'id'      => $post_id,
		'day'     => '',
		'set'     => 0,
		'kind'    => $kind,
		'product' => 'product' === $kind ? (int) $dd['product'] : 0,
		'topic'   => 'topic' === $kind ? $topic : '',
		'status'  => 'draft',
		'text'    => rzd_posts_assemble( $ai, $dd ),
		'photos'  => array_values( $photos ),
		'when'    => $post_id && (int) get_post_meta( $post_id, '_when', true ) > time() ? (int) get_post_meta( $post_id, '_when', true ) : rzd_posts_next_pub_time(),
		'extra'   => (string) $extra,
		'src'     => 'manual',
		'err'     => '',
		'by'      => is_user_logged_in() ? wp_get_current_user()->display_name : '',
	) );
	return array( true, rzd_posts_get( $id ) );
}

/**
 * Zapytanie do Gemini (2.48.2). Dwa sposoby: Interactions API (POST v1beta/interactions – zalecany przez Google
 * dla nowych kont i modeli 3.x; na nowym koncie gemini-3.8-flash przez generateContent potrafił nie odpowiadać
 * wcale) i zapasowo generateContent. Krótkie „myślenie”: Interactions – thinking_level low, potem bez ustawienia;
 * generateContent – thinkingLevel low, thinkingBudget 0, bez ustawienia. Pierwszy wariant, który model przyjmie,
 * jest zapamiętywany dla modelu (opcja rzd_posts_think: [ model => 'ia-low' | 'ia-none' | 'gc-low' | … ]).
 * Na Interactions → generateContent przechodzi przy odrzuceniu zapytania (400/404/501), nie przy przekroczeniu
 * czasu ani przeciążeniu (429/503). Każde zapytanie zapisuje się w rzd_posts_last_call (Ustawienia).
 * $req: system, text, images [ [mime, data] ], keys (JSON z tymi kluczami | null – zwykły tekst), temp.
 * [ ok, tekst odpowiedzi (bez „myśli” modelu) | komunikat ].
 */
function rzd_posts_gemini_ask( $model, $key, $req, $what, $timeout = 0 ) {
	if ( function_exists( 'set_time_limit' ) ) {
		@set_time_limit( 200 ); // phpcs:ignore -- tam, gdzie hosting pozwala
	}
	$timeout = $timeout ? (int) $timeout : (int) apply_filters( 'rzd_posts_gemini_timeout', 150 );
	$all     = array( 'ia-low', 'ia-none', 'gc-low', 'gc-budget', 'gc-none' );
	$known   = get_option( 'rzd_posts_think', array() );
	$known   = is_array( $known ) ? $known : array();
	$order   = $all;
	if ( isset( $known[ $model ] ) && in_array( $known[ $model ], $all, true ) ) {
		$order = array_values( array_unique( array_merge( array( $known[ $model ] ), $all ) ) );
	}
	$t0     = microtime( true );
	$res    = array( false, 'Brak odpowiedzi z Gemini.' );
	$skipia = false;
	$used   = '';
	foreach ( $order as $v ) {
		list( $api, $th ) = explode( '-', $v );
		if ( 'ia' === $api && $skipia ) {
			continue;
		}
		if ( 'ia' === $api ) {
			$url  = rzd_posts_gemini_base() . 'interactions';
			$body = rzd_posts_gemini_body_ia( $model, $req, $th );
		} else {
			$url  = rzd_posts_gemini_base() . 'models/' . rawurlencode( $model ) . ':generateContent';
			$body = rzd_posts_gemini_body_gc( $req, $th );
		}
		$r = wp_remote_post( $url, array(
			'timeout' => $timeout,
			'headers' => array( 'x-goog-api-key' => $key, 'Content-Type' => 'application/json' ),
			'body'    => wp_json_encode( $body ),
		) );
		if ( is_wp_error( $r ) ) {
			$msg = $r->get_error_message();
			$res = array( false, ( false !== stripos( $msg, 'timed out' ) || false !== stripos( $msg, 'timeout' ) ) ? 'Gemini nie odpowiedział w czasie (' . $msg . '). Wybierz inny model albo spróbuj ponownie za chwilę.' : 'Brak połączenia z Gemini: ' . $msg );
			$used = $api;
			break;
		}
		$code = (int) wp_remote_retrieve_response_code( $r );
		$j    = json_decode( wp_remote_retrieve_body( $r ), true );
		$err  = isset( $j['error']['message'] ) ? (string) $j['error']['message'] : '';
		$used = $api;
		if ( 400 === $code && 'none' !== $th && preg_match( '/thinking/i', $err ) ) {
			continue; // model nie zna tego ustawienia „myślenia” – następny wariant
		}
		if ( 'ia' === $api && in_array( $code, array( 400, 404, 501 ), true ) && ! preg_match( '/api key|API_KEY|permission/i', $err ) ) {
			$skipia = true; // Interactions odrzucone – zapasowo generateContent
			continue;
		}
		if ( in_array( $code, array( 429, 500, 503 ), true ) ) {
			$res = array( false, 'Gemini jest teraz przeciążony albo przekroczono limit (' . ( '' !== $err ? $err : 'HTTP ' . $code ) . '). Spróbuj za kilka minut albo wybierz inny model.' );
			break;
		}
		if ( 200 !== $code ) {
			$res = array( false, 'Gemini: ' . ( '' !== $err ? $err : 'HTTP ' . $code ) );
			break;
		}
		$txt = 'ia' === $api ? rzd_posts_gemini_text_ia( $j ) : rzd_posts_gemini_text_gc( $j );
		if ( ! is_array( $txt ) ) {
			$res = array( false, $txt );
			break;
		}
		if ( ! isset( $known[ $model ] ) || $known[ $model ] !== $v ) {
			$known[ $model ] = $v;
			update_option( 'rzd_posts_think', $known, false );
		}
		$res = array( true, $txt[0] );
		break;
	}
	update_option( 'rzd_posts_last_call', array(
		'time'  => time(),
		'secs'  => round( microtime( true ) - $t0, 1 ),
		'model' => $model,
		'what'  => $what,
		'api'   => 'ia' === $used ? 'Interactions' : ( 'gc' === $used ? 'generateContent' : '' ),
		'ok'    => $res[0],
		'msg'   => $res[0] ? '' : $res[1],
	), false );
	return $res;
}

/** Treść zapytania Interactions API: system_instruction, input (tekst albo części z obrazkami), JSON wg schematu. */
function rzd_posts_gemini_body_ia( $model, $req, $th ) {
	$b = array( 'model' => $model, 'store' => false );
	if ( ! empty( $req['system'] ) ) {
		$b['system_instruction'] = $req['system'];
	}
	if ( empty( $req['images'] ) ) {
		$b['input'] = $req['text'];
	} else {
		$in = array( array( 'type' => 'text', 'text' => $req['text'] ) );
		foreach ( $req['images'] as $im ) {
			$in[] = array( 'type' => 'image', 'data' => $im['data'], 'mime_type' => $im['mime'] );
		}
		$b['input'] = $in;
	}
	$gc = array();
	if ( 'low' === $th ) {
		$gc['thinking_level'] = 'low';
	}
	if ( isset( $req['temp'] ) ) {
		$gc['temperature'] = $req['temp']; // nowsze modele ignorują – nie szkodzi
	}
	if ( $gc ) {
		$b['generation_config'] = $gc;
	}
	if ( ! empty( $req['keys'] ) ) {
		$props = array();
		foreach ( $req['keys'] as $k ) {
			$props[ $k ] = array( 'type' => 'string' );
		}
		$b['response_format'] = array( 'type' => 'text', 'mime_type' => 'application/json', 'schema' => array( 'type' => 'object', 'properties' => $props, 'required' => array_values( $req['keys'] ) ) );
	}
	return $b;
}

/** Treść zapytania generateContent (jak do 2.48.1). */
function rzd_posts_gemini_body_gc( $req, $th ) {
	$parts = array( array( 'text' => $req['text'] ) );
	foreach ( isset( $req['images'] ) ? $req['images'] : array() as $im ) {
		$parts[] = array( 'inline_data' => array( 'mime_type' => $im['mime'], 'data' => $im['data'] ) );
	}
	$b = array( 'contents' => array( array( 'role' => 'user', 'parts' => $parts ) ), 'generationConfig' => array() );
	if ( ! empty( $req['system'] ) ) {
		$b['systemInstruction'] = array( 'parts' => array( array( 'text' => $req['system'] ) ) );
	}
	if ( isset( $req['temp'] ) ) {
		$b['generationConfig']['temperature'] = $req['temp'];
	}
	if ( ! empty( $req['keys'] ) ) {
		$props = array();
		foreach ( $req['keys'] as $k ) {
			$props[ $k ] = array( 'type' => 'STRING' );
		}
		$b['generationConfig']['responseMimeType'] = 'application/json';
		$b['generationConfig']['responseSchema']   = array( 'type' => 'OBJECT', 'properties' => $props, 'required' => array_values( $req['keys'] ) );
	}
	if ( 'low' === $th ) {
		$b['generationConfig']['thinkingConfig'] = array( 'thinkingLevel' => 'low' );
	} elseif ( 'budget' === $th ) {
		$b['generationConfig']['thinkingConfig'] = array( 'thinkingBudget' => 0 );
	}
	if ( ! $b['generationConfig'] ) {
		unset( $b['generationConfig'] );
	}
	return $b;
}

/** Tekst z odpowiedzi Interactions: kroki „model_output”, części „text” (bez kroków „thought”). [ tekst ] | komunikat. */
function rzd_posts_gemini_text_ia( $j ) {
	$st = isset( $j['status'] ) ? (string) $j['status'] : 'completed';
	if ( in_array( $st, array( 'failed', 'cancelled' ), true ) ) {
		return 'Gemini przerwał odpowiedź (' . $st . ( isset( $j['error']['message'] ) ? ': ' . $j['error']['message'] : '' ) . ').';
	}
	$txt = '';
	foreach ( isset( $j['steps'] ) ? (array) $j['steps'] : array() as $step ) {
		if ( isset( $step['type'] ) && 'model_output' === $step['type'] ) {
			foreach ( isset( $step['content'] ) ? (array) $step['content'] : array() as $c ) {
				$txt .= isset( $c['type'], $c['text'] ) && 'text' === $c['type'] ? $c['text'] : '';
			}
		}
	}
	foreach ( '' === $txt && isset( $j['outputs'] ) ? (array) $j['outputs'] : array() as $o ) { // starszy kształt odpowiedzi
		$txt .= isset( $o['type'], $o['text'] ) && 'text' === $o['type'] ? $o['text'] : '';
	}
	return '' === trim( $txt ) ? 'Gemini nie zwrócił tekstu (status: ' . $st . ').' : array( $txt );
}

/** Tekst z odpowiedzi generateContent (bez części „thought”). [ tekst ] | komunikat. */
function rzd_posts_gemini_text_gc( $j ) {
	$txt = '';
	foreach ( isset( $j['candidates'][0]['content']['parts'] ) ? (array) $j['candidates'][0]['content']['parts'] : array() as $p ) {
		$txt .= isset( $p['text'] ) && empty( $p['thought'] ) ? $p['text'] : '';
	}
	$why = isset( $j['candidates'][0]['finishReason'] ) ? ' (' . $j['candidates'][0]['finishReason'] . ')' : '';
	return '' === trim( $txt ) ? 'Gemini nie zwrócił tekstu' . $why . '.' : array( $txt );
}

/** „Test AI” w Ustawieniach: krótka odpowiedź, pomiar czasu, najwyżej 30 s. [ ok, komunikat ]. */
function rzd_posts_gemini_test() {
	$s   = rzd_posts_settings();
	$key = rzd_posts_secret( 'gemini_key' );
	if ( '' === $key || '' === $s['model'] ) {
		return array( false, 'Najpierw zapisz klucz API i model.' );
	}
	$t0 = microtime( true );
	list( $ok, $txt ) = rzd_posts_gemini_ask( $s['model'], $key, array( 'text' => 'Odpowiedz jednym słowem: działa', 'temp' => 0 ), 'test', (int) apply_filters( 'rzd_posts_gemini_test_timeout', 30 ) );
	$secs = str_replace( '.', ',', (string) round( microtime( true ) - $t0, 1 ) );
	if ( ! $ok ) {
		return array( false, $txt . ' (' . $secs . ' s)' );
	}
	$lc = get_option( 'rzd_posts_last_call' );
	return array( true, 'Gemini odpowiada: „' . mb_substr( trim( $txt ), 0, 40 ) . '” – ' . $secs . ' s (model ' . $s['model'] . ', ' . ( ! empty( $lc['api'] ) ? $lc['api'] : '' ) . ').' );
}
