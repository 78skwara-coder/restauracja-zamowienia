<?php
/**
 * Moduł 38-posty – zdjęcia posta dopasowane do Facebooka (2.50.0). Format całego posta: 4:5 (domyślnie – najwyższy,
 * jaki feed pokazuje bez przycinania), 1:1, 1,91:1 albo oryginał (plik z biblioteki bez zmian, jak przed 2.50.0).
 * Kadr: punkt centralny fx / fy (0–1) przy każdym zdjęciu – ta sama zasada co CSS object-fit: cover +
 * object-position: fx% fy% w podglądzie panelu (x = (szer. − szer. kadru) × fx), więc podgląd = plik.
 * Docięta kopia: JPEG (Instagram w przyszłości przyjmie tylko JPEG), dłuższy bok kadru ≤ 1440 px, jakość 85,
 * w uploads/rzd/posty/ – nazwa z ID, formatu, kadru i daty pliku, więc ta sama kopia służy kolejnym publikacjom.
 * Oryginał w bibliotece mediów zostaje nietknięty. Kopie starsze niż 60 dni czyści automat (po publikacji zdjęcia
 * są już na Facebooku).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Formaty: klucz => [ etykieta, szerokość / wysokość (0 = oryginał) ]. */
function rzd_posts_ratios() {
	return array(
		'4:5'    => array( '4:5 pion (zalecany)', 0.8 ),
		'1:1'    => array( '1:1 kwadrat', 1.0 ),
		'1.91:1' => array( '1,91:1 poziom', 1.91 ),
		'orig'   => array( 'Oryginał (bez docinania)', 0 ),
	);
}

function rzd_posts_ratio_key( $v, $def = '4:5' ) {
	$v = (string) $v;
	return isset( rzd_posts_ratios()[ $v ] ) ? $v : $def;
}

/** Format posta: zapisany przy poście albo domyślny z ustawień. */
function rzd_posts_ratio_for( $p ) {
	$def = rzd_posts_ratio_key( rzd_posts_settings()['ratio'] );
	return is_array( $p ) && ! empty( $p['ratio'] ) ? rzd_posts_ratio_key( $p['ratio'], $def ) : $def;
}

/** Punkt kadru 0–1 (domyślnie środek). */
function rzd_posts_focus( $v ) {
	return is_numeric( $v ) ? round( max( 0, min( 1, (float) $v ) ), 3 ) : 0.5;
}

/** Prostokąt kadru [ x, y, w, h ] dla obrazka $w × $h, proporcji $r i punktu fx / fy. */
function rzd_posts_crop_rect( $w, $h, $r, $fx, $fy ) {
	if ( $w / $h > $r ) {
		$cw = (int) round( $h * $r );
		return array( (int) round( ( $w - $cw ) * $fx ), 0, $cw, (int) $h );
	}
	$ch = (int) round( $w / $r );
	return array( 0, (int) round( ( $h - $ch ) * $fy ), (int) $w, $ch );
}

function rzd_posts_crop_dir() {
	$u = wp_upload_dir();
	return trailingslashit( $u['basedir'] ) . 'rzd/posty';
}

/**
 * Plik zdjęcia do wysłania: [ ścieżka, uwaga ]. Oryginał – plik z biblioteki. Gdy docięcie się nie uda (np. serwer
 * bez obsługi formatu), idzie oryginał z uwagą – Facebook przytnie go sam.
 */
function rzd_posts_photo_file( $ph, $ratio ) {
	$id   = ! empty( $ph['id'] ) ? (int) $ph['id'] : 0;
	$orig = $id ? get_attached_file( $id ) : '';
	if ( ! $orig || ! is_readable( $orig ) ) {
		return array( '', '' );
	}
	$rs = rzd_posts_ratios();
	$r  = isset( $rs[ $ratio ] ) ? $rs[ $ratio ][1] : 0;
	if ( ! $r ) {
		return array( $orig, '' );
	}
	$fx   = rzd_posts_focus( isset( $ph['fx'] ) ? $ph['fx'] : null );
	$fy   = rzd_posts_focus( isset( $ph['fy'] ) ? $ph['fy'] : null );
	$dir  = rzd_posts_crop_dir();
	$file = $dir . '/' . $id . '-' . str_replace( array( ':', '.' ), '', $ratio ) . '-' . (int) round( $fx * 1000 ) . '-' . (int) round( $fy * 1000 ) . '-' . (int) filemtime( $orig ) . '.jpg';
	if ( is_readable( $file ) ) {
		return array( $file, '' );
	}
	$ed = wp_get_image_editor( $orig );
	if ( is_wp_error( $ed ) ) {
		return array( $orig, 'Nie udało się dociąć zdjęcia (' . $ed->get_error_message() . ') – wysłano oryginał.' );
	}
	if ( method_exists( $ed, 'maybe_exif_rotate' ) ) {
		$ed->maybe_exif_rotate();
	}
	$sz = $ed->get_size();
	if ( empty( $sz['width'] ) || empty( $sz['height'] ) ) {
		return array( $orig, 'Nie udało się odczytać rozmiaru zdjęcia – wysłano oryginał.' );
	}
	list( $x, $y, $cw, $ch ) = rzd_posts_crop_rect( (int) $sz['width'], (int) $sz['height'], $r, $fx, $fy );
	$scale = min( 1, 1440 / max( $cw, $ch ) );
	$ok    = $ed->crop( $x, $y, $cw, $ch, max( 1, (int) round( $cw * $scale ) ), max( 1, (int) round( $ch * $scale ) ) );
	if ( is_wp_error( $ok ) ) {
		return array( $orig, 'Nie udało się dociąć zdjęcia – wysłano oryginał.' );
	}
	$ed->set_quality( 85 );
	wp_mkdir_p( $dir );
	$saved = $ed->save( $file, 'image/jpeg' );
	if ( is_wp_error( $saved ) || empty( $saved['path'] ) || ! is_readable( $saved['path'] ) ) {
		return array( $orig, 'Nie udało się zapisać dociętego zdjęcia – wysłano oryginał.' );
	}
	return array( $saved['path'], '' );
}

/** Kopie starsze niż $days dni – usuwane (wywołuje automat raz dziennie). */
function rzd_posts_photos_cleanup( $days = 60 ) {
	$n = 0;
	foreach ( (array) glob( rzd_posts_crop_dir() . '/*.jpg' ) as $f ) {
		if ( $f && filemtime( $f ) < time() - $days * DAY_IN_SECONDS && @unlink( $f ) ) { // phpcs:ignore
			$n++;
		}
	}
	return $n;
}
