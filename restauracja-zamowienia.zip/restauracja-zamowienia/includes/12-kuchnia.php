<?php
/**
 * MODUŁ 12: Kuchnia — dashboard zamówień wg terminu dostawy
 *
 * Pięć zakładek (zamówienia opłacone online albo z płatnością przy odbiorze):
 *  - Zamówienia – TAŚMA z niezrealizowanych (bez Dostarczonych): na górze
 *                 "Najbliższy wyjazd" z licznikami (cutoff za… / wyjazd
 *                 za…); po wyjeździe ekran sam się odświeża i wchodzi
 *                 następny termin. Pod nim "W drodze" (Spakowane w oknie
 *                 klienta = wyjazd + 1 h) i "Do przeplanowania" (okno minęło,
 *                 niedostarczone; przycisk "Nowy termin" + mail do klienta).
 *                 Pod grubą kreską czekające z poprawnym oknem, rosnąco,
 *                 BEZ tych z góry. Kolumny: nr, termin, nazwisko, adres,
 *                 wartość, status, Anuluj (nie dla dostarczonych).
 *  - Kuchnia    – lista załadunkowa WYBRANEGO terminu (ile czego zrobić),
 *                 przycisk oznacza cały termin jako "Przygotowane"
 *  - Pakowanie  – karty zamówień terminu; "Przygotowane" i "Spakowane"
 *                 pojedynczo, nie czeka na kuchnię
 *  - Planowanie – kolejność dostawy i konkretna godzina, "Zaplanowane" blokuje
 *  - Historia   – wszystko od (dziś − "Dni wstecz"), z dostarczonymi i
 *                 anulowanymi, malejąco; tylko podgląd
 * Kurier to osobny widok z osobnym PIN-em – moduł 19 (ten sam dashboard
 * w trybie 'kurier').
 *
 * Przełącznik "Auto przygotowanie" (moduł 13): po cutoffie zamówienia
 * same przechodzą na "W przygotowaniu".
 *
 * Responsywny (tablet/telefon/komputer), wydruk A4 poziomo, pełny ekran,
 * auto-odświeżanie co 60 s bez przeładowania strony. Na froncie przez
 * shortcode [kuchnia_dashboard] z bramką PIN (sekcja 5 niżej).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 1. MENU
 * ============================================================ */
add_action( 'admin_menu', function () {
	add_menu_page( 'Kuchnia', 'Kuchnia', 'manage_woocommerce', 'rzd-kuchnia', 'kuchnia_render_page', 'dashicons-carrot', 3 );
} );

// Statusy liczone jako "opłacone" – 'wc-on-hold' świadomie pominięty,
// bo zwykle oznacza oczekiwanie na przelew, a dashboard ma pokazywać
// tylko zamówienia faktycznie opłacone.
function kuchnia_statuses() {
	// 'wc-on-hold' jest tu potrzebne m.in. dla "płatność przy odbiorze" –
	// w zależności od konfiguracji WooCommerce zamówienie z tą metodą płatności
	// może wylądować właśnie w tym statusie, zanim jeszcze ktokolwiek je ruszy.
	$s = array( 'wc-processing', 'wc-completed', 'wc-on-hold' );
	if ( function_exists( 'rzd_kitchen_statuses' ) ) {
		foreach ( array_keys( rzd_kitchen_statuses() ) as $slug ) {
			$s[] = 'wc-' . $slug;
		}
	}
	return $s;
}

/* ============================================================
 * 2. DANE
 * ============================================================ */
// Zamówienia na dany dzień (wszystkie godziny) – opłacone ONLINE, albo z
// wybraną metodą "płatność przy odbiorze" (te idą do realizacji od razu,
// mimo że pieniądze jeszcze nie wpłynęły – klient płaci na miejscu).
function kuchnia_orders_for_date( $date ) {
	// Ta funkcja jest wywoływana kilka razy na jedno wejście na dashboard
	// (osobno dla "Zamówienia" i osobno dla reszty zakładek) – bez cache'a
	// robiłaby to samo zapytanie do bazy po kilka razy z rzędu.
	static $cache = array();
	if ( isset( $cache[ $date ] ) ) {
		return $cache[ $date ];
	}
	$orders = wc_get_orders( array(
		'limit'      => -1,
		'status'     => kuchnia_statuses(),
		'orderby'    => 'date',
		'order'      => 'ASC',
		'meta_query' => array( // phpcs:ignore
			array( 'key' => '_dc_delivery_date', 'value' => $date, 'compare' => '=' ),
		),
		'return'     => 'objects',
	) );
	$cache[ $date ] = kuchnia_filter_paid( $orders );
	return $cache[ $date ];
}

// Tylko opłacone ONLINE albo z płatnością przy odbiorze (cod). Anulowane
// (Historia) – tylko te, które kiedyś były opłacone: porzucone, nieopłacone
// zamówienia z Przelewy24 WooCommerce też anuluje, a tych kuchnia nie widziała.
function kuchnia_filter_paid( $orders ) {
	return array_values( array_filter( $orders, function ( $o ) {
		if ( 'cancelled' === $o->get_status() ) {
			return (bool) $o->get_date_paid() || 'cod' === $o->get_payment_method();
		}
		if ( $o->is_paid() ) {
			return true;
		}
		return 'cod' === $o->get_payment_method();
	} ) );
}

// Zakładka Historia: wszystko z dostawą od $from (Y-m-d) wzwyż – także
// przyszłość bez limitu i anulowane.
function kuchnia_orders_from_date( $from ) {
	$orders = wc_get_orders( array(
		'limit'      => -1,
		'status'     => array_merge( kuchnia_statuses(), array( 'wc-cancelled' ) ),
		'meta_query' => array( // phpcs:ignore
			array( 'key' => '_dc_delivery_date', 'value' => $from, 'compare' => '>=' ),
		),
		'return'     => 'objects',
	) );
	return kuchnia_filter_paid( $orders );
}

// Zakładka Zamówienia: wszystko NIEZREALIZOWANE (bez Dostarczonych i
// Zrealizowanych), niezależnie od daty – zapomniane z poprzednich dni też.
function kuchnia_orders_open() {
	$open = array_values( array_diff( kuchnia_statuses(), array( 'wc-wydane', 'wc-completed' ) ) );
	$orders = wc_get_orders( array(
		'limit'      => -1,
		'status'     => $open,
		'meta_query' => array( // phpcs:ignore
			array( 'key' => '_dc_delivery_date', 'compare' => 'EXISTS' ),
		),
		'return'     => 'objects',
	) );
	return kuchnia_filter_paid( $orders );
}

// Zamówienie da się anulować z Kuchni tylko, dopóki nie jest dostarczone
// (ta sama reguła pilnowana na serwerze, moduł 13).
function kuchnia_can_cancel( $order ) {
	return ! in_array( $order->get_status(), array( 'wydane', 'completed', 'cancelled' ), true );
}

/**
 * Zamówienia pogrupowane: dzień dostawy → cutoff → godzina wyjazdu.
 * Zwraca listę terminów (slotów), każdy:
 * [ 'date', 'time', 'cutoff_ts', 'depart_ts', 'closed', 'orders' ].
 * Zamówienia bez godziny dostawy mają time '—' i cutoff_ts 0.
 */
function kuchnia_slot_groups( $orders ) {
	$slots = array();
	foreach ( $orders as $o ) {
		$d = (string) $o->get_meta( '_dc_delivery_date' );
		$t = (string) $o->get_meta( '_dc_delivery_time' );
		$t = $t ? $t : '—';
		$k = $d . ' ' . $t;
		if ( ! isset( $slots[ $k ] ) ) {
			$has_time    = ( '—' !== $t );
			$slots[ $k ] = array(
				'date'      => $d,
				'time'      => $t,
				'cutoff_ts' => ( $has_time && function_exists( 'dc_cutoff_ts' ) ) ? dc_cutoff_ts( $d, $t ) : 0,
				'depart_ts' => ( $has_time && function_exists( 'dc_date_ts' ) ) ? dc_date_ts( $d, $t ) : 0,
				'closed'    => ( $has_time && function_exists( 'dc_is_cutoff_passed' ) ) ? dc_is_cutoff_passed( $d, $t ) : true,
				'orders'    => array(),
			);
		}
		$slots[ $k ]['orders'][] = $o;
	}
	foreach ( $slots as &$sl ) {
		// W obrębie terminu: najmłodsze zamówienie na górze.
		usort( $sl['orders'], function ( $a, $b ) {
			return $b->get_id() <=> $a->get_id();
		} );
	}
	unset( $sl );
	return array_values( $slots );
}

// "Nowe" zamówienie = opłacone (albo złożone, gdy płatność przy odbiorze)
// w ciągu ostatnich 10 minut – wyróżnione pogrubieniem, potem jak inne.
function kuchnia_is_new_order( $order ) {
	$d = $order->get_date_paid();
	if ( ! $d ) {
		$d = $order->get_date_created();
	}
	return $d && ( time() - $d->getTimestamp() ) < 10 * MINUTE_IN_SECONDS;
}

// Moment cutoffu jako tekst, np. "30.09 10:30".
function kuchnia_cutoff_label( $ts ) {
	return $ts ? wp_date( 'd.m H:i', $ts ) : '—';
}

// Tabela zamówień: Nr, Termin, Nazwisko, Adres, Wartość, Status, [Anuluj].
// $actions = false → Historia, tylko podgląd.
function kuchnia_orders_table_html( $orders, $actions = true, $resched = false ) {
	ob_start();
	?>
	<table class="kuchnia-table">
		<thead><tr><th>Nr</th><th>Termin</th><th>Nazwisko</th><th>Adres</th><th>Wartość</th><th>Status</th><?php if ( $actions ) : ?><th class="kuchnia-noprint"></th><?php endif; ?></tr></thead>
		<tbody>
		<?php foreach ( $orders as $order ) : ?>
			<?php
			$t     = $order->get_meta( '_dc_delivery_time' );
			$ptime = $order->get_meta( '_dc_planned_time' );
			$term  = ( $t ? $t : '—' ) . ( $ptime ? ' → ' . $ptime : '' );
			?>
			<tr<?php echo kuchnia_is_new_order( $order ) ? ' class="kuchnia-new"' : ''; ?>>
				<td data-label="Nr">#<?php echo esc_html( $order->get_order_number() ); ?></td>
				<td data-label="Termin"><?php echo esc_html( $term ); ?></td>
				<td data-label="Nazwisko"><?php echo esc_html( $order->get_formatted_billing_full_name() ); ?></td>
				<td data-label="Adres"><?php echo esc_html( kuchnia_order_address( $order ) ); ?></td>
				<td data-label="Wartość"><?php echo wp_kses_post( wc_price( $order->get_total(), array( 'currency' => $order->get_currency() ) ) ); ?></td>
				<td data-label="Status"><?php echo kuchnia_status_badge_html( $order ); ?></td>
				<?php if ( $actions ) : ?>
				<td data-label="" class="kuchnia-noprint">
					<?php if ( $resched ) : ?>
						<button type="button" class="kuchnia-resched-btn" data-order="<?php echo (int) $order->get_id(); ?>">Nowy termin</button>
					<?php endif; ?>
					<?php if ( kuchnia_can_cancel( $order ) ) : ?>
						<button type="button" class="kuchnia-cancel-btn" data-order="<?php echo (int) $order->get_id(); ?>">Anuluj</button>
					<?php endif; ?>
				</td>
				<?php endif; ?>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
	<?php
	return ob_get_clean();
}

// Zbiorczy znaczek otwarty/zamknięty dla grupy terminów (zamknięty = wszystkie zamknięte).
function kuchnia_group_badge_html( $slots ) {
	$closed = true;
	foreach ( $slots as $sl ) {
		if ( ! $sl['closed'] ) {
			$closed = false;
		}
	}
	return '<span class="kuchnia-cutoff-badge kuchnia-cutoff-' . ( $closed ? 'closed' : 'open' ) . '">' . ( $closed ? 'zamknięty' : 'otwarty' ) . '</span>';
}

// Lista pod kreską: $days = [ data => [ cutoff_ts => [ sloty ] ] ] w gotowej
// kolejności. Nagłówek dnia → "Cutoff: …" → "Wyjazd HH:MM" → tabela.
function kuchnia_days_html( $days, $actions ) {
	ob_start();
	foreach ( $days as $d => $cuts ) {
		$day_count = 0;
		foreach ( $cuts as $cut_slots ) {
			foreach ( $cut_slots as $sl ) {
				$day_count += count( $sl['orders'] );
			}
		}
		echo '<div class="kuchnia-section-header kuchnia-day-header">' . esc_html( ucfirst( function_exists( 'dc_date_label' ) ? dc_date_label( $d ) : $d ) ) . ' <span class="kuchnia-count">(' . (int) $day_count . ')</span></div>';
		foreach ( $cuts as $cut_ts => $cut_slots ) {
			echo '<div class="kuchnia-cutoff-header">' . ( $cut_ts ? 'Cutoff: ' . esc_html( kuchnia_cutoff_label( $cut_ts ) ) . ' ' . kuchnia_group_badge_html( $cut_slots ) : 'Bez godziny dostawy' ) . '</div>';
			foreach ( $cut_slots as $sl ) {
				echo '<div class="kuchnia-time-header">Wyjazd ' . esc_html( $sl['time'] ) . ' <span class="kuchnia-count">(' . count( $sl['orders'] ) . ')</span></div>';
				echo kuchnia_orders_table_html( $sl['orders'], $actions ); // phpcs:ignore
			}
		}
	}
	return ob_get_clean();
}

// [ 'HH:MM' => liczba zamówień ], posortowane godzinowo.
function kuchnia_slots_for_date( $date ) {
	$counts = array();
	foreach ( kuchnia_orders_for_date( $date ) as $order ) {
		$t = $order->get_meta( '_dc_delivery_time' );
		if ( ! $t ) {
			$t = '—';
		}
		$counts[ $t ] = ( isset( $counts[ $t ] ) ? $counts[ $t ] : 0 ) + 1;
	}
	ksort( $counts );
	return $counts;
}

// Zamówienia dokładnie na wybrany dzień + godzinę.
function kuchnia_orders_for_slot( $date, $time ) {
	$out = array();
	foreach ( kuchnia_orders_for_date( $date ) as $order ) {
		$t = $order->get_meta( '_dc_delivery_time' );
		if ( ( $t ? $t : '—' ) === $time ) {
			$out[] = $order;
		}
	}
	return $out;
}

// Statusy oznaczające "minął cutoff, zamówienie jest już w realizacji" –
// to one decydują o widoczności w zakładkach Kuchnia/Pakowanie/Planowanie/
// Kurier (w odróżnieniu od "Zamówienia", które pokazuje wszystko opłacone).
// Zamiast pokazywać w Kuchni/Pakowaniu/Planowaniu/Kurierze tylko to, co już
// przeszło cutoff, pokazujemy WSZYSTKIE opłacone zamówienia dnia – kuchnia ma
// wiedzieć wcześniej, co nadchodzi, żeby móc zacząć przygotowania z
// wyprzedzeniem. Rozróżnienie "cutoff otwarty/zamknięty" pokazujemy osobno,
// przy każdym oknie (patrz kuchnia_cutoff_badge_html), zamiast całkiem
// chować zamówienia, których okno jeszcze przyjmuje nowe zgłoszenia.
function kuchnia_pipeline_statuses() {
	$out = array();
	foreach ( kuchnia_statuses() as $s ) {
		$out[] = ( 0 === strpos( $s, 'wc-' ) ) ? substr( $s, 3 ) : $s;
	}
	return $out;
}

function kuchnia_orders_for_date_pipeline( $date ) {
	$statuses = kuchnia_pipeline_statuses();
	return array_values( array_filter( kuchnia_orders_for_date( $date ), function ( $o ) use ( $statuses ) {
		return in_array( $o->get_status(), $statuses, true );
	} ) );
}

function kuchnia_slots_for_date_pipeline( $date ) {
	$counts = array();
	foreach ( kuchnia_orders_for_date_pipeline( $date ) as $order ) {
		$t = $order->get_meta( '_dc_delivery_time' );
		if ( ! $t ) {
			$t = '—';
		}
		$counts[ $t ] = ( isset( $counts[ $t ] ) ? $counts[ $t ] : 0 ) + 1;
	}
	ksort( $counts );
	return $counts;
}

function kuchnia_orders_for_slot_pipeline( $date, $time ) {
	$out = array();
	foreach ( kuchnia_orders_for_date_pipeline( $date ) as $order ) {
		$t = $order->get_meta( '_dc_delivery_time' );
		if ( ( $t ? $t : '—' ) === $time ) {
			$out[] = $order;
		}
	}
	return $out;
}

// Pozycje jednego zamówienia rozbite na dania (zestaw -> jego dania) z ilością i info czy to dodatek.
function kuchnia_order_lines( $order ) {
	$lines = array();
	foreach ( $order->get_items() as $item ) {
		$qty = (int) $item->get_quantity();
		if ( $qty <= 0 ) {
			continue;
		}
		$w_zest = $item->get_meta( 'W zestawie' );
		if ( $w_zest ) {
			foreach ( array_filter( array_map( 'trim', explode( ',', $w_zest ) ) ) as $nazwa ) {
				$lines[] = array( 'name' => $nazwa, 'qty' => $qty, 'addon' => false, 'set_name' => $item->get_name(), 'kind' => 'danie' );
			}
		} else {
			$is_addon = (bool) $item->get_meta( 'Dodatek do' );
			$lines[]  = array( 'name' => $item->get_name(), 'qty' => $qty, 'addon' => $is_addon, 'set_name' => '', 'kind' => $is_addon ? 'dodatki' : 'danie' );
		}

		// Dodatki z modułu 10 (katalog Składników) – osobne, policzalne wiersze,
		// niezależnie od tego, czy to była pozycja zestawowa czy zwykły produkt.
		// "Odejmuje" pokazujemy jako osobną pozycję "Bez: …", żeby kuchnia
		// widziała wprost, ile sztuk NIE robić, zamiast cichego odjęcia od sumy.
		if ( function_exists( 'rzd_item_addon_usage' ) ) {
			foreach ( rzd_item_addon_usage( $item ) as $u ) {
				$kind    = function_exists( 'rzd_usage_kind' ) ? rzd_usage_kind( $u ) : 'dodatki';
				$name    = ( 'bez' === $kind ) ? ( 'Bez: ' . $u['name'] ) : $u['name'];
				$lines[] = array( 'name' => $name, 'qty' => (int) $u['qty'] * $qty, 'addon' => true, 'set_name' => '', 'kind' => $kind );
			}
		}
	}
	// Opakowania (moduł 21) – policzone przy zamówieniu, na całe zamówienie.
	if ( function_exists( 'rzd_order_packaging' ) ) {
		foreach ( rzd_order_packaging( $order ) as $p ) {
			if ( ! empty( $p['count'] ) ) {
				$lines[] = array( 'name' => $p['name'], 'qty' => (int) $p['count'], 'addon' => true, 'set_name' => '', 'kind' => 'opakowanie' );
			}
		}
	}
	return $lines;
}

// Modyfikacje wybrane na pozycji zamówienia (z modułu 10) – do widoku "Pakowanie".
function kuchnia_item_modifier_notes( $item ) {
	$notes = array();
	$skip  = array( 'W zestawie', 'Dodatek do', '_reduced_stock', '_qty', '_rzd_addon_usage' );
	foreach ( $item->get_all_formatted_meta_data( '' ) as $meta ) {
		if ( in_array( $meta->key, $skip, true ) ) {
			continue;
		}
		$notes[] = $meta->display_key . ': ' . wp_strip_all_tags( $meta->display_value );
	}
	return $notes;
}

// Skład zestawu zapisany w pozycji zamówienia ("W zestawie", moduł 04) –
// dania zamrożone na dzień dostawy w chwili dodania do koszyka.
function kuchnia_item_set_html( $item ) {
	$w_zest = $item->get_meta( 'W zestawie' );
	if ( ! $w_zest ) {
		return '';
	}
	$names = array_filter( array_map( 'trim', explode( ',', $w_zest ) ) );
	if ( ! $names ) {
		return '';
	}
	return '<div class="kuchnia-set-sklad">W zestawie: ' . esc_html( implode( ', ', $names ) ) . '</div>';
}

// Zestawienie statusów zamówień terminu jako znaczki, np. "2× Przyjęte · 1× Przygotowane".
function kuchnia_status_summary_html( $orders ) {
	$counts = array();
	$first  = array();
	foreach ( $orders as $o ) {
		$st = $o->get_status();
		$counts[ $st ] = ( isset( $counts[ $st ] ) ? $counts[ $st ] : 0 ) + 1;
		if ( ! isset( $first[ $st ] ) ) {
			$first[ $st ] = $o;
		}
	}
	if ( ! $counts ) {
		return '';
	}
	// Kolejność wg przepływu (Przyjęte → … → Dostarczone), inne statusy na początku.
	$flow = function_exists( 'rzd_kitchen_statuses' ) ? array_keys( rzd_kitchen_statuses() ) : array();
	uksort( $counts, function ( $a, $b ) use ( $flow ) {
		$ia = array_search( $a, $flow, true );
		$ib = array_search( $b, $flow, true );
		return ( false === $ia ? -1 : $ia ) <=> ( false === $ib ? -1 : $ib );
	} );
	$parts = array();
	foreach ( $counts as $st => $n ) {
		$parts[] = (int) $n . '× ' . kuchnia_status_badge_html( $first[ $st ] );
	}
	return implode( ' ', $parts );
}

// Widok "Kuchnia": suma ilości wg nazwy dania w całym terminie.
// Lista załadunkowa: sumy OSOBNO w każdym rodzaju (frytki "w zestawie" i
// frytki "dodatek płatny" to dwa wiersze). Kolejność: dania, wybór w
// zestawie, dodatki płatne, obowiązkowe, bez; w rodzaju malejąco po ilości.
function kuchnia_aggregate( $orders ) {
	$out = array();
	foreach ( $orders as $order ) {
		foreach ( kuchnia_order_lines( $order ) as $l ) {
			$kind = isset( $l['kind'] ) ? $l['kind'] : ( $l['addon'] ? 'dodatki' : 'danie' );
			$key  = $kind . '|' . $l['name'];
			if ( ! isset( $out[ $key ] ) ) {
				$out[ $key ] = array( 'name' => $l['name'], 'qty' => 0, 'addon' => $l['addon'], 'kind' => $kind );
			}
			$out[ $key ]['qty'] += $l['qty'];
		}
	}
	$rank = array( 'danie' => 0, 'zestaw' => 1, 'dodatki' => 2, 'obowiazkowe' => 3, 'opakowanie' => 4, 'bez' => 5 );
	usort( $out, function ( $a, $b ) use ( $rank ) {
		$ra = isset( $rank[ $a['kind'] ] ) ? $rank[ $a['kind'] ] : 9;
		$rb = isset( $rank[ $b['kind'] ] ) ? $rank[ $b['kind'] ] : 9;
		return array( $ra, $b['qty'] ) <=> array( $rb, $a['qty'] );
	} );
	return $out;
}

function kuchnia_order_address( $order ) {
	return trim( implode( ', ', array_filter( array(
		$order->get_shipping_address_1() ?: $order->get_billing_address_1(),
		$order->get_shipping_city() ?: $order->get_billing_city(),
		$order->get_shipping_postcode() ?: $order->get_billing_postcode(),
	) ) ) );
}

// Statusy uznawane za "spakowane" w widoku Pakowanie/Kurier (Gotowe i dalej).
function kuchnia_is_packed_status( $status ) {
	return in_array( $status, array( 'gotowe', 'w-dostawie', 'wydane' ), true );
}

function kuchnia_status_label( $slug ) {
	if ( function_exists( 'rzd_kitchen_statuses' ) ) {
		$all = rzd_kitchen_statuses();
		if ( isset( $all[ $slug ] ) ) {
			return $all[ $slug ];
		}
	}
	$name = wc_get_order_status_name( 'wc-' . $slug );
	return $name ? $name : $slug;
}

// Mały znaczek statusu – używany wszędzie, gdzie pokazujemy pojedyncze
// zamówienie (Pakowanie, Planowanie, Kurier), żeby zawsze było widać, na
// jakim etapie realizacji ono jest, bez przechodzenia do innej zakładki.
/**
 * Płatność zamówienia – zwykły tekst (tabele, CSV).
 * Płatność przy odbiorze (COD) → wprost kwota do pobrania; pozostałe metody
 * pojawiają się w dashboardzie dopiero po opłaceniu (patrz kuchnia_orders_for_date),
 * więc dla nich wystarczy "Opłacone" + nazwa metody.
 */
function kuchnia_payment_text( $order ) {
	if ( 'cod' === $order->get_payment_method() ) {
		$amount = html_entity_decode( wp_strip_all_tags( wc_price( $order->get_total() ) ), ENT_QUOTES, 'UTF-8' );
		return 'Przy odbiorze – pobierz ' . trim( $amount );
	}
	$title = $order->get_payment_method_title();
	if ( '' === $title ) {
		$title = $order->get_payment_method();
	}
	return 'Opłacone' . ( '' !== $title ? ' – ' . $title : '' );
}

// Ta sama informacja jako plakietka: COD wyraźnie wyróżnione (kurier ma pobrać gotówkę).
function kuchnia_payment_html( $order ) {
	$cod = ( 'cod' === $order->get_payment_method() );
	return '<span class="kuchnia-pay ' . ( $cod ? 'kuchnia-pay-cod' : 'kuchnia-pay-paid' ) . '">' . esc_html( kuchnia_payment_text( $order ) ) . '</span>';
}

function kuchnia_status_badge_html( $order ) {
	$status = $order->get_status();
	return '<span class="kuchnia-status-badge kuchnia-status-' . esc_attr( $status ) . '">' . esc_html( kuchnia_status_label( $status ) ) . '</span>';
}

// Czy dany termin (okno dostawy) nadal przyjmuje nowe zamówienia, czy jest
// już zamknięty (cutoff minął – lista dla tego okna jest ostateczna).
function kuchnia_cutoff_badge_html( $date, $time ) {
	if ( ! $time || '—' === $time || ! function_exists( 'dc_is_cutoff_passed' ) ) {
		return '';
	}
	$closed = dc_is_cutoff_passed( $date, $time );
	$label  = $closed ? 'Cutoff dostawy: zamknięty' : 'Cutoff dostawy: otwarty';
	$title  = $closed
		? 'Ten termin jest już zamknięty – nic nowego do niego nie dojdzie, można zaczynać przygotowanie albo pakowanie.'
		: 'Ten termin jeszcze przyjmuje zamówienia – mogą dojść kolejne, zanim zaczniesz przygotowanie.';
	return '<span class="kuchnia-cutoff-badge kuchnia-cutoff-' . ( $closed ? 'closed' : 'open' ) . '" title="' . esc_attr( $title ) . '">' . esc_html( $label ) . '</span>';
}

/**
 * "Zaplanowane" na zakładce Planowanie: po kliknięciu, jeśli nie ma błędów
 * (patrz moduł 13), plan danego terminu (data+godzina) zamraża się – pola
 * przestają być edytowalne, dopóki ktoś nie kliknie "Edytuj". Stan trzymamy
 * jako zwykłą opcję w bazie (jedna flaga na termin), nie w metadanych
 * poszczególnych zamówień – to nie jest atrybut zamówienia, tylko stan
 * całego planu na ten termin.
 */
function kuchnia_planning_lock_key( $date, $time ) {
	// JEDYNE miejsce, które decyduje, jaki znak zastępuje pustą godzinę –
	// wywołujący kod (moduł 13) przekazuje $time bez własnej podmiany, żeby
	// nie było dwóch różnych kluczy dla tego samego terminu.
	return 'kuchnia_plan_locked_' . $date . '_' . ( $time ? $time : '-' );
}
function kuchnia_is_planning_locked( $date, $time ) {
	return (bool) get_option( kuchnia_planning_lock_key( $date, $time ), false );
}

// Sortowanie zamówień wg kolejności z Planowania (moduł 13); bez ustawionej
// kolejności lądują na końcu, w kolejności złożenia.
function kuchnia_sort_by_sequence( $orders ) {
	usort( $orders, function ( $a, $b ) {
		$sa = (int) $a->get_meta( '_dc_delivery_sequence' );
		$sb = (int) $b->get_meta( '_dc_delivery_sequence' );
		if ( ! $sa ) { $sa = 999999 + $a->get_id(); }
		if ( ! $sb ) { $sb = 999999 + $b->get_id(); }
		return $sa <=> $sb;
	} );
	return $orders;
}

/* ============================================================
 * 3. STRONA
 * ============================================================ */
function kuchnia_url( $base, $date, $time, $view ) {
	return esc_url( add_query_arg( array( 'date' => $date, 'time' => $time, 'view' => $view ), $base ) );
}

/**
 * Wspólna treść dashboardu – używana zarówno przez stronę w panelu admina,
 * jak i przez shortcode na froncie. $base to adres, do którego linki
 * (terminy, zakładki) dopisują parametry date/time/view.
 */
function kuchnia_render_dashboard( $base, $mode = 'kuchnia' ) {
	$mode  = ( 'kurier' === $mode ) ? 'kurier' : 'kuchnia';
	$date  = isset( $_GET['date'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $_GET['date'] ) ? $_GET['date'] : current_time( 'Y-m-d' );
	// Tryb "kurier" (moduł 19, osobny link i PIN) ma jeden widok i nic więcej.
	$views = ( 'kurier' === $mode ) ? array( 'kurier' ) : array( 'zamowienia', 'kuchnia', 'pakowanie', 'planowanie', 'historia' );
	$view  = isset( $_GET['view'] ) && in_array( $_GET['view'], $views, true ) ? $_GET['view'] : $views[0];
	$range = in_array( $view, array( 'zamowienia', 'historia' ), true ); // widoki bez jednego dnia

	// Zamówienia: wszystko niezrealizowane, bez względu na datę.
	// Historia: od (dziś − "Dni wstecz") do końca przyszłości, z anulowanymi.
	$days_back  = function_exists( 'rzd_kitchen_days_back' ) ? rzd_kitchen_days_back() : 3;
	$auto_prep  = function_exists( 'rzd_kitchen_auto_prep_enabled' ) ? rzd_kitchen_auto_prep_enabled() : true;
	$zam_orders = array();
	if ( 'zamowienia' === $view ) {
		$zam_orders = kuchnia_orders_open();
	} elseif ( 'historia' === $view ) {
		$from_dt = new DateTime( current_time( 'Y-m-d' ), wp_timezone() );
		$from_dt->modify( '-' . $days_back . ' days' );
		$zam_orders = kuchnia_orders_from_date( $from_dt->format( 'Y-m-d' ) );
	}

	// Zanim cokolwiek policzymy: zamówienia, którym minął cutoff, same
	// przechodzą na "W przygotowaniu" (o ile włączone "Auto przygotowanie",
	// moduł 13). Sprawdzane przy każdym wejściu na dashboard (brak WP-Cron),
	// więc w praktyce na bieżąco dzięki auto-odświeżaniu co 60 s.
	if ( 'zamowienia' === $view && function_exists( 'rzd_auto_advance_orders' ) ) {
		rzd_auto_advance_orders( $zam_orders );
	} elseif ( 'historia' !== $view && function_exists( 'rzd_auto_advance_past_cutoff' ) ) {
		rzd_auto_advance_past_cutoff( $date );
	}

	// Pozostałe zakładki pracują na jednym dniu (kalendarzyk) i jego terminach.
	$slots_all = kuchnia_slots_for_date( $date );
	$slots     = ( 'zamowienia' === $view ) ? $slots_all : kuchnia_slots_for_date_pipeline( $date );

	// Kurier: termin, w którym WSZYSTKO jest już dostarczone, znika z wyboru
	// godzin. Po ostatnim "Dostarczone" ekran sam przechodzi do kolejnego
	// terminu (nieznana już godzina z adresu → pierwsza pozostała).
	if ( 'kurier' === $view ) {
		foreach ( array_keys( $slots ) as $st ) {
			$left = array_filter( kuchnia_orders_for_slot_pipeline( $date, $st ), function ( $o ) {
				return ! in_array( $o->get_status(), array( 'wydane', 'completed' ), true );
			} );
			if ( ! $left ) {
				unset( $slots[ $st ] );
			}
		}
	}

	$time = isset( $_GET['time'] ) ? sanitize_text_field( $_GET['time'] ) : '';
	if ( '' === $time || ! isset( $slots[ $time ] ) ) {
		$keys = array_keys( $slots );
		$time = $keys ? $keys[0] : '';
	}

	$orders = $time ? ( ( 'zamowienia' === $view ) ? kuchnia_orders_for_slot( $date, $time ) : kuchnia_orders_for_slot_pipeline( $date, $time ) ) : array();

	// $base bywa adresem z gotowym query stringiem (np. .../admin.php?page=rzd-kuchnia).
	// Formularz z metodą GET przy wysyłce ZASTĘPUJE query string z action swoim własnym,
	// więc żeby np. "page=rzd-kuchnia" nie zniknęło po zmianie daty, doklejamy istniejące
	// parametry $base jako ukryte pola – działa tak samo w panelu, jak i na stronie front-endowej.
	$base_parts = wp_parse_url( $base );
	$base_path  = ( isset( $base_parts['path'] ) ? $base_parts['path'] : $base );
	if ( isset( $base_parts['host'] ) ) {
		$base_path = ( isset( $base_parts['scheme'] ) ? $base_parts['scheme'] . '://' : '//' ) . $base_parts['host'] . $base_path;
	}
	$base_query = array();
	if ( isset( $base_parts['query'] ) ) {
		parse_str( $base_parts['query'], $base_query );
	}
	$front      = ! is_admin(); // strona publiczna ([kuchnia_dashboard]) vs ekran w panelu WP
	$tab_labels = array( 'zamowienia' => 'Zamówienia', 'kuchnia' => 'Kuchnia', 'pakowanie' => 'Pakowanie', 'planowanie' => 'Planowanie', 'historia' => 'Historia', 'kurier' => 'Kurier' );
	$date_label = ucfirst( function_exists( 'dc_date_label' ) ? dc_date_label( $date ) : $date );
	if ( $range ) { // tu nie ma jednego dnia – pokazujemy dzisiejszą datę
		$today      = current_time( 'Y-m-d' );
		$date_label = 'Dziś: ' . ( function_exists( 'dc_date_label' ) ? dc_date_label( $today ) : $today );
	}
	?>
	<div id="kuchnia-popup-root"></div>
	<div class="kuchnia-wrap<?php echo $front ? ' is-front' : ''; ?>">
		<style>
			.kuchnia-wrap { font-size: 16px; }
			/* Strona publiczna: panel zajmuje cały ekran i przykrywa menu/nagłówek/stopkę motywu. */
			.kuchnia-wrap.is-front { position: fixed; inset: 0; z-index: 99990; background: #fff; overflow: auto; padding: 12px 18px 24px; box-sizing: border-box; }
			body.admin-bar .kuchnia-wrap.is-front { top: 32px; }
			@media (max-width: 782px) { body.admin-bar .kuchnia-wrap.is-front { top: 46px; } }
			body.kuchnia-front-body { overflow: hidden; }
			body.kuchnia-front-body .kc-float-cart { display: none !important; }
			/* Data: wyśrodkowana, biała na czarnym; pod nią linia oddzielająca obszar roboczy (na wydruku zastępuje ją .kuchnia-print-head) */
			/* 2.26.20: nagłówek = [wybór dnia] [data] [⚙], kreska pod całym nagłówkiem. */
			.kuchnia-head { display: grid; grid-template-columns: minmax(0, 1fr) auto minmax(0, 1fr); align-items: center; gap: 8px; margin: 0 0 14px; padding: 0 0 12px; border-bottom: 2px solid #c4c4c4; }
			.kuchnia-head-left { justify-self: start; min-width: 0; }
			.kuchnia-head-right { justify-self: end; }
			.kuchnia-head form { margin: 0; }
			.kuchnia-head input[type=date] { font-size: 13px; padding: 5px 6px; max-width: 100%; }
			.kuchnia-gear { width: 38px; height: 38px; padding: 0; border: 1.5px solid #222; border-radius: 50%; background: #fff; color: #222; font-size: 20px; line-height: 1; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; }
			.kuchnia-gear.is-on { background: #222; color: #fff; }
			.kuchnia-date { text-align: center; margin: 0; min-width: 0; }
			.kuchnia-date span { display: inline-block; background: #222; color: #fff; font-size: 16px; font-weight: 600; letter-spacing: .2px; padding: 6px 22px; border-radius: 8px; }
			.kuchnia-print-head { display: none; }
			.kuchnia-top { display: flex; flex-wrap: wrap; align-items: center; gap: 8px; margin: 0 0 10px; }
			.kuchnia-top input[type=date] { font-size: 13px; padding: 5px 6px; }
			.kuchnia-slots { display: flex; flex-wrap: wrap; gap: 6px; margin: 0 0 12px; }
			.kuchnia-slot { display: inline-block; padding: 6px 12px; border: 1.5px solid #222; border-radius: 8px; font-size: 13px; text-decoration: none; color: #222; font-weight: 700; background: #fff; }
			.kuchnia-slot.is-active { background: #222; color: #fff; }
			.kuchnia-tabs { display: flex; flex-wrap: wrap; gap: 6px; margin: 0; }
			.kuchnia-tab { padding: 6px 12px; border: 1.5px solid #222; border-radius: 8px; font-size: 13px; text-decoration: none; color: #222; background: #fff; font-weight: 600; }
			.kuchnia-tab.is-active { background: #222; color: #fff; }
			.kuchnia-actions { margin-left: auto; display: flex; gap: 6px; }
			.kuchnia-btn { padding: 6px 12px; border: 1.5px solid #222; border-radius: 8px; background: #fff; color: #222; cursor: pointer; font-size: 13px; }
			.kuchnia-btn.is-on { background: #222; color: #fff; }
			.kuchnia-btn:disabled { opacity: .45; cursor: default; }
			.kuchnia-btn-primary { background: #222; color: #fff; }
			table.kuchnia-table { width: 100%; border-collapse: collapse; background: #fff; margin-bottom: 10px; }
			table.kuchnia-table th, table.kuchnia-table td { text-align: left; padding: 10px 12px; border-bottom: 1px solid #ddd; font-size: 16px; vertical-align: middle; }
			table.kuchnia-table th { background: #f6f6f6; }
			.kuchnia-qty { font-weight: 700; font-size: 20px; white-space: nowrap; }
			.kuchnia-section-header { font-size: 20px; font-weight: 700; margin: 24px 0 10px; }
			.kuchnia-section-header:first-child { margin-top: 0; }
			.kuchnia-card { background: #fff; border: 1px solid #ddd; border-radius: 10px; padding: 14px 16px; margin: 0 0 14px; display: flex; flex-wrap: wrap; gap: 16px; justify-content: space-between; align-items: flex-start; }
			.kuchnia-card-main { flex: 1 1 260px; min-width: 0; }
			.kuchnia-card h3 { margin: 0 0 8px; }
			.kuchnia-card ul { margin: 0; padding-left: 20px; }
			.kuchnia-card .kuchnia-mod { color: #666; font-size: 13px; }
			.rzd-sklad-note { color: #888; font-size: 12px; }
			.kuchnia-set-sklad { color: #444; font-size: 13px; margin-top: 2px; }
			.kuchnia-status-summary .kuchnia-status-badge { margin-right: 6px; }
			.kuchnia-wait { color: #888; font-size: 13px; }
			.kuchnia-packed-box { display: inline-flex; align-items: center; gap: 10px; background: #fff; border: 1px solid #ddd; border-radius: 8px; padding: 10px 14px; margin: 0 8px 8px 0; cursor: pointer; font-weight: 600; }
			.kuchnia-packed-box:hover { background: #f6f6f6; }
			.kuchnia-packed-detail { display: none; background: #fff; border: 1px solid #ddd; border-radius: 8px; padding: 12px 14px; margin: 0 0 10px; }
			.kuchnia-packed-detail.is-open { display: block; }
			.kuchnia-pack-btn, .kuchnia-cancel-btn, .kuchnia-deliver-btn { padding: 8px 14px; border: 2px solid #222; border-radius: 8px; background: #fff; color: #222; cursor: pointer; font-weight: 700; }
			.kuchnia-pack-btn:hover, .kuchnia-deliver-btn:hover { background: #222; color: #fff; }
			.kuchnia-status-badge { display: inline-block; font-size: 13px; font-weight: 700; padding: 3px 10px; border-radius: 20px; background: #eee; color: #444; border: 1px solid rgba(0,0,0,.12); vertical-align: middle; white-space: nowrap; }
			.kuchnia-pay { display: inline-block; font-size: 12px; font-weight: 700; padding: 2px 8px; border-radius: 20px; vertical-align: middle; }
			.kuchnia-pay-paid { background: #d9f2df; color: #146c34; }
			.kuchnia-pay-cod { background: #fde8c8; color: #8a4b00; border: 1px solid #e0a35a; }
			.kuchnia-cutoff-badge { display: inline-block; font-size: 11px; font-weight: 700; padding: 2px 8px; border-radius: 20px; vertical-align: middle; }
			.kuchnia-cutoff-open { background: #d9f2df; color: #146c34; }
			.kuchnia-cutoff-closed { background: #f0f0f0; color: #666; }
			.kuchnia-status-badge.kuchnia-status-przyjete { background: #eceff3; color: #3a4655; }
			.kuchnia-status-badge.kuchnia-status-w-przygotowaniu { background: #ffe1c7; color: #8a3f00; }
			.kuchnia-status-badge.kuchnia-status-gotowe { background: #fff3cd; color: #7a5b00; }
			.kuchnia-status-badge.kuchnia-status-w-dostawie { background: #d8e8ff; color: #14418a; }
			.kuchnia-status-badge.kuchnia-status-wydane { background: #d9f2df; color: #146c34; }
			.kuchnia-popup-backdrop { position: fixed; inset: 0; background: rgba(0,0,0,.45); z-index: 100010; display: flex; align-items: center; justify-content: center; }
			.kuchnia-popup { background: #fff; border-radius: 12px; padding: 24px 28px; max-width: 320px; width: 100%; text-align: center; box-shadow: 0 10px 40px rgba(0,0,0,.3); }
			.kuchnia-popup p { font-size: 16px; margin: 0 0 18px; }
			.kuchnia-popup button { padding: 10px 28px; border-radius: 8px; border: 2px solid #222; background: #222; color: #fff; font-weight: 700; cursor: pointer; }
			.kuchnia-cancel-btn { border-color: #b32d2e; color: #b32d2e; }
			.kuchnia-cancel-btn:hover { background: #b32d2e; color: #fff; }
			.kuchnia-plan-input { width: 70px; padding: 6px; font-size: 15px; }
			.kuchnia-plan-time { width: 100px; padding: 6px; font-size: 15px; }
			select.kuchnia-plan-time { width: auto; min-width: 110px; }
			.kuchnia-plan-head { margin: 0 0 10px; padding: 8px 12px; border: 2px solid #2271b1; border-radius: 8px; background: #f0f6fc; font-size: 15px; }
			.kuchnia-plan-head.is-over { border-color: #b32d2e; background: #fcf0f1; color: #b32d2e; }
			.kuchnia-plan-input:disabled, .kuchnia-plan-time:disabled { background: #f0f0f0; color: #666; border-color: #ddd; }
			#kuchnia-plan-actions { margin-top: 4px; }
			.kuchnia-next { border: 2px solid #222; border-radius: 10px; padding: 12px 14px; margin: 0 0 6px; background: #fafafa; }
			.kuchnia-next-title { font-size: 20px; font-weight: 700; margin: 0 0 6px; }
			hr.kuchnia-split { border: 0; border-top: 6px solid #222; margin: 22px 0; }
			.kuchnia-cutoff-header { font-size: 16px; font-weight: 700; margin: 14px 0 6px; padding-left: 10px; border-left: 4px solid #999; }
			.kuchnia-time-header { font-size: 14px; font-weight: 700; color: #444; margin: 8px 0 4px 14px; }
			.kuchnia-count { color: #888; font-weight: 400; }
			.kuchnia-overdue-header { color: #8a3f00; }
			.kuchnia-resched { border: 2px solid #8a3f00; border-radius: 10px; padding: 8px 14px 12px; margin: 14px 0 0; background: #fff8f0; }
			.kuchnia-resched .kuchnia-section-header { margin-top: 4px; }
			table.kuchnia-table tr.kuchnia-kind-row td { background: #f0f0f1; font-weight: 700; font-size: 13px; text-transform: uppercase; letter-spacing: .03em; }
			table.kuchnia-table tr.kuchnia-kind-bez td { color: #8a3f00; }
			.kuchnia-packs { font-size: 16px; margin: 6px 0; padding: 6px 10px; background: #f6f7f7; border-radius: 6px; }
			.kurier-contents div { white-space: nowrap; line-height: 1.5; }
			.kuchnia-onroad { margin: 8px 0 0; padding: 6px 12px; border-radius: 8px; background: #f0f0f1; color: #555; font-size: 14px; }
			.kuchnia-cd { margin-left: 8px; font-weight: 700; white-space: nowrap; }
			.kuchnia-cd.is-soon { font-variant-numeric: tabular-nums; }
			.kuchnia-resched-btn { padding: 4px 10px; border: 2px solid #8a3f00; border-radius: 6px; background: #fff; color: #8a3f00; cursor: pointer; font-weight: 700; margin-right: 6px; }
			.kuchnia-resched-btn:hover { background: #8a3f00; color: #fff; }
			.kuchnia-rs-dates { display: block; width: 100%; margin: 6px 0 10px; padding: 6px; font-size: 15px; }
			.kuchnia-rs-times { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 10px; }
			.kuchnia-rs-times button { padding: 6px 12px; border: 2px solid #222; border-radius: 6px; background: #fff; cursor: pointer; }
			.kuchnia-rs-times button.is-on { background: #222; color: #fff; }
			.kuchnia-status-badge.kuchnia-status-cancelled { background: #eee; color: #777; text-decoration: line-through; }
			.kuchnia-maplink, .kuchnia-tellink { color: inherit; text-decoration: underline; }
			.kuchnia-days-back { font-size: 13px; }
			.kuchnia-days-back input { width: 60px; font-size: 13px; padding: 4px 6px; }
			.kuchnia-settings { display: none; flex-wrap: wrap; align-items: center; gap: 6px; margin: 0 0 12px; padding: 10px; border: 1px solid #ddd; border-radius: 8px; background: #fafafa; }
			.kuchnia-settings.is-open { display: flex; }
			/* Nowe zamówienie (ostatnie 10 min) – tylko pogrubione */
			table.kuchnia-table tr.kuchnia-new td { font-weight: 700; }
			.kuchnia-card.kuchnia-new, .kuchnia-card.kuchnia-new li { font-weight: 700; }
			/* Pakowanie: skład większy, pozycje w dwóch kolumnach */
			.kuchnia-card ul { columns: 2; column-gap: 32px; }
			.kuchnia-card li { font-size: 18px; margin: 0 0 8px; break-inside: avoid; page-break-inside: avoid; }
			.kuchnia-card li .kuchnia-set-sklad, .kuchnia-card li .rzd-sklad-note, .kuchnia-card li .kuchnia-mod { font-size: 15px; color: #333; }
			.kuchnia-card-btns { display: flex; flex-direction: column; gap: 8px; }
			.kuchnia-prep-btn { padding: 8px 14px; border: 2px solid #222; border-radius: 8px; background: #fff; color: #222; cursor: pointer; font-weight: 700; }
			.kuchnia-prep-btn:hover { background: #222; color: #fff; }
			.kuchnia-prep-btn.is-muted { border-color: #bbb; color: #999; }
			.kuchnia-prep-btn.is-muted:hover { background: #999; border-color: #999; color: #fff; }
			.kuchnia-prep-done { padding: 8px 4px; font-weight: 700; color: #7a5b00; text-align: center; }
			@media (max-width: 782px) { .kuchnia-card ul { columns: 1; } }
			/* Telefon: mniejsze przyciski górnego menu */
			@media (max-width: 600px) {
				.kuchnia-top, .kuchnia-tabs, .kuchnia-actions, .kuchnia-slots, .kuchnia-settings { gap: 4px; }
				.kuchnia-tab, .kuchnia-slot, .kuchnia-btn { font-size: 11px; padding: 3px 7px; border-width: 1px; border-radius: 6px; }
				.kuchnia-top input[type=date], .kuchnia-days-back, .kuchnia-days-back input { font-size: 11px; }
				.kuchnia-actions { margin-left: 0; }
				.kuchnia-date span { font-size: 12px; padding: 4px 10px; }
				.kuchnia-head { grid-template-columns: auto minmax(0, 1fr) auto; gap: 6px; }
				.kuchnia-head input[type=date] { font-size: 11px; padding: 3px 4px; }
				.kuchnia-gear { width: 32px; height: 32px; font-size: 17px; }
			}
			.kuchnia-empty { padding: 20px; background: #fff; border: 1px dashed #ccc; border-radius: 10px; color: #666; }
			@media (max-width: 600px) { .kuchnia-card { flex-direction: column; } }
			@media (max-width: 782px) {
				table.kuchnia-table, table.kuchnia-table thead, table.kuchnia-table tbody, table.kuchnia-table th, table.kuchnia-table td, table.kuchnia-table tr { display: block; }
				table.kuchnia-table thead { display: none; }
				table.kuchnia-table tr { border: 1px solid #ddd; border-radius: 8px; margin-bottom: 10px; padding: 6px 0; }
				table.kuchnia-table td { border: 0; }
				table.kuchnia-table td::before { content: attr(data-label); display: block; font-size: 12px; color: #888; }
			}
			body.kuchnia-kiosk #adminmenumain, body.kuchnia-kiosk #wpadminbar, body.kuchnia-kiosk #wpfooter { display: none !important; }
			body.kuchnia-kiosk #wpcontent, body.kuchnia-kiosk #wpbody-content { margin-left: 0 !important; padding-left: 0 !important; }
			body.kuchnia-kiosk html { margin-top: 0 !important; }
			/* ---------- WYDRUK ----------
			   Cel: czytelna lista (zwłaszcza dla kuriera) – sama treść, bez ozdobników:
			   bez menu/nagłówka/logo/stopki motywu, bez przycisków, tabela na całą szerokość
			   kartki (poziomo). Elementy motywu chowa skrypt niżej (klasa kuchnia-print-hide
			   na "rodzeństwie" panelu), bo nie znamy selektorów cudzego motywu. */
			@page { size: A4 landscape; margin: 10mm; }
			@media print {
				.kuchnia-print-hide, #adminmenumain, #wpadminbar, #wpfooter, .kc-float-cart, #kuchnia-popup-root,
				.kuchnia-top, .kuchnia-slots, .kuchnia-tabs, .kuchnia-head, .kuchnia-date, .kuchnia-pack-btn, .kuchnia-cancel-btn, .kuchnia-deliver-btn { display: none !important; }
				html, body { background: #fff !important; margin: 0 !important; padding: 0 !important; height: auto !important; overflow: visible !important; }
				#wpcontent, #wpbody-content { margin: 0 !important; padding: 0 !important; }
				/* 2.26.3: na wydruku większa czcionka i tabela zawsze w szerokości kartki. */
				.kuchnia-print-anc { width: auto !important; min-width: 0 !important; max-width: none !important; margin: 0 !important; padding: 0 !important; float: none !important; position: static !important; transform: none !important; box-shadow: none !important; border: 0 !important; }
				.kuchnia-wrap, .kuchnia-wrap.is-front { position: static !important; inset: auto !important; overflow: visible !important; width: auto !important; min-width: 0 !important; max-width: none !important; height: auto !important; margin: 0 !important; padding: 0 !important; background: none !important; font-size: 14px; color: #000; }
				.kuchnia-wrap a[href]::after { content: none !important; } /* motywy dopisują adres linku – rozpycha kolumny */
				.kuchnia-print-head { display: block !important; font-size: 18px; margin: 0 0 10px; }
				.kuchnia-slot-header::before { content: "Wyjazd o godzinie: "; font-weight: 400; }
				.kuchnia-section-header { font-size: 18px; margin: 14px 0 6px; }
				.kuchnia-cutoff-header { font-size: 16px; }
				.kuchnia-time-header { font-size: 15px; color: #000; }
				table.kuchnia-table { display: table !important; width: 100% !important; max-width: 100% !important; table-layout: auto; border-collapse: collapse; margin: 0 0 8px; }
				table.kuchnia-table thead { display: table-header-group !important; }
				table.kuchnia-table tbody { display: table-row-group !important; }
				table.kuchnia-table tr { display: table-row !important; page-break-inside: avoid; break-inside: avoid; border: 0 !important; padding: 0 !important; margin: 0 !important; }
				table.kuchnia-table th, table.kuchnia-table td { display: table-cell !important; border: 1px solid #555 !important; padding: 5px 7px !important; font-size: 14px !important; line-height: 1.35; color: #000 !important; background: none !important; overflow-wrap: anywhere; word-break: break-word; vertical-align: top; white-space: normal !important; }
				table.kuchnia-table td *, .kurier-contents div { white-space: normal !important; }
				table.kuchnia-table th { font-weight: 700; font-size: 13px !important; }
				table.kuchnia-table .kuchnia-qty { white-space: nowrap !important; font-size: 16px !important; }
				table.kuchnia-table td::before { content: none !important; }
				table.kuchnia-table .kuchnia-noprint { display: none !important; }
				/* Kurier: stałe szerokości kolumn – suma 100 %, nic nie wyjdzie za kartkę. */
				table.kuchnia-table.kurier-table { table-layout: fixed; }
				table.kurier-table th:nth-child(1) { width: 4%; }
				table.kurier-table th:nth-child(2) { width: 15%; }
				table.kurier-table th:nth-child(3) { width: 9%; }
				table.kurier-table th:nth-child(4) { width: 8%; }
				table.kurier-table th:nth-child(5) { width: 22%; }
				table.kurier-table th:nth-child(6) { width: 12%; }
				table.kurier-table th:nth-child(7) { width: 9%; }
				table.kurier-table th:nth-child(8) { width: 21%; }
				.kuchnia-pay, .kuchnia-status-badge { background: none !important; border: 0 !important; padding: 0 !important; border-radius: 0 !important; font-size: 13px !important; font-weight: 700; color: #000 !important; white-space: normal !important; }
				.kuchnia-card, .kuchnia-packed-box, .kuchnia-packed-detail { break-inside: avoid; }
				.kuchnia-settings, .kuchnia-card-btns { display: none !important; }
				.kuchnia-card { border: 1px solid #555 !important; }
				.kuchnia-card-main { flex: 1 1 100% !important; }
				.kuchnia-card h3 { font-size: 18px; }
				.kuchnia-card ul { columns: 2 !important; }
				.kuchnia-card li { font-size: 16px !important; color: #000 !important; }
				.kuchnia-card li .kuchnia-set-sklad, .kuchnia-card li .rzd-sklad-note, .kuchnia-card li .kuchnia-mod { font-size: 14px !important; color: #000 !important; }
				.kuchnia-packs { font-size: 15px; background: none !important; padding: 2px 0; }
				.kuchnia-plan-input, .kuchnia-plan-time { font-size: 14px; }

			}
		</style>

		<?php
		// 2.26.20: nagłówek nad kreską – data (wybór dnia) z lewej, etykieta dnia
		// na środku, ⚙ z prawej. Pełny ekran i Drukuj są w panelu pod trybikiem.
		?>
		<div class="kuchnia-head">
			<div class="kuchnia-head-left">
				<?php if ( ! $range ) : ?>
				<form method="get" class="kuchnia-date-form" action="<?php echo esc_url( $base_path ); ?>">
					<?php foreach ( $base_query as $k => $v ) : ?>
						<input type="hidden" name="<?php echo esc_attr( $k ); ?>" value="<?php echo esc_attr( $v ); ?>">
					<?php endforeach; ?>
					<input type="hidden" name="view" value="<?php echo esc_attr( $view ); ?>">
					<input type="date" name="date" value="<?php echo esc_attr( $date ); ?>" onchange="this.form.requestSubmit ? this.form.requestSubmit() : this.form.submit()">
				</form>
				<?php endif; ?>
			</div>
			<div class="kuchnia-date"><span><?php echo esc_html( $date_label ); ?></span></div>
			<div class="kuchnia-head-right">
				<button type="button" class="kuchnia-gear" id="kuchnia-settings-toggle" title="Ustawienia" aria-label="Ustawienia">⚙</button>
			</div>
		</div>
		<div class="kuchnia-print-head"><strong><?php echo esc_html( $date_label ); ?></strong> · <?php echo esc_html( isset( $tab_labels[ $view ] ) ? $tab_labels[ $view ] : '' ); ?><?php echo ( $time && '—' !== $time && ! $range ) ? ' · Wyjazd o godzinie: ' . esc_html( $time ) : ''; ?></div>

		<?php // Panel ustawień: "Auto przygotowanie" – wspólne (serwer), reszta – na tym urządzeniu. ?>
		<div class="kuchnia-settings" id="kuchnia-settings">
			<button type="button" class="kuchnia-btn" id="kuchnia-kiosk-toggle">Pełny ekran</button>
			<button type="button" class="kuchnia-btn" onclick="window.print()">Drukuj</button>
			<button type="button" class="kuchnia-btn" id="kuchnia-refresh-toggle">Auto-odświeżanie: włączone</button>
			<?php if ( 'kuchnia' === $mode ) : ?>
			<button type="button" class="kuchnia-btn<?php echo $auto_prep ? ' is-on' : ''; ?>" id="kuchnia-autoprep-toggle" data-on="<?php echo $auto_prep ? '1' : '0'; ?>" title="Po cutoffie zamówienia same przechodzą na „W przygotowaniu” (wspólne dla wszystkich urządzeń)">Auto przygotowanie: <?php echo $auto_prep ? 'włączone' : 'wyłączone'; ?></button>
			<button type="button" class="kuchnia-btn" id="kuchnia-alert-popup-toggle" title="Tak: okno z OK przy nowym zamówieniu. Nie: sam dźwięk i pogrubienie.">Okno z powiadomieniem: nie</button>
			<button type="button" class="kuchnia-btn" id="kuchnia-alert-repeat-toggle" title="Dźwięk powtarzany, aż ktoś kliknie OK (tylko z oknem powiadomienia)">Powtarzaj dźwięk: nie</button>
			<button type="button" class="kuchnia-btn" id="kuchnia-sound-test">Test dźwięku</button>
			<span class="kuchnia-mod">Okno, powtarzanie i odświeżanie zapisują się na tym urządzeniu.</span>
			<?php endif; ?>
		</div>

		<div class="kuchnia-top">
			<?php if ( 'zamowienia' === $view ) : ?>
			<?php elseif ( 'historia' === $view ) : ?>
			<label class="kuchnia-days-back">Dni wstecz: <input type="number" min="0" max="60" id="kuchnia-days-back" value="<?php echo (int) $days_back; ?>"></label>
			<?php endif; ?>
			<?php if ( 'kuchnia' === $mode ) : ?>
			<div class="kuchnia-tabs">
				<a class="kuchnia-tab<?php echo ( 'zamowienia' === $view ) ? ' is-active' : ''; ?>" href="<?php echo kuchnia_url( $base, $date, $time, 'zamowienia' ); ?>">Zamówienia</a>
				<a class="kuchnia-tab<?php echo ( 'kuchnia' === $view ) ? ' is-active' : ''; ?>" href="<?php echo kuchnia_url( $base, $date, $time, 'kuchnia' ); ?>">Kuchnia</a>
				<a class="kuchnia-tab<?php echo ( 'pakowanie' === $view ) ? ' is-active' : ''; ?>" href="<?php echo kuchnia_url( $base, $date, $time, 'pakowanie' ); ?>">Pakowanie</a>
				<a class="kuchnia-tab<?php echo ( 'planowanie' === $view ) ? ' is-active' : ''; ?>" href="<?php echo kuchnia_url( $base, $date, $time, 'planowanie' ); ?>">Planowanie</a>
				<a class="kuchnia-tab<?php echo ( 'historia' === $view ) ? ' is-active' : ''; ?>" href="<?php echo kuchnia_url( $base, $date, $time, 'historia' ); ?>">Historia</a>
			</div>
			<?php else : ?>
			<div class="kuchnia-tabs"><span class="kuchnia-tab is-active">Kurier</span></div>
			<?php endif; ?>
		</div>


		<?php if ( ! $range ) : ?>
			<?php if ( ! $slots ) : ?>
				<p class="kuchnia-empty"><?php echo 'kurier' === $view ? 'Wszystkie dostawy na ten dzień są dostarczone albo nie ma zamówień.' : 'Brak opłaconych zamówień na ten dzień.'; ?></p>
			<?php else : ?>
				<div class="kuchnia-slots">
					<?php foreach ( $slots as $t => $count ) : ?>
						<a class="kuchnia-slot<?php echo ( $t === $time ) ? ' is-active' : ''; ?>" href="<?php echo kuchnia_url( $base, $date, $t, $view ); ?>">
							<?php echo esc_html( $t ); ?> · <?php echo (int) $count; ?> <?php echo kuchnia_cutoff_badge_html( $date, $t ); ?>
						</a>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		<?php endif; ?>

		<?php if ( 'zamowienia' === $view ) : ?>
			<?php
			$groups = kuchnia_slot_groups( $zam_orders );
			$now_ts = time();
			$today  = current_time( 'Y-m-d' );
			usort( $groups, function ( $a, $b ) {
				return array( $a['date'], $a['cutoff_ts'] ? $a['cutoff_ts'] : PHP_INT_MAX, $a['time'] ) <=> array( $b['date'], $b['cutoff_ts'] ? $b['cutoff_ts'] : PHP_INT_MAX, $b['time'] );
			} );

			// TAŚMA: lista (czeka) → "Najbliższy wyjazd" → wyjazd.
			// Po godzinie wyjazdu: Spakowane w oknie klienta (wyjazd + 1 h) = "W drodze";
			// niespakowane albo po końcu okna bez "Dostarczone" = "Do przeplanowania".
			$upcoming = array();
			$resched  = array(); // sloty (tylko zamówienia do przeplanowania)
			$onroad   = array(); // [ 'time' => …, 'count' => …, 'end' => ts ]
			foreach ( $groups as $sl ) {
				usort( $sl['orders'], function ( $a, $b ) { return $a->get_id() <=> $b->get_id(); } );
				$gone = $sl['depart_ts'] ? ( $sl['depart_ts'] <= $now_ts ) : ( $sl['date'] < $today );
				if ( ! $gone ) {
					$upcoming[] = $sl;
					continue;
				}
				$win_end = $sl['depart_ts'] ? $sl['depart_ts'] + HOUR_IN_SECONDS : 0;
				// Tryb okien: prawdziwy koniec okna zamiast wyjazdu + 1 h.
				if ( $sl['depart_ts'] && function_exists( 'dc_windows_on' ) && dc_windows_on() ) {
					$w_obj = dc_window_at( $sl['date'], $sl['time'] );
					if ( $w_obj ) {
						$win_end = dc_date_ts( $sl['date'], $w_obj['end'] );
					}
				}
				$road    = array();
				$late    = array();
				foreach ( $sl['orders'] as $o ) {
					if ( 'w-dostawie' === $o->get_status() && $win_end && $now_ts < $win_end ) {
						$road[] = $o;
					} else {
						$late[] = $o;
					}
				}
				if ( $road ) {
					$onroad[] = array( 'time' => $sl['time'], 'count' => count( $road ), 'end' => $win_end );
				}
				if ( $late ) {
					$sl['orders'] = $late;
					$resched[]    = $sl;
				}
			}

			// GÓRA: wszystkie zamknięte terminy przed wyjazdem; gdy brak – najbliższy otwarty cutoff.
			$top = array_values( array_filter( $upcoming, function ( $sl ) { return $sl['closed'] && $sl['depart_ts']; } ) );
			if ( ! $top && $upcoming ) {
				$timed = array_values( array_filter( $upcoming, function ( $sl ) { return (bool) $sl['depart_ts']; } ) );
				if ( $timed ) {
					$next_cut = min( array_map( function ( $sl ) { return $sl['cutoff_ts']; }, $timed ) );
					$top      = array_values( array_filter( $timed, function ( $sl ) use ( $next_cut ) { return $sl['cutoff_ts'] === $next_cut; } ) );
				}
			}
			usort( $top, function ( $a, $b ) { return $a['depart_ts'] <=> $b['depart_ts']; } );
			$top_keys   = array();
			$top_blocks = array(); // cutoff_ts => sloty, w kolejności najbliższego wyjazdu
			foreach ( $top as $sl ) {
				$top_blocks[ $sl['cutoff_ts'] ][] = $sl;
				$top_keys[ $sl['date'] . ' ' . $sl['time'] ] = true;
			}

			// DÓŁ: czekające z poprawnym oknem, BEZ tych z góry (bez dublowania).
			$days = array();
			foreach ( $upcoming as $sl ) {
				if ( ! isset( $top_keys[ $sl['date'] . ' ' . $sl['time'] ] ) ) {
					$days[ $sl['date'] ][ $sl['cutoff_ts'] ][] = $sl;
				}
			}
			$resched_count = 0;
			foreach ( $resched as $sl ) {
				$resched_count += count( $sl['orders'] );
			}
			?>
			<div class="kuchnia-next" data-now="<?php echo (int) $now_ts; ?>">
				<div class="kuchnia-next-title">Najbliższy wyjazd</div>
				<?php if ( ! $top_blocks ) : ?>
					<p class="kuchnia-mod">Brak zamówień czekających na wyjazd.</p>
				<?php else : ?>
					<?php foreach ( $top_blocks as $cut_ts => $cut_slots ) : ?>
						<?php $open = ! $cut_slots[0]['closed']; ?>
						<div class="kuchnia-cutoff-header">Cutoff: <?php echo esc_html( kuchnia_cutoff_label( $cut_ts ) ); ?> <?php echo kuchnia_group_badge_html( $cut_slots ); ?>
							<?php if ( $open && $cut_ts > $now_ts ) : ?>
								<span class="kuchnia-cd" data-ts="<?php echo (int) $cut_ts; ?>" data-kind="cutoff" data-reload="1"></span>
							<?php endif; ?>
						</div>
						<?php foreach ( $cut_slots as $sl ) : ?>
							<div class="kuchnia-time-header"><?php echo esc_html( ucfirst( function_exists( 'dc_date_label' ) ? dc_date_label( $sl['date'] ) : $sl['date'] ) ); ?> · wyjazd <?php echo esc_html( $sl['time'] ); ?> <span class="kuchnia-count">(<?php echo count( $sl['orders'] ); ?>)</span>
								<span class="kuchnia-cd" data-ts="<?php echo (int) $sl['depart_ts']; ?>" data-kind="depart" data-reload="1"></span>
							</div>
							<?php echo kuchnia_orders_table_html( $sl['orders'] ); ?>
						<?php endforeach; ?>
					<?php endforeach; ?>
				<?php endif; ?>
			</div>

			<?php if ( $onroad ) : ?>
				<?php
				$road_n   = array_sum( wp_list_pluck( $onroad, 'count' ) );
				$road_t   = implode( ', ', array_unique( wp_list_pluck( $onroad, 'time' ) ) );
				$road_end = min( wp_list_pluck( $onroad, 'end' ) );
				?>
				<div class="kuchnia-onroad">W drodze: <?php echo (int) $road_n; ?> <?php echo 1 === $road_n ? 'zamówienie' : ( ( $road_n % 10 >= 2 && $road_n % 10 <= 4 && ( $road_n % 100 < 10 || $road_n % 100 >= 20 ) ) ? 'zamówienia' : 'zamówień' ); ?> (wyjazd <?php echo esc_html( $road_t ); ?>)
					<span class="kuchnia-cd" data-ts="<?php echo (int) $road_end; ?>" data-kind="silent" data-reload="1" hidden></span>
				</div>
			<?php endif; ?>

			<?php if ( $resched ) : ?>
				<div class="kuchnia-resched">
					<div class="kuchnia-section-header kuchnia-overdue-header">Do przeplanowania – okno minęło, zamówienie niedostarczone <span class="kuchnia-count">(<?php echo (int) $resched_count; ?>)</span></div>
					<p class="kuchnia-mod">Nadaj nowy termin – zamówienie wróci na listę z nowym oknem dostawy.</p>
					<?php foreach ( $resched as $sl ) : ?>
						<div class="kuchnia-time-header"><?php echo esc_html( ucfirst( function_exists( 'dc_date_label' ) ? dc_date_label( $sl['date'] ) : $sl['date'] ) ); ?> · wyjazd <?php echo esc_html( $sl['time'] ); ?> <span class="kuchnia-count">(<?php echo count( $sl['orders'] ); ?>)</span></div>
						<?php echo kuchnia_orders_table_html( $sl['orders'], true, true ); ?>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<hr class="kuchnia-split">

			<?php if ( ! $days ) : ?>
				<p class="kuchnia-empty">Brak kolejnych zamówień czekających na realizację.</p>
			<?php else : ?>
				<?php echo kuchnia_days_html( $days, true ); // phpcs:ignore ?>
			<?php endif; ?>

		<?php elseif ( 'historia' === $view ) : ?>
			<?php
			// Wszystko (także dostarczone i anulowane), malejąco: najnowsze na górze.
			$groups = kuchnia_slot_groups( $zam_orders );
			usort( $groups, function ( $a, $b ) {
				return array( $b['date'], $b['cutoff_ts'], $b['time'] ) <=> array( $a['date'], $a['cutoff_ts'], $a['time'] );
			} );
			$days = array();
			foreach ( $groups as $sl ) {
				$days[ $sl['date'] ][ $sl['cutoff_ts'] ][] = $sl;
			}
			?>
			<?php if ( ! $days ) : ?>
				<p class="kuchnia-empty">Brak zamówień w wybranym zakresie.</p>
			<?php else : ?>
				<?php echo kuchnia_days_html( $days, false ); // phpcs:ignore ?>
			<?php endif; ?>

		<?php elseif ( 'kuchnia' === $view ) : ?>
			<?php
			// Wszystko, co jeszcze NIE jest oznaczone jako Przygotowane – celowo
			// bez względu na to, czy cutoff już minął, żeby kuchnia widziała z
			// wyprzedzeniem, co nadchodzi. Znaczek obok pokazuje, czy lista jest
			// jeszcze otwarta (mogą dojść kolejne zamówienia), czy zamknięta
			// (ostateczna – bezpiecznie można w pełni ruszać z przygotowaniem).
			$do_przygotowania = array_values( array_filter( $orders, function ( $o ) { return ! in_array( $o->get_status(), array( 'gotowe', 'w-dostawie', 'wydane' ), true ); } ) );
			$rows = kuchnia_aggregate( $do_przygotowania );
			?>
			<p class="kuchnia-mod">Ten termin: <?php echo kuchnia_cutoff_badge_html( $date, $time ); ?></p>
			<?php if ( $orders ) : ?>
				<p class="kuchnia-mod kuchnia-status-summary">Zamówienia: <?php echo kuchnia_status_summary_html( $orders ); ?></p>
			<?php endif; ?>
			<?php if ( ! $rows ) : ?>
				<p class="kuchnia-empty">Wszystko z tego terminu jest już przygotowane.</p>
			<?php else : ?>
				<table class="kuchnia-table">
					<thead><tr><th>Produkt</th><th>Rodzaj</th><th>Ilość</th></tr></thead>
					<tbody>
					<?php $prev_kind = null; ?>
					<?php foreach ( $rows as $r ) : ?>
						<?php if ( $r['kind'] !== $prev_kind ) : $prev_kind = $r['kind']; ?>
							<tr class="kuchnia-kind-row"><td colspan="3"><?php echo esc_html( 'danie' === $r['kind'] ? 'Dania' : ( 'opakowanie' === $r['kind'] ? 'Opakowania' : ( function_exists( 'rzd_kind_label' ) ? rzd_kind_label( $r['kind'] ) : 'Dodatki' ) ) ); ?></td></tr>
						<?php endif; ?>
						<tr class="kuchnia-kind-<?php echo esc_attr( $r['kind'] ); ?>">
							<td data-label="Produkt"><?php echo esc_html( 'bez' === $r['kind'] ? preg_replace( '/^Bez: /', '', $r['name'] ) : $r['name'] ); ?></td>
							<td data-label="Rodzaj"><?php echo esc_html( function_exists( 'rzd_kind_label' ) ? rzd_kind_label( $r['kind'] ) : ( $r['addon'] ? 'Dodatek' : 'Danie' ) ); ?></td>
							<td data-label="Ilość" class="kuchnia-qty"><?php echo (int) $r['qty']; ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<button type="button" class="kuchnia-btn kuchnia-btn-primary" id="kuchnia-mark-preparing" data-date="<?php echo esc_attr( $date ); ?>" data-time="<?php echo esc_attr( $time ); ?>">Oznacz cały termin jako „Przygotowane"</button>
			<?php endif; ?>

		<?php elseif ( 'pakowanie' === $view ) : ?>
			<?php
			// Do spakowania = wszystko, co jeszcze nie jest spakowane – bez
			// czekania, aż kuchnia oznaczy termin jako Przygotowane (od 2.20.0).
			// Znaczek statusu przy każdym zamówieniu mówi, na jakim jest etapie.
			$todo   = array_values( array_filter( $orders, function ( $o ) { return ! in_array( $o->get_status(), array( 'w-dostawie', 'wydane' ), true ); } ) );
			$packed = array_values( array_filter( $orders, function ( $o ) { return in_array( $o->get_status(), array( 'w-dostawie', 'wydane' ), true ); } ) );
			?>
			<div class="kuchnia-section-header">Do spakowania (<?php echo count( $todo ); ?>)</div>
			<?php if ( ! $todo ) : ?>
				<p class="kuchnia-empty">Nic do spakowania w tym terminie – wszystko już spakowane.</p>
			<?php else : ?>
				<?php foreach ( $todo as $order ) : ?>
					<div class="kuchnia-card<?php echo kuchnia_is_new_order( $order ) ? ' kuchnia-new' : ''; ?>">
						<div class="kuchnia-card-main">
							<h3>#<?php echo esc_html( $order->get_order_number() ); ?> — <?php echo esc_html( $order->get_formatted_billing_full_name() ); ?> <?php echo kuchnia_status_badge_html( $order ); ?></h3>
							<p class="kuchnia-mod"><?php echo kuchnia_payment_html( $order ); ?></p>
							<ul>
								<?php foreach ( $order->get_items() as $item ) : ?>
									<?php
									$qty  = (int) $item->get_quantity();
									if ( $qty <= 0 ) { continue; }
									$mods = kuchnia_item_modifier_notes( $item );
									?>
									<li>
										<strong><?php echo (int) $qty; ?>×</strong> <?php echo function_exists( 'rzd_product_name_with_sklad_html' ) ? rzd_product_name_with_sklad_html( $item->get_product_id(), $item->get_name() ) : esc_html( $item->get_name() ); ?>
										<?php echo kuchnia_item_set_html( $item ); ?>
										<?php if ( $mods ) : ?>
											<div class="kuchnia-mod"><?php echo esc_html( implode( ' · ', $mods ) ); ?></div>
										<?php endif; ?>
									</li>
								<?php endforeach; ?>
							</ul>
							<?php $packs = function_exists( 'rzd_order_packaging' ) ? rzd_order_packaging( $order ) : array(); ?>
							<?php if ( $packs ) : ?>
								<p class="kuchnia-packs"><strong>Opakowania:</strong>
									<?php echo esc_html( implode( ', ', array_map( function ( $p ) { return (int) $p['count'] . '× ' . $p['name']; }, $packs ) ) ); ?>
								</p>
							<?php endif; ?>
							<?php if ( $order->get_customer_note() ) : ?>
								<p class="kuchnia-mod"><strong>Uwagi klienta:</strong> <?php echo esc_html( $order->get_customer_note() ); ?></p>
							<?php endif; ?>
						</div>
						<div class="kuchnia-card-btns">
							<?php if ( 'gotowe' === $order->get_status() ) : ?>
								<span class="kuchnia-prep-done">✓ Przygotowane</span>
							<?php else : ?>
								<?php // Przy włączonym "Auto przygotowanie" szary = krok opcjonalny, dalej klikalny. ?>
								<button type="button" class="kuchnia-prep-btn<?php echo $auto_prep ? ' is-muted' : ''; ?>" data-order="<?php echo (int) $order->get_id(); ?>">Przygotowane</button>
							<?php endif; ?>
							<button type="button" class="kuchnia-pack-btn" data-order="<?php echo (int) $order->get_id(); ?>">Spakowane</button>
						</div>
					</div>
				<?php endforeach; ?>
			<?php endif; ?>

			<div class="kuchnia-section-header">Spakowane (<?php echo count( $packed ); ?>)</div>
			<?php if ( ! $packed ) : ?>
				<p class="kuchnia-empty">Jeszcze nic nie jest spakowane.</p>
			<?php else : ?>
				<div>
					<?php foreach ( $packed as $order ) : ?>
						<div class="kuchnia-packed-box" data-toggle="kpd-<?php echo (int) $order->get_id(); ?>">
							#<?php echo esc_html( $order->get_order_number() ); ?> — <?php echo esc_html( $order->get_formatted_billing_full_name() ); ?> <?php echo kuchnia_status_badge_html( $order ); ?>
						</div>
					<?php endforeach; ?>
				</div>
				<?php foreach ( $packed as $order ) : ?>
					<div class="kuchnia-packed-detail" id="kpd-<?php echo (int) $order->get_id(); ?>">
						<strong>#<?php echo esc_html( $order->get_order_number() ); ?> — <?php echo esc_html( $order->get_formatted_billing_full_name() ); ?></strong>
						<ul style="margin:8px 0 0 20px;">
							<?php foreach ( $order->get_items() as $item ) : ?>
								<?php $qty = (int) $item->get_quantity(); if ( $qty <= 0 ) { continue; } ?>
								<li><strong><?php echo (int) $qty; ?>×</strong> <?php echo function_exists( 'rzd_product_name_with_sklad_html' ) ? rzd_product_name_with_sklad_html( $item->get_product_id(), $item->get_name() ) : esc_html( $item->get_name() ); ?><?php echo kuchnia_item_set_html( $item ); ?></li>
							<?php endforeach; ?>
						</ul>
					</div>
				<?php endforeach; ?>
			<?php endif; ?>

		<?php elseif ( 'planowanie' === $view ) : ?>
			<?php if ( ! $orders ) : ?>
				<p class="kuchnia-empty">Brak zamówień w tym terminie.</p>
			<?php else : ?>
				<?php
				$locked = kuchnia_is_planning_locked( $date, $time );
				// Tryb okien (2.25.0): siatka slotów z wszystkich zamówień terminu
				// (także już dostarczonych – ich godziny wciąż są zajęte).
				$all_in_slot = function_exists( 'dc_plan_grid' ) ? kuchnia_orders_for_slot( $date, $time ) : array();
				$grid        = function_exists( 'dc_plan_grid' ) ? dc_plan_grid( $date, $time, $all_in_slot ) : null;
				?>
				<?php if ( $grid ) : ?>
					<div class="kuchnia-plan-head<?php echo $grid['used'] > $grid['cap'] ? ' is-over' : ''; ?>">
						Okno <strong><?php echo esc_html( $grid['win']['start'] . '–' . $grid['win']['end'] ); ?></strong>
						· Punkty: <strong><?php echo (int) $grid['used']; ?> / <?php echo (int) $grid['cap']; ?></strong>
						· co <?php echo esc_html( str_replace( '.', ',', (string) round( $grid['win']['len'] / max( 1, $grid['cap'] ), 1 ) ) ); ?> min
						<?php echo $grid['used'] > $grid['cap'] ? ' · <strong>przeładowane – ostatnie godziny wypadają po oknie</strong>' : ''; ?>
					</div>
				<?php endif; ?>
				<table class="kuchnia-table<?php echo $locked ? ' kuchnia-plan-locked' : ''; ?>" id="kuchnia-plan-table">
					<thead><tr><th>Nr</th><th>Nazwisko</th><th>Adres</th><th>Telefon</th><th>Płatność</th><th>Status</th><?php echo $grid ? '<th>Pkt</th>' : ''; ?><th>Kolejność</th><th>Godzina dostawy</th></tr></thead>
					<tbody>
					<?php foreach ( $orders as $order ) : ?>
						<?php
						$seq   = (int) $order->get_meta( '_dc_delivery_sequence' );
						$ptime = $order->get_meta( '_dc_planned_time' );
						?>
						<tr data-order="<?php echo (int) $order->get_id(); ?>">
							<td data-label="Nr">#<?php echo esc_html( $order->get_order_number() ); ?></td>
							<td data-label="Nazwisko"><?php echo esc_html( $order->get_formatted_billing_full_name() ); ?></td>
							<td data-label="Adres"><?php echo esc_html( kuchnia_order_address( $order ) ); ?></td>
							<td data-label="Telefon"><?php echo esc_html( $order->get_billing_phone() ); ?></td>
							<td data-label="Płatność"><?php echo kuchnia_payment_html( $order ); ?></td>
							<td data-label="Status"><?php echo kuchnia_status_badge_html( $order ); ?></td>
							<?php if ( $grid ) : ?>
								<?php
								$opts = dc_plan_options( dc_plan_grid( $date, $time, $all_in_slot, $order->get_id() ), $order );
								?>
								<td data-label="Pkt"><?php echo (int) dc_order_points( $order ); ?></td>
								<td data-label="Kolejność"><input type="number" min="1" class="kuchnia-plan-input" data-field="sequence" value="<?php echo $seq ? esc_attr( $seq ) : ''; ?>" <?php disabled( $locked ); ?>></td>
								<td data-label="Godzina dostawy">
									<select class="kuchnia-plan-time" data-field="planned_time" <?php disabled( $locked ); ?>>
										<option value="">–</option>
										<?php if ( $ptime && ! isset( $opts[ $ptime ] ) ) : ?>
											<option value="<?php echo esc_attr( $ptime ); ?>" selected><?php echo esc_html( $ptime . ' ⚠ koliduje' ); ?></option>
										<?php endif; ?>
										<?php foreach ( $opts as $t => $lbl ) : ?>
											<option value="<?php echo esc_attr( $t ); ?>" <?php selected( $ptime, $t ); ?>><?php echo esc_html( $lbl ); ?></option>
										<?php endforeach; ?>
									</select>
								</td>
							<?php else : ?>
							<td data-label="Kolejność"><input type="number" min="1" class="kuchnia-plan-input" data-field="sequence" value="<?php echo $seq ? esc_attr( $seq ) : ''; ?>" <?php disabled( $locked ); ?>></td>
							<td data-label="Godzina dostawy"><input type="time" class="kuchnia-plan-time" data-field="planned_time" value="<?php echo esc_attr( $ptime ); ?>" <?php disabled( $locked ); ?>></td>
							<?php endif; ?>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<div id="kuchnia-plan-actions">
					<button type="button" class="kuchnia-btn kuchnia-btn-primary" id="kuchnia-plan-confirm" data-date="<?php echo esc_attr( $date ); ?>" data-time="<?php echo esc_attr( $time ); ?>" style="<?php echo $locked ? 'display:none;' : ''; ?>">Zaplanowane</button>
					<button type="button" class="kuchnia-btn" id="kuchnia-plan-edit" data-date="<?php echo esc_attr( $date ); ?>" data-time="<?php echo esc_attr( $time ); ?>" style="<?php echo $locked ? '' : 'display:none;'; ?>">Edytuj</button>
				</div>
				<p class="kuchnia-mod"><?php echo $locked ? 'Plan zatwierdzony – kliknij „Edytuj", żeby coś zmienić.' : 'Wypełnij pola, a potem kliknij „Zaplanowane".'; ?></p>
			<?php endif; ?>

		<?php else : // kurier (moduł 19) ?>
			<?php echo function_exists( 'kurier_view_html' ) ? kurier_view_html( $orders, $date ) : ''; // phpcs:ignore ?>
		<?php endif; ?>
	</div>

	<script>
	(function () {
		var kioskBtn = null, refreshBtn = null; // przypisywane w bindToolbar() (po podmianie treści powstają na nowo)
		var wrapEl = document.querySelector('.kuchnia-wrap');
		var KUCHNIA_MODE = <?php echo wp_json_encode( $mode ); ?>; // 'kuchnia' albo 'kurier' (bez dźwięku i sygnału nowych zamówień)
		var KIOSK_KEY = 'kuchnia_kiosk';
		var REFRESH_KEY = 'kuchnia_autorefresh';
		var isFront = <?php echo $front ? 'true' : 'false'; ?>;

		// Strona publiczna: panel przenosimy na sam wierzch dokumentu (<body>), żeby
		// nakładka na cały ekran nie zależała od kontenerów motywu (transform,
		// overflow itp. potrafią rozwalić position:fixed) – i żeby przy druku
		// wystarczyło schować rodzeństwo panelu.
		if (isFront && wrapEl) {
			document.body.appendChild(wrapEl);
			document.body.classList.add('kuchnia-front-body');
		}

		// ---- Pełny ekran = prawdziwy tryb pełnoekranowy przeglądarki ----
		// Wcześniej przycisk tylko chował elementy panelu WordPressa, więc na
		// stronie publicznej nie robił nic. Uwaga: przeładowanie strony (np. przez
		// auto-odświeżanie) kończy tryb pełnoekranowy – przeglądarka nie pozwala
		// wejść w niego z powrotem bez kliknięcia użytkownika.
		var rootEl = document.documentElement;
		function fsSupported() { return !!(rootEl.requestFullscreen || rootEl.webkitRequestFullscreen); }
		function inFs() { return !!(document.fullscreenElement || document.webkitFullscreenElement); }
		function enterFs() {
			var r = rootEl.requestFullscreen || rootEl.webkitRequestFullscreen;
			if (r) { var pr = r.call(rootEl); if (pr && pr.catch) { pr.catch(function () {}); } }
		}
		function exitFs() {
			var x = document.exitFullscreen || document.webkitExitFullscreen;
			if (x) { var pr = x.call(document); if (pr && pr.catch) { pr.catch(function () {}); } }
		}

		var kiosk = !isFront && localStorage.getItem(KIOSK_KEY) === '1'; // ukrywanie menu WP – tylko w panelu
		function updateKioskLabel() {
			if (!kioskBtn) { return; }
			var on = isFront ? inFs() : (kiosk || inFs());
			kioskBtn.classList.toggle('is-on', on);
			kioskBtn.textContent = on ? 'Wyjdź z pełnego ekranu' : 'Pełny ekran';
		}
		function applyKiosk(on) {
			document.body.classList.toggle('kuchnia-kiosk', on);
			updateKioskLabel();
		}
		document.addEventListener('fullscreenchange', updateKioskLabel);
		document.addEventListener('webkitfullscreenchange', updateKioskLabel);

		// ---- Wydruk: chowamy wszystko, co nie jest panelem (menu, logo, stopka motywu) ----
		// Idziemy w górę od panelu do <body> i każdemu "rodzeństwu" po drodze dajemy
		// klasę kuchnia-print-hide (display:none w druku) – bez znajomości selektorów motywu.
		function markForPrint() {
			var el = wrapEl;
			while (el && el !== document.body && el.parentNode) {
				var par = el.parentNode;
				par.classList.add('kuchnia-print-anc'); // 2.26.3: zdejmij szerokość/marginesy kontenerów motywu
				Array.prototype.forEach.call(par.children, function (sib) {
					var tn = sib.tagName;
					if (sib === el || tn === 'SCRIPT' || tn === 'STYLE' || tn === 'LINK' || tn === 'META' || tn === 'NOSCRIPT') { return; }
					sib.classList.add('kuchnia-print-hide');
				});
				el = par;
			}
		}
		function unmarkAfterPrint() {
			Array.prototype.forEach.call(document.querySelectorAll('.kuchnia-print-hide, .kuchnia-print-anc'), function (n) { n.classList.remove('kuchnia-print-hide', 'kuchnia-print-anc'); });
		}
		window.addEventListener('beforeprint', markForPrint);
		window.addEventListener('afterprint', unmarkAfterPrint);
		if (window.matchMedia) { // Safari nie zawsze wysyła beforeprint/afterprint
			var mq = window.matchMedia('print');
			var onMq = function (e) { if (e.matches) { markForPrint(); } else { unmarkAfterPrint(); } };
			if (mq.addEventListener) { mq.addEventListener('change', onMq); } else if (mq.addListener) { mq.addListener(onMq); }
		}

		var refreshOn = localStorage.getItem(REFRESH_KEY) !== '0';
		var timer = null;
		function applyRefresh(on) {
			if (timer) { clearTimeout(timer); timer = null; }
			if (on) { timer = setTimeout(softReload, 60000); }
			if (!refreshBtn) { return; }
			refreshBtn.classList.toggle('is-on', on);
			refreshBtn.textContent = 'Auto-odświeżanie: ' + (on ? 'włączone' : 'wyłączone');
		}

		// Przyciski paska (Pełny ekran, Auto-odświeżanie) – wiązane od nowa po każdej podmianie treści.
		var settingsOpen = false; // panel "⚙ Ustawienia" zostaje otwarty po podmianie treści
		// Liczniki "cutoff za… / wyjazd za…" liczymy od czasu serwera (zegar tabletu bywa przestawiony).
		var clockOffset = 0;
		function syncClock() {
			var n = wrapEl ? wrapEl.querySelector('.kuchnia-next[data-now]') : null;
			if (n) { clockOffset = parseInt(n.getAttribute('data-now'), 10) - Date.now() / 1000; }
		}
		function bindToolbar() {
			syncClock();
			var setBtn = wrapEl ? wrapEl.querySelector('#kuchnia-settings-toggle') : null;
			var setPanel = wrapEl ? wrapEl.querySelector('#kuchnia-settings') : null;
			if (setBtn && setPanel) {
				setPanel.classList.toggle('is-open', settingsOpen);
				setBtn.classList.toggle('is-on', settingsOpen);
				setBtn.addEventListener('click', function () {
					settingsOpen = !settingsOpen;
					setPanel.classList.toggle('is-open', settingsOpen);
					setBtn.classList.toggle('is-on', settingsOpen);
				});
			}
			updateAlertLabels();
			kioskBtn = wrapEl ? wrapEl.querySelector('#kuchnia-kiosk-toggle') : null;
			refreshBtn = wrapEl ? wrapEl.querySelector('#kuchnia-refresh-toggle') : null;
			if (!kioskBtn || !refreshBtn) { return; }
			if (isFront && !fsSupported()) {
				kioskBtn.style.display = 'none'; // np. iPhone – przeglądarka nie udostępnia pełnego ekranu dla stron
			}
			applyKiosk(kiosk);
			kioskBtn.addEventListener('click', function () {
				var turnOn = isFront ? !inFs() : !kiosk;
				if (!isFront) {
					kiosk = turnOn;
					localStorage.setItem(KIOSK_KEY, kiosk ? '1' : '0');
					applyKiosk(kiosk);
				}
				if (turnOn) { enterFs(); } else if (inFs()) { exitFs(); }
			});
			applyRefresh(refreshOn);
			refreshBtn.addEventListener('click', function () {
				refreshOn = !refreshOn;
				localStorage.setItem(REFRESH_KEY, refreshOn ? '1' : '0');
				applyRefresh(refreshOn);
			});
		}

		// Popup potwierdzający zmianę statusu – klik "OK" odświeża stronę,
		// żeby nowy status był widoczny wszędzie (nie tylko tam, gdzie kliknięto).
		var popupRoot = document.getElementById('kuchnia-popup-root');
		function showStatusPopup(message, reloadAfter) {
			popupRoot.innerHTML = '';
			var backdrop = document.createElement('div');
			backdrop.className = 'kuchnia-popup-backdrop';
			var box = document.createElement('div');
			box.className = 'kuchnia-popup';
			var p = document.createElement('p');
			p.textContent = message;
			var ok = document.createElement('button');
			ok.type = 'button';
			ok.textContent = 'OK';
			ok.addEventListener('click', function () {
				popupRoot.innerHTML = '';
				if (reloadAfter) { softReload(); }
			});
			box.appendChild(p);
			box.appendChild(ok);
			backdrop.appendChild(box);
			popupRoot.appendChild(backdrop);
			ok.focus();
		}

		// Popup z pytaniem tak/nie – zamiast natywnego window.confirm()
		// przeglądarki, żeby wyglądało spójnie z resztą dashboardu.
		function showConfirmPopup(message, confirmLabel, onConfirm) {
			popupRoot.innerHTML = '';
			var backdrop = document.createElement('div');
			backdrop.className = 'kuchnia-popup-backdrop';
			var box = document.createElement('div');
			box.className = 'kuchnia-popup';
			var p = document.createElement('p');
			p.textContent = message;
			var row = document.createElement('div');
			row.style.display = 'flex';
			row.style.gap = '10px';
			var cancel = document.createElement('button');
			cancel.type = 'button';
			cancel.textContent = 'Nie';
			cancel.style.background = '#fff';
			cancel.style.color = '#222';
			var yes = document.createElement('button');
			yes.type = 'button';
			yes.textContent = confirmLabel || 'Tak';
			yes.style.background = '#b32d2e';
			yes.style.borderColor = '#b32d2e';
			cancel.addEventListener('click', function () { popupRoot.innerHTML = ''; });
			yes.addEventListener('click', function () { popupRoot.innerHTML = ''; onConfirm(); });
			row.appendChild(cancel);
			row.appendChild(yes);
			box.appendChild(p);
			box.appendChild(row);
			backdrop.appendChild(box);
			popupRoot.appendChild(backdrop);
			yes.focus();
		}

		// Właściwy adres endpointu WooCommerce AJAX (nie admin-ajax.php!) –
		// WC_AJAX::get_endpoint() sam dokłada poprawny znak zapytania.
		// Wcześniejsza, ręcznie sklejana wersja adresu psuła WSZYSTKIE
		// przyciski w tym module (404 połykane po cichu przez fetch).
		var wcAjaxTpl = <?php echo wp_json_encode( class_exists( 'WC_AJAX' ) ? WC_AJAX::get_endpoint( '__ACTION__' ) : '' ); ?>;
		function post(action, body, cb, onError) {
			var url = wcAjaxTpl.replace('__ACTION__', action);
			fetch(url, {
				method: 'POST', credentials: 'same-origin',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: body
			})
				.then(function (r) { return r.json(); })
				.then(function (r) {
					if (r && r.ok === false) { (onError || showStatusPopup)(r.message || 'Nie udało się wykonać akcji.'); return; }
					(cb || function () {})(r);
				})
				.catch(function () { (onError || showStatusPopup)('Błąd połączenia – spróbuj ponownie.'); });
		}

		// Planowanie: zapis kolejności/godziny po zmianie pola
		document.addEventListener('change', function (e) {
			var input = e.target;
			if (!(input.matches && input.matches('.kuchnia-plan-input, .kuchnia-plan-time'))) { return; }
			var tr = input.closest('tr');
			var orderId = tr.getAttribute('data-order');
			var seq = tr.querySelector('.kuchnia-plan-input').value;
			var ptime = tr.querySelector('.kuchnia-plan-time').value;
			// Lista godzin (tryb okien) zależy od wyborów innych zamówień – po zapisie
			// odświeżamy treść, żeby zajęte sloty zniknęły z pozostałych list.
			var isSelect = input.tagName === 'SELECT';
			post('kuchnia_set_planning', 'order_id=' + encodeURIComponent(orderId) + '&sequence=' + encodeURIComponent(seq) + '&planned_time=' + encodeURIComponent(ptime), function () {
				if (isSelect) { softReload(); }
			}, function (msg) { showStatusPopup(msg, true); });
		});

		// Planowanie: "Zaplanowane" – sprawdza duplikaty kolejności/godzin na
		// serwerze (świeże dane, nie to co akurat jest w polach na ekranie) i,
		// jeśli nie ma błędów, zamraża plan do edycji.
		// Przyciski wiązane wprost (istnieją tylko w niektórych zakładkach) – po podmianie treści wiążemy je od nowa.
		function bindActionButtons() {
		var planConfirmBtn = document.getElementById('kuchnia-plan-confirm');
		if (planConfirmBtn) {
			planConfirmBtn.addEventListener('click', function () {
				planConfirmBtn.disabled = true;
				post('kuchnia_confirm_planning', 'date=' + encodeURIComponent(planConfirmBtn.getAttribute('data-date')) + '&time=' + encodeURIComponent(planConfirmBtn.getAttribute('data-time')), function (r) {
					var sent = r && r.sent ? r.sent : 0;
					showStatusPopup('Plan zapisany – pola są teraz zablokowane do edycji.' + (sent ? ' Wysłano klientom maile z godziną dostawy: ' + sent + '.' : ''), true);
				}, function (msg) { planConfirmBtn.disabled = false; showStatusPopup(msg); });
			});
		}

		// Planowanie: "Edytuj" – odblokowuje plan z powrotem do edycji.
		var planEditBtn = document.getElementById('kuchnia-plan-edit');
		if (planEditBtn) {
			planEditBtn.addEventListener('click', function () {
				planEditBtn.disabled = true;
				post('kuchnia_unlock_planning', 'date=' + encodeURIComponent(planEditBtn.getAttribute('data-date')) + '&time=' + encodeURIComponent(planEditBtn.getAttribute('data-time')), function () {
					softReload();
				}, function (msg) { planEditBtn.disabled = false; showStatusPopup(msg); });
			});
		}

		// Kuchnia: "Oznacz cały termin jako Przygotowane"
		var prepAllBtn = document.getElementById('kuchnia-mark-preparing');
		if (prepAllBtn) {
			prepAllBtn.addEventListener('click', function () {
				prepAllBtn.disabled = true;
				post('kuchnia_bulk_status', 'date=' + encodeURIComponent(prepAllBtn.getAttribute('data-date')) + '&time=' + encodeURIComponent(prepAllBtn.getAttribute('data-time')) + '&status=gotowe', function (r) {
					showStatusPopup('Nadano status: ' + (r && r.label ? r.label : 'Przygotowane'), true);
				});
			});
		}

		}
		bindActionButtons();

		// ---- Nowe zamówienie: dźwięk, pogrubienie, opcjonalnie okno ----
		// Ustawienia "Okno z powiadomieniem" i "Powtarzaj dźwięk" są zapisane na tym
		// urządzeniu (to sprawa tabletu w kuchni, nie całego sklepu).
		var ALERT_POPUP_KEY = 'kuchnia_alert_popup';
		var ALERT_REPEAT_KEY = 'kuchnia_alert_repeat';
		function alertPopupOn() { return localStorage.getItem(ALERT_POPUP_KEY) === '1'; }
		function alertRepeatOn() { return localStorage.getItem(ALERT_REPEAT_KEY) === '1'; }
		function updateAlertLabels() {
			var pb = wrapEl ? wrapEl.querySelector('#kuchnia-alert-popup-toggle') : null;
			var rb = wrapEl ? wrapEl.querySelector('#kuchnia-alert-repeat-toggle') : null;
			if (pb) { pb.textContent = 'Okno z powiadomieniem: ' + (alertPopupOn() ? 'tak' : 'nie'); pb.classList.toggle('is-on', alertPopupOn()); }
			if (rb) { rb.textContent = 'Powtarzaj dźwięk: ' + (alertRepeatOn() ? 'tak' : 'nie'); rb.classList.toggle('is-on', alertRepeatOn()); rb.disabled = !alertPopupOn(); }
		}
		document.addEventListener('click', function (e) {
			var t = e.target;
			if (!t || !t.id) { return; }
			if (t.id === 'kuchnia-alert-popup-toggle') { localStorage.setItem(ALERT_POPUP_KEY, alertPopupOn() ? '0' : '1'); updateAlertLabels(); }
			else if (t.id === 'kuchnia-alert-repeat-toggle') { localStorage.setItem(ALERT_REPEAT_KEY, alertRepeatOn() ? '0' : '1'); updateAlertLabels(); }
			else if (t.id === 'kuchnia-sound-test') { beep(); }
		});

		// Dźwięk z przeglądarki (bez pliku). Przeglądarka pozwala grać dopiero po
		// pierwszym dotknięciu/kliknięciu strony – wtedy "odblokowujemy" dźwięk.
		var audioCtx = null;
		function ensureAudio() {
			try {
				if (!audioCtx) {
					var AC = window.AudioContext || window.webkitAudioContext;
					if (!AC) { return null; }
					audioCtx = new AC();
				}
				if (audioCtx.state === 'suspended') { audioCtx.resume(); }
			} catch (err) { return null; }
			return audioCtx;
		}
		function beep() {
			var ctx = ensureAudio();
			if (!ctx) { return; }
			var t0 = ctx.currentTime;
			[[880, 0], [1175, 0.2], [880, 0.4]].forEach(function (n) {
				var o = ctx.createOscillator(), g = ctx.createGain();
				o.type = 'sine';
				o.frequency.value = n[0];
				g.gain.setValueAtTime(0.0001, t0 + n[1]);
				g.gain.exponentialRampToValueAtTime(0.6, t0 + n[1] + 0.02);
				g.gain.exponentialRampToValueAtTime(0.0001, t0 + n[1] + 0.18);
				o.connect(g); g.connect(ctx.destination);
				o.start(t0 + n[1]); o.stop(t0 + n[1] + 0.2);
			});
		}

		// Blokada wygaszania ekranu, dopóki dashboard jest otwarty (Wake Lock API;
		// wymaga https; po powrocie do karty trzeba ją wziąć od nowa).
		var wakeLock = null;
		function requestWake() {
			if (wakeLock || !('wakeLock' in navigator) || document.visibilityState !== 'visible') { return; }
			navigator.wakeLock.request('screen').then(function (l) {
				wakeLock = l;
				l.addEventListener('release', function () { wakeLock = null; });
			}).catch(function () {});
		}
		if (KUCHNIA_MODE !== 'kurier') {
			requestWake();
			document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'visible') { requestWake(); } });
		}
		['pointerdown', 'touchstart', 'keydown'].forEach(function (ev) {
			document.addEventListener(ev, function () { if (KUCHNIA_MODE !== 'kurier') { ensureAudio(); requestWake(); } }, true);
		});

		// Okno "Nowe zamówienie" – zbiera kolejne, dopóki nikt nie kliknie OK;
		// przy "Powtarzaj dźwięk" gra co 5 s aż do OK.
		var pendingNew = [], repeatTimer = null;
		function fmtDate(d) { return (d && d.length === 10) ? d.slice(8, 10) + '.' + d.slice(5, 7) : ''; }
		function showNewOrderPopup() {
			popupRoot.innerHTML = '';
			var backdrop = document.createElement('div');
			backdrop.className = 'kuchnia-popup-backdrop';
			var box = document.createElement('div');
			box.className = 'kuchnia-popup';
			var p = document.createElement('p');
			p.style.whiteSpace = 'pre-line';
			p.textContent = pendingNew.map(function (o) {
				return 'Nowe zamówienie #' + o.number + (o.date ? ' · dostawa ' + fmtDate(o.date) + (o.time ? ' ' + o.time : '') : '');
			}).join('\n');
			var ok = document.createElement('button');
			ok.type = 'button';
			ok.textContent = 'OK';
			ok.addEventListener('click', function () {
				popupRoot.innerHTML = '';
				pendingNew = [];
				if (repeatTimer) { clearInterval(repeatTimer); repeatTimer = null; }
			});
			box.appendChild(p);
			box.appendChild(ok);
			backdrop.appendChild(box);
			popupRoot.appendChild(backdrop);
		}
		function onNewOrders(fresh) {
			beep();
			softReload(); // pokazuje nowe zamówienie (pogrubione) bez czekania na odświeżanie
			if (!alertPopupOn()) { return; }
			pendingNew = pendingNew.concat(fresh);
			showNewOrderPopup();
			if (alertRepeatOn() && !repeatTimer) { repeatTimer = setInterval(beep, 5000); }
		}

		// Co 20 s pytamy serwer o ostatnio zmienione zamówienia (moduł 13). Przy
		// starcie zapamiętujemy czas serwera – alarm tylko dla opłaconych później.
		var seenIds = {}, alertSince = null;
		function pollNew() {
			post('kuchnia_new_orders', '', function (r) {
				var list = (r && r.orders) ? r.orders : [];
				if (alertSince === null) { alertSince = r && r.now ? r.now : 0; }
				var fresh = list.filter(function (o) { return !seenIds[o.id] && o.ts >= alertSince; });
				list.forEach(function (o) { seenIds[o.id] = 1; });
				if (fresh.length) { onNewOrders(fresh.reverse()); }
			}, function () {}); // błąd połączenia – po cichu, spróbujemy za 20 s
		}
		if (KUCHNIA_MODE !== 'kurier') {
			pollNew();
			setInterval(pollNew, 20000);
		}

		// ---- Taśma w Zamówieniach: odliczanie i przejście po wyjeździe ----
		var cdReloading = false;
		function fmtLeft(sec) {
			if (sec >= 3600) { var h = Math.floor(sec / 3600); return h + ' h ' + Math.floor((sec % 3600) / 60) + ' min'; }
			if (sec >= 600) { return Math.floor(sec / 60) + ' min'; }
			var m = Math.floor(sec / 60), ss = Math.floor(sec % 60);
			return m + ':' + (ss < 10 ? '0' : '') + ss;
		}
		function tickCountdowns() {
			if (!wrapEl) { return; }
			var els = wrapEl.querySelectorAll('.kuchnia-cd');
			var now = Date.now() / 1000 + clockOffset;
			for (var i = 0; i < els.length; i++) {
				var el = els[i];
				var left = parseInt(el.getAttribute('data-ts'), 10) - now;
				if (left <= 0) {
					// Czas minął – odświeżamy: wyjazd znika z góry, wchodzi następny.
					if (el.getAttribute('data-reload') && !cdReloading) {
						cdReloading = true;
						setTimeout(function () { cdReloading = false; }, 8000);
						softReload();
					}
					continue;
				}
				var kind = el.getAttribute('data-kind');
				if (kind === 'silent') { continue; }
				el.textContent = (kind === 'cutoff' ? 'cutoff za ' : 'wyjazd za ') + fmtLeft(left);
				el.classList.toggle('is-soon', left < 600);
			}
		}
		setInterval(tickCountdowns, 1000);

		// ---- "Nowy termin" dla zamówienia do przeplanowania ----
		document.addEventListener('click', function (e) {
			var btn = e.target.closest ? e.target.closest('.kuchnia-resched-btn') : null;
			if (!btn) { return; }
			var orderId = btn.getAttribute('data-order');
			btn.disabled = true;
			post('kuchnia_resched_slots', 'order_id=' + encodeURIComponent(orderId), function (r) {
				btn.disabled = false;
				if (!r.dates || !r.dates.length) { showStatusPopup(r.message || 'Brak dostępnych terminów.'); return; }
				var chosen = { date: r.dates[0].date, time: '' };
				popupRoot.innerHTML = '';
				var backdrop = document.createElement('div');
				backdrop.className = 'kuchnia-popup-backdrop';
				var box = document.createElement('div');
				box.className = 'kuchnia-popup';
				var h = document.createElement('p');
				h.innerHTML = '<strong></strong>';
				h.firstChild.textContent = 'Nowy termin – zamówienie #' + r.number;
				var sel = document.createElement('select');
				sel.className = 'kuchnia-rs-dates';
				r.dates.forEach(function (d) { var o = document.createElement('option'); o.value = d.date; o.textContent = d.label; sel.appendChild(o); });
				var times = document.createElement('div');
				times.className = 'kuchnia-rs-times';
				var notify = document.createElement('label');
				notify.innerHTML = '<input type="checkbox" checked> Powiadom klienta mailem';
				var save = document.createElement('button');
				save.type = 'button'; save.textContent = 'Zapisz nowy termin'; save.disabled = true;
				var cancel = document.createElement('button');
				cancel.type = 'button'; cancel.textContent = 'Anuluj';
				cancel.addEventListener('click', function () { popupRoot.innerHTML = ''; });
				function paintTimes() {
					times.innerHTML = '';
					var d = null;
					r.dates.forEach(function (x) { if (x.date === sel.value) { d = x; } });
					chosen.date = sel.value;
					if (!d || d.times.indexOf(chosen.time) === -1) { chosen.time = ''; }
					(d ? d.times : []).forEach(function (t) {
						var b = document.createElement('button');
						b.type = 'button'; b.textContent = (d.labels && d.labels[t]) ? d.labels[t] : t;
						if (t === chosen.time) { b.className = 'is-on'; }
						b.addEventListener('click', function () { chosen.time = t; paintTimes(); });
						times.appendChild(b);
					});
					save.disabled = !chosen.time;
				}
				sel.addEventListener('change', paintTimes);
				save.addEventListener('click', function () {
					save.disabled = true;
					var body = 'order_id=' + encodeURIComponent(orderId) + '&date=' + encodeURIComponent(chosen.date) + '&time=' + encodeURIComponent(chosen.time) + '&notify=' + (notify.querySelector('input').checked ? '1' : '');
					post('kuchnia_reschedule', body, function (x) {
						showStatusPopup('Nowy termin: ' + x.label + '.' + (x.mailed ? ' Wysłano mail do klienta.' : ''), true);
					}, function (msg) { save.disabled = false; showStatusPopup(msg); });
				});
				box.appendChild(h); box.appendChild(sel); box.appendChild(times); box.appendChild(notify);
				var acts = document.createElement('div');
				acts.style.cssText = 'display:flex;gap:8px;justify-content:flex-end;margin-top:12px;';
				acts.appendChild(cancel); acts.appendChild(save);
				box.appendChild(acts);
				backdrop.appendChild(box);
				popupRoot.appendChild(backdrop);
				paintTimes();
			}, function (msg) { btn.disabled = false; showStatusPopup(msg); });
		});

		// ---- Nawigacja BEZ przeładowania strony ----
		// Przeładowanie strony kończy tryb pełnoekranowy przeglądarki (i nie da się do niego wrócić
		// bez kliknięcia). Dlatego zakładki, godziny, data i odświeżanie pobierają nową treść w tle
		// i podmieniają zawartość panelu w miejscu – pełny ekran zostaje.
		// Adres bez daty i godziny – tylko do paska adresu (patrz niżej, 2.26.20).
		var TODAY = '<?php echo esc_js( current_time( 'Y-m-d' ) ); ?>';
		var curUrl = window.location.href;
		function cleanUrl(url) {
			try {
				var u = new URL(url, window.location.href);
				u.searchParams.delete('date');
				u.searchParams.delete('time');
				return u.toString();
			} catch (err) { return url; }
		}
		function softGo(url, push) {
			if (!wrapEl) { window.location.href = url; return; }
			var scroller = isFront ? wrapEl : (document.scrollingElement || document.documentElement);
			var keep = scroller.scrollTop;
			fetch(url, { credentials: 'same-origin' })
				.then(function (r) { return r.text(); })
				.then(function (html) {
					var doc = new DOMParser().parseFromString(html, 'text/html');
					var fresh = doc.querySelector('.kuchnia-wrap');
					if (!fresh) { window.location.href = url; return; } // np. wygasła sesja/PIN – pełne wczytanie pokaże ekran logowania
					wrapEl.innerHTML = fresh.innerHTML;
					curUrl = url;
					if (push) { history.pushState({ kuchnia: 1, url: url }, '', cleanUrl(url)); }
					bindToolbar();
					bindActionButtons();
					scroller.scrollTop = push ? 0 : keep;
				})
				.catch(function () { window.location.href = url; });
		}
		function softReload() { softGo(curUrl, false); }
		bindToolbar();
		// 2.26.20: przy każdym otwarciu ekranu – bieżąca data, nie ostatnio wybrana.
		// Wybrany dzień i godzina żyją tylko w tej karcie (curUrl + history.state),
		// pasek adresu ich nie pokazuje – przywrócona karta, zakładka czy skrót
		// na ekranie telefonu otwierają dziś. Stary adres z datą (sprzed 2.26.20)
		// też przestawia się na dziś, chyba że to „Wstecz” w przeglądarce.
		(function () {
			var u = new URL(curUrl), d = u.searchParams.get('date');
			var nav = (window.performance && performance.getEntriesByType) ? performance.getEntriesByType('navigation')[0] : null;
			var back = nav && nav.type === 'back_forward';
			if (d && d !== TODAY && !back) {
				curUrl = cleanUrl(curUrl);
				history.replaceState({ kuchnia: 1, url: curUrl }, '', curUrl);
				softGo(curUrl, false);
				return;
			}
			history.replaceState({ kuchnia: 1, url: curUrl }, '', cleanUrl(curUrl));
		})();
		document.addEventListener('click', function (e) {
			var a = e.target.closest ? e.target.closest('.kuchnia-wrap a.kuchnia-tab, .kuchnia-wrap a.kuchnia-slot') : null;
			if (!a || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) { return; }
			e.preventDefault();
			softGo(a.href, true);
		});
		document.addEventListener('submit', function (e) {
			var f = e.target;
			if (!f || !f.closest || !f.closest('.kuchnia-top, .kuchnia-head')) { return; }
			e.preventDefault();
			var qs = new URLSearchParams(new FormData(f)).toString();
			softGo(f.action + (f.action.indexOf('?') > -1 ? '&' : '?') + qs, true);
		});
		window.addEventListener('popstate', function (e) {
			softGo((e.state && e.state.url) ? e.state.url : window.location.href, false);
		});

		// Zamówienia: "Dni wstecz" i "Auto przygotowanie" – wspólne ustawienia na serwerze (moduł 13).
		document.addEventListener('change', function (e) {
			var input = e.target;
			if (!input || input.id !== 'kuchnia-days-back') { return; }
			var n = Math.max(0, Math.min(60, parseInt(input.value, 10) || 0));
			post('kuchnia_save_settings', 'days_back=' + n, function () { softReload(); });
		});
		document.addEventListener('click', function (e) {
			var btn = e.target.closest ? e.target.closest('#kuchnia-autoprep-toggle') : null;
			if (!btn) { return; }
			btn.disabled = true;
			var turnOn = btn.getAttribute('data-on') !== '1';
			post('kuchnia_save_settings', 'auto_prep=' + (turnOn ? '1' : '0'), function () { softReload(); }, function (msg) { btn.disabled = false; showStatusPopup(msg); });
		});

		// Pakowanie: "Przygotowane" dla jednego zamówienia (szary przy Auto przygotowaniu = opcjonalny).
		document.addEventListener('click', function (e) {
			var btn = e.target.closest ? e.target.closest('.kuchnia-prep-btn') : null;
			if (!btn) { return; }
			btn.disabled = true;
			post('kuchnia_set_status', 'order_id=' + encodeURIComponent(btn.getAttribute('data-order')) + '&status=gotowe', function (r) {
				showStatusPopup('Nadano status: ' + (r && r.label ? r.label : 'Przygotowane'), true);
			}, function (msg) { btn.disabled = false; showStatusPopup(msg); });
		});

		// Pakowanie: "Spakowane"
		document.addEventListener('click', function (e) {
			var btn = e.target.closest ? e.target.closest('.kuchnia-pack-btn') : null;
			if (!btn) { return; }
			btn.disabled = true;
			post('kuchnia_set_status', 'order_id=' + encodeURIComponent(btn.getAttribute('data-order')) + '&status=w-dostawie', function (r) {
				showStatusPopup('Nadano status: ' + (r && r.label ? r.label : 'Spakowane'), true);
			}, function (msg) { btn.disabled = false; showStatusPopup(msg); });
		});

		// Kurier: "Dostarczone"
		document.addEventListener('click', function (e) {
			var btn = e.target.closest ? e.target.closest('.kuchnia-deliver-btn') : null;
			if (!btn) { return; }
			btn.disabled = true;
			post('kuchnia_set_status', 'order_id=' + encodeURIComponent(btn.getAttribute('data-order')) + '&status=wydane', function (r) {
				showStatusPopup('Nadano status: ' + (r && r.label ? r.label : 'Dostarczone'), true);
			}, function (msg) { btn.disabled = false; showStatusPopup(msg); });
		});

		// Zamówienia: "Anuluj" z potwierdzeniem (popup, nie natywny confirm())
		document.addEventListener('click', function (e) {
			var btn = e.target.closest ? e.target.closest('.kuchnia-cancel-btn') : null;
			if (!btn) { return; }
			showConfirmPopup(
				'Na pewno anulować to zamówienie? Tej operacji nie można cofnąć – jeśli klient już zapłacił, zwrot trzeba obsłużyć osobno, zgodnie z polityką zwrotów.',
				'Tak, anuluj',
				function () {
					btn.disabled = true;
					post('kuchnia_cancel_order', 'order_id=' + encodeURIComponent(btn.getAttribute('data-order')), function () {
						showStatusPopup('Zamówienie zostało anulowane.', true);
					}, function (msg) { btn.disabled = false; showStatusPopup(msg); });
				}
			);
		});

		// Pakowanie: rozwijanie szczegółów spakowanego zamówienia
		document.addEventListener('click', function (e) {
			var box = e.target.closest ? e.target.closest('.kuchnia-packed-box') : null;
			if (!box) { return; }
			var target = document.getElementById(box.getAttribute('data-toggle'));
			if (target) { target.classList.toggle('is-open'); }
		});
	})();
	</script>
	<?php
}

/* ============================================================
 * 4. PANEL ADMINA – cienki wrapper wokół wspólnego dashboardu
 * ============================================================ */
function kuchnia_render_page() {
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		return;
	}
	echo '<div class="wrap">';
	kuchnia_render_dashboard( admin_url( 'admin.php?page=rzd-kuchnia' ) );
	kuchnia_render_pin_settings();
	echo '</div>';
}

/* Ustawienie PIN-u dostępu do wersji front-endowej – tuż pod dashboardem w panelu. */
function kuchnia_render_pin_settings() {
	$pin = get_option( 'kuchnia_pin', '' );
	?>
	<hr style="margin:30px 0;">
	<h2>Dostęp do widoku na stronie (dla tabletu w kuchni)</h2>
	<p class="description">
		Ten sam dashboard możesz wyświetlić na zwykłej stronie internetowej (bez logowania się do panelu WordPressa)
		shortcodem <code>[kuchnia_dashboard]</code>, wstawionym na osobnej, nigdzie nie podlinkowanej stronie/podstronie.
		Taka strona wymaga podania PIN-u poniżej – ustaw go, żeby dostęp miały tylko osoby, którym go podasz.
		Strona nie jest widoczna w wyszukiwarkach (dodajemy do niej znacznik "noindex").
	</p>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="kuchnia_save_pin">
		<?php wp_nonce_field( 'kuchnia_save_pin' ); ?>
		<p><label>PIN kuchni (<code>[kuchnia_dashboard]</code>, otwiera też stronę kuriera):<br>
		<input type="text" name="kuchnia_pin" value="<?php echo esc_attr( $pin ); ?>" placeholder="np. 4218" style="width:120px;"></label></p>
		<p><label>PIN kuriera (<code>[kurier_dashboard]</code>, tylko widok kuriera):<br>
		<input type="text" name="kurier_pin" value="<?php echo esc_attr( get_option( 'kurier_pin', '' ) ); ?>" placeholder="np. 7351" style="width:120px;"></label></p>
		<p class="description">Kurier ma osobną stronę: wstaw shortcode <code>[kurier_dashboard]</code> na nową, niepodlinkowaną stronę i daj kurierowi jej adres. PIN-y muszą być różne.</p>
		<button type="submit" class="button button-primary">Zapisz PIN-y</button>
		<?php if ( ! empty( $_GET['pin_same'] ) ) : ?>
			<span style="color:#b32d2e;margin-left:10px;">PIN kuriera nie może być taki sam jak PIN kuchni – nie zapisano go.</span>
		<?php elseif ( isset( $_GET['pin_saved'] ) ) : ?>
			<span style="color:#008a20;margin-left:10px;">Zapisano.</span>
		<?php endif; ?>
	</form>
	<?php
}

add_action( 'admin_post_kuchnia_save_pin', function () {
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		wp_die( 'Brak uprawnień.' );
	}
	check_admin_referer( 'kuchnia_save_pin' );
	$pin = isset( $_POST['kuchnia_pin'] ) ? preg_replace( '/[^0-9A-Za-z]/', '', $_POST['kuchnia_pin'] ) : '';
	update_option( 'kuchnia_pin', $pin, false );
	$kpin = isset( $_POST['kurier_pin'] ) ? preg_replace( '/[^0-9A-Za-z]/', '', $_POST['kurier_pin'] ) : '';
	$same = ( $kpin && $kpin === $pin );
	if ( $same ) {
		$kpin = ''; // ten sam PIN otwierałby kuchnię – kurier musi mieć własny
	}
	update_option( 'kurier_pin', $kpin, false );
	wp_safe_redirect( add_query_arg( array( 'page' => 'rzd-kuchnia', 'pin_saved' => 1, 'pin_same' => $same ? 1 : 0 ), admin_url( 'admin.php' ) ) );
	exit;
} );

/* ============================================================
 * 5. WERSJA FRONT-ENDOWA: shortcode [kuchnia_dashboard] + bramka PIN-em
 * ============================================================ */
function kuchnia_frontend_authed() {
	if ( current_user_can( 'manage_woocommerce' ) ) {
		return true; // zalogowany admin/menedżer – nie musi wpisywać PIN-u
	}
	$pin = get_option( 'kuchnia_pin', '' );
	if ( ! $pin ) {
		return false; // PIN nie ustawiony – front-end jest zablokowany dla bezpieczeństwa
	}
	return isset( $_COOKIE['rzd_kuchnia_auth'] ) && hash_equals( wp_hash( 'kuchnia_pin_' . $pin ), $_COOKIE['rzd_kuchnia_auth'] );
}

// Sprawdzenie/zapis PIN-u MUSI się odbyć zanim WordPress zacznie wysyłać treść
// strony (inaczej ustawienie ciasteczka może się nie udać) – stąd hook "init",
// nie środek renderowania shortcode'u.
add_action( 'init', function () {
	if ( ! isset( $_POST['kuchnia_pin_try'] ) ) {
		return;
	}
	$pin = get_option( 'kuchnia_pin', '' );
	$try = sanitize_text_field( wp_unslash( $_POST['kuchnia_pin_try'] ) );
	if ( $pin && hash_equals( (string) $pin, $try ) ) {
		setcookie( 'rzd_kuchnia_auth', wp_hash( 'kuchnia_pin_' . $pin ), time() + 30 * DAY_IN_SECONDS, COOKIEPATH ?: '/', COOKIE_DOMAIN, is_ssl(), true );
	} else {
		$GLOBALS['kuchnia_pin_error'] = true;
	}
} );

// Strona z tym shortcode'em nie powinna trafiać do wyszukiwarek ani do sitemap.
add_action( 'wp_head', function () {
	global $post;
	if ( $post && has_shortcode( $post->post_content, 'kuchnia_dashboard' ) ) {
		echo '<meta name="robots" content="noindex,nofollow">' . "\n";
	}
} );

add_shortcode( 'kuchnia_dashboard', function () {
	if ( ! kuchnia_frontend_authed() ) {
		ob_start();
		?>
		<div style="max-width:320px;margin:60px auto;padding:24px;border:2px solid #222;border-radius:12px;font-family:sans-serif;text-align:center;">
			<h2 style="margin-top:0;">Kuchnia</h2>
			<?php if ( ! empty( $GLOBALS['kuchnia_pin_error'] ) ) : ?>
				<p style="color:#b32d2e;">Błędny PIN, spróbuj ponownie.</p>
			<?php endif; ?>
			<form method="post">
				<input type="password" inputmode="numeric" name="kuchnia_pin_try" placeholder="PIN" style="font-size:20px;padding:10px;width:100%;box-sizing:border-box;text-align:center;letter-spacing:4px;">
				<button type="submit" style="margin-top:12px;padding:10px 20px;font-size:16px;background:#222;color:#fff;border:0;border-radius:8px;cursor:pointer;">Wejdź</button>
			</form>
		</div>
		<?php
		return ob_get_clean();
	}

	ob_start();
	kuchnia_render_dashboard( get_permalink() );
	return ob_get_clean();
} );
