<?php
/**
 * MODUŁ 00: Wspólne funkcje pomocnicze (wczytywany pierwszy).
 *
 * Funkcje, które były skopiowane w kilku modułach z identyczną treścią.
 * Dawne nazwy (dc_clean_time, rwz_clean_time, kuchnia_statuses, rr_statuses_default)
 * zostają jako przekierowania – jedna nazwa w całej wtyczce to krok 5 porządków.
 */

// Godzina „HH:MM” (00:00–23:59) albo '' – z formularzy i zapytań.
function rzd_clean_time( $t ) {
	$t = sanitize_text_field( (string) $t );
	return preg_match( '/^([01]\d|2[0-3]):[0-5]\d$/', $t ) ? $t : '';
}

/**
 * Statusy zamówień „do realizacji”: przyjęte, zrealizowane, wstrzymane + własne statusy
 * Kuchni (moduł 13). Bez anulowanych i nieopłaconych. Używają: Kuchnia, raporty,
 * zajętość terminów, dashboard.
 * 'wc-on-hold' jest tu potrzebne m.in. dla „płatność przy odbiorze” – w zależności od
 * konfiguracji WooCommerce zamówienie z tą metodą może wylądować właśnie w tym statusie.
 */
function rzd_order_statuses_active() {
	$s = array( 'wc-processing', 'wc-completed', 'wc-on-hold' );
	if ( function_exists( 'rzd_kitchen_statuses' ) ) {
		foreach ( array_keys( rzd_kitchen_statuses() ) as $slug ) {
			$s[] = 'wc-' . $slug;
		}
	}
	return $s;
}
