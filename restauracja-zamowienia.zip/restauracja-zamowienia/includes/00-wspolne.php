<?php
/**
 * MODUŁ 00: Wspólne funkcje pomocnicze (wczytywany pierwszy).
 *
 * Funkcje, które były skopiowane w kilku modułach z identyczną treścią.
 * Dawne nazwy (dc_clean_time, rwz_clean_time, kuchnia_statuses, rr_statuses_default)
 * przekierowuje 99-stare-nazwy.php.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Godzina „HH:MM” (00:00–23:59) albo '' – z formularzy i zapytań.
function rzd_clean_time( $t ) {
	$t = sanitize_text_field( (string) $t );
	return preg_match( '/^([01]\d|2[0-3]):[0-5]\d$/', $t ) ? $t : '';
}

/**
 * Statusy zamówień „do realizacji”: przyjęte, zrealizowane, wstrzymane + własne statusy
 * Kuchni (moduł 13). Bez anulowanych i nieopłaconych. Używają: Kuchnia, raporty,
 * zajętość terminów, dashboard.
 * 'wc-on-hold' jest tu potrzebne m.in. dla „płatność przy odbiorze” – w zależności od
 * konfiguracji WooCommerce zamówienie z tą metodą może wylądować właśnie w tym statusie.
 */
function rzd_order_statuses_active() {
	$s = array( 'wc-processing', 'wc-completed', 'wc-on-hold' );
	if ( function_exists( 'rzd_kitchen_statuses' ) ) {
		foreach ( array_keys( rzd_kitchen_statuses() ) as $slug ) {
			$s[] = 'wc-' . $slug;
		}
	}
	return $s;
}

/**
 * Bieżący produkt na stronie produktu – zawsze obiekt WC_Product albo null.
 * Globalne $product bywa NAPISEM (np. szablony blokowe WooCommerce / Store API ustawiają
 * je na slug w trakcie składania strony) – wtedy produkt bierzemy z bieżącego wpisu.
 * Zwraca kopię do zmiennej lokalnej – globalnego $product nie zmieniamy.
 */
function rzd_current_product() {
	global $product;
	if ( $product instanceof WC_Product ) {
		return $product;
	}
	$id = get_the_ID();
	if ( $id && 'product' === get_post_type( $id ) && function_exists( 'wc_get_product' ) ) {
		$p = wc_get_product( $id );
		return $p instanceof WC_Product ? $p : null;
	}
	return null;
}

/**
 * Czy żądanie przyszło z TEJ strony (obrona przed CSRF dla akcji sklepu, także gości).
 * Nonce WordPressa dla niezalogowanych jest wspólny dla wszystkich gości, więc sam nie wystarcza.
 * Przeglądarka przy żądaniu z innej strony zawsze wysyła nagłówek Origin (strona nie może go podrobić);
 * gdy go nie ma – Referer. Brak obu (stare narzędzia, nie przeglądarka) = przepuszczamy, decyduje nonce.
 */
function rzd_request_same_origin() {
	$src = isset( $_SERVER['HTTP_ORIGIN'] ) ? (string) $_SERVER['HTTP_ORIGIN'] : ( isset( $_SERVER['HTTP_REFERER'] ) ? (string) $_SERVER['HTTP_REFERER'] : '' ); // phpcs:ignore
	if ( '' === $src ) {
		return true;
	}
	$host = strtolower( (string) wp_parse_url( $src, PHP_URL_HOST ) );
	$ok   = array_map( 'strtolower', array_filter( array( wp_parse_url( home_url(), PHP_URL_HOST ), wp_parse_url( site_url(), PHP_URL_HOST ) ) ) );
	return '' !== $host && in_array( $host, $ok, true );
}

/**
 * Wpis do dziennika WooCommerce (WooCommerce → Status → Logi, źródło „restauracja…”).
 * Poziomy jak w WooCommerce: debug, info, notice, warning, error, critical.
 */
function rzd_log( $level, $message, $source = 'restauracja' ) {
	if ( function_exists( 'wc_get_logger' ) ) {
		wc_get_logger()->log( $level, (string) $message, array( 'source' => $source ) );
	} else {
		error_log( '[' . $source . '] ' . $level . ': ' . $message ); // phpcs:ignore
	}
}
