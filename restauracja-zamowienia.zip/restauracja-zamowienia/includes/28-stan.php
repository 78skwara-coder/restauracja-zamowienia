<?php
/**
 * MODUŁ 28: Stan wtyczki – samotest, błędy krytyczne, alarmy (Restauracja → Stan i poczta).
 *
 * - Błąd krytyczny w pliku wtyczki zapisuje plik główny (rzd_record_fatal) → tu: komunikat w panelu
 *   i mail do administratora.
 * - Samotest raz na dobę (Action Scheduler – kolejka zadań WooCommerce): wtyczka otwiera w tle listę,
 *   produkt, zestaw, koszyk, kasę i Kuchnię i sprawdza, czy odpowiadają bez błędu. Łapie np. problem
 *   po nocnej aktualizacji WooCommerce, zanim trafi na niego klient. Można też uruchomić ręcznie.
 * - Alarm: mail do administratora (adres z Ustawienia → Ogólne) najwyżej raz na dobę na ten sam
 *   problem + czerwony komunikat w panelu. Wszystko też w dzienniku WooCommerce (źródło „restauracja”).
 * WordPress sam wysyła mail przy błędzie krytycznym (tryb odzyskiwania) – to uzupełnienie: samotest,
 * historia w panelu, jeden dziennik.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 1. ALARM (mail + komunikat)
 * ============================================================ */
function rzd_health_alert( $subject, $body ) {
	$key = 'rzd_alert_' . md5( $subject );
	rzd_log( 'error', $subject . ' – ' . wp_strip_all_tags( $body ) );
	if ( get_transient( $key ) ) {
		return false; // ten sam problem – mail już poszedł w ciągu doby
	}
	set_transient( $key, 1, DAY_IN_SECONDS );
	$site = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
	return wp_mail(
		get_option( 'admin_email' ),
		'[' . $site . '] Restauracja: ' . $subject,
		$body . "\n\nSzczegóły: " . admin_url( 'admin.php?page=rzd-stan' ) . "\nDziennik: " . admin_url( 'admin.php?page=wc-status&tab=logs&source=restauracja' ) . "\n\n(Ten sam problem zgłaszamy najwyżej raz na dobę.)"
	);
}

// Błąd krytyczny zapisany przez plik główny – mail przy następnym wywołaniu (po błędzie strona nie działała).
add_action( 'init', function () {
	$f = get_option( 'rzd_health_fatal' );
	if ( is_array( $f ) && empty( $f['alerted'] ) ) {
		$f['alerted'] = time();
		update_option( 'rzd_health_fatal', $f, false );
		rzd_health_alert( 'błąd krytyczny wtyczki', 'Wtyczka zgłosiła błąd krytyczny ' . wp_date( 'j.m.Y H:i', (int) $f['time'] ) . ":\n" . $f['msg'] . "\nPlik: " . $f['file'] . ':' . $f['line'] . "\nAdres: " . $f['url'] );
	}
}, 99 );

/* ============================================================
 * 2. SAMOTEST
 * ============================================================ */
function rzd_selftest_targets() {
	$t    = array();
	$list = rzd_page_url_opt( 'rzd_list_page_id', 'lista_zamowien' );
	if ( $list ) {
		$t['Lista zamówień'] = $list;
	}
	$q = function ( $compare ) {
		return get_posts( array( 'post_type' => 'product', 'post_status' => 'publish', 'numberposts' => 1, 'fields' => 'ids', 'has_password' => false, 'meta_query' => array( array( 'key' => '_rwz_slots', 'compare' => $compare ) ) ) ); // phpcs:ignore
	};
	$p = $q( 'NOT EXISTS' );
	if ( $p ) {
		$t['Strona produktu'] = get_permalink( $p[0] );
	}
	$z = $q( 'EXISTS' );
	if ( $z ) {
		$t['Zestaw dnia'] = get_permalink( $z[0] );
	}
	$t['Koszyk'] = wc_get_cart_url();
	$t['Kasa']   = wc_get_checkout_url();
	if ( function_exists( 'rzd_kitchen_page_url' ) && rzd_kitchen_page_url() ) {
		$t['Kuchnia'] = rzd_kitchen_page_url();
	}
	return apply_filters( 'rzd_selftest_targets', $t );
}

// Strona „działa”: odpowiedź poniżej 500 i bez komunikatu o błędzie krytycznym PHP / WordPressa.
function rzd_selftest_check_body( $code, $body ) {
	if ( $code >= 500 ) {
		return 'błąd serwera (HTTP ' . $code . ')';
	}
	foreach ( array( 'Fatal error', 'Parse error', 'W witrynie wystąpił błąd krytyczny', 'critical error on this website', 'Uncaught Error', 'Uncaught Exception' ) as $m ) {
		if ( false !== stripos( (string) $body, $m ) ) {
			return 'błąd na stronie („' . $m . '”)';
		}
	}
	return '';
}

function rzd_selftest_run( $manual = false ) {
	$res  = array();
	$bad  = array();
	$conn = 0;
	foreach ( rzd_selftest_targets() as $label => $url ) {
		$r = wp_remote_get( $url, array(
			'timeout'     => 20,
			'redirection' => 5,
			'sslverify'   => apply_filters( 'https_local_ssl_verify', false ), // jak test „połączenie zwrotne” w Zdrowiu witryny
			'headers'     => array( 'Cache-Control' => 'no-cache' ),
			'user-agent'  => 'Restauracja-Samotest/' . RZD_PLUGIN_VERSION,
		) );
		if ( is_wp_error( $r ) ) {
			$res[ $label ] = array( 'url' => $url, 'code' => 0, 'err' => 'brak połączenia: ' . $r->get_error_message() );
			$conn++;
			continue;
		}
		$code          = (int) wp_remote_retrieve_response_code( $r );
		$err           = rzd_selftest_check_body( $code, wp_remote_retrieve_body( $r ) );
		$res[ $label ] = array( 'url' => $url, 'code' => $code, 'err' => $err );
		if ( $err ) {
			$bad[] = $label . ': ' . $err;
		}
	}
	$all_conn = $res && count( $res ) === $conn; // serwer nie łączy się sam ze sobą (zablokowane połączenie zwrotne)
	$state    = array( 'time' => time(), 'manual' => (bool) $manual, 'results' => $res, 'ok' => ! $bad && ! $all_conn, 'loopback' => ! $all_conn );
	update_option( 'rzd_health_selftest', $state, false );
	if ( $bad ) {
		rzd_health_alert( 'samotest wykrył błąd', "Codzienny samotest wtyczki znalazł problem:\n- " . implode( "\n- ", $bad ) );
	} elseif ( $all_conn ) {
		rzd_log( 'warning', 'Samotest: serwer nie może połączyć się sam ze sobą (połączenie zwrotne) – samotest nie działa na tym hostingu.' );
	} else {
		rzd_log( 'info', 'Samotest: ' . count( $res ) . ' stron bez błędów.' );
	}
	return $state;
}

// Raz na dobę o 5:30 (czas sklepu) – przed porannymi zamówieniami.
add_action( 'rzd_selftest', function () {
	rzd_selftest_run( false );
} );
add_action( 'action_scheduler_init', function () {
	// Filtr rzd_selftest_schedule = false wyłącza codzienny samotest (np. hosting bez połączeń zwrotnych).
	if ( ! function_exists( 'as_next_scheduled_action' ) || ! apply_filters( 'rzd_selftest_schedule', true ) || false !== as_next_scheduled_action( 'rzd_selftest', array(), 'restauracja' ) ) {
		return;
	}
	try {
		$first = new DateTime( 'tomorrow 05:30', wp_timezone() );
		as_schedule_recurring_action( $first->getTimestamp(), DAY_IN_SECONDS, 'rzd_selftest', array(), 'restauracja' );
	} catch ( Exception $e ) {
		rzd_log( 'warning', 'Nie udało się zaplanować samotestu: ' . $e->getMessage() );
	}
} );
register_deactivation_hook( RZD_PLUGIN_FILE, function () {
	if ( function_exists( 'as_unschedule_all_actions' ) ) {
		as_unschedule_all_actions( 'rzd_selftest', array(), 'restauracja' );
	}
} );

add_action( 'admin_post_rzd_selftest_now', function () {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Brak uprawnień.' );
	}
	check_admin_referer( 'rzd_selftest_now' );
	rzd_selftest_run( true );
	wp_safe_redirect( admin_url( 'admin.php?page=rzd-stan&rzd_msg=selftest' ) );
	exit;
} );

add_action( 'admin_post_rzd_health_dismiss', function () {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Brak uprawnień.' );
	}
	check_admin_referer( 'rzd_health_dismiss' );
	delete_option( 'rzd_health_fatal' );
	delete_option( 'rzd_mail_last_error' );
	$st = get_option( 'rzd_health_selftest' );
	if ( is_array( $st ) ) {
		$st['dismissed'] = time();
		update_option( 'rzd_health_selftest', $st, false );
	}
	wp_safe_redirect( admin_url( 'admin.php?page=rzd-stan' ) );
	exit;
} );

/* ============================================================
 * 3. KOMUNIKAT W PANELU (administrator)
 * ============================================================ */
function rzd_health_problems() {
	$out = array();
	$f   = get_option( 'rzd_health_fatal' );
	if ( is_array( $f ) && (int) $f['time'] > time() - 7 * DAY_IN_SECONDS ) {
		$out[] = 'błąd krytyczny ' . wp_date( 'j.m H:i', (int) $f['time'] ) . ' (' . $f['file'] . ')';
	}
	$st = get_option( 'rzd_health_selftest' );
	if ( is_array( $st ) && empty( $st['ok'] ) && ! empty( $st['loopback'] ) && empty( $st['dismissed'] ) ) {
		$out[] = 'samotest ' . wp_date( 'j.m H:i', (int) $st['time'] ) . ' znalazł błąd';
	}
	$m = get_option( 'rzd_mail_last_error' );
	if ( is_array( $m ) ) {
		$out[] = 'mail nie wyszedł ' . wp_date( 'j.m H:i', (int) $m['time'] ) . ': ' . $m['msg'];
	}
	return $out;
}
add_action( 'admin_notices', function () {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$p = rzd_health_problems();
	if ( ! $p ) {
		return;
	}
	echo '<div class="notice notice-error"><p><strong>Restauracja:</strong> ' . esc_html( implode( ' · ', $p ) ) . ' – <a href="' . esc_url( admin_url( 'admin.php?page=rzd-stan' ) ) . '">Stan i poczta</a></p></div>';
} );

/* ============================================================
 * 4. STRONA: Restauracja → Stan i poczta
 * ============================================================ */
function rzd_stan_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$msg = isset( $_GET['rzd_msg'] ) ? sanitize_key( wp_unslash( $_GET['rzd_msg'] ) ) : ''; // phpcs:ignore -- tylko komunikat
	$st  = get_option( 'rzd_health_selftest' );
	$f   = get_option( 'rzd_health_fatal' );
	$hpos = class_exists( '\Automattic\WooCommerce\Utilities\OrderUtil' ) && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();
	$next = function_exists( 'as_next_scheduled_action' ) ? as_next_scheduled_action( 'rzd_selftest', array(), 'restauracja' ) : false;
	?>
	<div class="wrap">
		<h1>Stan i poczta</h1>
		<?php if ( 'mail_saved' === $msg ) : ?><div class="notice notice-success is-dismissible"><p>Zapisano ustawienia poczty.</p></div><?php endif; ?>
		<?php if ( 'selftest' === $msg ) : ?><div class="notice notice-info is-dismissible"><p>Samotest wykonany – wynik poniżej.</p></div><?php endif; ?>

		<h2>Stan wtyczki</h2>
		<table class="widefat striped" style="max-width:900px">
			<tbody>
				<tr><td style="width:240px">Wersja</td><td><?php echo esc_html( RZD_PLUGIN_VERSION ); ?> · WooCommerce <?php echo esc_html( defined( 'WC_VERSION' ) ? WC_VERSION : '?' ); ?> · PHP <?php echo esc_html( PHP_VERSION ); ?></td></tr>
				<tr><td>Zapis zamówień</td><td><?php echo $hpos ? 'HPOS (nowy, zalecany) ✅' : '⚠️ stary (wpisy) – Kuchnia i raporty mogą nie filtrować daty; włącz HPOS: WooCommerce → Ustawienia → Zaawansowane → Funkcje'; ?></td></tr>
				<tr><td>Ostatni błąd krytyczny</td><td><?php echo is_array( $f ) ? '<span style="color:#b32d2e">' . esc_html( wp_date( 'j.m.Y H:i', (int) $f['time'] ) . ' – ' . $f['msg'] . ' (' . $f['file'] . ':' . $f['line'] . ')' ) . '</span>' : 'brak ✅'; ?></td></tr>
				<tr><td>Samotest</td><td>
					<?php if ( is_array( $st ) ) : ?>
						<?php echo esc_html( wp_date( 'j.m.Y H:i', (int) $st['time'] ) . ( ! empty( $st['manual'] ) ? ' (ręcznie)' : '' ) ); ?> –
						<?php echo ! empty( $st['ok'] ) ? 'bez błędów ✅' : ( empty( $st['loopback'] ) ? '⚠️ serwer nie łączy się sam ze sobą – na tym hostingu samotest nie zadziała (zapytaj hosting o „loopback”)' : '<strong style="color:#b32d2e">znaleziono błąd</strong>' ); // phpcs:ignore ?>
						<ul style="margin:6px 0 0 18px;list-style:disc">
							<?php foreach ( (array) $st['results'] as $label => $r ) : ?>
								<li><?php echo esc_html( $label ); ?>: <?php echo $r['err'] ? '<span style="color:#b32d2e">' . esc_html( $r['err'] ) . '</span>' : 'OK (HTTP ' . (int) $r['code'] . ')'; // phpcs:ignore ?></li>
							<?php endforeach; ?>
						</ul>
					<?php else : ?>
						jeszcze nie było
					<?php endif; ?>
					<p class="description">Następny automatyczny: <?php echo $next ? esc_html( wp_date( 'j.m.Y H:i', (int) $next ) ) : 'nie zaplanowano'; ?> (codziennie 5:30).</p>
				</td></tr>
				<?php if ( function_exists( 'rzd_co_legal_pages' ) ) : $lp = rzd_co_legal_pages(); ?>
				<tr><td>Regulamin i polityka prywatności</td><td><?php echo ( $lp['terms'] && $lp['privacy'] ) ? 'ustawione ✅ (pole zgody w kasie działa)' : '<strong style="color:#b32d2e">⚠️ brak ' . esc_html( implode( ' i ', array_filter( array( $lp['terms'] ? '' : 'strony regulaminu', $lp['privacy'] ? '' : 'polityki prywatności' ) ) ) ) . '</strong> – bez tego kasa nie pokaże pola zgody wymaganego m.in. przez Przelewy24. <a href="' . esc_url( admin_url( 'admin.php?page=rzd-formularz' ) ) . '">Formularz zamówienia</a>'; // phpcs:ignore ?></td></tr>
				<?php endif; ?>
				<tr><td>Dziennik</td><td><a href="<?php echo esc_url( admin_url( 'admin.php?page=wc-status&tab=logs&source=restauracja' ) ); ?>">WooCommerce → Status → Logi (restauracja)</a></td></tr>
			</tbody>
		</table>
		<p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
				<input type="hidden" name="action" value="rzd_selftest_now"><?php wp_nonce_field( 'rzd_selftest_now' ); ?>
				<button type="submit" class="button button-primary">Uruchom samotest teraz</button>
			</form>
			<?php if ( rzd_health_problems() ) : ?>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
					<input type="hidden" name="action" value="rzd_health_dismiss"><?php wp_nonce_field( 'rzd_health_dismiss' ); ?>
					<button type="submit" class="button">Problem rozwiązany – ukryj komunikat</button>
				</form>
			<?php endif; ?>
		</p>
		<hr>
		<?php rzd_mail_section_html(); ?>
	</div>
	<?php
}
