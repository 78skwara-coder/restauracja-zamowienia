<?php
/**
 * Moduł 42-api-strony – spis wszystkich shortcodów wtyczki (Panel restauracji → Shortcody i API). Tylko informacja.
 * Przy nowym shortcodzie we wtyczce – dopisz go tutaj. Każdy: tag, nazwa, gdzie, opis, atrybuty [ nazwa, wartości,
 * domyślnie, opis ], przykłady, grupa (sklep | strona | obsluga).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function rzd_shortcodes_catalog() {
	$styles = function_exists( 'rzd_kf_styles' ) ? implode( ', ', array_keys( rzd_kf_styles() ) ) : 'klasyczny, karta, minimalny, ciemny';
	$list   = array(
		/* ---------- sklep ---------- */
		array( 'tag' => 'lista_zamowien', 'g' => 'sklep', 'n' => 'Lista dań do zamawiania', 'where' => 'Strona „Zamów” (i strony kategorii)',
			'd' => 'Dania z cenami, alergenami, modyfikacjami i przyciskiem „Dodaj”. Pasek z terminem dostawy pojawia się nad pierwszą listą na stronie.',
			'a' => array(
				array( 'kategoria', 'nazwa albo adres kategorii; kilka po przecinku', 'wszystkie', 'Tylko dania z tych kategorii.' ),
				array( 'limit', 'liczba', 'bez limitu', 'Ile dań najwyżej.' ),
				array( 'pasek', 'tak / nie', 'nie', 'Pasek z terminem dostawy nad listą (zwykle pokazuje go sama strona).' ),
			),
			'ex' => array( '[lista_zamowien]', '[lista_zamowien kategoria="Zupy,Dania główne"]' ) ),
		array( 'tag' => 'kategorie_zamowien', 'g' => 'sklep', 'n' => 'Kafle kategorii', 'where' => 'Strona główna sklepu / „Kategorie”',
			'd' => 'Kafle kategorii ze zdjęciem; każda prowadzi pod adres ustawiony przy kategorii. Wygląd – Panel → Wygląd.',
			'a' => array( array( 'kategoria', 'nazwy kategorii po przecinku', 'wszystkie z daniami', 'Tylko wskazane, w podanej kolejności.' ) ),
			'ex' => array( '[kategorie_zamowien]', '[kategorie_zamowien kategoria="Bajgle,Zupy"]' ) ),
		array( 'tag' => 'koszyk', 'g' => 'sklep', 'n' => 'Koszyk w menu', 'where' => 'Menu / nagłówek',
			'd' => 'Ikona koszyka z liczbą i wartością (wygląd – Panel → Sklep). Pływający koszyk włącza się w ustawieniach, bez shortcodu.',
			'a' => array(), 'ex' => array( '[koszyk]' ) ),
		array( 'tag' => 'dc_termin', 'g' => 'sklep', 'n' => 'Pasek terminu', 'where' => 'Dowolna strona sklepu',
			'd' => 'Wybrany termin dostawy / odbioru z przyciskiem „Zmień termin”.', 'a' => array(), 'ex' => array( '[dc_termin]' ) ),
		array( 'tag' => 'wybierz_date_dostawy', 'g' => 'sklep', 'n' => 'Przycisk „Wybierz datę dostawy”', 'where' => 'Dowolna strona sklepu',
			'd' => 'Otwiera okienko wyboru terminu.', 'a' => array( array( 'tekst', 'napis', 'Wybierz datę dostawy', 'Napis na przycisku.' ) ),
			'ex' => array( '[wybierz_date_dostawy tekst="Ustaw dostawę"]' ) ),
		array( 'tag' => 'koszty_dostawy', 'g' => 'sklep', 'n' => 'Tabela kosztów dostawy', 'where' => 'Strona „Dostawa” / FAQ',
			'd' => 'Miejscowości z kosztem dostawy, minimalnym zamówieniem, darmową dostawą od i dniami / godzinami (z Panel → Miejscowości).',
			'a' => array(), 'ex' => array( '[koszty_dostawy]' ) ),
		/* ---------- strona restauracji ---------- */
		array( 'tag' => 'rzd_zestaw', 'g' => 'strona', 'n' => 'Zestaw ze składem na dzień', 'where' => 'Strona główna, „Obiad dnia”',
			'd' => 'Zdjęcie, nazwa, dzień, skład (rola i danie), cena i przycisk do sklepu. Bez „dzien” – pierwszy dzień dostawy, jak w sklepie.',
			'a' => array(
				array( 'id', 'numer zestawu (ID produktu)', 'pierwszy zestaw', 'Który zestaw. ID widać w Edycji menu i w adresie edycji produktu.' ),
				array( 'dzien', 'RRRR-MM-DD', 'pierwszy dzień dostawy', 'Skład na konkretny dzień.' ),
				array( 'zdjecie', 'tak / nie', 'tak', '' ), array( 'sklad', 'tak / nie', 'tak', '' ), array( 'cena', 'tak / nie', 'tak', '' ),
				array( 'przycisk', 'napis; pusty = bez przycisku', rzd_site_api_settings()['btn'], 'Przycisk prowadzi do zestawu w sklepie.' ),
			),
			'ex' => array( '[rzd_zestaw]', '[rzd_zestaw id="123" przycisk="Zamów obiad"]', '[rzd_zestaw id="123" zdjecie="nie" cena="nie" przycisk=""]' ) ),
		array( 'tag' => 'rzd_zestawy', 'g' => 'strona', 'n' => 'Wszystkie zestawy', 'where' => 'Strona główna, „Menu”',
			'd' => 'Siatka wszystkich zestawów widocznych w sklepie, każdy jak w [rzd_zestaw].',
			'a' => array( array( 'dzien', 'RRRR-MM-DD', 'pierwszy dzień dostawy', '' ), array( 'zdjecie / sklad / cena / przycisk', 'jak w [rzd_zestaw]', '', '' ) ),
			'ex' => array( '[rzd_zestawy]', '[rzd_zestawy cena="nie"]' ) ),
		array( 'tag' => 'rzd_godziny', 'g' => 'strona', 'n' => 'Godziny dostaw i odbioru', 'where' => 'Strona główna, stopka, „Kontakt”',
			'd' => 'Dziś (albo w wybranym dniu): dostawy od–do, do kiedy przyjmujemy zamówienia, odbiór osobisty. Z ustawień Panel → Terminy.',
			'a' => array( array( 'dzien', 'RRRR-MM-DD', 'dziś', '' ), array( 'grupy', 'tak / nie', 'tak', 'Osobne godziny każdej grupy dań (np. Śniadania, Obiady), gdy jest ich kilka.' ) ),
			'ex' => array( '[rzd_godziny]', '[rzd_godziny grupy="nie"]' ) ),
		array( 'tag' => 'rzd_menu', 'g' => 'strona', 'n' => 'Pełne menu', 'where' => 'Strona „Menu” / „Karta dań”',
			'd' => 'Kategorie i dania z cenami (brutto), krótkim opisem i miniaturą – jak w sklepie (bez dań „Nie wyświetlaj”). Kolejność kategorii jak kafle, dań – jak w sklepie. Nazwa dania prowadzi do sklepu.',
			'a' => array(
				array( 'kategoria', 'nazwy albo adresy kategorii po przecinku', 'wszystkie', 'Tylko te kategorie, w podanej kolejności.' ),
				array( 'zdjecie', 'tak / nie', 'tak', 'Miniatura dania.' ), array( 'opis', 'tak / nie', 'tak', 'Krótki opis dania.' ), array( 'cena', 'tak / nie', 'tak', '' ),
				array( 'alergeny', 'tak / nie', 'nie', 'Nazwy alergenów pod daniem.' ),
				array( 'spis', 'tak / nie', 'tak', 'Na górze linki do kategorii (gdy jest ich kilka).' ),
				array( 'przycisk', 'napis', 'bez przycisku', 'Przycisk pod menu prowadzący do zamawiania, np. przycisk="Zamów online".' ),
			),
			'ex' => array( '[rzd_menu]', '[rzd_menu kategoria="Zupy,Pierogi" zdjecie="nie"]', '[rzd_menu alergeny="tak" przycisk="Zamów online"]' ) ),
		array( 'tag' => 'rzd_kontakt', 'g' => 'strona', 'n' => 'Formularz kontaktowy', 'where' => 'Strona „Kontakt”, „Catering”',
			'd' => 'Formularz z Panel → Formularze; wiadomości trafiają do Panel → Wiadomości.',
			'a' => array( array( 'id', 'identyfikator formularza', 'pierwszy formularz', 'Z listy w Panel → Formularze.' ), array( 'styl', $styles, 'ustawiony przy formularzu', '' ) ),
			'ex' => array( '[rzd_kontakt id="kontakt"]', '[rzd_kontakt id="catering" styl="karta"]' ) ),
		/* ---------- ekrany obsługi (strony tworzą się same) ---------- */
		array( 'tag' => 'rzd_panel', 'g' => 'obsluga', 'n' => 'Panel restauracji', 'where' => 'Strona „Panel restauracji” (tworzy się sama)', 'd' => 'Wszystkie ustawienia wtyczki. Tylko po zalogowaniu.', 'a' => array(), 'ex' => array( '[rzd_panel]' ) ),
		array( 'tag' => 'kuchnia_dashboard', 'g' => 'obsluga', 'n' => 'Kuchnia', 'where' => 'Strona „Kuchnia”', 'd' => 'Zamówienia, pakowanie, planowanie, historia – na tablet.', 'a' => array(), 'ex' => array( '[kuchnia_dashboard]' ) ),
		array( 'tag' => 'kurier_dashboard', 'g' => 'obsluga', 'n' => 'Kurier', 'where' => 'Strona „Kurier”', 'd' => 'Trasa i „Dostarczone” – na telefon kuriera.', 'a' => array(), 'ex' => array( '[kurier_dashboard]' ) ),
		array( 'tag' => 'edycja_produktow', 'g' => 'obsluga', 'n' => 'Edycja menu', 'where' => 'Strona „Edycja menu”', 'd' => 'Dania, ceny, zdjęcia, zestawy, opisy AI – z telefonu i komputera.', 'a' => array(), 'ex' => array( '[edycja_produktow]' ) ),
		array( 'tag' => 'rzd_sala', 'g' => 'obsluga', 'n' => 'Sala (kelner)', 'where' => 'Strona „Sala” (tworzy się sama)', 'd' => 'Stoliki i rachunki dla kelnera.', 'a' => array(), 'ex' => array( '[rzd_sala]' ) ),
	);
	foreach ( $list as $i => $s ) {
		$list[ $i ]['on'] = shortcode_exists( $s['tag'] );
	}
	return $list;
}
