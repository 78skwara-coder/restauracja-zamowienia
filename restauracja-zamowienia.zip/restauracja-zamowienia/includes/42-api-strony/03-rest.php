<?php
/**
 * Moduł 42-api-strony – REST (tylko odczyt, publiczny – te same dane, które klient widzi w sklepie):
 *   GET /wp-json/rzd/v1/zestawy[?dzien=RRRR-MM-DD]            – wszystkie zestawy ze składem
 *   GET /wp-json/rzd/v1/zestaw/{id}[?dzien=RRRR-MM-DD]        – jeden zestaw
 *   GET /wp-json/rzd/v1/godziny[?dzien=RRRR-MM-DD]            – godziny dostaw i odbioru
 *   GET /wp-json/rzd/v1/menu[?kategoria=Zupy,Pierogi]         – pełne menu (kategorie i dania z cenami)
 * Bez ?dzien: zestaw – pierwszy dzień dostawy (jak w sklepie), godziny – dziś. ?html=1 → dodatkowo pole `html`
 * (gotowy wygląd; atrybuty jak w shortcodach: zdjecie, sklad, cena, przycisk, grupy, kategoria, opis, alergeny, spis). Zawsze działa też adres
 * /?rest_route=/rzd/v1/… (strona bez „ładnych” bezpośrednich odnośników).
 * Pamięć podręczna 5 min, kasowana przy zmianach (rzd_site_ver). CORS: WordPress pozwala każdej stronie czytać
 * publiczne REST; lista domen w ustawieniach (gdy niepusta) zawęża to do wpisanych.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'rest_api_init', function () {
	$args = array(
		'dzien' => array( 'type' => 'string', 'required' => false ),
		'html'  => array( 'type' => 'string', 'required' => false ),
	);
	register_rest_route( 'rzd/v1', '/zestawy', array( 'methods' => 'GET', 'callback' => 'rzd_site_rest', 'permission_callback' => '__return_true', 'args' => $args ) );
	register_rest_route( 'rzd/v1', '/zestaw/(?P<id>\d+)', array( 'methods' => 'GET', 'callback' => 'rzd_site_rest', 'permission_callback' => '__return_true', 'args' => $args ) );
	register_rest_route( 'rzd/v1', '/menu', array( 'methods' => 'GET', 'callback' => 'rzd_site_rest', 'permission_callback' => '__return_true', 'args' => $args ) );
	register_rest_route( 'rzd/v1', '/godziny', array( 'methods' => 'GET', 'callback' => 'rzd_site_rest', 'permission_callback' => '__return_true', 'args' => $args ) );
} );

/** @param WP_REST_Request $r */
function rzd_site_rest( $r ) {
	if ( ! rzd_site_api_settings()['on'] ) {
		return new WP_Error( 'rzd_api_off', 'API strony jest wyłączone (Panel restauracji → Shortcody i API).', array( 'status' => 404 ) );
	}
	$route = $r->get_route();
	$p     = array_intersect_key( $r->get_query_params(), array_flip( array( 'dzien', 'html', 'zdjecie', 'sklad', 'cena', 'przycisk', 'grupy', 'kategoria', 'opis', 'alergeny', 'spis' ) ) );
	$p     = array_map( function ( $v ) {
		return is_scalar( $v ) ? mb_substr( sanitize_text_field( (string) $v ), 0, 40 ) : '';
	}, $p );
	ksort( $p );
	$key = 'rzd_site_' . md5( $route . '|' . wp_json_encode( $p ) . '|' . rzd_site_ver() );
	$out = get_transient( $key );
	if ( false === $out ) {
		$date = isset( $p['dzien'] ) ? rzd_site_valid_date( $p['dzien'] ) : '';
		$o    = rzd_site_opts( $p );
		if ( 0 === strpos( $route, '/rzd/v1/menu' ) ) {
			$out = rzd_site_menu( isset( $p['kategoria'] ) ? $p['kategoria'] : '' );
			$fn  = 'rzd_site_menu_html';
		} elseif ( 0 === strpos( $route, '/rzd/v1/godziny' ) ) {
			$out = rzd_site_hours( $date );
			$fn  = 'rzd_site_hours_html';
		} elseif ( 0 === strpos( $route, '/rzd/v1/zestaw/' ) ) {
			$out = rzd_site_set_data( (int) $r['id'], $date );
			if ( ! $out ) {
				return new WP_Error( 'rzd_not_found', 'Nie ma takiego zestawu.', array( 'status' => 404 ) );
			}
			$fn = 'rzd_site_set_html';
		} else {
			$out = array( 'sets' => array_values( array_filter( array_map( function ( $id ) use ( $date ) {
				return rzd_site_set_data( $id, $date );
			}, rzd_site_set_ids() ) ) ) );
			$fn = function ( $x, $o ) {
				return rzd_site_sets_html( $x['sets'], $o );
			};
		}
		if ( ! empty( $p['html'] ) ) {
			if ( 0 === strpos( $route, '/rzd/v1/menu' ) && ! isset( $p['przycisk'] ) ) {
				$o['przycisk'] = ''; // menu: przycisk do sklepu tylko na życzenie
			}
			$out['html'] = call_user_func( $fn, $out, $o );
			$out['css']  = RZD_PLUGIN_URL . 'assets/css/rzd-strona.css?ver=' . rzd_asset_ver( 'assets/css/rzd-strona.css' );
		}
		set_transient( $key, $out, 5 * MINUTE_IN_SECONDS );
	}
	$res = rest_ensure_response( $out );
	$res->header( 'Cache-Control', 'public, max-age=60' );
	return $res;
}

/** Lista domen (gdy wpisana) – inne strony nie dostaną nagłówka CORS dla tras rzd/v1. */
add_filter( 'rest_pre_serve_request', function ( $served, $result, $request ) {
	if ( 0 !== strpos( (string) $request->get_route(), '/rzd/v1/' ) ) {
		return $served;
	}
	$list   = rzd_site_api_origins();
	$origin = strtolower( untrailingslashit( (string) get_http_origin() ) );
	if ( $list && '' !== $origin && ! in_array( $origin, $list, true ) && ! headers_sent() ) {
		header_remove( 'Access-Control-Allow-Origin' );
		header_remove( 'Access-Control-Allow-Credentials' );
	} elseif ( '' !== $origin && ! headers_sent() ) {
		header( 'Access-Control-Allow-Origin: ' . esc_url_raw( $origin ) );
		header( 'Vary: Origin', false );
	}
	return $served;
}, 20, 3 );
