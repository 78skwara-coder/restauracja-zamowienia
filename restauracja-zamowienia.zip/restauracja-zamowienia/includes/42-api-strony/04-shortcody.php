<?php
/**
 * Moduł 42-api-strony – shortcody na stronach tego WordPressa (ten sam wygląd co REST ?html=1 i kod do wklejenia):
 *   [rzd_zestaw id="123" dzien="2026-11-12" zdjecie="tak" sklad="tak" cena="tak" przycisk="Zamów"]
 *   [rzd_zestawy …te same atrybuty bez id]
 *   [rzd_godziny dzien="" grupy="tak"]
 *   [rzd_menu kategoria="" zdjecie opis cena alergeny spis przycisk]
 * Bez id – pierwszy zestaw ze sklepu. Bez dzien – zestaw: pierwszy dzień dostawy, godziny: dziś.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function rzd_site_css() {
	wp_enqueue_style( 'rzd-strona', RZD_PLUGIN_URL . 'assets/css/rzd-strona.css', array(), rzd_asset_ver( 'assets/css/rzd-strona.css' ) );
}

add_shortcode( 'rzd_zestaw', function ( $atts ) {
	$a  = (array) $atts;
	$id = isset( $a['id'] ) ? (int) $a['id'] : 0;
	if ( ! $id ) {
		$ids = rzd_site_set_ids();
		$id  = $ids ? $ids[0] : 0;
	}
	rzd_site_css();
	$d = $id ? rzd_site_set_data( $id, isset( $a['dzien'] ) ? $a['dzien'] : '' ) : null;
	if ( ! $d ) {
		return current_user_can( 'edit_posts' ) ? '<p class="rzd-s rzd-s-mut">[rzd_zestaw] – nie ma takiego zestawu (id ' . (int) $id . '). Ten komunikat widzą tylko redaktorzy.</p>' : '';
	}
	return rzd_site_set_html( $d, rzd_site_opts( $a ) );
} );

add_shortcode( 'rzd_zestawy', function ( $atts ) {
	$a    = (array) $atts;
	$date = isset( $a['dzien'] ) ? $a['dzien'] : '';
	rzd_site_css();
	return rzd_site_sets_html( array_map( function ( $id ) use ( $date ) {
		return rzd_site_set_data( $id, $date );
	}, rzd_site_set_ids() ), rzd_site_opts( $a ) );
} );

add_shortcode( 'rzd_godziny', function ( $atts ) {
	$a = (array) $atts;
	rzd_site_css();
	return rzd_site_hours_html( rzd_site_hours( isset( $a['dzien'] ) ? $a['dzien'] : '' ), rzd_site_opts( $a ) );
} );

/** (2.59.0) [rzd_menu kategoria="" zdjecie="tak" opis="tak" cena="tak" alergeny="nie" spis="tak" przycisk=""] */
add_shortcode( 'rzd_menu', function ( $atts ) {
	$a = (array) $atts;
	rzd_site_css();
	$o = rzd_site_opts( $a );
	if ( ! isset( $a['przycisk'] ) ) {
		$o['przycisk'] = '';
	}
	return rzd_site_menu_html( rzd_site_menu( isset( $a['kategoria'] ) ? $a['kategoria'] : '' ), $o );
} );
