<?php
/**
 * MODUŁ 42: API STRONY (2.59.0) – dane sklepu do pokazania na stronie restauracji: zestawy ze składem na dzień
 * i godziny dostaw / odbioru. Trzy sposoby użycia (dane zawsze z tych samych funkcji):
 *  1) REST `/wp-json/rzd/v1/…` (JSON; `?html=1` – gotowy HTML) – dla strony na innej domenie;
 *  2) shortcody [rzd_zestaw], [rzd_zestawy], [rzd_godziny] – na stronach tego WordPressa;
 *  3) kod do wklejenia (assets/js/rzd-strona.js + <div data-rzd="…">) – dowolna strona, bez programowania.
 * (2.59.0) Także pełne menu: REST /menu, shortcode [rzd_menu].
 * Ustawienia – opcja `rzd_site_api` { on, origins (domeny z prawem pobierania – CORS), btn – napis przycisku }.
 * Bez nazw na stałe: wszystko z ustawień sklepu. Dawne snippety (WPCode) działają niezależnie.
 *
 * Części: 01-dane (ustawienia, dane), 02-html (wygląd – wspólny dla shortcodów, REST i osadzania),
 * 03-rest (trasy, CORS, pamięć podręczna), 04-shortcody, 05-pomoc (spis WSZYSTKICH shortcodów wtyczki – Panel).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function rzd_site_api_settings() {
	$o = get_option( 'rzd_site_api', array() );
	$o = is_array( $o ) ? $o : array();
	return array_merge( array( 'on' => 1, 'origins' => '', 'btn' => 'Zamów' ), array_intersect_key( $o, array_flip( array( 'on', 'origins', 'btn' ) ) ) );
}

/** Domeny z prawem pobierania danych (https://…, bez ścieżki). */
function rzd_site_api_origins( $text = null ) {
	$out = array();
	foreach ( preg_split( '/[\s,;]+/', null === $text ? (string) rzd_site_api_settings()['origins'] : (string) $text, -1, PREG_SPLIT_NO_EMPTY ) as $u ) {
		$p = wp_parse_url( false === strpos( $u, '://' ) ? 'https://' . $u : $u );
		if ( ! empty( $p['host'] ) ) {
			$out[] = strtolower( ( isset( $p['scheme'] ) ? $p['scheme'] : 'https' ) . '://' . $p['host'] . ( isset( $p['port'] ) ? ':' . (int) $p['port'] : '' ) );
		}
	}
	return array_values( array_unique( $out ) );
}

function rzd_site_api_save( $in ) {
	$s = rzd_site_api_settings();
	if ( array_key_exists( 'on', $in ) ) {
		$s['on'] = empty( $in['on'] ) ? 0 : 1;
	}
	if ( isset( $in['btn'] ) ) {
		$s['btn'] = mb_substr( sanitize_text_field( (string) $in['btn'] ), 0, 30 );
	}
	if ( isset( $in['origins'] ) ) {
		$s['origins'] = implode( "\n", rzd_site_api_origins( $in['origins'] ) ); // postać uporządkowana: https://domena
	}
	update_option( 'rzd_site_api', $s, false );
	rzd_site_bump();
	return array( true, 'Zapisano ustawienia API strony.' );
}

/** Wersja danych – podbijana przy zmianach (zestawy, dania, godziny); klucz pamięci podręcznej. */
function rzd_site_ver() {
	return (int) get_option( 'rzd_site_ver', 1 );
}
function rzd_site_bump() {
	update_option( 'rzd_site_ver', rzd_site_ver() + 1, false );
}
add_action( 'save_post_product', 'rzd_site_bump' );
add_action( 'updated_option', function ( $opt ) {
	if ( in_array( $opt, array( 'dc_settings', 'rzd_pickup', 'rzd_site_api' ), true ) ) {
		rzd_site_bump();
	}
} );
foreach ( array( 'added_post_meta', 'updated_post_meta', 'deleted_post_meta' ) as $rzd_site_h ) {
	add_action( $rzd_site_h, function ( $mid, $pid, $key ) {
		if ( in_array( $key, array( '_rwz_slots', '_rwz_set_order', '_thumbnail_id', '_price', '_rwz_hide_in_shop' ), true ) ) {
			rzd_site_bump();
		}
	}, 10, 3 );
}
add_action( 'set_object_terms', function ( $oid, $terms, $tt, $tax ) {
	if ( in_array( $tax, array( 'rzd_set_label', 'product_cat', 'alergen' ), true ) ) {
		rzd_site_bump();
	}
}, 10, 4 );

foreach ( array( 'created_product_cat', 'edited_product_cat', 'delete_product_cat' ) as $rzd_site_h ) {
	add_action( $rzd_site_h, 'rzd_site_bump' );
}

function rzd_site_today() {
	return current_time( 'Y-m-d' );
}

function rzd_site_valid_date( $d ) {
	return is_string( $d ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $d ) ? $d : '';
}

/** Zestawy widoczne w sklepie (opublikowane, bez „Nie wyświetlaj”). */
function rzd_site_set_ids() {
	$ids    = array();
	$hidden = function_exists( 'rzd_seo_hidden_product_ids' ) ? rzd_seo_hidden_product_ids() : array();
	foreach ( wc_get_products( array( 'status' => 'publish', 'limit' => 200, 'return' => 'ids', 'orderby' => 'menu_order', 'order' => 'ASC' ) ) as $pid ) {
		if ( rzd_zestaw_is_set_product( $pid ) && ! in_array( (int) $pid, $hidden, true ) ) {
			$ids[] = (int) $pid;
		}
	}
	return $ids;
}

function rzd_site_img( $att_id, $size = 'woocommerce_single' ) {
	$s = $att_id ? wp_get_attachment_image_src( (int) $att_id, $size ) : false;
	return $s ? array( 'url' => $s[0], 'w' => (int) $s[1], 'h' => (int) $s[2], 'alt' => (string) get_post_meta( (int) $att_id, '_wp_attachment_image_alt', true ) ) : null;
}

/**
 * Zestaw na dzień. $date '' = pierwszy dzień dostawy (jak w sklepie, gdy klient nie wybrał terminu).
 * { id, name, url, price, price_text, date, date_label, available, image, items [ { role, role_order, id, name, url,
 * image, addon } ] }. Skład = najgłębsze dania (zestawy pośrednie rozwinięte, rola z pozycji wpiętej w zestaw).
 */
function rzd_site_set_data( $pid, $date = '' ) {
	$p = wc_get_product( (int) $pid );
	if ( ! $p || 'publish' !== $p->get_status() || ! rzd_zestaw_is_set_product( $p->get_id() ) ) {
		return null;
	}
	$date = rzd_site_valid_date( $date );
	if ( '' === $date ) {
		$date = (string) rzd_zestaw_default_delivery_date( $p->get_id() );
	}
	$d     = '' !== $date ? $date : rzd_site_today();
	$act   = rzd_zestaw_get_active_components( $p->get_id(), $d );
	$items = array();
	foreach ( array( 'main' => false, 'addon' => true ) as $bucket => $is_addon ) {
		foreach ( (array) $act[ $bucket ] as $cid => $c ) {
			if ( (int) $c->get_id() === (int) $p->get_id() ) {
				continue;
			}
			$role    = isset( $act['roles'][ $cid ] ) ? $act['roles'][ $cid ] : array( 'label' => '', 'order' => null );
			$items[] = array(
				'role'       => (string) $role['label'],
				'role_order' => null === $role['order'] ? 999 : (int) $role['order'],
				'id'         => (int) $c->get_id(),
				'name'       => html_entity_decode( $c->get_name(), ENT_QUOTES, 'UTF-8' ),
				'url'        => get_permalink( $c->get_id() ),
				'image'      => rzd_site_img( $c->get_image_id(), 'woocommerce_thumbnail' ),
				'addon'      => $is_addon,
			);
		}
	}
	usort( $items, function ( $a, $b ) {
		return ( $a['addon'] <=> $b['addon'] ) ?: ( $a['role_order'] <=> $b['role_order'] );
	} );
	// zdjęcie: dzielone z dwóch dań → jedno danie → zdjęcie zestawu
	$img   = null;
	$split = function_exists( 'rzd_zestaw_split_image_html' ) ? rzd_zestaw_split_image_html( $p->get_id(), 'woocommerce_single', array(), true, $d ) : '';
	if ( $split ) {
		$img = array( 'url' => $split, 'w' => 0, 'h' => 0, 'alt' => html_entity_decode( $p->get_name(), ENT_QUOTES, 'UTF-8' ) );
	} else {
		$ids = function_exists( 'rzd_zestaw_get_display_image_ids' ) ? rzd_zestaw_get_display_image_ids( $p->get_id(), $d ) : array();
		$img = rzd_site_img( $ids ? $ids[0] : $p->get_image_id() );
	}
	return array(
		'id'         => (int) $p->get_id(),
		'name'       => html_entity_decode( $p->get_name(), ENT_QUOTES, 'UTF-8' ),
		'url'        => get_permalink( $p->get_id() ),
		'price'      => (float) wc_get_price_including_tax( $p ),
		'price_text' => html_entity_decode( wp_strip_all_tags( wc_price( wc_get_price_including_tax( $p ) ) ), ENT_QUOTES, 'UTF-8' ),
		'date'       => $date,
		'date_label' => '' !== $date && function_exists( 'rzd_dc_date_label' ) ? rzd_dc_date_label( $date ) : '',
		'available'  => '' !== $date && (bool) array_filter( $items, function ( $i ) { return ! $i['addon']; } ),
		'image'      => $img,
		'items'      => $items,
	);
}

/** Nazwa grupy terminów (kategoria / zbiór dań). */
function rzd_site_group_name( $term_id ) {
	$t = get_term( (int) $term_id );
	return $t && ! is_wp_error( $t ) ? html_entity_decode( $t->name, ENT_QUOTES, 'UTF-8' ) : 'Grupa ' . (int) $term_id;
}

/**
 * Godziny dnia: dostawy według grup (od, do – koniec ostatniego okna, „zamówienia do”) i odbiór osobisty.
 * { date, date_label, delivery { on, from, to, last_order, open_now, groups [ { id, name, from, to, last_order,
 * open_now, times [] } ] }, pickup { on, from, to, last_order, open_now } }. Godziny HH:MM; last_order – godzina
 * w dniu dostawy albo „HH:MM (dzień)” gdy zamawia się dzień wcześniej (last_order_at – pełna data i godzina).
 */
function rzd_site_hours( $date = '' ) {
	$date = rzd_site_valid_date( $date );
	$date = '' !== $date ? $date : rzd_site_today();
	$s    = rzd_dc_get_settings();
	$on   = ! empty( $s['enabled'] );
	$out  = array( 'date' => $date, 'date_label' => function_exists( 'rzd_dc_date_label' ) ? rzd_dc_date_label( $date ) : $date, 'delivery' => array( 'on' => false, 'from' => '', 'to' => '', 'last_order' => '', 'last_order_at' => '', 'open_now' => false, 'groups' => array() ), 'pickup' => array( 'on' => false, 'from' => '', 'to' => '', 'last_order' => '', 'open_now' => false ) );
	if ( ! $on ) {
		return $out;
	}
	$dow  = ( new DateTime( $date, wp_timezone() ) )->format( 'D' );
	$last = 0;
	foreach ( $s['groups'] as $tid => $cal ) {
		if ( ! in_array( $dow, (array) $cal['days'], true ) || in_array( $date, (array) $cal['blocked'], true ) || in_array( $date, (array) $s['global_blocked'], true ) || ( ! rzd_dc_windows_on() && in_array( $dow, (array) $s['off_days'], true ) ) ) {
			continue;
		}
		if ( ( ! empty( $cal['valid_from'] ) && $date < $cal['valid_from'] ) || ( ! empty( $cal['valid_to'] ) && $date > $cal['valid_to'] ) ) {
			continue;
		}
		$times = rzd_dc_group_times( $cal, $date );
		if ( ! $times ) {
			continue;
		}
		sort( $times );
		$lt  = end( $times );
		$w   = rzd_dc_windows_on() ? rzd_dc_window_at( $date, $lt ) : null;
		$to  = $w ? $w['end'] : $lt;
		$cut = rzd_dc_cutoff_ts( $date, $lt );
		$last = max( $last, $cut );
		$out['delivery']['groups'][] = array(
			'id'            => (int) $tid,
			'name'          => rzd_site_group_name( $tid ),
			'from'          => $times[0],
			'to'            => $to,
			'last_order'    => rzd_site_cut_label( $cut, $date ),
			'last_order_at' => $cut ? wp_date( 'Y-m-d H:i', $cut ) : '',
			'open_now'      => (bool) rzd_dc_calendar_times_for_date( $cal, $date ),
			'times'         => array_values( $times ),
		);
	}
	$g = $out['delivery']['groups'];
	if ( $g ) {
		$out['delivery']['on']            = true;
		$out['delivery']['from']          = min( wp_list_pluck( $g, 'from' ) );
		$out['delivery']['to']            = max( wp_list_pluck( $g, 'to' ) );
		$out['delivery']['last_order']    = rzd_site_cut_label( $last, $date );
		$out['delivery']['last_order_at'] = $last ? wp_date( 'Y-m-d H:i', $last ) : '';
		$out['delivery']['open_now']      = in_array( true, wp_list_pluck( $g, 'open_now' ), true );
	}
	if ( function_exists( 'rzd_pickup_on' ) && ! empty( rzd_pickup_settings()['on'] ) && function_exists( 'rzd_pickup_times_for_date' ) ) {
		$all = rzd_pickup_times_for_date( $date, true );
		if ( $all ) {
			sort( $all );
			$now = rzd_pickup_times_for_date( $date );
			$out['pickup'] = array( 'on' => true, 'from' => $all[0], 'to' => end( $all ), 'last_order' => '', 'open_now' => (bool) $now );
		}
	}
	return $out;
}

/** „10:30” (w dniu dostawy) albo „17:00, pt. 13.11” (wcześniej). */
function rzd_site_cut_label( $ts, $date ) {
	if ( ! $ts ) {
		return '';
	}
	$d = wp_date( 'Y-m-d', $ts );
	return wp_date( 'H:i', $ts ) . ( $d !== $date && function_exists( 'rzd_dc_date_label' ) ? ', ' . rzd_dc_date_label( $d ) : '' );
}

/**
 * (2.59.0) Pełne menu: kategorie w kolejności kafli (rzd_kategorie_sort), dania jak w sklepie (bez „Nie wyświetlaj”,
 * bez zahasłowanych), w kategorii wg kolejności produktu, potem nazwy. $cats – nazwy albo adresy kategorii po
 * przecinku ('' = wszystkie). { categories [ { id, name, slug, url, items [ { id, name, url, price, price_text,
 * desc, image, allergens [], is_set } ] } ] }. Danie w kilku kategoriach – w pierwszej widocznej.
 */
function rzd_site_menu( $cats = '' ) {
	$hidden = function_exists( 'rzd_seo_hidden_cat_ids' ) ? rzd_seo_hidden_cat_ids() : array();
	$want   = array();
	foreach ( array_filter( array_map( 'trim', explode( ',', (string) $cats ) ) ) as $c ) {
		$t = get_term_by( 'name', $c, 'product_cat' );
		$t = $t ? $t : get_term_by( 'slug', sanitize_title( $c ), 'product_cat' );
		if ( $t ) {
			$want[] = (int) $t->term_id;
		}
	}
	$prods = function_exists( 'rzd_seo_visible_products' ) ? rzd_seo_visible_products() : wc_get_products( array( 'status' => 'publish', 'limit' => 400, 'visibility' => 'catalog' ) );
	usort( $prods, function ( $a, $b ) {
		return ( $a->get_menu_order() <=> $b->get_menu_order() ) ?: strcoll( $a->get_name(), $b->get_name() );
	} );
	$secs  = array();
	$terms = array();
	foreach ( $prods as $p ) {
		$cat = null;
		foreach ( wp_get_post_terms( $p->get_id(), 'product_cat' ) as $t ) {
			if ( in_array( (int) $t->term_id, $hidden, true ) ) {
				continue;
			}
			if ( ! $want || in_array( (int) $t->term_id, $want, true ) ) {
				$cat = $t;
				break;
			}
		}
		if ( ! $cat ) {
			continue;
		}
		$cid = (int) $cat->term_id;
		if ( ! isset( $secs[ $cid ] ) ) {
			$link         = get_term_meta( $cid, 'rzd_kategoria_url', true );
			$terms[ $cid ] = $cat;
			$secs[ $cid ]  = array( 'id' => $cid, 'name' => html_entity_decode( $cat->name, ENT_QUOTES, 'UTF-8' ), 'slug' => $cat->slug, 'url' => $link ? $link : get_term_link( $cat ), 'items' => array() );
		}
		$price = $p->is_type( 'variable' ) ? (float) $p->get_variation_price( 'min', true ) : (float) wc_get_price_including_tax( $p );
		$desc  = trim( wp_strip_all_tags( $p->get_short_description() ) );
		$al    = function_exists( 'rzd_alergeny_terms' ) ? array_map( function ( $t ) {
			return html_entity_decode( $t->name, ENT_QUOTES, 'UTF-8' );
		}, rzd_alergeny_terms( $p->get_id() ) ) : array();
		$secs[ $cid ]['items'][] = array(
			'id'         => (int) $p->get_id(),
			'name'       => html_entity_decode( $p->get_name(), ENT_QUOTES, 'UTF-8' ),
			'url'        => get_permalink( $p->get_id() ),
			'price'      => $price,
			'price_text' => $price > 0 ? ( $p->is_type( 'variable' ) ? 'od ' : '' ) . html_entity_decode( wp_strip_all_tags( wc_price( $price ) ), ENT_QUOTES, 'UTF-8' ) : '',
			'desc'       => '' !== $desc ? wp_html_excerpt( $desc, 240, '…' ) : '',
			'image'      => rzd_site_img( $p->get_image_id(), 'woocommerce_thumbnail' ),
			'allergens'  => $al,
			'is_set'     => (bool) rzd_zestaw_is_set_product( $p->get_id() ),
		);
	}
	// kolejność: jak w shortcodzie (gdy podano), inaczej jak kafle kategorii
	if ( $want ) {
		$ordered = array();
		foreach ( $want as $id ) {
			if ( isset( $secs[ $id ] ) ) {
				$ordered[] = $secs[ $id ];
			}
		}
	} else {
		$ts      = function_exists( 'rzd_kategorie_sort' ) ? rzd_kategorie_sort( array_values( $terms ) ) : array_values( $terms );
		$ordered = array_map( function ( $t ) use ( $secs ) {
			return $secs[ (int) $t->term_id ];
		}, $ts );
	}
	return array( 'categories' => array_values( $ordered ) );
}
