<?php
/**
 * Moduł 42-api-strony – wygląd (HTML) zestawów i godzin. Ten sam HTML dają shortcody, REST z ?html=1 i kod
 * do wklejenia. Klasy `rzd-s-*`, kolory przez zmienne CSS (assets/css/rzd-strona.css): --rzd-s-acc, --rzd-s-ink,
 * --rzd-s-mut, --rzd-s-line, --rzd-s-bg, --rzd-s-r – strona może je nadpisać.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Opcje wyglądu z atrybutów („tak” / „nie”). */
function rzd_site_opts( $a ) {
	$yes = function ( $v ) {
		return ! in_array( strtolower( trim( (string) $v ) ), array( 'nie', '0', 'no', 'false', 'off' ), true );
	};
	return array(
		'zdjecie'  => $yes( isset( $a['zdjecie'] ) ? $a['zdjecie'] : 'tak' ),
		'sklad'    => $yes( isset( $a['sklad'] ) ? $a['sklad'] : 'tak' ),
		'cena'     => $yes( isset( $a['cena'] ) ? $a['cena'] : 'tak' ),
		'grupy'    => $yes( isset( $a['grupy'] ) ? $a['grupy'] : 'tak' ),
		'opis'     => $yes( isset( $a['opis'] ) ? $a['opis'] : 'tak' ),
		'alergeny' => $yes( isset( $a['alergeny'] ) ? $a['alergeny'] : 'nie' ),
		'spis'     => $yes( isset( $a['spis'] ) ? $a['spis'] : 'tak' ),
		'przycisk' => isset( $a['przycisk'] ) ? (string) $a['przycisk'] : rzd_site_api_settings()['btn'],
	);
}

function rzd_site_day_word( $date, $label ) {
	if ( $date === rzd_site_today() ) {
		return 'dziś';
	}
	$t = new DateTime( rzd_site_today(), wp_timezone() );
	$t->modify( '+1 day' );
	return $date === $t->format( 'Y-m-d' ) ? 'jutro' : $label;
}

function rzd_site_set_html( $d, $o ) {
	if ( ! $d ) {
		return '';
	}
	$h = '<article class="rzd-s rzd-s-set' . ( $d['available'] ? '' : ' rzd-s-off' ) . '">';
	if ( $o['zdjecie'] && $d['image'] ) {
		$h .= '<a class="rzd-s-img" href="' . esc_url( $d['url'] ) . '"><img src="' . esc_url( $d['image']['url'] ) . '" alt="' . esc_attr( $d['image']['alt'] ? $d['image']['alt'] : $d['name'] ) . '" loading="lazy"' . ( $d['image']['w'] ? ' width="' . (int) $d['image']['w'] . '" height="' . (int) $d['image']['h'] . '"' : '' ) . '></a>';
	}
	$h .= '<div class="rzd-s-body"><h3 class="rzd-s-t"><a href="' . esc_url( $d['url'] ) . '">' . esc_html( $d['name'] ) . '</a></h3>';
	if ( $d['date'] ) {
		$h .= '<p class="rzd-s-day">' . esc_html( ucfirst( rzd_site_day_word( $d['date'], $d['date_label'] ) ) ) . '</p>';
	}
	if ( ! $d['available'] ) {
		$h .= '<p class="rzd-s-mut">' . ( $d['date'] ? 'Skład na ten dzień nie jest jeszcze ustalony.' : 'Brak najbliższego terminu dostawy.' ) . '</p>';
	} elseif ( $o['sklad'] ) {
		$h .= '<ul class="rzd-s-items">';
		foreach ( $d['items'] as $i ) {
			$h .= '<li class="' . ( $i['addon'] ? 'rzd-s-addon' : '' ) . '">' . ( '' !== $i['role'] ? '<span class="rzd-s-role">' . esc_html( $i['role'] ) . '</span> ' : '' ) . '<a href="' . esc_url( $i['url'] ) . '">' . esc_html( $i['name'] ) . '</a></li>';
		}
		$h .= '</ul>';
	}
	$foot = '';
	if ( $o['cena'] && $d['price'] > 0 ) {
		$foot .= '<span class="rzd-s-price">' . esc_html( $d['price_text'] ) . '</span>';
	}
	if ( '' !== trim( $o['przycisk'] ) && $d['available'] ) {
		$foot .= '<a class="rzd-s-btn" href="' . esc_url( $d['url'] ) . '">' . esc_html( $o['przycisk'] ) . '</a>';
	}
	if ( '' !== $foot ) {
		$h .= '<div class="rzd-s-foot">' . $foot . '</div>';
	}
	return $h . '</div></article>';
}

function rzd_site_sets_html( $list, $o ) {
	$list = array_filter( $list );
	if ( ! $list ) {
		return '<p class="rzd-s rzd-s-mut">Brak zestawów.</p>';
	}
	return '<div class="rzd-s-grid">' . implode( '', array_map( function ( $d ) use ( $o ) {
		return rzd_site_set_html( $d, $o );
	}, $list ) ) . '</div>';
}

function rzd_site_hours_html( $x, $o ) {
	$day = rzd_site_day_word( $x['date'], $x['date_label'] );
	$dl  = $x['delivery'];
	$pk  = $x['pickup'];
	$h   = '<div class="rzd-s rzd-s-hours">';
	if ( ! $dl['on'] && ! $pk['on'] ) {
		return $h . '<p class="rzd-s-mut">' . esc_html( ucfirst( $day ) ) . ' nie przyjmujemy zamówień.</p></div>';
	}
	$h .= '<dl>';
	if ( $dl['on'] ) {
		$h .= '<dt>Dostawy ' . esc_html( $day ) . '</dt><dd><strong>' . esc_html( $dl['from'] . '–' . $dl['to'] ) . '</strong>'
			. ( $dl['last_order'] ? ' · zamówienia do ' . esc_html( $dl['last_order'] ) : '' )
			. ( $dl['open_now'] ? '' : ' · <span class="rzd-s-mut">zamówienia na ten dzień już zamknięte</span>' ) . '</dd>';
		if ( $o['grupy'] && count( $dl['groups'] ) > 1 ) {
			foreach ( $dl['groups'] as $g ) {
				$h .= '<dd class="rzd-s-grp">' . esc_html( $g['name'] ) . ': ' . esc_html( $g['from'] . '–' . $g['to'] ) . ( $g['last_order'] ? ', zamówienia do ' . esc_html( $g['last_order'] ) : '' ) . '</dd>';
			}
		}
	} else {
		$h .= '<dt>Dostawy ' . esc_html( $day ) . '</dt><dd class="rzd-s-mut">brak</dd>';
	}
	if ( $pk['on'] ) {
		$h .= '<dt>Odbiór osobisty</dt><dd><strong>' . esc_html( $pk['from'] . '–' . $pk['to'] ) . '</strong>' . ( $pk['open_now'] ? '' : ' · <span class="rzd-s-mut">zamówienia na ten dzień już zamknięte</span>' ) . '</dd>';
	}
	return $h . '</dl></div>';
}

/** (2.59.0) Pełne menu. Opcje: zdjecie, opis, cena, alergeny, spis (spis kategorii z kotwicami na górze). */
function rzd_site_menu_html( $m, $o ) {
	if ( empty( $m['categories'] ) ) {
		return '<p class="rzd-s rzd-s-mut">Menu jest puste.</p>';
	}
	$h = '<div class="rzd-s rzd-s-menu' . ( $o['zdjecie'] ? '' : ' rzd-s-noimg' ) . '">';
	if ( $o['spis'] && count( $m['categories'] ) > 1 ) {
		$h .= '<nav class="rzd-s-toc" aria-label="Kategorie menu">';
		foreach ( $m['categories'] as $c ) {
			$h .= '<a href="#rzd-menu-' . esc_attr( $c['slug'] ) . '">' . esc_html( $c['name'] ) . '</a>';
		}
		$h .= '</nav>';
	}
	foreach ( $m['categories'] as $c ) {
		$h .= '<section class="rzd-s-cat" id="rzd-menu-' . esc_attr( $c['slug'] ) . '"><h3 class="rzd-s-cat-t">' . esc_html( $c['name'] ) . '</h3><ul class="rzd-s-dishes">';
		foreach ( $c['items'] as $i ) {
			$h .= '<li class="rzd-s-dish">';
			if ( $o['zdjecie'] && $i['image'] ) {
				$h .= '<a class="rzd-s-dish-img" href="' . esc_url( $i['url'] ) . '"><img src="' . esc_url( $i['image']['url'] ) . '" alt="' . esc_attr( $i['image']['alt'] ? $i['image']['alt'] : $i['name'] ) . '" loading="lazy"></a>';
			}
			$h .= '<div class="rzd-s-dish-b"><div class="rzd-s-dish-h"><a class="rzd-s-dish-n" href="' . esc_url( $i['url'] ) . '">' . esc_html( $i['name'] ) . '</a>';
			if ( $o['cena'] && '' !== $i['price_text'] ) {
				$h .= '<span class="rzd-s-dots" aria-hidden="true"></span><span class="rzd-s-price">' . esc_html( $i['price_text'] ) . '</span>';
			}
			$h .= '</div>';
			if ( $o['opis'] && '' !== $i['desc'] ) {
				$h .= '<p class="rzd-s-desc">' . esc_html( $i['desc'] ) . '</p>';
			}
			if ( $o['alergeny'] && $i['allergens'] ) {
				$h .= '<p class="rzd-s-al">Alergeny: ' . esc_html( implode( ', ', $i['allergens'] ) ) . '</p>';
			}
			$h .= '</div></li>';
		}
		$h .= '</ul></section>';
	}
	if ( '' !== trim( $o['przycisk'] ) && function_exists( 'rzd_seo_list_url' ) && rzd_seo_list_url() ) {
		$h .= '<p class="rzd-s-menu-foot"><a class="rzd-s-btn" href="' . esc_url( rzd_seo_list_url() ) . '">' . esc_html( $o['przycisk'] ) . '</a></p>';
	}
	return $h . '</div>';
}
