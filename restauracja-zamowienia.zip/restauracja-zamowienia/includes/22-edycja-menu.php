<?php
/**
 * Moduł 22 – EDYCJA MENU Z TELEFONU (2.27.0)
 *
 * Shortcode [edycja_produktow] – osobna strona pełnoekranowa (jak Kuchnia):
 *  - zakładka Produkty: lista z wyszukiwarką i filtrem kategorii; karta
 *    produktu: zdjęcie (aparat / galeria, zmniejszane w przeglądarce),
 *    nazwa, cena brutto, wyprzedane, alergeny, krótki i pełny opis,
 *  - zakładka Zestaw dnia: dania zestawu na wybrany dzień (zmiana, dodanie,
 *    usunięcie, kopiowanie z innego dnia, nowe danie), sam zestaw (nazwa,
 *    cena, wyprzedane w dniu, zdjęcie zastępcze).
 *
 * Dostęp (decyzja użytkownika): konto WordPress z uprawnieniem rzd_edit_menu –
 * rola „Redaktor menu” (tylko ta strona, bez kokpitu) albo administrator /
 * kierownik sklepu. NIE PIN – strona zmienia sklep i wgrywa pliki.
 *
 * Zapis dnia zestawu = termin z KONKRETNĄ DATĄ i znacznikiem 'override'
 * (moduł 04, rwz_slots_for_date): zastępuje reguły dni tygodnia tylko w tym
 * dniu; reguły zostają nietknięte. Zestaw zagnieżdżony (np. „Zupa dnia”
 * w „Zestawie dnia”) zapisuje się w SWOIM harmonogramie – struktura
 * (opakowania, modyfikacje zestawu pośredniego) zostaje.
 *
 * Wyprzedane (meta _rzd_soldout = [ always, dates[] ]) – wg DNIA DOSTAWY,
 * nie magazynu (klient zamawia też na przyszłe dni). Wyprzedane danie
 * wyprzedaje zestaw, w którym jest w tym dniu (decyzja użytkownika).
 */

defined( 'ABSPATH' ) || exit;

if ( ! defined( 'RZD_ED_CAP' ) ) {
	define( 'RZD_ED_CAP', 'rzd_edit_menu' );
}

/* ============================================================
 * 1. ROLA „REDAKTOR MENU” I DOSTĘP
 * ============================================================ */
add_action( 'init', function () {
	if ( '1' === get_option( 'rzd_ed_roles_v' ) ) {
		return;
	}
	if ( ! get_role( 'rzd_menu_editor' ) ) {
		add_role( 'rzd_menu_editor', 'Redaktor menu', array( 'read' => true, RZD_ED_CAP => true ) );
	}
	foreach ( array( 'administrator', 'shop_manager' ) as $r ) {
		$role = get_role( $r );
		if ( $role ) {
			$role->add_cap( RZD_ED_CAP );
		}
	}
	update_option( 'rzd_ed_roles_v', '1', true );
}, 20 );

function rzd_ed_can() {
	return is_user_logged_in() && current_user_can( RZD_ED_CAP );
}

// Sam „Redaktor menu” (bez uprawnień sklepu) – bez kokpitu i paska admina.
function rzd_ed_is_editor_only( $user = null ) {
	$user = $user ? $user : wp_get_current_user();
	return $user && $user->exists() && in_array( 'rzd_menu_editor', (array) $user->roles, true ) && ! user_can( $user, 'manage_woocommerce' ) && ! user_can( $user, 'edit_posts' );
}

function rzd_ed_page_url() {
	$id = (int) get_option( 'rzd_ed_page_id' );
	return ( $id && 'publish' === get_post_status( $id ) ) ? get_permalink( $id ) : home_url( '/' );
}

add_filter( 'show_admin_bar', function ( $show ) {
	return rzd_ed_is_editor_only() ? false : $show;
} );

add_action( 'admin_init', function () {
	if ( wp_doing_ajax() || ! rzd_ed_is_editor_only() ) {
		return;
	}
	wp_safe_redirect( rzd_ed_page_url() );
	exit;
} );

add_filter( 'login_redirect', function ( $to, $requested, $user ) {
	return ( $user instanceof WP_User && rzd_ed_is_editor_only( $user ) ) ? rzd_ed_page_url() : $to;
}, 20, 3 );
add_filter( 'woocommerce_login_redirect', function ( $to, $user ) {
	return ( $user instanceof WP_User && rzd_ed_is_editor_only( $user ) ) ? rzd_ed_page_url() : $to;
}, 20, 2 );

// Strona z edycją nie może trafić do cache strony (dane się zmieniają, jest zalogowany redaktor).
add_action( 'template_redirect', function () {
	if ( ! is_singular() ) {
		return;
	}
	$post = get_post();
	if ( $post && has_shortcode( $post->post_content, 'edycja_produktow' ) ) {
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true );
		}
		nocache_headers();
		if ( (int) get_option( 'rzd_ed_page_id' ) !== (int) $post->ID ) {
			update_option( 'rzd_ed_page_id', (int) $post->ID, false );
		}
	}
} );

/* ============================================================
 * 2. WYPRZEDANE (wg dnia dostawy)
 * ============================================================ */
function rzd_soldout_get( $pid ) {
	$s = get_post_meta( (int) $pid, '_rzd_soldout', true );
	$s = is_array( $s ) ? $s : array();
	return array(
		'always' => empty( $s['always'] ) ? 0 : 1,
		'dates'  => isset( $s['dates'] ) ? array_values( array_filter( (array) $s['dates'], function ( $d ) { return is_string( $d ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $d ); } ) ) : array(),
	);
}

function rzd_soldout_on( $pid, $date ) {
	$s = rzd_soldout_get( $pid );
	return $s['always'] || in_array( (string) $date, $s['dates'], true );
}

// Produkt albo zestaw (zestaw: sam albo którekolwiek jego danie w tym dniu).
function rzd_soldout_effective( $pid, $date ) {
	static $memo = array();
	$k = (int) $pid . '|' . $date;
	if ( isset( $memo[ $k ] ) ) {
		return $memo[ $k ];
	}
	$out = rzd_soldout_on( $pid, $date );
	if ( ! $out && function_exists( 'rwz_get_slots' ) && rwz_get_slots( $pid ) && function_exists( 'rwz_get_active_components' ) ) {
		$a = rwz_get_active_components( $pid, $date );
		foreach ( (array) $a['main'] as $p ) {
			if ( (int) $p->get_id() !== (int) $pid && rzd_soldout_on( $p->get_id(), $date ) ) {
				$out = true;
				break;
			}
		}
	}
	return $memo[ $k ] = $out;
}

function rzd_soldout_save( $pid, $always, $dates ) {
	$today = function_exists( 'dc_now' ) ? dc_now()->format( 'Y-m-d' ) : current_time( 'Y-m-d' );
	$dates = array_values( array_unique( array_filter( (array) $dates, function ( $d ) use ( $today ) {
		return is_string( $d ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $d ) && $d >= $today; // minione dni wypadają same
	} ) ) );
	sort( $dates );
	if ( ! $always && ! $dates ) {
		delete_post_meta( $pid, '_rzd_soldout' );
	} else {
		update_post_meta( $pid, '_rzd_soldout', array( 'always' => $always ? 1 : 0, 'dates' => $dates ) );
	}
}

// Kalendarz dostaw (moduł 06): wyprzedane w tym dniu = niedostępne (lista, okienko terminu, koszyk, kasa).
add_filter( 'dc_product_available_on', function ( $ok, $pid, $date ) {
	return ( $ok && rzd_soldout_effective( $pid, $date ) ) ? false : $ok;
}, 10, 3 );

// „Do odwołania” – nie do kupienia w ogóle (też bez kalendarza dostaw).
add_filter( 'woocommerce_is_purchasable', function ( $can, $product ) {
	if ( $can && $product && is_object( $product ) ) {
		$s = rzd_soldout_get( $product->get_parent_id() ? $product->get_parent_id() : $product->get_id() );
		if ( $s['always'] ) {
			return false;
		}
	}
	return $can;
}, 10, 2 );

/* ============================================================
 * 3. DANE DLA STRONY
 * ============================================================ */
function rzd_ed_today() {
	return function_exists( 'dc_now' ) ? dc_now()->format( 'Y-m-d' ) : current_time( 'Y-m-d' );
}

function rzd_ed_is_set( $pid ) {
	return function_exists( 'rwz_get_slots' ) && (bool) rwz_get_slots( $pid );
}

// Danie tylko do zestawów: kategoria z „Nie wyświetlaj w sklepie” (moduł 04).
function rzd_ed_only_in_set( $product ) {
	foreach ( (array) $product->get_category_ids() as $cid ) {
		if ( '1' === (string) get_term_meta( $cid, 'rwz_hide_in_shop', true ) ) {
			return true;
		}
	}
	return false;
}

function rzd_ed_money( $v ) {
	return html_entity_decode( wp_strip_all_tags( wc_price( (float) $v ) ), ENT_QUOTES, 'UTF-8' );
}

function rzd_ed_thumb( $att_id, $size = 'thumbnail' ) {
	$u = $att_id ? wp_get_attachment_image_url( (int) $att_id, $size ) : '';
	return $u ? $u : '';
}

// Wiersz listy produktów.
function rzd_ed_row( $p ) {
	$id     = $p->get_id();
	$is_set = rzd_ed_is_set( $id );
	$thumb  = '';
	if ( $is_set && function_exists( 'rwz_split_image_html' ) ) {
		$thumb = rwz_split_image_html( $id, 'thumbnail', array(), true );
		if ( ! $thumb && function_exists( 'rwz_get_display_image_id' ) ) {
			$thumb = rzd_ed_thumb( rwz_get_display_image_id( $id ) );
		}
	}
	if ( ! $thumb ) {
		$thumb = rzd_ed_thumb( get_post_thumbnail_id( $id ) );
	}
	$only = ! $is_set && rzd_ed_only_in_set( $p );
	$sold = rzd_soldout_get( $id );
	return array(
		'id'      => $id,
		'name'    => $p->get_name(),
		'cats'    => array_map( 'intval', (array) $p->get_category_ids() ),
		'price'   => $only ? 'w zestawie' : ( '' !== $p->get_price() ? rzd_ed_money( $p->get_price() ) : '' ),
		'thumb'   => $thumb,
		'is_set'  => $is_set,
		'only'    => $only,
		'sold'    => $sold['always'] ? 'do odwołania' : ( in_array( rzd_ed_today(), $sold['dates'], true ) ? 'dziś' : ( $sold['dates'] ? 'w wybrane dni' : '' ) ),
		'hidden'  => 'publish' !== $p->get_status(),
	);
}

// Tekst z HTML-a opisu do pola tekstowego. null = opis ma formatowanie, którego pole nie odda.
function rzd_ed_html_to_text( $html ) {
	$html = (string) $html;
	if ( false !== strpos( $html, '<!-- wp:' ) ) {
		return null; // bloki edytora
	}
	$test = preg_replace( '#</?(p|br)\b[^>]*>#i', '', $html );
	if ( preg_match( '#<[a-z]#i', $test ) ) {
		return null; // pogrubienia, listy, linki, nagłówki, obrazki… – zostaje w panelu (zapis z telefonu by je zgubił)
	}
	$t = preg_replace( '#<br\s*/?>#i', "\n", $html );
	$t = preg_replace( '#</p>\s*<p[^>]*>#i', "\n\n", $t );
	$t = wp_strip_all_tags( $t );
	return trim( html_entity_decode( $t, ENT_QUOTES, 'UTF-8' ) );
}

function rzd_ed_product_data( $p ) {
	$id     = $p->get_id();
	$is_set = rzd_ed_is_set( $id );
	$short  = rzd_ed_html_to_text( $p->get_short_description() );
	$desc   = rzd_ed_html_to_text( $p->get_description() );
	$alg    = wp_get_object_terms( $id, 'alergen', array( 'fields' => 'ids' ) );
	$own    = get_post_thumbnail_id( $id );
	return array(
		'id'         => $id,
		'name'       => $p->get_name(),
		'is_set'     => $is_set,
		'only'       => ! $is_set && rzd_ed_only_in_set( $p ),
		'price_edit' => $p->is_type( 'simple' ),
		'price'      => '' !== $p->get_regular_price() ? str_replace( '.', ',', wc_format_decimal( $p->get_regular_price(), 2 ) ) : '',
		'sale'       => '' !== $p->get_sale_price(),
		'short'      => null === $short ? '' : $short,
		'short_lock' => null === $short,
		'desc'       => null === $desc ? '' : $desc,
		'desc_lock'  => null === $desc,
		'img'        => rzd_ed_thumb( $own, 'medium_large' ),
		'allergens'  => is_wp_error( $alg ) ? array() : array_map( 'intval', $alg ),
		'soldout'    => rzd_soldout_get( $id ),
		'edit_url'   => current_user_can( 'edit_post', $id ) ? get_edit_post_link( $id, 'raw' ) : '',
	);
}

/* ---------- Zestaw na dzień ---------- */

// Surowe pozycje zestawu w danym dniu (wszystkie pasujące terminy, z „zastępuje”).
function rzd_ed_day_items( $set_id, $date ) {
	$items = array();
	$src   = 'rule';
	foreach ( rwz_slots_for_date( $set_id, $date ) as $slot ) {
		if ( ! rwz_slot_matches_date( $slot, $date ) ) {
			continue;
		}
		if ( ! empty( $slot['override'] ) ) {
			$src = 'day';
		} elseif ( ! empty( $slot['date'] ) && 'day' !== $src ) {
			$src = 'date';
		}
		foreach ( ( isset( $slot['items'] ) && is_array( $slot['items'] ) ) ? $slot['items'] : array() as $it ) {
			if ( empty( $it['product_id'] ) ) {
				continue;
			}
			$items[] = array(
				'product_id' => (int) $it['product_id'],
				'type'       => ( isset( $it['type'] ) && 'addon' === $it['type'] ) ? 'addon' : 'main',
				'photo'      => empty( $it['photo'] ) ? 0 : 1,
			);
		}
	}
	return array( $items, $src );
}

// Opis produktu do wiersza dnia (nazwa, miniatura, rola, wyprzedane).
function rzd_ed_dish_info( $pid, $date ) {
	$p = wc_get_product( $pid );
	if ( ! $p ) {
		return null;
	}
	$role = function_exists( 'rwz_get_set_role' ) ? rwz_get_set_role( $pid ) : array( 'label' => '' );
	return array(
		'id'     => (int) $pid,
		'name'   => $p->get_name(),
		'thumb'  => rzd_ed_thumb( get_post_thumbnail_id( $pid ) ),
		'role'   => $role['label'],
		'is_set' => rzd_ed_is_set( $pid ),
		'sold'   => rzd_soldout_on( $pid, $date ),
	);
}

// Zestaw + wszystkie zestawy zagnieżdżone: [ id => [ name, items, src ] ], $info = opisy produktów.
function rzd_ed_day_owners( $set_id, $date, &$owners, &$info, $depth = 0 ) {
	if ( isset( $owners[ $set_id ] ) || $depth > 4 ) {
		return;
	}
	list( $items, $src ) = rzd_ed_day_items( $set_id, $date );
	$owners[ $set_id ] = array( 'name' => get_the_title( $set_id ), 'items' => $items, 'src' => $src );
	foreach ( $items as $it ) {
		$pid = $it['product_id'];
		if ( ! isset( $info[ $pid ] ) ) {
			$i = rzd_ed_dish_info( $pid, $date );
			if ( $i ) {
				$info[ $pid ] = $i;
			}
		}
		if ( rzd_ed_is_set( $pid ) && (int) $pid !== (int) $set_id ) {
			rzd_ed_day_owners( $pid, $date, $owners, $info, $depth + 1 );
		}
	}
}

// Zestawy, w które wpięto dany zestaw (rekurencyjnie w górę).
function rzd_ed_set_parents( $set_id, $seen = array() ) {
	static $memo = array();
	if ( ! $seen && isset( $memo[ (int) $set_id ] ) ) {
		return $memo[ (int) $set_id ];
	}
	$top = ! $seen;
	$out = array();
	if ( ! function_exists( 'rzd_all_sets' ) ) {
		return $out;
	}
	foreach ( rzd_all_sets() as $sid ) {
		if ( (int) $sid === (int) $set_id || in_array( $sid, $seen, true ) ) {
			continue;
		}
		foreach ( rwz_get_slots( $sid ) as $slot ) {
			foreach ( ( isset( $slot['items'] ) && is_array( $slot['items'] ) ) ? $slot['items'] : array() as $it ) {
				if ( ! empty( $it['product_id'] ) && (int) $it['product_id'] === (int) $set_id ) {
					$out[] = (int) $sid;
					break 2;
				}
			}
		}
	}
	$all = $out;
	foreach ( $out as $p ) {
		$all = array_merge( $all, rzd_ed_set_parents( $p, array_merge( $seen, array( (int) $set_id ), $out ) ) );
	}
	$all = array_values( array_unique( $all ) );
	if ( $top ) {
		$memo[ (int) $set_id ] = $all;
	}
	return $all;
}

// Złożone zamówienia na ten dzień z którymkolwiek z zestawów (ich skład jest zamrożony).
function rzd_ed_orders_with_sets( $date, $set_ids ) {
	$res = array( 'count' => 0, 'sklady' => array() );
	if ( ! function_exists( 'kuchnia_orders_for_date' ) || ! $set_ids ) {
		return $res;
	}
	foreach ( kuchnia_orders_for_date( $date ) as $o ) {
		if ( in_array( $o->get_status(), array( 'cancelled', 'failed', 'refunded' ), true ) ) {
			continue;
		}
		$hit = false;
		foreach ( $o->get_items() as $item ) {
			if ( in_array( (int) $item->get_product_id(), $set_ids, true ) ) {
				$hit = true;
				$w   = (string) $item->get_meta( 'W zestawie' );
				if ( '' !== $w ) {
					$res['sklady'][ $w ] = true;
				}
			}
		}
		if ( $hit ) {
			$res['count']++;
		}
	}
	$res['sklady'] = array_slice( array_keys( $res['sklady'] ), 0, 3 );
	return $res;
}

function rzd_ed_day_data( $set_id, $date ) {
	$owners = array();
	$info   = array();
	rzd_ed_day_owners( $set_id, $date, $owners, $info );
	$active = rwz_get_active_components( $set_id, $date );
	$names  = array();
	foreach ( (array) $active['main'] as $p ) {
		if ( (int) $p->get_id() !== (int) $set_id ) {
			$names[] = $p->get_name();
		}
	}
	$preview = function_exists( 'rwz_split_image_html' ) ? rwz_split_image_html( $set_id, 'woocommerce_thumbnail', array(), true, $date ) : '';
	if ( ! $preview && function_exists( 'rwz_get_display_image_ids' ) ) {
		$ids     = rwz_get_display_image_ids( $set_id, $date );
		$preview = rzd_ed_thumb( $ids ? $ids[0] : get_post_thumbnail_id( $set_id ), 'woocommerce_thumbnail' );
	}
	$affected = array_values( array_unique( array_merge( array_map( 'intval', array_keys( $owners ) ), rzd_ed_set_parents( $set_id ) ) ) );
	$set      = wc_get_product( $set_id );
	return array(
		'set'      => (int) $set_id,
		'date'     => $date,
		'label'    => rzd_ed_day_label( $date ),
		'owners'   => $owners,
		'info'     => $info,
		'title'    => $names ? implode( ' + ', $names ) : '',
		'preview'  => $preview,
		'has_dish' => function_exists( 'rwz_set_has_dish' ) ? rwz_set_has_dish( $set_id, $date ) : (bool) $names,
		'orders'   => rzd_ed_orders_with_sets( $date, $affected ),
		'product'  => $set ? rzd_ed_product_data( $set ) : null,
	);
}

function rzd_ed_day_label( $date ) {
	$ts = strtotime( $date . ' 12:00:00' );
	$wd = array( 'nd', 'pon', 'wt', 'śr', 'czw', 'pt', 'sob' );
	return $ts ? $wd[ (int) gmdate( 'w', $ts ) ] . ' ' . gmdate( 'j.m', $ts ) : $date;
}

// Zapis dnia jednego zestawu: jeden termin z tą datą i „zastępuje”, inne terminy tej daty znikają.
function rzd_ed_write_day( $owner, $date, $items ) {
	$slots = rwz_get_slots( $owner );
	$keep  = array();
	$from  = '';
	$to    = '';
	foreach ( $slots as $s ) {
		if ( isset( $s['date'] ) && $s['date'] === $date ) {
			continue; // ich dania są w $items (edytor zaczynał od sumy wszystkich terminów dnia)
		}
		if ( '' === $from && '' === $to && empty( $s['date'] ) && rwz_slot_matches_date( $s, $date ) ) {
			$from = isset( $s['from'] ) ? (string) $s['from'] : '';
			$to   = isset( $s['to'] ) ? (string) $s['to'] : '';
		}
		$keep[] = $s;
	}
	$keep[] = array(
		'days'      => array(),
		'date'      => $date,
		'date_from' => '',
		'date_to'   => '',
		'from'      => $from,
		'to'        => $to,
		'items'     => $items,
		'override'  => 1,
	);
	update_post_meta( $owner, '_rwz_slots', array_values( $keep ) );
	if ( function_exists( 'rwz_rebuild_component_flags' ) ) {
		rwz_rebuild_component_flags( $owner );
	}
}

function rzd_ed_clear_caches() {
	if ( function_exists( 'dc_clear_slots_cache' ) ) {
		dc_clear_slots_cache();
	}
	if ( function_exists( 'rwz_slots_for_date' ) ) {
		rwz_slots_for_date( 0, '', true );
	}
}

/* ============================================================
 * 4. AJAX (tylko zalogowani z rzd_edit_menu)
 * ============================================================ */
function rzd_ed_guard() {
	if ( ! check_ajax_referer( 'rzd_ed', 'n', false ) ) {
		wp_send_json_error( array( 'msg' => 'Sesja wygasła – odśwież stronę.' ), 403 );
	}
	if ( ! rzd_ed_can() ) {
		wp_send_json_error( array( 'msg' => 'Brak uprawnień do edycji menu.' ), 403 );
	}
}

function rzd_ed_post( $k, $def = '' ) {
	return isset( $_POST[ $k ] ) ? wp_unslash( $_POST[ $k ] ) : $def; // phpcs:ignore
}

add_action( 'wp_ajax_rzd_ed_boot', function () {
	rzd_ed_guard();
	$ids  = wc_get_products( array( 'status' => array( 'publish', 'private' ), 'limit' => -1, 'return' => 'ids', 'orderby' => 'title', 'order' => 'ASC', 'type' => array( 'simple', 'variable', 'grouped', 'external' ) ) );
	_prime_post_caches( array_map( 'intval', $ids ), true, true ); // produkty z metadanymi i terminami jednym zapytaniem
	$rows = array();
	$used = array();
	foreach ( $ids as $id ) {
		$p = wc_get_product( $id );
		if ( ! $p ) {
			continue;
		}
		$r      = rzd_ed_row( $p );
		$rows[] = $r;
		foreach ( $r['cats'] as $c ) {
			$used[ $c ] = true;
		}
	}
	$cats = array();
	$terms = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false, 'include' => array_keys( $used ) ? array_keys( $used ) : array( 0 ) ) );
	if ( ! is_wp_error( $terms ) ) {
		foreach ( $terms as $t ) {
			if ( 'uncategorized' !== $t->slug ) {
				$cats[] = array( 'id' => (int) $t->term_id, 'name' => $t->name );
			}
		}
	}
	$sets = array();
	foreach ( $rows as $r ) {
		if ( $r['is_set'] ) {
			$sets[] = array( 'id' => $r['id'], 'name' => $r['name'], 'price' => $r['price'] );
		}
	}
	// Najpierw zestawy, w które nic nie jest wpięte wyżej (np. „Zestaw dnia”, „Danie dnia”), potem pośrednie.
	usort( $sets, function ( $a, $b ) {
		$pa = rzd_ed_set_parents( $a['id'] ) ? 1 : 0;
		$pb = rzd_ed_set_parents( $b['id'] ) ? 1 : 0;
		return $pa === $pb ? strcmp( $a['name'], $b['name'] ) : $pa - $pb;
	} );
	$alg = array();
	$at  = get_terms( array( 'taxonomy' => 'alergen', 'hide_empty' => false ) );
	if ( ! is_wp_error( $at ) ) {
		foreach ( $at as $t ) {
			$alg[] = array( 'id' => (int) $t->term_id, 'name' => $t->name );
		}
	}
	$days = array();
	$d    = function_exists( 'dc_now' ) ? dc_now() : new DateTime( 'now', wp_timezone() );
	for ( $i = 0; $i < 14; $i++ ) {
		$ymd    = $d->format( 'Y-m-d' );
		$days[] = array( 'date' => $ymd, 'label' => rzd_ed_day_label( $ymd ) );
		$d->modify( '+1 day' );
	}
	wp_send_json_success( array( 'rows' => $rows, 'cats' => $cats, 'sets' => $sets, 'allergens' => $alg, 'days' => $days, 'today' => rzd_ed_today() ) );
} );

add_action( 'wp_ajax_rzd_ed_get', function () {
	rzd_ed_guard();
	$p = wc_get_product( absint( rzd_ed_post( 'id', 0 ) ) );
	if ( ! $p ) {
		wp_send_json_error( array( 'msg' => 'Nie ma takiego produktu.' ) );
	}
	wp_send_json_success( rzd_ed_product_data( $p ) );
} );

add_action( 'wp_ajax_rzd_ed_save', function () {
	rzd_ed_guard();
	$p = wc_get_product( absint( rzd_ed_post( 'id', 0 ) ) );
	if ( ! $p ) {
		wp_send_json_error( array( 'msg' => 'Nie ma takiego produktu.' ) );
	}
	$f = json_decode( (string) rzd_ed_post( 'data', '{}' ), true );
	$f = is_array( $f ) ? $f : array();

	if ( isset( $f['name'] ) ) {
		$name = trim( sanitize_text_field( $f['name'] ) );
		if ( '' === $name ) {
			wp_send_json_error( array( 'msg' => 'Nazwa nie może być pusta.' ) );
		}
		$p->set_name( $name );
	}
	if ( isset( $f['price'] ) && $p->is_type( 'simple' ) ) {
		$raw = trim( str_replace( array( ' ', "\xc2\xa0", 'zł' ), '', (string) $f['price'] ) );
		$raw = str_replace( ',', '.', $raw );
		if ( '' !== $raw ) {
			if ( ! is_numeric( $raw ) || (float) $raw < 0 ) {
				wp_send_json_error( array( 'msg' => 'Cena musi być liczbą, np. 37,00.' ) );
			}
			$p->set_regular_price( wc_format_decimal( $raw, 2 ) ); // brutto – jak wszędzie w projekcie
		}
	}
	$data = rzd_ed_product_data( $p );
	if ( isset( $f['short'] ) && ! $data['short_lock'] ) {
		$p->set_short_description( wp_kses_post( trim( (string) $f['short'] ) ) );
	}
	if ( isset( $f['desc'] ) && ! $data['desc_lock'] ) {
		$p->set_description( wp_kses_post( trim( (string) $f['desc'] ) ) );
	}
	$p->save();

	if ( isset( $f['allergens'] ) && taxonomy_exists( 'alergen' ) ) {
		$valid = get_terms( array( 'taxonomy' => 'alergen', 'hide_empty' => false, 'fields' => 'ids' ) );
		$ids   = array_values( array_intersect( array_map( 'intval', (array) $f['allergens'] ), is_wp_error( $valid ) ? array() : array_map( 'intval', $valid ) ) );
		wp_set_object_terms( $p->get_id(), $ids, 'alergen' );
	}
	if ( isset( $f['soldout'] ) && is_array( $f['soldout'] ) ) {
		rzd_soldout_save( $p->get_id(), ! empty( $f['soldout']['always'] ), isset( $f['soldout']['dates'] ) ? (array) $f['soldout']['dates'] : array() );
	}
	rzd_ed_clear_caches();
	wc_delete_product_transients( $p->get_id() );
	$p = wc_get_product( $p->get_id() );
	wp_send_json_success( array( 'row' => rzd_ed_row( $p ), 'product' => rzd_ed_product_data( $p ) ) );
} );

// Zdjęcie: plik już zmniejszony w przeglądarce (JPG ~1600 px); i tak sprawdzamy typ i rozmiar.
add_action( 'wp_ajax_rzd_ed_photo', function () {
	rzd_ed_guard();
	$pid = absint( rzd_ed_post( 'id', 0 ) );
	$p   = wc_get_product( $pid );
	if ( ! $p || empty( $_FILES['file'] ) ) {
		wp_send_json_error( array( 'msg' => 'Brak pliku albo produktu.' ) );
	}
	$file = $_FILES['file']; // phpcs:ignore
	if ( ! empty( $file['error'] ) || (int) $file['size'] > 12 * MB_IN_BYTES ) {
		wp_send_json_error( array( 'msg' => 'Plik jest za duży albo nie dotarł (max 12 MB).' ) );
	}
	$chk = wp_check_filetype_and_ext( $file['tmp_name'], $file['name'], array( 'jpg|jpeg|jpe' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp' ) );
	if ( empty( $chk['type'] ) ) {
		wp_send_json_error( array( 'msg' => 'To nie jest zdjęcie (JPG, PNG albo WebP).' ) );
	}
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	$_FILES['file']['name'] = sanitize_file_name( sanitize_title( $p->get_name() ) . '.' . ( 'image/png' === $chk['type'] ? 'png' : ( 'image/webp' === $chk['type'] ? 'webp' : 'jpg' ) ) );
	$att = media_handle_upload( 'file', $pid, array( 'post_title' => $p->get_name() ), array( 'test_form' => false, 'mimes' => array( 'jpg|jpeg|jpe' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp' ) ) );
	if ( is_wp_error( $att ) ) {
		wp_send_json_error( array( 'msg' => 'Nie udało się zapisać zdjęcia: ' . $att->get_error_message() ) );
	}
	update_post_meta( $att, '_wp_attachment_image_alt', $p->get_name() );
	$p->set_image_id( $att );
	$p->save();
	rzd_ed_clear_caches();
	$p = wc_get_product( $pid );
	wp_send_json_success( array( 'img' => rzd_ed_thumb( $att, 'medium_large' ), 'row' => rzd_ed_row( $p ) ) );
} );

add_action( 'wp_ajax_rzd_ed_day', function () {
	rzd_ed_guard();
	$set  = absint( rzd_ed_post( 'set', 0 ) );
	$date = (string) rzd_ed_post( 'date', '' );
	if ( ! $set || ! rzd_ed_is_set( $set ) || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
		wp_send_json_error( array( 'msg' => 'Nieprawidłowy zestaw albo dzień.' ) );
	}
	wp_send_json_success( rzd_ed_day_data( $set, $date ) );
} );

add_action( 'wp_ajax_rzd_ed_day_save', function () {
	rzd_ed_guard();
	$set  = absint( rzd_ed_post( 'set', 0 ) );
	$date = (string) rzd_ed_post( 'date', '' );
	$own  = json_decode( (string) rzd_ed_post( 'owners', '{}' ), true );
	if ( ! $set || ! rzd_ed_is_set( $set ) || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) || ! is_array( $own ) || ! $own ) {
		wp_send_json_error( array( 'msg' => 'Nie ma czego zapisać.' ) );
	}
	if ( $date < rzd_ed_today() ) {
		wp_send_json_error( array( 'msg' => 'Minionych dni nie zmieniamy.' ) );
	}
	// Wolno zapisać tylko zestawy z drzewa tego zestawu na ten dzień.
	$owners = array();
	$info   = array();
	rzd_ed_day_owners( $set, $date, $owners, $info );
	$clean = array();
	foreach ( $own as $oid => $items ) {
		$oid = (int) $oid;
		if ( ! isset( $owners[ $oid ] ) || ! is_array( $items ) ) {
			continue;
		}
		$list = array();
		foreach ( $items as $it ) {
			$pid = isset( $it['product_id'] ) ? absint( $it['product_id'] ) : 0;
			if ( ! $pid || $pid === $oid || ! wc_get_product( $pid ) ) {
				continue;
			}
			$row = array( 'product_id' => $pid, 'type' => ( isset( $it['type'] ) && 'addon' === $it['type'] ) ? 'addon' : 'main' );
			if ( ! empty( $it['photo'] ) ) {
				$row['photo'] = 1;
			}
			$list[] = $row;
		}
		$clean[ $oid ] = $list;
	}
	if ( ! $clean ) {
		wp_send_json_error( array( 'msg' => 'Nie ma czego zapisać.' ) );
	}
	// Ostrzeżenie: na ten dzień są już złożone zamówienia ze starym składem (decyzja użytkownika).
	if ( '1' !== (string) rzd_ed_post( 'confirm', '' ) ) {
		$aff = array_values( array_unique( array_merge( array_keys( $owners ), rzd_ed_set_parents( $set ) ) ) );
		$o   = rzd_ed_orders_with_sets( $date, array_map( 'intval', $aff ) );
		if ( $o['count'] ) {
			wp_send_json_success( array( 'confirm' => sprintf(
				'Na %1$s są już złożone zamówienia z tym zestawem: %2$d. Mają zapisany stary skład (%3$s) – zmiana go w nich NIE poprawi, kuchnia przygotuje to, co w zamówieniach. Zapisać mimo to?',
				rzd_ed_day_label( $date ),
				$o['count'],
				$o['sklady'] ? implode( ' / ', $o['sklady'] ) : 'bez nazw'
			) ) );
		}
	}
	foreach ( $clean as $oid => $list ) {
		rzd_ed_write_day( $oid, $date, $list );
	}
	rzd_ed_clear_caches();
	wp_send_json_success( array( 'saved' => true ) );
} );

// Dania do wyboru: ostatnio w zestawach (z datą) + wyszukiwanie.
add_action( 'wp_ajax_rzd_ed_dishes', function () {
	rzd_ed_guard();
	$q    = trim( sanitize_text_field( (string) rzd_ed_post( 'q', '' ) ) );
	$last = array();
	if ( function_exists( 'rzd_all_sets' ) ) {
		foreach ( rzd_all_sets() as $sid ) {
			foreach ( rwz_get_slots( $sid ) as $slot ) {
				$d = ! empty( $slot['date'] ) ? (string) $slot['date'] : '';
				foreach ( ( isset( $slot['items'] ) && is_array( $slot['items'] ) ) ? $slot['items'] : array() as $it ) {
					$pid = ! empty( $it['product_id'] ) ? (int) $it['product_id'] : 0;
					if ( ! $pid || rzd_ed_is_set( $pid ) ) {
						continue;
					}
					if ( ! isset( $last[ $pid ] ) || $d > $last[ $pid ] ) {
						$last[ $pid ] = $d;
					}
				}
			}
		}
	}
	$ids = array();
	if ( '' !== $q ) {
		$found = get_posts( array( 'post_type' => 'product', 'post_status' => array( 'publish', 'private' ), 'numberposts' => 30, 'fields' => 'ids', 's' => $q, 'orderby' => 'title', 'order' => 'ASC', 'suppress_filters' => false ) );
		foreach ( $found as $id ) {
			if ( ! rzd_ed_is_set( $id ) ) {
				$ids[] = (int) $id;
			}
		}
	} else {
		arsort( $last );
		$ids = array_slice( array_keys( $last ), 0, 25 );
	}
	$out = array();
	foreach ( $ids as $id ) {
		$p = wc_get_product( $id );
		if ( ! $p ) {
			continue;
		}
		$role  = function_exists( 'rwz_get_set_role' ) ? rwz_get_set_role( $id ) : array( 'label' => '' );
		$out[] = array(
			'id'    => $id,
			'name'  => $p->get_name(),
			'thumb' => rzd_ed_thumb( get_post_thumbnail_id( $id ) ),
			'role'  => $role['label'],
			'last'  => ! empty( $last[ $id ] ) ? 'ostatnio: ' . rzd_ed_day_label( $last[ $id ] ) : ( isset( $last[ $id ] ) ? 'w regule zestawu' : '' ),
		);
	}
	wp_send_json_success( array( 'dishes' => $out ) );
} );

// Nowe danie: kategorie, cena, rola, grupy modyfikacji i opakowanie jak u dania-wzoru (tej samej roli).
add_action( 'wp_ajax_rzd_ed_new_dish', function () {
	rzd_ed_guard();
	$name = trim( sanitize_text_field( (string) rzd_ed_post( 'name', '' ) ) );
	if ( '' === $name ) {
		wp_send_json_error( array( 'msg' => 'Podaj nazwę dania.' ) );
	}
	$like = wc_get_product( absint( rzd_ed_post( 'like', 0 ) ) );
	$p    = new WC_Product_Simple();
	$p->set_name( $name );
	$p->set_status( 'publish' );
	$p->set_short_description( wp_kses_post( trim( (string) rzd_ed_post( 'short', '' ) ) ) );
	$cat = absint( rzd_ed_post( 'cat', 0 ) );
	if ( $cat && term_exists( $cat, 'product_cat' ) ) {
		$p->set_category_ids( array( $cat ) ); // wybrana w oknie (nowe danie bez dania-wzoru)
	}
	if ( $like && ! rzd_ed_is_set( $like->get_id() ) ) {
		$p->set_category_ids( $like->get_category_ids() );
		if ( '' !== $like->get_regular_price() ) {
			$p->set_regular_price( $like->get_regular_price() );
		}
	}
	$id = $p->save();
	if ( ! $id ) {
		wp_send_json_error( array( 'msg' => 'Nie udało się utworzyć dania.' ) );
	}
	if ( $like && ! rzd_ed_is_set( $like->get_id() ) ) {
		$lid = $like->get_id();
		foreach ( array( '_rzd_modifiers', '_rwz_set_order', '_rzd_packaging', '_rzd_prod_pack_capacity' ) as $k ) {
			$v = get_post_meta( $lid, $k, true );
			if ( '' !== $v && null !== $v ) {
				update_post_meta( $id, $k, $v );
			}
		}
		$labels = wp_get_object_terms( $lid, 'rzd_set_label', array( 'fields' => 'ids' ) );
		if ( ! is_wp_error( $labels ) && $labels ) {
			wp_set_object_terms( $id, array_map( 'intval', $labels ), 'rzd_set_label' );
		}
	}
	$alg = json_decode( (string) rzd_ed_post( 'allergens', '[]' ), true );
	if ( is_array( $alg ) && taxonomy_exists( 'alergen' ) ) {
		wp_set_object_terms( $id, array_map( 'intval', $alg ), 'alergen' );
	}
	rzd_ed_clear_caches();
	$p = wc_get_product( $id );
	wp_send_json_success( array( 'id' => $id, 'row' => rzd_ed_row( $p ), 'info' => rzd_ed_dish_info( $id, rzd_ed_today() ) ) );
} );

/* ============================================================
 * 5. SHORTCODE [edycja_produktow]
 * ============================================================ */
add_shortcode( 'edycja_produktow', function () {
	if ( ! is_user_logged_in() ) {
		return '<div class="rzd-ed-login" style="max-width:420px;margin:30px auto;font-size:16px">'
			. '<h2 style="margin:0 0 12px">Edycja menu</h2><p>Zaloguj się kontem redaktora menu.</p>'
			. wp_login_form( array( 'echo' => false, 'redirect' => get_permalink(), 'remember' => true, 'value_remember' => true ) )
			. '</div>';
	}
	if ( ! rzd_ed_can() ) {
		return '<p style="margin:30px auto;max-width:420px">To konto nie ma uprawnień do edycji menu. Poproś administratora o rolę „Redaktor menu”.</p>';
	}
	$ver = defined( 'RZD_PLUGIN_VERSION' ) ? RZD_PLUGIN_VERSION : '1';
	$js  = RZD_PLUGIN_DIR . 'assets/js/rzd-edycja.js';
	wp_enqueue_script( 'rzd-edycja', RZD_PLUGIN_URL . 'assets/js/rzd-edycja.js', array(), $ver . '.' . (int) @filemtime( $js ), true ); // phpcs:ignore
	wp_add_inline_script( 'rzd-edycja', 'window.rzdEd = ' . wp_json_encode( array(
		'ajax'    => admin_url( 'admin-ajax.php' ),
		'nonce'   => wp_create_nonce( 'rzd_ed' ),
		'logout'  => wp_logout_url( get_permalink() ),
		'home'    => home_url( '/' ),
		'user'    => wp_get_current_user()->display_name,
	) ) . ';', 'before' );
	return '<div id="rzd-ed" class="rzd-ed"><div class="rzd-ed-loading">Wczytuję menu…</div></div>' . rzd_ed_css();
} );

function rzd_ed_css() {
	$c = '#rzd-ed{position:fixed;inset:0;z-index:999990;background:#FBF8F3;color:#2A2522;font-family:Lato,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;font-size:16px;line-height:1.4;display:flex;flex-direction:column;overflow:hidden;-webkit-text-size-adjust:100%}'
		. '#rzd-ed *{box-sizing:border-box}'
		. '#rzd-ed button,#rzd-ed input,#rzd-ed textarea,#rzd-ed select{font:inherit;color:inherit;margin:0;letter-spacing:normal;text-transform:none;box-shadow:none}'
		. '#rzd-ed .rzd-ed-loading{margin:auto;color:#6E645C}'
		. '#rzd-ed .ed-wrap{width:100%;max-width:640px;margin:0 auto;display:flex;flex-direction:column;flex:1;min-height:0}'
		. '#rzd-ed .ed-head{flex:none;padding:16px 16px 12px;border-bottom:1px solid #E8E0D5;display:flex;flex-direction:column;gap:12px;background:#FBF8F3}'
		. '#rzd-ed .ed-top{display:flex;align-items:center;gap:8px}'
		. '#rzd-ed .ed-top h1{margin:0;flex:1;font-family:"Playfair Display",Georgia,serif;font-size:24px;font-weight:700;line-height:1.2;color:#2A2522}'
		. '#rzd-ed .ed-top small{color:#6E645C;font-size:13px}'
		. '#rzd-ed .ed-ico{display:inline-flex;align-items:center;justify-content:center;width:44px;height:44px;border-radius:22px;border:0;background:transparent;cursor:pointer;padding:0;flex:none;text-decoration:none;color:#2A2522}'
		. '#rzd-ed .ed-ico svg{width:22px;height:22px}'
		. '#rzd-ed .ed-tabs{display:grid;grid-template-columns:1fr 1fr;background:#F1EAE0;border-radius:12px;padding:4px;gap:4px}'
		. '#rzd-ed .ed-tabs button{height:42px;border-radius:9px;border:0;background:transparent;color:#5C524A;cursor:pointer;font-size:15px}'
		. '#rzd-ed .ed-tabs button.on{background:#fff;font-weight:700;color:#2A2522;box-shadow:0 1px 2px rgba(42,37,34,.12)}'
		. '#rzd-ed .ed-search{display:flex;align-items:center;gap:10px;height:48px;padding:0 14px;background:#fff;border:1px solid #E0D6C9;border-radius:12px}'
		. '#rzd-ed .ed-search input{border:0;outline:0;flex:1;min-width:0;background:transparent;font-size:16px;padding:0;height:auto}'
		. '#rzd-ed .ed-chips{display:flex;gap:8px;overflow-x:auto;margin:0 -16px;padding:0 16px 2px;scrollbar-width:none}'
		. '#rzd-ed .ed-chip{flex:none;height:40px;padding:0 16px;border-radius:20px;border:1px solid #D9CEC0;background:#fff;cursor:pointer;white-space:nowrap;font-size:14px}'
		. '#rzd-ed .ed-chip.on{background:#2A2522;border-color:#2A2522;color:#fff;font-weight:700}'
		. '#rzd-ed .ed-body{flex:1;overflow-y:auto;-webkit-overflow-scrolling:touch;padding:4px 16px 120px}'
		. '#rzd-ed .ed-row{display:flex;align-items:center;gap:14px;width:100%;padding:12px 0;border:0;border-bottom:1px solid #ECE4D9;background:transparent;text-align:left;cursor:pointer;min-height:64px}'
		. '#rzd-ed .ed-th{flex:none;width:56px;height:56px;border-radius:12px;background:#E8DFD3 center/cover no-repeat;object-fit:cover}'
		. '#rzd-ed .ed-rt{flex:1;min-width:0;display:flex;flex-direction:column;gap:3px}'
		. '#rzd-ed .ed-rt b{font-size:16px;line-height:1.25}'
		. '#rzd-ed .ed-rt span{font-size:13px;color:#6E645C}'
		. '#rzd-ed .ed-pr{font-family:Oswald,sans-serif;font-size:17px;white-space:nowrap}'
		. '#rzd-ed .ed-pr.mut{color:#6E645C;font-family:inherit;font-size:13px}'
		. '#rzd-ed .ed-badge{align-self:flex-start;margin-top:2px;font-size:12px;font-weight:700;color:#fff;background:#A84D0C;border-radius:6px;padding:2px 8px}'
		. '#rzd-ed .ed-badge.gray{background:#6E645C}'
		. '#rzd-ed .ed-rt .ed-badge{color:#fff;font-size:12px}'
		. '#rzd-ed .ed-foot{position:absolute;left:0;right:0;bottom:0;padding:12px 16px calc(16px + env(safe-area-inset-bottom));background:#FBF8F3;border-top:1px solid #E8E0D5}'
		. '#rzd-ed .ed-foot .ed-wrap{flex-direction:row;gap:10px}'
		. '#rzd-ed .ed-btn{display:flex;align-items:center;justify-content:center;gap:8px;min-height:52px;padding:0 16px;border-radius:14px;border:1px solid #D9CEC0;background:#fff;cursor:pointer;font-size:16px;text-decoration:none;color:#2A2522;flex:1}'
		. '#rzd-ed .ed-btn.pri{background:#FBF1E1;border:1.5px solid #8A5A2B;font-weight:700;flex:2}'
		. '#rzd-ed .ed-btn.sm{min-height:42px;font-size:14px;border-radius:10px;flex:none}'
		. '#rzd-ed .ed-btn[disabled]{opacity:.55;cursor:default}'
		. '#rzd-ed .ed-field{display:flex;flex-direction:column;gap:6px;margin:0 0 18px}'
		. '#rzd-ed .ed-field>span{font-size:14px;font-weight:700}'
		. '#rzd-ed .ed-field>span em{font-weight:400;font-style:normal;color:#6E645C}'
		. '#rzd-ed .ed-in{width:100%;min-height:48px;padding:10px 14px;border:1px solid #D9CEC0;border-radius:12px;background:#fff;font-size:16px;outline:0}'
		. '#rzd-ed .ed-in:focus{border-color:#8A5A2B}'
		. '#rzd-ed textarea.ed-in{resize:vertical;line-height:1.45}'
		. '#rzd-ed .ed-note{padding:12px 14px;border-radius:12px;background:#F3ECE2;font-size:14px;line-height:1.45;color:#4A4039;margin:0 0 18px}'
		. '#rzd-ed .ed-note.warn{background:#FFF4EC;border:1px solid #E0A57A;color:#7A3606}'
		. '#rzd-ed .ed-photo{position:relative;height:240px;border-radius:16px;background:#E8DFD3 center/cover no-repeat;display:flex;align-items:flex-end;justify-content:center;gap:10px;padding:14px;margin:12px 0 18px}'
		. '#rzd-ed .ed-photo label{display:inline-flex;align-items:center;gap:8px;min-height:46px;padding:0 16px;border-radius:12px;background:rgba(255,255,255,.92);font-weight:700;font-size:15px;cursor:pointer}'
		. '#rzd-ed .ed-photo input{position:absolute;width:1px;height:1px;opacity:0;pointer-events:none}'
		. '#rzd-ed .ed-photo .ed-empty{position:absolute;top:12px;left:14px;font-size:13px;background:rgba(255,255,255,.8);padding:3px 8px;border-radius:6px}'
		. '#rzd-ed .ed-box{padding:14px;border-radius:14px;background:#fff;border:1px solid #E0D6C9;margin:0 0 18px;display:flex;flex-direction:column;gap:12px}'
		. '#rzd-ed .ed-sw{display:flex;align-items:center;justify-content:space-between;gap:12px;min-height:44px;cursor:pointer}'
		. '#rzd-ed .ed-sw input{width:26px;height:26px;accent-color:#A84D0C;flex:none}'
		. '#rzd-ed .ed-sw b{display:block;font-size:16px}'
		. '#rzd-ed .ed-sw small{display:block;font-size:13px;color:#6E645C}'
		. '#rzd-ed .ed-seg{display:grid;grid-template-columns:repeat(3,1fr);gap:6px}'
		. '#rzd-ed .ed-seg button{min-height:44px;border-radius:10px;border:1px solid #D9CEC0;background:#FBF8F3;cursor:pointer;font-size:13px;line-height:1.2;padding:4px}'
		. '#rzd-ed .ed-seg button.on{background:#2A2522;color:#fff;border-color:#2A2522;font-weight:700}'
		. '#rzd-ed .ed-alg{display:flex;flex-wrap:wrap;gap:8px}'
		. '#rzd-ed .ed-alg button{min-height:40px;padding:0 12px;border-radius:20px;border:1px solid #D9CEC0;background:#fff;cursor:pointer;font-size:14px}'
		. '#rzd-ed .ed-alg button.on{background:#FBF1E1;border:1.5px solid #8A5A2B;font-weight:700}'
		. '#rzd-ed .ed-sets{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:8px}'
		. '#rzd-ed .ed-sets button{display:flex;flex-direction:column;align-items:flex-start;gap:2px;min-height:56px;padding:8px 12px;border-radius:12px;border:1px solid #D9CEC0;background:#fff;cursor:pointer;text-align:left;font-size:14px}'
		. '#rzd-ed .ed-sets button.on{background:#FBF1E1;border:1.5px solid #8A5A2B}'
		. '#rzd-ed .ed-sets b{font-size:14px}'
		. '#rzd-ed .ed-sets span{font-family:Oswald,sans-serif;font-size:15px}'
		. '#rzd-ed .ed-days{display:flex;gap:6px;overflow-x:auto;margin:0 -16px;padding:0 16px 2px;scrollbar-width:none}'
		. '#rzd-ed .ed-days button{flex:none;display:flex;flex-direction:column;align-items:center;justify-content:center;width:54px;height:64px;border-radius:12px;border:1px solid #D9CEC0;background:#fff;cursor:pointer;line-height:1.15}'
		. '#rzd-ed .ed-days button b{font-size:18px}'
		. '#rzd-ed .ed-days button small{font-size:11px}'
		. '#rzd-ed .ed-days button.on{background:#2A2522;color:#fff;border-color:#2A2522}'
		. '#rzd-ed .ed-prev{display:flex;gap:14px;align-items:center;margin:16px 0}'
		. '#rzd-ed .ed-prev .ed-th{width:96px;height:96px;border-radius:14px}'
		. '#rzd-ed .ed-prev small{display:block;font-size:12px;color:#6E645C;text-transform:uppercase;letter-spacing:.06em}'
		. '#rzd-ed .ed-prev b{display:block;font-family:"Playfair Display",Georgia,serif;font-size:19px;line-height:1.25}'
		. '#rzd-ed .ed-dish{display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid #ECE4D9}'
		. '#rzd-ed .ed-dish:last-of-type{border-bottom:0}'
		. '#rzd-ed .ed-dish .ed-th{width:48px;height:48px;border-radius:10px}'
		. '#rzd-ed .ed-x{flex:none;width:40px;height:40px;border-radius:10px;border:1px solid #D9CEC0;background:#fff;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;padding:0}'
		. '#rzd-ed .ed-add{display:flex;align-items:center;gap:10px;min-height:48px;border:0;background:transparent;color:#5C3A1A;font-weight:700;cursor:pointer;padding:0;font-size:15px}'
		. '#rzd-ed h2.ed-h{margin:22px 0 10px;font-family:"Playfair Display",Georgia,serif;font-size:19px;font-weight:700;color:#2A2522}'
		. '#rzd-ed .ed-sheet{position:absolute;inset:0;background:rgba(42,37,34,.55);display:flex;align-items:flex-end;justify-content:center;z-index:5}'
		. '#rzd-ed .ed-sheet>div{width:100%;max-width:640px;height:92%;background:#FBF8F3;border-radius:22px 22px 0 0;display:flex;flex-direction:column}'
		. '#rzd-ed .ed-toast{position:absolute;left:50%;bottom:96px;transform:translateX(-50%);background:#2A2522;color:#fff;padding:10px 16px;border-radius:12px;font-size:14px;z-index:9;max-width:90%;text-align:center}'
		. '#rzd-ed .ed-toast.err{background:#A84D0C}'
		. '#rzd-ed .ed-hide{display:none!important}';
	return '<style id="rzd-ed-css">' . $c . '</style>';
}
