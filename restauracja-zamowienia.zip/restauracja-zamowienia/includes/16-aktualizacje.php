<?php
/**
 * MODUŁ 16: Aktualizacje — podpięcie pod natywny mechanizm WordPressa
 *
 * Ta wtyczka nie jest w oficjalnym repozytorium WordPress.org, więc sama
 * z siebie WordPress nigdy nie sprawdzi, czy jest nowsza wersja. Ten moduł
 * dopina ją "ręcznie" do TEGO SAMEGO mechanizmu, którego WordPress używa
 * dla zwykłych wtyczek: strona Wtyczki pokaże "Dostępna jest aktualizacja",
 * a "Aktualizuj teraz" zadziała jednym kliknięciem, bez usuwania niczego.
 *
 * Jak to działa: co jakiś czas WordPress i tak sam pyta (w tle) o
 * aktualizacje wszystkich wtyczek. My podpinamy się pod to pytanie
 * (filtr "pre_set_site_transient_update_plugins") i sami odpowiadamy,
 * pobierając mały plik update.json spod adresu RZD_UPDATE_MANIFEST_URL –
 * jeśli wersja w tym pliku jest nowsza niż zainstalowana, WordPress
 * pokaże standardowy komunikat o aktualizacji i pobierze zip z adresu
 * podanego w tym samym pliku.
 *
 * KONFIGURACJA: podmień adres niżej (RZD_UPDATE_MANIFEST_URL) na miejsce,
 * gdzie faktycznie hostujesz plik update.json (np. link "raw" do pliku
 * w repozytorium na GitHubie). Format tego pliku – patrz przykład na
 * końcu tego modułu, w komentarzu.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'RZD_UPDATE_MANIFEST_URL' ) ) {
	// PODMIEŃ na własny adres, np.:
	// https://raw.githubusercontent.com/TWOJ-LOGIN/TWOJE-REPO/main/update.json
	define( 'RZD_UPDATE_MANIFEST_URL', 'https://raw.githubusercontent.com/78skwara-coder/restauracja-zamowienia/main/update.json' );
}

function rzd_update_plugin_file() {
	// Ścieżka "folder/plik.php" względem wp-content/plugins – dokładnie
	// tak, jak WordPress identyfikuje każdą wtyczkę wewnętrznie.
	return plugin_basename( dirname( __DIR__ ) . '/restauracja-zamowienia.php' );
}

function rzd_update_fetch_manifest() {
	if ( ! RZD_UPDATE_MANIFEST_URL ) {
		return null;
	}
	static $cached = null; // jedno zapytanie sieciowe na cały request, nie na każde wywołanie
	if ( null !== $cached ) {
		return $cached;
	}
	$resp = wp_remote_get( RZD_UPDATE_MANIFEST_URL, array( 'timeout' => 8 ) );
	if ( is_wp_error( $resp ) || 200 !== (int) wp_remote_retrieve_response_code( $resp ) ) {
		return $cached = false;
	}
	$data = json_decode( wp_remote_retrieve_body( $resp ) );
	return $cached = ( $data && ! empty( $data->version ) ) ? $data : false;
}

add_filter( 'pre_set_site_transient_update_plugins', function ( $transient ) {
	if ( empty( $transient ) || ! is_object( $transient ) ) {
		return $transient;
	}
	$manifest = rzd_update_fetch_manifest();
	if ( ! $manifest ) {
		return $transient;
	}
	$plugin_file    = rzd_update_plugin_file();
	$plugin_data    = get_plugin_data( WP_PLUGIN_DIR . '/' . $plugin_file, false, false );
	$current_version = isset( $plugin_data['Version'] ) ? $plugin_data['Version'] : '0';

	if ( version_compare( $manifest->version, $current_version, '>' ) ) {
		$item              = new stdClass();
		$item->slug        = dirname( $plugin_file );
		$item->plugin      = $plugin_file;
		$item->new_version = $manifest->version;
		$item->url         = isset( $manifest->homepage ) ? $manifest->homepage : '';
		$item->package     = isset( $manifest->download_url ) ? $manifest->download_url : '';
		$item->tested      = isset( $manifest->tested ) ? $manifest->tested : '';
		$transient->response[ $plugin_file ] = $item;
	} else {
		// Jawnie mówimy WordPressowi "to jest aktualne" – inaczej ekran
		// wtyczek potrafi pokazywać stan "sprawdzanie..." w nieskończoność.
		$item              = new stdClass();
		$item->slug        = dirname( $plugin_file );
		$item->plugin      = $plugin_file;
		$item->new_version = $current_version;
		$transient->no_update[ $plugin_file ] = $item;
	}
	return $transient;
} );

/**
 * 2.26.1: nazwa folderu przy aktualizacji. WordPress rozpakowuje zip i instaluje
 * go do folderu o nazwie z zipa – jeśli wtyczka siedzi w folderze o innej nazwie
 * (np. „restauracja-zamowienia2_26_0”, bo tak nazywał się wgrany plik), powstałby
 * drugi folder obok i błąd „Cannot redeclare”. Tu zmieniamy nazwę rozpakowanego
 * folderu na nazwę folderu, w którym wtyczka jest zainstalowana TERAZ.
 */
add_filter( 'upgrader_source_selection', function ( $source, $remote_source, $upgrader, $hook_extra = array() ) {
	global $wp_filesystem;
	if ( empty( $hook_extra['plugin'] ) || rzd_update_plugin_file() !== $hook_extra['plugin'] || is_wp_error( $source ) ) {
		return $source;
	}
	$want = trailingslashit( $remote_source ) . dirname( rzd_update_plugin_file() );
	if ( untrailingslashit( $source ) === untrailingslashit( $want ) ) {
		return $source;
	}
	if ( untrailingslashit( $source ) === untrailingslashit( $remote_source ) ) {
		// Zip bez folderu w środku – tego nie przeniesiemy bezpiecznie.
		return new WP_Error( 'rzd_zip_layout', 'Zip aktualizacji musi mieć w środku folder „restauracja-zamowienia/”.' );
	}
	if ( $wp_filesystem && $wp_filesystem->move( untrailingslashit( $source ), $want, true ) ) {
		return trailingslashit( $want );
	}
	return new WP_Error( 'rzd_rename', 'Nie udało się przygotować folderu aktualizacji.' );
}, 10, 4 );

// Okienko "Zobacz szczegóły wersji" na ekranie Wtyczki (opcjonalne, ale wygodne).
add_filter( 'plugins_api', function ( $result, $action, $args ) {
	if ( 'plugin_information' !== $action || empty( $args->slug ) || dirname( rzd_update_plugin_file() ) !== $args->slug ) {
		return $result;
	}
	$manifest = rzd_update_fetch_manifest();
	if ( ! $manifest ) {
		return $result;
	}
	$info              = new stdClass();
	$info->name        = 'Restauracja – Zamówienia i Dostawy';
	$info->slug        = $args->slug;
	$info->version     = $manifest->version;
	$info->sections    = array(
		'changelog' => isset( $manifest->changelog ) ? $manifest->changelog : '',
	);
	$info->download_link = isset( $manifest->download_url ) ? $manifest->download_url : '';
	return $info;
}, 10, 3 );

/**
 * Przykładowa zawartość pliku update.json, który hostujesz pod adresem
 * z RZD_UPDATE_MANIFEST_URL (np. surowy plik na GitHubie):
 *
 * {
 *   "version": "2.10.0",
 *   "download_url": "https://github.com/TWOJ-LOGIN/TWOJE-REPO/releases/download/v2.10.0/restauracja-zamowienia.zip",
 *   "homepage": "https://github.com/TWOJ-LOGIN/TWOJE-REPO",
 *   "tested": "6.7",
 *   "changelog": "<h4>2.10.0</h4><ul><li>Opis zmiany</li></ul>"
 * }
 *
 * Każdą kolejną wersję wgrywasz tak: 1) tworzysz nowy "Release" na GitHubie
 * z plikiem zip dołączonym jako załącznik, 2) podmieniasz "version" i
 * "download_url" w update.json na nowy numer/link. WordPress sam to
 * zauważy przy najbliższym sprawdzeniu (albo od razu, jeśli wejdziesz na
 * ekran Wtyczki – WordPress dorzuca sprawdzenie także wtedy).
 */
