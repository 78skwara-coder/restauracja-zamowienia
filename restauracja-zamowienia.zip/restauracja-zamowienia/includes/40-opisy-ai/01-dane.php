<?php
/**
 * Moduł 40-opisy-ai – opisy dań pisane przez AI (2.52.0). Administrator projektuje formularz (Panel → Opisy AI):
 * pola z instrukcją, jak AI ma potraktować wpisane wartości (np. „każde słowo to osobny podpunkt”, „rozwiń w tym
 * kierunku”), nagłówek części w opisie i do którego opisu pole trafia (krótki / pełny / oba). Przy daniu (Edycja
 * menu) wprowadzający wypełnia pola → „Generuj” → podgląd → „Zatwierdź” zapisuje opisy jak edytor sekcji (moduł 24:
 * format rzd-opis, kopia „Poprzednia wersja”). Wartości pól zapisują się przy daniu (meta _rzd_ai_desc_in).
 * Opcja rzd_aidesc: { rules, fields [ {k, n, t line|text, ph, h, head, lv 2|3|4, to short|long|both, req, on} ] }.
 * Połączenie z AI – Połączenia API (moduł 39). Uprawnienie „Opisy AI” (aidesc).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function rzd_aidesc_default_rules() {
	return implode( "\n", array(
		'Piszesz opisy dań do sklepu internetowego restauracji – po polsku, apetycznie i konkretnie.',
		'Korzystaj tylko z informacji z pól i z nazwy dania – nie wymyślaj składników, gramatur, cen ani alergenów.',
		'Poprawiaj pisownię nazw potraw (np. „devolay” → „de volaille”).',
		'Opis krótki: 1–2 zdania, bez nagłówków i list.',
	) );
}

function rzd_aidesc_default_fields() {
	return array(
		array( 'k' => 'opis', 'n' => 'Opis produktu', 't' => 'text', 'ph' => 'np. długo gotowana zupa ze świeżych składników', 'h' => 'Rozwiń w 2–3 apetyczne zdania w tym kierunku. W opisie krótkim – jedno zdanie.', 'head' => '', 'lv' => 3, 'to' => 'both', 'req' => 1, 'on' => 1 ),
		array( 'k' => 'cechy', 'n' => 'Cechy', 't' => 'line', 'ph' => 'np. świeży, czerwony, słodki', 'h' => 'Każde podane słowo to osobny podpunkt listy: zacznij od tego słowa z dużej litery i dopisz krótkie rozwinięcie (kilka słów).', 'head' => 'Dlaczego warto', 'lv' => 3, 'to' => 'long', 'req' => 0, 'on' => 1 ),
		array( 'k' => 'sklad', 'n' => 'Skład', 't' => 'line', 'ph' => 'np. schab, panierka, ziemniaki, surówka z kapusty', 'h' => 'Wypisz jako listę – każdy składnik w osobnym podpunkcie, z dużej litery, bez gramatur i bez dodawania niczego od siebie.', 'head' => 'Skład', 'lv' => 3, 'to' => 'long', 'req' => 0, 'on' => 1 ),
		array( 'k' => 'podanie', 'n' => 'Jak podajemy', 't' => 'line', 'ph' => 'np. z koperkiem, na gorąco', 'h' => 'Jedno krótkie zdanie o sposobie podania.', 'head' => 'Jak podajemy', 'lv' => 3, 'to' => 'long', 'req' => 0, 'on' => 1 ),
	);
}

function rzd_aidesc_targets() {
	return array( 'short' => 'opis krótki', 'long' => 'opis pełny', 'both' => 'krótki i pełny' );
}

function rzd_aidesc_settings( $reset = false ) {
	static $s = null;
	if ( $reset ) {
		$s = null;
	}
	if ( null !== $s ) {
		return $s;
	}
	$o = get_option( 'rzd_aidesc', null );
	$s = array(
		'rules'  => is_array( $o ) && isset( $o['rules'] ) ? (string) $o['rules'] : rzd_aidesc_default_rules(),
		'fields' => is_array( $o ) && isset( $o['fields'] ) && is_array( $o['fields'] ) ? $o['fields'] : rzd_aidesc_default_fields(),
	);
	$s['fields'] = array_values( array_filter( array_map( 'rzd_aidesc_clean_field', $s['fields'] ) ) );
	return $s;
}

function rzd_aidesc_clean_field( $r ) {
	if ( ! is_array( $r ) ) {
		return null;
	}
	$n = mb_substr( sanitize_text_field( isset( $r['n'] ) ? (string) $r['n'] : '' ), 0, 60 );
	if ( '' === $n ) {
		return null;
	}
	$lv = isset( $r['lv'] ) ? (int) $r['lv'] : 3;
	return array(
		'k'    => sanitize_key( isset( $r['k'] ) && '' !== $r['k'] ? $r['k'] : remove_accents( $n ) ),
		'n'    => $n,
		't'    => isset( $r['t'] ) && 'text' === $r['t'] ? 'text' : 'line',
		'ph'   => mb_substr( sanitize_text_field( isset( $r['ph'] ) ? (string) $r['ph'] : '' ), 0, 160 ),
		'h'    => mb_substr( sanitize_textarea_field( isset( $r['h'] ) ? (string) $r['h'] : '' ), 0, 1000 ),
		'head' => mb_substr( sanitize_text_field( isset( $r['head'] ) ? (string) $r['head'] : '' ), 0, 120 ),
		'lv'   => in_array( $lv, array( 2, 3, 4 ), true ) ? $lv : 3,
		'to'   => isset( $r['to'] ) && isset( rzd_aidesc_targets()[ $r['to'] ] ) ? $r['to'] : 'long',
		'req'  => empty( $r['req'] ) ? 0 : 1,
		'on'   => ! array_key_exists( 'on', $r ) || ! empty( $r['on'] ) ? 1 : 0,
	);
}

/** Zapis z panelu. [ ok, komunikat ]. Klucze pól unikalne – zmiana nazwy pola nie gubi wartości przy daniach. */
function rzd_aidesc_save( $in ) {
	$in     = is_array( $in ) ? $in : array();
	$fields = array();
	$keys   = array();
	foreach ( isset( $in['fields'] ) && is_array( $in['fields'] ) ? $in['fields'] : array() as $i => $r ) {
		$f = rzd_aidesc_clean_field( $r );
		if ( ! $f ) {
			continue;
		}
		if ( '' === $f['k'] || 'krotki' === $f['k'] || isset( $keys[ $f['k'] ] ) ) {
			$f['k'] = 'p' . $i . '_' . wp_rand( 100, 999 );
		}
		$keys[ $f['k'] ] = 1;
		$fields[]        = $f;
	}
	if ( count( $fields ) > 20 ) {
		return array( false, 'Najwyżej 20 pól.' );
	}
	update_option( 'rzd_aidesc', array( 'rules' => mb_substr( sanitize_textarea_field( isset( $in['rules'] ) ? (string) $in['rules'] : '' ), 0, 4000 ), 'fields' => $fields ), false );
	rzd_aidesc_settings( true );
	return array( true, 'Zapisano ustawienia opisów AI.' );
}

/** Aktywne pola. */
function rzd_aidesc_fields() {
	return array_values( array_filter( rzd_aidesc_settings()['fields'], function ( $f ) { return $f['on']; } ) );
}

/** Wartości pól zapisane przy daniu. */
function rzd_aidesc_inputs( $pid ) {
	$v = get_post_meta( (int) $pid, '_rzd_ai_desc_in', true );
	return is_array( $v ) ? $v : array();
}

/** Treść dla AI: [ system, user, keys ] albo komunikat (np. brak wymaganego pola). */
function rzd_aidesc_prompt( $p, $vals ) {
	$s     = rzd_aidesc_settings();
	$lines = array( 'Danie: ' . $p->get_name() . '.' );
	$cats  = wp_get_post_terms( $p->get_id(), 'product_cat', array( 'fields' => 'names' ) );
	if ( ! is_wp_error( $cats ) && $cats ) {
		$lines[] = 'Kategoria: ' . implode( ', ', $cats ) . '.';
	}
	$alg = taxonomy_exists( 'alergen' ) ? wp_get_post_terms( $p->get_id(), 'alergen', array( 'fields' => 'names' ) ) : array();
	if ( ! is_wp_error( $alg ) && $alg ) {
		$lines[] = 'Alergeny (tylko do wiadomości – nie wymieniaj ich w opisie, sklep pokazuje je osobno): ' . implode( ', ', $alg ) . '.';
	}
	$lines[] = '';
	$lines[] = 'Pola formularza – wartości od restauracji i instrukcje, jak je potraktować (instrukcja pola ma pierwszeństwo przed zasadami ogólnymi):';
	$short = false;
	$keys  = array();
	$tg    = rzd_aidesc_targets();
	foreach ( rzd_aidesc_fields() as $f ) {
		$v = isset( $vals[ $f['k'] ] ) ? trim( preg_replace( '/\s*\n\s*/', ' ', (string) $vals[ $f['k'] ] ) ) : '';
		if ( '' === $v ) {
			if ( $f['req'] ) {
				return 'Uzupełnij pole „' . $f['n'] . '”.';
			}
			continue;
		}
		$lines[] = '* „' . $f['n'] . '” (klucz „' . $f['k'] . '”, trafia do: ' . $tg[ $f['to'] ] . ') – wartości: ' . $v . ( '' !== trim( $f['h'] ) ? ' – instrukcja: ' . trim( preg_replace( '/\s*\n\s*/', ' ', $f['h'] ) ) : '' );
		if ( 'long' !== $f['to'] ) {
			$short = true;
		}
		if ( 'short' !== $f['to'] ) {
			$keys[] = $f['k'];
		}
	}
	if ( ! $keys && ! $short ) {
		return 'Wypełnij choć jedno pole.';
	}
	if ( $short ) {
		array_unshift( $keys, 'krotki' );
	}
	$lines[] = '';
	$lines[] = 'Zwróć JSON z kluczami: ' . implode( ', ', $keys ) . '.'
		. ( $short ? ' „krotki” – cały opis krótki, napisany z pól, które trafiają do opisu krótkiego.' : '' )
		. ' Pozostałe klucze – część opisu pełnego z danego pola (bez jego nagłówka – dodamy go sami).'
		. ' Listę pisz jako linie zaczynające się od „- ”; akapity oddzielaj pustą linią; pogrubienie tylko jako **tekst**; bez innego formatowania.';
	return array( 'system' => trim( $s['rules'] ), 'user' => implode( "\n", $lines ), 'keys' => $keys );
}

/** Tekst od AI → HTML dozwolony w opisie: akapity, listy (linie „- ”, „• ”, „* ”, „1. ”), **pogrubienie**. */
function rzd_aidesc_html( $txt ) {
	$txt  = str_replace( "\r", '', trim( (string) $txt ) );
	$out  = '';
	$list = array();
	$para = array();
	$fmt  = function ( $s ) {
		return preg_replace( '/\*\*(.+?)\*\*/u', '<strong>$1</strong>', esc_html( trim( $s ) ) );
	};
	$flush = function () use ( &$out, &$list, &$para, $fmt ) {
		if ( $para ) {
			$out .= '<p>' . implode( '<br>', array_map( $fmt, $para ) ) . '</p>';
			$para = array();
		}
		if ( $list ) {
			$out .= '<ul>' . implode( '', array_map( function ( $x ) use ( $fmt ) { return '<li>' . $fmt( $x ) . '</li>'; }, $list ) ) . '</ul>';
			$list = array();
		}
	};
	foreach ( explode( "\n", $txt ) as $l ) {
		if ( '' === trim( $l ) ) {
			$flush();
			continue;
		}
		if ( preg_match( '/^\s*(?:[-•*–]|\d+[.)])\s+(.+)$/u', $l, $m ) ) {
			if ( $para ) {
				$flush();
			}
			$list[] = $m[1];
			continue;
		}
		if ( $list ) {
			$flush();
		}
		$para[] = $l;
	}
	$flush();
	return function_exists( 'rzd_desc_clean' ) ? rzd_desc_clean( $out ) : $out;
}

/**
 * Generowanie: [ ok, { short: sections, long: sections, short_html, long_html } | komunikat ]. Puste części
 * pomijane; brak pól krótkiego / pełnego → ten opis bez zmian (null).
 */
function rzd_aidesc_generate( $pid, $vals ) {
	$p = wc_get_product( (int) $pid );
	if ( ! $p ) {
		return array( false, 'Nie znaleziono dania.' );
	}
	$clean = array();
	foreach ( rzd_aidesc_settings()['fields'] as $f ) {
		if ( isset( $vals[ $f['k'] ] ) ) {
			$clean[ $f['k'] ] = mb_substr( sanitize_textarea_field( (string) $vals[ $f['k'] ] ), 0, 1000 );
		}
	}
	update_post_meta( $p->get_id(), '_rzd_ai_desc_in', $clean );
	$pr = rzd_aidesc_prompt( $p, $clean );
	if ( ! is_array( $pr ) ) {
		return array( false, $pr );
	}
	list( $ok, $txt ) = rzd_ai_ask( array( 'system' => $pr['system'], 'text' => $pr['user'], 'keys' => $pr['keys'], 'temp' => 0.7 ), 'opis' );
	if ( ! $ok ) {
		return array( false, $txt );
	}
	$j = json_decode( trim( preg_replace( '/^```(?:json)?|```$/m', '', $txt ) ), true );
	if ( ! is_array( $j ) ) {
		return array( false, 'AI nie zwróciło opisu. Spróbuj ponownie albo wybierz inny model (Połączenia API).' );
	}
	$short = null;
	$long  = array();
	if ( in_array( 'krotki', $pr['keys'], true ) && isset( $j['krotki'] ) && is_scalar( $j['krotki'] ) && '' !== trim( (string) $j['krotki'] ) ) {
		$short = array( array( 't' => '', 'lv' => 0, 'cols' => 0, 'html' => rzd_aidesc_html( $j['krotki'] ) ) );
	}
	foreach ( rzd_aidesc_fields() as $f ) {
		if ( 'short' === $f['to'] || ! in_array( $f['k'], $pr['keys'], true ) || ! isset( $j[ $f['k'] ] ) || ! is_scalar( $j[ $f['k'] ] ) ) {
			continue;
		}
		$html = rzd_aidesc_html( $j[ $f['k'] ] );
		if ( '' !== $html ) {
			$long[] = array( 't' => $f['head'], 'lv' => '' !== $f['head'] ? $f['lv'] : 0, 'cols' => 0, 'html' => $html );
		}
	}
	$long = $long ? $long : null;
	if ( ! $short && ! $long ) {
		return array( false, 'AI zwróciło pusty opis. Spróbuj ponownie.' );
	}
	return array( true, array(
		'short'      => $short,
		'long'       => $long,
		'short_html' => $short ? rzd_desc_build( $short, 'short' ) : '',
		'long_html'  => $long ? rzd_desc_build( $long, 'long' ) : '',
	) );
}

/** Czy przy daniu pokazać „Opis z AI”: uprawnienie, połączenie z AI, choć jedno pole. */
function rzd_aidesc_box_data() {
	$can = function_exists( 'rzd_can' ) && rzd_can( 'aidesc' );
	if ( ! $can ) {
		return array( 'on' => false );
	}
	$fields = array_map( function ( $f ) { return array( 'k' => $f['k'], 'n' => $f['n'], 't' => $f['t'], 'ph' => $f['ph'], 'req' => $f['req'] ); }, rzd_aidesc_fields() );
	$ready  = function_exists( 'rzd_ai_ready' ) && rzd_ai_ready();
	return array( 'on' => (bool) $fields, 'ready' => $ready, 'fields' => $fields, 'ai' => function_exists( 'rzd_ai_choices' ) ? rzd_ai_choices() : null, 'note' => $ready ? '' : 'AI nie jest połączone – Panel restauracji → Połączenia API.' );
}
