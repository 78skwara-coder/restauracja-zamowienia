<?php
/**
 * Moduł 40-opisy-ai – Edycja menu: wp_ajax_rzd_ed_ai_desc (nonce i dostęp do Edycji menu – rzd_ed_guard, moduł 22;
 * dodatkowo uprawnienie „Opisy AI”). Zatwierdzenie idzie zwykłym rzd_ed_save (short_doc / desc_doc) – te same
 * sprawdzenia i kopie opisu co edytor sekcji.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'wp_ajax_rzd_ed_ai_desc', function () {
	rzd_ed_guard();
	if ( ! rzd_can( 'aidesc' ) ) {
		wp_send_json_error( array( 'msg' => 'Brak uprawnienia „Opisy AI”.' ), 403 );
	}
	$vals = json_decode( (string) rzd_ed_post( 'vals', '{}' ), true );
	$ai   = (string) rzd_ed_post( 'ai', '' ); // (2.53.0) wybrany dostawca – tylko skonfigurowany
	if ( '' !== $ai ) {
		if ( ! rzd_ai_provider_ready( $ai ) ) {
			wp_send_json_error( array( 'msg' => 'Ten dostawca AI nie jest skonfigurowany – Panel restauracji → Połączenia API.' ) );
		}
		rzd_ai_use( $ai );
	}
	try {
		list( $ok, $r ) = rzd_aidesc_generate( (int) rzd_ed_post( 'id', 0 ), is_array( $vals ) ? $vals : array(), array( // (2.54.0) tryb ze zdjęcia, wskazówki, internet
			'mode' => 'photo' === rzd_ed_post( 'mode', 'form' ) ? 'photo' : 'form',
			'hint' => (string) rzd_ed_post( 'hint', '' ),
			'web'  => (int) rzd_ed_post( 'web', 0 ) ? 1 : 0,
		) );
	} catch ( Throwable $e ) {
		wp_send_json_error( array( 'msg' => 'Błąd przy pisaniu opisu: ' . $e->getMessage() ) );
	}
	if ( ! $ok ) {
		wp_send_json_error( array( 'msg' => $r ) );
	}
	wp_send_json_success( $r );
} );
