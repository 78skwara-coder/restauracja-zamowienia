<?php
/**
 * Moduł 40-opisy-ai – Edycja menu: wp_ajax_rzd_ed_ai_desc (nonce i dostęp do Edycji menu – rzd_ed_guard, moduł 22;
 * dodatkowo uprawnienie „Opisy AI”). Zatwierdzenie idzie zwykłym rzd_ed_save (short_doc / desc_doc) – te same
 * sprawdzenia i kopie opisu co edytor sekcji.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'wp_ajax_rzd_ed_ai_desc', function () {
	rzd_ed_guard();
	if ( ! rzd_can( 'aidesc' ) ) {
		wp_send_json_error( array( 'msg' => 'Brak uprawnienia „Opisy AI”.' ), 403 );
	}
	$vals = json_decode( (string) rzd_ed_post( 'vals', '{}' ), true );
	try {
		list( $ok, $r ) = rzd_aidesc_generate( (int) rzd_ed_post( 'id', 0 ), is_array( $vals ) ? $vals : array() );
	} catch ( Throwable $e ) {
		wp_send_json_error( array( 'msg' => 'Błąd przy pisaniu opisu: ' . $e->getMessage() ) );
	}
	if ( ! $ok ) {
		wp_send_json_error( array( 'msg' => $r ) );
	}
	wp_send_json_success( $r );
} );
