<?php
/**
 * Moduł 18 – Wzory modyfikacji (predefiniowane modyfikacje).
 *
 * - Katalog "Wzory modyfikacji" (CPT rzd_mod_preset, Panel restauracji → Menu → Wzory). Wzór to
 *   nazwa + jedna lub kilka grup modyfikacji, budowanych TYM SAMYM edytorem co
 *   na produkcie (rzd_render_sections_editor() z modułu 10), zapisanych tym
 *   samym czyszczeniem (rzd_sanitize_sections()).
 * - Na produkcie, w zakładce "Możliwe modyfikacje": lista wzorów i przycisk
 *   "Dodaj z predefiniowanych". Przycisk KOPIUJE grupy wzoru na koniec grup
 *   produktu (w przeglądarce, bez zapisu). Utrwalają się dopiero przy
 *   "Aktualizuj" produktu. Po kopii to zwykłe grupy produktu – bez powiązania
 *   ze wzorem: zmiana wzoru NIE poprawia produktów, do których go wstawiono.
 * - Ceny zostają wspólne, bo modyfikacje wskazują Dodatki z katalogu.
 * - Wstawiona grupa pamięta ID wzoru (pole 'preset' – tylko
 *   informacja, np. „ze wzoru: …” na stronie edycji z telefonu, moduł 22;
 *   nadal to KOPIA). Wzór wstawia się też z telefonu (rzd_preset_copy_sections()).
 * - „Duplikuj” na liście wzorów (kopia w szkicu, od razu do edycji)
 *   i „Kopiuj grupę” w edytorze grup (moduł 10).
 *
 * Wzór trzyma dane w meta _rzd_preset_sections – celowo NIE w _rzd_modifiers,
 * bo rzd_products_with_modifiers() (moduł 10) zbiera wszystkie wpisy z tym
 * kluczem i traktowałby wzory jak produkty.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'init', function () {
	register_post_type( 'rzd_mod_preset', array(
		'labels'          => array(
			'name'               => 'Wzory modyfikacji',
			'singular_name'      => 'Wzór modyfikacji',
			'menu_name'          => 'Wzory modyfikacji',
			'add_new'            => 'Dodaj nowy',
			'add_new_item'       => 'Dodaj wzór modyfikacji',
			'edit_item'          => 'Edytuj wzór modyfikacji',
			'new_item'           => 'Nowy wzór',
			'search_items'       => 'Szukaj wzorów',
			'not_found'          => 'Nie znaleziono wzorów',
			'not_found_in_trash' => 'Brak wzorów w koszu',
			'all_items'          => 'Wzory modyfikacji',
		),
		'public'          => false,
		'show_ui'         => true,
		'show_in_menu'    => false, // w menu Restauracja (moduł 00-menu)
		'supports'        => array( 'title' ),
		'capability_type' => 'post',
	) );
} );

/** Grupy zapisane we wzorze. */
function rzd_get_preset_sections( $preset_id ) {
	$s = get_post_meta( $preset_id, '_rzd_preset_sections', true );
	return is_array( $s ) ? array_values( $s ) : array();
}

/** Opublikowane wzory: [ id => tytuł ], alfabetycznie. */
function rzd_get_all_presets() {
	$posts = get_posts( array(
		'post_type'      => 'rzd_mod_preset',
		'post_status'    => 'publish',
		'posts_per_page' => -1,
		'orderby'        => 'title',
		'order'          => 'ASC',
	) );
	$out = array();
	foreach ( $posts as $p ) {
		$out[ $p->ID ] = '' !== $p->post_title ? $p->post_title : ( 'Wzór #' . $p->ID );
	}
	return $out;
}

/* ============================================================
 * 1. ZAPIS WZORU (od 2.45.0 – Panel restauracji → Menu → Wzory modyfikacji;
 *    ekran kokpitu przekierowuje do panelu)
 * ============================================================ */

/**
 * Tworzy / zmienia wzór. $active = widoczny przy wstawianiu (opublikowany), inaczej szkic.
 * $sections – grupy jak w produkcie (czyszczone rzd_sanitize_sections). Zwraca ID albo WP_Error.
 */
function rzd_preset_save( $id, $title, $active, $sections ) {
	$title = trim( sanitize_text_field( (string) $title ) );
	if ( '' === $title ) {
		return new WP_Error( 'title', 'Podaj nazwę wzoru.' );
	}
	$status = $active ? 'publish' : 'draft';
	$id     = absint( $id );
	if ( $id ) {
		if ( 'rzd_mod_preset' !== get_post_type( $id ) ) {
			return new WP_Error( 'id', 'Nie ma takiego wzoru.' );
		}
		wp_update_post( array( 'ID' => $id, 'post_title' => $title, 'post_status' => $status ) );
	} else {
		$id = wp_insert_post( array( 'post_type' => 'rzd_mod_preset', 'post_status' => $status, 'post_title' => $title ), true );
		if ( is_wp_error( $id ) ) {
			return $id;
		}
	}
	$clean = function_exists( 'rzd_sanitize_sections' ) ? rzd_sanitize_sections( (array) $sections ) : array();
	foreach ( $clean as $k => $sec ) {
		unset( $clean[ $k ]['preset'] ); // wzór nie odwołuje się do wzoru
	}
	if ( empty( $clean ) ) {
		delete_post_meta( $id, '_rzd_preset_sections' );
	} else {
		update_post_meta( $id, '_rzd_preset_sections', array_values( $clean ) );
	}
	return (int) $id;
}

/* ============================================================
 * 2. PRODUKT: "Dodaj z predefiniowanych"
 * ============================================================
 * Wywoływane z rzd_render_sections_editor() (moduł 10), tylko na produkcie.
 * Każdy wzór jest wyrenderowany jako szablon; indeksy jego grup to
 * symbole __P0__, __P1__, … – przycisk podmienia je na kolejne wolne numery
 * z licznika data-next na #rzd-sections (ten sam, z którego korzysta
 * "+ Dodaj grupę"), więc grupy wzoru i grupy dodane ręcznie się nie gryzą.
 */

/** Grupy wzoru gotowe do wstawienia jako KOPIA – każda z 'preset' => ID wzoru. */
function rzd_preset_copy_sections( $preset_id ) {
	$out = array();
	foreach ( rzd_get_preset_sections( $preset_id ) as $sec ) {
		$sec['preset'] = (int) $preset_id;
		$out[]         = $sec;
	}
	return $out;
}

function rzd_render_preset_picker() {
	$presets = rzd_get_all_presets();
	$usable  = array();
	foreach ( $presets as $id => $title ) {
		$secs = rzd_preset_copy_sections( $id );
		if ( $secs ) {
			$usable[ $id ] = array( 'title' => $title, 'sections' => $secs );
		}
	}
	$new_url = function_exists( 'rzd_panel_url' ) ? rzd_panel_url( 'menu', array( 'tab' => 'wzory' ) ) : admin_url();

	echo '<div id="rzd-preset-picker" style="margin:4px 12px 14px;padding:10px 12px;border:1px dashed #8a8f99;background:#fbfbfc;">';
	if ( ! $usable ) {
		echo '<span class="description">Nie masz jeszcze żadnego wzoru z grupami. <a href="' . esc_url( $new_url ) . '" target="_blank">Utwórz wzór modyfikacji</a> (np. „wybierz jedno: frytki / ziemniaki / kluski”), a potem wstawisz go tu jednym kliknięciem.</span>';
		echo '</div>';
		return;
	}
	echo '<label for="rzd-preset-select"><strong>Wzór:</strong></label> ';
	echo '<select id="rzd-preset-select" style="min-width:220px;max-width:100%;">';
	foreach ( $usable as $id => $p ) {
		echo '<option value="' . (int) $id . '">' . esc_html( $p['title'] ) . ' (' . count( $p['sections'] ) . ' ' . ( 1 === count( $p['sections'] ) ? 'grupa' : 'grupy' ) . ')</option>';
	}
	echo '</select> ';
	echo '<button type="button" class="button" id="rzd-add-preset">+ Dodaj z predefiniowanych</button>';
	echo '<p class="description" style="margin:6px 0 0;">Wstawia <strong>kopię</strong> grup wzoru na koniec listy powyżej. Możesz ją potem zmienić tylko dla tego produktu. Zapisuje się razem z produktem (przycisk „Aktualizuj”). <a href="' . esc_url( $new_url ) . '" target="_blank">Zarządzaj wzorami</a></p>';
	echo '</div>';

	foreach ( $usable as $id => $p ) {
		$html = '';
		foreach ( $p['sections'] as $k => $sec ) {
			$html .= rzd_render_section( '__P' . $k . '__', $sec );
		}
		echo '<script type="text/html" id="rzd-preset-tpl-' . (int) $id . '" data-count="' . (int) count( $p['sections'] ) . '">' . $html . '</script>';
	}
	?>
	<?php echo rzd_js_tag( 'assets/js/admin/rzd-wzory-wstaw.js' ); // phpcs:ignore ?>
	<?php
}

/* ============================================================
 * 3. KOPIA WZORU (Panel restauracji: „Duplikuj”)
 * ============================================================ */
/** Kopia wzoru (szkic, tytuł z dopiskiem „(kopia)”). Zwraca ID albo 0. */
function rzd_duplicate_preset( $id ) {
	$src = get_post( $id );
	if ( ! $src ) {
		return 0;
	}
	$new = wp_insert_post( array(
		'post_type'   => 'rzd_mod_preset',
		'post_status' => 'draft',
		'post_title'  => $src->post_title . ' (kopia)',
	), true );
	if ( is_wp_error( $new ) || ! $new ) {
		return 0;
	}
	$secs = rzd_get_preset_sections( $id );
	if ( $secs ) {
		update_post_meta( $new, '_rzd_preset_sections', $secs );
	}
	return (int) $new;
}
