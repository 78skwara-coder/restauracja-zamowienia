<?php
/**
 * Moduł 18 – Wzory modyfikacji (predefiniowane modyfikacje), od 2.19.0.
 *
 * - Katalog "Wzory modyfikacji" (CPT rzd_mod_preset, w menu Dodatki). Wzór to
 *   nazwa + jedna lub kilka grup modyfikacji, budowanych TYM SAMYM edytorem co
 *   na produkcie (rzd_render_sections_editor() z modułu 10), zapisanych tym
 *   samym czyszczeniem (rzd_sanitize_sections()).
 * - Na produkcie, w zakładce "Możliwe modyfikacje": lista wzorów i przycisk
 *   "Dodaj z predefiniowanych". Przycisk KOPIUJE grupy wzoru na koniec grup
 *   produktu (w przeglądarce, bez zapisu). Utrwalają się dopiero przy
 *   "Aktualizuj" produktu. Po kopii to zwykłe grupy produktu – bez powiązania
 *   ze wzorem: zmiana wzoru NIE poprawia produktów, do których go wstawiono.
 * - Ceny zostają wspólne, bo modyfikacje wskazują Dodatki z katalogu.
 *
 * Wzór trzyma dane w meta _rzd_preset_sections – celowo NIE w _rzd_modifiers,
 * bo rzd_products_with_modifiers() (moduł 10) zbiera wszystkie wpisy z tym
 * kluczem i traktowałby wzory jak produkty.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'init', function () {
	register_post_type( 'rzd_mod_preset', array(
		'labels'          => array(
			'name'               => 'Wzory modyfikacji',
			'singular_name'      => 'Wzór modyfikacji',
			'menu_name'          => 'Wzory modyfikacji',
			'add_new'            => 'Dodaj nowy',
			'add_new_item'       => 'Dodaj wzór modyfikacji',
			'edit_item'          => 'Edytuj wzór modyfikacji',
			'new_item'           => 'Nowy wzór',
			'search_items'       => 'Szukaj wzorów',
			'not_found'          => 'Nie znaleziono wzorów',
			'not_found_in_trash' => 'Brak wzorów w koszu',
			'all_items'          => 'Wzory modyfikacji',
		),
		'public'          => false,
		'show_ui'         => true,
		'show_in_menu'    => 'edit.php?post_type=rzd_addon', // podmenu "Dodatki"
		'supports'        => array( 'title' ),
		'capability_type' => 'post',
	) );
} );

/** Grupy zapisane we wzorze. */
function rzd_get_preset_sections( $preset_id ) {
	$s = get_post_meta( $preset_id, '_rzd_preset_sections', true );
	return is_array( $s ) ? array_values( $s ) : array();
}

/** Opublikowane wzory: [ id => tytuł ], alfabetycznie. */
function rzd_get_all_presets() {
	$posts = get_posts( array(
		'post_type'      => 'rzd_mod_preset',
		'post_status'    => 'publish',
		'posts_per_page' => -1,
		'orderby'        => 'title',
		'order'          => 'ASC',
	) );
	$out = array();
	foreach ( $posts as $p ) {
		$out[ $p->ID ] = '' !== $p->post_title ? $p->post_title : ( 'Wzór #' . $p->ID );
	}
	return $out;
}

/* ============================================================
 * 1. EKRAN WZORU (edycja)
 * ============================================================ */
add_action( 'admin_enqueue_scripts', function ( $hook ) {
	global $post_type;
	if ( 'rzd_mod_preset' === $post_type && in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) {
		wp_enqueue_media();
		// ta sama naprawa układu co w zakładce produktu (moduł 04)
		if ( function_exists( 'rzd_admin_tabs_layout_fix' ) ) {
			add_action( 'admin_print_styles', 'rzd_admin_tabs_layout_fix' );
		}
	}
} );

add_action( 'add_meta_boxes_rzd_mod_preset', function () {
	add_meta_box( 'rzd_preset_editor', 'Grupy modyfikacji we wzorze', 'rzd_render_preset_metabox', 'rzd_mod_preset', 'normal', 'high' );
} );

function rzd_render_preset_metabox( $post ) {
	wp_nonce_field( 'rzd_save_preset', 'rzd_preset_nonce' );
	echo '<p class="description" style="margin:4px 0 10px;">Zbuduj grupy dokładnie tak jak w zakładce „Możliwe modyfikacje” produktu, np. grupa „Wybierz dodatek” z pojedynczym wyborem: frytki / ziemniaki / kluski. Wzór wstawiasz potem na produkcie przyciskiem <strong>„Dodaj z predefiniowanych”</strong>. Wstawienie robi <strong>kopię</strong>: późniejsza zmiana wzoru nie zmienia produktów, do których już go wstawiono. Ceny biorą się z Dodatków, więc zmiana ceny dodatku działa wszędzie.</p>';
	// id="rzd_mods_data" – żeby zadziałały te same style co na produkcie
	echo '<div id="rzd_mods_data" class="woocommerce_options_panel" style="float:none;width:auto;">';
	if ( function_exists( 'rzd_render_sections_editor' ) ) {
		rzd_render_sections_editor( rzd_get_preset_sections( $post->ID ), false );
	} else {
		echo '<p>Brak edytora modyfikacji (moduł 10).</p>';
	}
	echo '</div>';
}

add_action( 'save_post_rzd_mod_preset', function ( $post_id ) {
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( wp_is_post_revision( $post_id ) ) {
		return;
	}
	if ( ! isset( $_POST['rzd_preset_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['rzd_preset_nonce'] ) ), 'rzd_save_preset' ) ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) || ! function_exists( 'rzd_sanitize_sections' ) ) {
		return;
	}
	$clean = rzd_sanitize_sections( isset( $_POST['rzd_section'] ) ? wp_unslash( $_POST['rzd_section'] ) : array() );
	if ( empty( $clean ) ) {
		delete_post_meta( $post_id, '_rzd_preset_sections' );
	} else {
		update_post_meta( $post_id, '_rzd_preset_sections', $clean );
	}
} );

/* Lista wzorów: kolumna z zawartością */
add_filter( 'manage_rzd_mod_preset_posts_columns', function ( $cols ) {
	$new = array();
	foreach ( $cols as $k => $v ) {
		$new[ $k ] = $v;
		if ( 'title' === $k ) {
			$new['rzd_preset_content'] = 'Zawartość';
		}
	}
	return $new;
} );

add_action( 'manage_rzd_mod_preset_posts_custom_column', function ( $col, $post_id ) {
	if ( 'rzd_preset_content' !== $col ) {
		return;
	}
	$sections = rzd_get_preset_sections( $post_id );
	if ( ! $sections ) {
		echo '<span style="color:#b32d2e;">pusty – nie pojawi się na liście wzorów w produkcie</span>';
		return;
	}
	$mods  = 0;
	$names = array();
	foreach ( $sections as $sec ) {
		$mods   += isset( $sec['items'] ) ? count( (array) $sec['items'] ) : 0;
		$names[] = '' !== $sec['header'] ? $sec['header'] : '(grupa bez nagłówka)';
	}
	echo esc_html( sprintf( 'Grup: %d, modyfikacji: %d', count( $sections ), $mods ) );
	echo '<br><span class="description">' . esc_html( implode( ' · ', $names ) ) . '</span>';
}, 10, 2 );

/* ============================================================
 * 2. PRODUKT: "Dodaj z predefiniowanych"
 * ============================================================
 * Wywoływane z rzd_render_sections_editor() (moduł 10), tylko na produkcie.
 * Każdy wzór jest wyrenderowany jako szablon; indeksy jego grup to
 * symbole __P0__, __P1__, … – przycisk podmienia je na kolejne wolne numery
 * z licznika data-next na #rzd-sections (ten sam, z którego korzysta
 * "+ Dodaj grupę"), więc grupy wzoru i grupy dodane ręcznie się nie gryzą.
 */
function rzd_render_preset_picker() {
	$presets = rzd_get_all_presets();
	$usable  = array();
	foreach ( $presets as $id => $title ) {
		$secs = rzd_get_preset_sections( $id );
		if ( $secs ) {
			$usable[ $id ] = array( 'title' => $title, 'sections' => $secs );
		}
	}
	$new_url = admin_url( 'post-new.php?post_type=rzd_mod_preset' );

	echo '<div id="rzd-preset-picker" style="margin:4px 12px 14px;padding:10px 12px;border:1px dashed #8a8f99;background:#fbfbfc;">';
	if ( ! $usable ) {
		echo '<span class="description">Nie masz jeszcze żadnego wzoru z grupami. <a href="' . esc_url( $new_url ) . '" target="_blank">Utwórz wzór modyfikacji</a> (np. „wybierz jedno: frytki / ziemniaki / kluski”), a potem wstawisz go tu jednym kliknięciem.</span>';
		echo '</div>';
		return;
	}
	echo '<label for="rzd-preset-select"><strong>Wzór:</strong></label> ';
	echo '<select id="rzd-preset-select" style="min-width:220px;max-width:100%;">';
	foreach ( $usable as $id => $p ) {
		echo '<option value="' . (int) $id . '">' . esc_html( $p['title'] ) . ' (' . count( $p['sections'] ) . ' ' . ( 1 === count( $p['sections'] ) ? 'grupa' : 'grupy' ) . ')</option>';
	}
	echo '</select> ';
	echo '<button type="button" class="button" id="rzd-add-preset">+ Dodaj z predefiniowanych</button>';
	echo '<p class="description" style="margin:6px 0 0;">Wstawia <strong>kopię</strong> grup wzoru na koniec listy powyżej. Możesz ją potem zmienić tylko dla tego produktu. Zapisuje się razem z produktem (przycisk „Aktualizuj”). <a href="' . esc_url( admin_url( 'edit.php?post_type=rzd_mod_preset' ) ) . '" target="_blank">Zarządzaj wzorami</a></p>';
	echo '</div>';

	foreach ( $usable as $id => $p ) {
		$html = '';
		foreach ( $p['sections'] as $k => $sec ) {
			$html .= rzd_render_section( '__P' . $k . '__', $sec );
		}
		echo '<script type="text/html" id="rzd-preset-tpl-' . (int) $id . '" data-count="' . (int) count( $p['sections'] ) . '">' . $html . '</script>';
	}
	?>
	<script>
	jQuery(function ($) {
		$('#rzd-add-preset').on('click', function (e) {
			e.preventDefault();
			var id = $('#rzd-preset-select').val();
			var $tpl = $('#rzd-preset-tpl-' + id);
			if (!$tpl.length) { return; }
			var $sections = $('#rzd-sections');
			var n = parseInt($sections.attr('data-next'), 10) || 0;
			var count = parseInt($tpl.attr('data-count'), 10) || 0;
			var html = $tpl.html();
			// od najwyższego numeru w dół – żeby __P1__ nie złapało kawałka __P10__
			for (var k = count - 1; k >= 0; k--) {
				html = html.split('__P' + k + '__').join(n + k);
			}
			var $added = $($.parseHTML(html)).filter('.rzd-section');
			$sections.append($added);
			$sections.attr('data-next', n + count);
			$added.css('outline', '3px solid #72aee6');
			setTimeout(function () { $added.css('outline', ''); }, 1500);
			if ($added.length && $added[0].scrollIntoView) { $added[0].scrollIntoView({ behavior: 'smooth', block: 'center' }); }
		});
	});
	</script>
	<?php
}
