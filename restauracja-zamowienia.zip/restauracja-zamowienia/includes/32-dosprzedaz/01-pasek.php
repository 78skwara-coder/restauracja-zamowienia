<?php
/**
 * MODUŁ 32: DOSPRZEDAŻ – część 1: pasek dostawy (2.41.0).
 *
 * Informacja „ile brakuje”, liczona DOKŁADNIE jak dostawa (moduł 20,
 * rzd_town_delivery_status / rzd_town_status_for): wartość produktów przed
 * rabatem, bez opakowań, miejscowość z okienka terminu. Stany:
 *  - min      – poniżej minimum zamówienia (najważniejszy – bez tego nie da się zamówić),
 *  - to_free  – do darmowej dostawy (pasek postępu),
 *  - free     – darmowa dostawa,
 *  - paid     – miejscowość bez darmowej dostawy: „dostawa za każde zamówienie – dobierz teraz”.
 * Brak miejscowości (albo inna metoda dostawy) – nic.
 *
 * Miejsca: „Sprawdź zamówienie” (pod pozycjami; podpowiedź „dodaj dodatek X i masz darmową
 * dostawę” – istniejące okno „Dodatki płatne”), koszyk (nad tabelą), kasa (sama informacja
 * nad płatnościami – bez kart produktów, decyzja użytkownika), „Dodano do koszyka” (linijka).
 * Ustawienia: Panel restauracji → Sklep → „Pasek dostawy” (opcja rzd_upsell) – domyślnie
 * wyłączone: wygląd i teksty zatwierdza szefowa.
 * Etap 2 – karty „Dobierz do zamówienia” (02-karty.php, 2.42.0); etap 3 (pomiar) – później.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 1. USTAWIENIA
 * ============================================================ */
function rzd_upsell_defaults() {
	return array(
		'on'        => 0,
		'where'     => array( 'review' => 1, 'cart' => 1, 'checkout' => 1, 'added' => 1 ),
		'hint'      => 1,
		't_min'     => 'Do minimalnego zamówienia z dostawą do {miasto} brakuje {kwota}.',
		't_to_free' => 'Do darmowej dostawy do {miasto} brakuje {kwota}.',
		't_free'    => 'Masz darmową dostawę do {miasto}.',
		't_paid'    => 'Dostawa do {miasto} kosztuje {koszt} za każde zamówienie – jeśli czegoś brakuje, dobierz teraz, żeby nie płacić drugi raz.',
		't_hint_free' => 'Dodaj {dodatek} do „{danie}” (+{cena}) i masz darmową dostawę.',
		't_hint_min'  => 'Dodaj {dodatek} do „{danie}” (+{cena}) – i zamówienie osiągnie minimum.',
	);
}
function rzd_upsell_settings() {
	$s = get_option( 'rzd_upsell', array() );
	$s = wp_parse_args( is_array( $s ) ? $s : array(), rzd_upsell_defaults() );
	$s['where'] = wp_parse_args( is_array( $s['where'] ) ? $s['where'] : array(), array( 'review' => 0, 'cart' => 0, 'checkout' => 0, 'added' => 0 ) );
	return $s;
}
function rzd_upsell_on( $place ) {
	$s = rzd_upsell_settings();
	return ! empty( $s['on'] ) && ! empty( $s['where'][ $place ] );
}

/* ============================================================
 * 2. STAN PASKA
 * ============================================================ */
function rzd_upsell_money( $v ) {
	return html_entity_decode( wp_strip_all_tags( wc_price( (float) $v ) ), ENT_QUOTES, 'UTF-8' );
}
function rzd_upsell_fill( $tpl, $vars ) {
	foreach ( $vars as $k => $v ) {
		$tpl = str_replace( '{' . $k . '}', (string) $v, $tpl );
	}
	return trim( $tpl );
}

/**
 * Dane paska dla miejsca ($place: review|cart|checkout|added) albo null (nic do pokazania).
 * [ state, text, progress (0–1, tylko min/to_free), hint: null | [ key, text ] ]
 */
function rzd_upsell_bar_data( $place ) {
	if ( ! rzd_upsell_on( $place ) || ! function_exists( 'rzd_town_delivery_status' ) || ! function_exists( 'WC' ) || ! WC()->cart || WC()->cart->is_empty() ) {
		return null;
	}
	$st = rzd_town_delivery_status();
	if ( ! $st ) {
		return null;
	}
	$s    = rzd_upsell_settings();
	$vars = array( 'miasto' => $st['town'], 'kwota' => rzd_upsell_money( $st['missing'] ), 'koszt' => rzd_upsell_money( $st['cost'] ) );
	$text = rzd_upsell_fill( $s[ 't_' . $st['state'] ], $vars );
	if ( '' === $text ) {
		return null; // pusty tekst w ustawieniach = ten stan bez paska
	}
	$out = array(
		'state'    => $st['state'],
		'text'     => $text,
		'progress' => in_array( $st['state'], array( 'min', 'to_free' ), true ) ? round( $st['progress'], 3 ) : null,
		'hint'     => null,
	);
	if ( 'review' === $place && ! empty( $s['hint'] ) && in_array( $st['state'], array( 'min', 'to_free' ), true ) ) {
		$h = rzd_upsell_hint( $st['missing'] );
		if ( $h ) {
			$t = rzd_upsell_fill( 'min' === $st['state'] ? $s['t_hint_min'] : $s['t_hint_free'], array( 'dodatek' => $h['addon'], 'danie' => $h['dish'], 'cena' => rzd_upsell_money( $h['price'] ) ) );
			if ( '' !== $t ) {
				$out['hint'] = array( 'key' => $h['key'], 'text' => $t );
			}
		}
	}
	return $out;
}

/**
 * Podpowiedź „domknij próg dodatkiem”: najtańszy płatny dodatek z grup „W przeglądzie zamówienia”
 * (przycisk / licznik, rola „dodaje”) dania już w koszyku, który sam domyka brakującą kwotę.
 * Pomija: już wybrane, dodatki z Typem (dokładka tego, co danie zawiera) i to, co danie
 * ma w składzie po wyborze klienta – ta sama zasada co ⓘ „Danie zawiera już” w przeglądzie.
 */
function rzd_upsell_hint( $missing ) {
	if ( $missing <= 0 || ! function_exists( 'rzd_get_modifier_groups' ) || ! function_exists( 'rzd_group_place' ) ) {
		return null;
	}
	$best = null;
	foreach ( WC()->cart->get_cart() as $key => $it ) {
		if ( ! isset( $it['rzd_raw'] ) ) {
			continue; // pozycja bez danych wyboru – „Dodatki płatne” się dla niej nie otwierają
		}
		$pid = (int) $it['product_id'];
		$raw = (array) $it['rzd_raw'];
		foreach ( rzd_get_modifier_groups( $pid ) as $gi => $g ) {
			if ( 'cart' !== rzd_group_place( $g ) || ! in_array( $g['type'], array( 'tap', 'stepper' ), true ) || 'dodaje' !== $g['role'] ) {
				continue;
			}
			$val = isset( $raw[ $gi ]['val'] ) ? (string) $raw[ $gi ]['val'] : '';
			if ( '' !== $val && '0' !== $val ) {
				continue; // już wybrane
			}
			$a = rzd_get_addon( $g['addon_id'] );
			if ( ! $a || ! empty( $a['type_id'] ) ) {
				continue;
			}
			$price = rzd_addon_role_price( $a, 'dodaje' );
			$add = $price * max( 1, (int) $it['quantity'] ); // dodatek liczy się na każdą sztukę pozycji
			if ( $price <= 0 || $add + 0.001 < $missing ) {
				continue; // nie domyka progu sam
			}
			$src = isset( $g['_src'] ) ? (int) $g['_src'] : $pid;
			if ( function_exists( 'rzd_effective_sklad' ) ) {
				foreach ( rzd_effective_sklad( $pid, $src, $raw )['items'] as $sk ) {
					if ( (int) $sk['id'] === (int) $a['id'] ) {
						continue 2; // danie już to zawiera
					}
				}
			}
			if ( ! $best || $add < $best['price'] ) {
				$best = array( 'key' => $key, 'price' => $add, 'addon' => $a['name'], 'dish' => get_the_title( $src ) );
			}
		}
	}
	return $best;
}

/* ============================================================
 * 3. WYGLĄD (HTML koszyka i kasy; „Sprawdź zamówienie” buduje to samo w JS)
 * ============================================================ */
function rzd_upsell_bar_html( $d, $place ) {
	if ( ! $d ) {
		return '';
	}
	$h = '<div class="rzd-dbar rzd-dbar-' . esc_attr( $d['state'] ) . ' rzd-dbar-at-' . esc_attr( $place ) . '" role="status">'
		. '<p class="rzd-dbar-t">' . esc_html( $d['text'] ) . '</p>';
	if ( null !== $d['progress'] ) {
		$pc = (int) round( $d['progress'] * 100 );
		$h .= '<div class="rzd-dbar-track" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' . $pc . '"><span style="width:' . $pc . '%"></span></div>';
	}
	return $h . '</div>';
}

add_action( 'woocommerce_before_cart_table', function () {
	echo rzd_upsell_bar_html( rzd_upsell_bar_data( 'cart' ), 'cart' ); // phpcs:ignore -- escapowane w środku
} );
// kasa: WooCommerce woła ten hak tylko przy pełnym wczytaniu strony (nie w update_order_review),
// więc zawsze stawiamy opakowanie i odświeżamy je fragmentem – zmiana dostawy/kwoty od razu zmienia pasek.
function rzd_upsell_checkout_box() {
	return '<div class="rzd-dbar-box-checkout">' . rzd_upsell_bar_html( rzd_upsell_bar_data( 'checkout' ), 'checkout' ) . '</div>';
}
add_action( 'woocommerce_review_order_before_payment', function () {
	if ( rzd_upsell_on( 'checkout' ) ) {
		echo rzd_upsell_checkout_box(); // phpcs:ignore -- escapowane w środku
	}
} );
add_filter( 'woocommerce_update_order_review_fragments', function ( $f ) {
	if ( is_array( $f ) && rzd_upsell_on( 'checkout' ) ) {
		$f['.rzd-dbar-box-checkout'] = rzd_upsell_checkout_box();
	}
	return $f;
} );
add_filter( 'rzd_koszyk_added_data', function ( $data ) {
	$d = rzd_upsell_bar_data( 'added' );
	if ( $d && is_array( $data ) ) {
		$data['bar'] = array( 'state' => $d['state'], 'text' => $d['text'] );
	}
	return $data;
} );
add_filter( 'rzd_review_bar', function () {
	return rzd_upsell_bar_data( 'review' );
} );

add_action( 'wp_enqueue_scripts', function () {
	$s = rzd_upsell_settings();
	if ( empty( $s['on'] ) || is_admin() ) {
		return;
	}
	wp_enqueue_style( 'rzd-dosprzedaz', RZD_PLUGIN_URL . 'assets/css/rzd-dosprzedaz.css', array(), rzd_asset_ver( 'assets/css/rzd-dosprzedaz.css' ) );
	$st  = function_exists( 'rzd_list_style_get' ) ? rzd_list_style_get() : array();
	$hex = function ( $k, $d ) use ( $st ) {
		$v = isset( $st[ $k ] ) ? sanitize_hex_color( (string) $st[ $k ] ) : '';
		return $v ? $v : $d;
	};
	// kolory z „Wyglądu listy” (przycisk „Dodaj do koszyka”) – spójnie z resztą sklepu
	wp_add_inline_style( 'rzd-dosprzedaz', ':root{--rzd-db-accent:' . $hex( 'button_border_color', '#c08a2e' ) . ';--rzd-db-soft:' . $hex( 'button_bg', '#faf3e3' ) . ';--rzd-db-text:' . $hex( 'button_text_color', '#2b2110' ) . ';}' );
} );

/* ============================================================
 * 4. ZAPIS (Panel restauracji → Sklep → Pasek dostawy, moduł 34)
 * ============================================================ */
/** Miejsca paska i opisy tekstów (panel). */
function rzd_upsell_places() {
	return array( 'review' => '„Sprawdź zamówienie” (pod pozycjami)', 'cart' => 'Koszyk (nad listą produktów)', 'checkout' => 'Kasa (sama informacja nad płatnościami)', 'added' => '„Dodano do koszyka” (jedna linijka)' );
}
function rzd_upsell_texts() {
	return array(
		't_min'       => array( 'Poniżej minimum zamówienia', '{miasto}, {kwota} = ile brakuje' ),
		't_to_free'   => array( 'Do darmowej dostawy', '{miasto}, {kwota} = ile brakuje' ),
		't_free'      => array( 'Darmowa dostawa', '{miasto}' ),
		't_paid'      => array( 'Miejscowość bez darmowej dostawy', '{miasto}, {koszt} = koszt dostawy' ),
		't_hint_free' => array( 'Podpowiedź – do darmowej', '{dodatek}, {danie}, {cena}' ),
		't_hint_min'  => array( 'Podpowiedź – do minimum', '{dodatek}, {danie}, {cena}' ),
	);
}
function rzd_upsell_save( $in ) {
	$in  = is_array( $in ) ? $in : array();
	$def = rzd_upsell_defaults();
	$w   = isset( $in['where'] ) && is_array( $in['where'] ) ? $in['where'] : array();
	$out = array(
		'on'    => empty( $in['on'] ) ? 0 : 1,
		'hint'  => empty( $in['hint'] ) ? 0 : 1,
		'where' => array(),
	);
	foreach ( array_keys( $def['where'] ) as $k ) {
		$out['where'][ $k ] = empty( $w[ $k ] ) ? 0 : 1;
	}
	foreach ( $def as $k => $v ) {
		if ( 0 === strpos( $k, 't_' ) ) {
			$out[ $k ] = isset( $in[ $k ] ) ? sanitize_text_field( (string) $in[ $k ] ) : $v; // pusty = ten stan bez paska
		}
	}
	update_option( 'rzd_upsell', $out, false );
	return rzd_upsell_settings();
}
