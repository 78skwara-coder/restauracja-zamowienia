<?php
/**
 * MODUŁ 32: DOSPRZEDAŻ – etap 2: karty „Dobierz do zamówienia” (2.42.0).
 *
 * 2–3 karty polecanych produktów w „Sprawdź zamówienie” (pod paskiem dostawy) i w koszyku
 * (nad listą). W kasie – nic (decyzja użytkownika). Źródła – włączane i ustawiane w kolejności
 * (Panel restauracji → Sklep → „Dobierz do zamówienia”):
 *   cross – sprzedaż krzyżowa WooCommerce (Dane produktu → Produkty połączone) dań w koszyku,
 *   list  – ręczna lista „Polecane przy koszyku”,
 *   gap   – najtańszy produkt z wybranych kategorii, który SAM domyka próg darmowej dostawy
 *           (albo minimum) – bez kategorii nic nie pokazuje (żeby nie polecać drugiego obiadu).
 * Filtr (rzd_upsell_card_reject): w koszyku, nieopublikowany / niedostępny do kupienia, inny niż
 * prosty (warianty, grupowe – potrzebują formularza), Zestaw dnia, kategoria „Nie wyświetlaj
 * w sklepie”, nie do dowiezienia w terminie koszyka (rzd_dc_check_product_for_slot: dzień,
 * wyprzedane, cutoff, „danie w zestawie”), danie w koszyku już to zawiera (po nazwie).
 * Dodanie: rzdAddProduct (brama, moduł 08) – te same kroki co „Dodaj do koszyka”, w tle.
 * Znacznik źródła: pozycja koszyka 'rzd_upsell' → meta pozycji zamówienia `_rzd_upsell`
 * (cross|list|gap|hint) – pod pomiar (etap 3). Klient i kuchnia go nie widzą.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 1. USTAWIENIA (opcja rzd_upsell_cards)
 * ============================================================ */
function rzd_upsell_card_sources() {
	return array(
		'cross' => 'Sprzedaż krzyżowa WooCommerce (przypięte do dań w koszyku)',
		'list'  => 'Lista „Polecane przy koszyku” (poniżej)',
		'gap'   => 'Produkt domykający próg darmowej dostawy (z wybranych kategorii)',
	);
}
function rzd_upsell_cards_defaults() {
	return array(
		'on'      => 0,
		'where'   => array( 'review' => 1, 'cart' => 1 ),
		'order'   => array( 'cross', 'list', 'gap' ),
		'src'     => array( 'cross' => 1, 'list' => 1, 'gap' => 1 ),
		'list'    => array(),
		'cats'    => array(),
		'max'     => 3,
		'title'   => 'Dobierz do zamówienia',
		'no'      => 'Nie, dziękuję',
		'gap_tag' => 'Darmowa dostawa',
	);
}
function rzd_upsell_cards_settings() {
	$s = get_option( 'rzd_upsell_cards', array() );
	$s = wp_parse_args( is_array( $s ) ? $s : array(), rzd_upsell_cards_defaults() );
	$s['where'] = wp_parse_args( is_array( $s['where'] ) ? $s['where'] : array(), array( 'review' => 0, 'cart' => 0 ) );
	$s['src']   = wp_parse_args( is_array( $s['src'] ) ? $s['src'] : array(), array( 'cross' => 0, 'list' => 0, 'gap' => 0 ) );
	$order      = array_values( array_intersect( (array) $s['order'], array_keys( rzd_upsell_card_sources() ) ) );
	$s['order'] = array_values( array_unique( array_merge( $order, array_keys( rzd_upsell_card_sources() ) ) ) );
	$s['list']  = array_values( array_filter( array_map( 'intval', (array) $s['list'] ) ) );
	$s['cats']  = array_values( array_filter( array_map( 'intval', (array) $s['cats'] ) ) );
	$s['max']   = max( 1, min( 6, (int) $s['max'] ) );
	return $s;
}
function rzd_upsell_cards_on( $place ) {
	$s = rzd_upsell_cards_settings();
	return ! empty( $s['on'] ) && ! empty( $s['where'][ $place ] );
}

/* ============================================================
 * 2. KANDYDACI I FILTR
 * ============================================================ */

/** Kontekst koszyka: produkty w koszyku, nazwy tego, co dania już zawierają, termin. */
function rzd_upsell_cart_ctx() {
	$in    = array();
	$names = array();
	foreach ( WC()->cart->get_cart() as $it ) {
		$pid  = (int) $it['product_id'];
		$in[ $pid ] = true;
		if ( ! empty( $it['variation_id'] ) ) {
			$in[ (int) $it['variation_id'] ] = true;
		}
		$raw = isset( $it['rzd_raw'] ) ? (array) $it['rzd_raw'] : array();
		if ( function_exists( 'rzd_effective_sklad_names' ) ) {
			foreach ( rzd_effective_sklad_names( $pid, $pid, $raw ) as $n ) {
				$names[ rzd_upsell_norm( $n ) ] = true;
			}
		}
		// wybrane „Dodatki płatne” (przegląd) – też już są w daniu
		if ( $raw && function_exists( 'rzd_get_modifier_groups' ) && function_exists( 'rzd_group_place' ) ) {
			foreach ( rzd_get_modifier_groups( $pid ) as $gi => $g ) {
				$val = isset( $raw[ $gi ]['val'] ) ? (string) $raw[ $gi ]['val'] : '';
				if ( 'cart' === rzd_group_place( $g ) && '' !== $val && '0' !== $val && ! empty( $g['addon_id'] ) ) {
					$a = rzd_get_addon( $g['addon_id'] );
					if ( $a ) {
						$names[ rzd_upsell_norm( $a['name'] ) ] = true;
					}
				}
			}
		}
	}
	$slot = ( function_exists( 'rzd_dc_enabled' ) && rzd_dc_enabled() && function_exists( 'rzd_dc_get_slot' ) ) ? rzd_dc_get_slot() : null;
	return array( 'in' => $in, 'names' => $names, 'slot' => $slot );
}
function rzd_upsell_norm( $s ) {
	return trim( preg_replace( '/\s+/u', ' ', mb_strtolower( wp_strip_all_tags( (string) $s ), 'UTF-8' ) ) );
}

/** '' = produkt może być kartą; inaczej powód odrzucenia (testy, diagnostyka). */
function rzd_upsell_card_reject( $pid, $ctx ) {
	$p = wc_get_product( $pid );
	if ( ! $p || 'publish' !== $p->get_status() ) {
		return 'brak';
	}
	if ( ! $p->is_type( 'simple' ) ) {
		return 'typ'; // warianty, grupowe, zewnętrzne – potrzebują formularza
	}
	if ( ! $p->is_purchasable() || ! $p->is_in_stock() || 'hidden' === $p->get_catalog_visibility() ) {
		return 'niedostępny';
	}
	if ( isset( $ctx['in'][ $pid ] ) ) {
		return 'w koszyku';
	}
	if ( function_exists( 'rzd_zestaw_get_slots' ) && rzd_zestaw_get_slots( $pid ) ) {
		return 'zestaw';
	}
	if ( function_exists( 'rzd_zestaw_product_in_hidden_category' ) && rzd_zestaw_product_in_hidden_category( $pid ) ) {
		return 'ukryta kategoria';
	}
	if ( $ctx['slot'] && function_exists( 'rzd_dc_check_product_for_slot' ) && '' !== rzd_dc_check_product_for_slot( $pid, $ctx['slot'] ) ) {
		return 'termin';
	}
	if ( isset( $ctx['names'][ rzd_upsell_norm( $p->get_name() ) ] ) ) {
		return 'danie zawiera';
	}
	return '';
}

/** Cena produktu tak, jak widzi ją klient (z podatkiem wg ustawień sklepu). */
function rzd_upsell_price( $p ) {
	return (float) wc_get_price_to_display( $p );
}

/** Kandydaci ze źródła (id produktów w kolejności). */
function rzd_upsell_source_ids( $src, $s, $ctx ) {
	if ( 'cross' === $src ) {
		$ids = array();
		foreach ( WC()->cart->get_cart() as $it ) {
			$p = wc_get_product( (int) $it['product_id'] );
			if ( $p ) {
				$ids = array_merge( $ids, array_map( 'intval', $p->get_cross_sell_ids() ) );
			}
		}
		return array_values( array_unique( $ids ) );
	}
	if ( 'list' === $src ) {
		return $s['list'];
	}
	if ( 'gap' === $src ) {
		if ( ! $s['cats'] || ! function_exists( 'rzd_town_delivery_status' ) ) {
			return array();
		}
		$st = rzd_town_delivery_status();
		if ( ! $st || ! in_array( $st['state'], array( 'min', 'to_free' ), true ) || $st['missing'] <= 0 ) {
			return array();
		}
		$cand = wc_get_products( array(
			'status'   => 'publish',
			'type'     => 'simple',
			'limit'    => 200,
			'return'   => 'ids',
			'category' => array_values( array_filter( array_map( function ( $t ) { $x = get_term( $t, 'product_cat' ); return ( $x && ! is_wp_error( $x ) ) ? $x->slug : ''; }, $s['cats'] ) ) ),
		) );
		$best = null;
		$bp   = 0;
		foreach ( $cand as $id ) {
			$p = wc_get_product( $id );
			if ( ! $p ) {
				continue;
			}
			$pr = rzd_upsell_price( $p );
			if ( $pr + 0.001 < $st['missing'] || '' !== rzd_upsell_card_reject( (int) $id, $ctx ) ) {
				continue;
			}
			if ( null === $best || $pr < $bp ) {
				$best = (int) $id;
				$bp   = $pr;
			}
		}
		return $best ? array( $best ) : array();
	}
	return array();
}

/**
 * Karty dla miejsca (review|cart): [ id, name, price (liczba), price_html, img, src, tag ].
 * Pusta tablica = nic do pokazania.
 */
function rzd_upsell_cards_data( $place ) {
	if ( ! rzd_upsell_cards_on( $place ) || ! function_exists( 'WC' ) || ! WC()->cart || WC()->cart->is_empty() ) {
		return array();
	}
	$s    = rzd_upsell_cards_settings();
	$ctx  = rzd_upsell_cart_ctx();
	$out  = array();
	$seen = array();
	foreach ( $s['order'] as $src ) {
		if ( empty( $s['src'][ $src ] ) ) {
			continue;
		}
		foreach ( rzd_upsell_source_ids( $src, $s, $ctx ) as $id ) {
			if ( count( $out ) >= $s['max'] ) {
				break 2;
			}
			if ( isset( $seen[ $id ] ) || '' !== rzd_upsell_card_reject( $id, $ctx ) ) {
				continue;
			}
			$seen[ $id ] = true;
			$p           = wc_get_product( $id );
			$img         = $p->get_image_id() ? wp_get_attachment_image_url( $p->get_image_id(), 'woocommerce_thumbnail' ) : wc_placeholder_img_src( 'woocommerce_thumbnail' );
			$out[]       = array(
				'id'         => $id,
				'name'       => $p->get_name(),
				'price'      => rzd_upsell_price( $p ),
				'price_html' => wc_price( rzd_upsell_price( $p ) ),
				'img'        => $img ? $img : '',
				'src'        => $src,
				'tag'        => 'gap' === $src ? (string) $s['gap_tag'] : '',
			);
		}
	}
	return $out;
}

/* ============================================================
 * 3. ZNACZNIK ŹRÓDŁA (pod pomiar – etap 3)
 * ============================================================ */
function rzd_upsell_src_valid( $v ) {
	return in_array( $v, array( 'cross', 'list', 'gap', 'hint' ), true ) ? $v : '';
}
add_filter( 'woocommerce_add_cart_item_data', function ( $data ) {
	$v = isset( $_POST['rzd_upsell'] ) ? rzd_upsell_src_valid( sanitize_key( wp_unslash( $_POST['rzd_upsell'] ) ) ) : ''; // phpcs:ignore -- tylko znacznik, bez skutków
	if ( $v && 'hint' !== $v ) {
		$data['rzd_upsell'] = $v;
	}
	return $data;
}, 20 );
add_action( 'woocommerce_checkout_create_order_line_item', function ( $item, $key, $values ) {
	if ( ! empty( $values['rzd_upsell'] ) && rzd_upsell_src_valid( $values['rzd_upsell'] ) ) {
		$item->add_meta_data( '_rzd_upsell', $values['rzd_upsell'], true );
	}
}, 10, 3 );

/* ============================================================
 * 4. WYGLĄD – koszyk (HTML); „Sprawdź zamówienie” buduje to samo w JS (rzd-dobierz.js)
 * ============================================================ */
function rzd_upsell_cards_html( $cards, $place ) {
	if ( ! $cards ) {
		return '';
	}
	$s = rzd_upsell_cards_settings();
	$h = '<div class="rzd-up rzd-up-at-' . esc_attr( $place ) . '" data-place="' . esc_attr( $place ) . '">'
		. '<div class="rzd-up-head"><p class="rzd-up-title">' . esc_html( $s['title'] ) . '</p>'
		. ( '' !== $s['no'] ? '<button type="button" class="rzd-up-no">' . esc_html( $s['no'] ) . '</button>' : '' ) . '</div><div class="rzd-up-row">';
	foreach ( $cards as $c ) {
		$h .= '<div class="rzd-up-card" data-id="' . (int) $c['id'] . '" data-src="' . esc_attr( $c['src'] ) . '">'
			. ( $c['img'] ? '<img class="rzd-up-img" src="' . esc_url( $c['img'] ) . '" alt="" loading="lazy">' : '<span class="rzd-up-img rzd-up-noimg" aria-hidden="true"></span>' )
			. ( '' !== $c['tag'] ? '<span class="rzd-up-tag">' . esc_html( $c['tag'] ) . '</span>' : '' )
			. '<span class="rzd-up-name">' . esc_html( $c['name'] ) . '</span>'
			. '<span class="rzd-up-price">' . wp_kses_post( $c['price_html'] ) . '</span>'
			. '<button type="button" class="rzd-up-add" aria-label="' . esc_attr( 'Dodaj: ' . $c['name'] ) . '">+ Dodaj</button>'
			. '</div>';
	}
	return $h . '</div></div>';
}
add_action( 'woocommerce_before_cart_table', function () {
	echo rzd_upsell_cards_html( rzd_upsell_cards_data( 'cart' ), 'cart' ); // phpcs:ignore -- escapowane w środku
}, 20 ); // pod paskiem dostawy (priorytet 10)
add_filter( 'rzd_review_cards', function () {
	$s = rzd_upsell_cards_settings();
	$c = rzd_upsell_cards_data( 'review' );
	return $c ? array( 'title' => $s['title'], 'no' => $s['no'], 'items' => $c ) : null;
} );

add_action( 'wp_enqueue_scripts', function () {
	$s = rzd_upsell_cards_settings();
	if ( empty( $s['on'] ) || is_admin() ) {
		return;
	}
	if ( ! wp_style_is( 'rzd-dosprzedaz', 'enqueued' ) ) { // pasek wyłączony – style kart i tak potrzebne
		wp_enqueue_style( 'rzd-dosprzedaz', RZD_PLUGIN_URL . 'assets/css/rzd-dosprzedaz.css', array(), rzd_asset_ver( 'assets/css/rzd-dosprzedaz.css' ) );
	}
	wp_enqueue_script( 'rzd-dobierz', RZD_PLUGIN_URL . 'assets/js/rzd-dobierz.js', array( 'rzd-brama' ), rzd_asset_ver( 'assets/js/rzd-dobierz.js' ), array( 'in_footer' => true, 'strategy' => 'defer' ) );
}, 20 );

/* ============================================================
 * 5. ZAPIS (Panel restauracji → Sklep → Dobierz do zamówienia, moduł 34)
 * ============================================================ */
function rzd_upsell_cards_save( $in ) {
	$in  = is_array( $in ) ? $in : array();
	$def = rzd_upsell_cards_defaults();
	$w   = isset( $in['where'] ) && is_array( $in['where'] ) ? $in['where'] : array();
	$src = isset( $in['src'] ) && is_array( $in['src'] ) ? $in['src'] : array();
	$ids = function ( $k ) use ( $in ) {
		return array_values( array_unique( array_filter( array_map( 'intval', (array) ( isset( $in[ $k ] ) ? $in[ $k ] : array() ) ) ) ) );
	};
	$out = array(
		'on'      => empty( $in['on'] ) ? 0 : 1,
		'where'   => array( 'review' => empty( $w['review'] ) ? 0 : 1, 'cart' => empty( $w['cart'] ) ? 0 : 1 ),
		'order'   => array_values( array_intersect( array_map( 'sanitize_key', (array) ( isset( $in['order'] ) ? $in['order'] : array() ) ), array_keys( rzd_upsell_card_sources() ) ) ),
		'src'     => array(),
		'list'    => $ids( 'list' ),
		'cats'    => $ids( 'cats' ),
		'max'     => isset( $in['max'] ) && '' !== (string) $in['max'] ? max( 1, min( 6, (int) $in['max'] ) ) : $def['max'],
		'title'   => isset( $in['title'] ) ? sanitize_text_field( (string) $in['title'] ) : $def['title'],
		'no'      => isset( $in['no'] ) ? sanitize_text_field( (string) $in['no'] ) : $def['no'],
		'gap_tag' => isset( $in['gap_tag'] ) ? sanitize_text_field( (string) $in['gap_tag'] ) : $def['gap_tag'],
	);
	foreach ( array_keys( rzd_upsell_card_sources() ) as $k ) {
		$out['src'][ $k ] = empty( $src[ $k ] ) ? 0 : 1;
	}
	update_option( 'rzd_upsell_cards', $out, false );
	return rzd_upsell_cards_settings();
}
