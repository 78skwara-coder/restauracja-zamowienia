<?php
/**
 * MODUŁ 19: Kurier — osobny widok
 *
 * Wyciągnięty z Kuchni (moduł 12, do 2.21.x zakładka "Kurier").
 *  - shortcode [kurier_dashboard] na osobnej stronie = link dla kuriera,
 *  - 2.30.0: wejście KONTEM z uprawnieniem „Kurier” (konfigurator, moduły 25/26;
 *    logowanie 30 dni) albo AWARYJNYM PIN-em (domyślnie wyłączony, ustawiany
 *    w Panel restauracji → Zespół; limit 5 prób / 15 min),
 *  - kurier widzi TYLKO ten ekran (bez zakładek i ustawień) i może nadać
 *    wyłącznie "Dostarczone" spakowanym zamówieniom – pilnuje tego serwer
 *    (moduł 13, wc_ajax_kuchnia_set_status),
 *  - bez dźwięku i sygnału nowych zamówień; auto-odświeżanie zostaje,
 *  - (2.46.1) „Otwórz trasę” (Mapy Google – przystanki w kolejności z Planowania, bez dostarczonych;
 *    po 10 na link, skrypt rzd-kuchnia.js; ten sam przycisk w Kuchni → Planowanie) i pasek
 *    „Do pobrania” (za pobraniem: termin + cały dzień, do pobrania / pobrane).
 * Wygląd, skrypt i nawigacja bez przeładowania są wspólne z Kuchnią:
 * rzd_kuchnia_render_dashboard( $base, 'kurier' ).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 1. Dostęp
 * ============================================================ */
function rzd_kurier_frontend_authed() {
	if ( function_exists( 'rzd_can' ) && rzd_can( 'courier' ) ) {
		return true; // konto z uprawnieniem „Kurier” (też administrator)
	}
	if ( ! function_exists( 'rzd_courier_pin_enabled' ) || ! rzd_courier_pin_enabled() ) {
		return false; // awaryjny PIN wyłączony
	}
	$pin = get_option( 'kurier_pin', '' );
	return isset( $_COOKIE['rzd_kurier_auth'] ) && hash_equals( wp_hash( 'kurier_pin_' . $pin ), (string) $_COOKIE['rzd_kurier_auth'] );
}

// Awaryjny PIN sprawdzamy na "init" (przed wysłaniem treści), żeby dało się ustawić ciasteczko.
// Limit prób: 5 błędnych → 15 minut blokady (moduł 25). Zmiana PIN-u unieważnia stare ciasteczka.
add_action( 'init', function () {
	if ( ! isset( $_POST['kurier_pin_try'] ) || ! function_exists( 'rzd_courier_pin_enabled' ) || ! rzd_courier_pin_enabled() ) {
		return;
	}
	$wait = rzd_pin_locked( 'kurier' );
	if ( $wait ) {
		$GLOBALS['kurier_pin_error'] = 'Za dużo błędnych prób. Spróbuj ponownie za ' . $wait . ' min.';
		return;
	}
	$try  = sanitize_text_field( wp_unslash( $_POST['kurier_pin_try'] ) );
	$kpin = (string) get_option( 'kurier_pin', '' );
	if ( '' !== $kpin && hash_equals( $kpin, $try ) ) {
		setcookie( 'rzd_kurier_auth', wp_hash( 'kurier_pin_' . $kpin ), time() + DAY_IN_SECONDS, COOKIEPATH ?: '/', COOKIE_DOMAIN, is_ssl(), true ); // awaryjnie: 1 dzień
		$_COOKIE['rzd_kurier_auth'] = wp_hash( 'kurier_pin_' . $kpin ); // działa od razu, bez drugiego wejścia
		rzd_pin_ok( 'kurier' );
	} else {
		rzd_pin_fail( 'kurier' );
		$left = rzd_pin_locked( 'kurier' );
		$GLOBALS['kurier_pin_error'] = $left ? 'Za dużo błędnych prób. Spróbuj ponownie za ' . $left . ' min.' : 'Błędny PIN, spróbuj ponownie.';
	}
} );

// Strona kuriera poza wyszukiwarkami – moduł 35-seo (wszystkie ekrany obsługi: meta robots + X-Robots-Tag).

/* ============================================================
 * 2. Shortcode [kurier_dashboard] + podgląd w panelu (menu Kuchnia → Kurier)
 * ============================================================ */
add_shortcode( 'kurier_dashboard', function () {
	if ( ! rzd_kurier_frontend_authed() ) {
		if ( is_user_logged_in() && ! ( function_exists( 'rzd_courier_pin_enabled' ) && rzd_courier_pin_enabled() ) ) {
			return rzd_no_access_html( 'Kurier' );
		}
		$pin = function_exists( 'rzd_courier_pin_enabled' ) && rzd_courier_pin_enabled();
		$out = is_user_logged_in() ? '' : rzd_staff_login_html( 'Kurier', 'Zaloguj się swoim kontem kuriera. Zostaw zaznaczone „Zapamiętaj mnie”.' );
		if ( $pin ) {
			ob_start();
			?>
			<div style="max-width:360px;margin:20px auto 60px;padding:20px 24px;border:2px dashed #999;border-radius:12px;font-family:sans-serif;text-align:center;">
				<h3 style="margin-top:0;">Zastępstwo – awaryjny PIN</h3>
				<?php if ( ! empty( $GLOBALS['kurier_pin_error'] ) ) : ?>
					<p style="color:#b32d2e;"><?php echo esc_html( is_string( $GLOBALS['kurier_pin_error'] ) ? $GLOBALS['kurier_pin_error'] : 'Błędny PIN, spróbuj ponownie.' ); ?></p>
				<?php endif; ?>
				<form method="post">
					<input type="password" inputmode="numeric" name="kurier_pin_try" placeholder="PIN" autocomplete="off" style="font-size:20px;padding:10px;width:100%;box-sizing:border-box;text-align:center;letter-spacing:4px;">
					<button type="submit" style="margin-top:12px;padding:10px 20px;font-size:16px;background:#222;color:#fff;border:0;border-radius:8px;cursor:pointer;">Wejdź</button>
				</form>
			</div>
			<?php
			$out .= ob_get_clean();
		}
		return $out;
	}
	if ( ! function_exists( 'rzd_kuchnia_render_dashboard' ) ) {
		return '';
	}
	ob_start();
	rzd_kuchnia_render_dashboard( get_permalink(), 'kurier' );
	return ob_get_clean();
} );

// Strona w panelu: Restauracja → Kurier (menu w module 00-menu).
function rzd_kurier_admin_page() {
	if ( ! rzd_can( 'courier' ) || ! function_exists( 'rzd_kuchnia_render_dashboard' ) ) {
		return;
	}
	echo '<div class="wrap">';
	rzd_kuchnia_render_dashboard( admin_url( 'admin.php?page=rzd-kurier' ), 'kurier' );
	echo '</div>';
}

/* ============================================================
 * 3. Trasa i pobrania (2.46.1)
 * ============================================================ */
function rzd_kurier_is_done( $order ) {
	return in_array( $order->get_status(), array( 'wydane', 'completed' ), true );
}

// Atrybuty wiersza tabeli dla przycisku trasy: adres i czy już dostarczone (skrypt składa link).
function rzd_kurier_route_attrs( $order ) {
	$addr = function_exists( 'rzd_kuchnia_order_address' ) ? rzd_kuchnia_order_address( $order ) : '';
	return ' data-addr="' . esc_attr( $addr ) . '" data-done="' . ( rzd_kurier_is_done( $order ) ? '1' : '0' ) . '"';
}

// Przycisk „Otwórz trasę” dla tabeli $table_id. Link składa skrypt w chwili kliknięcia – w Planowaniu
// z bieżącej kolejności w polach (zapis idzie w tle, bez przeładowania).
function rzd_kurier_route_btn_html( $table_id ) {
	return '<div class="rzd-route kuchnia-noprint"><a href="#" class="kuchnia-btn kuchnia-btn-primary rzd-route-btn" data-table="' . esc_attr( $table_id ) . '" target="_blank" rel="noopener">🗺️ Otwórz trasę</a>'
		. '<span class="rzd-route-hint">Mapy Google · kolejność z Planowania · bez dostarczonych</span></div>';
}

/** Za pobraniem: [ due => kwota do pobrania, due_n, got => pobrane, got_n ]. Anulowane itp. pomijane. */
function rzd_kurier_cod_sums( $orders ) {
	$out = array( 'due' => 0.0, 'due_n' => 0, 'got' => 0.0, 'got_n' => 0 );
	foreach ( $orders as $o ) {
		if ( 'cod' !== $o->get_payment_method() || in_array( $o->get_status(), array( 'cancelled', 'refunded', 'failed', 'trash' ), true ) ) {
			continue;
		}
		$k = rzd_kurier_is_done( $o ) ? 'got' : 'due';
		$out[ $k ]        += (float) $o->get_total();
		$out[ $k . '_n' ] += 1;
	}
	return $out;
}

function rzd_kurier_money( $v ) {
	return trim( html_entity_decode( wp_strip_all_tags( wc_price( $v ) ), ENT_QUOTES, 'UTF-8' ) );
}

function rzd_kurier_n_orders( $n ) {
	return $n . ' ' . ( 1 === $n ? 'zamówienie' : ( ( $n % 10 >= 2 && $n % 10 <= 4 && ( $n % 100 < 10 || $n % 100 >= 20 ) ) ? 'zamówienia' : 'zamówień' ) );
}

// Pasek „Do pobrania”: ten termin + cały dzień (gdy w dniu jest więcej terminów z pobraniem).
function rzd_kurier_cod_html( $orders, $date ) {
	$t   = rzd_kurier_cod_sums( $orders );
	$day = array();
	if ( function_exists( 'rzd_kuchnia_slots_for_date_pipeline' ) && function_exists( 'rzd_kuchnia_orders_for_slot_pipeline' ) ) {
		foreach ( array_keys( rzd_kuchnia_slots_for_date_pipeline( $date ) ) as $st ) {
			foreach ( rzd_kuchnia_orders_for_slot_pipeline( $date, $st ) as $o ) {
				$day[ $o->get_id() ] = $o;
			}
		}
	}
	$d    = rzd_kurier_cod_sums( $day );
	$show_day = ( $d['due_n'] + $d['got_n'] ) > ( $t['due_n'] + $t['got_n'] );
	if ( ! ( $t['due_n'] + $t['got_n'] ) && ! $show_day ) {
		return '<div class="rzd-cod rzd-cod-none">Za pobraniem: brak – wszystko opłacone online.</div>';
	}
	$h  = '<div class="rzd-cod">';
	$h .= '<div class="rzd-cod-row"><span class="rzd-cod-lbl">Ten termin</span>'
		. '<span class="rzd-cod-due' . ( $t['due_n'] ? '' : ' is-zero' ) . '">Do pobrania: <strong>' . esc_html( rzd_kurier_money( $t['due'] ) ) . '</strong>' . ( $t['due_n'] ? ' <small>(' . esc_html( rzd_kurier_n_orders( $t['due_n'] ) ) . ')</small>' : '' ) . '</span>'
		. '<span class="rzd-cod-got">pobrane: ' . esc_html( rzd_kurier_money( $t['got'] ) ) . '</span></div>';
	if ( $show_day ) {
		$h .= '<div class="rzd-cod-row rzd-cod-day"><span class="rzd-cod-lbl">Cały dzień</span>'
			. '<span class="rzd-cod-due' . ( $d['due_n'] ? '' : ' is-zero' ) . '">Do pobrania: <strong>' . esc_html( rzd_kurier_money( $d['due'] ) ) . '</strong>' . ( $d['due_n'] ? ' <small>(' . esc_html( rzd_kurier_n_orders( $d['due_n'] ) ) . ')</small>' : '' ) . '</span>'
			. '<span class="rzd-cod-got">pobrane: ' . esc_html( rzd_kurier_money( $d['got'] ) ) . '</span></div>';
	}
	return $h . '</div>';
}

/* ============================================================
 * 4. Widok: zamówienia wybranego terminu w kolejności z Planowania
 * ============================================================ */
function rzd_kurier_view_html( $orders, $date ) {
	// Kurier widzi od razu wszystkie zamówienia terminu, żeby mógł planować
	// trasę. "Dostarczone" da się kliknąć dopiero po spakowaniu.
	$sorted = function_exists( 'rzd_kuchnia_sort_by_sequence' ) ? rzd_kuchnia_sort_by_sequence( $orders ) : $orders;
	ob_start();
	if ( ! $sorted ) {
		echo '<p class="kuchnia-empty">Brak zamówień w tym terminie.</p>';
		return ob_get_clean();
	}
	echo rzd_kurier_cod_html( $sorted, $date ); // phpcs:ignore -- escapowane w funkcji
	echo rzd_kurier_route_btn_html( 'kurier-table' ); // phpcs:ignore
	?>
	<table class="kuchnia-table kurier-table" id="kurier-table">
		<thead><tr><th>#</th><th>Klient</th><th>Status</th><th>Data i godzina</th><th>Adres</th><th>Telefon</th><th>Płatność</th><th>Zawartość</th><th class="kuchnia-noprint"></th></tr></thead>
		<tbody>
		<?php foreach ( $sorted as $i => $order ) : ?>
			<?php
			// Zawartość zsumowana: te same pozycje (np. kilka "Opakowanie" z różnych
			// dań) w jednej linii z łączną ilością. "Bez: …" pomijamy – to sprawa
			// kuchni, kurier przekazuje tylko to, co jest w torbie.
			$sum = array();
			foreach ( rzd_kuchnia_order_lines( $order ) as $l ) {
				if ( ( isset( $l['kind'] ) && 'bez' === $l['kind'] ) || 0 === strpos( $l['name'], 'Bez: ' ) ) {
					continue;
				}
				$sum[ $l['name'] ] = ( isset( $sum[ $l['name'] ] ) ? $sum[ $l['name'] ] : 0 ) + (int) $l['qty'];
			}
			$ptime        = $order->get_meta( '_dc_planned_time' );
			$delivered    = ( 'wydane' === $order->get_status() );
			$delivered_at = $order->get_meta( '_dc_delivered_at' );
			$address      = rzd_kuchnia_order_address( $order );
			$phone        = $order->get_billing_phone();
			$tel          = preg_replace( '/[^0-9+]/', '', (string) $phone );
			?>
			<tr<?php echo rzd_kurier_route_attrs( $order ); // phpcs:ignore ?><?php echo ( 'cod' === $order->get_payment_method() && ! $delivered ) ? ' class="kurier-cod-due"' : ''; ?>>
				<td data-label="#"><?php echo (int) $i + 1; ?></td>
				<td data-label="Klient">#<?php echo esc_html( $order->get_order_number() ); ?> <?php echo esc_html( $order->get_formatted_billing_full_name() ); ?></td>
				<td data-label="Status"><?php echo rzd_kuchnia_status_badge_html( $order ); ?></td>
				<td data-label="Godzina"><?php echo esc_html( date_i18n( 'd.m', strtotime( $date ) ) . ' ' . ( $ptime ? $ptime : '—' ) ); ?></td>
				<td data-label="Adres">
					<?php echo rzd_kuchnia_address_html( $order, true ); // pełny adres (z nr mieszkania) + uwagi klienta – phpcs:ignore ?>
				</td>
				<td data-label="Telefon">
					<?php if ( $tel ) : ?>
						<a class="kuchnia-tellink" href="<?php echo esc_attr( 'tel:' . $tel ); ?>">📞 <?php echo esc_html( $phone ); ?></a>
					<?php endif; ?>
				</td>
				<td data-label="Płatność"><?php echo rzd_kuchnia_payment_html( $order ); ?></td>
				<td data-label="Zawartość" class="kurier-contents">
					<?php foreach ( $sum as $cname => $cqty ) : ?>
						<div><strong><?php echo (int) $cqty; ?>×</strong> <?php echo esc_html( $cname ); ?></div>
					<?php endforeach; ?>
				</td>
				<td data-label="" class="kuchnia-noprint">
					<?php if ( $delivered ) : ?>
						<em>Dostarczone<?php echo $delivered_at ? ( ': ' . esc_html( $delivered_at ) ) : ''; ?></em>
					<?php elseif ( 'w-dostawie' !== $order->get_status() ) : ?>
						<em class="kuchnia-wait">Czeka na spakowanie</em>
					<?php else : ?>
						<button type="button" class="kuchnia-deliver-btn" data-order="<?php echo (int) $order->get_id(); ?>">Dostarczone</button>
					<?php endif; ?>
				</td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
	<?php
	return ob_get_clean();
}
