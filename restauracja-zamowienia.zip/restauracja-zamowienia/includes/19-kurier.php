<?php
/**
 * MODUŁ 19: Kurier — osobny widok z osobnym PIN-em
 *
 * Wyciągnięty z Kuchni (moduł 12, do 2.21.x zakładka "Kurier").
 *  - shortcode [kurier_dashboard] na osobnej stronie = link dla kuriera,
 *  - PIN kuriera ustawiany razem z PIN-em kuchni (moduł 12, pod dashboardem),
 *  - kurier widzi TYLKO ten ekran (bez zakładek i ustawień) i może nadać
 *    wyłącznie "Dostarczone" spakowanym zamówieniom – pilnuje tego serwer
 *    (moduł 13, wc_ajax_kuchnia_set_status),
 *  - PIN kuchni i admin też otwierają ten widok ("kuchnia widzi wszystko"),
 *  - bez dźwięku i sygnału nowych zamówień; auto-odświeżanie zostaje.
 * Wygląd, skrypt i nawigacja bez przeładowania są wspólne z Kuchnią:
 * kuchnia_render_dashboard( $base, 'kurier' ).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 1. Dostęp
 * ============================================================ */
function kurier_frontend_authed() {
	if ( function_exists( 'kuchnia_frontend_authed' ) && kuchnia_frontend_authed() ) {
		return true; // admin/menedżer albo PIN kuchni
	}
	$pin = get_option( 'kurier_pin', '' );
	if ( ! $pin ) {
		return false; // PIN kuriera nie ustawiony – strona kuriera zamknięta
	}
	return isset( $_COOKIE['rzd_kurier_auth'] ) && hash_equals( wp_hash( 'kurier_pin_' . $pin ), $_COOKIE['rzd_kurier_auth'] );
}

// PIN sprawdzamy na "init" (przed wysłaniem treści), żeby dało się ustawić ciasteczko.
add_action( 'init', function () {
	if ( ! isset( $_POST['kurier_pin_try'] ) ) {
		return;
	}
	$try   = sanitize_text_field( wp_unslash( $_POST['kurier_pin_try'] ) );
	$kpin  = get_option( 'kurier_pin', '' );
	$kupin = get_option( 'kuchnia_pin', '' );
	if ( $kpin && hash_equals( (string) $kpin, $try ) ) {
		setcookie( 'rzd_kurier_auth', wp_hash( 'kurier_pin_' . $kpin ), time() + 30 * DAY_IN_SECONDS, COOKIEPATH ?: '/', COOKIE_DOMAIN, is_ssl(), true );
		$_COOKIE['rzd_kurier_auth'] = wp_hash( 'kurier_pin_' . $kpin ); // działa od razu, bez drugiego wejścia
	} elseif ( $kupin && hash_equals( (string) $kupin, $try ) ) {
		// PIN kuchni też otwiera stronę kuriera – logujemy wtedy jako kuchnię.
		setcookie( 'rzd_kuchnia_auth', wp_hash( 'kuchnia_pin_' . $kupin ), time() + 30 * DAY_IN_SECONDS, COOKIEPATH ?: '/', COOKIE_DOMAIN, is_ssl(), true );
		$_COOKIE['rzd_kuchnia_auth'] = wp_hash( 'kuchnia_pin_' . $kupin );
	} else {
		$GLOBALS['kurier_pin_error'] = true;
	}
} );

// Strona kuriera poza wyszukiwarkami.
add_action( 'wp_head', function () {
	global $post;
	if ( $post && has_shortcode( $post->post_content, 'kurier_dashboard' ) ) {
		echo '<meta name="robots" content="noindex,nofollow">' . "\n";
	}
} );

/* ============================================================
 * 2. Shortcode [kurier_dashboard] + podgląd w panelu (menu Kuchnia → Kurier)
 * ============================================================ */
add_shortcode( 'kurier_dashboard', function () {
	if ( ! kurier_frontend_authed() ) {
		ob_start();
		?>
		<div style="max-width:320px;margin:60px auto;padding:24px;border:2px solid #222;border-radius:12px;font-family:sans-serif;text-align:center;">
			<h2 style="margin-top:0;">Kurier</h2>
			<?php if ( ! empty( $GLOBALS['kurier_pin_error'] ) ) : ?>
				<p style="color:#b32d2e;">Błędny PIN, spróbuj ponownie.</p>
			<?php endif; ?>
			<form method="post">
				<input type="password" inputmode="numeric" name="kurier_pin_try" placeholder="PIN" style="font-size:20px;padding:10px;width:100%;box-sizing:border-box;text-align:center;letter-spacing:4px;">
				<button type="submit" style="margin-top:12px;padding:10px 20px;font-size:16px;background:#222;color:#fff;border:0;border-radius:8px;cursor:pointer;">Wejdź</button>
			</form>
		</div>
		<?php
		return ob_get_clean();
	}
	if ( ! function_exists( 'kuchnia_render_dashboard' ) ) {
		return '';
	}
	ob_start();
	kuchnia_render_dashboard( get_permalink(), 'kurier' );
	return ob_get_clean();
} );

add_action( 'admin_menu', function () {
	add_submenu_page( 'rzd-kuchnia', 'Kurier', 'Kurier', 'manage_woocommerce', 'rzd-kurier', function () {
		if ( ! current_user_can( 'manage_woocommerce' ) || ! function_exists( 'kuchnia_render_dashboard' ) ) {
			return;
		}
		echo '<div class="wrap">';
		kuchnia_render_dashboard( admin_url( 'admin.php?page=rzd-kurier' ), 'kurier' );
		echo '</div>';
	} );
}, 20 );

/* ============================================================
 * 3. Widok: zamówienia wybranego terminu w kolejności z Planowania
 * ============================================================ */
function kurier_view_html( $orders, $date ) {
	// Kurier widzi od razu wszystkie zamówienia terminu, żeby mógł planować
	// trasę. "Dostarczone" da się kliknąć dopiero po spakowaniu.
	$sorted = function_exists( 'kuchnia_sort_by_sequence' ) ? kuchnia_sort_by_sequence( $orders ) : $orders;
	ob_start();
	if ( ! $sorted ) {
		echo '<p class="kuchnia-empty">Brak zamówień w tym terminie.</p>';
		return ob_get_clean();
	}
	?>
	<table class="kuchnia-table kurier-table">
		<thead><tr><th>#</th><th>Klient</th><th>Status</th><th>Data i godzina</th><th>Adres</th><th>Telefon</th><th>Płatność</th><th>Zawartość</th><th class="kuchnia-noprint"></th></tr></thead>
		<tbody>
		<?php foreach ( $sorted as $i => $order ) : ?>
			<?php
			// Zawartość zsumowana: te same pozycje (np. kilka "Opakowanie" z różnych
			// dań) w jednej linii z łączną ilością. "Bez: …" pomijamy – to sprawa
			// kuchni, kurier przekazuje tylko to, co jest w torbie.
			$sum = array();
			foreach ( kuchnia_order_lines( $order ) as $l ) {
				if ( ( isset( $l['kind'] ) && 'bez' === $l['kind'] ) || 0 === strpos( $l['name'], 'Bez: ' ) ) {
					continue;
				}
				$sum[ $l['name'] ] = ( isset( $sum[ $l['name'] ] ) ? $sum[ $l['name'] ] : 0 ) + (int) $l['qty'];
			}
			$ptime        = $order->get_meta( '_dc_planned_time' );
			$delivered    = ( 'wydane' === $order->get_status() );
			$delivered_at = $order->get_meta( '_dc_delivered_at' );
			$address      = kuchnia_order_address( $order );
			$phone        = $order->get_billing_phone();
			$tel          = preg_replace( '/[^0-9+]/', '', (string) $phone );
			?>
			<tr>
				<td data-label="#"><?php echo (int) $i + 1; ?></td>
				<td data-label="Klient">#<?php echo esc_html( $order->get_order_number() ); ?> <?php echo esc_html( $order->get_formatted_billing_full_name() ); ?></td>
				<td data-label="Status"><?php echo kuchnia_status_badge_html( $order ); ?></td>
				<td data-label="Godzina"><?php echo esc_html( date_i18n( 'd.m', strtotime( $date ) ) . ' ' . ( $ptime ? $ptime : '—' ) ); ?></td>
				<td data-label="Adres">
					<?php if ( $address ) : ?>
						<a class="kuchnia-maplink" href="<?php echo esc_url( 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode( $address ) ); ?>" target="_blank" rel="noopener">📍 <?php echo esc_html( $address ); ?></a>
					<?php endif; ?>
				</td>
				<td data-label="Telefon">
					<?php if ( $tel ) : ?>
						<a class="kuchnia-tellink" href="<?php echo esc_attr( 'tel:' . $tel ); ?>">📞 <?php echo esc_html( $phone ); ?></a>
					<?php endif; ?>
				</td>
				<td data-label="Płatność"><?php echo kuchnia_payment_html( $order ); ?></td>
				<td data-label="Zawartość" class="kurier-contents">
					<?php foreach ( $sum as $cname => $cqty ) : ?>
						<div><strong><?php echo (int) $cqty; ?>×</strong> <?php echo esc_html( $cname ); ?></div>
					<?php endforeach; ?>
				</td>
				<td data-label="" class="kuchnia-noprint">
					<?php if ( $delivered ) : ?>
						<em>Dostarczone<?php echo $delivered_at ? ( ': ' . esc_html( $delivered_at ) ) : ''; ?></em>
					<?php elseif ( 'w-dostawie' !== $order->get_status() ) : ?>
						<em class="kuchnia-wait">Czeka na spakowanie</em>
					<?php else : ?>
						<button type="button" class="kuchnia-deliver-btn" data-order="<?php echo (int) $order->get_id(); ?>">Dostarczone</button>
					<?php endif; ?>
				</td>
			</tr>
		<?php endforeach; ?>
		</tbody>
	</table>
	<?php
	return ob_get_clean();
}
