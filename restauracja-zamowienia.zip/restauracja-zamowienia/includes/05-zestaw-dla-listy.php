<?php
/**
 * SNIPPET 5: Połączenie "Zestawu dnia" (snippet 4) z listą zamówień (snippet 2)
 * Code Snippets → Run everywhere (pomiń pierwszą linię "<?php")
 *
 * Podaje liście, jakie produkty są w zestawie – w dniu dostawy wybranym przez klienta
 * (moduł 06), a gdy termin nie jest jeszcze wybrany, z NAJBLIŻSZEJ możliwej daty
 * dostawy (o to dba moduł 04 – rwz_default_delivery_date()).
 * Zagnieżdżone zestawy są rozwijane do tego, co jest na końcu zagnieżdżenia
 * (np. "Zupa dnia" → konkretna zupa) – robi to moduł 04, tu nic nie trzeba zmieniać.
 *  - dania główne  → małe linki pod nazwą zestawu
 *  - dodatki       → osobne pozycje z ilością i przyciskiem "Dodaj"
 *  - alergeny zestawu = suma alergenów dań głównych z tego samego dnia
 *    (dodatki mają swoje alergeny przy własnej pozycji)
 *  - harmonogram   → okienko z datami i składem zestawu (historia + kolejne dni)
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter( 'rest_zestaw_skladniki', function ( $ids, $product_id ) {
	if ( ! function_exists( 'rwz_get_active_components' ) ) {
		return $ids;
	}
	$active = rwz_get_active_components( $product_id );
	foreach ( $active['main'] as $p ) {
		if ( (int) $p->get_id() !== (int) $product_id ) {
			$ids[] = $p->get_id();
		}
	}
	return $ids;
}, 10, 2 );

add_filter( 'rest_zestaw_dodatki', function ( $ids, $product_id ) {
	if ( ! function_exists( 'rwz_get_active_components' ) ) {
		return $ids;
	}
	$active = rwz_get_active_components( $product_id );
	foreach ( $active['addon'] as $p ) {
		if ( (int) $p->get_id() !== (int) $product_id ) {
			$ids[] = $p->get_id();
		}
	}
	return $ids;
}, 10, 2 );

add_filter( 'rest_alergeny_zrodla', function ( $ids, $product_id ) {
	if ( ! function_exists( 'rwz_get_active_components' ) ) {
		return $ids;
	}
	$active = rwz_get_active_components( $product_id );
	$dania  = [];
	foreach ( $active['main'] as $p ) {
		if ( (int) $p->get_id() !== (int) $product_id ) {
			$dania[] = $p->get_id();
		}
	}
	// zwykły produkt albo zestaw bez aktywnych dań → własne alergeny produktu
	return $dania ? $dania : $ids;
}, 10, 2 );

/* ---------- Harmonogram: daty + skład zestawu (2.26.1: okienko) ----------
 * Kliknięcie ramki „Harmonogram” na liście otwiera okienko (wspólny styl
 * okienek, moduł 15 → rzd_popup_css). W okienku dzień po dniu: nazwa dnia
 * + dd.mm.rr, dania z miniaturami, dodatki; dziś wyróżnione, minione dni
 * wyszarzone („Harmonogram – dni wstecz” w Wygląd listy, domyślnie 7).
 * Przy dniach, na które da się jeszcze zamówić: „Dodaj na ten dzień” –
 * otwiera okienko terminu (moduł 06) z tym dniem zaznaczonym, potem zwykła
 * ścieżka dodawania (brama, moduł 08). Jeden koszyk = jeden termin dostawy.
 */
// Ile dni do przodu pokazujemy – tyle, na ile pozwala kalendarz dostaw
// (moduł 06), a bez niego rozsądny domyślny zakres dwóch tygodni.
function rwz_schedule_horizon_days() {
	if ( function_exists( 'dc_max_horizon' ) ) {
		$h = (int) dc_max_horizon();
		if ( $h > 0 ) {
			return min( 30, $h );
		}
	}
	return 13;
}

// Ile dni wstecz (historia) – z panelu „Wygląd listy”, 0 = bez historii.
function rwz_schedule_days_back() {
	$back = 7;
	if ( function_exists( 'rzd_list_style_get' ) ) {
		$s = rzd_list_style_get();
		if ( isset( $s['harmono_days_back'] ) && is_numeric( $s['harmono_days_back'] ) ) {
			$back = (int) $s['harmono_days_back'];
		}
	}
	return max( 0, min( 60, $back ) );
}

// Polska nazwa dnia tygodnia (bez zależności od języka serwera – „Środa”, nie „środa”).
function rwz_pl_day_name( $date ) {
	$names = array( 'Mon' => 'Poniedziałek', 'Tue' => 'Wtorek', 'Wed' => 'Środa', 'Thu' => 'Czwartek', 'Fri' => 'Piątek', 'Sat' => 'Sobota', 'Sun' => 'Niedziela' );
	$dow   = ( new DateTime( $date, wp_timezone() ) )->format( 'D' );
	return isset( $names[ $dow ] ) ? $names[ $dow ] : $dow;
}

// Dni, na które ten zestaw da się jeszcze zamówić (kalendarz dostaw z cutoffami,
// bufor 2 min w module 06). Miejscowość, pojemność okien i koszyk sprawdzi
// okienko terminu – tu tylko „czy pokazać przycisk”.
function rwz_schedule_open_dates( $product_id ) {
	if ( ! function_exists( 'dc_slots_for_products' ) || ( function_exists( 'dc_enabled' ) && ! dc_enabled() ) ) {
		return array();
	}
	$slots = dc_slots_for_products( array( $product_id ) );
	return is_array( $slots ) ? array_filter( $slots ) : array();
}

// Skład zestawu dzień po dniu (od dziś − dni wstecz do horyzontu kalendarza):
// [ ['date','day','short','past','today','open','main'=>[[name,img]],'addon'=>nazwy], … ]
// Pomija dni bez żadnego aktywnego składnika – nie ma tam nic do pokazania.
function rwz_get_schedule( $product_id ) {
	if ( ! function_exists( 'rwz_get_slots' ) || ! rwz_get_slots( $product_id ) ) {
		return array();
	}
	$back  = rwz_schedule_days_back();
	$ahead = rwz_schedule_horizon_days();
	$today = current_time( 'Y-m-d' );
	$open  = rwz_schedule_open_dates( $product_id );
	$out   = array();
	$day   = new DateTime( $today, wp_timezone() );
	if ( $back ) {
		$day->modify( '-' . $back . ' days' );
	}

	for ( $i = -$back; $i <= $ahead; $i++ ) {
		$date   = $day->format( 'Y-m-d' );
		$active = rwz_get_active_components( $product_id, $date );
		if ( $active['main'] || $active['addon'] ) {
			$out[] = array(
				'date'  => $date,
				'day'   => rwz_pl_day_name( $date ),
				'short' => $day->format( 'd.m.y' ),
				'past'  => $date < $today,
				'today' => $date === $today,
				'open'  => $date >= $today && ! empty( $open[ $date ] ),
				'main'  => array_map( function ( $p ) {
					return array( $p->get_name(), (int) $p->get_image_id() );
				}, $active['main'] ),
				'addon' => array_map( function ( $p ) { return $p->get_name(); }, $active['addon'] ),
			);
		}
		$day->modify( '+1 day' );
	}
	return $out;
}

// Treść okienka – to jest ta kosztowna część (pętla po dniach). Renderowana
// TYLKO na żądanie (patrz AJAX niżej), nie przy każdym wczytaniu listy.
function rwz_render_schedule_table_html( $product_id ) {
	$schedule = rwz_get_schedule( $product_id );
	if ( ! $schedule ) {
		return '<p class="rwz-hm-empty">Brak zaplanowanego składu w najbliższym czasie.</p>';
	}
	$product = wc_get_product( $product_id );
	$title   = ( function_exists( 'rzd_list_label' ) ? rzd_list_label( 'harmono' ) : 'Harmonogram' ) . ( $product ? ': ' . $product->get_name() : '' );
	ob_start();
	?>
	<div class="rwz-hm-list" data-title="<?php echo esc_attr( $title ); ?>">
		<?php foreach ( $schedule as $row ) : ?>
			<div class="rwz-hm-day<?php echo $row['past'] ? ' is-past' : ''; ?><?php echo $row['today'] ? ' is-today' : ''; ?>">
				<div class="rwz-hm-date">
					<strong><?php echo esc_html( $row['day'] ); ?></strong>
					<span><?php echo esc_html( $row['short'] ); ?></span>
					<?php if ( $row['today'] ) : ?><em>dziś</em><?php endif; ?>
				</div>
				<div class="rwz-hm-main">
					<?php if ( $row['main'] ) : ?>
						<ul class="rwz-hm-dishes">
							<?php foreach ( $row['main'] as $dish ) : ?>
								<li>
									<?php
									if ( $dish[1] ) {
										// 2.26.4: klik w miniaturę = duże zdjęcie (data-full, rozmiar „large”).
										echo wp_get_attachment_image( $dish[1], 'thumbnail', false, array(
											'class'     => 'rwz-hm-img',
											'loading'   => 'lazy',
											'alt'       => $dish[0],
											'data-full' => (string) wp_get_attachment_image_url( $dish[1], 'large' ),
											'role'      => 'button',
											'tabindex'  => '0',
										) );
									}
									?>
									<span><?php echo esc_html( $dish[0] ); ?></span>
								</li>
							<?php endforeach; ?>
						</ul>
					<?php endif; ?>
					<?php if ( $row['addon'] ) : ?>
						<div class="rwz-hm-addons">Dodatki: <?php echo esc_html( implode( ', ', $row['addon'] ) ); ?></div>
					<?php endif; ?>
				</div>
				<?php // 2.26.3: przycisk / „zamknięte” w osobnej kolumnie po prawej. ?>
				<?php if ( $row['open'] ) : ?>
					<div class="rwz-hm-side"><button type="button" class="rwz-hm-add" data-date="<?php echo esc_attr( $row['date'] ); ?>">Dodaj na ten dzień</button></div>
				<?php elseif ( ! $row['past'] ) : ?>
					<div class="rwz-hm-side"><span class="rwz-hm-closed">Zamówienia zamknięte</span></div>
				<?php endif; ?>
			</div>
		<?php endforeach; ?>
	</div>
	<?php
	return ob_get_clean();
}

add_action( 'wc_ajax_rwz_harmonogram', function () {
	$pid = isset( $_GET['product_id'] ) ? absint( $_GET['product_id'] ) : 0;
	echo $pid ? rwz_render_schedule_table_html( $pid ) : ''; // phpcs:ignore
	wp_die();
} );

/**
 * WYDAJNOŚĆ: na liście pokazujemy tylko "skorupkę" – ramkę z tytułem.
 * Treść okienka (pętla po wszystkich dniach) liczymy dopiero, gdy klient
 * faktycznie kliknie "Harmonogram", przez mały request AJAX.
 * <details> zostaje (wygląd ramki z panelu), ale kliknięcie nie rozwija go,
 * tylko otwiera okienko.
 */
function rwz_render_schedule_html( $product_id ) {
	if ( ! function_exists( 'rwz_get_slots' ) || ! rwz_get_slots( $product_id ) ) {
		return '';
	}
	return '<details class="rl-harmono" data-product="' . esc_attr( $product_id ) . '">'
		. '<summary>' . esc_html( function_exists( 'rzd_list_label' ) ? rzd_list_label( 'harmono' ) : 'Harmonogram' ) . '</summary>'
		. '</details>';
}

add_filter( 'rest_zestaw_harmonogram', function ( $html, $product_id ) {
	if ( ! function_exists( 'rwz_render_schedule_html' ) ) {
		return $html;
	}
	return rwz_render_schedule_html( $product_id );
}, 10, 2 );

// 2.26.7: „Harmonogram” zestawu także na stronie produktu (pod alergenami, priorytet 26).
add_action( 'woocommerce_single_product_summary', function () {
	global $product;
	if ( ! $product || ! function_exists( 'rzd_list_style_get' ) ) {
		return;
	}
	$s = rzd_list_style_get();
	if ( empty( $s['single_on'] ) || empty( $s['single_harmono'] ) ) {
		return;
	}
	echo rwz_render_schedule_html( $product->get_id() ); // phpcs:ignore – pusty, gdy to nie zestaw
}, 26 );

// 2.26.13: skrypt okienka jako plik (wcześniej w stopce każdej strony).
add_action( 'wp_enqueue_scripts', function () {
	if ( ! class_exists( 'WC_AJAX' ) ) {
		return;
	}
	wp_enqueue_script( 'rzd-harmonogram', RZD_PLUGIN_URL . 'assets/js/rzd-harmonogram.js', array(), rzd_asset_ver( 'assets/js/rzd-harmonogram.js' ), array( 'in_footer' => true, 'strategy' => 'defer' ) );
	wp_add_inline_script( 'rzd-harmonogram', 'var rzdHarmonoCfg = ' . wp_json_encode( array( 'url' => WC_AJAX::get_endpoint( 'rwz_harmonogram' ) ) ) . ';', 'before' );
} );

// Okienko harmonogramu (znaczniki). Wygląd: moduł 15 → rzd_popup_css().
add_action( 'wp_footer', function () {
	if ( is_admin() || ! class_exists( 'WC_AJAX' ) ) {
		return;
	}
	?>
	<div id="rwz-hm-zoom" hidden><figure><img alt=""><figcaption></figcaption></figure><button type="button" class="rwz-hm-zoom-x" aria-label="Zamknij zdjęcie">✕</button></div>
	<div id="rwz-harmono" hidden>
		<div class="dc-panel" role="dialog" aria-modal="true" aria-labelledby="rwz-hm-title">
			<?php // 2.26.3: przyklejony pasek z tytułem i krzyżykiem – zamknięcie z każdego miejsca listy. ?>
			<div class="rwz-hm-head">
				<h3 id="rwz-hm-title" class="dc-title"><?php echo esc_html( function_exists( 'rzd_list_label' ) ? rzd_list_label( 'harmono' ) : 'Harmonogram' ); ?></h3>
				<button type="button" class="rwz-hm-x rwz-hm-close" aria-label="Zamknij">✕</button>
			</div>
			<div class="rwz-hm-body"></div>
			<div class="dc-actions">
				<div class="dc-act"><button type="button" class="dc-ok rwz-hm-close">Zamknij</button></div>
			</div>
		</div>
	</div>
	
	<?php
}, 15 ); // 2.26.13: przed skryptami stopki (wp_print_footer_scripts = 20)

/* ---------- Strona produktu-zestawu: linki do składników zamiast "podobnych produktów" ---------- */
add_action( 'wp', function () {
	if ( ! function_exists( 'is_product' ) || ! is_product() || ! function_exists( 'rwz_get_slots' ) ) {
		return;
	}
	global $post;
	if ( ! $post || ! rwz_get_slots( $post->ID ) ) {
		return;
	}
	remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );
	add_action( 'woocommerce_after_single_product_summary', 'rwz_render_set_components_block', 20 );
} );

function rwz_render_set_components_block() {
	global $product;
	if ( ! $product ) {
		return;
	}
	$dania   = apply_filters( 'rest_zestaw_skladniki', array(), $product->get_id() );
	$dodatki = apply_filters( 'rest_zestaw_dodatki', array(), $product->get_id() );
	if ( ! $dania && ! $dodatki ) {
		return;
	}
	echo '<section class="rwz-set-components"><h2>Składniki zestawu</h2><ul class="rwz-set-links">';
	foreach ( $dania as $cid ) {
		$lbl = function_exists( 'rwz_get_component_role' ) ? rwz_get_component_role( $product->get_id(), $cid ) : array( 'label' => '' );
		echo '<li>' . ( $lbl['label'] ? '<span class="rwz-role-inline">' . esc_html( $lbl['label'] ) . ':</span> ' : '' ) . rwz_component_link_or_text( $cid ) . '</li>';
	}
	foreach ( $dodatki as $cid ) {
		echo '<li>' . rwz_component_link_or_text( $cid ) . ' <span class="rwz-set-addon-tag">(dodatek)</span></li>';
	}
	echo '</ul></section>';
}

/**
 * Zwykły produkt → link (bezpiecznie, zawsze pokaże to samo, co tu widać).
 * Zagnieżdżony ZESTAW (ma własny harmonogram) → sama nazwa, BEZ linku –
 * jego własna strona przelicza "dziś" od nowa i niezależnie od kontekstu,
 * z którego przyszliśmy, może pokazać zupełnie inny dzień (np. wejście w
 * "Zupa dnia" pokazane tu jako nazwa zastępcza pokazałoby na własnej
 * stronie akurat dzisiejszą zupę, myląco sugerując błędny link).
 */
function rwz_component_link_or_text( $cid ) {
	$is_nested_zestaw = function_exists( 'rwz_get_slots' ) && rwz_get_slots( $cid );
	if ( $is_nested_zestaw ) {
		return esc_html( get_the_title( $cid ) );
	}
	return '<a href="' . esc_url( get_permalink( $cid ) ) . '">' . esc_html( get_the_title( $cid ) ) . '</a>';
}
