<?php
/**
 * Moduł 34-panel – kokpit: wejście „Restauracja → Panel restauracji” (tworzy stronę, gdy jej nie ma)
 * i przekierowanie dawnych stron, które przeniesiono do panelu (zakładki w przeglądarce działają dalej).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Dawne strony kokpitu => sekcja panelu. */
function rzd_panel_moved_pages() {
	return array(
		'rzd-panel'      => '',
		'rzd-towns'      => 'miejscowosci',
		'rzd-sala'       => 'sala',
		'rzd-wiadomosci' => 'wiadomosci',
		'rr-raporty'     => 'raporty',
		// 2.45.0
		'delivery-calendar' => 'terminy',
		'rzd-zestawy'       => 'zestawy',
		// 2.45.0 (etapy 3–4); „sekcja:zakładka”
		'kc-koszyk'         => 'sklep:koszyk',
		'rzd-formularz'     => 'sklep:formularz',
		'rzd-wyglad-listy'  => 'wyglad',
		'rzd-menu-strony'   => 'strona',
		'rzd-formularze'    => 'formularze',
		'rzd-uprawnienia'   => 'zespol:uprawnienia', // dawniej Użytkownicy → Uprawnienia
	);
}

/**
 * Ekrany WordPressa dawnych katalogów (2.45.0) => [ sekcja, zakładka ]: listy, dodawanie i edycja
 * Dodatków, Wzorów, Opakowań oraz Typów dodatków i Etykiet na zestawie.
 */
function rzd_panel_moved_screens() {
	return array(
		'rzd_addon'      => array( 'menu', 'dodatki' ),
		'rzd_mod_preset' => array( 'menu', 'wzory' ),
		'rzd_packaging'  => array( 'menu', 'opakowania' ),
		'rzd_addon_type' => array( 'menu', 'typy' ),
		'rzd_set_label'  => array( 'menu', 'etykiety' ),
	);
}

add_action( 'admin_init', function () {
	global $pagenow;
	if ( wp_doing_ajax() || 'GET' !== ( isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : 'GET' ) ) { // phpcs:ignore
		return;
	}
	$map = rzd_panel_moved_screens();
	$key = '';
	$id  = 0;
	if ( in_array( $pagenow, array( 'edit.php', 'post-new.php' ), true ) && isset( $_GET['post_type'] ) ) { // phpcs:ignore
		$key = sanitize_key( wp_unslash( $_GET['post_type'] ) ); // phpcs:ignore
	} elseif ( 'post.php' === $pagenow && isset( $_GET['post'], $_GET['action'] ) && 'edit' === $_GET['action'] ) { // phpcs:ignore
		$id  = absint( $_GET['post'] ); // phpcs:ignore
		$key = (string) get_post_type( $id );
	} elseif ( in_array( $pagenow, array( 'edit-tags.php', 'term.php' ), true ) && isset( $_GET['taxonomy'] ) ) { // phpcs:ignore
		$key = sanitize_key( wp_unslash( $_GET['taxonomy'] ) ); // phpcs:ignore
	}
	if ( '' === $key || ! isset( $map[ $key ] ) ) {
		return;
	}
	if ( ! rzd_panel_section_can( $map[ $key ][0] ) ) {
		return; // bez dostępu do panelu – jak dotąd (konto obsługi → swój ekran, inaczej odmowa WordPressa)
	}
	if ( '' === rzd_panel_ensure_page() ) {
		return;
	}
	$args = array( 'tab' => $map[ $key ][1] );
	if ( $id ) {
		$args['id'] = $id;
	}
	wp_safe_redirect( rzd_panel_url( $map[ $key ][0], $args ) );
	exit;
}, 1 );

/*
 * Dawne strony nie są już w menu, więc WordPress odmówiłby dostępu („Nie masz uprawnień…”) jeszcze
 * przed admin_init – stąd także admin_page_access_denied. „rzd-panel” jest w menu → admin_init.
 */
function rzd_panel_kokpit_redirect() {
	if ( wp_doing_ajax() || ! isset( $_GET['page'] ) ) { // phpcs:ignore
		return;
	}
	$page  = sanitize_key( wp_unslash( $_GET['page'] ) ); // phpcs:ignore
	$moved = rzd_panel_moved_pages();
	if ( ! isset( $moved[ $page ] ) ) {
		return;
	}
	if ( ! rzd_panel_can() ) {
		wp_die( 'Brak uprawnień – to konto nie ma dostępu do Panelu restauracji.', 403 );
	}
	$url = rzd_panel_ensure_page();
	if ( '' === $url ) {
		wp_die( 'Nie udało się utworzyć strony „Panel restauracji”. Utwórz zwykłą stronę z treścią [rzd_panel].' );
	}
	$args = array();
	$sec  = $moved[ $page ];
	if ( false !== strpos( $sec, ':' ) ) {
		list( $sec, $args['tab'] ) = explode( ':', $sec, 2 );
	}
	if ( '' !== $sec && ! rzd_panel_section_can( $sec ) ) {
		wp_die( 'Brak uprawnień – to konto nie ma dostępu do tej części Panelu restauracji.', 403 );
	}
	if ( 'rzd-formularze' === $page && ! empty( $_GET['edit'] ) ) { // phpcs:ignore
		$args['form'] = sanitize_key( wp_unslash( $_GET['edit'] ) ); // phpcs:ignore
	}
	if ( 'rzd-wiadomosci' === $page && ! empty( $_GET['form'] ) ) { // phpcs:ignore
		$args['form'] = sanitize_key( wp_unslash( $_GET['form'] ) ); // phpcs:ignore
	}
	if ( 'rzd-zestawy' === $page && ! empty( $_GET['product_id'] ) ) { // phpcs:ignore
		$args['zestaw'] = absint( $_GET['product_id'] ); // phpcs:ignore
	}
	wp_safe_redirect( '' !== $sec ? rzd_panel_url( $sec, $args ) : $url );
	exit;
}
add_action( 'admin_page_access_denied', 'rzd_panel_kokpit_redirect', 1 );
add_action( 'admin_init', 'rzd_panel_kokpit_redirect', 1 );

/** Strona „Restauracja → Panel restauracji” – zwykle przekierowuje wcześniej (admin_init); to tylko zapas. */
function rzd_panel_admin_page() {
	$url = rzd_panel_ensure_page();
	echo '<div class="wrap"><h1>Panel restauracji</h1><p><a class="button button-primary" href="' . esc_url( $url ) . '">Otwórz Panel restauracji</a></p></div>';
}
