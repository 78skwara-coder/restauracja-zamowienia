<?php
/**
 * Moduł 34-panel – sekcja „Post dnia” (2.48.0, moduł 38-posty). Zakładki (rzd-panel-posty.js): Nowy post,
 * Plan tygodnia, Historia, Ustawienia. Akcje: posts (dane sekcji), posts_day (dania i zdjęcia zestawu na dzień),
 * posts_generate, posts_save, posts_publish, posts_unschedule, posts_delete, posts_settings_save, posts_models,
 * posts_fb_check, posts_media_list / posts_media_upload (wybór zdjęć – te same funkcje co w Sklepie).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter( 'rzd_panel_actions', function ( $a ) {
	foreach ( array( 'posts', 'posts_day', 'posts_generate', 'posts_save', 'posts_publish', 'posts_unschedule', 'posts_delete', 'posts_settings_save', 'posts_models', 'posts_fb_check', 'posts_ai_test', 'posts_product', 'posts_media_list', 'posts_media_upload', 'posts_park', 'posts_copy', 'posts_week_set', 'posts_ig_retry', 'posts_keep' ) as $k ) {
		$a[ $k ] = 'posty';
	}
	return $a;
} );

function rzd_panel_posts_payload() {
	$s       = rzd_posts_settings();
	$history = array();
	$not_parked = array( 'relation' => 'OR', array( 'key' => '_parked', 'compare' => 'NOT EXISTS' ), array( 'key' => '_parked', 'value' => '1', 'compare' => '!=' ) ); // (2.50.0) odłożone – osobna zakładka
	foreach ( get_posts( array( 'post_type' => 'rzd_fbpost', 'post_status' => 'publish', 'numberposts' => 40, 'fields' => 'ids', 'orderby' => 'date', 'order' => 'DESC', 'meta_query' => $not_parked ) ) as $id ) { // phpcs:ignore
		$p = rzd_posts_get( $id );
		if ( $p ) {
			$p['fbUrl']    = rzd_posts_fb_url( $p['fb'] );
			$p['dayLabel'] = rzd_panel_posts_label( $p );
			$history[]     = $p;
		}
	}
	$days = array();
	$d    = new DateTime( current_time( 'Y-m-d' ), wp_timezone() );
	for ( $i = 0; $i <= 14; $i++ ) {
		$days[] = array( 'day' => $d->format( 'Y-m-d' ), 'label' => ucfirst( rzd_dc_date_label( $d->format( 'Y-m-d' ) ) ) );
		$d->modify( '+1 day' );
	}
	$vals = array(
		'ai_images'    => (int) $s['ai_images'],
		'instructions' => $s['instructions'],
		'about'        => $s['about'],
		'gen_time'     => $s['gen_time'],
		'pub_time'     => $s['pub_time'],
		'auto'         => (int) $s['auto'],
		'mail_to'      => $s['mail_to'],
		'sections'     => $s['sections'],
		'place'        => $s['place'],
		'place_def'    => (int) $s['place_def'],
		'ratio'        => rzd_posts_ratio_key( $s['ratio'] ),
		'auto_ai'      => $s['auto_ai'],
		'week_set'     => (int) $s['week_set'],
		'ig_def'       => (int) $s['ig_def'],
		'keep_days'    => (int) $s['keep_days'],
		'autos'        => $s['autos'], // (2.57.0)
	);
	$parked = array();
	foreach ( rzd_posts_parked_list() as $p ) {
		$p['dayLabel'] = rzd_panel_posts_label( $p );
		$parked[]      = $p;
	}
	$ratios = array();
	foreach ( rzd_posts_ratios() as $k => $r ) {
		$ratios[] = array( 'k' => $k, 'n' => $r[0], 'r' => $r[1] );
	}
	$hasKey   = '' !== rzd_posts_secret( 'gemini_key' );
	$hasToken = '' !== rzd_posts_secret( 'fb_token' );
	return array(
		'ready'    => rzd_ai_ready() && $hasToken && '' !== $s['fb_page'],
		'ai'       => rzd_ai_choices(), // (2.53.0) pole „AI:” przy Generuj
		'hasKey'   => $hasKey,
		'hasToken' => $hasToken,
		'keyConst' => defined( 'RZD_GEMINI_KEY' ),
		'tokConst' => defined( 'RZD_FB_TOKEN' ),
		'sets'     => rzd_posts_sets(),
		'days'     => $days,
		'week'     => rzd_posts_week( 7 ),
		'history'  => $history,
		'values'   => $vals,
		'statuses' => rzd_posts_status_labels(),
		'pubTime'  => $s['pub_time'],
		'genTime'  => $s['gen_time'],
		'now'      => time(),
		'tz'       => wp_timezone_string(),
		'lastCall' => rzd_panel_posts_last_call(),
		'instrWarn' => rzd_posts_instructions_warn( $s ),
		'kinds'    => rzd_posts_kinds(),
		'products' => rzd_posts_products(),
		'nextPub'  => rzd_posts_next_pub_time(),
		'parked'   => $parked,
		'api'      => rzd_api_status(), // (2.51.0) stan połączeń – klucze w Połączeniach API
		'canApi'   => rzd_can( 'api' ),
		'ratios'   => $ratios,
		'today'    => current_time( 'Y-m-d' ),
		'ig'       => array( 'on' => rzd_posts_ig_on(), 'user' => $s['ig_user'] ), // (2.55.0)
		'edUrl'    => rzd_can( 'menu' ) && function_exists( 'rzd_ed_page_url' ) && rzd_page_url_opt( 'rzd_ed_page_id', 'edycja_produktow' ) ? rzd_ed_page_url() : '', // (2.53.2) „Zmień dania”
	);
}

/** Opis posta w Historii: dzień zestawu, produkt albo początek tematu (2.49.0). */
function rzd_panel_posts_label( $p ) {
	if ( 'product' === $p['kind'] ) {
		return 'Produkt: ' . ( $p['product'] ? get_the_title( $p['product'] ) : '?' );
	}
	if ( 'topic' === $p['kind'] ) {
		return 'Temat: ' . mb_substr( $p['topic'], 0, 60 ) . ( mb_strlen( $p['topic'] ) > 60 ? '…' : '' );
	}
	return $p['day'] ? ucfirst( rzd_dc_date_label( $p['day'] ) ) : '';
}

/** „Ostatnie zapytanie do Gemini” – diagnostyka w Ustawieniach. */
function rzd_panel_posts_last_call() {
	$c = get_option( 'rzd_posts_last_call' );
	if ( ! is_array( $c ) || empty( $c['time'] ) ) {
		return '';
	}
	$ps   = function_exists( 'rzd_ai_providers' ) ? rzd_ai_providers() : array();
	$prov = ! empty( $c['provider'] ) && isset( $ps[ $c['provider'] ] ) ? $ps[ $c['provider'] ][0] . ' ' : '';
	$tok  = isset( $c['tok_in'] ) && null !== $c['tok_in'] ? ' · tokeny: ' . (int) $c['tok_in'] . ' wejście / ' . (int) $c['tok_out'] . ' wyjście' : '';
	$tok .= isset( $c['web'] ) && null !== $c['web'] ? ' · wyszukiwania w internecie: ' . (int) $c['web'] : ''; // (2.54.0)
	return wp_date( 'j.m H:i', (int) $c['time'] ) . ' · ' . ( isset( array( 'test' => 1, 'opis' => 1 )[ $c['what'] ] ) ? $c['what'] : 'post' ) . ' · ' . $prov . $c['model'] . ( ! empty( $c['api'] ) ? ' (' . $c['api'] . ')' : '' ) . ' · ' . str_replace( '.', ',', (string) $c['secs'] ) . ' s' . $tok . ' · ' . ( $c['ok'] ? 'OK' : 'błąd: ' . $c['msg'] );
}

/** (2.53.0) Dostawca AI z pola „AI:” (parametr ai) – tylko skonfigurowany; inaczej odmowa. */
function rzd_panel_ai_pick() {
	$p = rzd_panel_str( 'ai' );
	if ( '' === $p ) {
		return;
	}
	if ( ! function_exists( 'rzd_ai_provider_ready' ) || ! rzd_ai_provider_ready( $p ) ) {
		rzd_panel_fail( 'Ten dostawca AI nie jest skonfigurowany – Panel → Połączenia API.' );
	}
	rzd_ai_use( $p );
}

function rzd_panel_posts_day_ok( $day ) {
	if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $day ) ) {
		rzd_panel_fail( 'Nieprawidłowy dzień.' );
	}
	return $day;
}

/** Zdjęcia z panelu: tylko obrazki z biblioteki (id) – adres liczony na serwerze. */
function rzd_panel_posts_photos( $in ) {
	$out = array();
	foreach ( is_array( $in ) ? $in : array() as $ph ) {
		$id = is_array( $ph ) && isset( $ph['id'] ) ? (int) $ph['id'] : (int) $ph;
		$p  = $id && wp_attachment_is_image( $id ) ? rzd_posts_photo( $id ) : null;
		if ( $p ) {
			if ( is_array( $ph ) && ( isset( $ph['fx'] ) || isset( $ph['fy'] ) ) ) { // (2.50.0) punkt kadru
				$p['fx'] = rzd_posts_focus( isset( $ph['fx'] ) ? $ph['fx'] : null );
				$p['fy'] = rzd_posts_focus( isset( $ph['fy'] ) ? $ph['fy'] : null );
			}
			$out[] = $p;
		}
	}
	return array_slice( $out, 0, 10 );
}

function rzd_panel_do_posts() {
	rzd_panel_out( rzd_panel_posts_payload() );
}

function rzd_panel_do_posts_day() {
	$day = rzd_panel_posts_day_ok( rzd_panel_str( 'day' ) );
	$dd  = rzd_posts_day_data( (int) rzd_panel_str( 'set' ), $day );
	$dd['posts'] = rzd_posts_for_day( $day, true );
	$dd['when']  = rzd_posts_default_when( $day, (int) rzd_panel_str( 'set' ) );
	$dd['closed'] = function_exists( 'rzd_posts_day_closed' ) && rzd_posts_day_closed( (int) rzd_panel_str( 'set' ), $day ); // (2.56.2)
	rzd_panel_out( $dd );
}

function rzd_panel_do_posts_generate() {
	rzd_panel_ai_pick();
	$day = rzd_panel_posts_day_ok( rzd_panel_str( 'day' ) );
	$pid = (int) rzd_panel_str( 'post' );
	if ( $pid ) {
		$old = rzd_posts_get( $pid );
		if ( ! $old || in_array( $old['status'], array( 'scheduled', 'published' ), true ) ) {
			rzd_panel_fail( 'Tego posta nie można już zmienić – jest na Facebooku.' );
		}
	}
	$ph   = rzd_panel_json( 'photos' );
	$kind = rzd_panel_str( 'kind' );
	if ( in_array( $kind, array( 'product', 'topic' ), true ) ) {
		try {
			list( $ok, $p ) = rzd_posts_generate_other( $kind, (int) rzd_panel_str( 'product' ), mb_substr( isset( $_POST['topic'] ) ? sanitize_textarea_field( wp_unslash( (string) $_POST['topic'] ) ) : '', 0, 1500 ), mb_substr( rzd_panel_str( 'extra' ), 0, 500 ), null === $ph ? null : rzd_panel_posts_photos( $ph ), $pid ); // phpcs:ignore
		} catch ( Throwable $e ) {
			rzd_panel_fail( 'Błąd przy przygotowaniu posta: ' . $e->getMessage() );
		}
		if ( ! $ok ) {
			rzd_panel_fail( $p );
		}
		rzd_panel_posts_place( $p['id'] );
		rzd_panel_out( array( 'post' => rzd_posts_get( $p['id'] ), 'message' => 'Gotowe – sprawdź tekst i zatwierdź.' ) );
	}
	try {
		list( $ok, $p ) = rzd_posts_generate( (int) rzd_panel_str( 'set' ), $day, mb_substr( rzd_panel_str( 'extra' ), 0, 500 ), null === $ph ? null : rzd_panel_posts_photos( $ph ), $pid, rzd_panel_str( 'src' ) === 'week' ? 'week' : 'manual' );
	} catch ( Throwable $e ) {
		rzd_panel_fail( 'Błąd przy przygotowaniu posta: ' . $e->getMessage() );
	}
	if ( ! $ok ) {
		rzd_panel_fail( $p );
	}
	rzd_panel_posts_place( $p['id'] );
	rzd_panel_out( array( 'post' => rzd_posts_get( $p['id'] ), 'message' => 'Gotowe – sprawdź tekst i zatwierdź.' ) );
}

/** Przełącznik „📍 oznacz lokalizację” przy poście (gdy przyszedł z panelu); (2.50.0) też format zdjęć. */
function rzd_panel_posts_place( $id ) {
	if ( isset( $_POST['place'] ) ) { // phpcs:ignore
		update_post_meta( (int) $id, '_place', rzd_panel_str( 'place' ) ? 1 : 0 );
	}
	if ( isset( $_POST['ratio'] ) ) { // phpcs:ignore
		update_post_meta( (int) $id, '_ratio', rzd_posts_ratio_key( rzd_panel_str( 'ratio' ), '' ) );
	}
	if ( isset( $_POST['ig'] ) ) { // phpcs:ignore -- (2.55.0) „Także na Instagramie”
		update_post_meta( (int) $id, '_ig', rzd_panel_str( 'ig' ) ? 1 : 0 );
	}
}

function rzd_panel_do_posts_product() {
	$dd = rzd_posts_product_data( (int) rzd_panel_str( 'product' ) );
	if ( ! $dd ) {
		rzd_panel_fail( 'Nie znaleziono produktu.' );
	}
	rzd_panel_out( $dd );
}

function rzd_panel_do_posts_save() {
	$p = rzd_posts_get( (int) rzd_panel_str( 'post' ) );
	if ( ! $p ) {
		rzd_panel_fail( 'Nie znaleziono posta.' );
	}
	if ( in_array( $p['status'], array( 'scheduled', 'published' ), true ) ) {
		rzd_panel_fail( 'Ten post jest już na Facebooku – najpierw cofnij planowanie.' );
	}
	$text = isset( $_POST['text'] ) ? sanitize_textarea_field( wp_unslash( (string) $_POST['text'] ) ) : $p['text']; // phpcs:ignore
	$ph   = rzd_panel_json( 'photos' );
	rzd_posts_save_post( array( 'id' => $p['id'], 'day' => $p['day'], 'text' => mb_substr( $text, 0, 5000 ), 'photos' => null === $ph ? $p['photos'] : rzd_panel_posts_photos( $ph ) ) );
	rzd_panel_posts_place( $p['id'] );
	rzd_panel_out( array( 'post' => rzd_posts_get( $p['id'] ), 'message' => 'Zapisano szkic.' ) );
}

/** (2.50.0) „Odłóż na potem”: zapis poprawek + znacznik, bez godziny publikacji. */
function rzd_panel_do_posts_park() {
	$p = rzd_posts_get( (int) rzd_panel_str( 'post' ) );
	if ( ! $p ) {
		rzd_panel_fail( 'Nie znaleziono posta.' );
	}
	if ( in_array( $p['status'], array( 'scheduled', 'published' ), true ) ) {
		rzd_panel_fail( 'Ten post jest już na Facebooku – najpierw cofnij planowanie.' );
	}
	$text = isset( $_POST['text'] ) ? sanitize_textarea_field( wp_unslash( (string) $_POST['text'] ) ) : $p['text']; // phpcs:ignore
	$ph   = rzd_panel_json( 'photos' );
	rzd_posts_save_post( array( 'id' => $p['id'], 'day' => $p['day'], 'text' => mb_substr( $text, 0, 5000 ), 'photos' => null === $ph ? $p['photos'] : rzd_panel_posts_photos( $ph ), 'status' => 'draft', 'when' => 0, 'parked' => 1, 'err' => '' ) );
	rzd_panel_posts_place( $p['id'] );
	rzd_panel_out( array_merge( rzd_panel_posts_payload(), array( 'post' => rzd_posts_get( $p['id'] ), 'message' => 'Odłożone – znajdziesz go w zakładce „Odłożone”.' ) ) );
}

/** (2.50.0) „Użyj ponownie”: kopia jako nowy szkic do edycji (oryginał zostaje). */
function rzd_panel_do_posts_copy() {
	list( $ok, $p ) = rzd_posts_copy( (int) rzd_panel_str( 'post' ) );
	if ( ! $ok ) {
		rzd_panel_fail( $p );
	}
	rzd_panel_out( array_merge( rzd_panel_posts_payload(), array( 'post' => $p, 'message' => 'Kopia gotowa – popraw i zatwierdź.' ) ) );
}

function rzd_panel_do_posts_publish() {
	$id = (int) rzd_panel_str( 'post' );
	if ( isset( $_POST['text'] ) ) { // phpcs:ignore -- najpierw zapis bieżących poprawek
		$p = rzd_posts_get( $id );
		if ( $p && 'draft' === $p['status'] ) {
			$ph = rzd_panel_json( 'photos' );
			rzd_posts_save_post( array( 'id' => $id, 'day' => $p['day'], 'text' => mb_substr( sanitize_textarea_field( wp_unslash( (string) $_POST['text'] ) ), 0, 5000 ), 'photos' => null === $ph ? $p['photos'] : rzd_panel_posts_photos( $ph ) ) ); // phpcs:ignore
		}
	}
	$cur = rzd_posts_get( $id );
	if ( $cur && 'draft' === $cur['status'] ) {
		rzd_panel_posts_place( $id );
	}
	$when = 'now' === rzd_panel_str( 'mode' ) ? 0 : (int) rzd_panel_str( 'when' );
	list( $ok, $p ) = rzd_posts_fb_publish( $id, $when );
	if ( ! $ok ) {
		rzd_panel_fail( $p );
	}
	$ig = function_exists( 'rzd_posts_ig_after_fb' ) ? rzd_posts_ig_after_fb( $id, $when ) : ''; // (2.55.0)
	rzd_panel_out( array( 'post' => rzd_posts_get( $id ), 'message' => ( $when ? 'Zaplanowane – Facebook opublikuje post ' . wp_date( 'j.m H:i', $when ) . '.' : 'Opublikowano na Facebooku.' ) . ( '' !== $p['err'] ? ' ' . $p['err'] : '' ) . ( '' !== $ig ? ' ' . $ig : '' ) ) );
}

/** (2.55.0) „Ponów na Instagramie” – post już na Facebooku, Instagram z błędem albo pominięty. */
function rzd_panel_do_posts_ig_retry() {
	$p = rzd_posts_get( (int) rzd_panel_str( 'post' ) );
	if ( ! $p || ! in_array( $p['status'], array( 'scheduled', 'published' ), true ) ) {
		rzd_panel_fail( 'Najpierw opublikuj albo zaplanuj post na Facebooku.' );
	}
	if ( 'scheduled' === $p['status'] && $p['when'] > time() ) {
		update_post_meta( $p['id'], '_ig', 1 );
		$m = rzd_posts_ig_after_fb( $p['id'], $p['when'] );
		rzd_panel_out( array( 'post' => rzd_posts_get( $p['id'] ), 'message' => '' !== $m ? $m : 'Instagram nie jest połączony.' ) );
	}
	list( $ok, $r ) = rzd_posts_ig_publish( $p['id'] );
	if ( ! $ok ) {
		rzd_panel_fail( $r );
	}
	rzd_panel_out( array( 'post' => $r, 'message' => 'Opublikowano na Instagramie.' ) );
}

/** (2.54.3) „Zestaw do postów” z góry Planu tygodnia – zapis tylko tego ustawienia. */
function rzd_panel_do_posts_week_set() {
	list( $ok, $m ) = rzd_posts_save_settings( array( 'week_set' => (int) rzd_panel_str( 'set' ) ) );
	if ( ! $ok ) {
		rzd_panel_fail( $m );
	}
	rzd_panel_out( array_merge( rzd_panel_posts_payload(), array( 'message' => 'Zestaw do postów zapisany.' ) ) );
}

function rzd_panel_do_posts_unschedule() {
	list( $ok, $p ) = rzd_posts_fb_unschedule( (int) rzd_panel_str( 'post' ) );
	if ( ! $ok ) {
		rzd_panel_fail( $p );
	}
	rzd_panel_out( array( 'post' => $p, 'message' => 'Cofnięto planowanie – post wrócił do szkiców.' ) );
}

function rzd_panel_do_posts_delete() {
	$p = rzd_posts_get( (int) rzd_panel_str( 'post' ) );
	if ( ! $p ) {
		rzd_panel_fail( 'Nie znaleziono posta.' );
	}
	list( $ok, $why ) = rzd_posts_can_forget( $p ); // (2.56.1) opublikowany – tylko wpis w historii, post zostaje na FB / IG
	if ( ! $ok ) {
		rzd_panel_fail( $why );
	}
	rzd_posts_forget( $p['id'] );
	rzd_panel_out( array_merge( rzd_panel_posts_payload(), array( 'message' => in_array( $p['status'], array( 'published', 'scheduled' ), true ) ? 'Usunięto z historii – post zostaje na Facebooku' . ( 'published' === $p['ig_status'] ? ' i Instagramie' : '' ) . '.' : 'Usunięto.' ) ) );
}

/** (2.56.1) „📌 Nie usuwaj” – przypięcie / odpięcie wpisu. */
function rzd_panel_do_posts_keep() {
	$p = rzd_posts_get( (int) rzd_panel_str( 'post' ) );
	if ( ! $p ) {
		rzd_panel_fail( 'Nie znaleziono posta.' );
	}
	$on = rzd_panel_str( 'on' ) ? 1 : 0;
	update_post_meta( $p['id'], '_keep', $on );
	rzd_panel_out( array_merge( rzd_panel_posts_payload(), array( 'message' => $on ? 'Przypięte – ten post nie zniknie z historii.' : 'Odpięte.' ) ) );
}

function rzd_panel_do_posts_settings_save() {
	$v = rzd_panel_json( 'values' );
	if ( null === $v ) {
		rzd_panel_fail( 'Brak danych do zapisu.' );
	}
	list( $ok, $m ) = rzd_posts_save_settings( $v );
	if ( ! $ok ) {
		rzd_panel_fail( $m );
	}
	rzd_panel_out( array_merge( rzd_panel_posts_payload(), array( 'message' => $m ) ) );
}

function rzd_panel_do_posts_models() {
	$k = trim( rzd_panel_str( 'key' ) );
	list( $ok, $r ) = rzd_posts_gemini_models( '' !== $k ? $k : null );
	if ( ! $ok ) {
		rzd_panel_fail( $r );
	}
	rzd_panel_out( array( 'models' => $r ) );
}

function rzd_panel_do_posts_fb_check() {
	list( $ok, $r, $note ) = rzd_posts_fb_check();
	if ( ! $ok ) {
		rzd_panel_fail( $r );
	}
	rzd_panel_out( array( 'name' => $r, 'message' => '' !== $note ? $note : 'Połączono ze stroną: ' . $r ) );
}

function rzd_panel_do_posts_ai_test() {
	list( $ok, $m ) = rzd_posts_gemini_test();
	if ( ! $ok ) {
		rzd_panel_fail( $m );
	}
	rzd_panel_out( array( 'message' => $m, 'lastCall' => rzd_panel_posts_last_call() ) );
}

function rzd_panel_do_posts_media_list() {
	rzd_panel_do_media_list();
}

function rzd_panel_do_posts_media_upload() {
	rzd_panel_do_media_upload();
}
