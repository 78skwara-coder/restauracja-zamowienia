<?php
/**
 * Moduł 34-panel – sekcja „Post dnia” (2.48.0, moduł 38-posty). Zakładki (rzd-panel-posty.js): Nowy post,
 * Plan tygodnia, Historia, Ustawienia. Akcje: posts (dane sekcji), posts_day (dania i zdjęcia zestawu na dzień),
 * posts_generate, posts_save, posts_publish, posts_unschedule, posts_delete, posts_settings_save, posts_models,
 * posts_fb_check, posts_media_list / posts_media_upload (wybór zdjęć – te same funkcje co w Sklepie).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter( 'rzd_panel_actions', function ( $a ) {
	foreach ( array( 'posts', 'posts_day', 'posts_generate', 'posts_save', 'posts_publish', 'posts_unschedule', 'posts_delete', 'posts_settings_save', 'posts_models', 'posts_fb_check', 'posts_ai_test', 'posts_media_list', 'posts_media_upload' ) as $k ) {
		$a[ $k ] = 'posty';
	}
	return $a;
} );

function rzd_panel_posts_payload() {
	$s       = rzd_posts_settings();
	$history = array();
	foreach ( get_posts( array( 'post_type' => 'rzd_fbpost', 'post_status' => 'publish', 'numberposts' => 40, 'fields' => 'ids', 'orderby' => 'date', 'order' => 'DESC' ) ) as $id ) {
		$p = rzd_posts_get( $id );
		if ( $p ) {
			$p['fbUrl']    = rzd_posts_fb_url( $p['fb'] );
			$p['dayLabel'] = $p['day'] ? ucfirst( rzd_dc_date_label( $p['day'] ) ) : '';
			$history[]     = $p;
		}
	}
	$days = array();
	$d    = new DateTime( current_time( 'Y-m-d' ), wp_timezone() );
	for ( $i = 0; $i <= 14; $i++ ) {
		$days[] = array( 'day' => $d->format( 'Y-m-d' ), 'label' => ucfirst( rzd_dc_date_label( $d->format( 'Y-m-d' ) ) ) );
		$d->modify( '+1 day' );
	}
	$vals = array(
		'gemini_key'   => '',
		'model'        => $s['model'],
		'ai_images'    => (int) $s['ai_images'],
		'instructions' => $s['instructions'],
		'fb_page'      => $s['fb_page'],
		'fb_token'     => '',
		'gen_time'     => $s['gen_time'],
		'pub_time'     => $s['pub_time'],
		'auto'         => (int) $s['auto'],
		'mail_to'      => $s['mail_to'],
		'sections'     => $s['sections'],
	);
	$hasKey   = '' !== rzd_posts_secret( 'gemini_key' );
	$hasToken = '' !== rzd_posts_secret( 'fb_token' );
	return array(
		'ready'    => $hasKey && '' !== $s['model'] && $hasToken && '' !== $s['fb_page'],
		'hasKey'   => $hasKey,
		'hasToken' => $hasToken,
		'keyConst' => defined( 'RZD_GEMINI_KEY' ),
		'tokConst' => defined( 'RZD_FB_TOKEN' ),
		'sets'     => rzd_posts_sets(),
		'days'     => $days,
		'week'     => rzd_posts_week( 7 ),
		'history'  => $history,
		'values'   => $vals,
		'statuses' => rzd_posts_status_labels(),
		'pubTime'  => $s['pub_time'],
		'genTime'  => $s['gen_time'],
		'now'      => time(),
		'tz'       => wp_timezone_string(),
		'lastCall' => rzd_panel_posts_last_call(),
	);
}

/** „Ostatnie zapytanie do Gemini” – diagnostyka w Ustawieniach. */
function rzd_panel_posts_last_call() {
	$c = get_option( 'rzd_posts_last_call' );
	if ( ! is_array( $c ) || empty( $c['time'] ) ) {
		return '';
	}
	return wp_date( 'j.m H:i', (int) $c['time'] ) . ' · ' . ( 'test' === $c['what'] ? 'test' : 'post' ) . ' · ' . $c['model'] . ' · ' . str_replace( '.', ',', (string) $c['secs'] ) . ' s · ' . ( $c['ok'] ? 'OK' : 'błąd: ' . $c['msg'] );
}

function rzd_panel_posts_day_ok( $day ) {
	if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $day ) ) {
		rzd_panel_fail( 'Nieprawidłowy dzień.' );
	}
	return $day;
}

/** Zdjęcia z panelu: tylko obrazki z biblioteki (id) – adres liczony na serwerze. */
function rzd_panel_posts_photos( $in ) {
	$out = array();
	foreach ( is_array( $in ) ? $in : array() as $ph ) {
		$id = is_array( $ph ) && isset( $ph['id'] ) ? (int) $ph['id'] : (int) $ph;
		$p  = $id && wp_attachment_is_image( $id ) ? rzd_posts_photo( $id ) : null;
		if ( $p ) {
			$out[] = $p;
		}
	}
	return array_slice( $out, 0, 10 );
}

function rzd_panel_do_posts() {
	rzd_panel_out( rzd_panel_posts_payload() );
}

function rzd_panel_do_posts_day() {
	$day = rzd_panel_posts_day_ok( rzd_panel_str( 'day' ) );
	$dd  = rzd_posts_day_data( (int) rzd_panel_str( 'set' ), $day );
	$dd['posts'] = rzd_posts_for_day( $day, true );
	$dd['when']  = rzd_posts_default_when( $day );
	rzd_panel_out( $dd );
}

function rzd_panel_do_posts_generate() {
	$day = rzd_panel_posts_day_ok( rzd_panel_str( 'day' ) );
	$pid = (int) rzd_panel_str( 'post' );
	if ( $pid ) {
		$old = rzd_posts_get( $pid );
		if ( ! $old || in_array( $old['status'], array( 'scheduled', 'published' ), true ) ) {
			rzd_panel_fail( 'Tego posta nie można już zmienić – jest na Facebooku.' );
		}
	}
	$ph = rzd_panel_json( 'photos' );
	try {
		list( $ok, $p ) = rzd_posts_generate( (int) rzd_panel_str( 'set' ), $day, mb_substr( rzd_panel_str( 'extra' ), 0, 500 ), null === $ph ? null : rzd_panel_posts_photos( $ph ), $pid, rzd_panel_str( 'src' ) === 'week' ? 'week' : 'manual' );
	} catch ( Throwable $e ) {
		rzd_panel_fail( 'Błąd przy przygotowaniu posta: ' . $e->getMessage() );
	}
	if ( ! $ok ) {
		rzd_panel_fail( $p );
	}
	rzd_panel_out( array( 'post' => $p, 'message' => 'Gotowe – sprawdź tekst i zatwierdź.' ) );
}

function rzd_panel_do_posts_save() {
	$p = rzd_posts_get( (int) rzd_panel_str( 'post' ) );
	if ( ! $p ) {
		rzd_panel_fail( 'Nie znaleziono posta.' );
	}
	if ( in_array( $p['status'], array( 'scheduled', 'published' ), true ) ) {
		rzd_panel_fail( 'Ten post jest już na Facebooku – najpierw cofnij planowanie.' );
	}
	$text = isset( $_POST['text'] ) ? sanitize_textarea_field( wp_unslash( (string) $_POST['text'] ) ) : $p['text']; // phpcs:ignore
	$ph   = rzd_panel_json( 'photos' );
	rzd_posts_save_post( array( 'id' => $p['id'], 'day' => $p['day'], 'text' => mb_substr( $text, 0, 5000 ), 'photos' => null === $ph ? $p['photos'] : rzd_panel_posts_photos( $ph ) ) );
	rzd_panel_out( array( 'post' => rzd_posts_get( $p['id'] ), 'message' => 'Zapisano szkic.' ) );
}

function rzd_panel_do_posts_publish() {
	$id = (int) rzd_panel_str( 'post' );
	if ( isset( $_POST['text'] ) ) { // phpcs:ignore -- najpierw zapis bieżących poprawek
		$p = rzd_posts_get( $id );
		if ( $p && 'draft' === $p['status'] ) {
			$ph = rzd_panel_json( 'photos' );
			rzd_posts_save_post( array( 'id' => $id, 'day' => $p['day'], 'text' => mb_substr( sanitize_textarea_field( wp_unslash( (string) $_POST['text'] ) ), 0, 5000 ), 'photos' => null === $ph ? $p['photos'] : rzd_panel_posts_photos( $ph ) ) ); // phpcs:ignore
		}
	}
	$when = 'now' === rzd_panel_str( 'mode' ) ? 0 : (int) rzd_panel_str( 'when' );
	list( $ok, $p ) = rzd_posts_fb_publish( $id, $when );
	if ( ! $ok ) {
		rzd_panel_fail( $p );
	}
	rzd_panel_out( array( 'post' => $p, 'message' => $when ? 'Zaplanowane – Facebook opublikuje post ' . wp_date( 'j.m H:i', $when ) . '.' : 'Opublikowano na Facebooku.' ) );
}

function rzd_panel_do_posts_unschedule() {
	list( $ok, $p ) = rzd_posts_fb_unschedule( (int) rzd_panel_str( 'post' ) );
	if ( ! $ok ) {
		rzd_panel_fail( $p );
	}
	rzd_panel_out( array( 'post' => $p, 'message' => 'Cofnięto planowanie – post wrócił do szkiców.' ) );
}

function rzd_panel_do_posts_delete() {
	$p = rzd_posts_get( (int) rzd_panel_str( 'post' ) );
	if ( ! $p ) {
		rzd_panel_fail( 'Nie znaleziono posta.' );
	}
	if ( in_array( $p['status'], array( 'scheduled', 'published' ), true ) ) {
		rzd_panel_fail( 'Post jest na Facebooku – usuń go tam (zaplanowany: najpierw „Cofnij planowanie”).' );
	}
	wp_delete_post( $p['id'], true );
	rzd_panel_out( array_merge( rzd_panel_posts_payload(), array( 'message' => 'Usunięto szkic.' ) ) );
}

function rzd_panel_do_posts_settings_save() {
	$v = rzd_panel_json( 'values' );
	if ( null === $v ) {
		rzd_panel_fail( 'Brak danych do zapisu.' );
	}
	list( $ok, $m ) = rzd_posts_save_settings( $v );
	if ( ! $ok ) {
		rzd_panel_fail( $m );
	}
	rzd_panel_out( array_merge( rzd_panel_posts_payload(), array( 'message' => $m ) ) );
}

function rzd_panel_do_posts_models() {
	$k = trim( rzd_panel_str( 'key' ) );
	list( $ok, $r ) = rzd_posts_gemini_models( '' !== $k ? $k : null );
	if ( ! $ok ) {
		rzd_panel_fail( $r );
	}
	rzd_panel_out( array( 'models' => $r ) );
}

function rzd_panel_do_posts_fb_check() {
	list( $ok, $r ) = rzd_posts_fb_check();
	if ( ! $ok ) {
		rzd_panel_fail( $r );
	}
	rzd_panel_out( array( 'name' => $r, 'message' => 'Połączono ze stroną: ' . $r ) );
}

function rzd_panel_do_posts_ai_test() {
	list( $ok, $m ) = rzd_posts_gemini_test();
	if ( ! $ok ) {
		rzd_panel_fail( $m );
	}
	rzd_panel_out( array( 'message' => $m, 'lastCall' => rzd_panel_posts_last_call() ) );
}

function rzd_panel_do_posts_media_list() {
	rzd_panel_do_media_list();
}

function rzd_panel_do_posts_media_upload() {
	rzd_panel_do_media_upload();
}
