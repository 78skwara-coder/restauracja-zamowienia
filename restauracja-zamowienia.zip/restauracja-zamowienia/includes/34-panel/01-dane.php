<?php
/**
 * MODUŁ 34: PANEL RESTAURACJI (2.44.0) – wszystkie ustawienia wtyczki w przeglądarce,
 * bez kokpitu WordPressa (decyzja użytkownika 2026-10-27: jedyne miejsce ustawień;
 * w kokpicie zostaje tylko wejście „Restauracja → Panel restauracji” i „Stan i poczta”).
 *
 * Strona z [rzd_panel] (tworzy się sama z kokpitu), pełny ekran BEZ motywu (własny dokument
 * HTML – aktualizacja motywu go nie zepsuje), poza cache, tylko po zalogowaniu. Sekcje wg
 * uprawnień z konfiguratora (moduł 25): Miejscowości, Terminy, Sala – „Ustawienia wtyczki”;
 * Wiadomości – „Formularze kontaktowe”; Raporty – „Raporty”. Zapis przez admin-ajax
 * (akcja rzd_panel, nonce rzd_panel) do TYCH SAMYCH opcji co dawne strony kokpitu.
 *
 * Etapy: 1 (2.44.0) Start, Miejscowości, Terminy (dni bez dostaw, limit), Sala, Wiadomości, Raporty.
 *        2 (2.45.0) Menu (dodatki, typy, opakowania, etykiety, wzory + edytor grup), cały Terminy
 *          (grupy, godziny w dniach tygodnia, okna dostaw), Zestawy (harmonogram);
 *        3 (2.45.0) Sklep (koszyk, pasek dostawy, dobierz, formularz zamówienia), Wygląd (wygląd listy
 *          z podglądem na żywo), Menu strony, Formularze (kreator formularzy kontaktowych);
 *        4 (2.45.0) Zespół (uprawnienia ról, konta pracowników, awaryjny PIN kuriera).
 * W kokpicie zostaje tylko „Restauracja → Panel restauracji”, Kuchnia, Kurier i „Stan i poczta” (Administrator).
 *
 * Logo w lewym górnym rogu (panel i ekrany obsługi) prowadzi do sklepu – adres do wyboru
 * w panelu (Start → „Logo prowadzi do”): sklep / strona główna / własny adres.
 *
 * Części: 01-dane (sekcje, dostęp, adresy, logo), 02-strona (dokument, shortcode, logowanie),
 * 03-api (admin-ajax: dyspozytor + Start, Miejscowości, Terminy – dni wolne, Sala, Wiadomości,
 * Raporty), 04-kokpit (wejście z kokpitu, przekierowania dawnych stron), 05-menu, 06-terminy,
 * 07-zestawy, 08-sklep, 09-wyglad, 10-strona, 11-formularze, 12-zespol (akcje 2.45.0 – rejestrowane
 * filtrem rzd_panel_actions), 13-seo (2.46.0; dane i działanie – moduł 35-seo).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Sekcje panelu: klucz => [ nazwa, uprawnienie z konfiguratora (null = każdy z dostępem do panelu) ]. */
function rzd_panel_sections() {
	return array(
		'start'        => array( 'Start', null ),
		'miejscowosci' => array( 'Miejscowości', 'settings' ),
		'terminy'      => array( 'Terminy', 'settings' ),
		'menu'         => array( 'Menu', 'settings' ),    // 2.45.0: dodatki, typy, opakowania, etykiety, wzory
		'zestawy'      => array( 'Zestawy', 'settings' ), // 2.45.0: harmonogram zestawów
		'sala'         => array( 'Sala', 'settings' ),
		'sklep'        => array( 'Sklep', 'settings' ),        // 2.45.0: koszyk, pasek dostawy, dobierz, formularz zamówienia
		'wyglad'       => array( 'Wygląd', 'settings' ),       // 2.45.0: wygląd listy (podgląd na żywo)
		'strona'       => array( 'Menu strony', 'settings' ),  // 2.45.0: nawigacja strony
		'seo'          => array( 'SEO', 'settings' ),          // 2.46.0: wizytówka, udostępnianie, indeksowanie, do poprawy
		'formularze'   => array( 'Formularze', 'forms' ),      // 2.45.0: formularze kontaktowe (kreator)
		'wiadomosci'   => array( 'Wiadomości', 'forms' ),
		'raporty'      => array( 'Raporty', 'reports' ),
		'zespol'       => array( 'Zespół', 'staff' ),          // 2.45.0: uprawnienia, konta pracowników, PIN kuriera
	);
}

function rzd_panel_section_can( $key, $user = null ) {
	$s = rzd_panel_sections();
	if ( ! isset( $s[ $key ] ) || ! rzd_panel_can( $user ) ) {
		return false;
	}
	return null === $s[ $key ][1] || rzd_can( $s[ $key ][1], $user );
}

/** Dostęp do panelu = choć jedna sekcja z ustawieniami. */
function rzd_panel_can( $user = null ) {
	if ( ! function_exists( 'rzd_can' ) ) {
		return false;
	}
	return rzd_can( 'settings', $user ) || rzd_can( 'forms', $user ) || rzd_can( 'reports', $user ) || rzd_can( 'staff', $user );
}

function rzd_panel_page_url() {
	return function_exists( 'rzd_page_url_opt' ) ? rzd_page_url_opt( 'rzd_panel_page_id', 'rzd_panel' ) : '';
}

/** Strona panelu – tworzy, gdy jej nie ma (wejście z kokpitu). Zwraca adres. */
function rzd_panel_ensure_page() {
	$url = rzd_panel_page_url();
	if ( $url ) {
		return $url;
	}
	$id = wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_title' => 'Panel restauracji', 'post_name' => 'panel-restauracji', 'post_content' => '[rzd_panel]' ) );
	if ( $id && ! is_wp_error( $id ) ) {
		update_option( 'rzd_panel_page_id', (int) $id, false );
		return get_permalink( $id );
	}
	return '';
}

/**
 * Adres sekcji panelu, np. rzd_panel_url( 'wiadomosci', array( 'form' => 'kontakt' ) ).
 * Gdy strony jeszcze nie ma – wejście z kokpitu (utworzy ją i przekieruje).
 */
function rzd_panel_url( $section = '', $args = array() ) {
	$url = rzd_panel_page_url();
	if ( '' === $url ) {
		$url  = admin_url( 'admin.php?page=rzd-panel' );
	}
	if ( '' !== $section && 'start' !== $section ) {
		$args = array_merge( array( 'sekcja' => $section ), (array) $args );
	}
	return $args ? add_query_arg( array_map( 'rawurlencode', $args ), $url ) : $url;
}

/* ============================================================
 * LOGO W LEWYM GÓRNYM ROGU – dokąd prowadzi (wszystkie ekrany obsługi)
 * ============================================================ */
function rzd_brand_cfg() {
	$c = get_option( 'rzd_brand', array() );
	$c = is_array( $c ) ? $c : array();
	return wp_parse_args( $c, array( 'link' => 'shop', 'url' => '' ) );
}

function rzd_brand_link_options() {
	return array( 'shop' => 'Sklep', 'home' => 'Strona główna', 'custom' => 'Inny adres' );
}

/** Adres sklepu: strona sklepu WooCommerce, a gdy jej nie ma – strona z [lista_zamowien], na końcu główna. */
function rzd_shop_url() {
	$id = function_exists( 'wc_get_page_id' ) ? (int) wc_get_page_id( 'shop' ) : 0;
	if ( $id > 0 && 'publish' === get_post_status( $id ) ) {
		return get_permalink( $id );
	}
	$list = function_exists( 'rzd_page_url_opt' ) ? rzd_page_url_opt( 'rzd_lista_page_id', 'lista_zamowien' ) : '';
	return '' !== $list ? $list : home_url( '/' );
}

/** [ url, logo (adres obrazka albo ''), name ] – logo z motywu (Wygląd → Dostosuj), inaczej ikona strony. */
function rzd_brand() {
	$c   = rzd_brand_cfg();
	$url = home_url( '/' );
	if ( 'shop' === $c['link'] ) {
		$url = rzd_shop_url();
	} elseif ( 'custom' === $c['link'] && '' !== $c['url'] ) {
		$url = $c['url'];
	}
	$logo = '';
	$lid  = (int) get_theme_mod( 'custom_logo' );
	if ( $lid ) {
		$logo = (string) wp_get_attachment_image_url( $lid, 'medium' );
	}
	if ( '' === $logo && function_exists( 'get_site_icon_url' ) ) {
		$logo = (string) get_site_icon_url( 96 );
	}
	return array(
		'url'   => $url,
		'logo'  => $logo,
		'name'  => html_entity_decode( get_bloginfo( 'name' ), ENT_QUOTES, 'UTF-8' ),
		'label' => isset( rzd_brand_link_options()[ $c['link'] ] ) ? rzd_brand_link_options()[ $c['link'] ] : 'Sklep',
	);
}

/** Zapis: $link shop|home|custom, $url – tylko dla „Inny adres” (adres tej strony albo pełny http/https). */
function rzd_brand_save( $link, $url ) {
	$link = isset( rzd_brand_link_options()[ $link ] ) ? $link : 'shop';
	$url  = 'custom' === $link ? esc_url_raw( trim( (string) $url ), array( 'http', 'https' ) ) : '';
	if ( 'custom' === $link && '' === $url ) {
		return new WP_Error( 'url', 'Podaj adres zaczynający się od https://' );
	}
	update_option( 'rzd_brand', array( 'link' => $link, 'url' => $url ), false );
	return rzd_brand_cfg();
}

/** Logo jako HTML (ekrany obsługi renderowane w PHP – Kuchnia, Kurier). */
function rzd_brand_html( $class = 'rzd-brand' ) {
	$b   = rzd_brand();
	$img = '' !== $b['logo'] ? '<img src="' . esc_url( $b['logo'] ) . '" alt="">' : '<span class="rzd-brand-txt">' . esc_html( $b['name'] ) . '</span>';
	return '<a class="' . esc_attr( $class ) . '" href="' . esc_url( $b['url'] ) . '" title="' . esc_attr( $b['label'] . ' – ' . $b['name'] ) . '" aria-label="' . esc_attr( $b['label'] ) . '">' . $img . '</a>';
}
