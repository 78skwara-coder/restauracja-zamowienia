<?php
/**
 * Moduł 34-panel – admin-ajax „rzd_panel”: { do: <akcja>, _n: nonce, …dane }.
 * Każda akcja sprawdza nonce i uprawnienie sekcji (ukryty przycisk to nie zabezpieczenie).
 * Zapis – przez funkcje modułów (rzd_towns_save, rzd_dc_save_general, rzd_sala_save…),
 * te same, z których korzystały dawne strony kokpitu.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function rzd_panel_out( $data = array(), $code = 200 ) {
	wp_send_json( array_merge( array( 'ok' => $code < 400 ), (array) $data ), $code );
}

function rzd_panel_fail( $message, $code = 400 ) {
	rzd_panel_out( array( 'message' => $message ), $code );
}

/** Pole JSON z żądania (tablice/obiekty z panelu wysyłane jako JSON). */
function rzd_panel_json( $key ) {
	if ( ! isset( $_POST[ $key ] ) ) { // phpcs:ignore -- nonce sprawdzony wcześniej
		return null;
	}
	$v = json_decode( wp_unslash( (string) $_POST[ $key ] ), true ); // phpcs:ignore
	return is_array( $v ) ? $v : null;
}

function rzd_panel_str( $key, $def = '' ) {
	return isset( $_POST[ $key ] ) ? sanitize_text_field( wp_unslash( (string) $_POST[ $key ] ) ) : $def; // phpcs:ignore
}

add_action( 'wp_ajax_rzd_panel', function () {
	if ( ! check_ajax_referer( 'rzd_panel', '_n', false ) ) {
		rzd_panel_fail( 'Sesja panelu wygasła – odśwież stronę.', 403 );
	}
	if ( ! rzd_panel_can() ) {
		rzd_panel_fail( 'To konto nie ma dostępu do Panelu restauracji.', 403 );
	}
	$do    = rzd_panel_str( 'do' );
	$need  = array(
		'boot' => 'start', 'brand_save' => 'start',
		'towns' => 'miejscowosci', 'towns_save' => 'miejscowosci',
		'terms' => 'terminy', 'terms_save' => 'terminy',
		'sala' => 'sala', 'sala_save' => 'sala', 'sala_page' => 'sala',
		'msgs' => 'wiadomosci', 'msg' => 'wiadomosci', 'msgs_set' => 'wiadomosci', 'msgs_delete' => 'wiadomosci',
		'report' => 'raporty',
	);
	// akcja => sekcja (uprawnienie sekcji); kolejne pliki modułu dokładają swoje akcje
	$need = apply_filters( 'rzd_panel_actions', $need );
	if ( ! isset( $need[ $do ] ) || ! function_exists( 'rzd_panel_do_' . $do ) ) {
		rzd_panel_fail( 'Nieznana akcja.' );
	}
	if ( ! rzd_panel_section_can( $need[ $do ] ) ) {
		rzd_panel_fail( 'Brak uprawnienia do tej części panelu.', 403 );
	}
	if ( 'brand_save' === $do && ! rzd_can( 'settings' ) ) {
		rzd_panel_fail( 'Brak uprawnienia: Ustawienia wtyczki.', 403 );
	}
	$fn = 'rzd_panel_do_' . $do;
	$fn();
} );

/* ============================================================
 * START
 * ============================================================ */
function rzd_panel_do_boot() {
	$user     = wp_get_current_user();
	$sections = array();
	foreach ( rzd_panel_sections() as $k => $s ) {
		if ( rzd_panel_section_can( $k ) ) {
			$sections[] = array( 'key' => $k, 'name' => $s[0] );
		}
	}
	// kafle ekranów, do których konto ma dostęp
	$tiles = array();
	$kurl  = function_exists( 'rzd_kitchen_page_url' ) ? rzd_kitchen_page_url() : '';
	if ( $kurl && rzd_kitchen_can() ) {
		$tiles[] = array( 'key' => 'kuchnia', 'name' => 'Kuchnia', 'desc' => 'Zamówienia, pakowanie, planowanie', 'url' => $kurl );
	}
	if ( rzd_can( 'menu' ) && function_exists( 'rzd_ed_page_url' ) && rzd_page_url_opt( 'rzd_ed_page_id', 'edycja_produktow' ) ) {
		$tiles[] = array( 'key' => 'menu', 'name' => 'Edycja menu', 'desc' => 'Dania, ceny, zdjęcia, zestawy', 'url' => rzd_ed_page_url() );
	}
	$surl = function_exists( 'rzd_sala_page_url' ) ? rzd_sala_page_url() : '';
	if ( $surl && rzd_can( 'sala' ) ) {
		$tiles[] = array( 'key' => 'sala', 'name' => 'Sala', 'desc' => 'Panel kelnera: stoliki i rachunki', 'url' => $surl );
	}
	if ( $kurl && rzd_can( 'dashboard' ) ) {
		$tiles[] = array( 'key' => 'dashboard', 'name' => 'Dashboard', 'desc' => 'Sprzedaż dziś i w czasie', 'url' => add_query_arg( 'view', 'dashboard', $kurl ) );
	}
	$curl = function_exists( 'rzd_page_url_opt' ) ? rzd_page_url_opt( 'rzd_kurier_page_id', 'kurier_dashboard' ) : '';
	if ( $curl && rzd_can( 'courier' ) ) {
		$tiles[] = array( 'key' => 'kurier', 'name' => 'Kurier', 'desc' => 'Ekran kierowcy', 'url' => $curl );
	}
	if ( rzd_can( 'shop' ) ) {
		$tiles[] = array( 'key' => 'wp', 'name' => 'Kokpit WordPressa', 'desc' => 'WooCommerce: zamówienia, płatności, produkty', 'url' => admin_url() );
	}
	rzd_panel_out( array(
		'user'     => $user->display_name,
		'sections' => $sections,
		'tiles'    => $tiles,
		'brand'    => rzd_brand(),
		'brandCfg' => rzd_brand_cfg(),
		'brandOpts' => rzd_brand_link_options(),
		'canBrand' => rzd_can( 'settings' ),
		'warnings' => rzd_panel_warnings(),
		'newMsgs'  => rzd_panel_section_can( 'wiadomosci' ) ? (int) get_option( 'rzd_kf_new' ) : 0,
		'shop'     => rzd_shop_url(),
		'home'     => home_url( '/' ),
		'today'    => current_time( 'Y-m-d' ),
	) );
}

/** Ostrzeżenia zbierane z modułów: [ { level: error|warning, text, section } ]. */
function rzd_panel_warnings() {
	$out = array();
	// 2.45.0: awaryjny PIN kuriera włączony – przypomnienie (dotąd tylko komunikat w kokpicie)
	if ( rzd_can( 'staff' ) && function_exists( 'rzd_roles_cfg' ) ) {
		$pc = rzd_roles_cfg()['pin'];
		if ( ! empty( $pc['on'] ) ) {
			$days  = $pc['since'] ? max( 0, (int) floor( ( current_time( 'timestamp' ) - strtotime( $pc['since'] ) ) / DAY_IN_SECONDS ) ) : 0;
			$out[] = array( 'level' => 'warning', 'text' => 'Awaryjny PIN kuriera jest włączony' . ( $days ? ' od ' . $days . ' dni' : '' ) . ' – wyłącz go, gdy zastępstwo się skończy.', 'section' => 'zespol' );
		}
	}
	if ( ! rzd_can( 'settings' ) ) {
		return $out;
	}
	// 2.46.0: SEO
	if ( ! get_option( 'blog_public' ) ) {
		$out[] = array( 'level' => 'error', 'text' => 'Strona jest ukryta przed wyszukiwarkami (WordPress: „Proś wyszukiwarki o nieindeksowanie”) – Google nie pokaże sklepu.', 'section' => 'seo' );
	}
	if ( function_exists( 'rzd_seo_snippet_stale' ) && rzd_seo_snippet_stale() ) {
		$out[] = array( 'level' => 'warning', 'text' => 'Kod wizytówki na stronie głównej restauracji jest nieaktualny – skopiuj go ponownie (SEO → Wizytówka).', 'section' => 'seo' );
	} elseif ( function_exists( 'rzd_seo_card_ready' ) && ! rzd_seo_card_ready() ) {
		$out[] = array( 'level' => 'warning', 'text' => 'Uzupełnij wizytówkę restauracji w SEO – Google nie zna adresu ani obszaru dostaw.', 'section' => 'seo' );
	}
	$dc = function_exists( 'rzd_dc_get_settings' ) ? rzd_dc_get_settings() : array();
	if ( isset( $dc['enabled'] ) && empty( $dc['enabled'] ) ) {
		$out[] = array( 'level' => 'warning', 'text' => 'Wybór terminu dostawy jest wyłączony – klienci nie wybierają terminu.', 'section' => 'terminy' );
	}
	if ( ! empty( $dc['enabled'] ) && function_exists( 'rzd_dc_products_without_group' ) ) {
		$ng = array_values( array_filter( rzd_dc_products_without_group(), function ( $pid ) {
			return ! ( function_exists( 'rzd_product_sell' ) && 'onsite' === rzd_product_sell( $pid ) );
		} ) );
		if ( $ng ) {
			$out[] = array( 'level' => 'warning', 'text' => 'Produkty bez kalendarza dostaw (' . count( $ng ) . ') nie mogą być zamówione: ' . implode( ', ', array_map( 'get_the_title', array_slice( $ng, 0, 8 ) ) ) . ( count( $ng ) > 8 ? ' …' : '' ) . '.', 'section' => 'terminy' );
		}
		if ( function_exists( 'rzd_dc_windows_on' ) && ! rzd_dc_windows_on() ) {
			foreach ( (array) $dc['groups'] as $tid => $g ) {
				if ( empty( $g['times'] ) ) {
					$t = get_term( (int) $tid, 'product_cat' );
					if ( $t && ! is_wp_error( $t ) ) {
						$out[] = array( 'level' => 'error', 'text' => 'Grupa „' . $t->name . '” nie ma godzin wyjazdu – jej produktów nie da się zamówić.', 'section' => 'terminy' );
					}
				}
			}
		}
	}
	if ( function_exists( 'rzd_towns' ) ) {
		if ( ! rzd_towns() ) {
			$out[] = array( 'level' => 'warning', 'text' => 'Lista miejscowości jest pusta – dodaj miejscowości, do których dowozisz.', 'section' => 'miejscowosci' );
		}
		foreach ( rzd_town_zone_warnings() as $w ) {
			$out[] = array( 'level' => $w[0], 'text' => $w[1], 'section' => 'miejscowosci' );
		}
		foreach ( array_merge( rzd_town_threshold_warnings(), rzd_town_points_warnings() ) as $w ) {
			$out[] = array( 'level' => 'warning', 'text' => $w, 'section' => 'miejscowosci' );
		}
	}
	return $out;
}

function rzd_panel_do_brand_save() {
	$r = rzd_brand_save( rzd_panel_str( 'link' ), isset( $_POST['url'] ) ? wp_unslash( (string) $_POST['url'] ) : '' ); // phpcs:ignore
	if ( is_wp_error( $r ) ) {
		rzd_panel_fail( $r->get_error_message() );
	}
	rzd_panel_out( array( 'brand' => rzd_brand(), 'brandCfg' => $r ) );
}

/* ============================================================
 * MIEJSCOWOŚCI
 * ============================================================ */
function rzd_panel_towns_payload() {
	$rows = rzd_towns();
	usort( $rows, function ( $a, $b ) { return strcoll( $a['name'], $b['name'] ); } );
	$warn = array();
	foreach ( rzd_town_zone_warnings() as $w ) {
		$warn[] = array( 'level' => $w[0], 'text' => $w[1] );
	}
	foreach ( array_merge( rzd_town_threshold_warnings(), rzd_town_points_warnings() ) as $w ) {
		$warn[] = array( 'level' => 'warning', 'text' => $w );
	}
	return array(
		'rows'     => array_values( $rows ),
		'days'     => function_exists( 'rzd_dc_days' ) ? rzd_dc_days() : array(),
		'warnings' => $warn,
		'method'   => rzd_town_method_active(),
		'windows'  => function_exists( 'rzd_dc_windows_on' ) && rzd_dc_windows_on(),
		'preview'  => do_shortcode( '[koszty_dostawy]' ),
		'wcShip'   => current_user_can( 'manage_woocommerce' ) ? admin_url( 'admin.php?page=wc-settings&tab=shipping' ) : '',
	);
}

function rzd_panel_do_towns() {
	rzd_panel_out( rzd_panel_towns_payload() );
}

function rzd_panel_do_towns_save() {
	$rows = rzd_panel_json( 'rows' );
	if ( null === $rows ) {
		rzd_panel_fail( 'Brak danych do zapisu.' );
	}
	rzd_towns_save( $rows );
	rzd_panel_out( array_merge( rzd_panel_towns_payload(), array( 'message' => 'Zapisano miejscowości.' ) ) );
}

/* ============================================================
 * TERMINY: włączenie, limit na okno, dni bez dostaw (wszystkie grupy i pojedyncze)
 * ============================================================ */
function rzd_panel_terms_payload() {
	$s      = rzd_dc_get_settings();
	$groups = array();
	foreach ( $s['groups'] as $tid => $g ) {
		$t = get_term( (int) $tid, 'product_cat' );
		if ( ! $t || is_wp_error( $t ) ) {
			continue;
		}
		$groups[] = array( 'id' => (int) $tid, 'name' => $t->name, 'blocked' => array_values( (array) $g['blocked'] ) );
	}
	usort( $groups, function ( $a, $b ) { return strcoll( $a['name'], $b['name'] ); } );
	// zamówienia czekające na dostawę – na dzień (ostrzeżenie przy oznaczaniu dnia jako wolny)
	$orders = array();
	if ( function_exists( 'rzd_kuchnia_orders_open' ) ) {
		foreach ( rzd_kuchnia_orders_open() as $o ) {
			$d = (string) $o->get_meta( '_dc_delivery_date' );
			if ( '' !== $d ) {
				$orders[ $d ] = isset( $orders[ $d ] ) ? $orders[ $d ] + 1 : 1;
			}
		}
	}
	$off = array();
	foreach ( (array) $s['off_days'] as $dk ) {
		$off[] = $dk;
	}
	return array_merge( array(
		'enabled'  => ! empty( $s['enabled'] ),
		'max'      => (int) ( isset( $s['max_per_slot'] ) ? $s['max_per_slot'] : 6 ),
		'windows'  => rzd_dc_windows_on(),
		'blocked'  => array_values( (array) $s['global_blocked'] ),
		'groups'   => $groups,
		'orders'   => $orders ? $orders : new stdClass(),
		'offDays'  => $off,
		'today'    => current_time( 'Y-m-d' ),
	), function_exists( 'rzd_panel_terms_full' ) ? rzd_panel_terms_full( $s ) : array() );
}

function rzd_panel_do_terms() {
	rzd_panel_out( rzd_panel_terms_payload() );
}

function rzd_panel_do_terms_save() {
	$blocked = rzd_panel_json( 'blocked' );
	$groups  = rzd_panel_json( 'groups' );
	$max     = isset( $_POST['max'] ) ? absint( $_POST['max'] ) : 6; // phpcs:ignore
	if ( null === $blocked ) {
		rzd_panel_fail( 'Brak danych do zapisu.' );
	}
	rzd_dc_save_general( ! empty( $_POST['enabled'] ) && '0' !== $_POST['enabled'], $blocked, max( 1, $max ) ); // phpcs:ignore
	foreach ( (array) $groups as $tid => $dates ) {
		rzd_dc_save_group_blocked( (int) $tid, (array) $dates );
	}
	rzd_panel_out( array_merge( rzd_panel_terms_payload(), array( 'message' => 'Zapisano terminy.' ) ) );
}

/* ============================================================
 * SALA
 * ============================================================ */
function rzd_panel_sala_payload() {
	$c    = rzd_sala_cfg();
	$open = function_exists( 'rzd_sala_open_tables' ) ? array_keys( rzd_sala_open_tables() ) : array();
	return array(
		'zones'  => array_values( $c['zones'] ),
		'tables' => array_values( array_map( function ( $t ) use ( $open ) {
			$t['busy'] = in_array( $t['id'], $open, true );
			return $t;
		}, $c['tables'] ) ),
		'cats'   => rzd_sala_cats_cfg(),
		'scopes' => rzd_sell_scopes(),
		'page'   => rzd_sala_page_url(),
	);
}

function rzd_panel_do_sala() {
	rzd_panel_out( rzd_panel_sala_payload() );
}

function rzd_panel_do_sala_save() {
	$zones  = rzd_panel_json( 'zones' );
	$tables = rzd_panel_json( 'tables' );
	$cats   = rzd_panel_json( 'cats' );
	if ( null === $zones || null === $tables ) {
		rzd_panel_fail( 'Brak danych do zapisu.' );
	}
	$r   = rzd_sala_save( $zones, $tables, $cats );
	$msg = 'Zapisano salę.' . ( $r['kept'] ? ' Stolików z otwartym rachunkiem nie można usunąć – zostały: ' . implode( ', ', $r['kept'] ) . '.' : '' );
	rzd_panel_out( array_merge( rzd_panel_sala_payload(), array( 'message' => $msg, 'kept' => $r['kept'] ) ) );
}

function rzd_panel_do_sala_page() {
	$url = rzd_sala_make_page();
	if ( '' === $url ) {
		rzd_panel_fail( 'Nie udało się utworzyć strony.' );
	}
	rzd_panel_out( array_merge( rzd_panel_sala_payload(), array( 'message' => 'Utworzono stronę panelu kelnera.' ) ) );
}

/* ============================================================
 * WIADOMOŚCI
 * ============================================================ */
function rzd_panel_do_msgs() {
	rzd_kf_cleanup();
	$req   = array(
		'form'   => rzd_panel_str( 'form' ),
		'status' => rzd_panel_str( 'status' ),
		's'      => rzd_panel_str( 's' ),
	);
	$paged = max( 1, isset( $_POST['page'] ) ? absint( $_POST['page'] ) : 1 ); // phpcs:ignore
	$q     = new WP_Query( rzd_kf_query_args( $req ) + array( 'posts_per_page' => 30, 'paged' => $paged ) );
	$forms = array();
	foreach ( rzd_kf_forms() as $id => $f ) {
		$forms[] = array( 'id' => (string) $id, 'title' => (string) $f['title'] );
	}
	rzd_panel_out( array(
		'items'    => array_map( 'rzd_kf_msg_data', $q->posts ),
		'pages'    => (int) $q->max_num_pages,
		'page'     => $paged,
		'total'    => (int) $q->found_posts,
		'forms'    => $forms,
		'statuses' => rzd_kf_statuses(),
		'newMsgs'  => (int) get_option( 'rzd_kf_new' ),
		'keep'     => (int) rzd_kf_settings()['keep'],
	) );
}

function rzd_panel_do_msg() {
	$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0; // phpcs:ignore
	if ( ! $id || 'rzd_kf_msg' !== get_post_type( $id ) ) {
		rzd_panel_fail( 'Nie ma takiej wiadomości.', 404 );
	}
	if ( 'new' === get_post_meta( $id, '_rzd_kf_status', true ) ) {
		rzd_kf_set_status( array( $id ), 'read' );
	}
	rzd_panel_out( array( 'item' => rzd_kf_msg_data( get_post( $id ), true ), 'newMsgs' => (int) get_option( 'rzd_kf_new' ) ) );
}

function rzd_panel_msg_ids() {
	$ids = rzd_panel_json( 'ids' );
	return array_values( array_filter( array_map( 'absint', (array) $ids ), function ( $id ) {
		return $id && 'rzd_kf_msg' === get_post_type( $id );
	} ) );
}

function rzd_panel_do_msgs_set() {
	$status = rzd_panel_str( 'status' );
	if ( ! isset( rzd_kf_statuses()[ $status ] ) ) {
		rzd_panel_fail( 'Nieznany status.' );
	}
	$ids = rzd_panel_msg_ids();
	rzd_kf_set_status( $ids, $status );
	rzd_panel_out( array( 'done' => count( $ids ), 'newMsgs' => (int) get_option( 'rzd_kf_new' ) ) );
}

function rzd_panel_do_msgs_delete() {
	$ids = rzd_panel_msg_ids();
	foreach ( $ids as $id ) {
		wp_delete_post( $id, true );
	}
	rzd_kf_recount();
	rzd_panel_out( array( 'done' => count( $ids ), 'newMsgs' => (int) get_option( 'rzd_kf_new' ) ) );
}

/* ============================================================
 * RAPORTY (podgląd; plik CSV – formularz do admin-post rr_export)
 * ============================================================ */
function rzd_panel_do_report() {
	$d = rzd_raport_data( array(
		'date_from'      => rzd_panel_str( 'date_from' ),
		'date_to'        => rzd_panel_str( 'date_to' ),
		'time_from'      => rzd_panel_str( 'time_from' ),
		'time_to'        => rzd_panel_str( 'time_to' ),
		'only_confirmed' => '1' === rzd_panel_str( 'only_confirmed', '1' ),
		'mode'           => rzd_panel_str( 'mode' ),
	) );
	if ( is_wp_error( $d ) ) {
		rzd_panel_fail( $d->get_error_message() );
	}
	rzd_panel_out( array( 'head' => $d['vhead'], 'rows' => $d['preview'], 'file' => $d['file'] ) );
}
