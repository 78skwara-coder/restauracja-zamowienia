<?php
/**
 * Moduł 34-panel – Terminy → Odbiór osobisty (2.47.0): ustawienia modułu 36 jako formularz ze schematu
 * (rzd-panel-formy.js), zapis rzd_pickup_save(). Akcje: pickup, pickup_save (sekcja Terminy).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter( 'rzd_panel_actions', function ( $a ) {
	$a['pickup']      = 'terminy';
	$a['pickup_save'] = 'terminy';
	return $a;
} );

function rzd_panel_pickup_payload() {
	$s   = rzd_pickup_settings();
	$cod = false;
	if ( function_exists( 'WC' ) && WC()->payment_gateways() ) {
		$all = WC()->payment_gateways()->payment_gateways();
		$cod = isset( $all['cod'] ) && 'yes' === $all['cod']->enabled;
	}
	$dc     = rzd_dc_get_settings();
	$status = array(
		array( 'label' => 'Wybór terminu', 'ok' => ! empty( $dc['enabled'] ), 'text' => ! empty( $dc['enabled'] ) ? 'włączony – odbiór pojawi się w okienku terminu' : 'wyłączony – odbiór działa razem z wyborem terminu', 'fixText' => 'Włącz w zakładce „Dni wolne i limit”' ),
		array( 'label' => 'Płatność przy odbiorze', 'ok' => $cod || 'online' === $s['pay'], 'text' => $cod ? 'metoda „Za pobraniem” włączona w WooCommerce' : ( 'online' === $s['pay'] ? 'nie dotyczy – tylko płatność online' : 'metoda „Za pobraniem” jest wyłączona w WooCommerce – klienci zapłacą tylko online' ), 'fix' => admin_url( 'admin.php?page=wc-settings&tab=checkout&section=cod' ), 'fixText' => 'Włącz w WooCommerce' ),
	);
	$hint = array();
	if ( function_exists( 'rzd_seo_settings' ) ) {
		$seo = rzd_seo_settings();
		if ( ! empty( $seo['hours'] ) && is_array( $seo['hours'] ) ) {
			$hint = $seo['hours'];
		}
	}
	$schema = array(
		array( 'title' => 'Odbiór osobisty', 'fields' => array(
			array( 't' => 'status', 'items' => $status ),
			array( 't' => 'check', 'k' => 'on', 'l' => 'Klient może odebrać zamówienie sam w lokalu', 'hint' => 'W okienku terminu pojawi się wybór „🚚 Dostawa / 🏃 Odbiór osobisty”. Bez kosztu dostawy i bez adresu w kasie.' ),
			array( 't' => 'text', 'k' => 'address', 'l' => 'Adres miejsca odbioru', 'ph' => 'ul. Przykładowa 1, 64-920 Piła', 'max' => 200, 'hint' => 'Klient zobaczy go przy wyborze terminu, w kasie i w mailach. Domyślnie z wizytówki (Panel → SEO).' ),
			array( 't' => 'textarea', 'k' => 'note', 'l' => 'Wskazówki (opcjonalnie)', 'ph' => 'np. wejście od podwórza, dzwonek „Kuchnia”', 'max' => 500 ),
		) ),
		array( 'title' => 'Godziny odbioru', 'hint' => 'Odbiór działa tylko w dni, w które kuchnia przyjmuje zamówienia na dania z koszyka (dni grup, daty wyłączone, cutoff dzienny) – tu ustawiasz same godziny wydawania.', 'fields' => array(
			array( 't' => 'hours', 'k' => 'hours', 'l' => 'Godziny wydawania zamówień', 'suggest' => $hint ? $hint : null, 'suggestLabel' => 'Wpisz godziny lokalu (z Panel → SEO)', 'suggestAsk' => 'Wpisać godziny otwarcia lokalu z wizytówki (Panel → SEO)? Obecne godziny zostaną zastąpione.' ),
			array( 't' => 'select', 'k' => 'step', 'l' => 'Godziny do wyboru co', 'o' => array( '10' => '10 minut', '15' => '15 minut', '20' => '20 minut', '30' => '30 minut', '60' => 'godzinę' ) ),
			array( 't' => 'number', 'k' => 'lead', 'l' => 'Najpóźniej ile minut przed odbiorem można zamówić', 'min' => 0, 'max' => 1440, 'hint' => 'Np. 30 – o 12:00 najbliższa godzina odbioru to 12:30 (przy kroku 15 minut). Po tym czasie zamówienie samo przechodzi „W przygotowaniu” (gdy włączone „Auto przygotowanie” w Kuchni).' ),
			array( 't' => 'number', 'k' => 'max', 'l' => 'Najwięcej odbiorów o jednej godzinie', 'min' => 0, 'max' => 999, 'hint' => '0 = bez limitu. Pełna godzina znika z wyboru.' ),
		) ),
		array( 'title' => 'Kwoty i płatność', 'fields' => array(
			array( 't' => 'text', 'k' => 'min', 'l' => 'Minimalna wartość zamówienia przy odbiorze (zł)', 'ph' => 'puste = bez minimum', 'max' => 10, 'hint' => 'Wartość produktów przed rabatem. Minimum z Miejscowości dotyczy tylko dostawy.' ),
			array( 't' => 'radio', 'k' => 'disc_type', 'l' => 'Rabat za odbiór osobisty', 'o' => array( 'none' => 'Bez rabatu', 'pct' => 'Procent od wartości produktów', 'fix' => 'Kwota (zł)' ) ),
			array( 't' => 'text', 'k' => 'disc_val', 'l' => 'Wartość rabatu', 'ph' => 'np. 5', 'max' => 10, 'ifv' => array( 'disc_type', '!none' ), 'hint' => 'W koszyku i kasie jako osobna pozycja „Rabat za odbiór osobisty”.' ),
			array( 't' => 'radio', 'k' => 'pay', 'l' => 'Płatność przy odbiorze (gotówka lub karta w lokalu)', 'o' => array( 'online' => 'Nie – tylko płatność online', 'regular' => 'Tylko dla zalogowanych klientów, którzy już coś u nas odebrali (zalecane)', 'all' => 'Dla wszystkich' ), 'hint' => 'Przy płatności na miejscu rośnie ryzyko, że ktoś zamówi i nie przyjdzie. Korzysta z metody WooCommerce „Za pobraniem”.' ),
			array( 't' => 'check', 'k' => 'mail', 'l' => 'Mail do klienta „Gotowe do odbioru” po kliknięciu „Spakowane” w Kuchni' ),
		) ),
	);
	$v          = $s;
	$v['step']  = (string) $s['step'];
	return array( 'schema' => $schema, 'values' => $v );
}

function rzd_panel_do_pickup() {
	rzd_panel_out( rzd_panel_pickup_payload() );
}

function rzd_panel_do_pickup_save() {
	$v = rzd_panel_json( 'values' );
	if ( null === $v ) {
		rzd_panel_fail( 'Brak danych do zapisu.' );
	}
	list( $ok, $msg ) = rzd_pickup_save( $v );
	if ( ! $ok ) {
		rzd_panel_fail( $msg );
	}
	rzd_panel_out( array_merge( rzd_panel_pickup_payload(), array( 'message' => $msg ) ) );
}
