<?php
/**
 * Moduł 34-panel – sekcja SEO (2.46.0): zakładki Wizytówka, Udostępnianie, Indeksowanie, Do poprawy.
 * Dane i działanie – moduł 35-seo. Uprawnienie: „Ustawienia wtyczki”.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter( 'rzd_panel_actions', function ( $a ) {
	foreach ( array( 'seo', 'seo_save', 'seo_copied', 'seo_fix_alt', 'seo_public' ) as $k ) {
		$a[ $k ] = 'seo';
	}
	return $a;
} );

/** Podpowiedź godzin otwarcia z okien dostaw (pierwsze okno – ostatnie okno dnia). */
function rzd_panel_seo_hours_hint() {
	$out = array();
	foreach ( array_keys( rzd_seo_days() ) as $d ) {
		$w = function_exists( 'rzd_dc_windows_on' ) && rzd_dc_windows_on() ? rzd_dc_windows_for_dow( $d ) : array();
		$out[ $d ] = $w ? array( 'c' => 0, 'from' => $w[0]['start'], 'to' => $w[ count( $w ) - 1 ]['end'] ) : array( 'c' => 1, 'from' => '', 'to' => '' );
	}
	return $out;
}

function rzd_panel_seo_payload() {
	$s      = rzd_seo_settings();
	$plugin = rzd_seo_plugin();
	$types  = rzd_seo_types();
	$towns  = array();
	foreach ( function_exists( 'rzd_towns' ) ? rzd_towns() : array() as $t ) {
		$towns[] = (string) $t['name'];
	}
	$card = array(
		array( 'title' => 'Gdzie jest wizytówka restauracji', 'fields' => array(
			array( 't' => 'radio', 'k' => 'mode', 'l' => 'Układ', 'o' => array( 'main' => 'Ta strona to główna strona restauracji', 'separate' => 'Sklep jest osobną stroną – główna strona restauracji jest pod innym adresem' ) ),
			array( 't' => 'url', 'k' => 'main_url', 'l' => 'Adres strony głównej restauracji', 'ph' => 'https://twoja-restauracja.pl/', 'ifv' => array( 'mode', 'separate' ), 'hint' => 'Tam ma być pełna wizytówka – wtyczka przygotuje kod do wklejenia (niżej, po zapisie). W sklepie zostaje tylko odniesienie, żeby Google nie widział dwóch wizytówek tej samej firmy.' ),
		) ),
		array( 'title' => 'Dane restauracji', 'fields' => array(
			array( 't' => 'select', 'k' => 'type', 'l' => 'Rodzaj lokalu', 'o' => $types ),
			array( 't' => 'text', 'k' => 'name', 'l' => 'Nazwa', 'ph' => html_entity_decode( get_bloginfo( 'name' ), ENT_QUOTES, 'UTF-8' ), 'hint' => 'Puste = nazwa strony.' ),
			array( 't' => 'textarea', 'k' => 'desc', 'l' => 'Krótki opis', 'rows' => 3, 'ph' => 'np. Domowe obiady z dowozem w Pile i okolicy. Zestaw dnia od poniedziałku do piątku.' ),
			array( 't' => 'text', 'k' => 'street', 'l' => 'Ulica i numer' ),
			array( 't' => 'text', 'k' => 'postcode', 'l' => 'Kod pocztowy' ),
			array( 't' => 'text', 'k' => 'city', 'l' => 'Miejscowość' ),
			array( 't' => 'text', 'k' => 'phone', 'l' => 'Telefon', 'ph' => '+48 600 100 200' ),
			array( 't' => 'text', 'k' => 'email', 'l' => 'E-mail' ),
			array( 't' => 'text', 'k' => 'cuisine', 'l' => 'Rodzaj kuchni', 'ph' => 'np. polska, domowa', 'hint' => 'Kilka – po przecinku.' ),
			array( 't' => 'text', 'k' => 'price', 'l' => 'Przedział cen', 'ph' => 'np. 20–50 zł' ),
			array( 't' => 'check', 'k' => 'reservations', 'l' => 'Przyjmujemy rezerwacje stolików' ),
			array( 't' => 'status', 'items' => array( array( 'label' => 'Obszar dostaw (z Miejscowości)', 'ok' => (bool) $towns, 'text' => $towns ? implode( ', ', $towns ) : 'brak miejscowości – dodaj je w sekcji Miejscowości' ) ) ),
		) ),
		array( 'title' => 'Godziny otwarcia', 'fields' => array(
			array( 't' => 'hours', 'k' => 'hours', 'l' => 'Godziny otwarcia lokalu', 'suggest' => rzd_panel_seo_hours_hint(), 'hint' => 'To godziny lokalu (kiedy można przyjść albo zadzwonić), nie godziny dostaw. Puste dni – Google ich nie pokaże.' ),
		) ),
		array( 'title' => 'Logo, zdjęcie i profile', 'fields' => array(
			array( 't' => 'image', 'k' => 'logo_id', 'l' => 'Logo', 'hint' => 'Puste = logo motywu (Wygląd → Dostosuj → Tożsamość witryny).' ),
			array( 't' => 'image', 'k' => 'image_id', 'l' => 'Zdjęcie lokalu albo dania', 'hint' => 'Pokazywane przy wizytówce w Google.' ),
			array( 't' => 'textarea', 'k' => 'same_as', 'l' => 'Profile (Facebook, Instagram, Google Maps…)', 'rows' => 3, 'ph' => "https://www.facebook.com/…\nhttps://www.instagram.com/…", 'hint' => 'Jeden adres w linii – Google łączy je z restauracją.' ),
		) ),
	);
	$share = array(
		array( 'title' => 'Udostępnianie (Open Graph)', 'fields' => array_merge(
			'' !== $plugin ? array( array( 't' => 'note', 'warn' => 1, 'l' => 'Działa wtyczka ' . $plugin . ' – udostępnianie ustawiasz w niej (te pola są wtedy nieużywane).' ) ) : array(),
			array(
				array( 't' => 'image', 'k' => 'og_image_id', 'l' => 'Obrazek do udostępniania', 'hint' => 'Najlepiej 1200 × 630 px (poziomy). Dla strony głównej i listy dań; danie pokazuje swoje zdjęcie, zestaw – zdjęcie dzisiejszego dania.' ),
				array( 't' => 'textarea', 'k' => 'og_desc', 'l' => 'Opis strony głównej i listy dań', 'rows' => 3, 'ph' => 'np. Zamów obiad z dowozem – zestaw dnia, pierogi, ciasta. Dowozimy w Pile i okolicy.', 'hint' => 'Pod tytułem w Google i na Facebooku. Do ok. 155 znaków.' ),
			)
		) ),
	);
	$verify = array(
		array( 'title' => 'Weryfikacja w Google i Bing', 'fields' => '' !== $plugin
			? array( array( 't' => 'note', 'l' => 'Działa wtyczka ' . $plugin . ' – kody weryfikacji wpisuje się w niej.' ) )
			: array(
				array( 't' => 'note', 'l' => 'Potrzebne tylko przy Google Search Console z usługą „Prefiks URL”. Usługa „Domena” weryfikuje się rekordem DNS – tu nic nie wpisujesz.' ),
				array( 't' => 'text', 'k' => 'verify_google', 'l' => 'Kod Google (google-site-verification)', 'ph' => 'wklej kod albo cały znacznik <meta …>' ),
				array( 't' => 'text', 'k' => 'verify_bing', 'l' => 'Kod Bing (msvalidate.01)' ),
			) ),
	);
	$staff = array();
	foreach ( rzd_seo_staff_page_ids() as $pid ) {
		$staff[] = get_the_title( $pid );
	}
	$hidden = rzd_seo_hidden_product_ids();
	$index  = array(
		array( 'label' => 'Widoczność dla wyszukiwarek', 'ok' => (bool) get_option( 'blog_public' ), 'text' => get_option( 'blog_public' ) ? 'włączona' : 'WYŁĄCZONA – Google nie pokaże sklepu (Ustawienia → Czytanie)' ),
		array( 'label' => 'Strony obsługi ukryte (noindex)', 'ok' => true, 'text' => $staff ? implode( ', ', $staff ) : 'Kuchnia, Panel, Edycja menu, Sala, Kurier – gdy powstaną' ),
		array( 'label' => 'Koszyk, kasa, konto', 'ok' => true, 'text' => 'ukryte przez WooCommerce' ),
		array( 'label' => 'Dania poza sprzedażą online (noindex, poza mapą)', 'ok' => true, 'text' => $hidden ? count( $hidden ) . ': ' . implode( ', ', array_map( 'get_the_title', array_slice( $hidden, 0, 8 ) ) ) . ( count( $hidden ) > 8 ? ' …' : '' ) : 'brak' ),
		array( 'label' => 'Mapa witryny', 'ok' => true, 'text' => '' !== $plugin ? 'z wtyczki ' . $plugin : home_url( '/wp-sitemap.xml' ), 'url' => '' !== $plugin ? '' : home_url( '/wp-sitemap.xml' ) ),
	);
	$imgs = rzd_panel_img_urls( array( $s['logo_id'], $s['image_id'], $s['og_image_id'] ) );
	$theme_logo = (int) get_theme_mod( 'custom_logo' );
	return array(
		'values'  => $s,
		'card'    => $card,
		'share'   => $share,
		'verify'  => $verify,
		'imgs'    => $imgs,
		'plugin'  => $plugin,
		'index'   => $index,
		'public'  => (bool) get_option( 'blog_public' ),
		'audit'   => rzd_seo_audit(),
		'snippet' => 'separate' === $s['mode'] ? rzd_seo_snippet() : '',
		'stale'   => rzd_seo_snippet_stale(),
		'copied'  => '' !== $s['snippet_hash'],
		'ready'   => rzd_seo_card_ready(),
		'og'      => array(
			'title' => html_entity_decode( get_bloginfo( 'name' ), ENT_QUOTES, 'UTF-8' ),
			'host'  => wp_parse_url( home_url(), PHP_URL_HOST ),
			'logo'  => $theme_logo ? (string) wp_get_attachment_image_url( $theme_logo, 'large' ) : '',
			'imgL'  => $s['og_image_id'] ? (string) wp_get_attachment_image_url( $s['og_image_id'], 'large' ) : '',
		),
		'tests'   => array(
			'google' => 'https://search.google.com/test/rich-results?url=' . rawurlencode( home_url( '/' ) ),
			'menu'   => rzd_seo_list_url() ? 'https://search.google.com/test/rich-results?url=' . rawurlencode( rzd_seo_list_url() ) : '',
			'fb'     => 'https://developers.facebook.com/tools/debug/?q=' . rawurlencode( home_url( '/' ) ),
			'main'   => 'separate' === $s['mode'] && $s['main_url'] ? 'https://search.google.com/test/rich-results?url=' . rawurlencode( $s['main_url'] ) : '',
		),
	);
}

function rzd_panel_do_seo() {
	rzd_panel_out( rzd_panel_seo_payload() );
}

function rzd_panel_do_seo_save() {
	$v = rzd_panel_json( 'values' );
	if ( null === $v ) {
		rzd_panel_fail( 'Brak danych do zapisu.' );
	}
	$s = rzd_seo_save( $v );
	$m = 'Zapisano ustawienia SEO.';
	if ( 'separate' === $s['mode'] && rzd_seo_snippet_stale() ) {
		$m .= ' Dane wizytówki się zmieniły – skopiuj kod na stronę główną ponownie.';
	}
	rzd_panel_out( array_merge( rzd_panel_seo_payload(), array( 'message' => $m ) ) );
}

/** Kod skopiowany na stronę główną – zapamiętany skrót (przypomnienie, gdy dane się zmienią). */
function rzd_panel_do_seo_copied() {
	$s                 = get_option( 'rzd_seo', array() );
	$s                 = is_array( $s ) ? $s : array();
	$s['snippet_hash'] = rzd_seo_snippet_hash();
	update_option( 'rzd_seo', $s, true );
	rzd_panel_out( array_merge( rzd_panel_seo_payload(), array( 'message' => 'Skopiowano. Wklej kod w <head> strony głównej (przed </head>).' ) ) );
}

function rzd_panel_do_seo_fix_alt() {
	$n = rzd_seo_fix_alt();
	rzd_panel_out( array_merge( rzd_panel_seo_payload(), array( 'message' => 'Uzupełniono tekst alternatywny: ' . $n . '.' ) ) );
}

function rzd_panel_do_seo_public() {
	if ( ! current_user_can( 'manage_options' ) && ! rzd_can( 'settings' ) ) {
		rzd_panel_fail( 'Brak uprawnień.', 403 );
	}
	update_option( 'blog_public', '1' );
	rzd_panel_out( array_merge( rzd_panel_seo_payload(), array( 'message' => 'Strona jest widoczna dla wyszukiwarek.' ) ) );
}
