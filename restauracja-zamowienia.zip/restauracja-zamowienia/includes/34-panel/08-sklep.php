<?php
/**
 * Moduł 34-panel – sekcja Sklep (2.45.0): zakładki Koszyk, Pasek dostawy, Dobierz do zamówienia,
 * Formularz zamówienia. Każda zakładka = schemat pól (rysuje go rzd-panel-formy.js) + wartości;
 * zapis przez funkcje modułów (rzd_koszyk_save – 07, rzd_upsell_save / rzd_upsell_cards_save – 32,
 * rzd_co_save – 29) do TYCH SAMYCH opcji co dawne strony kokpitu (kc_settings, rzd_upsell,
 * rzd_upsell_cards, rzd_checkout).
 *
 * Pole schematu: t (typ: text, textarea, number, url, check, checks, radio, select, image, color,
 * products, cats, srcorder, note, status), k (klucz), l (etykieta), hint, o (opcje), min/max/step/u,
 * ph (podpowiedź w polu), if (pokaż, gdy pole k jest zaznaczone), ifv ([k, wartość]), adv (w „Zaawansowane”).
 * Obrazki: wybór z biblioteki albo wgranie (akcje media_list / media_upload).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter( 'rzd_panel_actions', function ( $a ) {
	foreach ( array( 'shop', 'shop_save', 'media_list', 'media_upload' ) as $k ) {
		$a[ $k ] = 'sklep';
	}
	return $a;
} );

function rzd_panel_shop_tabs() {
	return array(
		'koszyk'    => 'Koszyk',
		'pasek'     => 'Pasek dostawy',
		'dobierz'   => 'Dobierz do zamówienia',
		'formularz' => 'Formularz zamówienia',
	);
}

/** Schemat i wartości zakładki. */
function rzd_panel_shop_tab( $tab ) {
	switch ( $tab ) {
		case 'pasek':
			return rzd_panel_shop_pasek();
		case 'dobierz':
			return rzd_panel_shop_dobierz();
		case 'formularz':
			return rzd_panel_shop_formularz();
		default:
			return rzd_panel_shop_koszyk();
	}
}

/** Adresy obrazków (podgląd w polu „obrazek”). */
function rzd_panel_img_urls( $ids ) {
	$out = array();
	foreach ( array_filter( array_map( 'intval', (array) $ids ) ) as $id ) {
		$u = wp_get_attachment_image_url( $id, 'thumbnail' );
		if ( $u ) {
			$out[ $id ] = $u;
		}
	}
	return $out;
}

/* ---------- Koszyk ---------- */
function rzd_panel_shop_koszyk() {
	$s = rzd_koszyk_get_settings();
	return array(
		'title'   => 'Koszyk',
		'intro'   => 'Ikona koszyka w menu strony, pływający koszyk, okienko po dodaniu i strona pustego koszyka.',
		'schema'  => array(
			array( 'title' => 'Koszyk w menu', 'fields' => array(
				array( 't' => 'image', 'k' => 'image_id', 'l' => 'Obrazek koszyka', 'hint' => 'Najlepiej kwadratowy PNG z przezroczystym tłem. Bez obrazka – ikona domyślna.' ),
				array( 't' => 'text', 'k' => 'name', 'l' => 'Nazwa koszyka' ),
				array( 't' => 'radio', 'k' => 'display', 'l' => 'Wyświetlanie', 'o' => array( 'both' => 'Obrazek i nazwa', 'image' => 'Tylko obrazek' ) ),
				array( 't' => 'check', 'k' => 'show_qty', 'l' => 'Pokaż ilość produktów w koszyku', 'hint' => 'Bez ilości, ale z produktami w koszyku, pojawia się mały czerwony znacznik.' ),
				array( 't' => 'check', 'k' => 'show_total', 'l' => 'Pokaż wartość koszyka' ),
				array( 't' => 'check', 'k' => 'menu_replace', 'l' => 'Zastąp pozycję menu prowadzącą do koszyka tym koszykiem', 'hint' => 'Koszyk możesz też wstawić w dowolnym miejscu shortcodem [koszyk].' ),
			) ),
			array( 'title' => 'Pływający koszyk', 'fields' => array(
				array( 't' => 'check', 'k' => 'float_enabled', 'l' => 'Włącz pływający koszyk', 'hint' => 'Nie pokazuje się na stronie koszyka i kasy.' ),
				array( 't' => 'check', 'k' => 'float_mobile_only', 'l' => 'Pokazuj tylko na telefonach i tabletach', 'if' => 'float_enabled' ),
				array( 't' => 'select', 'k' => 'float_pos', 'l' => 'Położenie', 'o' => array( 'right' => 'Prawy dolny róg', 'left' => 'Lewy dolny róg' ), 'if' => 'float_enabled' ),
			) ),
			array( 'title' => 'Koszyk na telefonie', 'fields' => array(
				array( 't' => 'check', 'k' => 'mobile_enabled', 'l' => 'Pokaż koszyk w nagłówku na telefonie (między logo a menu)', 'hint' => 'Wygląda jak koszyk w menu (ten sam obrazek, nazwa i liczniki). Pozycja koszyka w rozwijanym menu jest wtedy na telefonie ukrywana, żeby się nie dublowała.' ),
				array( 't' => 'number', 'k' => 'mobile_breakpoint', 'l' => 'Pokazuj przy szerokości ekranu do', 'u' => 'px', 'min' => 320, 'max' => 1400, 'if' => 'mobile_enabled' ),
				array( 't' => 'text', 'k' => 'mobile_logo_sel', 'l' => 'Selektor logo motywu', 'ph' => rzd_koszyk_default_logo_sel(), 'adv' => 1, 'if' => 'mobile_enabled', 'hint' => 'Zostaw puste – wykrywanie automatyczne. Wpisz selektor CSS tylko, gdy koszyk ląduje w złym miejscu.' ),
				array( 't' => 'text', 'k' => 'mobile_menu_sel', 'l' => 'Selektor przycisku menu (burgera)', 'ph' => rzd_koszyk_default_menu_sel(), 'adv' => 1, 'if' => 'mobile_enabled' ),
			) ),
			array( 'title' => 'Po dodaniu do koszyka', 'fields' => array(
				array( 't' => 'check', 'k' => 'added_popup', 'l' => 'Pokaż okienko z tym, co dodano (Przejdź do koszyka / Kontynuuj zakupy)' ),
				array( 't' => 'url', 'k' => 'list_url', 'l' => 'Adres strony z listą produktów', 'ph' => 'https://twoja-strona.pl/zamow/', 'hint' => 'Tu wraca „Kontynuuj zakupy” (gdy dodawano z innej strony) i „Wybierz inny produkt” w kalendarzu dostaw.' ),
			) ),
			array( 'title' => 'Pusty koszyk', 'fields' => array(
				array( 't' => 'text', 'k' => 'empty_text', 'l' => 'Napis' ),
				array( 't' => 'radio', 'k' => 'empty_icon', 'l' => 'Ikonka nad napisem', 'o' => array( 'default' => 'smutna buźka WooCommerce', 'image' => 'własny obrazek', 'none' => 'bez ikonki' ) ),
				array( 't' => 'image', 'k' => 'empty_icon_id', 'l' => 'Własny obrazek', 'ifv' => array( 'empty_icon', 'image' ), 'hint' => 'Najlepiej kwadratowy PNG z przezroczystym tłem (np. smutny bajgiel z logo).' ),
				array( 't' => 'number', 'k' => 'empty_icon_size', 'l' => 'Wielkość ikonki', 'u' => 'px', 'min' => 24, 'max' => 400, 'ifv' => array( 'empty_icon', '!none' ) ),
				array( 't' => 'check', 'k' => 'empty_icon_full', 'l' => 'Na całą szerokość (wielkość = wysokość obrazka)', 'ifv' => array( 'empty_icon', 'image' ) ),
			) ),
			array( 'title' => 'Przycisk powrotu (koszyk i kasa)', 'fields' => array(
				array( 't' => 'text', 'k' => 'back_text', 'l' => 'Napis na przycisku' ),
				array( 't' => 'check', 'k' => 'back_center', 'l' => 'Na środku', 'hint' => 'Kolory, zaokrąglenie i czcionka – z Wyglądu → „Przycisk »Dodaj do koszyka«”.' ),
			) ),
		),
		'values'  => $s,
		'imgs'    => rzd_panel_img_urls( array( $s['image_id'], $s['empty_icon_id'] ) ),
		'preview' => rzd_koszyk_preview_doc(),
		'links'   => array( array( 'Zobacz koszyk w sklepie', wc_get_cart_url() ) ),
	);
}

/* ---------- Pasek dostawy ---------- */
function rzd_panel_shop_pasek() {
	$s      = rzd_upsell_settings();
	$fields = array(
		array( 't' => 'check', 'k' => 'on', 'l' => 'Pasek dostawy włączony' ),
		array( 't' => 'checks', 'k' => 'where', 'l' => 'Gdzie pokazywać', 'o' => rzd_upsell_places(), 'if' => 'on' ),
		array( 't' => 'check', 'k' => 'hint', 'l' => 'Podpowiedź z dodatkiem w „Sprawdź zamówienie”', 'if' => 'on', 'hint' => 'Np. „Dodaj frytki do „Schabowego” (+6 zł) i masz darmową dostawę” – otwiera „Dodatki płatne” tego dania. Brany jest najtańszy płatny dodatek z grup „W przeglądzie zamówienia”, który sam domyka brakującą kwotę.' ),
	);
	$texts = array();
	foreach ( rzd_upsell_texts() as $k => $t ) {
		$texts[] = array( 't' => 'text', 'k' => $k, 'l' => $t[0], 'hint' => 'Znaczniki: ' . $t[1] . '. Puste = ten stan bez paska.' );
	}
	return array(
		'title'  => 'Pasek dostawy',
		'intro'  => 'Informacja dla klienta, ile brakuje do minimum zamówienia albo do darmowej dostawy – liczona tak samo jak dostawa w Miejscowościach (wartość produktów przed rabatem, bez opakowań, miejscowość z okienka terminu). Bez wybranej miejscowości pasek się nie pokazuje.',
		'schema' => array(
			array( 'title' => 'Ustawienia', 'fields' => $fields ),
			array( 'title' => 'Teksty', 'fields' => $texts, 'if' => 'on' ),
		),
		'values' => $s,
	);
}

/* ---------- Dobierz do zamówienia ---------- */
function rzd_panel_shop_dobierz() {
	$s    = rzd_upsell_cards_settings();
	$cats = array();
	foreach ( get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false ) ) as $t ) {
		if ( ! is_wp_error( $t ) && ! get_term_meta( $t->term_id, 'rwz_hide_in_shop', true ) ) { // ukryta – jej produktów i tak się nie poleca
			$cats[] = array( 'id' => (int) $t->term_id, 'name' => $t->name );
		}
	}
	return array(
		'title'    => 'Dobierz do zamówienia',
		'intro'    => 'Karty polecanych produktów w „Sprawdź zamówienie” (pod paskiem dostawy) i w koszyku – klient dodaje jednym kliknięciem. Pokazywane są tylko produkty, które da się dowieźć w terminie z koszyka, nie są już w koszyku i których danie nie zawiera. Zestawy i produkty z wariantami są pomijane. W kasie kart nie ma.',
		'schema'   => array(
			array( 'title' => 'Ustawienia', 'fields' => array(
				array( 't' => 'check', 'k' => 'on', 'l' => 'Karty włączone' ),
				array( 't' => 'checks', 'k' => 'where', 'l' => 'Gdzie pokazywać', 'o' => array( 'review' => '„Sprawdź zamówienie” (pod paskiem dostawy)', 'cart' => 'Koszyk (nad listą produktów)' ), 'if' => 'on' ),
				array( 't' => 'srcorder', 'k' => 'order', 'l' => 'Źródła i kolejność', 'o' => rzd_upsell_card_sources(), 'if' => 'on', 'hint' => 'Karty brane są po kolei: najpierw z pierwszego źródła, potem z następnych – do limitu kart. Ten sam produkt – tylko raz.' ),
				array( 't' => 'number', 'k' => 'max', 'l' => 'Najwyżej kart', 'min' => 1, 'max' => 6, 'if' => 'on' ),
			) ),
			array( 'title' => 'Polecane przy koszyku', 'if' => 'on', 'fields' => array(
				array( 't' => 'products', 'k' => 'list', 'l' => 'Produkty (w tej kolejności)', 'hint' => 'Sprzedaż krzyżową ustawiasz w produkcie WooCommerce: Dane produktu → Produkty połączone → „Sprzedaż krzyżowa”.' ),
			) ),
			array( 'title' => 'Kategorie do domykania progu', 'if' => 'on', 'fields' => array(
				array( 't' => 'cats', 'k' => 'cats', 'l' => 'Kategorie', 'hint' => 'Np. napoje, desery, sosy – źródło „domykający próg” poleca najtańszy produkt z tych kategorii, który sam wystarczy do darmowej dostawy (albo do minimum). Bez kategorii to źródło nic nie pokazuje.' ),
			) ),
			array( 'title' => 'Teksty', 'if' => 'on', 'fields' => array(
				array( 't' => 'text', 'k' => 'title', 'l' => 'Nagłówek' ),
				array( 't' => 'text', 'k' => 'no', 'l' => 'Przycisk „nie”', 'hint' => 'Chowa karty do końca wizyty. Puste = bez przycisku.' ),
				array( 't' => 'text', 'k' => 'gap_tag', 'l' => 'Plakietka „domyka próg”', 'hint' => 'Na karcie produktu, który domyka próg. Puste = bez plakietki.' ),
			) ),
		),
		'values'   => $s,
		'products' => array_values( array_filter( rzd_panel_product_list(), function ( $p ) {
			return ! $p['hidden'];
		} ) ),
		'cats'     => $cats,
	);
}

/* ---------- Formularz zamówienia ---------- */
function rzd_panel_shop_formularz() {
	$s     = rzd_co_settings();
	$pages = rzd_co_legal_pages();
	$wp    = current_user_can( 'manage_woocommerce' );
	$items = array(
		array( 'label' => 'Regulamin', 'ok' => (bool) $pages['terms'], 'text' => $pages['terms'] ? get_the_title( $pages['terms'] ) : 'nie ustawiony – WooCommerce nie pokaże pola akceptacji (wymagane m.in. przez Przelewy24)', 'url' => $pages['terms'] ? get_permalink( $pages['terms'] ) : '', 'fix' => $wp ? admin_url( 'admin.php?page=wc-settings&tab=advanced' ) : '', 'fixText' => 'WooCommerce → Ustawienia → Zaawansowane' ),
		array( 'label' => 'Polityka prywatności', 'ok' => (bool) $pages['privacy'], 'text' => $pages['privacy'] ? get_the_title( $pages['privacy'] ) : 'nie ustawiona (strona musi być opublikowana)', 'url' => $pages['privacy'] ? get_permalink( $pages['privacy'] ) : '', 'fix' => current_user_can( 'manage_privacy_options' ) ? admin_url( 'options-privacy.php' ) : '', 'fixText' => 'Ustawienia → Prywatność' ),
	);
	$design = array( array( 't' => 'check', 'k' => 'design', 'l' => 'Nowy wygląd kasy', 'hint' => 'Sekcje jako karty, telefon przy danych kontaktowych, bez pola „Kraj” (gdy dowozimy tylko do miejscowości z listy albo sklep sprzedaje do jednego kraju), płatności jako kafelki, na komputerze podsumowanie obok formularza. Kolory i czcionka z Wyglądu. Wyłączenie = kasa jak dotąd.' ) );
	if ( rzd_co_fluid_active() ) {
		array_unshift( $design, array( 't' => 'note', 'warn' => 1, 'l' => 'Działa Fluid Checkout – nowy wygląd się nie włączy (dwa układy kasy naraz). Zgody i przycisk działają.' ) );
	}
	$design[] = array( 't' => 'check', 'k' => 'invoice', 'l' => 'Pole „Potrzebuję faktury (firma)” – nazwa firmy i NIP (sprawdzany)', 'if' => 'design' );
	$design[] = array( 't' => 'radio', 'k' => 'notes', 'l' => 'Uwagi do zamówienia', 'o' => array( 'collapsed' => 'zwinięte pod linkiem „+ Dodaj uwagi”', 'open' => 'widoczne', 'hidden' => 'bez uwag' ), 'if' => 'design' );
	return array(
		'title'  => 'Formularz zamówienia',
		'intro'  => 'Wygląd i zgody na stronie kasy (przed płatnością) – bez dodatkowych wtyczek.',
		'schema' => array(
			array( 'title' => 'Strony prawne', 'fields' => array( array( 't' => 'status', 'items' => $items ) ) ),
			array( 'title' => 'Zgody i przycisk (działają zawsze)', 'fields' => array(
				array( 't' => 'radio', 'k' => 'consent', 'l' => 'Zgody', 'o' => array( 'combined' => 'jedno wymagane pole: regulamin + polityka prywatności (zalecane)', 'separate' => 'dwa osobne wymagane pola', 'woocommerce' => 'bez zmian (ustawienia WooCommerce)' ) ),
				array( 't' => 'text', 'k' => 'consent_text', 'l' => 'Treść pola zgody', 'ifv' => array( 'consent', 'combined' ), 'hint' => '[terms] = link do regulaminu, [privacy_policy] = link do polityki prywatności. Pole nigdy nie jest zaznaczone z góry.' ),
				array( 't' => 'text', 'k' => 'privacy_text', 'l' => 'Treść pola polityki prywatności', 'ifv' => array( 'consent', 'separate' ) ),
				array( 't' => 'text', 'k' => 'extra_consent', 'l' => 'Dodatkowe wymagane pole', 'ph' => 'np. Akceptuję regulamin Przelewy24', 'hint' => 'Puste = brak. Gdy operator płatności wymaga osobnej akceptacji swojego regulaminu. Link: <a href="adres z umowy">…</a>.' ),
				array( 't' => 'text', 'k' => 'button_text', 'l' => 'Napis na przycisku zamówienia', 'hint' => 'Prawo (art. 17 ustawy o prawach konsumenta) wymaga, by przycisk jednoznacznie mówił o obowiązku zapłaty – „Zamawiam i płacę” jest bezpieczne. Puste = tekst WooCommerce.' ),
				array( 't' => 'check', 'k' => 'button_total', 'l' => 'Z kwotą do zapłaty („Zamawiam i płacę 67,50 zł”)' ),
			) ),
			array( 'title' => 'Nowy wygląd', 'fields' => $design ),
		),
		'values' => $s,
		'links'  => array( array( 'Otwórz kasę (z produktem w koszyku)', wc_get_checkout_url() ) ),
	);
}

function rzd_panel_do_shop() {
	$tab = rzd_panel_str( 'tab' );
	rzd_panel_out( array( 'tab' => isset( rzd_panel_shop_tabs()[ $tab ] ) ? $tab : 'koszyk' ) + rzd_panel_shop_tab( $tab ) );
}

function rzd_panel_do_shop_save() {
	$tab = rzd_panel_str( 'tab' );
	$v   = rzd_panel_json( 'values' );
	if ( null === $v || ! isset( rzd_panel_shop_tabs()[ $tab ] ) ) {
		rzd_panel_fail( 'Brak danych do zapisu.' );
	}
	switch ( $tab ) {
		case 'pasek':
			rzd_upsell_save( $v );
			$msg = 'Zapisano pasek dostawy.';
			break;
		case 'dobierz':
			rzd_upsell_cards_save( $v );
			$msg = 'Zapisano „Dobierz do zamówienia”.';
			break;
		case 'formularz':
			rzd_co_save( $v );
			$msg = 'Zapisano formularz zamówienia.';
			break;
		default:
			rzd_koszyk_save( $v );
			$msg = 'Zapisano koszyk.';
	}
	rzd_panel_out( array( 'tab' => $tab, 'message' => $msg ) + rzd_panel_shop_tab( $tab ) );
}

/* ============================================================
 * OBRAZKI: biblioteka mediów (ostatnie, szukanie) i wgranie
 * ============================================================ */
function rzd_panel_media_item( $id ) {
	return array( 'id' => (int) $id, 'url' => (string) wp_get_attachment_image_url( $id, 'thumbnail' ), 'title' => get_the_title( $id ) );
}

function rzd_panel_do_media_list() {
	$q    = rzd_panel_str( 's' );
	$args = array( 'post_type' => 'attachment', 'post_status' => 'inherit', 'post_mime_type' => 'image', 'numberposts' => 48, 'orderby' => 'date', 'order' => 'DESC', 'fields' => 'ids' );
	if ( '' !== $q ) {
		$args['s'] = $q;
	}
	rzd_panel_out( array( 'items' => array_map( 'rzd_panel_media_item', get_posts( $args ) ), 'canUpload' => current_user_can( 'upload_files' ) ) );
}

function rzd_panel_do_media_upload() {
	if ( ! current_user_can( 'upload_files' ) ) {
		rzd_panel_fail( 'To konto nie może wgrywać plików.', 403 );
	}
	if ( empty( $_FILES['file'] ) || ! empty( $_FILES['file']['error'] ) || (int) $_FILES['file']['size'] > 5 * MB_IN_BYTES ) { // phpcs:ignore
		rzd_panel_fail( 'Plik nie dotarł albo jest za duży (max 5 MB).' );
	}
	$mimes = array( 'jpg|jpeg|jpe' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp', 'gif' => 'image/gif' );
	$chk   = wp_check_filetype_and_ext( $_FILES['file']['tmp_name'], $_FILES['file']['name'], $mimes ); // phpcs:ignore
	if ( empty( $chk['type'] ) ) {
		rzd_panel_fail( 'To nie jest obrazek (JPG, PNG, WebP, GIF).' );
	}
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	$att = media_handle_upload( 'file', 0, array(), array( 'test_form' => false, 'mimes' => $mimes ) );
	if ( is_wp_error( $att ) ) {
		rzd_panel_fail( 'Nie udało się zapisać obrazka: ' . $att->get_error_message() );
	}
	rzd_panel_out( array( 'item' => rzd_panel_media_item( $att ), 'message' => 'Wgrano obrazek.' ) );
}
