<?php
/**
 * Moduł 34-panel – strona [rzd_panel]: własny dokument HTML bez motywu, logowanie, skrypt panelu.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function rzd_panel_is_page() {
	if ( is_admin() || ! is_singular() ) {
		return false;
	}
	$post = get_post();
	return $post && has_shortcode( $post->post_content, 'rzd_panel' );
}

/*
 * Pełny ekran bez motywu: zamiast szablonu motywu – własny, minimalny dokument (wp_head / wp_footer
 * zostają, bo przez nie dochodzą nasze skrypty). Style i skrypty motywu są zdejmowane, więc zmiana
 * czy aktualizacja motywu nie wpływa na panel. Strona nigdy z cache (dane się zmieniają, jest zalogowany).
 */
// bez paska WordPressa – przed _wp_admin_bar_init (template_redirect, priorytet 0)
add_action( 'template_redirect', function () {
	if ( rzd_panel_is_page() ) {
		add_filter( 'show_admin_bar', '__return_false', 99 );
	}
}, -1 );

add_action( 'template_redirect', function () {
	if ( ! rzd_panel_is_page() ) {
		return;
	}
	if ( ! defined( 'DONOTCACHEPAGE' ) ) {
		define( 'DONOTCACHEPAGE', true );
	}
	nocache_headers();
	remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
	remove_action( 'wp_print_styles', 'print_emoji_styles' );
	remove_action( 'wp_enqueue_scripts', 'wp_enqueue_emoji_styles' );
	$id = (int) get_the_ID();
	if ( (int) get_option( 'rzd_panel_page_id' ) !== $id ) {
		update_option( 'rzd_panel_page_id', $id, false );
	}
	$post = get_post();
	$body = do_shortcode( (string) $post->post_content );
	?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title><?php echo esc_html( 'Panel restauracji – ' . get_bloginfo( 'name' ) ); ?></title>
<?php wp_head(); ?>
</head>
<body class="rzd-panel-body">
<?php echo $body; // phpcs:ignore -- treść shortcode'u (escapowana w środku) ?>
<?php wp_footer(); ?>
</body>
</html>
	<?php
	exit;
}, 99 );

// Zdejmujemy wszystko z katalogu motywu (style i skrypty) – panel ma własny wygląd.
add_action( 'wp_enqueue_scripts', function () {
	if ( ! rzd_panel_is_page() ) {
		return;
	}
	$theme = array( get_template_directory_uri(), get_stylesheet_directory_uri() );
	foreach ( array( wp_styles(), wp_scripts() ) as $deps ) {
		foreach ( (array) $deps->queue as $h ) {
			$src = isset( $deps->registered[ $h ] ) ? (string) $deps->registered[ $h ]->src : '';
			foreach ( $theme as $t ) {
				if ( '' !== $src && 0 === strpos( $src, $t ) ) {
					$deps === wp_styles() ? wp_dequeue_style( $h ) : wp_dequeue_script( $h );
				}
			}
		}
	}
	// okienka sklepu (termin, dosprzedaż, koszyk) nie mają tu sensu
	foreach ( array( 'rzd-termin', 'rzd-dobierz', 'rzd-brama', 'rzd-modyfikacje' ) as $h ) {
		wp_dequeue_script( $h );
	}
	if ( ! is_user_logged_in() || ! rzd_panel_can() ) {
		wp_enqueue_style( 'rzd-panel', RZD_PLUGIN_URL . 'assets/css/rzd-panel.css', array(), rzd_asset_ver( 'assets/css/rzd-panel.css' ) );
		return;
	}
	wp_enqueue_style( 'rzd-panel', RZD_PLUGIN_URL . 'assets/css/rzd-panel.css', array(), rzd_asset_ver( 'assets/css/rzd-panel.css' ) );
	wp_enqueue_style( 'rzd-grupy', RZD_PLUGIN_URL . 'assets/css/rzd-grupy.css', array(), rzd_asset_ver( 'assets/css/rzd-grupy.css' ) );
	wp_enqueue_script( 'rzd-grupy', RZD_PLUGIN_URL . 'assets/js/rzd-grupy.js', array(), rzd_asset_ver( 'assets/js/rzd-grupy.js' ), array( 'in_footer' => true, 'strategy' => 'defer' ) );
	wp_enqueue_script( 'rzd-panel', RZD_PLUGIN_URL . 'assets/js/rzd-panel.js', array( 'rzd-grupy' ), rzd_asset_ver( 'assets/js/rzd-panel.js' ), array( 'in_footer' => true, 'strategy' => 'defer' ) );
	// części sekcji (2.45.0) – rejestrują się w window.rzdPanelKit; panel startuje po DOMContentLoaded
	// 2.45.0 (etapy 3–4): formy (formularz ze schematu – wspólny), sklep (Sklep, Wygląd), strona (Menu strony),
	// formularze (kreator formularzy kontaktowych), zespol (uprawnienia, konta)
	foreach ( array( 'formy', 'terminy', 'menu', 'zestawy', 'sklep', 'strona', 'formularze', 'zespol', 'seo', 'odbior', 'posty', 'polaczenia', 'opisy', 'sms', 'shortcody' ) as $part ) {
		wp_enqueue_script( 'rzd-panel-' . $part, RZD_PLUGIN_URL . 'assets/js/rzd-panel-' . $part . '.js', array( 'rzd-panel' ), rzd_asset_ver( 'assets/js/rzd-panel-' . $part . '.js' ), array( 'in_footer' => true, 'strategy' => 'defer' ) );
	}
	wp_add_inline_script( 'rzd-panel', 'var rzdPanel = ' . wp_json_encode( array(
		'ajax'     => admin_url( 'admin-ajax.php' ),
		'post'     => admin_url( 'admin-post.php' ),
		'nonce'    => wp_create_nonce( 'rzd_panel' ),
		'rrNonce'  => wp_create_nonce( 'rr_export' ),
		'csvNonce' => wp_create_nonce( 'rzd_kf_csv' ),
		'base'     => get_permalink(),
		'logout'   => wp_logout_url( get_permalink() ),
	) ) . ';', 'before' );
}, 999 );

add_shortcode( 'rzd_panel', function () {
	if ( ! is_user_logged_in() ) {
		return '<div class="rp-gate">' . rzd_brand_html( 'rzd-brand rp-gate-brand' ) . rzd_staff_login_html( 'Panel restauracji', 'Zaloguj się kontem szefa lub managera. Zostaw zaznaczone „Zapamiętaj mnie”.' ) . '</div>';
	}
	if ( ! rzd_panel_can() ) {
		$home = function_exists( 'rzd_staff_home' ) ? rzd_staff_home( wp_get_current_user() ) : '';
		return '<div class="rp-gate">' . rzd_brand_html( 'rzd-brand rp-gate-brand' ) . rzd_no_access_html( 'Panel restauracji' ) . ( $home ? '<p class="rp-gate-home"><a href="' . esc_url( $home ) . '">Przejdź do swojego ekranu →</a></p>' : '' ) . '</div>';
	}
	return '<div id="rzd-panel" class="rp" aria-live="polite"><p class="rp-load">Wczytuję panel…</p></div>';
} );

/*
 * Logowanie: osoba z dostępem do panelu, ale nie Administrator (Szef, Manager) – po zalogowaniu
 * od razu Panel restauracji zamiast kokpitu (decyzja użytkownika 2026-10-27). Gdy logowano się
 * z konkretnym adresem docelowym (redirect_to) – zostaje on. Konta „tylko obsługa” – jak dotąd (moduł 25).
 */
function rzd_panel_login_target( $user, $to, $requested = null ) {
	if ( ! $user instanceof WP_User || user_can( $user, 'manage_options' ) || ( function_exists( 'rzd_staff_only' ) && rzd_staff_only( $user ) ) || ! rzd_panel_can( $user ) ) {
		return $to;
	}
	$want  = null === $requested ? (string) $to : (string) $requested;
	$plain = array_filter( array( admin_url(), home_url( '/' ), function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : '' ) );
	if ( '' !== $want && ! in_array( untrailingslashit( $want ), array_map( 'untrailingslashit', $plain ), true ) ) {
		return $to; // logowanie z konkretnym adresem docelowym – zostaje
	}
	$url = rzd_panel_ensure_page(); // pierwszy raz po aktualizacji – strona tworzy się sama
	return '' !== $url ? $url : $to;
}
add_filter( 'login_redirect', function ( $to, $requested, $user ) {
	return rzd_panel_login_target( $user, $to, (string) $requested );
}, 40, 3 );
add_filter( 'woocommerce_login_redirect', function ( $to, $user ) {
	return rzd_panel_login_target( $user, $to );
}, 40, 2 );
