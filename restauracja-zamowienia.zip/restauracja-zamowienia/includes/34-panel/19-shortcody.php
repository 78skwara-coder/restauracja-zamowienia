<?php
/**
 * Moduł 34-panel – sekcja „Shortcody i API” (2.59.0, moduł 42-api-strony): spis wszystkich shortcodów wtyczki
 * z atrybutami i przykładami (do skopiowania), ustawienia API strony (włącznik, domeny, napis przycisku),
 * adresy REST i generator kodu do wklejenia na inną stronę. Akcje: shortcodes, shortcodes_save.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter( 'rzd_panel_actions', function ( $a ) {
	$a['shortcodes']      = 'shortcody';
	$a['shortcodes_save'] = 'shortcody';
	return $a;
} );

function rzd_panel_shortcodes_payload() {
	$s = rzd_site_api_settings();
	return array(
		'list'    => rzd_shortcodes_catalog(),
		'api'     => array( 'on' => (int) $s['on'], 'origins' => $s['origins'], 'btn' => $s['btn'] ),
		'rest'    => rest_url( 'rzd/v1/' ),
		'restAlt' => home_url( '/?rest_route=/rzd/v1/' ),
		'js'      => RZD_PLUGIN_URL . 'assets/js/rzd-strona.js',
		'home'    => home_url( '/' ),
		'sets'    => array_map( function ( $id ) {
			return array( 'id' => $id, 'name' => html_entity_decode( get_the_title( $id ), ENT_QUOTES, 'UTF-8' ) );
		}, rzd_site_set_ids() ),
	);
}

function rzd_panel_do_shortcodes() {
	rzd_panel_out( rzd_panel_shortcodes_payload() );
}

function rzd_panel_do_shortcodes_save() {
	$v = rzd_panel_json( 'values' );
	if ( null === $v ) {
		rzd_panel_fail( 'Brak danych.' );
	}
	list( $ok, $m ) = rzd_site_api_save( (array) $v );
	if ( ! $ok ) {
		rzd_panel_fail( $m );
	}
	rzd_panel_out( array_merge( rzd_panel_shortcodes_payload(), array( 'message' => $m ) ) );
}
