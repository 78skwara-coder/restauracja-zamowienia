<?php
/**
 * Moduł 34-panel – sekcja Menu strony (2.45.0): edytor nawigacji strony (moduł 31 – odczyt i zapis menu
 * WordPressa: motyw klasyczny nav_menu + położenia, motyw blokowy wp_navigation + nagłówek). Te same funkcje
 * co dawna strona kokpitu (rzd_nav_read, rzd_nav_save_all, rzd_nav_create, rzd_nav_delete, rzd_nav_use_in_header).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter( 'rzd_panel_actions', function ( $a ) {
	foreach ( array( 'nav', 'nav_search', 'nav_save', 'nav_new', 'nav_delete', 'nav_header' ) as $k ) {
		$a[ $k ] = 'strona';
	}
	return $a;
} );

function rzd_panel_nav_payload( $cur = 0 ) {
	$menus = rzd_nav_menus();
	$block = rzd_nav_block_mode();
	$cur   = (int) $cur;
	if ( ! isset( $menus[ $cur ] ) ) {
		$cur = rzd_nav_default_menu();
	}
	$list = array();
	foreach ( $menus as $id => $name ) {
		$list[] = array( 'id' => (int) $id, 'name' => $name );
	}
	$locs = array();
	if ( ! $block && $cur ) {
		$now = get_nav_menu_locations();
		foreach ( rzd_nav_locations() as $slug => $label ) {
			$other  = ! empty( $now[ $slug ] ) && (int) $now[ $slug ] !== $cur && isset( $menus[ $now[ $slug ] ] ) ? $menus[ $now[ $slug ] ] : '';
			$locs[] = array( 'slug' => $slug, 'label' => $label, 'hint' => rzd_nav_location_hint( $slug ), 'on' => ! empty( $now[ $slug ] ) && (int) $now[ $slug ] === $cur, 'other' => $other );
		}
	}
	$astra = '';
	if ( ! $block ) {
		$all = rzd_nav_locations();
		$now = get_nav_menu_locations();
		if ( isset( $all['primary'], $all['mobile_menu'] ) && empty( $now['mobile_menu'] ) ) {
			$astra = 'Astra na telefonie pokazuje menu z położenia „' . $all['mobile_menu'] . '” – bez niego zamiast menu jest lista wszystkich stron. Zaznacz je razem z nagłówkiem.';
		}
	}
	return array(
		'block'     => $block,
		'theme'     => wp_get_theme()->get( 'Name' ),
		'menus'     => $list,
		'cur'       => $cur,
		'name'      => $cur ? $menus[ $cur ] : '',
		'rows'      => $cur ? rzd_nav_read( $cur ) : array(),
		'quick'     => rzd_nav_quick_items(),
		'locations' => $locs,
		'astra'     => $astra,
		'header'    => $block ? array( 'tpl' => (bool) rzd_nav_header_template(), 'ref' => rzd_nav_header_ref() ) : null,
		'max'       => RZD_NAV_MAX_DEPTH,
		'home'      => home_url( '/' ),
	);
}

function rzd_panel_do_nav() {
	rzd_panel_out( rzd_panel_nav_payload( absint( rzd_panel_str( 'menu' ) ) ) );
}

function rzd_panel_do_nav_search() {
	rzd_panel_out( array( 'groups' => rzd_nav_search_items( rzd_panel_str( 's' ) ) ) );
}

function rzd_panel_do_nav_save() {
	$menu = absint( rzd_panel_str( 'menu' ) );
	$rows = rzd_panel_json( 'rows' );
	$locs = rzd_panel_json( 'locations' );
	$r    = rzd_nav_save_all( $menu, is_array( $rows ) ? $rows : array(), isset( $_POST['locations'] ) ? (array) $locs : null, rzd_panel_str( 'name' ) ); // phpcs:ignore
	if ( is_wp_error( $r ) ) {
		rzd_panel_fail( 'Nie zapisano: ' . $r->get_error_message() );
	}
	rzd_panel_out( array_merge( rzd_panel_nav_payload( $menu ), array( 'message' => 'Zapisano menu – zmiany są już na stronie.' ) ) );
}

function rzd_panel_do_nav_new() {
	$copy = absint( rzd_panel_str( 'copy' ) );
	$name = rzd_panel_str( 'name' );
	$menus = rzd_nav_menus();
	if ( $copy && ! isset( $menus[ $copy ] ) ) {
		$copy = 0;
	}
	if ( $copy && '' === $name ) {
		$name = $menus[ $copy ] . ' (kopia)';
	}
	$id = rzd_nav_create( $name, $copy );
	if ( is_wp_error( $id ) ) {
		rzd_panel_fail( 'Nie utworzono menu: ' . $id->get_error_message() );
	}
	rzd_panel_out( array_merge( rzd_panel_nav_payload( $id ), array( 'message' => $copy ? 'Utworzono kopię menu.' : 'Utworzono menu – dodaj pozycje i zapisz.' ) ) );
}

function rzd_panel_do_nav_delete() {
	$id = absint( rzd_panel_str( 'menu' ) );
	if ( ! isset( rzd_nav_menus()[ $id ] ) || ! rzd_nav_delete( $id ) ) {
		rzd_panel_fail( 'Nie usunięto menu.' );
	}
	rzd_panel_out( array_merge( rzd_panel_nav_payload( 0 ), array( 'message' => 'Usunięto menu.' . ( rzd_nav_block_mode() ? ' (Jest w koszu – WordPress usunie je po 30 dniach.)' : '' ) ) ) );
}

function rzd_panel_do_nav_header() {
	$id = absint( rzd_panel_str( 'menu' ) );
	$r  = isset( rzd_nav_menus()[ $id ] ) ? rzd_nav_use_in_header( $id ) : new WP_Error( 'rzd_nav', 'Nie ma takiej nawigacji.' );
	if ( is_wp_error( $r ) ) {
		rzd_panel_fail( $r->get_error_message() );
	}
	rzd_panel_out( array_merge( rzd_panel_nav_payload( $id ), array( 'message' => 'Nagłówek strony pokazuje teraz to menu.' ) ) );
}
