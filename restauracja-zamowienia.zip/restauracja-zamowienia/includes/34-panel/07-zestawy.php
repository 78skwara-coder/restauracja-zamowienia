<?php
/**
 * Moduł 34-panel – sekcja Zestawy (2.45.0): harmonogram zestawu (terminy: dni tygodnia, zakres
 * dat, konkretna data z „zastępuje”, godziny; dania główne i dodatki opcjonalne, zdjęcie).
 * Zapis rzd_zestaw_save_slots() (moduł 04) w kolejności z bazy (najstarszy termin pierwszy),
 * potem przeliczenie flag dań zestawów i pamięci terminów – jak dawna strona kokpitu.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter( 'rzd_panel_actions', function ( $a ) {
	foreach ( array( 'sets', 'set_get', 'set_save' ) as $k ) {
		$a[ $k ] = 'zestawy';
	}
	return $a;
} );

/** Lista produktów do wyboru (dania i zestawy): id, nazwa, kategorie. */
function rzd_panel_product_list() {
	$out = array();
	foreach ( get_posts( array( 'post_type' => 'product', 'post_status' => array( 'publish', 'private', 'draft' ), 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC' ) ) as $p ) {
		$cats  = wp_get_post_terms( $p->ID, 'product_cat', array( 'fields' => 'names' ) );
		$out[] = array( 'id' => (int) $p->ID, 'name' => $p->post_title, 'cats' => is_wp_error( $cats ) ? '' : implode( ', ', $cats ), 'hidden' => 'publish' !== $p->post_status );
	}
	return $out;
}

function rzd_panel_sets_payload() {
	$sets = array();
	foreach ( function_exists( 'rzd_all_sets' ) ? rzd_all_sets() : array() as $sid ) {
		$p = get_post( $sid );
		if ( ! $p || 'product' !== $p->post_type || 'trash' === $p->post_status ) {
			continue;
		}
		$slots = rzd_zestaw_get_slots( $sid );
		$now   = false;
		foreach ( $slots as $slot ) {
			if ( ! empty( $slot['items'] ) && rzd_zestaw_slot_matches_now( $slot ) ) {
				$now = true;
			}
		}
		$sets[] = array( 'id' => (int) $sid, 'name' => $p->post_title, 'slots' => count( $slots ), 'now' => $now, 'hidden' => 'publish' !== $p->post_status );
	}
	usort( $sets, function ( $a, $b ) { return strcoll( $a['name'], $b['name'] ); } );
	return array(
		'sets'     => $sets,
		'products' => rzd_panel_product_list(),
		'days'     => rzd_zestaw_days_labels(),
		'now'      => wp_date( 'j.m.Y H:i' ),
	);
}

/** Jeden zestaw: terminy w kolejności z bazy + czy termin pasuje teraz. */
function rzd_panel_set_data( $id ) {
	$slots = array();
	foreach ( array_values( rzd_zestaw_get_slots( $id ) ) as $slot ) {
		$items = array();
		foreach ( ( isset( $slot['items'] ) && is_array( $slot['items'] ) ) ? $slot['items'] : array() as $it ) {
			if ( empty( $it['product_id'] ) ) {
				continue;
			}
			$items[] = array( 'product_id' => (int) $it['product_id'], 'name' => get_the_title( $it['product_id'] ), 'type' => ( isset( $it['type'] ) && 'addon' === $it['type'] ) ? 'addon' : 'main', 'photo' => ! empty( $it['photo'] ) );
		}
		$slots[] = array(
			'days'      => array_values( isset( $slot['days'] ) ? (array) $slot['days'] : array() ),
			'date'      => isset( $slot['date'] ) ? (string) $slot['date'] : '',
			'date_from' => isset( $slot['date_from'] ) ? (string) $slot['date_from'] : '',
			'date_to'   => isset( $slot['date_to'] ) ? (string) $slot['date_to'] : '',
			'from'      => isset( $slot['from'] ) ? (string) $slot['from'] : '',
			'to'        => isset( $slot['to'] ) ? (string) $slot['to'] : '',
			'override'  => ! empty( $slot['override'] ),
			'items'     => $items,
			'now'       => $items ? (bool) rzd_zestaw_slot_matches_now( $slot ) : false,
		);
	}
	return array( 'id' => (int) $id, 'name' => get_the_title( $id ), 'slots' => $slots, 'edit' => current_user_can( 'edit_post', $id ) ? get_edit_post_link( $id, 'raw' ) : '' );
}

function rzd_panel_do_sets() {
	rzd_panel_out( rzd_panel_sets_payload() );
}

function rzd_panel_do_set_get() {
	$id = absint( rzd_panel_str( 'id' ) );
	if ( ! $id || 'product' !== get_post_type( $id ) ) {
		rzd_panel_fail( 'Nie ma takiego produktu.' );
	}
	rzd_panel_out( array( 'set' => rzd_panel_set_data( $id ) ) );
}

function rzd_panel_do_set_save() {
	$id    = absint( rzd_panel_str( 'id' ) );
	$slots = rzd_panel_json( 'slots' );
	if ( ! $id || 'product' !== get_post_type( $id ) || null === $slots ) {
		rzd_panel_fail( 'Brak danych do zapisu.' );
	}
	foreach ( $slots as $k => $slot ) {
		foreach ( ( is_array( $slot ) && isset( $slot['items'] ) ) ? (array) $slot['items'] : array() as $j => $it ) {
			$pid = isset( $it['product_id'] ) ? absint( $it['product_id'] ) : 0;
			if ( $pid === $id ) {
				rzd_panel_fail( 'Zestaw nie może zawierać samego siebie.' );
			}
			if ( $pid && 'product' !== get_post_type( $pid ) ) {
				unset( $slots[ $k ]['items'][ $j ] );
			}
		}
	}
	$n = rzd_zestaw_save_slots( $id, $slots, false );
	if ( function_exists( 'rzd_zestaw_rebuild_component_flags' ) ) {
		rzd_zestaw_rebuild_component_flags( $id );
	}
	if ( function_exists( 'rzd_dc_clear_slots_cache' ) ) {
		rzd_dc_clear_slots_cache();
	}
	if ( function_exists( 'wc_delete_product_transients' ) ) {
		wc_delete_product_transients( $id );
	}
	rzd_panel_out( array_merge( rzd_panel_sets_payload(), array( 'set' => rzd_panel_set_data( $id ), 'message' => $n ? 'Zapisano zestaw.' : 'Zapisano – zestaw nie ma już terminów (przestał być zestawem).' ) ) );
}
