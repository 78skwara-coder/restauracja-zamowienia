<?php
/**
 * Moduł 34-panel – Terminy, część 2 (2.45.0): kalendarze grup (kategorii), godziny dostaw
 * w dniach tygodnia (matryca), okna dostaw, stałe dni tygodnia bez dostaw.
 * Zapis funkcjami modułu 06 (rzd_dc_save_group, rzd_dc_delete_group, rzd_dc_save_matrix,
 * rzd_dc_save_windows); odpowiedź = pełne dane sekcji (rzd_panel_terms_payload).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter( 'rzd_panel_actions', function ( $a ) {
	foreach ( array( 'term_group_save', 'term_group_delete', 'term_matrix_save', 'term_windows_save' ) as $k ) {
		$a[ $k ] = 'terminy';
	}
	return $a;
} );

/** Dodatkowe dane sekcji Terminy (dokładane do rzd_panel_terms_payload). */
function rzd_panel_terms_full( $s ) {
	$terms = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false, 'orderby' => 'name' ) );
	$cats  = array();
	foreach ( is_wp_error( $terms ) ? array() : $terms as $t ) {
		$conf = isset( $s['groups'][ $t->term_id ] );
		$g    = $conf ? $s['groups'][ $t->term_id ] : rzd_dc_default_group();
		$cats[] = array(
			'id'     => (int) $t->term_id,
			'name'   => $t->name,
			'parent' => (int) $t->parent,
			'count'  => (int) $t->count,
			'conf'   => $conf,
			'g'      => array(
				'times'       => array_values( (array) $g['times'] ),
				'cutoff'      => (string) $g['cutoff'],
				'cutoff_days' => (int) $g['cutoff_days'],
				'lead'        => (int) $g['lead'],
				'days'        => array_values( (array) $g['days'] ),
				'horizon'     => (int) $g['horizon'],
				'valid_from'  => (string) $g['valid_from'],
				'valid_to'    => (string) $g['valid_to'],
				'blocked'     => array_values( (array) $g['blocked'] ),
			),
			'window' => (object) ( isset( $g['window'] ) && is_array( $g['window'] ) ? $g['window'] : array() ),
		);
	}
	$no_group = array();
	if ( function_exists( 'rzd_dc_products_without_group' ) ) {
		foreach ( rzd_dc_products_without_group() as $pid ) {
			if ( function_exists( 'rzd_product_sell' ) && 'onsite' === rzd_product_sell( $pid ) ) {
				continue; // „tylko na miejscu” (sala) nie potrzebuje kalendarza
			}
			$no_group[] = get_the_title( $pid );
		}
	}
	$wdays = array();
	foreach ( array_keys( rzd_dc_days() ) as $dow ) {
		$d             = ( isset( $s['win_days'][ $dow ] ) && is_array( $s['win_days'][ $dow ] ) ) ? $s['win_days'][ $dow ] : array();
		$wdays[ $dow ] = array(
			'on'    => ! empty( $d['on'] ),
			'start' => isset( $d['start'] ) ? (string) $d['start'] : '',
			'seq'   => array_values( isset( $d['seq'] ) ? (array) $d['seq'] : array() ),
		);
	}
	$defs = array();
	foreach ( ( isset( $s['win_defs'] ) && is_array( $s['win_defs'] ) ) ? $s['win_defs'] : array() as $id => $d ) {
		$defs[] = array( 'id' => (string) $id, 'name' => (string) $d['name'], 'len' => (int) $d['len'], 'cap' => (int) $d['cap'] );
	}
	return array(
		'days'         => rzd_dc_days(),
		'cats'         => $cats,
		'globalWindow' => (object) ( isset( $s['global_window'] ) && is_array( $s['global_window'] ) ? $s['global_window'] : array() ),
		'winOn'        => ! empty( $s['win_on'] ),
		'winDefs'      => $defs,
		'winDays'      => $wdays,
		'noGroup'      => $no_group,
		'townsOk'      => function_exists( 'rzd_towns_enabled' ) ? rzd_towns_enabled() : true,
	);
}

function rzd_panel_terms_out( $message ) {
	rzd_panel_out( array_merge( rzd_panel_terms_payload(), array( 'message' => $message ) ) );
}

function rzd_panel_do_term_group_save() {
	$g = rzd_panel_json( 'g' );
	if ( null === $g ) {
		rzd_panel_fail( 'Brak danych do zapisu.' );
	}
	$r = rzd_dc_save_group( absint( rzd_panel_str( 'term' ) ), $g );
	if ( is_wp_error( $r ) ) {
		rzd_panel_fail( $r->get_error_message() );
	}
	$msg = 'Zapisano kalendarz grupy.';
	if ( empty( $r['times'] ) && ! rzd_dc_windows_on() ) {
		$msg .= ' Uwaga: grupa nie ma godzin wyjazdu – jej produktów nie da się zamówić.';
	} elseif ( empty( $r['days'] ) ) {
		$msg .= ' Uwaga: nie zaznaczono żadnego dnia dostaw.';
	}
	rzd_panel_terms_out( $msg );
}

function rzd_panel_do_term_group_delete() {
	if ( ! rzd_dc_delete_group( absint( rzd_panel_str( 'term' ) ) ) ) {
		rzd_panel_fail( 'Ta kategoria nie ma kalendarza.' );
	}
	rzd_panel_terms_out( 'Usunięto kalendarz grupy.' );
}

function rzd_panel_do_term_matrix_save() {
	$global = rzd_panel_json( 'global' );
	$rows   = rzd_panel_json( 'rows' );
	$off    = rzd_panel_json( 'off' );
	if ( null === $global || null === $rows || null === $off ) {
		rzd_panel_fail( 'Brak danych do zapisu.' );
	}
	rzd_dc_save_matrix( $global, $rows, $off );
	rzd_panel_terms_out( 'Zapisano godziny dostaw w dniach tygodnia.' );
}

function rzd_panel_do_term_windows_save() {
	$defs = rzd_panel_json( 'defs' );
	$days = rzd_panel_json( 'wdays' );
	if ( null === $defs || null === $days ) {
		rzd_panel_fail( 'Brak danych do zapisu.' );
	}
	rzd_dc_save_windows( '1' === rzd_panel_str( 'on' ), $defs, $days );
	rzd_panel_terms_out( 'Zapisano okna dostaw.' );
}
