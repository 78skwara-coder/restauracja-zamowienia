<?php
/**
 * Moduł 34-panel – sekcja „Opisy AI” (2.52.0, moduł 40-opisy-ai): zasady wspólne i kreator pól formularza opisu
 * dania (nazwa, rodzaj, podpowiedź, instrukcja dla AI, nagłówek w opisie, do którego opisu, wymagane, aktywne).
 * Akcje: aidesc, aidesc_save.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter( 'rzd_panel_actions', function ( $a ) {
	$a['aidesc']      = 'opisy';
	$a['aidesc_save'] = 'opisy';
	return $a;
} );

function rzd_panel_aidesc_payload() {
	$s = rzd_aidesc_settings();
	return array(
		'rules'   => $s['rules'],
		'fields'  => $s['fields'],
		'targets' => rzd_aidesc_targets(),
		'ready'   => function_exists( 'rzd_ai_ready' ) && rzd_ai_ready(),
		'canApi'  => rzd_can( 'api' ),
		'defRules' => rzd_aidesc_default_rules(),
		'photo'    => $s['photo'],   // (2.54.0) zasady trybu „AI ze zdjęcia”
		'defPhoto' => rzd_aidesc_default_photo(),
		'web_max'  => $s['web_max'], // 0 = bez wyszukiwania w internecie
	);
}

function rzd_panel_do_aidesc() {
	rzd_panel_out( rzd_panel_aidesc_payload() );
}

function rzd_panel_do_aidesc_save() {
	$v = rzd_panel_json( 'values' );
	if ( null === $v ) {
		rzd_panel_fail( 'Brak danych.' );
	}
	list( $ok, $m ) = rzd_aidesc_save( (array) $v );
	if ( ! $ok ) {
		rzd_panel_fail( $m );
	}
	rzd_panel_out( array_merge( rzd_panel_aidesc_payload(), array( 'message' => $m ) ) );
}
