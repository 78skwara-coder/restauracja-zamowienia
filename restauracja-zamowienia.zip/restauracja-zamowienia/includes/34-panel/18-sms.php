<?php
/**
 * Moduł 34-panel – sekcja „SMS” (2.58.0, moduł 41-sms): Powiadomienia (4 rodzaje: włącz, treść ze zmiennymi,
 * test), Marketing (zgoda w kasie, kampanie, godziny wysyłki), Zgody (lista, szukaj, wycofaj, CSV), Dziennik.
 * Uprawnienie „SMS” (domyślnie Szef i Kierownik sklepu). Token i nadawca – Połączenia API.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter( 'rzd_panel_actions', function ( $a ) {
	foreach ( array( 'sms', 'sms_save', 'sms_test', 'sms_consents', 'sms_consent_withdraw', 'sms_consent_csv', 'sms_campaign_preview', 'sms_campaign_send', 'sms_campaign_cancel', 'sms_log' ) as $k ) {
		$a[ $k ] = 'sms';
	}
	return $a;
} );

function rzd_panel_sms_camps() {
	return array_map( function ( $c ) {
		unset( $c['last_id'] );
		$c['send_label'] = wp_date( 'D j.m, H:i', (int) $c['send_at'] );
		$c['at_label']   = wp_date( 'j.m.Y H:i', (int) $c['at'] );
		return $c;
	}, array_slice( rzd_sms_campaigns(), 0, 20 ) );
}

function rzd_panel_sms_payload() {
	$s   = rzd_sms_settings();
	$api = rzd_api_settings();
	return array(
		'settings'  => $s,
		'events'    => rzd_sms_events(),
		'defaults'  => rzd_sms_default_texts(),
		'orderVars' => rzd_sms_order_vars(),
		'mktVars'   => rzd_sms_mkt_vars(),
		'sample'    => rzd_sms_sample_vars(),
		'shopName'  => html_entity_decode( get_bloginfo( 'name' ), ENT_QUOTES, 'UTF-8' ),
		'ready'     => rzd_sms_ready(),
		'from'      => $api['sms_from'],
		'testMode'  => '1' === $api['sms_test'],
		'canApi'    => rzd_can( 'api' ),
		'consents'  => rzd_sms_consent_count(),
		'camps'     => rzd_panel_sms_camps(),
	);
}

function rzd_panel_do_sms() {
	rzd_panel_out( rzd_panel_sms_payload() );
}

function rzd_panel_do_sms_save() {
	$v = rzd_panel_json( 'values' );
	if ( null === $v ) {
		rzd_panel_fail( 'Brak danych.' );
	}
	list( $ok, $m ) = rzd_sms_save( (array) $v );
	if ( ! $ok ) {
		rzd_panel_fail( $m );
	}
	rzd_panel_out( array_merge( rzd_panel_sms_payload(), array( 'message' => $m ) ) );
}

/** SMS testowy: treść z pola (niezapisana) i przykładowe dane. kind = order|way|ready|staff|mkt|plain. */
function rzd_panel_do_sms_test() {
	$to   = rzd_panel_str( 'to' );
	$kind = rzd_panel_str( 'kind', 'plain' );
	$text = isset( $_POST['text'] ) ? sanitize_textarea_field( wp_unslash( (string) $_POST['text'] ) ) : ''; // phpcs:ignore
	if ( '' === rzd_sms_phone( $to ) ) {
		rzd_panel_fail( 'Wpisz poprawny numer telefonu do testu.' );
	}
	if ( 'mkt' === $kind ) {
		$msg = rzd_sms_campaign_text( $text, 'Anna', 'test' );
	} elseif ( 'plain' === $kind ) {
		$msg = '' !== $text ? $text : rzd_sms_name() . ': test SMS z panelu restauracji.';
	} else {
		$msg = rzd_sms_render( $text, rzd_sms_sample_vars() );
	}
	list( $ok, $r ) = rzd_sms_send( $to, $msg, array( 'kind' => 'test' ) );
	if ( ! $ok ) {
		rzd_panel_fail( $r );
	}
	$test = '1' === rzd_api_settings()['sms_test'];
	rzd_panel_out( array( 'message' => $test ? 'Tryb testowy: SMSAPI przyjęło SMS-a, ale go nie wysłało (bez opłaty).' : 'Wysłano SMS testowy na ' . rzd_sms_mask( rzd_sms_phone( $to ) ) . '.' ) );
}

function rzd_panel_do_sms_consents() {
	$off = max( 0, (int) rzd_panel_str( 'offset', '0' ) );
	list( $rows, $total ) = rzd_sms_consent_list( rzd_panel_str( 'q' ), '1' !== rzd_panel_str( 'all' ), 50, $off );
	$rows = array_map( function ( $r ) {
		return array(
			'id'       => (int) $r['id'],
			'phone'    => $r['phone_masked'],
			'name'     => $r['name'],
			'at'       => mysql2date( 'j.m.Y H:i', $r['consent_at'] ),
			'source'   => $r['source'],
			'order'    => (int) $r['order_id'],
			'withdrawn' => $r['withdrawn_at'] ? mysql2date( 'j.m.Y H:i', $r['withdrawn_at'] ) : '',
		);
	}, $rows );
	rzd_panel_out( array( 'rows' => $rows, 'total' => $total, 'active' => rzd_sms_consent_count() ) );
}

function rzd_panel_do_sms_consent_withdraw() {
	if ( '' === rzd_sms_consent_withdraw( (int) rzd_panel_str( 'id' ) ) ) {
		rzd_panel_fail( 'Nie ma takiej zgody.' );
	}
	rzd_panel_out( array( 'message' => 'Zgoda wycofana – ten numer nie dostanie już SMS-ów marketingowych.', 'active' => rzd_sms_consent_count() ) );
}

/** CSV wszystkich zgód (pełne numery – dowód zgody; tylko uprawnienie SMS). */
function rzd_panel_do_sms_consent_csv() {
	list( $rows ) = rzd_sms_consent_list( '', false, 100000, 0, false );
	$f = fopen( 'php://temp', 'r+' );
	fputcsv( $f, array( 'telefon', 'imie', 'zgoda', 'zrodlo', 'zamowienie', 'ip', 'tresc_zgody', 'wycofana' ), ';' );
	foreach ( $rows as $r ) {
		fputcsv( $f, array( '+' . $r['phone'], $r['name'], $r['consent_at'], $r['source'], $r['order_id'] ? $r['order_id'] : '', $r['ip'], $r['text'], (string) $r['withdrawn_at'] ), ';' );
	}
	rewind( $f );
	$csv = "\xEF\xBB\xBF" . stream_get_contents( $f ); // BOM – Excel czyta polskie litery
	fclose( $f );
	rzd_panel_out( array( 'csv' => $csv, 'file' => 'zgody-sms-' . current_time( 'Y-m-d' ) . '.csv' ) );
}

function rzd_panel_do_sms_campaign_preview() {
	$text = isset( $_POST['text'] ) ? sanitize_textarea_field( wp_unslash( (string) $_POST['text'] ) ) : ''; // phpcs:ignore
	rzd_panel_out( rzd_sms_campaign_preview( $text ) );
}

function rzd_panel_do_sms_campaign_send() {
	$text = isset( $_POST['text'] ) ? sanitize_textarea_field( wp_unslash( (string) $_POST['text'] ) ) : ''; // phpcs:ignore
	$at   = rzd_panel_str( 'at' ); // „2026-11-12T10:00” (czas strony) albo puste = teraz
	$ts   = 0;
	if ( '' !== $at ) {
		$d = date_create_immutable( str_replace( 'T', ' ', $at ), wp_timezone() );
		if ( ! $d ) {
			rzd_panel_fail( 'Nieprawidłowa data wysyłki.' );
		}
		$ts = $d->getTimestamp();
	}
	list( $ok, $c ) = rzd_sms_campaign_create( $text, $ts );
	if ( ! $ok ) {
		rzd_panel_fail( $c );
	}
	$soon = (int) $c['send_at'] <= time() + 60;
	rzd_panel_out( array( 'camps' => rzd_panel_sms_camps(), 'message' => ( $soon ? 'Kampania ruszyła' : 'Kampania zaplanowana na ' . wp_date( 'D j.m, H:i', (int) $c['send_at'] ) ) . ' – ' . $c['total'] . ' odbiorców.' ) );
}

function rzd_panel_do_sms_campaign_cancel() {
	if ( ! rzd_sms_campaign_cancel( (int) rzd_panel_str( 'id' ) ) ) {
		rzd_panel_fail( 'Tej kampanii nie da się już zatrzymać.' );
	}
	rzd_panel_out( array( 'camps' => rzd_panel_sms_camps(), 'message' => 'Kampania zatrzymana.' ) );
}

function rzd_panel_do_sms_log() {
	$kind = rzd_panel_str( 'kind' );
	if ( 'none' === $kind ) { // tylko odświeżenie historii kampanii
		rzd_panel_out( array( 'rows' => array(), 'camps' => rzd_panel_sms_camps() ) );
	}
	$kind = in_array( $kind, array( 'order', 'way', 'ready', 'staff', 'mkt', 'test' ), true ) ? $kind : '';
	$rows = array_map( function ( $r ) {
		return array( 'at' => mysql2date( 'j.m H:i', $r['at'] ), 'phone' => $r['phone'], 'kind' => $r['kind'], 'ref' => (int) $r['ref'], 'parts' => (int) $r['parts'], 'status' => $r['status'], 'err' => $r['err'], 'text' => (string) $r['text'] );
	}, rzd_sms_log_list( $kind, 100, max( 0, (int) rzd_panel_str( 'offset', '0' ) ) ) );
	rzd_panel_out( array( 'rows' => $rows, 'camps' => rzd_panel_sms_camps() ) );
}
