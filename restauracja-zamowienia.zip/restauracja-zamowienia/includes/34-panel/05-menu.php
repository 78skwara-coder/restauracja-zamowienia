<?php
/**
 * Moduł 34-panel – sekcja Menu (2.45.0): Dodatki, Typy dodatków, Opakowania, Etykiety na zestawie
 * (z rolą dań w zestawach) i Wzory modyfikacji (edytor grup – assets/js/rzd-grupy.js).
 * Zapis przez funkcje modułów (rzd_addon_save, rzd_packaging_save, rzd_preset_save,
 * rzd_zestaw_set_role_save) – te same dane co dawne ekrany kokpitu.
 * Usunięcie dodatku / typu / opakowania / etykiety, które są w użyciu, jest blokowane
 * (z listą miejsc) – inaczej modyfikacje dań traciłyby po cichu pozycje.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter( 'rzd_panel_actions', function ( $a ) {
	foreach ( array( 'menu', 'addon_save', 'addon_delete', 'addon_icon', 'type_save', 'type_delete', 'pack_save', 'pack_delete', 'pack_icon', 'label_save', 'label_delete', 'roles_save', 'preset_save', 'preset_dup', 'preset_delete' ) as $k ) {
		$a[ $k ] = 'menu';
	}
	return $a;
} );

/** Grupy modyfikacji w postaci dla edytora (miejsce wyboru zawsze na grupie). */
function rzd_panel_sections_for_editor( $sections ) {
	$out = array();
	foreach ( (array) $sections as $sec ) {
		if ( ! is_array( $sec ) || ! isset( $sec['items'] ) ) {
			continue;
		}
		$items = array();
		foreach ( (array) $sec['items'] as $it ) {
			if ( is_array( $it ) ) {
				unset( $it['place'] );
				$items[] = $it;
			}
		}
		$row = array(
			'header'      => isset( $sec['header'] ) ? (string) $sec['header'] : '',
			'description' => isset( $sec['description'] ) ? (string) $sec['description'] : '',
			'place'       => function_exists( 'rzd_section_place' ) ? rzd_section_place( $sec ) : ( isset( $sec['place'] ) ? $sec['place'] : 'before' ),
			'items'       => $items,
		);
		if ( ! empty( $sec['preset'] ) ) {
			$row['preset'] = (int) $sec['preset'];
		}
		$out[] = $row;
	}
	return $out;
}

/** Słowniki edytora grup (też Edycja menu): dodatki z cenami, role, sposoby wyświetlania. */
function rzd_panel_group_dict() {
	$addons = array();
	foreach ( function_exists( 'rzd_get_all_addons' ) ? rzd_get_all_addons() : array() as $a ) {
		if ( $a ) {
			$addons[] = array( 'id' => (int) $a['id'], 'name' => $a['name'], 'type' => $a['type_name'], 'price' => (float) $a['price'], 'minus' => (float) $a['price_minus'], 'mandatory' => (bool) $a['mandatory'] );
		}
	}
	return array(
		'addons' => $addons,
		'roles'  => array(
			'dodaje'      => 'Dodaje – dolicza cenę dodatku',
			'odejmuje'    => 'Odejmuje – odejmuje cenę „przy odejmowaniu”',
			'neutralna'   => 'Neutralna – bez wpływu na cenę',
			'obowiazkowa' => 'Obowiązkowa – zawsze aktywna',
			'dezaktywuje' => 'Dezaktywuje – „ani jedno, ani drugie” (odejmuje i blokuje inne z tym dodatkiem)',
		),
		'types'  => array(
			'radio'   => 'Pojedynczy wybór (jedno z kilku)',
			'tap'     => 'Przycisk włącz / wyłącz',
			'stepper' => 'Licznik + / −',
			'text'    => 'Pole tekstowe',
			'clone'   => 'Powiel skład (dokładki)',
		),
		'places' => array(
			'before' => 'Przed dodaniem do koszyka',
			'cart'   => 'W przeglądzie zamówienia („Dodatki płatne”)',
		),
	);
}

function rzd_panel_menu_payload() {
	$refs   = function_exists( 'rzd_addon_refs' ) ? rzd_addon_refs() : array();
	$prefs  = function_exists( 'rzd_packaging_refs' ) ? rzd_packaging_refs() : array();
	$addons = array();
	foreach ( function_exists( 'rzd_get_all_addons' ) ? rzd_get_all_addons() : array() as $a ) {
		if ( ! $a ) {
			continue;
		}
		$minus    = get_post_meta( $a['id'], '_rzd_addon_price_minus', true );
		$addons[] = array(
			'id'        => (int) $a['id'],
			'name'      => $a['name'],
			'type'      => (int) $a['type_id'],
			'typeName'  => $a['type_name'],
			'price'     => (float) $a['price'],
			'minus'     => '' === $minus ? '' : (float) $minus,
			'mandatory' => (bool) $a['mandatory'],
			'pack'      => (int) $a['packaging'],
			'cap'       => (int) $a['pack_capacity'],
			'icon'      => (string) get_the_post_thumbnail_url( $a['id'], 'thumbnail' ),
			'used'      => isset( $refs[ $a['id'] ] ) ? $refs[ $a['id'] ] : array(),
		);
	}
	$types = array();
	foreach ( function_exists( 'rzd_get_all_addon_types' ) ? rzd_get_all_addon_types() : array() as $t ) {
		$n = 0;
		foreach ( $addons as $a ) {
			$n += ( $a['type'] === (int) $t->term_id ) ? 1 : 0;
		}
		$types[] = array( 'id' => (int) $t->term_id, 'name' => $t->name, 'count' => $n );
	}
	$packs = array();
	foreach ( function_exists( 'rzd_packaging_all' ) ? rzd_packaging_all() : array() as $p ) {
		$u       = isset( $prefs[ $p->ID ] ) ? $prefs[ $p->ID ] : array();
		$packs[] = array(
			'id'    => (int) $p->ID,
			'name'  => $p->post_title,
			'price' => (float) get_post_meta( $p->ID, '_rzd_pack_price', true ),
			'icon'  => (string) get_the_post_thumbnail_url( $p->ID, 'thumbnail' ),
			'used'  => array(
				'cats'     => isset( $u['cats'] ) ? $u['cats'] : array(),
				'products' => isset( $u['products'] ) ? $u['products'] : array(),
				'addons'   => isset( $u['addons'] ) ? $u['addons'] : array(),
			),
		);
	}
	$labels = array();
	$lt     = get_terms( array( 'taxonomy' => 'rzd_set_label', 'hide_empty' => false ) );
	foreach ( is_wp_error( $lt ) ? array() : $lt as $t ) {
		$labels[] = array( 'id' => (int) $t->term_id, 'name' => $t->name, 'count' => (int) $t->count );
	}
	// dania w zestawach (i dania z etykietą) – etykieta i kolejność to cecha DANIA
	$ids = array();
	foreach ( function_exists( 'rzd_all_sets' ) ? rzd_all_sets() : array() as $sid ) {
		foreach ( rzd_zestaw_get_slots( $sid ) as $slot ) {
			foreach ( ( isset( $slot['items'] ) && is_array( $slot['items'] ) ) ? $slot['items'] : array() as $it ) {
				if ( ! empty( $it['product_id'] ) && ( ! isset( $it['type'] ) || 'addon' !== $it['type'] ) ) {
					$ids[ (int) $it['product_id'] ] = true;
				}
			}
		}
	}
	$labeled = get_posts( array( 'post_type' => 'product', 'post_status' => 'any', 'numberposts' => -1, 'fields' => 'ids', 'tax_query' => array( array( 'taxonomy' => 'rzd_set_label', 'operator' => 'EXISTS' ) ) ) ); // phpcs:ignore
	foreach ( $labeled as $pid ) {
		$ids[ (int) $pid ] = true;
	}
	$roles = array();
	foreach ( array_keys( $ids ) as $pid ) {
		if ( 'product' !== get_post_type( $pid ) || 'trash' === get_post_status( $pid ) ) {
			continue;
		}
		$t       = wp_get_object_terms( $pid, 'rzd_set_label', array( 'fields' => 'ids' ) );
		$o       = get_post_meta( $pid, '_rwz_set_order', true );
		$roles[] = array( 'id' => (int) $pid, 'name' => get_the_title( $pid ), 'label' => ( ! is_wp_error( $t ) && $t ) ? (int) $t[0] : 0, 'order' => '' === $o ? '' : (int) $o, 'isSet' => rzd_zestaw_get_slots( $pid ) ? true : false );
	}
	usort( $roles, function ( $a, $b ) {
		$x = '' === $a['order'] ? 9999 : $a['order'];
		$y = '' === $b['order'] ? 9999 : $b['order'];
		return $x === $y ? strcoll( $a['name'], $b['name'] ) : $x - $y;
	} );
	// wzory + w ilu daniach są ich kopie
	$copies = array();
	global $wpdb;
	foreach ( (array) $wpdb->get_results( "SELECT pm.meta_value, p.post_title FROM {$wpdb->postmeta} pm JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE pm.meta_key = '_rzd_modifiers' AND p.post_type = 'product' AND p.post_status NOT IN ('trash','auto-draft')" ) as $r ) { // phpcs:ignore
		foreach ( (array) maybe_unserialize( $r->meta_value ) as $sec ) {
			if ( is_array( $sec ) && ! empty( $sec['preset'] ) ) {
				$copies[ (int) $sec['preset'] ][ $r->post_title ] = true;
			}
		}
	}
	$presets = array();
	foreach ( get_posts( array( 'post_type' => 'rzd_mod_preset', 'post_status' => array( 'publish', 'draft', 'private' ), 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC' ) ) as $p ) {
		$presets[] = array(
			'id'       => (int) $p->ID,
			'title'    => '' !== $p->post_title ? $p->post_title : 'Wzór #' . $p->ID,
			'active'   => 'publish' === $p->post_status,
			'sections' => rzd_panel_sections_for_editor( rzd_get_preset_sections( $p->ID ) ),
			'copies'   => isset( $copies[ $p->ID ] ) ? array_keys( $copies[ $p->ID ] ) : array(),
		);
	}
	return array(
		'addons'    => $addons,
		'types'     => $types,
		'packs'     => $packs,
		'labels'    => $labels,
		'roles'     => $roles,
		'presets'   => $presets,
		'dict'      => rzd_panel_group_dict(),
		'canUpload' => current_user_can( 'upload_files' ),
	);
}

function rzd_panel_menu_out( $message = '', $extra = array() ) {
	rzd_panel_out( array_merge( rzd_panel_menu_payload(), array( 'message' => $message ), $extra ) );
}

function rzd_panel_do_menu() {
	rzd_panel_menu_out();
}

/* ---------- Dodatki ---------- */
function rzd_panel_do_addon_save() {
	$in = rzd_panel_json( 'item' );
	if ( null === $in ) {
		rzd_panel_fail( 'Brak danych do zapisu.' );
	}
	$id = rzd_addon_save( isset( $in['id'] ) ? $in['id'] : 0, $in );
	if ( is_wp_error( $id ) ) {
		rzd_panel_fail( $id->get_error_message() );
	}
	rzd_panel_menu_out( 'Zapisano dodatek.', array( 'savedId' => $id ) );
}

function rzd_panel_do_addon_delete() {
	$id = absint( rzd_panel_str( 'id' ) );
	if ( ! $id || 'rzd_addon' !== get_post_type( $id ) ) {
		rzd_panel_fail( 'Nie ma takiego dodatku.' );
	}
	$refs = rzd_addon_refs();
	if ( ! empty( $refs[ $id ] ) ) {
		rzd_panel_fail( 'Tego dodatku nie można usunąć – jest używany: ' . implode( ', ', array_slice( $refs[ $id ], 0, 12 ) ) . ( count( $refs[ $id ] ) > 12 ? ' …' : '' ) . '. Najpierw usuń go z tych dań i wzorów.' );
	}
	wp_trash_post( $id ); // kosz – da się przywrócić w WordPressie
	rzd_panel_menu_out( 'Usunięto dodatek.' );
}

/** Ikonka (obraz wyróżniający) dodatku albo opakowania: plik w polu „file”, remove=1 – usunięcie. */
function rzd_panel_set_icon( $post_type ) {
	$id = absint( rzd_panel_str( 'id' ) );
	if ( ! $id || get_post_type( $id ) !== $post_type ) {
		rzd_panel_fail( 'Nie ma takiej pozycji.' );
	}
	if ( '1' === rzd_panel_str( 'remove' ) ) {
		delete_post_thumbnail( $id );
		return;
	}
	if ( ! current_user_can( 'upload_files' ) ) {
		rzd_panel_fail( 'To konto nie może wgrywać plików.', 403 );
	}
	if ( empty( $_FILES['file'] ) || ! empty( $_FILES['file']['error'] ) || (int) $_FILES['file']['size'] > 5 * MB_IN_BYTES ) { // phpcs:ignore
		rzd_panel_fail( 'Plik nie dotarł albo jest za duży (max 5 MB).' );
	}
	$mimes = array( 'jpg|jpeg|jpe' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp', 'gif' => 'image/gif' );
	$chk   = wp_check_filetype_and_ext( $_FILES['file']['tmp_name'], $_FILES['file']['name'], $mimes ); // phpcs:ignore
	if ( empty( $chk['type'] ) ) {
		rzd_panel_fail( 'To nie jest obrazek (JPG, PNG, WebP, GIF).' );
	}
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	$att = media_handle_upload( 'file', $id, array( 'post_title' => get_the_title( $id ) ), array( 'test_form' => false, 'mimes' => $mimes ) );
	if ( is_wp_error( $att ) ) {
		rzd_panel_fail( 'Nie udało się zapisać obrazka: ' . $att->get_error_message() );
	}
	set_post_thumbnail( $id, $att );
}

function rzd_panel_do_addon_icon() {
	rzd_panel_set_icon( 'rzd_addon' );
	rzd_panel_menu_out( 'Zapisano ikonkę.' );
}

/* ---------- Typy dodatków ---------- */
function rzd_panel_term_save( $tax, $what ) {
	$id   = absint( rzd_panel_str( 'id' ) );
	$name = trim( rzd_panel_str( 'name' ) );
	if ( '' === $name ) {
		rzd_panel_fail( 'Podaj nazwę.' );
	}
	$r = $id ? wp_update_term( $id, $tax, array( 'name' => $name ) ) : wp_insert_term( $name, $tax );
	if ( is_wp_error( $r ) ) {
		rzd_panel_fail( 'term_exists' === $r->get_error_code() ? 'Taki ' . $what . ' już jest.' : $r->get_error_message() );
	}
}

function rzd_panel_do_type_save() {
	rzd_panel_term_save( 'rzd_addon_type', 'typ' );
	rzd_panel_menu_out( 'Zapisano typ.' );
}

function rzd_panel_do_type_delete() {
	$id = absint( rzd_panel_str( 'id' ) );
	$t  = get_term( $id, 'rzd_addon_type' );
	if ( ! $t || is_wp_error( $t ) ) {
		rzd_panel_fail( 'Nie ma takiego typu.' );
	}
	$used = get_posts( array( 'post_type' => array( 'rzd_addon' ), 'post_status' => 'publish', 'numberposts' => 12, 'tax_query' => array( array( 'taxonomy' => 'rzd_addon_type', 'terms' => $id ) ) ) ); // phpcs:ignore
	if ( $used ) {
		rzd_panel_fail( 'Tego typu nie można usunąć – mają go dodatki: ' . implode( ', ', wp_list_pluck( $used, 'post_title' ) ) . '. Najpierw zmień im typ.' );
	}
	wp_delete_term( $id, 'rzd_addon_type' );
	rzd_panel_menu_out( 'Usunięto typ.' );
}

/* ---------- Opakowania ---------- */
function rzd_panel_do_pack_save() {
	$in = rzd_panel_json( 'item' );
	if ( null === $in ) {
		rzd_panel_fail( 'Brak danych do zapisu.' );
	}
	$id = rzd_packaging_save( isset( $in['id'] ) ? $in['id'] : 0, $in );
	if ( is_wp_error( $id ) ) {
		rzd_panel_fail( $id->get_error_message() );
	}
	rzd_panel_menu_out( 'Zapisano opakowanie.', array( 'savedId' => $id ) );
}

function rzd_panel_do_pack_delete() {
	$id = absint( rzd_panel_str( 'id' ) );
	if ( ! $id || 'rzd_packaging' !== get_post_type( $id ) ) {
		rzd_panel_fail( 'Nie ma takiego opakowania.' );
	}
	$r = rzd_packaging_refs();
	if ( ! empty( $r[ $id ] ) ) {
		$names = array_merge( isset( $r[ $id ]['cats'] ) ? $r[ $id ]['cats'] : array(), isset( $r[ $id ]['products'] ) ? $r[ $id ]['products'] : array(), isset( $r[ $id ]['addons'] ) ? $r[ $id ]['addons'] : array() );
		rzd_panel_fail( 'Tego opakowania nie można usunąć – jest przypięte: ' . implode( ', ', array_slice( $names, 0, 12 ) ) . '. Najpierw je odepnij (kategoria: Edycja menu → Kategorie; danie: edycja produktu; dodatek: tu, w Dodatkach).' );
	}
	wp_trash_post( $id );
	rzd_panel_menu_out( 'Usunięto opakowanie.' );
}

function rzd_panel_do_pack_icon() {
	rzd_panel_set_icon( 'rzd_packaging' );
	rzd_panel_menu_out( 'Zapisano ikonę.' );
}

/* ---------- Etykiety na zestawie i rola dań ---------- */
function rzd_panel_do_label_save() {
	rzd_panel_term_save( 'rzd_set_label', 'etykieta' );
	rzd_panel_menu_out( 'Zapisano etykietę.' );
}

function rzd_panel_do_label_delete() {
	$id = absint( rzd_panel_str( 'id' ) );
	$t  = get_term( $id, 'rzd_set_label' );
	if ( ! $t || is_wp_error( $t ) ) {
		rzd_panel_fail( 'Nie ma takiej etykiety.' );
	}
	if ( (int) $t->count > 0 ) {
		rzd_panel_fail( 'Tej etykiety nie można usunąć – mają ją dania (' . (int) $t->count . '). Najpierw zmień im etykietę niżej.' );
	}
	wp_delete_term( $id, 'rzd_set_label' );
	rzd_panel_menu_out( 'Usunięto etykietę.' );
}

function rzd_panel_do_roles_save() {
	$rows = rzd_panel_json( 'rows' );
	if ( null === $rows ) {
		rzd_panel_fail( 'Brak danych do zapisu.' );
	}
	foreach ( $rows as $r ) {
		$pid = isset( $r['id'] ) ? absint( $r['id'] ) : 0;
		if ( $pid && 'product' === get_post_type( $pid ) && current_user_can( 'edit_post', $pid ) ) {
			rzd_zestaw_set_role_save( $pid, isset( $r['label'] ) ? $r['label'] : 0, isset( $r['order'] ) ? $r['order'] : '' );
		}
	}
	if ( function_exists( 'rzd_dc_clear_slots_cache' ) ) {
		rzd_dc_clear_slots_cache();
	}
	rzd_panel_menu_out( 'Zapisano etykiety i kolejność dań.' );
}

/* ---------- Wzory modyfikacji ---------- */
function rzd_panel_do_preset_save() {
	$in = rzd_panel_json( 'item' );
	if ( null === $in ) {
		rzd_panel_fail( 'Brak danych do zapisu.' );
	}
	$id = rzd_preset_save( isset( $in['id'] ) ? $in['id'] : 0, isset( $in['title'] ) ? $in['title'] : '', ! empty( $in['active'] ), isset( $in['sections'] ) ? $in['sections'] : array() );
	if ( is_wp_error( $id ) ) {
		rzd_panel_fail( $id->get_error_message() );
	}
	$n   = count( rzd_get_preset_sections( $id ) );
	$msg = 'Zapisano wzór.' . ( $n ? '' : ' Wzór nie ma żadnej grupy z modyfikacjami – nie pojawi się na liście do wstawienia.' );
	rzd_panel_menu_out( $msg, array( 'savedId' => $id ) );
}

function rzd_panel_do_preset_dup() {
	$id = absint( rzd_panel_str( 'id' ) );
	if ( ! $id || 'rzd_mod_preset' !== get_post_type( $id ) ) {
		rzd_panel_fail( 'Nie ma takiego wzoru.' );
	}
	$new = rzd_duplicate_preset( $id );
	if ( ! $new ) {
		rzd_panel_fail( 'Nie udało się zrobić kopii.' );
	}
	rzd_panel_menu_out( 'Zrobiono kopię wzoru (nieaktywna – włącz ją po poprawkach).', array( 'savedId' => $new ) );
}

function rzd_panel_do_preset_delete() {
	$id = absint( rzd_panel_str( 'id' ) );
	if ( ! $id || 'rzd_mod_preset' !== get_post_type( $id ) ) {
		rzd_panel_fail( 'Nie ma takiego wzoru.' );
	}
	wp_trash_post( $id ); // dania mają KOPIE grup – zostają bez zmian
	rzd_panel_menu_out( 'Usunięto wzór. Dania, do których go wstawiono, mają kopie grup – nic się w nich nie zmienia.' );
}
