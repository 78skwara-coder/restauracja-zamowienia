<?php
/**
 * Moduł 34-panel – sekcja Wygląd (2.45.0): „Wygląd listy” (moduł 15) – te same pola (rzd_list_style_fields),
 * zakładki Komputer / Telefon („Na telefonie inaczej” w sekcji), zapis rzd_list_style_save() do opcji
 * rzd_list_style. Podgląd NA ŻYWO: wartości z ekranu → rzd_list_style_preview() (dokument do <iframe>
 * o szerokości urządzenia, więc @media działają naprawdę) – bez zapisu.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter( 'rzd_panel_actions', function ( $a ) {
	foreach ( array( 'style', 'style_save', 'style_preview' ) as $k ) {
		$a[ $k ] = 'wyglad';
	}
	return $a;
} );

function rzd_panel_style_payload() {
	$secs = array();
	foreach ( rzd_list_style_fields() as $sid => $sec ) {
		$fields = array();
		foreach ( $sec[1] as $f ) {
			$fields[] = array_intersect_key( $f, array_flip( array( 't', 'k', 'l', 'o', 'u', 'step', 'toggle', 'shared' ) ) );
		}
		$secs[] = array(
			'id'     => $sid,
			'title'  => $sec[0],
			'mobile' => ! ( isset( $sec[2] ) && false === $sec[2] ) && (bool) rzd_style_section_keys( $sec[1] ),
			'fields' => $fields,
		);
	}
	$s = rzd_list_style_get( true );
	return array(
		'sections' => $secs,
		'values'   => $s,
		'bp'       => RZD_STYLE_BREAKPOINT,
		'preview'  => rzd_style_preview_doc( $s ),
	);
}

function rzd_panel_do_style() {
	rzd_panel_out( rzd_panel_style_payload() );
}

function rzd_panel_do_style_save() {
	$v = rzd_panel_json( 'values' );
	if ( null === $v ) {
		rzd_panel_fail( 'Brak danych do zapisu.' );
	}
	rzd_list_style_save( $v );
	rzd_panel_out( array_merge( rzd_panel_style_payload(), array( 'message' => 'Zapisano wygląd – sklep pokazuje go od razu.' ) ) );
}

function rzd_panel_do_style_preview() {
	$v = rzd_panel_json( 'values' );
	if ( null === $v ) {
		rzd_panel_fail( 'Brak danych podglądu.' );
	}
	rzd_panel_out( array( 'preview' => rzd_list_style_preview( $v ) ) );
}
