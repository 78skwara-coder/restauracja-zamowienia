<?php
/**
 * Moduł 34-panel – sekcja Formularze (2.45.0): formularze kontaktowe (moduł 30) – lista z shortcode'ami,
 * kreator (pola, wygląd, własny CSS, maile, po wysłaniu, RODO) z podglądem na żywo, wspólny CSS,
 * ochrona przed spamem i przechowywanie (tylko Administrator). Uprawnienie: „Formularze kontaktowe”.
 * Zapis: rzd_kf_form_new / rzd_kf_form_save / rzd_kf_form_delete / rzd_kf_css_save / rzd_kf_settings_save.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter( 'rzd_panel_actions', function ( $a ) {
	foreach ( array( 'forms', 'form_get', 'form_save', 'form_new', 'form_delete', 'form_preview', 'forms_css', 'forms_protect' ) as $k ) {
		$a[ $k ] = 'formularze';
	}
	return $a;
} );

function rzd_panel_forms_payload() {
	$counts = rzd_kf_counts_by_form();
	$styles = rzd_kf_styles();
	$list   = array();
	foreach ( rzd_kf_forms() as $id => $f ) {
		$list[] = array(
			'id'     => $id,
			'title'  => $f['title'],
			'style'  => isset( $styles[ $f['style'] ] ) ? $styles[ $f['style'] ]['label'] : $f['style'],
			'fields' => count( array_filter( $f['fields'], function ( $x ) {
				return 'heading' !== $x['type'];
			} ) ),
			'msgs'   => isset( $counts[ $id ] ) ? (int) $counts[ $id ] : 0,
			'sc'     => '[rzd_kontakt id="' . $id . '"]',
		);
	}
	$s     = rzd_kf_settings();
	$admin = current_user_can( 'manage_options' );
	return array(
		'forms'   => $list,
		'styles'  => $styles,
		'css'     => $s['css'],
		'admin'   => $admin,
		'protect' => $admin ? array(
			'rate'      => (int) $s['rate'],
			'keep'      => (int) $s['keep'],
			'captcha'   => $s['captcha'],
			'site_key'  => $s['site_key'],
			'hasSecret' => '' !== rzd_mail_decrypt( $s['secret'] ),
			'spam'      => (int) $s['spam_count'],
			'min'       => defined( 'RZD_KF_MIN_SECONDS' ) ? (int) RZD_KF_MIN_SECONDS : 3,
			'on'        => rzd_kf_captcha_on(),
		) : null,
	);
}

/** Formularz do kreatora: opcje pól jako tekst (linia = opcja), strony do „przejście na stronę”. */
function rzd_panel_form_data( $f ) {
	$f['fields'] = array_map( function ( $x ) {
		$x['options'] = implode( "\n", (array) $x['options'] );
		return $x;
	}, $f['fields'] );
	return $f;
}

function rzd_panel_form_extras() {
	$pages = array( array( 'id' => 0, 'title' => '– zostań na stronie, pokaż komunikat –' ) );
	foreach ( get_pages( array( 'post_status' => 'publish', 'sort_column' => 'menu_order,post_title' ) ) as $p ) {
		$pages[] = array( 'id' => (int) $p->ID, 'title' => $p->post_title );
	}
	return array(
		'types'  => rzd_kf_field_types(),
		'styles' => rzd_kf_styles(),
		'pages'  => $pages,
		'admin'  => get_option( 'admin_email' ),
	);
}

function rzd_panel_do_forms() {
	rzd_panel_out( rzd_panel_forms_payload() );
}

function rzd_panel_form_or_fail( $id ) {
	$f = rzd_kf_form( $id );
	if ( ! $f ) {
		rzd_panel_fail( 'Nie ma takiego formularza.' );
	}
	return $f;
}

function rzd_panel_do_form_get() {
	$f = rzd_panel_form_or_fail( sanitize_key( rzd_panel_str( 'id' ) ) );
	rzd_panel_out( array( 'form' => rzd_panel_form_data( $f ), 'preview' => rzd_kf_preview_doc( $f ) ) + rzd_panel_form_extras() );
}

function rzd_panel_do_form_save() {
	$id = sanitize_key( rzd_panel_str( 'id' ) );
	$in = rzd_panel_json( 'form' );
	if ( null === $in ) {
		rzd_panel_fail( 'Brak danych do zapisu.' );
	}
	$f = rzd_kf_form_save( $id, $in );
	if ( is_wp_error( $f ) ) {
		rzd_panel_fail( 'Nie zapisano: ' . $f->get_error_message() );
	}
	rzd_panel_out( array( 'form' => rzd_panel_form_data( $f ), 'preview' => rzd_kf_preview_doc( $f ), 'message' => 'Zapisano formularz „' . $f['title'] . '”.' ) + rzd_panel_form_extras() + array( 'list' => rzd_panel_forms_payload() ) );
}

function rzd_panel_do_form_new() {
	$id = rzd_kf_form_new( rzd_panel_str( 'from' ) );
	rzd_panel_out( array_merge( rzd_panel_forms_payload(), array( 'id' => $id, 'message' => 'Utworzono formularz – ustaw pola i zapisz.' ) ) );
}

function rzd_panel_do_form_delete() {
	$t = rzd_kf_form_delete( sanitize_key( rzd_panel_str( 'id' ) ) );
	if ( '' === $t ) {
		rzd_panel_fail( 'Nie ma takiego formularza.' );
	}
	rzd_panel_out( array_merge( rzd_panel_forms_payload(), array( 'message' => 'Usunięto formularz „' . $t . '”. Wiadomości z niego zostają; shortcode z nim przestaje się wyświetlać.' ) ) );
}

/** Podgląd niezapisanego formularza (kreator – na żywo). */
function rzd_panel_do_form_preview() {
	$id = sanitize_key( rzd_panel_str( 'id' ) );
	$in = rzd_panel_json( 'form' );
	$f  = rzd_kf_sanitize_form( is_array( $in ) ? $in : array(), '' !== $id ? $id : 'podglad' );
	if ( is_wp_error( $f ) ) {
		rzd_panel_fail( $f->get_error_message() );
	}
	rzd_panel_out( array( 'preview' => rzd_kf_preview_doc( $f ) ) );
}

function rzd_panel_do_forms_css() {
	rzd_kf_css_save( isset( $_POST['css'] ) ? wp_unslash( (string) $_POST['css'] ) : '' ); // phpcs:ignore -- czyszczone w rzd_kf_sanitize_css
	rzd_panel_out( array_merge( rzd_panel_forms_payload(), array( 'message' => 'Zapisano wspólny CSS formularzy.' ) ) );
}

function rzd_panel_do_forms_protect() {
	if ( ! current_user_can( 'manage_options' ) ) {
		rzd_panel_fail( 'Ochronę przed spamem zmienia tylko Administrator.', 403 );
	}
	$p = rzd_panel_json( 'protect' );
	if ( null === $p ) {
		rzd_panel_fail( 'Brak danych do zapisu.' );
	}
	$s = rzd_kf_settings_save( $p );
	rzd_panel_out( array_merge( rzd_panel_forms_payload(), array( 'message' => 'Zapisano ochronę i przechowywanie.' . ( $s['captcha'] && ! rzd_kf_captcha_on() ? ' Uwaga: captcha nie działa, dopóki nie podasz obu kluczy.' : '' ) ) ) );
}
