<?php
/**
 * Moduł 34-panel – sekcja Zespół (2.45.0): konta pracowników (zakładanie, rola, hasło, wyłączenie,
 * usunięcie), uprawnienia ról (konfigurator – moduł 26, model – moduł 25) i awaryjny PIN kuriera.
 * Uprawnienie: „Uprawnienia i konta pracowników” (Administrator – zawsze). Konta Administratora
 * zmienia tylko Administrator (map_meta_cap, moduł 25).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter( 'rzd_panel_actions', function ( $a ) {
	foreach ( array( 'team', 'team_roles', 'role_add', 'role_delete', 'pin_save', 'user_save', 'user_toggle', 'user_delete', 'user_reset' ) as $k ) {
		$a[ $k ] = 'zespol';
	}
	return $a;
} );

function rzd_panel_team_payload() {
	$cfg    = rzd_roles_cfg();
	$counts = rzd_roles_user_counts();
	$cat    = array();
	foreach ( rzd_perm_catalog() as $k => $p ) {
		$cat[] = array( 'key' => $k, 'name' => $p[0], 'desc' => $p[2], 'needsShop' => (bool) $p[3] );
	}
	$roles = array();
	foreach ( $cfg['roles'] as $slug => $r ) {
		$roles[] = array(
			'slug'     => $slug,
			'name'     => (string) $r['name'],
			'builtin'  => ! empty( $r['builtin'] ),
			'perms'    => rzd_perms_normalize( $r['perms'] ),
			'histDays' => isset( $r['hist_days'] ) && '' !== $r['hist_days'] ? (int) $r['hist_days'] : '',
			'users'    => isset( $counts[ $slug ] ) ? (int) $counts[ $slug ] : 0,
		);
	}
	$since = ! empty( $cfg['pin']['on'] ) && $cfg['pin']['since'] ? mysql2date( 'j.m.Y', $cfg['pin']['since'] ) : '';
	return array(
		'catalog'   => $cat,
		'roles'     => $roles,
		'admins'    => isset( $counts['administrator'] ) ? (int) $counts['administrator'] : 0,
		'histMax'   => rzd_history_days_max(),
		'users'     => rzd_staff_users(),
		'assign'    => rzd_staff_roles(),
		'canCreate' => current_user_can( 'create_users' ),
		'isAdmin'   => current_user_can( 'manage_options' ),
		'pin'       => array( 'on' => ! empty( $cfg['pin']['on'] ), 'pin' => (string) get_option( 'kurier_pin', '' ), 'since' => $since ),
		'login'     => wp_login_url(),
	);
}

function rzd_panel_team_out( $msg, $extra = array() ) {
	rzd_panel_out( array_merge( rzd_panel_team_payload(), array( 'message' => $msg ), $extra ) );
}

function rzd_panel_do_team() {
	rzd_panel_out( rzd_panel_team_payload() );
}

function rzd_panel_do_team_roles() {
	$in = rzd_panel_json( 'roles' );
	if ( null === $in ) {
		rzd_panel_fail( 'Brak danych do zapisu.' );
	}
	$warn = rzd_roles_save_table( $in );
	rzd_panel_team_out( '' !== $warn ? $warn : 'Zapisano uprawnienia – działają od razu dla wszystkich kont z tymi rolami.', array( 'warn' => '' !== $warn ) );
}

function rzd_panel_do_role_add() {
	$r = rzd_roles_add( rzd_panel_str( 'name' ), rzd_panel_str( 'base' ) );
	if ( is_wp_error( $r ) ) {
		rzd_panel_fail( $r->get_error_message() );
	}
	rzd_panel_team_out( 'Dodano rolę – ustaw jej uprawnienia w tabeli i zapisz.', array( 'added' => $r ) );
}

function rzd_panel_do_role_delete() {
	$r = rzd_roles_delete( rzd_panel_str( 'slug' ) );
	if ( is_wp_error( $r ) ) {
		rzd_panel_fail( $r->get_error_message() );
	}
	rzd_panel_team_out( 'Usunięto rolę.' );
}

function rzd_panel_do_pin_save() {
	$r = rzd_courier_pin_save( '1' === rzd_panel_str( 'on' ), rzd_panel_str( 'pin' ) );
	if ( is_wp_error( $r ) ) {
		rzd_panel_fail( $r->get_error_message() );
	}
	rzd_panel_team_out( 'Zapisano awaryjny PIN kuriera.' );
}

function rzd_panel_do_user_save() {
	$in = rzd_panel_json( 'user' );
	if ( null === $in ) {
		rzd_panel_fail( 'Brak danych do zapisu.' );
	}
	$id = absint( rzd_panel_str( 'id' ) );
	$r  = rzd_staff_user_save( $id, $in );
	if ( is_wp_error( $r ) ) {
		rzd_panel_fail( $r->get_error_message() );
	}
	rzd_panel_team_out( $id ? 'Zapisano konto.' : 'Założono konto.', array( 'newPass' => $r[1], 'userId' => $r[0] ) );
}

function rzd_panel_do_user_toggle() {
	$on = '1' === rzd_panel_str( 'enable' );
	$r  = rzd_staff_user_toggle( absint( rzd_panel_str( 'id' ) ), $on );
	if ( is_wp_error( $r ) ) {
		rzd_panel_fail( $r->get_error_message() );
	}
	rzd_panel_team_out( $on ? 'Konto włączone.' : 'Konto wyłączone – wylogowane ze wszystkich urządzeń.' );
}

function rzd_panel_do_user_delete() {
	$r = rzd_staff_user_delete( absint( rzd_panel_str( 'id' ) ) );
	if ( is_wp_error( $r ) ) {
		rzd_panel_fail( $r->get_error_message() );
	}
	rzd_panel_team_out( 'Usunięto konto.' );
}

function rzd_panel_do_user_reset() {
	$r = rzd_staff_user_reset_link( absint( rzd_panel_str( 'id' ) ) );
	if ( is_wp_error( $r ) ) {
		rzd_panel_fail( $r->get_error_message() );
	}
	rzd_panel_team_out( 'Wysłano link do ustawienia hasła.' );
}
