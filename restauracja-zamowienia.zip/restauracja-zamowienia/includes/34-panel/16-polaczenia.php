<?php
/**
 * Moduł 34-panel – sekcja „Połączenia API” (2.51.0, moduł 39-api). Gemini (klucz, model, Test AI, ostatnie
 * zapytanie) i Facebook (ID strony, token, Sprawdź połączenie) – przeniesione z Post dnia → Ustawienia; kafelki
 * pozostałych integracji (Poczta – Stan i poczta, tylko Administrator; ochrona formularzy). Akcje: api, api_save,
 * api_models, api_fb_check, api_ai_test. Klucze nie wracają do przeglądarki (pole puste + „zapisany”).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter( 'rzd_panel_actions', function ( $a ) {
	foreach ( array( 'api', 'api_save', 'api_models', 'api_fb_check', 'api_ai_test' ) as $k ) {
		$a[ $k ] = 'polaczenia';
	}
	return $a;
} );

function rzd_panel_api_payload() {
	$s     = rzd_api_settings();
	$admin = current_user_can( 'manage_options' );
	$mail  = function_exists( 'rzd_mail_settings' ) ? rzd_mail_settings() : array();
	return array(
		'values'   => array( 'gemini_key' => '', 'model' => $s['model'], 'fb_page' => $s['fb_page'], 'fb_token' => '' ),
		'hasKey'   => '' !== rzd_api_secret( 'gemini_key' ),
		'hasToken' => '' !== rzd_api_secret( 'fb_token' ),
		'keyConst' => defined( 'RZD_GEMINI_KEY' ),
		'tokConst' => defined( 'RZD_FB_TOKEN' ),
		'status'   => rzd_api_status(),
		'lastCall' => function_exists( 'rzd_panel_posts_last_call' ) ? rzd_panel_posts_last_call() : '',
		'others'   => array(
			array( 'n' => 'Poczta (SMTP / API)', 'd' => 'Wysyłka maili sklepu – połączenie główne i zapasowe, dziennik.', 'url' => $admin ? admin_url( 'admin.php?page=rzd-stan' ) : '', 'note' => $admin ? 'Kokpit → Restauracja → Stan i poczta' : 'Tylko Administrator (Kokpit → Restauracja → Stan i poczta).', 'on' => ! empty( $mail['enabled'] ) ),
			array( 'n' => 'Ochrona formularzy', 'd' => 'Cloudflare Turnstile / hCaptcha w formularzach kontaktowych.', 'url' => $admin && function_exists( 'rzd_panel_url' ) ? rzd_panel_url( 'formularze' ) : '', 'note' => $admin ? 'Panel → Formularze (na dole)' : 'Tylko Administrator.', 'on' => null ),
		),
	);
}

function rzd_panel_do_api() {
	rzd_panel_out( rzd_panel_api_payload() );
}

function rzd_panel_do_api_save() {
	$v = rzd_panel_json( 'values' );
	if ( null === $v ) {
		rzd_panel_fail( 'Brak danych.' );
	}
	list( $ok, $m ) = rzd_api_save( array_intersect_key( (array) $v, array_flip( rzd_api_fields() ) ) );
	if ( ! $ok ) {
		rzd_panel_fail( $m );
	}
	rzd_panel_out( array_merge( rzd_panel_api_payload(), array( 'message' => $m ) ) );
}

function rzd_panel_do_api_models() {
	$k = trim( rzd_panel_str( 'key' ) );
	list( $ok, $r ) = rzd_ai_gemini_models( '' !== $k ? $k : null );
	if ( ! $ok ) {
		rzd_panel_fail( $r );
	}
	rzd_panel_out( array( 'models' => $r ) );
}

function rzd_panel_do_api_fb_check() {
	list( $ok, $r, $note ) = rzd_posts_fb_check();
	if ( ! $ok ) {
		rzd_panel_fail( $r );
	}
	rzd_panel_out( array( 'name' => $r, 'message' => '' !== $note ? $note : 'Połączono ze stroną: ' . $r ) );
}

function rzd_panel_do_api_ai_test() {
	list( $ok, $m ) = rzd_ai_gemini_test();
	if ( ! $ok ) {
		rzd_panel_fail( $m );
	}
	rzd_panel_out( array( 'message' => $m, 'lastCall' => rzd_panel_posts_last_call() ) );
}
