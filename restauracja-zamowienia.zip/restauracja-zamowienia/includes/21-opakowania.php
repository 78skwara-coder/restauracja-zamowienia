<?php
/**
 * MODUŁ 21: Opakowania
 *
 *  - Katalog "Opakowania" (menu Dodatki): ikona (obraz wyróżniający), nazwa,
 *    cena (BRUTTO, jak wszystko w projekcie).
 *  - Pojemność (ile produktów w jednym opakowaniu) od 2.25.1 należy do
 *    KATEGORII (term meta rzd_pack_capacity) albo do PRODUKTU z własnym
 *    opakowaniem (_rzd_prod_pack_capacity), nie do opakowania – to samo
 *    pudełko mieści 2 drożdżówki, ale 1 porcję pierogów. Stara pojemność
 *    opakowania (_rzd_pack_capacity) służy już tylko do jednorazowej migracji.
 *  - Przypięcie:
 *      KATEGORIA – opakowanie standardowe dla jej produktów (dziedziczą
 *                  podkategorie). Produkty tej samej kategorii z tym samym
 *                  opakowaniem dzielą opakowania: 3 drożdżówki / 2 = 2 szt.
 *      PRODUKT   – wyjątek, ma pierwszeństwo; liczy się osobno (tylko ten
 *                  produkt, z pojemnością ustawioną na produkcie) i NIE wchodzi
 *                  do wspólnej puli kategorii. Albo "Bez opakowania".
 *  - Zestawy NIE łączą: każde danie zestawu ma swoje opakowanie (produkt →
 *    zestaw pośredni, np. "Zupa dnia" → kategoria dania), do tego
 *    opakowanie samego zestawu – wszystko × ilość zestawów, bez dzielenia.
 *    Dodatki zestawu (pozycje "rwz_child_of") też bez łączenia.
 *  - Koszyk/kasa: opłata "Opakowanie: …" (brutto, bez podatku). NIE liczy
 *    się do progów dostawy (moduł 20 liczy same produkty).
 *  - Zamówienie: meta _rzd_packaging (JSON [id, name, count, price]) –
 *    z niej Kuchnia (blok "Opakowania"), Pakowanie, kurier i raporty.
 * Stare "Opakowanie" jako obowiązkowy Dodatek w modyfikacjach trzeba odpiąć
 * ręcznie, inaczej liczy się podwójnie.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 1. Katalog
 * ============================================================ */
add_action( 'init', function () {
	register_post_type( 'rzd_packaging', array(
		'labels'       => array(
			'name'          => 'Opakowania',
			'singular_name' => 'Opakowanie',
			'add_new'       => 'Dodaj opakowanie',
			'add_new_item'  => 'Nowe opakowanie',
			'edit_item'     => 'Edytuj opakowanie',
			'all_items'     => 'Opakowania',
			'menu_name'     => 'Opakowania',
			'not_found'     => 'Brak opakowań',
		),
		'public'       => false,
		'show_ui'      => true,
		'show_in_menu' => 'edit.php?post_type=rzd_addon',
		'supports'     => array( 'title', 'thumbnail' ),
	) );
} );

function rzd_packaging_get( $id ) {
	static $memo = array();
	$id = (int) $id;
	if ( ! $id ) {
		return null;
	}
	if ( array_key_exists( $id, $memo ) ) {
		return $memo[ $id ];
	}
	$p = get_post( $id );
	if ( ! $p || 'rzd_packaging' !== $p->post_type || 'publish' !== $p->post_status ) {
		return $memo[ $id ] = null;
	}
	return $memo[ $id ] = array(
		'id'    => $id,
		'name'  => $p->post_title,
		'price' => (float) get_post_meta( $id, '_rzd_pack_price', true ),
	);
}

// Pojemność z pola kategorii/produktu: puste albo < 1 = 1 (osobne opakowanie na sztukę).
function rzd_pack_capacity_value( $raw ) {
	return max( 1, (int) $raw );
}

function rzd_packaging_all() {
	return get_posts( array( 'post_type' => 'rzd_packaging', 'post_status' => 'publish', 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC' ) );
}

add_action( 'add_meta_boxes_rzd_packaging', function () {
	add_meta_box( 'rzd_pack_data', 'Cena', function ( $post ) {
		wp_nonce_field( 'rzd_pack_save', 'rzd_pack_nonce' );
		$price = get_post_meta( $post->ID, '_rzd_pack_price', true );
		?>
		<p><label><strong>Cena (zł, brutto)</strong><br><input type="number" step="0.01" min="0" name="rzd_pack_price" value="<?php echo esc_attr( $price ); ?>" style="width:120px;"></label></p>
		<p class="description">Ikona: „Obraz wyróżniający”. Opakowanie przypinasz w kategorii produktów albo na produkcie – tam też ustawiasz, ile produktów mieści się w jednym opakowaniu (to samo pudełko może mieścić 2 drożdżówki, ale 1 porcję pierogów).</p>
		<?php
	}, 'rzd_packaging', 'normal', 'high' );
} );

add_action( 'save_post_rzd_packaging', function ( $post_id ) {
	if ( ! isset( $_POST['rzd_pack_nonce'] ) || ! wp_verify_nonce( $_POST['rzd_pack_nonce'], 'rzd_pack_save' ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$price = isset( $_POST['rzd_pack_price'] ) ? str_replace( ',', '.', wp_unslash( $_POST['rzd_pack_price'] ) ) : '';
	update_post_meta( $post_id, '_rzd_pack_price', is_numeric( $price ) ? (string) max( 0, round( (float) $price, 2 ) ) : '0' );
} );

add_filter( 'manage_rzd_packaging_posts_columns', function ( $cols ) {
	$new = array();
	foreach ( $cols as $k => $v ) {
		$new[ $k ] = $v;
		if ( 'title' === $k ) {
			$new['rzd_pack_icon']  = 'Ikona';
			$new['rzd_pack_price'] = 'Cena';
		}
	}
	unset( $new['date'] );
	return $new;
} );
add_action( 'manage_rzd_packaging_posts_custom_column', function ( $col, $id ) {
	if ( 'rzd_pack_icon' === $col ) {
		echo has_post_thumbnail( $id ) ? get_the_post_thumbnail( $id, array( 32, 32 ) ) : '—';
	} elseif ( 'rzd_pack_price' === $col ) {
		echo esc_html( number_format_i18n( (float) get_post_meta( $id, '_rzd_pack_price', true ), 2 ) . ' zł' );
	}
}, 10, 2 );

/* ============================================================
 * 2. Przypięcie: kategoria (term meta) i produkt (meta)
 * ============================================================ */
function rzd_packaging_select_html( $name, $current, $with_inherit ) {
	$html = '<select name="' . esc_attr( $name ) . '">';
	if ( $with_inherit ) {
		$html .= '<option value="">— z kategorii —</option>';
		$html .= '<option value="none"' . selected( 'none', $current, false ) . '>Bez opakowania</option>';
	} else {
		$html .= '<option value="">— brak —</option>';
	}
	foreach ( rzd_packaging_all() as $p ) {
		$html .= '<option value="' . (int) $p->ID . '"' . selected( (string) $p->ID, (string) $current, false ) . '>' . esc_html( $p->post_title ) . '</option>';
	}
	return $html . '</select>';
}

function rzd_pack_capacity_input_html( $name, $value ) {
	return '<input type="number" step="1" min="1" name="' . esc_attr( $name ) . '" value="' . esc_attr( rzd_pack_capacity_value( $value ) ) . '" style="width:90px;">';
}

add_action( 'product_cat_add_form_fields', function () {
	echo '<div class="form-field"><label>Opakowanie standardowe</label>' . rzd_packaging_select_html( 'rzd_packaging', '', false ) . '<p>Dla produktów tej kategorii i podkategorii. Produkt może mieć własne (wyjątek).</p></div>'; // phpcs:ignore
	echo '<div class="form-field"><label>Ile produktów mieści się w jednym opakowaniu</label>' . rzd_pack_capacity_input_html( 'rzd_pack_capacity', 1 ) . '<p>Produkty tej kategorii (i podkategorii) dzielą opakowania: przy 2 trzy drożdżówki = 2 opakowania. 1 = osobne opakowanie na każdą sztukę.</p></div>'; // phpcs:ignore
} );
add_action( 'product_cat_edit_form_fields', function ( $term ) {
	echo '<tr class="form-field"><th scope="row"><label>Opakowanie standardowe</label></th><td>' . rzd_packaging_select_html( 'rzd_packaging', get_term_meta( $term->term_id, 'rzd_packaging', true ), false ) . '<p class="description">Dla produktów tej kategorii i podkategorii. Produkt może mieć własne (wyjątek).</p></td></tr>'; // phpcs:ignore
	echo '<tr class="form-field"><th scope="row"><label>Ile produktów mieści się w jednym opakowaniu</label></th><td>' . rzd_pack_capacity_input_html( 'rzd_pack_capacity', get_term_meta( $term->term_id, 'rzd_pack_capacity', true ) ) . '<p class="description">Produkty tej kategorii (i podkategorii) dzielą opakowania: przy 2 trzy drożdżówki = 2 opakowania. 1 = osobne opakowanie na każdą sztukę.</p></td></tr>'; // phpcs:ignore
} );
$rzd_save_cat_pack = function ( $term_id ) {
	if ( ! current_user_can( 'manage_product_terms' ) ) {
		return;
	}
	if ( isset( $_POST['rzd_packaging'] ) ) {
		update_term_meta( $term_id, 'rzd_packaging', absint( $_POST['rzd_packaging'] ) ?: '' );
	}
	if ( isset( $_POST['rzd_pack_capacity'] ) ) {
		update_term_meta( $term_id, 'rzd_pack_capacity', rzd_pack_capacity_value( wp_unslash( $_POST['rzd_pack_capacity'] ) ) );
	}
};
add_action( 'created_product_cat', $rzd_save_cat_pack );
add_action( 'edited_product_cat', $rzd_save_cat_pack );

add_action( 'add_meta_boxes_product', function () {
	add_meta_box( 'rzd_product_pack', 'Opakowanie', function ( $post ) {
		wp_nonce_field( 'rzd_prod_pack', 'rzd_prod_pack_nonce' );
		echo rzd_packaging_select_html( 'rzd_product_packaging', get_post_meta( $post->ID, '_rzd_packaging', true ), true ); // phpcs:ignore
		echo '<p><label>Ile sztuk w jednym opakowaniu<br>' . rzd_pack_capacity_input_html( 'rzd_product_pack_capacity', get_post_meta( $post->ID, '_rzd_prod_pack_capacity', true ) ) . '</label><br><span class="description">Tylko przy własnym opakowaniu produktu. Przy opakowaniu z kategorii liczy się pojemność ustawiona w kategorii.</span></p>'; // phpcs:ignore
		$res = rzd_product_packaging_resolve( $post->ID );
		echo '<p class="description">Własne opakowanie produktu ma pierwszeństwo przed kategorią i nie dzieli się z innymi produktami. ';
		echo $res ? 'Teraz: <strong>' . esc_html( $res['pack']['name'] ) . '</strong>, ' . (int) $res['capacity'] . ' szt. w opakowaniu (' . ( 'product' === $res['source'] ? 'z produktu' : 'z kategorii' ) . ').' : 'Teraz: bez opakowania.';
		echo '</p>';
	}, 'product', 'side', 'default' );
} );
add_action( 'save_post_product', function ( $post_id ) {
	if ( ! isset( $_POST['rzd_prod_pack_nonce'] ) || ! wp_verify_nonce( $_POST['rzd_prod_pack_nonce'], 'rzd_prod_pack' ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$v = isset( $_POST['rzd_product_packaging'] ) ? sanitize_text_field( wp_unslash( $_POST['rzd_product_packaging'] ) ) : '';
	if ( 'none' === $v ) {
		update_post_meta( $post_id, '_rzd_packaging', 'none' );
	} elseif ( absint( $v ) ) {
		update_post_meta( $post_id, '_rzd_packaging', absint( $v ) );
	} else {
		delete_post_meta( $post_id, '_rzd_packaging' );
	}
	if ( isset( $_POST['rzd_product_pack_capacity'] ) ) {
		update_post_meta( $post_id, '_rzd_prod_pack_capacity', rzd_pack_capacity_value( wp_unslash( $_POST['rzd_product_pack_capacity'] ) ) );
	}
} );

/**
 * Jednorazowa migracja (2.25.1): pojemność przeniesiona z opakowania na
 * kategorie i produkty, które mają je przypięte i nie mają jeszcze własnej
 * pojemności. Po aktualizacji koszyk liczy dokładnie tak jak wcześniej.
 */
add_action( 'init', function () {
	if ( '1' === get_option( 'rzd_pack_cap_migrated' ) ) {
		return;
	}
	$old = function ( $pack_id ) {
		return rzd_pack_capacity_value( get_post_meta( (int) $pack_id, '_rzd_pack_capacity', true ) );
	};
	$terms = get_terms( array(
		'taxonomy'   => 'product_cat',
		'hide_empty' => false,
		'meta_query' => array( array( 'key' => 'rzd_packaging', 'compare' => 'EXISTS' ) ), // phpcs:ignore
	) );
	if ( ! is_wp_error( $terms ) ) {
		foreach ( $terms as $t ) {
			$pid = (int) get_term_meta( $t->term_id, 'rzd_packaging', true );
			if ( $pid && '' === (string) get_term_meta( $t->term_id, 'rzd_pack_capacity', true ) ) {
				update_term_meta( $t->term_id, 'rzd_pack_capacity', $old( $pid ) );
			}
		}
	}
	$products = get_posts( array(
		'post_type'   => 'product',
		'post_status' => 'any',
		'numberposts' => -1,
		'fields'      => 'ids',
		'meta_key'    => '_rzd_packaging', // phpcs:ignore
	) );
	foreach ( $products as $id ) {
		$pid = get_post_meta( $id, '_rzd_packaging', true );
		if ( 'none' !== $pid && (int) $pid && '' === (string) get_post_meta( $id, '_rzd_prod_pack_capacity', true ) ) {
			update_post_meta( $id, '_rzd_prod_pack_capacity', $old( $pid ) );
		}
	}
	update_option( 'rzd_pack_cap_migrated', '1' );
}, 20 );

/**
 * Opakowanie produktu: [ 'pack' => …, 'source' => 'product'|'category', 'group' => klucz puli,
 * 'capacity' => ile sztuk w opakowaniu ] albo null. Pojemność pochodzi z miejsca przypięcia.
 * Kategoria: pierwsza z przypiętym opakowaniem, szukana od kategorii produktu
 * w górę (podkategoria dziedziczy). Pula = kategoria, w której przypięto.
 */
function rzd_product_packaging_resolve( $product_id ) {
	$product_id = (int) $product_id;
	$parent     = wp_get_post_parent_id( $product_id );
	if ( $parent && 'product_variation' === get_post_type( $product_id ) ) {
		$product_id = $parent;
	}
	$own = get_post_meta( $product_id, '_rzd_packaging', true );
	if ( 'none' === $own ) {
		return null;
	}
	if ( $own && ( $pack = rzd_packaging_get( $own ) ) ) {
		return array( 'pack' => $pack, 'source' => 'product', 'group' => 'p' . $product_id, 'capacity' => rzd_pack_capacity_value( get_post_meta( $product_id, '_rzd_prod_pack_capacity', true ) ) );
	}
	$terms = get_the_terms( $product_id, 'product_cat' );
	if ( ! $terms || is_wp_error( $terms ) ) {
		return null;
	}
	foreach ( $terms as $t ) {
		$chain = array_merge( array( (int) $t->term_id ), array_map( 'intval', get_ancestors( $t->term_id, 'product_cat' ) ) );
		foreach ( $chain as $tid ) {
			$pid = get_term_meta( $tid, 'rzd_packaging', true );
			if ( $pid && ( $pack = rzd_packaging_get( $pid ) ) ) {
				return array( 'pack' => $pack, 'source' => 'category', 'group' => 'c' . $tid, 'capacity' => rzd_pack_capacity_value( get_term_meta( $tid, 'rzd_pack_capacity', true ) ) );
			}
		}
	}
	return null;
}

/* ============================================================
 * 3. Liczenie opakowań koszyka
 * ============================================================ */
// Zwraca [ pack_id => [ 'id','name','price','count' ] ].
function rzd_cart_packaging() {
	if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
		return array();
	}
	$pools = array(); // "grupa|opakowanie" => [ pack, qty ] – dzielone przez pojemność
	$fixed = array(); // pack_id => [ pack, count ] – bez dzielenia (zestawy)
	$add_fixed = function ( $res, $n ) use ( &$fixed ) {
		if ( ! $res || $n <= 0 ) {
			return;
		}
		$id = $res['pack']['id'];
		if ( ! isset( $fixed[ $id ] ) ) {
			$fixed[ $id ] = array( 'pack' => $res['pack'], 'count' => 0 );
		}
		$fixed[ $id ]['count'] += $n;
	};
	$date = function_exists( 'dc_selected_date' ) ? dc_selected_date() : null;

	foreach ( WC()->cart->get_cart() as $item ) {
		$pid = (int) $item['product_id'];
		$qty = (int) $item['quantity'];
		if ( $qty <= 0 ) {
			continue;
		}
		// Dodatek zestawu – bez łączenia.
		if ( ! empty( $item['rwz_child_of'] ) ) {
			$add_fixed( rzd_product_packaging_resolve( $pid ), $qty );
			continue;
		}
		// Zestaw – opakowanie zestawu + każde danie osobno, × ilość zestawów.
		if ( isset( $item['rwz_components'] ) && function_exists( 'rwz_get_active_components' ) ) {
			$add_fixed( rzd_product_packaging_resolve( $pid ), $qty );
			$active = rwz_get_active_components( $pid, $date ? $date : null );
			foreach ( (array) $active['main'] as $comp ) {
				$cid = (int) $comp->get_id();
				$res = null;
				$own = get_post_meta( $cid, '_rzd_packaging', true );
				if ( 'none' === $own ) {
					continue;
				}
				if ( $own ) {
					$res = rzd_product_packaging_resolve( $cid );
				}
				// Danie bez własnego → zestaw pośredni (np. "Zupa dnia"), od najbliższego.
				if ( ! $res && ! empty( $active['via'][ $cid ] ) ) {
					foreach ( array_reverse( (array) $active['via'][ $cid ] ) as $via_id ) {
						$vo = get_post_meta( (int) $via_id, '_rzd_packaging', true );
						if ( $vo && 'none' !== $vo && ( $vp = rzd_packaging_get( $vo ) ) ) {
							$res = array( 'pack' => $vp, 'source' => 'product', 'group' => 'p' . (int) $via_id, 'capacity' => 1 );
							break;
						}
					}
				}
				if ( ! $res ) {
					$res = rzd_product_packaging_resolve( $cid ); // kategoria dania
				}
				$add_fixed( $res, $qty );
			}
			continue;
		}
		// Zwykły produkt – pula kategorii albo własna pula produktu.
		$res = rzd_product_packaging_resolve( $pid );
		if ( ! $res ) {
			continue;
		}
		$key = $res['group'] . '|' . $res['pack']['id'];
		if ( ! isset( $pools[ $key ] ) ) {
			$pools[ $key ] = array( 'pack' => $res['pack'], 'qty' => 0, 'capacity' => $res['capacity'] );
		}
		$pools[ $key ]['qty'] += $qty;
	}

	$out = array();
	$put = function ( $pack, $n ) use ( &$out ) {
		$id = $pack['id'];
		if ( ! isset( $out[ $id ] ) ) {
			$out[ $id ] = array( 'id' => $id, 'name' => $pack['name'], 'price' => $pack['price'], 'count' => 0 );
		}
		$out[ $id ]['count'] += $n;
	};
	foreach ( $pools as $p ) {
		$put( $p['pack'], (int) ceil( $p['qty'] / max( 1, (int) $p['capacity'] ) ) );
	}
	foreach ( $fixed as $f ) {
		$put( $f['pack'], $f['count'] );
	}
	return $out;
}

// Opłaty w koszyku/kasie (brutto, bez podatku). Opakowanie za 0 zł nie
// zaśmieca koszyka klienta, ale i tak trafia do zamówienia dla kuchni.
add_action( 'woocommerce_cart_calculate_fees', function ( $cart ) {
	if ( is_admin() && ! wp_doing_ajax() ) {
		return;
	}
	foreach ( rzd_cart_packaging() as $p ) {
		if ( $p['price'] > 0 && $p['count'] > 0 ) {
			$cart->add_fee( 'Opakowanie: ' . $p['name'] . ' ×' . $p['count'], $p['price'] * $p['count'], false );
		}
	}
} );

// Zapis w zamówieniu – dla Kuchni, Pakowania, kuriera i raportów.
function rzd_save_packaging_to_order( $order ) {
	$packs = array_values( rzd_cart_packaging() );
	if ( $packs ) {
		$order->update_meta_data( '_rzd_packaging', wp_json_encode( $packs ) );
	}
}
add_action( 'woocommerce_checkout_create_order', 'rzd_save_packaging_to_order', 30 );
add_action( 'woocommerce_store_api_checkout_update_order_from_request', 'rzd_save_packaging_to_order', 30 );

function rzd_order_packaging( $order ) {
	$raw  = $order->get_meta( '_rzd_packaging' );
	$data = $raw ? json_decode( $raw, true ) : array();
	return is_array( $data ) ? $data : array();
}
