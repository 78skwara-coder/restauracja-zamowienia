<?php
/**
 * MODUŁ 17: Kategorie — shortcode [kategorie_zamowien]
 *
 * Kafle kategorii do umieszczenia np. na stronie głównej, jako "menu" do
 * poszczególnych stron z listami produktów (moduł 2). Każda kategoria ma
 * WŁASNY, ręcznie wpisany adres URL (pole na ekranie edycji kategorii w
 * Produkty → Kategorie) – bo różne kategorie mogą prowadzić na różne
 * strony, niekoniecznie na jedną wspólną listę z filtrem.
 *
 * Wygląd ustawia się w Wygląd listy → „Kafle kategorii” (od 2.26.6), osobno
 * dla telefonu i komputera. Domyślnie: telefon – zdjęcie kategorii w tle,
 * rozmyte i przyciemnione, biały pogrubiony napis, 2 w wierszu; komputer –
 * zdjęcie nad napisem, 4 w wierszu. Zdjęcie = to z „Edytuj kategorię” → Zdjęcie.
 *
 * Użycie: [kategorie_zamowien]                    (wszystkie kategorie z produktami)
 *         [kategorie_zamowien kategoria="Bajgle,Zupy"]  (tylko wskazane, w tej kolejności)
 * Kolejność bez listy w shortcodzie (2.26.13): pole „Kolejność kafla” na karcie
 * kategorii – najpierw z numerem rosnąco, bez numeru na końcu alfabetycznie.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ---------- Pole "Adres docelowy" na ekranie kategorii produktu ---------- */

add_action( 'product_cat_add_form_fields', function () {
	?>
	<div class="form-field">
		<label for="rzd_kategoria_url">Adres docelowy (kafel kategorii)</label>
		<input type="url" name="rzd_kategoria_url" id="rzd_kategoria_url" value="" placeholder="https://…">
		<p class="description">Dokąd ma prowadzić kafel tej kategorii w shortcodzie <code>[kategorie_zamowien]</code>. Puste = domyślna strona archiwum kategorii WooCommerce.</p>
	</div>
	<div class="form-field">
		<label for="rzd_kategoria_order">Kolejność kafla</label>
		<input type="number" name="rzd_kategoria_order" id="rzd_kategoria_order" value="" min="0" step="1" style="width:100px">
		<p class="description">Miejsce kafla w <code>[kategorie_zamowien]</code> (1 = pierwszy). Puste = na końcu, alfabetycznie. Ten sam numer u kilku kategorii = między nimi alfabetycznie.</p>
	</div>
	<?php
} );

add_action( 'product_cat_edit_form_fields', function ( $term ) {
	$url = get_term_meta( $term->term_id, 'rzd_kategoria_url', true );
	?>
	<tr class="form-field">
		<th scope="row"><label for="rzd_kategoria_url">Adres docelowy (kafel kategorii)</label></th>
		<td>
			<input type="url" name="rzd_kategoria_url" id="rzd_kategoria_url" value="<?php echo esc_attr( $url ); ?>" placeholder="https://…" style="width:100%;max-width:400px;">
			<p class="description">Dokąd ma prowadzić kafel tej kategorii w shortcodzie <code>[kategorie_zamowien]</code>. Puste = domyślna strona archiwum kategorii WooCommerce.</p>
		</td>
	</tr>
	<tr class="form-field">
		<th scope="row"><label for="rzd_kategoria_order">Kolejność kafla</label></th>
		<td>
			<input type="number" name="rzd_kategoria_order" id="rzd_kategoria_order" value="<?php echo esc_attr( get_term_meta( $term->term_id, 'rzd_kategoria_order', true ) ); ?>" min="0" step="1" style="width:100px">
			<p class="description">Miejsce kafla w <code>[kategorie_zamowien]</code> (1 = pierwszy). Puste = na końcu, alfabetycznie. Ten sam numer u kilku kategorii = między nimi alfabetycznie.</p>
		</td>
	</tr>
	<?php
} );

foreach ( [ 'created_product_cat', 'edited_product_cat' ] as $hook ) {
	add_action( $hook, function ( $term_id ) {
		if ( ! isset( $_POST['rzd_kategoria_url'] ) ) {
			return;
		}
		$url = trim( $_POST['rzd_kategoria_url'] );
		if ( '' === $url ) {
			delete_term_meta( $term_id, 'rzd_kategoria_url' );
		} else {
			update_term_meta( $term_id, 'rzd_kategoria_url', esc_url_raw( $url ) );
		}
		// 2.26.13: kolejność kafla (puste = na końcu, alfabetycznie).
		$ord = isset( $_POST['rzd_kategoria_order'] ) ? trim( (string) wp_unslash( $_POST['rzd_kategoria_order'] ) ) : '';
		if ( '' === $ord || ! is_numeric( $ord ) ) {
			delete_term_meta( $term_id, 'rzd_kategoria_order' );
		} else {
			update_term_meta( $term_id, 'rzd_kategoria_order', max( 0, (int) $ord ) );
		}
	} );
}

// Kolumna „Kolejność kafla” na liście kategorii (Produkty → Kategorie).
add_filter( 'manage_edit-product_cat_columns', function ( $cols ) {
	$cols['rzd_order'] = 'Kolejność kafla';
	return $cols;
} );
add_filter( 'manage_product_cat_custom_column', function ( $out, $col, $term_id ) {
	if ( 'rzd_order' === $col ) {
		$v   = get_term_meta( $term_id, 'rzd_kategoria_order', true );
		$out = '' !== (string) $v ? (int) $v : '—';
	}
	return $out;
}, 10, 3 );

// Sortowanie kafli: najpierw z numerem (rosnąco, przy równych – alfabetycznie),
// potem bez numeru – alfabetycznie.
function rzd_kategorie_sort( $terms ) {
	// Kolejność alfabetyczną bierzemy z bazy (get_terms orderby=name – poprawne
	// polskie litery, np. „Śniadania” po „Sałatki”), a nie z porównania w PHP.
	$pos = array();
	foreach ( array_values( $terms ) as $i => $t ) {
		$pos[ $t->term_id ] = $i;
	}
	usort( $terms, function ( $a, $b ) use ( $pos ) {
		$oa = get_term_meta( $a->term_id, 'rzd_kategoria_order', true );
		$ob = get_term_meta( $b->term_id, 'rzd_kategoria_order', true );
		$ha = '' !== (string) $oa;
		$hb = '' !== (string) $ob;
		if ( $ha !== $hb ) {
			return $ha ? -1 : 1;
		}
		if ( $ha && (int) $oa !== (int) $ob ) {
			return (int) $oa < (int) $ob ? -1 : 1;
		}
		return $pos[ $a->term_id ] - $pos[ $b->term_id ];
	} );
	return $terms;
}

function rzd_kategoria_link( $term ) {
	$custom = get_term_meta( $term->term_id, 'rzd_kategoria_url', true );
	return $custom ? esc_url( $custom ) : esc_url( get_term_link( $term ) );
}

/* ---------- Shortcode ---------- */

// Kategorie do pokazania: wskazane (w podanej kolejności) albo wszystkie z
// produktami, bez oznaczonych „Nie wyświetlaj w sklepie”.
function rzd_kategorie_terms( $list ) {
	if ( $list ) {
		// Kolejność DOKŁADNIE taka, jak wpisana w shortcodzie – nie alfabetyczna.
		$terms = [];
		foreach ( array_map( 'trim', explode( ',', $list ) ) as $token ) {
			if ( '' === $token ) {
				continue;
			}
			$t = get_term_by( 'name', $token, 'product_cat' );
			if ( ! $t ) {
				$t = get_term_by( 'slug', sanitize_title( $token ), 'product_cat' );
			}
			if ( $t ) {
				$terms[] = $t;
			}
		}
		return $terms;
	}
	$terms = get_terms( [
		'taxonomy'   => 'product_cat',
		'hide_empty' => true,
		'orderby'    => 'name',
	] );
	if ( is_wp_error( $terms ) ) {
		return [];
	}
	// Domyślnie (bez ręcznie wskazanych kategorii w shortcodzie) pomijamy
	// te oznaczone "Nie wyświetlaj w sklepie" (ta sama flaga co przy
	// ukrywaniu komponentów zestawów – patrz moduł 4) – to kategorie
	// pomocnicze, nie własne pozycje menu do pokazania klientowi.
	return rzd_kategorie_sort( array_values( array_filter( $terms, function ( $t ) {
		return ! get_term_meta( $t->term_id, 'rwz_hide_in_shop', true );
	} ) ) );
}

/**
 * Kafle. Wygląd (2.26.6): Wygląd listy → „Kafle kategorii” (moduł 15,
 * rzd_tiles_css) – osobno telefon i komputer: zdjęcie w tle (rozmyte,
 * przyciemnione), zdjęcie nad napisem albo sam napis. $limit = podgląd w panelu.
 */
function rzd_kategorie_tiles_html( $terms, $limit = 0 ) {
	if ( $limit ) {
		$terms = array_slice( $terms, 0, $limit );
	}
	if ( ! $terms ) {
		return '';
	}
	// 2.26.12: kafle w rozwijanym polu („Kategorie menu”) – czy zwinięte, decyduje
	// Wygląd listy → Kafle kategorii (osobno telefon/komputer, CSS w module 15).
	$title = 'Kategorie menu';
	if ( function_exists( 'rzd_list_style_get' ) ) {
		$st = rzd_list_style_get();
		if ( ! empty( $st['tiles_collapse_title'] ) ) {
			$title = $st['tiles_collapse_title'];
		}
	}
	// 2.26.13: zdjęcia wszystkich kafli jednym zapytaniem.
	$thumbs = array_filter( array_map( function ( $t ) { return (int) get_term_meta( $t->term_id, 'thumbnail_id', true ); }, $terms ) );
	if ( $thumbs ) {
		_prime_post_caches( array_values( $thumbs ), false, true );
	}
	$h = '<div class="rk-wrap' . ( $limit ? ' is-open' : '' ) . '">'
		. '<button type="button" class="rk-toggle" aria-expanded="' . ( $limit ? 'true' : 'false' ) . '"><span class="rk-arrow" aria-hidden="true">▶</span><span>' . esc_html( $title ) . '</span></button>'
		. '<div class="rk-panel"><div class="rk-grid">';
	foreach ( $terms as $t ) {
		$thumb_id = (int) get_term_meta( $t->term_id, 'thumbnail_id', true );
		$img      = $thumb_id ? wp_get_attachment_image( $thumb_id, 'medium', false, [ 'loading' => 'lazy', 'alt' => '' ] ) : '';
		$h       .= '<a class="rk-tile' . ( $img ? '' : ' rk-noimg' ) . '" href="' . rzd_kategoria_link( $t ) . '">'
			. '<span class="rk-tile-img">' . $img . '</span>'
			. '<span class="rk-tile-name">' . esc_html( $t->name ) . '</span>'
			. '</a>';
	}
	$h .= '</div></div></div>';
	static $js = false;
	if ( ! $js && ! $limit ) {
		$js = true;
		$h .= '<script>document.addEventListener("click",function(e){var b=e.target&&e.target.closest?e.target.closest(".rk-toggle"):null;if(!b){return;}var w=b.parentNode;var o=!w.classList.contains("is-open");w.classList.toggle("is-open",o);b.setAttribute("aria-expanded",o?"true":"false");});</script>';
	}
	return $h;
}

add_shortcode( 'kategorie_zamowien', function ( $atts ) {
	$a = shortcode_atts( [ 'kategoria' => '' ], $atts );
	return rzd_kategorie_tiles_html( rzd_kategorie_terms( $a['kategoria'] ) );
} );
