<?php
/**
 * MODUŁ 15: Wygląd listy — panel do samodzielnego dostosowania stylu
 *
 * Zamiast prosić o zmianę CSS za każdym razem, gdy coś ma wyglądać inaczej,
 * najważniejsze elementy listy zamówień (nazwa produktu, nagłówek kategorii,
 * cena, opis, zdjęcie, przycisk "Dodaj do koszyka", plakietki alergenów)
 * można teraz ustawić z panelu: krój i rozmiar czcionki, kolory, wielkość
 * zdjęcia, zaokrąglenia rogów tam, gdzie mają sens.
 *
 * Ustawienia zapisują się jako jedna opcja (rzd_list_style) i na froncie
 * są wstrzykiwane jako dodatkowy blok CSS DOKLEJONY do statycznego pliku
 * assets/css/lista-zamowien.css (moduł 03) – nadpisuje go tam, gdzie
 * coś faktycznie zmienisz, a wszystko inne zostaje bez zmian.
 *
 * Dwie zakładki – Komputer (wartości bazowe, od 900 px) i Telefon
 * (dziedziczy z komputera sekcjami; „Na telefonie inaczej” = własne m_*).
 * Podgląd w <iframe> o szerokości urządzenia, więc @media działają naprawdę.
 *
 * Domyślne wartości w panelu odpowiadają temu, co jest w tej chwili na
 * stronie – więc samo zainstalowanie tego modułu niczego nie zmienia,
 * dopóki czegoś nie ruszysz. Pola kolorów mają osobny checkbox "Nadpisz
 * kolor", bo bez niego nie da się bezpiecznie odróżnić "zostaw jak jest"
 * (kolor z motywu) od świadomego wyboru konkretnego koloru.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 1. DANE I DOMYŚLNE WARTOŚCI
 * ============================================================ */
function rzd_list_style_defaults() {
	return array(
		// Wartości bazowe = KOMPUTER (od 900 px). Telefon dziedziczy je sekcjami,
		// chyba że w sekcji zaznaczono „Na telefonie inaczej” (m_on_<sekcja>) –
		// wtedy bierze swoje m_<klucz> (style_v 2).
		'style_v'            => 5,

		'heading_font'       => 'Playfair Display',
		'body_font'          => 'Lato',
		'letter_spacing'     => 1.5,

		'name_size'          => 20,
		'name_color_on'      => 0,
		'name_color'         => '#c0392b',
		'name_gap'           => 0, // odstęp pod nazwą produktu w px (0 = jak dotąd)

		'cat_size'           => 26,
		'cat_color_on'       => 0,
		'cat_color'          => '#222222',

		'price_size'         => 34, // wcześniej plik CSS i tak wymuszał 34 px
		'price_color_on'     => 0,
		'price_color'        => '#222222',
		'price_cur_pos'      => 'side', // side | below | above
		'price_cur_size'     => 100,    // % rozmiaru ceny
		'price_dec_size'     => 100,    // % rozmiaru ceny (grosze)
		'price_dec_align'    => 'base', // base = w linii, top = u góry
		'price_cur_gap'      => 0,        // odstęp liczba ↔ waluta w px (0 = automatycznie)
		'price_cur_align'    => 'center', // przy pod/nad – left | center | right

		'desc_font'          => '', // puste = ta sama czcionka co reszta treści (body_font)
		'desc_size'          => 14,
		'desc_color_on'      => 0,
		'desc_color'         => '#666666',

		'image_size'         => 160,
		'image_radius'       => 16,
		'set_split'          => 'diag',    // zdjęcie dzielone zestawu: diag = skos „/”, vert = pionowo
		'set_split_line'     => 0,         // kreska podziału w px (0 = bez kreski)
		'set_split_color'    => '#ffffff', // kolor kreski

		// Kolory interakcji (hover): wiersz i ramka mają DWA różne kolory,
		// inaczej ramka „znika” na tle podświetlonego wiersza.
		'row_hover_bg'       => '#faf3e3',
		'box_hover_bg'       => '#ffffff',
		'box_hover_border'   => '#c08a2e',

		'button_padding_v'   => 8,
		'button_padding_h'   => 14,
		'button_radius'      => 6,
		'button_font_size'   => 15,
		'button_width'       => 'fill', // fill = reszta wiersza (jak dawniej), auto = wg napisu
		'button_align'       => 'left', // przy „auto” – left = obok licznika, right = do prawej krawędzi
		'button_text_color'  => '#2b2110',
		'button_bg'          => '#faf3e3',
		'button_border_color'=> '#c08a2e',
		'button_hover_bg'    => '#ffffff',
		'button_hover_text'  => '#2b2110',

		'allergen_bg'        => '#f3e9d8',
		'allergen_text'      => '#5a4520',
		'allergen_radius'    => 10,

		// Ramki rozwijane
		'box_border_color'    => '#c4c4c4',
		'box_border_width'    => 1.5,
		'box_radius'          => 8,
		'box_bg_on'           => 0,
		'box_bg'              => '#ffffff',
		'box_pad_v'           => 8,
		'box_pad_h'           => 12,
		'box_title_size'      => 12,
		'box_title_color'     => '#2b2b2b',
		'box_arrow_on'        => 1,
		'box_harmono_title'   => 'Harmonogram',
		'box_harmono_border'  => 1,
		'harmono_days_back'   => 7, // historia w okienku harmonogramu (0 = bez)
		'box_delivery_title'  => 'Możliwe dostawy',
		'box_delivery_border' => 1,
		'box_more_title'      => 'Pełny opis',
		'box_more_border'     => 1,
		'box_allergen_title'  => 'Alergeny', // ramka alergenów (na telefonie); liczba dopisywana sama
		'box_allergen_border' => 1,

		// Licznik ilości
		'qty_border_on'       => 0, // przy okrągłych − / + bez ramki licznika
		'qty_border_color'    => '#c4c4c4',
		'qty_border_width'    => 1.5,
		'qty_radius'          => 8,
		'qty_bg'              => '#ffffff',
		'qty_height'          => 52,
		'qty_font_size'       => 18,
		'qty_btn_width'       => 38,
		'qty_btn_radius'      => 0,
		'qty_btn_bg'          => '#f4f4f4',
		'qty_btn_text'        => '#2b2b2b',
		'qty_btn_hover_bg'    => '#e8e8e8',
		'qty_gap'             => 16,
		'qty_input_width'     => 0, // szerokość pola z liczbą w px, 0 = automatycznie
		'qty_btn_shape'       => 'circle', // 'rect' | 'circle'
		'qty_circle_size'     => 40,
		'qty_circle_border_w' => 1.5,
		'qty_circle_border_c' => '#c08a2e',

		'element_gap'         => 10,

		// Okienka: tło + czcionki i przyciski.
		// Grubość '' = jak motyw (nic nie narzucamy).
		'popup_opacity'       => 82,
		'popup_bg_color'      => '#ffffff',
		'popup_text_color'    => '#2b2b2b',
		'popup_blur'          => 14,
		'popup_title_size'    => 22,
		'popup_title_weight'  => '700',
		'popup_text_size'     => 13,
		'popup_text_weight'   => '',
		'popup_label_size'    => 13,
		'popup_label_weight'  => '',
		'popup_tile_size'     => 14,
		'popup_tile_weight'   => '',
		'popup_btn_size'      => 14,
		'popup_btn_weight'    => '600',
		'popup_btn_pad_v'     => 11,
		'popup_btn_width'     => 44,
		'popup_btn_radius'    => 8,

		// kafle kategorii [kategorie_zamowien] (moduł 17). Komputer = dotychczasowy
		// wygląd (zdjęcie nad napisem, 4 w wierszu), telefon = zdjęcie w tle, rozmyte,
		// przyciemnione, biały pogrubiony napis, 2 w wierszu.
		'tiles_style'         => 'below', // below | photo | plain
		'tiles_cols'          => 4,
		'tiles_gap'           => 20,
		'tiles_height'        => 80,
		'tiles_radius'        => 12,
		'tiles_blur'          => 3,
		'tiles_overlay'       => 50,
		'tiles_font_size'     => 16,
		'tiles_font_weight'   => '600',
		'tiles_text_color'    => '#2b2b2b',
		'tiles_upper'         => 0,
		'tiles_border'        => 0,
		'tiles_border_color'  => '#c4c4c4',
		'tiles_bg'            => '#ffffff',
		'tiles_hover_zoom'    => 1,
		'tiles_label_bg'      => 'none',    // tło pod napisem – none | pill | band | glow
		'tiles_label_color'   => '#000000',
		'tiles_label_opacity' => 55,
		'tiles_label_blur'    => 4,         // rozmycie zdjęcia TYLKO pod napisem (szkło)
		'tiles_label_pos'     => 'center',  // center | bottom
		'tiles_collapse'      => 0,         // kafle schowane w rozwijanym polu
		'm_tiles_collapse'    => 1,         // telefon – domyślnie schowane
		'tiles_collapse_title'=> 'Rozwiń',  // było „Kategorie menu” (migracja style_v 5)
		'tiles_collapse_title_open' => 'Zwiń', // napis, gdy kafle rozwinięte
		'tiles_collapse_open' => 1,         // na start rozwinięte (klienci nie zauważali „Rozwiń”)
		'tiles_toggle_size'   => 18,        // napis na przycisku Rozwiń/Zwiń (było 15 px na sztywno)
		'tiles_toggle_weight' => '800',
		'tiles_toggle_style'  => 'accent',  // accent = kolory przycisku „Dodaj do koszyka”, outline = biały z ramką (jak dawniej)
		'tiles_wrap_gap'      => 16,        // odstęp pod całym blokiem kafli
		'm_on_tiles'          => 1,
		'm_tiles_style'       => 'photo',
		'm_tiles_cols'        => 2,
		'm_tiles_gap'         => 12,
		'm_tiles_height'      => 80,
		'm_tiles_radius'      => 10,
		'm_tiles_blur'        => 3,
		'm_tiles_overlay'     => 50,
		'm_tiles_font_size'   => 15,
		'm_tiles_font_weight' => '700',
		'm_tiles_text_color'  => '#ffffff',
		'm_tiles_upper'       => 0,
		'm_tiles_border'      => 0,
		'm_tiles_border_color'=> '#c4c4c4',
		'm_tiles_bg'          => '#3a3a3a',
		'm_tiles_hover_zoom'  => 1,

		// strony sklepu WooCommerce (kategorie, sklep, podobne produkty).
		'shop_on'             => 1,
		'shop_center'         => 1,
		'shop_img_radius'     => 12,
		'shop_btn_style'      => 1,
		'shop_btn_full'       => 0,
		'shop_name_size'      => 17,
		'shop_name_weight'    => '700',
		'shop_price_size'     => 16,
		'shop_price_color_on' => 0,
		'shop_price_color'    => '#2b2b2b',
		'shop_card_gap'       => 8,
		'shop_hide_count'     => 1, // „Wyświetlanie wszystkich wyników: N”
		'shop_hide_sort'      => 1, // „Domyślne sortowanie”
		'shop_equal'          => 1, // równe kafle – przyciski w jednej linii
		'shop_grid_center'    => 1, // niepełny rząd kafli (np. 1–2 produkty w kategorii) na środku
		'gb_btn_style'        => 1, // przyciski z bloku Gutenberga „Przyciski” w stylu listy
		'shop_related_title'  => 'Zamów razem', // zamiast „Podobne produkty”

		// strona pojedynczego produktu.
		'single_on'           => 1,
		'single_buy'          => 1,
		'single_one_title'    => 1,
		'single_layout'       => 1, // do lewej, licznik i przycisk na dole kolumny (ilość nad przyciskiem)
		'single_harmono'      => 1, // ramka „Harmonogram” zestawu na stronie produktu
		'single_head_align'   => 'right', // nazwa i cena – left | center | right
		'single_buy_stack'    => 'stack', // stack = ilość nad przyciskiem, row = obok siebie
		'single_tabs_line'    => 'accent', // kreska nad zakładkami – accent | dark | theme
		'single_tab_cat'      => 1,        // zakładka „Opis” → nazwa kategorii produktu
		'single_tab_catdesc'  => 1,        // w zakładce opis kategorii + nazwa produktu zamiast „O produkcie”
		'm_on_single'         => 1,       // telefon – ilość i przycisk obok siebie
		'm_single_buy_stack'  => 'center', // telefon – wyśrodkowane, przycisk pod ilością
		'single_head_gap'     => 0,  // odstęp nazwa → cena (0 = motyw)
		'single_qty_size'     => 0,  // średnica − / + na stronie produktu (0 = jak na liście)
		'single_qty_font'     => 0,  // rozmiar liczby (0 = jak na liście)
		'single_btn_width'    => 0,  // szerokość przycisku w % kolumny (0 = automatycznie)
		'single_btn_height'   => 0,  // min. wysokość przycisku (0 = automatycznie)
		'm_single_qty_size'   => 54,
		'm_single_qty_font'   => 24,
		'm_single_btn_width'  => 90,
		'm_single_btn_height' => 56,
		'single_img_square'   => 1,
		'single_img_radius'   => 16,
		'single_thumb_radius' => 8,
		'single_title_size'   => 0,
		'single_price_size'   => 0,
		'single_price_color_on' => 0,
		'single_price_color'  => '#2b2b2b',

		// TELEFON – sekcje, które już przed 2.26.0 miały osobne wartości.
		'm_on_name'           => 1,
		'm_name_size'         => 16,
		'm_on_cat'            => 1,
		'm_cat_size'          => 22,
		'm_on_price'          => 1,
		'm_price_size'        => 34,
		'm_on_desc'           => 1,
		'm_desc_size'         => 13,
		'm_on_image'          => 1,
		'm_image_size'        => 112,
		'm_image_radius'      => 999, // duża wartość = pełne koło
	);
}

/**
 * Rejestr pól panelu – z niego powstaje formularz (obie zakładki), zapis
 * i dziedziczenie telefon ← komputer. 'shared' = pole wspólne dla obu
 * widoków (czcionki-nazwy, tytuły ramek); 'device' => false = sekcja bez
 * wersji telefonu.
 */
function rzd_list_style_fields() {
	$weight = array( '' => 'jak motyw', '400' => 'normalna', '500' => 'średnia', '600' => 'półgruba', '700' => 'gruba', '800' => 'bardzo gruba' );
	return array(
		'fonts'   => array( 'Czcionki ogólne', array(
			array( 't' => 'text', 'k' => 'heading_font', 'l' => 'Czcionka nagłówkowa (nazwa produktu, nagłówek kategorii)', 'shared' => 1 ),
			array( 't' => 'text', 'k' => 'body_font', 'l' => 'Czcionka treści (reszta tekstu na liście)', 'shared' => 1 ),
			array( 't' => 'note', 'l' => 'Nazwy czcionek z Google Fonts – wpisane dokładnie tak, jak tam widnieją. Wspólne dla telefonu i komputera.' ),
			array( 't' => 'number', 'k' => 'letter_spacing', 'l' => 'Odstęp między literami (nazwy, nagłówki)', 'step' => 0.1 ),
		) ),
		'name'    => array( 'Nazwa produktu', array(
			array( 't' => 'number', 'k' => 'name_size', 'l' => 'Rozmiar czcionki' ),
			array( 't' => 'color', 'k' => 'name_color', 'l' => 'Kolor', 'toggle' => 1 ),
			array( 't' => 'number', 'k' => 'name_gap', 'l' => 'Odstęp pod nazwą (0 = jak dotąd)' ),
		) ),
		'cat'     => array( 'Nagłówek kategorii', array(
			array( 't' => 'note', 'l' => 'Pojawia się, gdy w shortcodzie użyjesz parametru kategoria.' ),
			array( 't' => 'number', 'k' => 'cat_size', 'l' => 'Rozmiar czcionki' ),
			array( 't' => 'color', 'k' => 'cat_color', 'l' => 'Kolor', 'toggle' => 1 ),
		) ),
		'price'   => array( 'Cena', array(
			array( 't' => 'number', 'k' => 'price_size', 'l' => 'Rozmiar czcionki' ),
			array( 't' => 'color', 'k' => 'price_color', 'l' => 'Kolor', 'toggle' => 1 ),
			array( 't' => 'select', 'k' => 'price_cur_pos', 'l' => 'Waluta (zł)', 'o' => array( 'side' => 'obok ceny', 'below' => 'pod ceną', 'above' => 'nad ceną' ) ),
			array( 't' => 'number', 'k' => 'price_cur_size', 'l' => 'Wielkość waluty (% rozmiaru ceny)', 'u' => '%' ),
			array( 't' => 'number', 'k' => 'price_cur_gap', 'l' => 'Odstęp waluty od ceny (0 = automatycznie)' ),
			array( 't' => 'select', 'k' => 'price_cur_align', 'l' => 'Wyrównanie ceny i waluty (przy „pod ceną” / „nad ceną”)', 'o' => array( 'left' => 'do lewej', 'center' => 'do środka', 'right' => 'do prawej' ) ),
			array( 't' => 'number', 'k' => 'price_dec_size', 'l' => 'Wielkość groszy „,00” (% rozmiaru ceny)', 'u' => '%' ),
			array( 't' => 'select', 'k' => 'price_dec_align', 'l' => 'Grosze', 'o' => array( 'base' => 'w linii', 'top' => 'u góry (jak w karcie menu)' ) ),
		) ),
		'desc'    => array( 'Krótki opis', array(
			array( 't' => 'text', 'k' => 'desc_font', 'l' => 'Czcionka opisu (puste = jak reszta treści)', 'shared' => 1 ),
			array( 't' => 'number', 'k' => 'desc_size', 'l' => 'Rozmiar czcionki' ),
			array( 't' => 'color', 'k' => 'desc_color', 'l' => 'Kolor', 'toggle' => 1 ),
		) ),
		'image'   => array( 'Zdjęcie produktu', array(
			array( 't' => 'number', 'k' => 'image_size', 'l' => 'Rozmiar (szerokość i wysokość)' ),
			array( 't' => 'number', 'k' => 'image_radius', 'l' => 'Zaokrąglenie rogów (bardzo duża wartość = koło)' ),
			array( 't' => 'sub', 'l' => 'Zestaw z dwoma daniami – zdjęcie dzielone (lista, sklep i kategorie, strona produktu, koszyk, przegląd zamówienia)', 'shared' => 1 ),
			array( 't' => 'select', 'k' => 'set_split', 'l' => 'Podział zdjęcia', 'o' => array( 'diag' => 'po skosie – od prawego górnego do lewego dolnego rogu', 'vert' => 'pionowo – pół na pół' ), 'shared' => 1 ),
			array( 't' => 'number', 'k' => 'set_split_line', 'l' => 'Kreska podziału – grubość (0 = bez kreski)', 'step' => 0.5, 'shared' => 1 ),
			array( 't' => 'color', 'k' => 'set_split_color', 'l' => 'Kreska podziału – kolor', 'shared' => 1 ),
			array( 't' => 'note', 'l' => 'Pokazujemy najwyżej dwa dania. Checkbox „Zdjęcie” przy daniu w zestawie: zaznaczone jedno danie = tylko jego zdjęcie (bez podziału); kilka albo żadne = podział między dwa pierwsze dania z własnym zdjęciem. Ustawienia wspólne dla telefonu i komputera.', 'shared' => 1 ),
		) ),
		'button'  => array( 'Przycisk „Dodaj do koszyka”', array(
			array( 't' => 'select', 'k' => 'button_width', 'l' => 'Szerokość przycisku', 'o' => array( 'fill' => 'wypełnia resztę wiersza', 'auto' => 'dopasowana do napisu (węższa)' ) ),
			array( 't' => 'select', 'k' => 'button_align', 'l' => 'Położenie przycisku (przy „dopasowanej”)', 'o' => array( 'left' => 'obok licznika', 'right' => 'do prawej krawędzi' ) ),
			array( 't' => 'number', 'k' => 'button_padding_v', 'l' => 'Odstęp wewnętrzny góra / dół (przy „dopasowanej” decyduje o wysokości)' ),
			array( 't' => 'number', 'k' => 'button_padding_h', 'l' => 'Odstęp wewnętrzny lewo / prawo (przy „dopasowanej” decyduje o szerokości)' ),
			array( 't' => 'number', 'k' => 'button_font_size', 'l' => 'Wielkość czcionki' ),
			array( 't' => 'number', 'k' => 'button_radius', 'l' => 'Zaokrąglenie rogów' ),
			array( 't' => 'color', 'k' => 'button_bg', 'l' => 'Kolor tła (bez najechania)' ),
			array( 't' => 'color', 'k' => 'button_text_color', 'l' => 'Kolor tekstu (bez najechania)' ),
			array( 't' => 'color', 'k' => 'button_border_color', 'l' => 'Kolor obramowania (też akcent okienek)' ),
			array( 't' => 'color', 'k' => 'button_hover_bg', 'l' => 'Kolor tła po najechaniu' ),
			array( 't' => 'color', 'k' => 'button_hover_text', 'l' => 'Kolor tekstu po najechaniu' ),
		) ),
		'hover'   => array( 'Kolory przy najechaniu (produkt i ramki)', array(
			array( 't' => 'note', 'l' => 'Świadomie dwa różne kolory – przy tym samym ramka „znika” na tle podświetlonego wiersza.' ),
			array( 't' => 'color', 'k' => 'row_hover_bg', 'l' => 'Tło całego wiersza produktu' ),
			array( 't' => 'color', 'k' => 'box_hover_bg', 'l' => 'Tło ramki' ),
			array( 't' => 'color', 'k' => 'box_hover_border', 'l' => 'Obramowanie ramki' ),
		) ),
		'allergen' => array( 'Plakietki alergenów', array(
			array( 't' => 'color', 'k' => 'allergen_bg', 'l' => 'Kolor tła' ),
			array( 't' => 'color', 'k' => 'allergen_text', 'l' => 'Kolor tekstu' ),
			array( 't' => 'number', 'k' => 'allergen_radius', 'l' => 'Zaokrąglenie rogów' ),
		) ),
		'boxes'   => array( 'Ramki rozwijane (Harmonogram, Harmonogram dostaw, Pełny opis)', array(
			array( 't' => 'number', 'k' => 'box_border_width', 'l' => 'Grubość ramki', 'step' => 0.5 ),
			array( 't' => 'color', 'k' => 'box_border_color', 'l' => 'Kolor ramki' ),
			array( 't' => 'number', 'k' => 'box_radius', 'l' => 'Zaokrąglenie rogów' ),
			array( 't' => 'number', 'k' => 'box_pad_v', 'l' => 'Odstęp wewnętrzny – góra/dół' ),
			array( 't' => 'number', 'k' => 'box_pad_h', 'l' => 'Odstęp wewnętrzny – boki' ),
			array( 't' => 'color', 'k' => 'box_bg', 'l' => 'Kolor tła', 'toggle' => 1 ),
			array( 't' => 'number', 'k' => 'box_title_size', 'l' => 'Rozmiar tytułu' ),
			array( 't' => 'color', 'k' => 'box_title_color', 'l' => 'Kolor tytułu' ),
			array( 't' => 'check', 'k' => 'box_arrow_on', 'l' => 'Pokazuj strzałkę ▶ przed tytułem' ),
			array( 't' => 'sub', 'l' => 'Każda ramka osobno (puste pole tytułu = tytuł domyślny; tytuły wspólne dla obu widoków)' ),
			array( 't' => 'title', 'k' => 'box_harmono_title', 'l' => 'Tytuł: dni zestawu w menu', 'shared' => 1 ),
			array( 't' => 'check', 'k' => 'box_harmono_border', 'l' => 'Ramka wokół: dni zestawu w menu' ),
			array( 't' => 'number', 'k' => 'harmono_days_back', 'l' => 'Harmonogram – ile minionych dni pokazywać w okienku (0 = bez historii, max 60)', 'u' => 'dni', 'shared' => 1 ),
			array( 't' => 'title', 'k' => 'box_delivery_title', 'l' => 'Tytuł: godziny dostaw produktu', 'shared' => 1 ),
			array( 't' => 'check', 'k' => 'box_delivery_border', 'l' => 'Ramka wokół: godziny dostaw' ),
			array( 't' => 'title', 'k' => 'box_more_title', 'l' => 'Tytuł: pełny opis', 'shared' => 1 ),
			array( 't' => 'check', 'k' => 'box_more_border', 'l' => 'Ramka wokół: pełny opis' ),
			array( 't' => 'title', 'k' => 'box_allergen_title', 'l' => 'Tytuł: alergeny (na telefonie; liczba alergenów dopisuje się sama)', 'shared' => 1 ),
			array( 't' => 'check', 'k' => 'box_allergen_border', 'l' => 'Ramka wokół: alergeny' ),
		) ),
		'qty'     => array( 'Licznik ilości (− 1 +)', array(
			array( 't' => 'check', 'k' => 'qty_border_on', 'l' => 'Ramka wokół licznika (i linie przy − / +)' ),
			array( 't' => 'number', 'k' => 'qty_border_width', 'l' => 'Grubość ramki', 'step' => 0.5 ),
			array( 't' => 'color', 'k' => 'qty_border_color', 'l' => 'Kolor ramki' ),
			array( 't' => 'number', 'k' => 'qty_radius', 'l' => 'Zaokrąglenie rogów licznika' ),
			array( 't' => 'color', 'k' => 'qty_bg', 'l' => 'Tło pola z liczbą' ),
			array( 't' => 'number', 'k' => 'qty_font_size', 'l' => 'Rozmiar liczby' ),
			array( 't' => 'number', 'k' => 'qty_input_width', 'l' => 'Szerokość pola z liczbą (0 = automatycznie)' ),
			array( 't' => 'number', 'k' => 'qty_height', 'l' => 'Wysokość licznika i przycisku „Dodaj do koszyka”' ),
			array( 't' => 'sub', 'l' => 'Przyciski − i +' ),
			array( 't' => 'select', 'k' => 'qty_btn_shape', 'l' => 'Kształt', 'o' => array( 'circle' => 'koło', 'rect' => 'prostokąt' ) ),
			array( 't' => 'number', 'k' => 'qty_circle_size', 'l' => 'Koło: średnica' ),
			array( 't' => 'number', 'k' => 'qty_circle_border_w', 'l' => 'Koło: grubość obwódki (0 = bez)', 'step' => 0.5 ),
			array( 't' => 'color', 'k' => 'qty_circle_border_c', 'l' => 'Koło: kolor obwódki' ),
			array( 't' => 'number', 'k' => 'qty_btn_width', 'l' => 'Prostokąt: szerokość' ),
			array( 't' => 'number', 'k' => 'qty_btn_radius', 'l' => 'Prostokąt: zaokrąglenie rogów' ),
			array( 't' => 'color', 'k' => 'qty_btn_bg', 'l' => 'Kolor tła' ),
			array( 't' => 'color', 'k' => 'qty_btn_text', 'l' => 'Kolor znaku − / +' ),
			array( 't' => 'color', 'k' => 'qty_btn_hover_bg', 'l' => 'Kolor tła po najechaniu' ),
			array( 't' => 'number', 'k' => 'qty_gap', 'l' => 'Odstęp między licznikiem a „Dodaj do koszyka”' ),
			array( 't' => 'note', 'l' => 'Zaokrąglone przyciski − / + wyglądają najlepiej z wyłączoną ramką licznika.' ),
		) ),
		'popup'   => array( 'Okienka (termin dostawy, dostosuj produkt, dodano do koszyka, harmonogram)', array(
			array( 't' => 'number', 'k' => 'popup_opacity', 'l' => 'Krycie tła okienka (30–100; 100 = pełny kolor tła)', 'u' => '%' ),
			array( 't' => 'color', 'k' => 'popup_bg_color', 'l' => 'Kolor tła okienka (taki przy 100 % krycia)' ),
			array( 't' => 'color', 'k' => 'popup_text_color', 'l' => 'Kolor tekstu w okienku (opisy i etykiety – ten sam, trochę jaśniejszy/ciemniejszy)' ),
			array( 't' => 'number', 'k' => 'popup_blur', 'l' => 'Rozmycie strony pod okienkiem (0 = bez)' ),
			array( 't' => 'note', 'l' => 'Im mniejsze krycie, tym bardziej prześwituje strona. Przy kolorowych zdjęciach pod spodem pomaga rozmycie i większa, grubsza czcionka.' ),
			array( 't' => 'sub', 'l' => 'Czcionki' ),
			array( 't' => 'number', 'k' => 'popup_title_size', 'l' => 'Tytuł – rozmiar' ),
			array( 't' => 'weight', 'k' => 'popup_title_weight', 'l' => 'Tytuł – grubość', 'o' => $weight ),
			array( 't' => 'number', 'k' => 'popup_text_size', 'l' => 'Tekst i komunikaty – rozmiar' ),
			array( 't' => 'weight', 'k' => 'popup_text_weight', 'l' => 'Tekst i komunikaty – grubość', 'o' => $weight ),
			array( 't' => 'number', 'k' => 'popup_label_size', 'l' => 'Etykiety pól (Miejscowość, Data…) – rozmiar' ),
			array( 't' => 'weight', 'k' => 'popup_label_weight', 'l' => 'Etykiety pól – grubość', 'o' => $weight ),
			array( 't' => 'number', 'k' => 'popup_tile_size', 'l' => 'Kafelki godzin – rozmiar' ),
			array( 't' => 'weight', 'k' => 'popup_tile_weight', 'l' => 'Kafelki godzin – grubość (wybrany kafelek zawsze gruby)', 'o' => $weight ),
			array( 't' => 'sub', 'l' => 'Przyciski' ),
			array( 't' => 'number', 'k' => 'popup_btn_size', 'l' => 'Rozmiar czcionki' ),
			array( 't' => 'weight', 'k' => 'popup_btn_weight', 'l' => 'Grubość czcionki (główny przycisk o stopień grubszy)', 'o' => $weight ),
			array( 't' => 'number', 'k' => 'popup_btn_pad_v', 'l' => 'Wysokość (odstęp pionowy)' ),
			array( 't' => 'number', 'k' => 'popup_btn_width', 'l' => 'Szerokość każdego z dwóch przycisków (20–48 % okienka)', 'u' => '%' ),
			array( 't' => 'number', 'k' => 'popup_btn_radius', 'l' => 'Zaokrąglenie rogów' ),
		) ),
		'tiles'   => array( 'Kafle kategorii – shortcode [kategorie_zamowien]', array(
			array( 't' => 'check', 'k' => 'tiles_collapse', 'l' => 'Schowaj kafle w rozwijanym polu (kafle pokazują się po kliknięciu)' ),
			array( 't' => 'check', 'k' => 'tiles_collapse_open', 'l' => 'Na start rozwinięte (kafle widać od razu, przycisk pokazuje „Zwiń”)' ),
			array( 't' => 'title', 'k' => 'tiles_collapse_title', 'l' => 'Napis na rozwijanym polu (zwinięte)', 'shared' => 1 ),
			array( 't' => 'title', 'k' => 'tiles_collapse_title_open', 'l' => 'Napis na rozwijanym polu (rozwinięte)', 'shared' => 1 ),
			array( 't' => 'number', 'k' => 'tiles_toggle_size', 'l' => 'Przycisk Rozwiń/Zwiń – wielkość napisu' ),
			array( 't' => 'weight', 'k' => 'tiles_toggle_weight', 'l' => 'Przycisk Rozwiń/Zwiń – grubość napisu', 'o' => $weight ),
			array( 't' => 'select', 'k' => 'tiles_toggle_style', 'l' => 'Przycisk Rozwiń/Zwiń – wygląd', 'o' => array( 'accent' => 'wypełniony, kolory przycisku „Dodaj do koszyka”', 'outline' => 'biały z cienką ramką' ) ),
			array( 't' => 'number', 'k' => 'tiles_wrap_gap', 'l' => 'Odstęp pod całym blokiem kafli' ),
			array( 't' => 'select', 'k' => 'tiles_style', 'l' => 'Wygląd kafla', 'o' => array( 'photo' => 'zdjęcie w tle, napis na zdjęciu', 'below' => 'zdjęcie nad napisem', 'plain' => 'sam napis (bez zdjęcia)' ) ),
			array( 't' => 'number', 'k' => 'tiles_cols', 'l' => 'Kafli w wierszu (1–8)' ),
			array( 't' => 'number', 'k' => 'tiles_gap', 'l' => 'Odstęp między kaflami' ),
			array( 't' => 'number', 'k' => 'tiles_height', 'l' => 'Wysokość kafla (zdjęcie w tle / sam napis)' ),
			array( 't' => 'number', 'k' => 'tiles_radius', 'l' => 'Zaokrąglenie rogów' ),
			array( 't' => 'sub', 'l' => 'Zdjęcie w tle' ),
			array( 't' => 'number', 'k' => 'tiles_blur', 'l' => 'Rozmycie zdjęcia (0 = ostre)' ),
			array( 't' => 'number', 'k' => 'tiles_overlay', 'l' => 'Przyciemnienie zdjęcia (0–90)', 'u' => '%' ),
			array( 't' => 'check', 'k' => 'tiles_hover_zoom', 'l' => 'Lekkie powiększenie zdjęcia po najechaniu' ),
			array( 't' => 'sub', 'l' => 'Napis' ),
			array( 't' => 'number', 'k' => 'tiles_font_size', 'l' => 'Rozmiar czcionki' ),
			array( 't' => 'weight', 'k' => 'tiles_font_weight', 'l' => 'Grubość czcionki', 'o' => $weight ),
			array( 't' => 'color', 'k' => 'tiles_text_color', 'l' => 'Kolor napisu' ),
			array( 't' => 'check', 'k' => 'tiles_upper', 'l' => 'WIELKIE LITERY' ),
			array( 't' => 'sub', 'l' => 'Tło pod napisem (czytelny napis nawet na ostrym zdjęciu)' ),
			array( 't' => 'select', 'k' => 'tiles_label_bg', 'l' => 'Rodzaj', 'o' => array( 'none' => 'brak', 'glow' => 'miękka poświata za napisem', 'pill' => 'zaokrąglona plakietka', 'band' => 'pas na całą szerokość kafla' ) ),
			array( 't' => 'color', 'k' => 'tiles_label_color', 'l' => 'Kolor tła napisu' ),
			array( 't' => 'number', 'k' => 'tiles_label_opacity', 'l' => 'Krycie tła napisu (0–100)', 'u' => '%' ),
			array( 't' => 'number', 'k' => 'tiles_label_blur', 'l' => 'Rozmycie zdjęcia pod napisem – efekt szkła (0 = bez; plakietka i pas)' ),
			array( 't' => 'select', 'k' => 'tiles_label_pos', 'l' => 'Położenie napisu', 'o' => array( 'center' => 'na środku', 'bottom' => 'na dole kafla' ) ),
			array( 't' => 'sub', 'l' => 'Tło i ramka' ),
			array( 't' => 'color', 'k' => 'tiles_bg', 'l' => 'Tło kafla (sam napis; przy zdjęciu w tle – gdy kategoria nie ma zdjęcia)' ),
			array( 't' => 'check', 'k' => 'tiles_border', 'l' => 'Ramka wokół kafla' ),
			array( 't' => 'color', 'k' => 'tiles_border_color', 'l' => 'Kolor ramki' ),
			array( 't' => 'note', 'l' => 'Zdjęcie kafla to zdjęcie kategorii z Produkty → Kategorie → Edytuj → Zdjęcie. Tam też jest „Adres docelowy”, pod który prowadzi kafel.' ),
		) ),
		'shop'    => array( 'Strony sklepu WooCommerce (kategorie, sklep, podobne produkty)', array(
			array( 't' => 'check', 'k' => 'shop_on', 'l' => 'Stosuj nasz wygląd na stronach sklepu (wyłączone = wygląd motywu)' ),
			array( 't' => 'check', 'k' => 'shop_center', 'l' => 'Wyrównaj do środka (zdjęcie, kategoria, nazwa, cena, przycisk)' ),
			array( 't' => 'check', 'k' => 'shop_hide_count', 'l' => 'Ukryj „Wyświetlanie wszystkich wyników: …”' ),
			array( 't' => 'check', 'k' => 'shop_hide_sort', 'l' => 'Ukryj „Domyślne sortowanie” (wybór kolejności)' ),
			array( 't' => 'check', 'k' => 'shop_grid_center', 'l' => 'Wyśrodkuj produkty w rzędzie (gdy w kategorii jest mniej produktów niż kolumn, stoją na środku, nie przy lewej krawędzi)', 'shared' => 1 ),
			array( 't' => 'check', 'k' => 'shop_equal', 'l' => 'Równe kafle – ceny i przyciski „Dodaj do koszyka” w jednej linii (nawet gdy nazwa ma kilka wierszy)' ),
			array( 't' => 'title', 'k' => 'shop_related_title', 'l' => 'Nagłówek nad produktami pod kartą produktu (zamiast „Podobne produkty”; puste pole = „Zamów razem”)', 'shared' => 1 ),
			array( 't' => 'number', 'k' => 'shop_img_radius', 'l' => 'Zaokrąglenie rogów zdjęć' ),
			array( 't' => 'number', 'k' => 'shop_card_gap', 'l' => 'Odstęp między zdjęciem, nazwą, ceną i przyciskiem' ),
			array( 't' => 'number', 'k' => 'shop_name_size', 'l' => 'Nazwa produktu – rozmiar' ),
			array( 't' => 'weight', 'k' => 'shop_name_weight', 'l' => 'Nazwa produktu – grubość', 'o' => $weight ),
			array( 't' => 'number', 'k' => 'shop_price_size', 'l' => 'Cena – rozmiar' ),
			array( 't' => 'color', 'k' => 'shop_price_color', 'l' => 'Cena – kolor', 'toggle' => 1 ),
			array( 't' => 'check', 'k' => 'shop_btn_style', 'l' => 'Przycisk „Dodaj do koszyka” w stylu listy (kolory, odstępy, zaokrąglenie, czcionka z sekcji „Przycisk »Dodaj do koszyka«”)' ),
			array( 't' => 'check', 'k' => 'shop_btn_full', 'l' => 'Przycisk na całą szerokość kafla' ),
			array( 't' => 'check', 'k' => 'gb_btn_style', 'l' => 'Pozostałe przyciski w stylu listy: blok „Przyciski” z edytora stron (np. „Idź do koszyka”), w koszyku „Wróć do listy produktów” i „Przejdź do płatności”, w kasie „Kupuję i płacę”' ),
		) ),
		'single'  => array( 'Strona produktu', array(
			array( 't' => 'check', 'k' => 'single_on', 'l' => 'Stosuj nasz wygląd na stronie produktu (wyłączone = wygląd motywu)', 'shared' => 1 ),
			array( 't' => 'check', 'k' => 'single_buy', 'l' => 'Licznik ilości (− / +) i przycisk „Dodaj do koszyka” jak na liście', 'shared' => 1 ),
			array( 't' => 'check', 'k' => 'single_one_title', 'l' => 'Jeden tytuł (ukryj tytuł motywu, gdy wtyczka pokazuje własny – np. nazwa zestawu)', 'shared' => 1 ),
			array( 't' => 'check', 'k' => 'single_layout', 'l' => 'Układ: wszystko do lewej, na dole kolumny ilość, a pod nią „Dodaj do koszyka”' ),
			array( 't' => 'check', 'k' => 'single_harmono', 'l' => 'Pokaż „Harmonogram” przy zestawach (to samo okienko co na liście)', 'shared' => 1 ),
			array( 't' => 'select', 'k' => 'single_head_align', 'l' => 'Nazwa i cena – wyrównanie', 'o' => array( 'left' => 'do lewej', 'center' => 'do środka', 'right' => 'do prawej' ) ),
			array( 't' => 'select', 'k' => 'single_buy_stack', 'l' => 'Ilość i „Dodaj do koszyka”', 'o' => array( 'stack' => 'ilość nad przyciskiem, do lewej', 'center' => 'ilość nad przyciskiem, wyśrodkowane', 'row' => 'obok siebie (przycisk wypełnia resztę)' ) ),
			array( 't' => 'number', 'k' => 'single_qty_size', 'l' => 'Przyciski − / + – średnica (0 = jak na liście)' ),
			array( 't' => 'number', 'k' => 'single_qty_font', 'l' => 'Liczba sztuk – rozmiar (0 = jak na liście)' ),
			array( 't' => 'number', 'k' => 'single_btn_width', 'l' => '„Dodaj do koszyka” – szerokość (0 = automatycznie)', 'u' => '%' ),
			array( 't' => 'number', 'k' => 'single_btn_height', 'l' => '„Dodaj do koszyka” – wysokość (0 = automatycznie)' ),
			array( 't' => 'select', 'k' => 'single_tabs_line', 'l' => 'Kreska nad zakładkami (Opis / Opinie)', 'o' => array( 'accent' => 'cienka, w kolorze przycisków', 'dark' => 'cienka, czarna', 'theme' => 'jak motyw' ) ),
			array( 't' => 'check', 'k' => 'single_tab_cat', 'l' => 'Zakładka „Opis” nazywa się jak kategoria produktu (np. „Bajgle”)', 'shared' => 1 ),
			array( 't' => 'check', 'k' => 'single_tab_catdesc', 'l' => 'W zakładce: opis kategorii, pod nim nazwa produktu (zamiast „O produkcie”) i opis produktu', 'shared' => 1 ),
			array( 't' => 'check', 'k' => 'single_img_square', 'l' => 'Zdjęcie w kwadracie (przycięte do środka)' ),
			array( 't' => 'number', 'k' => 'single_img_radius', 'l' => 'Zaokrąglenie rogów zdjęcia (999 = koło)' ),
			array( 't' => 'number', 'k' => 'single_thumb_radius', 'l' => 'Zaokrąglenie miniaturek galerii (999 = koła)' ),
			array( 't' => 'number', 'k' => 'single_title_size', 'l' => 'Tytuł – rozmiar (0 = jak motyw)' ),
			array( 't' => 'number', 'k' => 'single_price_size', 'l' => 'Cena – rozmiar (0 = jak motyw)' ),
			array( 't' => 'number', 'k' => 'single_head_gap', 'l' => 'Odstęp między nazwą a ceną (0 = jak motyw)' ),
			array( 't' => 'color', 'k' => 'single_price_color', 'l' => 'Cena – kolor', 'toggle' => 1 ),
			array( 't' => 'note', 'l' => 'Wygląd licznika i przycisku bierze się z sekcji „Licznik ilości” i „Przycisk »Dodaj do koszyka«” – zmieniasz raz, działa na liście i na stronie produktu. „Podobne produkty” pod produktem mają wygląd z sekcji „Strony sklepu WooCommerce”.' ),
		) ),
		'gap'     => array( 'Odstępy', array(
			array( 't' => 'number', 'k' => 'element_gap', 'l' => 'Odstęp między elementami pod zdjęciem (alergeny, ramki, licznik, opis)' ),
		) ),
	);
}

// Klucze sekcji, które telefon może mieć inaczej (bez pól wspólnych).
function rzd_style_section_keys( $fields ) {
	$keys = array();
	foreach ( $fields as $f ) {
		if ( empty( $f['k'] ) || ! empty( $f['shared'] ) ) {
			continue;
		}
		$keys[] = $f['k'];
		if ( ! empty( $f['toggle'] ) ) {
			$keys[] = $f['k'] . '_on';
		}
	}
	return $keys;
}

// Tytuły ramek rozwijanych: 'harmono' | 'delivery' | 'more'.
function rzd_list_label( $which ) {
	$s   = rzd_list_style_get();
	$key = 'box_' . $which . '_title';
	if ( isset( $s[ $key ] ) && '' !== trim( (string) $s[ $key ] ) ) {
		return (string) $s[ $key ];
	}
	$d = rzd_list_style_defaults();
	return isset( $d[ $key ] ) ? $d[ $key ] : '';
}

/**
 * Migracja do 2.26.0: przed nią wartości bazowe były TELEFONEM, a pola
 * *_desktop komputerem (tylko rozmiary czcionek i zdjęcie). Teraz baza =
 * komputer, telefon = m_*. Przenosimy dokładnie te same liczby, więc wygląd
 * na obu urządzeniach się nie zmienia.
 */
function rzd_list_style_migrate_v2( $saved ) {
	$pairs = array(
		'name_size'    => array( 'name_size_desktop', 20 ),
		'cat_size'     => array( 'cat_size_desktop', 26 ),
		'price_size'   => array( 'price_size_desktop', 28 ),
		'desc_size'    => array( 'desc_size_desktop', 14 ),
		'image_size'   => array( 'image_size_desktop', 160 ),
		'image_radius' => array( 'image_radius_desktop', 16 ),
	);
	foreach ( $pairs as $k => $d ) {
		if ( isset( $saved[ $k ] ) ) {
			$saved[ 'm_' . $k ] = $saved[ $k ]; // telefon = dotychczasowa wartość bazowa
		}
		$saved[ $k ] = isset( $saved[ $d[0] ] ) ? $saved[ $d[0] ] : $d[1]; // komputer = dotychczasowe *_desktop
		unset( $saved[ $d[0] ] );
	}
	foreach ( array( 'name', 'cat', 'price', 'desc', 'image' ) as $sid ) {
		$saved[ 'm_on_' . $sid ] = 1;
	}
	$saved['style_v'] = 2;
	return $saved;
}

function rzd_list_style_get( $fresh = false ) {
	// wynik trzymany na czas żądania – funkcję woła każdy wiersz listy
	// (etykiety ramek), strona produktu, okienka… a wp_parse_args na ~250
	// ustawieniach to niepotrzebna praca przy każdym wywołaniu.
	static $memo = null;
	if ( null !== $memo && ! $fresh ) {
		return $memo;
	}
	$saved = get_option( 'rzd_list_style', array() );
	$saved = is_array( $saved ) ? $saved : array();
	if ( $saved && ( empty( $saved['style_v'] ) || (int) $saved['style_v'] < 3 ) ) {
		$saved['style_v'] = isset( $saved['style_v'] ) ? $saved['style_v'] : 0;
		if ( empty( $saved['style_v'] ) ) {
			$saved = rzd_list_style_migrate_v2( $saved );
		}
		// v3: pole rozmiaru ceny wreszcie działa (wcześniej plik CSS
		// wymuszał 34 px z !important) – ustawiamy 34 px, czyli to, co klienci
		// faktycznie widzieli, na obu urządzeniach.
		if ( (int) ( isset( $saved['style_v'] ) ? $saved['style_v'] : 0 ) < 3 ) {
			$saved['price_size']   = 34;
			$saved['m_price_size'] = 34;
		}
		$saved['style_v'] = 3;
	}
	// v4: uzgodnione zmiany wyglądu – „Możliwe dostawy” (tylko gdy tytuł
	// był domyślny), okrągłe − / + bez ramki licznika, większy odstęp do „Dodaj”.
	if ( $saved && (int) $saved['style_v'] < 4 ) {
		if ( ! isset( $saved['box_delivery_title'] ) || 'Harmonogram dostaw dla produktu' === $saved['box_delivery_title'] ) {
			$saved['box_delivery_title'] = 'Możliwe dostawy';
		}
		$saved['qty_btn_shape'] = 'circle';
		$saved['qty_border_on'] = 0;
		if ( ! isset( $saved['qty_gap'] ) || 10 == $saved['qty_gap'] ) { // phpcs:ignore
			$saved['qty_gap'] = 16;
		}
		$saved['style_v'] = 4;
		update_option( 'rzd_list_style', $saved, true );
	}
	// v5: rozwijane pole kafli – „Rozwiń” / „Zwiń” zamiast „Kategorie menu”
	// (tylko gdy napis był domyślny; własny napis zostaje).
	if ( $saved && (int) $saved['style_v'] < 5 ) {
		if ( ! isset( $saved['tiles_collapse_title'] ) || 'Kategorie menu' === $saved['tiles_collapse_title'] ) {
			$saved['tiles_collapse_title'] = 'Rozwiń';
		}
		$saved['style_v'] = 5;
		update_option( 'rzd_list_style', $saved, true );
	}
	$memo = wp_parse_args( $saved, rzd_list_style_defaults() );
	return $memo;
}

// Wartości dla urządzenia: 'desktop' = baza; 'mobile' = baza + sekcje „inaczej”.
function rzd_style_for_device( $s, $device ) {
	if ( 'mobile' !== $device ) {
		return $s;
	}
	foreach ( rzd_list_style_fields() as $sid => $sec ) {
		if ( empty( $s[ 'm_on_' . $sid ] ) ) {
			continue;
		}
		foreach ( rzd_style_section_keys( $sec[1] ) as $k ) {
			if ( isset( $s[ 'm_' . $k ] ) ) {
				$s[ $k ] = $s[ 'm_' . $k ];
			}
		}
	}
	return $s;
}

/**
 * rozbija cenę z WooCommerce na części, które da się osobno stylować:
 * <bdi class="rl-pbdi"><span class="rl-pnum">12<span class="rl-pdec">,00</span></span>
 * <span class="woocommerce-Price-currencySymbol">zł</span></bdi>. Działa też
 * dla promocji (<del>/<ins>) i zakresów cen – każda kwota osobno. Kolejność
 * liczba/waluta zostaje taka, jak w ustawieniach sklepu.
 */
function rzd_price_split_html( $html ) {
	$dec = function_exists( 'wc_get_price_decimal_separator' ) ? wc_get_price_decimal_separator() : ',';
	return preg_replace_callback( '#<bdi>(.*?)</bdi>#s', function ( $m ) use ( $dec ) {
		// waluta rozpoznawana po samej klasie (dowolne inne atrybuty/cudzysłowy).
		$cur_re = '#(<span[^>]*class=["\'][^"\']*woocommerce-Price-currencySymbol[^"\']*["\'][^>]*>.*?</span>)#s';
		$parts  = preg_split( $cur_re, $m[1], -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY );
		$out    = '';
		foreach ( (array) $parts as $part ) {
			if ( preg_match( '#^<span[^>]*woocommerce-Price-currencySymbol#', $part ) ) {
				$out .= '<span class="woocommerce-Price-currencySymbol">' . wp_strip_all_tags( $part ) . '</span>';
				continue;
			}
			$t = trim( str_replace( array( '&nbsp;', "\xC2\xA0" ), ' ', $part ) );
			if ( '' === $t ) {
				continue;
			}
			$pos = ( '' !== $dec && false === strpos( $t, '<' ) ) ? strrpos( $t, $dec ) : false;
			if ( false !== $pos ) {
				$t = substr( $t, 0, $pos ) . '<span class="rl-pdec">' . substr( $t, $pos ) . '</span>';
			}
			$out .= '<span class="rl-pnum">' . $t . '</span>';
		}
		return '<bdi class="rl-pbdi">' . $out . '</bdi>';
	}, (string) $html );
}

/**
 * cena składana od zera z liczby (bez parsowania HTML motywu/wtyczek):
 * <span class="woocommerce-Price-amount amount"><bdi class="rl-pbdi">
 *   <span class="rl-pnum">22<span class="rl-pdec">,00</span></span>
 *   <span class="woocommerce-Price-currencySymbol">zł</span></bdi></span>
 * Kolejność liczba/waluta wg ustawienia sklepu (Waluta → Pozycja).
 */
function rzd_price_parts_html( $amount ) {
	$amount = (float) $amount;
	$decs   = function_exists( 'wc_get_price_decimals' ) ? wc_get_price_decimals() : 2;
	$dsep   = function_exists( 'wc_get_price_decimal_separator' ) ? wc_get_price_decimal_separator() : ',';
	$tsep   = function_exists( 'wc_get_price_thousand_separator' ) ? wc_get_price_thousand_separator() : ' ';
	$num    = number_format( abs( $amount ), $decs, $dsep, $tsep );
	$int    = $num;
	$frac   = '';
	if ( $decs > 0 && '' !== $dsep && false !== ( $pos = strrpos( $num, $dsep ) ) ) {
		$int  = substr( $num, 0, $pos );
		$frac = substr( $num, $pos );
	}
	$pnum = '<span class="rl-pnum">' . ( $amount < 0 ? '-' : '' ) . esc_html( $int ) . ( '' !== $frac ? '<span class="rl-pdec">' . esc_html( $frac ) . '</span>' : '' ) . '</span>';
	$pcur = '<span class="woocommerce-Price-currencySymbol">' . ( function_exists( 'get_woocommerce_currency_symbol' ) ? get_woocommerce_currency_symbol() : 'zł' ) . '</span>';
	$left = in_array( get_option( 'woocommerce_currency_pos', 'right_space' ), array( 'left', 'left_space' ), true );
	return '<span class="woocommerce-Price-amount amount"><bdi class="rl-pbdi">' . ( $left ? $pcur . $pnum : $pnum . $pcur ) . '</bdi></span>';
}

/**
 * Cena produktu na liście: zwykła cena – składana od zera (pewne części do
 * stylowania); promocja, zakres cen (warianty), grupowy – HTML WooCommerce
 * rozbity przez rzd_price_split_html().
 */
function rzd_list_price_html( $p ) {
	if ( ! $p || '' === (string) $p->get_price() ) {
		return $p ? $p->get_price_html() : '';
	}
	if ( $p->is_on_sale() || $p->is_type( array( 'variable', 'grouped' ) ) ) {
		return rzd_price_split_html( $p->get_price_html() );
	}
	$html = rzd_price_parts_html( wc_get_price_to_display( $p ) );
	return apply_filters( 'rzd_list_price_html', $html . $p->get_price_suffix(), $p );
}

