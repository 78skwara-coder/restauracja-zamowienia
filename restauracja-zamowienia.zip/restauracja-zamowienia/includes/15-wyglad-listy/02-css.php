<?php
/**
 * Moduł 15-wyglad-listy – generowanie CSS z ustawień.
 * Część modułu (pliki wczytywane po kolei – kolejność jak w dawnym jednym pliku).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 2. GENEROWANIE CSS Z USTAWIEŃ
 * ============================================================ */
// Granica telefon/komputer – ta sama co przed 2.26.0.
define( 'RZD_STYLE_BREAKPOINT', 900 );

function rzd_list_style_css() {
	$s  = rzd_list_style_get();
	$bp = RZD_STYLE_BREAKPOINT;
	$any_mobile = false;
	foreach ( array_keys( rzd_list_style_fields() ) as $sid ) {
		if ( ! empty( $s[ 'm_on_' . $sid ] ) ) {
			$any_mobile = true;
			break;
		}
	}
	if ( ! $any_mobile ) {
		return rzd_list_style_rules( $s ); // telefon = komputer: jeden zestaw reguł
	}
	// Dwa rozłączne zakresy: „not all and (min-width)” to dokładne dopełnienie –
	// bez dziury przy ułamkowych szerokościach (zoom przeglądarki).
	return "@media (min-width: {$bp}px) {\n" . rzd_list_style_rules( rzd_style_for_device( $s, 'desktop' ) ) . "}\n"
		. "@media not all and (min-width: {$bp}px) {\n" . rzd_list_style_rules( rzd_style_for_device( $s, 'mobile' ) ) . "}\n";
}

// Reguły dla JEDNEGO urządzenia (bez @media) – $s już rozwiązane.
function rzd_list_style_rules( $s ) {
	$css = '';

	// Czcionki + odstęp liter (nazwa produktu i nagłówek kategorii)
	$css .= ".rl-name, .rl-cat-heading { font-family: '" . esc_attr( $s['heading_font'] ) . "', Georgia, serif; letter-spacing: " . esc_attr( $s['letter_spacing'] ) . "px; }\n";
	$css .= ".rl { font-family: '" . esc_attr( $s['body_font'] ) . "', -apple-system, BlinkMacSystemFont, sans-serif; }\n";

	$css .= ".rl-name { font-size: " . (float) $s['name_size'] . "px; }\n";
	if ( (float) $s['name_gap'] > 0 ) { // odstęp pod nazwą (np. nad zdjęciem na telefonie)
		$css .= ".rl2-row > .rl-name, .rl-name { margin-bottom: " . (float) $s['name_gap'] . "px !important; }\n";
	}
	if ( ! empty( $s['name_color_on'] ) ) {
		$css .= ".rl-name { color: " . esc_attr( $s['name_color'] ) . " !important; }\n";
	}
	$css .= ".rl-cat-heading { font-size: " . (float) $s['cat_size'] . "px; }\n";
	if ( ! empty( $s['cat_color_on'] ) ) {
		$css .= ".rl-cat-heading { color: " . esc_attr( $s['cat_color'] ) . "; }\n";
	}
	$css .= ".rl-price, .rl2-row > .rl-price { font-size: " . (float) $s['price_size'] . "px; }\n";
	if ( ! empty( $s['price_color_on'] ) ) {
		$css .= ".rl-price { color: " . esc_attr( $s['price_color'] ) . "; }\n";
	}
	// części ceny (rzd_price_split_html): .rl-pnum = liczba, .rl-pdec = grosze,
	// .woocommerce-Price-currencySymbol = waluta; .rl-pbdi = całość jednej kwoty.
	$cur_pct = max( 20, min( 200, (float) $s['price_cur_size'] ) ) / 100;
	$dec_pct = max( 20, min( 200, (float) $s['price_dec_size'] ) ) / 100;
	$css .= ".rl-price .rl-pbdi { display: inline-flex; align-items: baseline; gap: " . ( (float) $s['price_cur_gap'] > 0 ? (float) $s['price_cur_gap'] . 'px' : '.12em' ) . "; white-space: nowrap; }\n";
	$css .= ".rl-price .rl-pnum { line-height: 1; }\n";
	$css .= ".rl-price .rl-pbdi .woocommerce-Price-currencySymbol { font-size: {$cur_pct}em; line-height: 1; }\n";
	$css .= ".rl-price .rl-pdec { font-size: {$dec_pct}em; }\n";
	if ( 'top' === $s['price_dec_align'] ) {
		$css .= ".rl-price .rl-pdec { vertical-align: top; line-height: 1; }\n";
	}
	$cgap = (float) $s['price_cur_gap'];
	if ( in_array( $s['price_cur_pos'], array( 'below', 'above' ), true ) ) {
		$ai = array( 'left' => 'flex-start', 'center' => 'center', 'right' => 'flex-end' );
		$al = isset( $ai[ $s['price_cur_align'] ] ) ? $ai[ $s['price_cur_align'] ] : 'center';
		$css .= ".rl-price .rl-pbdi { flex-direction: column; align-items: {$al}; gap: " . ( $cgap > 0 ? $cgap . 'px' : '.05em' ) . "; }\n";
		$css .= ".rl-price .rl-pbdi .woocommerce-Price-currencySymbol { order: " . ( 'above' === $s['price_cur_pos'] ? '-1' : '2' ) . "; }\n";
	}
	if ( $s['desc_font'] ) {
		$css .= ".rl-short { font-family: '" . esc_attr( $s['desc_font'] ) . "', -apple-system, BlinkMacSystemFont, sans-serif; }\n";
	}
	$css .= ".rl-short { font-size: " . (float) $s['desc_size'] . "px; }\n";
	if ( ! empty( $s['desc_color_on'] ) ) {
		$css .= ".rl-short { color: " . esc_attr( $s['desc_color'] ) . "; }\n";
	}

	// Zdjęcie
	$css .= ".rl-thumb, .rl-thumb img { width: " . (int) $s['image_size'] . "px !important; height: " . (int) $s['image_size'] . "px !important; flex-basis: " . (int) $s['image_size'] . "px !important; }\n";
	$css .= ".rl-thumb img { border-radius: " . (int) $s['image_radius'] . "px !important; }\n";

	// Przycisk "Dodaj do koszyka" (bez − / + licznika)
	$css .= ".rl-buy button:not(.rl2-qty-btn), .rl-choose, .rl-addon button {\n"
		. "\tpadding: " . (int) $s['button_padding_v'] . "px " . (int) $s['button_padding_h'] . "px !important;\n"
		. "\tborder-radius: " . (int) $s['button_radius'] . "px !important;\n"
		. "\tfont-size: " . max( 10, (float) $s['button_font_size'] ) . "px !important;\n"
		. "\tbackground: " . esc_attr( $s['button_bg'] ) . " !important;\n"
		. "\tcolor: " . esc_attr( $s['button_text_color'] ) . " !important;\n"
		. "\tborder-color: " . esc_attr( $s['button_border_color'] ) . " !important;\n"
		. "}\n";
	$css .= ".rl-buy button:not(.rl2-qty-btn):hover, .rl-choose:hover, .rl-addon button:hover {\n"
		. "\tbackground: " . esc_attr( $s['button_hover_bg'] ) . " !important;\n"
		. "\tcolor: " . esc_attr( $s['button_hover_text'] ) . " !important;\n"
		. "}\n";

	// „dopasowana do napisu” – przycisk nie rozciąga się na resztę wiersza
	// (flex: 1 z pliku CSS), a wysokość wynika z odstępów góra/dół zamiast z
	// wysokości licznika. Licznik i przycisk zostają wyśrodkowane w pionie.
	if ( 'auto' === ( isset( $s['button_width'] ) ? $s['button_width'] : 'fill' ) ) {
		$css .= ".rl-buy button:not(.rl2-qty-btn), .rl-choose, .rl-addon button, .rl2-order .rl-buy button:not(.rl2-qty-btn), .rl2-order .rl-choose { flex: 0 0 auto !important; width: auto !important; min-height: 0 !important; white-space: nowrap; }\n";
		$css .= ".rl2-order .rl-buy { align-items: center; }\n";
		if ( 'right' === ( isset( $s['button_align'] ) ? $s['button_align'] : 'left' ) ) {
			// licznik po lewej, przycisk dosunięty do prawej krawędzi wiersza.
			$css .= ".rl2-order .rl-buy { max-width: none !important; width: 100%; }\n";
			$css .= ".rl-buy button:not(.rl2-qty-btn), .rl2-order .rl-buy button:not(.rl2-qty-btn), .rl2-order .rl-choose { margin-left: auto !important; }\n";
		}
	}

	// Hover wiersza i ramek
	$css .= ".rl2-row:hover, .rl2-row:active { background: " . esc_attr( $s['row_hover_bg'] ) . "; }\n";
	$css .= ".rl2-rest .rl-harmono:hover, .rl .rl2-delivery:hover, .rl2-bottom .rl-more:hover, .rl .rl2-allergen-box:hover {\n"
		. "\tbackground: " . esc_attr( $s['box_hover_bg'] ) . ";\n"
		. "\tborder-color: " . esc_attr( $s['box_hover_border'] ) . ";\n"
		. "}\n";

	// Alergeny
	$css .= ".rl-alergen { background: " . esc_attr( $s['allergen_bg'] ) . "; color: " . esc_attr( $s['allergen_text'] ) . "; border-radius: " . (int) $s['allergen_radius'] . "px; }\n";

	$css .= rzd_list_boxes_qty_css( $s );
	$css .= rzd_tiles_css( $s ); // kafle kategorii (moduł 17)
	$css .= rzd_shop_css( $s );  // strony sklepu WooCommerce
	$css .= rzd_single_css( $s ); // strona produktu
	$css .= rzd_popup_css( $s );

	return $css;
}

/**
 * ramki rozwijane, licznik ilości, odstępy. Selektory o wyższej
 * specyficzności niż plik CSS (moduł 03), a przy liczniku z !important, bo
 * plik ma !important na przyciskach w formularzu zakupu.
 */
/**
 * kafle kategorii [kategorie_zamowien] (moduł 17). Wcześniej sztywny
 * <style> w shortcodzie (2 w wierszu / 4 od 900 px) – teraz z panelu, osobno
 * telefon i komputer. Znaczniki: .rk-grid > a.rk-tile(.rk-noimg) > .rk-tile-img + .rk-tile-name.
 */
function rzd_tiles_css( $s ) {
	$num   = function ( $k, $min, $max ) use ( $s ) { return max( $min, min( $max, (float) $s[ $k ] ) ); };
	$style = in_array( $s['tiles_style'], array( 'photo', 'below', 'plain' ), true ) ? $s['tiles_style'] : 'below';
	$cols  = (int) $num( 'tiles_cols', 1, 8 );
	$gap   = $num( 'tiles_gap', 0, 60 );
	$h     = $num( 'tiles_height', 30, 400 );
	$r     = $num( 'tiles_radius', 0, 200 );
	$fs    = $num( 'tiles_font_size', 9, 40 );
	$fw    = '' !== (string) $s['tiles_font_weight'] ? ' font-weight: ' . esc_attr( $s['tiles_font_weight'] ) . ';' : '';
	$col   = esc_attr( $s['tiles_text_color'] );
	$bg    = esc_attr( $s['tiles_bg'] );
	$brd   = ! empty( $s['tiles_border'] ) ? '1.5px solid ' . esc_attr( $s['tiles_border_color'] ) : '0';
	$zoom  = ! empty( $s['tiles_hover_zoom'] );
	$c     = '';
	$c .= ".rk-grid { display: grid; grid-template-columns: repeat({$cols}, minmax(0, 1fr)); gap: {$gap}px; }\n";
	// rozwijane pole „Kategorie menu” (wygląd jak ramki rozwijane listy).
	$c .= '.rk-wrap { margin: 0 0 ' . $num( 'tiles_wrap_gap', 0, 80 ) . "px; }\n";
	if ( ! empty( $s['tiles_collapse'] ) ) {
		// napis wyśrodkowany, strzałka ▼ przed i za; po rozwinięciu strzałki ▲ i napis „Zwiń”.
		// większy, czytelniejszy przycisk (wielkość/grubość/wygląd z panelu); domyślnie w kolorach „Dodaj do koszyka”.
		$tsz    = max( 12, min( 30, (float) ( isset( $s['tiles_toggle_size'] ) ? $s['tiles_toggle_size'] : 18 ) ) );
		$twt    = ( isset( $s['tiles_toggle_weight'] ) && '' !== (string) $s['tiles_toggle_weight'] ) ? esc_attr( $s['tiles_toggle_weight'] ) : '700';
		$accent = ! isset( $s['tiles_toggle_style'] ) || 'outline' !== $s['tiles_toggle_style'];
		$tcol   = $accent
			? 'border: 2px solid ' . esc_attr( $s['button_border_color'] ) . ' !important; background: ' . esc_attr( $s['button_bg'] ) . ' !important; color: ' . esc_attr( $s['button_text_color'] ) . ' !important;'
			: 'border: 1.5px solid #dcdcdc !important; background: #fff !important; color: #2b2b2b !important;';
		$c .= ".rk-toggle { display: flex !important; align-items: center; justify-content: center; gap: 12px; width: 100%; box-sizing: border-box; margin: 0; min-height: 52px; padding: 12px 16px; {$tcol} border-radius: {$r}px; font: inherit; font-size: {$tsz}px !important; font-weight: {$twt} !important; line-height: 1.2; letter-spacing: .02em; text-align: center; cursor: pointer; box-shadow: none !important; text-transform: none; transition: background .15s, border-color .15s, color .15s; }\n";
		$c .= ".rk-wrap .rk-lbl-open, .rk-wrap.is-open .rk-lbl-closed { display: none; }\n.rk-wrap.is-open .rk-lbl-open { display: inline; }\n";
		$c .= $accent
			? ".rk-toggle:hover, .rk-toggle:focus { background: " . esc_attr( $s['button_hover_bg'] ) . ' !important; color: ' . esc_attr( $s['button_hover_text'] ) . " !important; }\n"
			: ".rk-toggle:hover, .rk-toggle:focus { background: " . esc_attr( $s['box_hover_bg'] ) . ' !important; border-color: ' . esc_attr( $s['box_hover_border'] ) . " !important; }\n";
		$c .= ".rk-arrow { display: inline-block; font-size: .85em; transition: transform .2s; }\n.rk-wrap.is-open .rk-arrow { transform: rotate(180deg); }\n";
		$c .= ".rk-wrap:not(.is-open) .rk-panel { display: none; }\n.rk-wrap.is-open .rk-panel { display: block; margin-top: 10px; }\n";
		if ( ! empty( $s['tiles_collapse_open'] ) ) {
			// stan startowy „rozwinięte” (klasa rk-init do pierwszego kliknięcia; osobno telefon/komputer).
			$c .= ".rk-wrap.rk-init .rk-panel { display: block; margin-top: 10px; }\n.rk-wrap.rk-init .rk-lbl-closed { display: none; }\n.rk-wrap.rk-init .rk-lbl-open { display: inline; }\n.rk-wrap.rk-init .rk-arrow { transform: rotate(180deg); }\n";
		}
	} else {
		$c .= ".rk-toggle { display: none !important; }\n.rk-panel { display: block !important; margin-top: 0 !important; }\n";
	}
	$c .= ".rk-tile { position: relative; overflow: hidden; display: flex; align-items: center; justify-content: center; text-align: center; box-sizing: border-box; text-decoration: none !important; color: {$col} !important; font-size: {$fs}px;{$fw} line-height: 1.25; border-radius: {$r}px; transition: background .15s, border-color .15s; }\n";
	$c .= ".rk-tile-name { position: relative; z-index: 2; padding: 0 8px; overflow-wrap: anywhere; }\n";
	if ( ! empty( $s['tiles_upper'] ) ) {
		$c .= ".rk-tile-name { text-transform: uppercase; letter-spacing: .04em; }\n";
	}
	if ( 'below' === $style ) {
		$c .= ".rk-tile { flex-direction: column; justify-content: flex-start; padding: 0; min-height: 0; border: 0; border-radius: 0; background: transparent; }\n";
		$c .= ".rk-tile-img { display: block; position: static; width: 100%; aspect-ratio: 1 / 1; margin-bottom: 10px; overflow: hidden; border-radius: {$r}px; border: {$brd}; box-sizing: border-box; background: {$bg}; }\n";
		$c .= ".rk-tile-img img { display: block; width: 100%; height: 100%; object-fit: cover; filter: none; transform: none; transition: transform .2s; }\n";
		if ( $zoom ) {
			$c .= ".rk-tile:hover .rk-tile-img img { transform: scale(1.04); }\n";
		}
	} elseif ( 'photo' === $style ) {
		$blur = $num( 'tiles_blur', 0, 30 );
		$ov   = $num( 'tiles_overlay', 0, 90 ) / 100;
		$ovh  = min( .95, $ov + .15 );
		$sc   = $blur > 0 ? 1.12 : 1; // przy rozmyciu lekko powiększone – bez jasnych brzegów
		$c .= ".rk-tile { min-height: {$h}px; padding: 12px 8px; border: {$brd}; background: {$bg}; text-shadow: 0 1px 3px rgba(0,0,0,.45); }\n";
		$c .= ".rk-tile-img { display: block; position: absolute; inset: 0; z-index: 0; margin: 0; }\n";
		$c .= ".rk-tile-img img { display: block; width: 100%; height: 100%; max-width: none; object-fit: cover; filter: blur({$blur}px); transform: scale({$sc}); transition: transform .25s; }\n";
		$c .= ".rk-tile::after { content: ''; position: absolute; inset: 0; z-index: 1; background: rgba(0,0,0,{$ov}); transition: background .2s; }\n";
		$c .= ".rk-tile.rk-noimg::after { content: none; }\n";
		$c .= ".rk-tile:hover::after { background: rgba(0,0,0,{$ovh}); }\n";
		if ( $zoom ) {
			$c .= ".rk-tile:hover .rk-tile-img img { transform: scale(" . ( $sc + .06 ) . "); }\n";
		}
	}
	if ( 'plain' === $style ) {
		$c .= ".rk-tile { min-height: {$h}px; padding: 14px 10px; border: {$brd}; background: {$bg}; }\n";
		$c .= ".rk-tile:hover { background: " . esc_attr( $s['button_bg'] ) . "; border-color: " . esc_attr( $s['button_border_color'] ) . "; }\n";
		$c .= ".rk-tile-img { display: none; }\n";
	}
	// tło pod samym napisem (zdjęcie w tle / sam napis) – zdjęcie może być w pełni ostre.
	$lbg = in_array( $s['tiles_label_bg'], array( 'none', 'glow', 'pill', 'band' ), true ) ? $s['tiles_label_bg'] : 'none';
	if ( 'below' !== $style && 'none' !== $lbg ) {
		$hx  = ltrim( (string) $s['tiles_label_color'], '#' );
		$rgb = preg_match( '/^[0-9a-fA-F]{6}$/', $hx ) ? hexdec( substr( $hx, 0, 2 ) ) . ',' . hexdec( substr( $hx, 2, 2 ) ) . ',' . hexdec( substr( $hx, 4, 2 ) ) : '0,0,0';
		$op  = $num( 'tiles_label_opacity', 0, 100 ) / 100;
		$lb  = $num( 'tiles_label_blur', 0, 20 );
		$bf  = $lb > 0 ? " -webkit-backdrop-filter: blur({$lb}px); backdrop-filter: blur({$lb}px);" : '';
		if ( 'glow' === $lbg ) {
			$c .= ".rk-tile-name { padding: 14px 24px; background: radial-gradient(ellipse at center, rgba({$rgb},{$op}) 0%, rgba({$rgb}," . round( $op * .6, 2 ) . ") 45%, rgba({$rgb},0) 75%); text-shadow: 0 1px 6px rgba({$rgb}," . min( 1, $op + .2 ) . "); }\n";
		} elseif ( 'pill' === $lbg ) {
			$c .= ".rk-tile-name { padding: 5px 14px; border-radius: 999px; background: rgba({$rgb},{$op});{$bf} }\n";
		} else { // band
			$c .= ".rk-tile-name { align-self: stretch; display: flex; align-items: center; justify-content: center; padding: 7px 8px; background: rgba({$rgb},{$op});{$bf} }\n";
		}
	}
	if ( 'below' !== $style && 'bottom' === $s['tiles_label_pos'] ) {
		$c .= ".rk-tile { align-items: flex-end; padding-bottom: " . ( 'band' === $lbg ? '0' : '10px' ) . "; }\n";
		if ( 'band' === $lbg ) {
			$c .= ".rk-tile { padding-left: 0; padding-right: 0; }\n.rk-tile-name { align-self: flex-end; flex: 1 1 100%; }\n";
		}
	} elseif ( 'below' !== $style && 'band' === $lbg ) {
		$c .= ".rk-tile { padding-left: 0; padding-right: 0; }\n.rk-tile-name { flex: 1 1 100%; }\n";
	}
	return $c;
}

/**
 * strony sklepu WooCommerce (archiwum kategorii, sklep, „Podobne
 * produkty”) – pętla motywu ul.products > li.product. Przycisk dostaje
 * wygląd przycisku z listy; zdjęcia zaokrąglone; opcjonalnie wszystko na środku.
 * !important, bo motywy stylują te elementy bardzo mocno.
 */
function rzd_shop_css( $s ) {
	$gb = '';
	if ( ! empty( $s['gb_btn_style'] ) ) {
		// blok Gutenberga „Przyciski” (.wp-block-button__link) – ten sam wygląd co
		// „Dodaj do koszyka”. Wariant „Obrys” (is-style-outline) dostaje przezroczyste tło.
		// + „Wróć do listy produktów”, „Przejdź do płatności” (koszyk blokowy i klasyczny), „Kupuję i płacę” (kasa).
		$b   = '.wp-block-button .wp-block-button__link, .wp-block-button .wp-element-button, .kc-back-to-shop .button.wc-backward, '
			. '.wc-block-cart__submit-button, .wc-block-components-checkout-place-order-button, .woocommerce a.checkout-button, .woocommerce #place_order, '
			// wszystkie przyciski kroków kasy i koszyka (np. „Zapisz zmiany”, „Dalej”, „Zastosuj kupon”) – też z wtyczek kroków kasy.
			. 'body.woocommerce-checkout button.button, body.woocommerce-checkout a.button:not(.wc-backward), body.woocommerce-checkout input[type=submit].button, body.woocommerce-checkout .wc-block-components-button:not(.is-link), '
			. 'body.woocommerce-cart button.button, body.woocommerce-cart .wc-block-components-button:not(.is-link), '
			// Fluid Checkout ma mocne własne style przycisków – wyższa „waga” selektorów (id / podwojone klasy).
			. 'html body.woocommerce-checkout #place_order, html body.woocommerce-checkout button.button.button, html body.woocommerce-checkout .fc-step__substep-save.fc-step__substep-save';
		$gb .= $b . ' { padding: ' . (int) $s['button_padding_v'] . 'px ' . (int) $s['button_padding_h'] . 'px !important;'
			. ' border: 1.5px solid ' . esc_attr( $s['button_border_color'] ) . ' !important;'
			. ' border-radius: ' . (int) $s['button_radius'] . 'px !important;'
			. ' background: ' . esc_attr( $s['button_bg'] ) . ' !important;'
			. ' color: ' . esc_attr( $s['button_text_color'] ) . ' !important;'
			. ' font-size: ' . max( 10, (float) $s['button_font_size'] ) . 'px !important;'
			. ' font-weight: 600 !important; line-height: 1.25 !important; text-decoration: none !important; box-shadow: none !important; text-transform: none !important; transition: background .15s, color .15s;'
			. ' box-sizing: border-box !important; max-width: 100% !important; white-space: normal; }' . "\n"; // szerokość 100 % + nasz padding/ramka nie wychodzi poza kontener
		$gb .= ".wc-block-cart__submit-button .wc-block-components-button__text, .wc-block-components-checkout-place-order-button .wc-block-components-button__text { color: inherit !important; }\n";
		$gb .= '.wp-block-button .wp-block-button__link:hover, .wp-block-button .wp-block-button__link:focus, .wp-block-button .wp-element-button:hover, .kc-back-to-shop .button.wc-backward:hover, .kc-back-to-shop .button.wc-backward:focus, .wc-block-cart__submit-button:hover, .wc-block-cart__submit-button:focus, .wc-block-components-checkout-place-order-button:hover, .woocommerce a.checkout-button:hover, .woocommerce #place_order:hover, body.woocommerce-checkout button.button:hover, body.woocommerce-checkout a.button:not(.wc-backward):hover, body.woocommerce-checkout input[type=submit].button:hover, body.woocommerce-checkout .wc-block-components-button:not(.is-link):hover, body.woocommerce-cart button.button:hover, body.woocommerce-cart .wc-block-components-button:not(.is-link):hover, html body.woocommerce-checkout #place_order:hover, html body.woocommerce-checkout button.button.button:hover, html body.woocommerce-checkout .fc-step__substep-save.fc-step__substep-save:hover { background: ' . esc_attr( $s['button_hover_bg'] ) . ' !important; color: ' . esc_attr( $s['button_hover_text'] ) . " !important; }\n";
		$gb .= ".wp-block-button.is-style-outline .wp-block-button__link:not(:hover) { background: transparent !important; }\n";
	}
	if ( empty( $s['shop_on'] ) ) {
		return $gb;
	}
	$li  = '.woocommerce ul.products li.product, .woocommerce-page ul.products li.product, ul.products li.product';
	$sel = function ( $suffix ) {
		return implode( ', ', array_map( function ( $b ) use ( $suffix ) { return $b . $suffix; }, array( '.woocommerce ul.products li.product', '.woocommerce-page ul.products li.product', 'ul.products li.product' ) ) );
	};
	$r   = max( 0, (float) $s['shop_img_radius'] );
	$gap = max( 0, (float) $s['shop_card_gap'] );
	$c   = '';
	$c  .= $sel( ' img' ) . " { border-radius: {$r}px !important; }\n";
	if ( ! empty( $s['shop_equal'] ) ) {
		// kafel jako kolumna, przycisk dosunięty do dołu – w rzędzie wszystkie
		// przyciski równo, niezależnie od długości nazwy. Astra trzyma nazwę/cenę/przycisk
		// w .astra-shop-summary-wrap – ona też musi się rozciągać.
		$c .= "ul.products { align-items: stretch; }\n";
		$c .= $sel( '' ) . " { display: flex !important; flex-direction: column; height: auto; }\n";
		$c .= $sel( ' .astra-shop-summary-wrap' ) . " { display: flex; flex-direction: column; flex: 1 1 auto; }\n";
		$c .= $sel( ' .button' ) . ', ' . $sel( ' .added_to_cart' ) . " { margin-top: auto !important; }\n";
		$c .= $sel( ' .price' ) . " { padding-bottom: 6px; }\n";
	}
	if ( ! empty( $s['shop_grid_center'] ) ) {
		$c .= rzd_shop_grid_center_css();
	}
	if ( ! empty( $s['shop_hide_count'] ) ) {
		$c .= ".woocommerce .woocommerce-result-count, .woocommerce-page .woocommerce-result-count { display: none !important; }\n";
	}
	if ( ! empty( $s['shop_hide_sort'] ) ) {
		$c .= ".woocommerce .woocommerce-ordering, .woocommerce-page .woocommerce-ordering { display: none !important; }\n";
	}
	$c  .= $sel( ' a img' ) . " { margin-bottom: {$gap}px !important; }\n";
	$c  .= $sel( ' .woocommerce-loop-product__title' ) . ' { font-size: ' . (float) $s['shop_name_size'] . 'px !important;' . ( '' !== (string) $s['shop_name_weight'] ? ' font-weight: ' . esc_attr( $s['shop_name_weight'] ) . ' !important;' : '' ) . " margin: 0 0 {$gap}px !important; padding: 0 !important; }\n";
	$c  .= $sel( ' .price' ) . ' { font-size: ' . (float) $s['shop_price_size'] . "px !important; margin: 0 0 {$gap}px !important;" . ( ! empty( $s['shop_price_color_on'] ) ? ' color: ' . esc_attr( $s['shop_price_color'] ) . ' !important;' : '' ) . " }\n";
	if ( ! empty( $s['shop_equal'] ) ) {
		// cena też dosunięta do dołu (tuż nad przyciskiem) – w rzędzie ceny w jednej
		// linii, nawet gdy nazwa zajmuje 2–3 wiersze. Margines auto przejmuje cena, przycisk
		// stoi zaraz pod nią. Standardowy WooCommerce trzyma cenę w linku z obrazkiem –
		// ten link też musi być kolumną. Cena nigdy się nie łamie.
		$c .= $sel( ' a.woocommerce-LoopProduct-link' ) . " { display: flex !important; flex-direction: column; flex: 1 1 auto; }\n";
		$c .= $sel( ' .price' ) . " { margin-top: auto !important; white-space: nowrap; }\n";
		$c .= $sel( ' .button' ) . ', ' . $sel( ' a.button' ) . " { margin-top: 0 !important; }\n";
	}
	if ( ! empty( $s['shop_center'] ) ) {
		$c .= "{$li} { text-align: center !important; }\n";
		$c .= $sel( ' img' ) . " { margin-left: auto !important; margin-right: auto !important; }\n";
		$c .= $sel( ' .price' ) . ', ' . $sel( ' .star-rating' ) . " { margin-left: auto !important; margin-right: auto !important; justify-content: center; }\n";
		$c .= $sel( ' .button' ) . ', ' . $sel( ' .added_to_cart' ) . " { margin-left: auto !important; margin-right: auto !important; }\n";
		// Motywy z flexem w kafelku (np. Kadence/Astra): wyśrodkuj kolumnę.
		$c .= $sel( ' .product-details' ) . ', ' . $sel( ' .astra-shop-summary-wrap' ) . " { text-align: center !important; align-items: center !important; }\n";
	}
	if ( ! empty( $s['shop_btn_style'] ) ) {
		$btn = $sel( ' .button' ) . ', ' . $sel( ' a.button' ) . ', ' . $sel( ' .added_to_cart' );
		$c  .= $btn . ' { display: ' . ( ! empty( $s['shop_btn_full'] ) ? 'block' : 'inline-block' ) . ' !important;'
			. ( ! empty( $s['shop_btn_full'] ) ? ' width: 100% !important; box-sizing: border-box;' : ' width: auto !important;' )
			. ' padding: ' . (int) $s['button_padding_v'] . 'px ' . (int) $s['button_padding_h'] . 'px !important;'
			. ' border: 1.5px solid ' . esc_attr( $s['button_border_color'] ) . ' !important;'
			. ' border-radius: ' . (int) $s['button_radius'] . 'px !important;'
			. ' background: ' . esc_attr( $s['button_bg'] ) . ' !important;'
			. ' color: ' . esc_attr( $s['button_text_color'] ) . ' !important;'
			. ' font-size: ' . max( 10, (float) $s['button_font_size'] ) . 'px !important;'
			. ' font-weight: 600 !important; line-height: 1.25 !important; text-align: center; text-decoration: none !important; box-shadow: none !important; text-transform: none; transition: background .15s, color .15s; }' . "\n";
		$c  .= $sel( ' .button:hover' ) . ', ' . $sel( ' .button:focus' ) . ', ' . $sel( ' .added_to_cart:hover' ) . ' { background: ' . esc_attr( $s['button_hover_bg'] ) . ' !important; color: ' . esc_attr( $s['button_hover_text'] ) . ' !important; border-color: ' . esc_attr( $s['button_border_color'] ) . " !important; }\n";
		$c  .= $sel( ' .added_to_cart' ) . " { margin-top: 6px !important; }\n";
	}
	return $gb . $c;
}

/**
 * wyśrodkowany rząd kafli sklepu. Motyw (Astra, też zwykły WooCommerce)
 * układa ul.products w siatkę CSS – niepełny rząd zawsze stoi przy lewej krawędzi.
 * Zamieniamy rząd na flex z zawijaniem i justify-content: center; szerokość kafla
 * liczymy z liczby kolumn, którą motyw już podaje w klasach listy: columns-N
 * (komputer), tablet-columns-N i mobile-columns-N (Astra, progi 921 / 544 px).
 * Pełny rząd wygląda jak dotąd, niepełny – na środku. Bez klasy kolumn dla danego
 * urządzenia reguła nic nie robi (zostaje układ motywu).
 */
function rzd_shop_grid_center_css() {
	$gx  = 20; // odstęp poziomy (px) – jak w siatce Astry
	$ul  = '.woocommerce ul.products, .woocommerce-page ul.products, ul.products';
	$css = '';
	$sets = array(
		array( '(min-width: 922px)', 'columns-' ),
		array( '(min-width: 545px) and (max-width: 921px)', 'tablet-columns-' ),
		array( '(max-width: 544px)', 'mobile-columns-' ),
	);
	foreach ( $sets as $set ) {
		$rules = '';
		for ( $n = 1; $n <= 6; $n++ ) {
			$cls  = $set[1] . $n;
			$list = implode( ', ', array_map( function ( $b ) use ( $cls ) { return $b . '.' . $cls; }, explode( ', ', $ul ) ) );
			$w    = 1 === $n ? '100%' : 'calc((100% - ' . ( ( $n - 1 ) * $gx ) . 'px) / ' . $n . ')';
			$rules .= $list . " { display: flex !important; flex-wrap: wrap !important; justify-content: center !important; column-gap: {$gx}px !important; row-gap: 2em !important; grid-template-columns: none !important; }\n";
			$rules .= implode( ', ', array_map( function ( $b ) { return $b . '::before, ' . $b . '::after'; }, explode( ', ', $list ) ) ) . " { display: none !important; }\n";
			$rules .= implode( ', ', array_map( function ( $b ) { return $b . ' > li.product'; }, explode( ', ', $list ) ) ) . " { flex: 0 0 auto !important; width: {$w} !important; max-width: {$w} !important; margin: 0 !important; float: none !important; clear: none !important; }\n";
		}
		$css .= '@media ' . $set[0] . " {\n" . $rules . "}\n";
	}
	return $css;
}

/**
 * strona pojedynczego produktu. Zdjęcie w kwadracie z zaokrągleniem
 * (999 = koło), miniaturki, tytuł/cena. Licznik i przycisk: skrypt
 * rzd_single_buy_script() przenosi .quantity i przycisk do <div class="rl2-order">
 * <div class="rl-buy"> i dodaje − / + – wtedy działają style listy z sekcji
 * „Licznik ilości” i „Przycisk”. Tu tylko poprawki pod motyw (float, marginesy).
 */
function rzd_single_css( $s ) {
	if ( empty( $s['single_on'] ) ) {
		return '';
	}
	$r  = max( 0, (float) $s['single_img_radius'] );
	$tr = max( 0, (float) $s['single_thumb_radius'] );
	$g  = '.woocommerce div.product div.images';
	$c  = '';
	$c .= "{$g} .woocommerce-product-gallery__wrapper, {$g} .flex-viewport, {$g} .woocommerce-product-gallery__image { border-radius: {$r}px; overflow: hidden; }\n";
	$c .= "{$g} .woocommerce-product-gallery__image img { border-radius: {$r}px; }\n";
	if ( ! empty( $s['single_img_square'] ) ) {
		$c .= "{$g} .woocommerce-product-gallery__image > a > img, {$g} .woocommerce-product-gallery__image > img { width: 100% !important; height: auto !important; aspect-ratio: 1 / 1; object-fit: cover; }\n";
	}
	$c .= "{$g} .flex-control-thumbs li img { border-radius: {$tr}px; aspect-ratio: 1 / 1; object-fit: cover; }\n";
	if ( (float) $s['single_title_size'] > 0 ) {
		$c .= '.woocommerce div.product .product_title { font-size: ' . (float) $s['single_title_size'] . "px !important; }\n";
	}
	if ( (float) $s['single_head_gap'] > 0 ) {
		$c .= '.woocommerce div.product .summary .product_title { margin-bottom: ' . (float) $s['single_head_gap'] . "px !important; }\n.woocommerce div.product .summary > p.price, .woocommerce div.product .summary > .price { margin-top: 0 !important; }\n";
	}
	if ( (float) $s['single_price_size'] > 0 || ! empty( $s['single_price_color_on'] ) ) {
		$c .= '.woocommerce div.product .summary p.price, .woocommerce div.product .summary span.price {'
			. ( (float) $s['single_price_size'] > 0 ? ' font-size: ' . (float) $s['single_price_size'] . 'px !important;' : '' )
			. ( ! empty( $s['single_price_color_on'] ) ? ' color: ' . esc_attr( $s['single_price_color'] ) . ' !important;' : '' ) . " }\n";
	}
	if ( ! empty( $s['single_one_title'] ) ) {
		// Motyw dokłada własny tytuł obok tytułu wtyczki (rwz-title, moduł 4) – zostaje tylko nasz.
		$c .= ".woocommerce div.product:has(.rwz-title) .product_title:not(.rwz-title) { display: none !important; }\n";
	}
	if ( ! empty( $s['single_layout'] ) ) {
		// kolumna po prawej od zdjęcia jako flex – formularz (ilość + przycisk)
		// zawsze na dole, niezależnie od kolejności haków motywu; wszystko do lewej.
		$sum = '.woocommerce div.product .summary';
		$c .= "{$sum} { display: flex; flex-direction: column; align-items: stretch; text-align: left; }\n";
		$c .= "{$sum} > * { order: 10; }\n";
		// margin-top: auto = na samo dno kolumny; wysokość kolumny = wysokość
		// zdjęcia (skrypt rzd_single_layout_script, gdy zdjęcie i kolumna są obok siebie).
		$c .= "{$sum} > form.cart, {$sum} > .cart { order: 90; margin-top: auto !important; padding-top: 8px; }\n";
		$c .= "{$sum} { box-sizing: border-box; }\n";
		$c .= "{$sum} { min-width: 0; max-width: 100%; }\n{$sum} .product_title { overflow-wrap: anywhere; }\n"; // nic nie wystaje poza ekran
		$c .= "{$sum} .rzd-sp-order .rl-buy .rl2-qty { flex: 0 0 auto; }\n";
		$mode = in_array( $s['single_buy_stack'], array( 'stack', 'center', 'row' ), true ) ? $s['single_buy_stack'] : 'stack';
		$bw   = max( 0, min( 100, (float) $s['single_btn_width'] ) );
		if ( 'row' === $mode ) { // obok siebie
			$c .= "{$sum} .rzd-sp-order .rl-buy { flex-direction: row; align-items: center; width: 100% !important; max-width: 440px !important; }\n";
			$c .= "{$sum} .rzd-sp-order .rl-buy button:not(.rl2-qty-btn) { flex: 1 1 auto !important; align-self: auto; margin-left: 0 !important; width: auto !important; min-width: 0; }\n";
		} elseif ( 'center' === $mode ) { // wyśrodkowane – ilość, pod nią szeroki przycisk
			$c .= "{$sum} .rzd-sp-order { width: 100%; }\n";
			$c .= "{$sum} .rzd-sp-order .rl-buy { flex-direction: column; align-items: center; width: 100% !important; max-width: none !important; margin: 0 auto; }\n";
			$c .= "{$sum} .rzd-sp-order .rl-buy .rl2-qty { justify-content: center; }\n";
			$c .= "{$sum} .rzd-sp-order .rl-buy button:not(.rl2-qty-btn) { align-self: center; margin: 0 auto !important; width: " . ( $bw > 0 ? $bw . '%' : 'auto' ) . " !important; max-width: 100%; }\n";
		} else {
			$c .= "{$sum} .rzd-sp-order .rl-buy { flex-direction: column; align-items: flex-start; width: auto !important; max-width: 360px !important; }\n";
			$c .= "{$sum} .rzd-sp-order .rl-buy button:not(.rl2-qty-btn) { align-self: stretch; margin-left: 0 !important; width: " . ( $bw > 0 ? $bw . '%' : '100%' ) . " !important; }\n";
		}
		// większy licznik i przycisk tylko na stronie produktu.
		$qd = (float) $s['single_qty_size'];
		if ( $qd > 0 ) {
			$c .= "{$sum} .rzd-sp-order .rl2-qty .rl2-qty-btn { width: {$qd}px !important; height: {$qd}px !important; min-width: {$qd}px !important; min-height: {$qd}px !important; font-size: " . round( $qd * 0.42 ) . "px !important; }\n";
			$c .= "{$sum} .rzd-sp-order .rl2-qty { min-width: " . ( 2 * $qd + 60 ) . "px !important; gap: 8px; }\n";
		}
		$qf = (float) $s['single_qty_font'];
		if ( $qf > 0 ) {
			$c .= "{$sum} .rzd-sp-order .rl2-qty input.qty, {$sum} .rzd-sp-order .rl2-qty input[type=number] { font-size: {$qf}px !important; min-width: " . round( $qf * 2 ) . "px; }\n";
		}
		$bh = (float) $s['single_btn_height'];
		if ( $bh > 0 ) {
			$c .= "{$sum} .rzd-sp-order .rl-buy button:not(.rl2-qty-btn) { min-height: {$bh}px !important; }\n";
		}
		$c .= "{$sum} .rzd-sp-order .rl-buy { row-gap: 14px; }\n";
	}
	if ( 'theme' !== $s['single_tabs_line'] ) { // delikatna kreska zakładek zamiast grubej pomarańczowej
		$lc = 'dark' === $s['single_tabs_line'] ? '#2b2b2b' : esc_attr( $s['button_border_color'] );
		$t  = '.woocommerce div.product .woocommerce-tabs ul.tabs';
		$c .= "{$t}::before { border-color: rgba(0,0,0,.08) !important; }\n";
		$c .= "{$t} li::before, {$t} li.active::before { background: {$lc} !important; height: 1px !important; }\n";
		$c .= "{$t} li.active, {$t} li.active a { border-color: {$lc} !important; }\n";
	}
	$c .= ".woocommerce div.product .rzd-cat-desc { margin: 0 0 18px; padding: 0 0 14px; border-bottom: 1px solid rgba(0,0,0,.08); }\n.woocommerce div.product .rzd-cat-desc > :last-child { margin-bottom: 0; }\n";
	$ha = in_array( $s['single_head_align'], array( 'left', 'center', 'right' ), true ) ? $s['single_head_align'] : 'left';
	if ( 'left' !== $ha ) {
		$c .= ".woocommerce div.product .summary .product_title, .woocommerce div.product .summary > p.price, .woocommerce div.product .summary > .price { text-align: {$ha} !important; }\n";
	}
	if ( ! empty( $s['single_harmono'] ) ) {
		$c .= ".woocommerce div.product .summary details.rl-harmono { display: block; max-width: 360px; box-sizing: border-box; margin: 10px 0; padding: 8px 12px; border: 1.5px solid #dcdcdc; border-radius: 8px; font-size: 13px; transition: background .15s, border-color .15s; }\n";
		$c .= ".woocommerce div.product .summary details.rl-harmono:hover { background: " . esc_attr( $s['box_hover_bg'] ) . '; border-color: ' . esc_attr( $s['box_hover_border'] ) . "; }\n";
		$c .= ".woocommerce div.product .summary details.rl-harmono summary { cursor: pointer; list-style: none; font-weight: 600; }\n";
		$c .= ".woocommerce div.product .summary details.rl-harmono summary::-webkit-details-marker { display: none; }\n";
		$c .= ".woocommerce div.product .summary details.rl-harmono summary::before { content: \"▶ \"; }\n";
	}
	if ( ! empty( $s['single_buy'] ) ) {
		$c .= ".woocommerce div.product form.cart .rzd-sp-order { margin: 12px 0 16px; }\n";
		$c .= ".woocommerce div.product form.cart .rzd-sp-order .quantity, .woocommerce div.product form.cart .rzd-sp-order .button { float: none !important; margin: 0 !important; }\n";
		$c .= ".woocommerce div.product form.cart .rzd-sp-order .quantity .screen-reader-text { position: absolute !important; }\n";
		$c .= ".woocommerce div.product form.cart .rzd-sp-order .quantity input.qty { flex: 1 1 auto; width: 100%; min-width: 2.2em; text-align: center; padding: 0 !important; -moz-appearance: textfield; }\n";
		$c .= ".woocommerce div.product form.cart .rzd-sp-order .quantity input.qty::-webkit-inner-spin-button, .woocommerce div.product form.cart .rzd-sp-order .quantity input.qty::-webkit-outer-spin-button { -webkit-appearance: none; margin: 0; }\n";
	}
	return $c;
}

/**
 * Skrypt strony produktu: licznik − / + i przycisk jak na liście. Wypisywany
 * zaraz za formularzem (bez „mignięcia”), działa też dla wariantów (przycisk
 * i ilość w .woocommerce-variation-add-to-cart). Nie dubluje − / +, jeśli
 * motyw ma własne. Kliknięcia − / + obsługuje wspólny skrypt listy (moduł 02).
 */
function rzd_single_buy_script() {
	static $done = false;
	$s = rzd_list_style_get();
	if ( $done || empty( $s['single_on'] ) || empty( $s['single_buy'] ) ) {
		return;
	}
	$done = true;
	?>
	<script>
	(function () {
		Array.prototype.forEach.call(document.querySelectorAll('form.cart'), function (f) {
			if (f.getAttribute('data-rzd-buy')) { return; }
			var b = f.querySelector('button.single_add_to_cart_button, button[name="add-to-cart"]');
			if (!b) { return; }
			f.setAttribute('data-rzd-buy', '1');
			var q = f.querySelector('.quantity');
			var wrap = document.createElement('div'); wrap.className = 'rl2-order rzd-sp-order';
			var buy = document.createElement('div'); buy.className = 'rl-buy';
			wrap.appendChild(buy);
			var anchor = (q && q.parentNode === b.parentNode) ? q : b;
			anchor.parentNode.insertBefore(wrap, anchor);
			if (q) {
				var inp = q.querySelector('input.qty');
				if (inp && inp.type !== 'hidden' && !q.querySelector('.plus, .minus, button')) {
					q.classList.add('rl2-qty');
					var mk = function (cls, txt, lbl) { var x = document.createElement('button'); x.type = 'button'; x.className = 'rl2-qty-btn ' + cls; x.textContent = txt; x.setAttribute('aria-label', lbl); return x; };
					inp.parentNode.insertBefore(mk('rl2-qty-minus', '−', 'Zmniejsz ilość'), inp);
					inp.parentNode.insertBefore(mk('rl2-qty-plus', '+', 'Zwiększ ilość'), inp.nextSibling);
				}
				buy.appendChild(q);
			}
			buy.appendChild(b);
		});
	})();
	</script>
	<?php
}
add_action( 'woocommerce_after_add_to_cart_form', 'rzd_single_buy_script' );

/**
 * kolumna obok zdjęcia ma co najmniej wysokość zdjęcia – wtedy ilość
 * i „Dodaj do koszyka” (margin-top: auto) stoją równo z dołem zdjęcia, nawet gdy
 * między ceną a przyciskiem nic nie ma. Gdy kolumna jest POD zdjęciem (telefon),
 * nic nie zmieniamy. Liczone po wczytaniu zdjęć, przy zmianie rozmiaru okna
 * i gdy galeria zmieni wysokość (ResizeObserver).
 */
add_action( 'wp_footer', function () {
	if ( ! function_exists( 'is_product' ) || ! is_product() ) {
		return;
	}
	$s = rzd_list_style_get();
	if ( empty( $s['single_on'] ) || empty( $s['single_layout'] ) ) {
		return;
	}
	?>
	<script>
	(function () {
		var p = document.querySelector('div.product');
		var g = p && p.querySelector('.woocommerce-product-gallery, div.images');
		var sm = p && p.querySelector('.summary');
		if (!g || !sm) { return; }
		function fit() {
			sm.style.minHeight = '';
			var gr = g.getBoundingClientRect(), sr = sm.getBoundingClientRect();
			var side = Math.abs(gr.top - sr.top) < 60 && sr.left >= gr.right - 4; // kolumna obok zdjęcia
			if (side && g.offsetHeight > sm.offsetHeight) { sm.style.minHeight = g.offsetHeight + 'px'; }
		}
		fit();
		window.addEventListener('load', fit);
		window.addEventListener('resize', fit);
		if (window.ResizeObserver) { new ResizeObserver(fit).observe(g); }
	})();
	</script>
	<?php
}, 30 );

// główna kategoria produktu (pierwsza, bez „Bez kategorii”).
function rzd_product_main_cat( $product_id ) {
	$terms = get_the_terms( $product_id, 'product_cat' );
	if ( ! $terms || is_wp_error( $terms ) ) {
		return null;
	}
	foreach ( $terms as $t ) {
		if ( 'uncategorized' !== $t->slug && (int) get_option( 'default_product_cat' ) !== (int) $t->term_id ) {
			return $t;
		}
	}
	return null;
}

/**
 * zakładka „Opis” na karcie produktu:
 *  - tytuł zakładki = nazwa kategorii (np. „Bajgle”),
 *  - w środku: opis kategorii (Produkty → Kategorie → Opis), pod nim nazwa
 *    produktu w miejscu „O produkcie” i opis produktu.
 * „O produkcie” zastępujemy, gdziekolwiek jest: jako nagłówek zakładki
 * (WooCommerce/motyw) albo jako nagłówek wpisany w treści opisu.
 */
add_filter( 'woocommerce_product_tabs', function ( $tabs ) {
	$product = rzd_current_product(); // obiekt produktu albo null (globalne $product bywa napisem – szablony blokowe)
	$s = rzd_list_style_get();
	if ( empty( $s['single_on'] ) || empty( $tabs['description'] ) || ! $product ) {
		return $tabs;
	}
	$cat = rzd_product_main_cat( $product->get_id() );
	if ( ! empty( $s['single_tab_cat'] ) && $cat ) {
		$tabs['description']['title'] = $cat->name;
	}
	if ( ! empty( $s['single_tab_catdesc'] ) ) {
		$tabs['description']['callback'] = 'rzd_description_tab_content';
	}
	return $tabs;
}, 98 );

function rzd_description_tab_content() {
	$product = rzd_current_product(); // obiekt produktu albo null (globalne $product bywa napisem – szablony blokowe)
	if ( ! $product ) {
		return;
	}
	$name = $product->get_name();
	$cat  = rzd_product_main_cat( $product->get_id() );
	if ( $cat ) {
		$cd = trim( (string) term_description( $cat->term_id, 'product_cat' ) );
		if ( '' !== $cd ) {
			echo '<div class="rzd-cat-desc">' . wp_kses_post( $cd ) . '</div>';
		}
	}
	$content = apply_filters( 'the_content', get_post_field( 'post_content', $product->get_id() ) ); // phpcs:ignore
	if ( '' === trim( wp_strip_all_tags( (string) $content ) ) ) {
		return;
	}
	// Nagłówek „O produkcie” wpisany w treści → nazwa produktu; brak takiego → dodajemy nazwę na górze.
	$re = '#(<h([1-6])[^>]*>)\s*O\s+produkcie\s*:?\s*(</h\2>)#iu';
	if ( preg_match( $re, $content ) ) {
		$content = preg_replace( $re, '${1}' . esc_html( $name ) . '${3}', $content, 1 );
	} else {
		$content = '<h2 class="rzd-desc-title">' . esc_html( $name ) . '</h2>' . $content;
	}
	echo $content; // phpcs:ignore – treść opisu po the_content
}


// nagłówek „Podobne produkty” pod kartą produktu z panelu (domyślnie „Zamów razem”).
add_filter( 'woocommerce_product_related_products_heading', function ( $heading ) {
	$s = rzd_list_style_get();
	$t = isset( $s['shop_related_title'] ) ? trim( (string) $s['shop_related_title'] ) : '';
	return '' !== $t ? $t : $heading;
} );

function rzd_list_boxes_qty_css( $s ) {
	$n   = function ( $k ) use ( $s ) { return (float) $s[ $k ]; };
	$col = function ( $k ) use ( $s ) { return esc_attr( $s[ $k ] ); };
	$c   = '';

	// --- Ramki rozwijane ---
	$boxes = array(
		'harmono'  => '.rl2-rest .rl-harmono',
		'delivery' => '.rl .rl2-delivery',
		'more'     => '.rl2-bottom .rl-more',
		'allergen' => '.rl .rl2-allergen-box',
	);
	$all = implode( ', ', $boxes );
	$c  .= "{$all} { border: " . $n( 'box_border_width' ) . 'px solid ' . $col( 'box_border_color' ) . '; border-radius: ' . $n( 'box_radius' ) . 'px; padding: ' . $n( 'box_pad_v' ) . 'px ' . $n( 'box_pad_h' ) . 'px;'
		. ( ! empty( $s['box_bg_on'] ) ? ' background: ' . $col( 'box_bg' ) . ';' : '' ) . " }\n";
	$sum = array();
	$arr = array();
	foreach ( $boxes as $sel ) {
		$sum[] = $sel . ' summary';
		$arr[] = $sel . ' summary::before';
	}
	$c .= implode( ', ', $sum ) . ' { font-size: ' . $n( 'box_title_size' ) . 'px; color: ' . $col( 'box_title_color' ) . "; }\n";
	if ( empty( $s['box_arrow_on'] ) ) {
		$c .= implode( ', ', $arr ) . " { display: none; }\n";
	}
	// Ramka wyłączona: bez obwódki i bez bocznego odstępu – tekst równa się z resztą.
	foreach ( $boxes as $key => $sel ) {
		if ( empty( $s[ 'box_' . $key . '_border' ] ) ) {
			$c .= "{$sel} { border: 0; padding-left: 0; padding-right: 0; }\n";
		}
	}

	// --- Licznik ilości ---
	$bw   = $n( 'qty_border_width' );
	$line = $bw . 'px solid ' . $col( 'qty_border_color' );
	$h    = $n( 'qty_height' );
	$c   .= '.rl2-order .rl2-qty { border: ' . ( ! empty( $s['qty_border_on'] ) ? $line : '0' ) . '; border-radius: ' . $n( 'qty_radius' ) . 'px; background: ' . $col( 'qty_bg' ) . "; }\n";
	// Pole z liczbą: motywy (np. Elementor) dają polom input własną ramkę i
	// cień – tu zawsze zero, żeby jedyną ramką była ramka licznika z panelu.
	$c   .= '.rl2-order .rl2-qty input[type=number] { min-height: ' . $h . 'px; font-size: ' . $n( 'qty_font_size' ) . "px; border: 0 !important; border-radius: 0 !important; box-shadow: none !important; background: transparent !important; margin: 0 !important; }\n";
	$c   .= ".rl2-order .rl2-qty input[type=number]:focus { border: 0 !important; box-shadow: none !important; }\n";
	$c   .= '.rl2-qty .rl2-qty-btn { flex: 0 0 ' . $n( 'qty_btn_width' ) . 'px !important; width: ' . $n( 'qty_btn_width' ) . 'px !important; min-height: ' . $h . 'px !important; padding: 0 !important; margin: 0 !important; border: 0 !important; border-radius: ' . $n( 'qty_btn_radius' ) . 'px !important; background: ' . $col( 'qty_btn_bg' ) . ' !important; color: ' . $col( 'qty_btn_text' ) . " !important; }\n";
	$c   .= '.rl2-qty .rl2-qty-btn:hover { background: ' . $col( 'qty_btn_hover_bg' ) . ' !important; color: ' . $col( 'qty_btn_text' ) . " !important; }\n";
	if ( 'circle' === $s['qty_btn_shape'] ) {
		// Koło: szerokość = wysokość = średnica (inaczej wychodzi owal), wyśrodkowane
		// w pionie w wysokości licznika; bez linii oddzielających od liczby.
		$d   = $n( 'qty_circle_size' );
		$cbw = $n( 'qty_circle_border_w' );
		$c  .= ".rl2-order .rl2-qty { align-items: center; background: transparent; gap: 4px; min-width: " . ( 2 * $d + 44 ) . "px; }\n"; // bez prostokąta za kołami; liczba nie ściśnięta między kołami
		$c  .= ".rl2-qty .rl2-qty-btn { flex: 0 0 {$d}px !important; width: {$d}px !important; height: {$d}px !important; min-height: {$d}px !important; border-radius: 50% !important; border: " . ( $cbw > 0 ? $cbw . 'px solid ' . $col( 'qty_circle_border_c' ) : '0' ) . " !important; }\n";
	} elseif ( ! empty( $s['qty_border_on'] ) ) {
		$c .= '.rl2-qty .rl2-qty-minus { border-right: ' . $line . " !important; }\n";
		$c .= '.rl2-qty .rl2-qty-plus { border-left: ' . $line . " !important; }\n";
	}
	$qw = $n( 'qty_input_width' );
	if ( $qw > 0 ) { // stała szerokość pola z liczbą – licznik bierze tyle, ile potrzebuje
		$c .= ".rl2-order .rl2-qty { flex: 0 0 auto !important; min-width: 0 !important; }\n";
		$c .= ".rl2-order .rl2-qty input[type=number] { flex: 0 0 {$qw}px; width: {$qw}px !important; min-width: {$qw}px; }\n";
	}
	$c .= '.rl2-order .rl-buy { gap: ' . $n( 'qty_gap' ) . "px; }\n";
	$c .= '.rl2-order .rl-buy button:not(.rl2-qty-btn), .rl2-order .rl-choose { min-height: ' . $h . "px; }\n";

	// --- Odstępy pod zdjęciem ---
	// .rl2-rest ma gap (domyślnie 10); dolny blok (opis, Pełny opis) dostaje
	// tyle samo względem tego, co było (row-gap siatki 6px + różnica).
	$g  = max( 0, $n( 'element_gap' ) );
	$c .= ".rl2-rest { gap: {$g}px; }\n";
	$c .= ".rl2-row { --rl2-gap: {$g}px; }\n"; // telefon: odstęp w jednej kolumnie (plik CSS)
	$c .= '.rl2-bottom { margin-top: ' . ( $g - 10 ) . "px; }\n";
	$c .= ".rl2-bottom .rl-short { margin-bottom: {$g}px; }\n";

	return $c;
}

/**
 * Jeden wspólny wygląd wszystkich okienek dla klienta: wybór terminu
 * (#dc-modal), konflikt terminu (#dc-conflict), informacja z ikonki "i"
 * (#dc-info-popup) i "Dodano do koszyka" (#kc-added). Wcześniej każde miało
 * własną, prawie identyczną kopię CSS (w modułach 6 i 7) – teraz jest jedno
 * miejsce, a kolory pochodzą z tego samego panelu co lista produktów
 * (przycisk główny = przycisk "Dodaj do koszyka", akcent = jego obramowanie,
 * hover drugorzędnych = tło wiersza przy najechaniu).
 *
 * Układ przycisków: dolna sekcja to dwa równe kontenery (.dc-act / .kc-added-act),
 * a przestrzeń między nimi i po bokach jest rozdzielona równo (space-evenly) –
 * czyli odstęp od lewej krawędzi, między przyciskami i od prawej jest taki sam.
 */
function rzd_popup_css( $s ) {
	$accent   = esc_attr( $s['button_border_color'] );
	$p_bg     = esc_attr( $s['button_bg'] );
	$p_txt    = esc_attr( $s['button_text_color'] );
	$p_hbg    = esc_attr( $s['button_hover_bg'] );
	$p_htxt   = esc_attr( $s['button_hover_text'] );
	$soft_hov = esc_attr( $s['row_hover_bg'] );
	$line     = '#dcdcdc'; // jasne, nieagresywne obramowania

	// Tekst na wybranej godzinie (tło = kolor akcentu): dobieramy biały albo
	// ciemny według jasności tła, żeby nigdy nie wyszło czarne na czarnym –
	// niezależnie od tego, jaki akcent ktoś ustawi w panelu.
	$lum = function ( $hex ) {
		$h = ltrim( (string) $hex, '#' );
		if ( 3 === strlen( $h ) ) {
			$h = $h[0] . $h[0] . $h[1] . $h[1] . $h[2] . $h[2];
		}
		if ( 6 !== strlen( $h ) || ! ctype_xdigit( $h ) ) {
			return 1;
		}
		return ( 0.299 * hexdec( substr( $h, 0, 2 ) ) + 0.587 * hexdec( substr( $h, 2, 2 ) ) + 0.114 * hexdec( substr( $h, 4, 2 ) ) ) / 255;
	};
	$on_accent = $lum( $s['button_border_color'] ) < 0.55 ? '#ffffff' : '#2b2110';

	// #rwz-harmono = okienko harmonogramu zestawu (moduł 05).
	// #rzd-review = przegląd zamówienia (moduł 10).
	$ov = '#dc-modal, #dc-conflict, #dc-info-popup, #kc-added, #rwz-harmono, #rzd-review';
	$pn = '#dc-modal .dc-panel, #dc-conflict .dc-panel, #dc-info-popup .dc-panel, #kc-added .kc-added-panel, #rwz-harmono .dc-panel, #rzd-review .dc-panel';
	$h3 = '#dc-modal h3, #dc-conflict h3, #dc-info-popup h3, #kc-added h3, #rwz-harmono h3, #rzd-review h3';
	$ac = '#dc-modal .dc-actions, #dc-conflict .dc-actions, #dc-info-popup .dc-actions, #kc-added .kc-added-actions, #rzd-mods .rzd-actions, #rwz-harmono .dc-actions, #rzd-review .dc-actions';
	$ce = '#dc-modal .dc-act, #dc-conflict .dc-act, #dc-info-popup .dc-act, #kc-added .kc-added-act, #rzd-mods .rzd-act, #rwz-harmono .dc-act, #rzd-review .dc-act';
	$bt = '#dc-modal .dc-act button, #dc-conflict .dc-act button, #dc-info-popup .dc-act button, #kc-added .kc-added-act button, #kc-added .kc-added-act a, #rzd-mods .rzd-act button, #rwz-harmono .dc-act button, #rzd-review .dc-act button';
	$pr = '#dc-modal .dc-act .dc-ok, #dc-conflict .dc-act .dc-ok, #dc-info-popup .dc-act .dc-ok, #kc-added .kc-added-act .kc-added-cart, #rzd-mods .rzd-act .rzd-ok, #rwz-harmono .dc-act .dc-ok, #rzd-review .dc-act .dc-ok';

	// Dokleja pseudo-klasę do KAŻDEGO selektora z listy rozdzielonej przecinkami
	// (zwykłe "{$lista}:hover" dokleiłoby ją tylko do ostatniego).
	$with = function ( $list, $suffixes ) {
		$out = array();
		foreach ( explode( ', ', $list ) as $sel ) {
			foreach ( (array) $suffixes as $sx ) {
				$out[] = $sel . $sx;
			}
		}
		return implode( ', ', $out );
	};

	$c  = "\n/* Okienka dla klienta – wspólny wygląd (patrz rzd_popup_css) */\n";
	$c .= "{$ov} { position: fixed; inset: 0; display: flex; align-items: center; justify-content: center; background: rgba(0,0,0,.5); padding: 16px; box-sizing: border-box; font-family: 'Lato', -apple-system, BlinkMacSystemFont, sans-serif; }\n";
	$c .= "#rzd-review { z-index: 100000; }\n";
	$c .= "#dc-modal, #dc-conflict, #dc-info-popup { z-index: 100000; }\n#kc-added { z-index: 100002; }\n#rwz-harmono { z-index: 99999; }\n";
	// UWAGA: [hidden] musi trafić do KAŻDEGO okna z listy – inaczej (był taki
	// błąd) chowa się tylko ostatnie, a reszta zostaje widoczna na stronie.
	$c .= $with( $ov, '[hidden]' ) . " { display: none; }\n";
	$alpha = max( 30, min( 100, (float) $s['popup_opacity'] ) ) / 100;
	$blur  = max( 0, (float) $s['popup_blur'] );
	// kolor tła i tekstu okienek z panelu (np. czarne okno, biały tekst).
	$hex2rgb = function ( $h ) {
		$h = ltrim( (string) $h, '#' );
		return preg_match( '/^[0-9a-fA-F]{6}$/', $h ) ? array( hexdec( substr( $h, 0, 2 ) ), hexdec( substr( $h, 2, 2 ) ), hexdec( substr( $h, 4, 2 ) ) ) : array( 255, 255, 255 );
	};
	$mix = function ( $a, $b, $t ) use ( $hex2rgb ) { // $t = udział koloru $a
		$x = $hex2rgb( $a );
		$y = $hex2rgb( $b );
		return sprintf( '#%02x%02x%02x', round( $x[0] * $t + $y[0] * ( 1 - $t ) ), round( $x[1] * $t + $y[1] * ( 1 - $t ) ), round( $x[2] * $t + $y[2] * ( 1 - $t ) ) );
	};
	$pbg     = preg_match( '/^#[0-9a-fA-F]{6}$/', (string) $s['popup_bg_color'] ) ? $s['popup_bg_color'] : '#ffffff';
	$txt     = preg_match( '/^#[0-9a-fA-F]{6}$/', (string) $s['popup_text_color'] ) ? $s['popup_text_color'] : '#2b2b2b';
	$muted   = $mix( $txt, $pbg, .75 ); // dawne #555/#666
	$faint   = $mix( $txt, $pbg, .55 ); // dawne #777/#999
	$rgb     = implode( ',', $hex2rgb( $pbg ) );
	$is_dark = $lum( $pbg ) < 0.5;
	$glass = 'background: rgba(' . $rgb . ',' . sprintf( '%.2F', $alpha ) . ') !important;' // %F: kropka niezależnie od locale
		. ( $blur > 0 ? " backdrop-filter: blur({$blur}px); -webkit-backdrop-filter: blur({$blur}px);" : ' backdrop-filter: none; -webkit-backdrop-filter: none;' );
	$c .= "{$pn}, #rzd-mods .rzd-panel { {$glass} }\n";
	$c .= "{$pn} { color: {$txt}; border-radius: 14px; max-width: 440px; width: 100%; padding: 24px; box-sizing: border-box; box-shadow: 0 10px 40px rgba(0,0,0,.25); max-height: 90vh; overflow: auto; font-family: inherit; }\n";
	// czcionki i przyciski okienek z panelu (osobno telefon/komputer).
	// Grubość '' = jak motyw → nie wypisujemy font-weight.
	$fw    = function ( $k, $min = 0 ) use ( $s ) {
		$w = isset( $s[ $k ] ) ? (string) $s[ $k ] : '';
		if ( '' === $w ) {
			return $min ? " font-weight: {$min};" : '';
		}
		return ' font-weight: ' . max( (int) $w, (int) $min ) . ';';
	};
	$px    = function ( $k ) use ( $s ) { return (float) $s[ $k ] . 'px'; };
	$t_sz  = $px( 'popup_title_size' );
	$x_sz  = $px( 'popup_text_size' );
	$l_sz  = $px( 'popup_label_size' );
	$c .= "{$h3} { margin: 0 0 12px; color: {$txt}; font-family: inherit; font-size: {$t_sz};" . $fw( 'popup_title_weight' ) . " letter-spacing: 0; line-height: 1.25; }\n";
	$c .= "#dc-modal .dc-msg, #dc-conflict .dc-msg, #dc-info-popup .dc-msg { font-size: {$x_sz};" . $fw( 'popup_text_weight' ) . " line-height: 1.5; color: {$muted}; margin: 0 0 14px; }\n";
	// „Dostosuj produkt” (moduł 10): tytuł jak w innych okienkach; nagłówek grupy
	// o 2 px większy od etykiet i zawsze gruby; opis grupy o 1 px mniejszy od tekstu.
	$c .= "#rzd-mods .rzd-panel h3 { font-size: {$t_sz};" . $fw( 'popup_title_weight' ) . " line-height: 1.25; }\n";
	// pasek tytułu okna modyfikacji z ✕ – tło i krzyżyk jak w przeglądzie zamówienia.
	$c .= "#rzd-mods .rzd-head { background: rgba({$rgb},.97) !important; }\n";
	$c .= "#rzd-mods .rzd-x { border-color: {$accent} !important; background: #fff !important; color: #2b2b2b !important; }\n";
	$c .= $with( '#rzd-mods .rzd-x', array( ':hover', ':focus' ) ) . " { background: {$soft_hov} !important; }\n";
	$c .= '#rzd-mods .rzd-panel .rzd-section-header { font-size: ' . ( (float) $s['popup_label_size'] + 2 ) . 'px;' . $fw( 'popup_label_weight', 700 ) . " }\n";
	$c .= '#rzd-mods .rzd-panel .rzd-section-desc { font-size: ' . ( (float) $s['popup_text_size'] - 1 ) . 'px;' . $fw( 'popup_text_weight' ) . " }\n";
	$c .= "#dc-modal .dc-msg.dc-err, #dc-conflict .dc-msg.dc-err, #dc-info-popup .dc-msg { color: #b32d2e; }\n";
	$c .= "#dc-modal .dc-field, #dc-conflict .dc-field { display: block; margin: 14px 0; font-size: {$l_sz};" . $fw( 'popup_label_weight' ) . " color: {$muted}; }\n";
	$c .= "#dc-modal select, #dc-conflict select, #dc-modal input.dc-town { display: block; width: 100%; box-sizing: border-box; margin-top: 6px; padding: 10px 12px; color: #2b2b2b; background: #fff; border: 1px solid {$line}; border-radius: 8px; font-family: inherit; font-size: 14px; transition: border-color .15s; }\n";
	$c .= "#dc-modal select:hover, #dc-modal select:focus, #dc-conflict select:hover, #dc-conflict select:focus { border-color: {$accent}; outline: 0; }\n";
	// Pole miejscowości: widoczne niezależnie od motywu (bez tego wyglądało jak zwykły tekst albo znikało).
	$c .= "#dc-modal input.dc-town { height: auto; min-height: 42px; opacity: 1; visibility: visible; }\n";
	$c .= "#dc-modal input.dc-town:hover, #dc-modal input.dc-town:focus { border-color: {$accent}; outline: 0; }\n";

	// Godziny: siatka o równych kolumnach – wszystkie kafelki tej samej szerokości
	$c .= "#dc-modal .dc-times, #dc-conflict .dc-times { display: grid; grid-template-columns: repeat(auto-fill, minmax(112px, 1fr)); gap: 8px; margin-top: 8px; }\n";
	$c .= "#dc-modal .dc-time, #dc-conflict .dc-time { padding: 9px 6px; border: 1px solid {$line}; border-radius: 8px; background: #fff !important; color: #2b2b2b !important; cursor: pointer; font-family: inherit; font-size: " . $px( 'popup_tile_size' ) . ';' . $fw( 'popup_tile_weight' ) . " text-align: center; transition: background .15s, border-color .15s; }\n";
	$c .= "#dc-modal .dc-time:hover, #dc-modal .dc-time:focus, #dc-conflict .dc-time:hover, #dc-conflict .dc-time:focus { background: {$soft_hov} !important; border-color: {$accent}; color: #2b2b2b !important; }\n";
	$c .= $with( '#dc-modal .dc-time.dc-on, #dc-conflict .dc-time.dc-on', array( '', ':hover', ':focus' ) ) . " { background: {$accent} !important; border-color: {$accent}; color: {$on_accent} !important;" . $fw( 'popup_tile_weight', 700 ) . " }\n";

	// Odbiór osobisty (moduł 36): przełącznik „Dostawa / Odbiór osobisty” i adres lokalu.
	$c .= "#dc-modal .dc-mode { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin: 10px 0 4px; }\n";
	$c .= "#dc-modal .dc-mode-b { padding: 11px 6px; border: 1px solid {$line}; border-radius: 10px; background: #fff !important; color: #2b2b2b !important; cursor: pointer; font-family: inherit; font-size: {$l_sz}; font-weight: 600; text-align: center; }\n";
	$c .= "#dc-modal .dc-mode-b:hover, #dc-modal .dc-mode-b:focus { background: {$soft_hov} !important; border-color: {$accent}; }\n";
	$c .= $with( '#dc-modal .dc-mode-b.dc-on', array( '', ':hover', ':focus' ) ) . " { background: {$accent} !important; border-color: {$accent}; color: {$on_accent} !important; }\n";
	$c .= "#dc-modal .dc-pk-where { margin: 8px 0 0; padding: 8px 12px; border-radius: 8px; background: {$soft_hov}; color: #2b2b2b; font-size: {$l_sz}; }\n";
	$c .= "#dc-modal [hidden] { display: none !important; }\n";

	// Dolna sekcja: dwa równe kontenery, odstępy po bokach i między nimi równe
	$c .= "{$ac} { display: flex; justify-content: space-evenly; align-items: stretch; margin-top: 22px; }\n";
	$bw = max( 20, min( 48, (float) $s['popup_btn_width'] ) ); // dwa przyciski zawsze się mieszczą
	$c .= "{$ce} { flex: 0 1 {$bw}%; display: flex; justify-content: center; }\n";
	$c .= "#dc-conflict .dc-act[hidden] { display: none; }\n"; // przełączanie „Zmień datę” / „Przejdź do koszyka”
	$c .= "{$bt} { display: flex; align-items: center; justify-content: center; width: 100%; box-sizing: border-box; padding: " . (float) $s['popup_btn_pad_v'] . "px 10px; line-height: 1.25; border: 1.5px solid {$line}; border-radius: " . (float) $s['popup_btn_radius'] . "px; background: #fff !important; color: #2b2b2b !important; cursor: pointer; font-family: inherit; font-size: " . $px( 'popup_btn_size' ) . ';' . $fw( 'popup_btn_weight' ) . " text-align: center; text-decoration: none !important; transition: background .15s, border-color .15s; }\n";
	$c .= $with( $bt, array( ':hover', ':focus' ) ) . " { background: {$soft_hov} !important; border-color: {$accent} !important; color: #2b2b2b !important; }\n";
	$pw = '' === (string) $s['popup_btn_weight'] ? 700 : min( 900, (int) $s['popup_btn_weight'] + 100 ); // główny o stopień grubszy
	$c .= "{$pr} { background: {$p_bg} !important; color: {$p_txt} !important; border-color: {$accent} !important; font-weight: {$pw}; }\n";
	$c .= $with( $pr, array( ':hover', ':focus' ) ) . " { background: {$p_hbg} !important; color: {$p_htxt} !important; border-color: {$accent} !important; }\n";
	$c .= "#dc-modal .dc-act .dc-ok:disabled, #dc-conflict .dc-act .dc-ok:disabled, #rzd-mods .rzd-act .rzd-ok:disabled { opacity: .4; cursor: not-allowed; }\n";
	// Okienko modyfikacji (moduł 10): pasek „Dopłata” nad przyciskami ma już dolny margines.
	$c .= "#rzd-mods .rzd-actions { margin-top: 6px; }\n";

	// Okienko harmonogramu zestawu (moduł 05): dzień = wiersz; po lewej
	// nazwa dnia + dd.mm.rr, po prawej dania z miniaturami 48 px, dodatki, przycisk.
	$c .= "#rwz-harmono .dc-panel { max-width: 560px; }\n";
	// przyklejony pasek u góry (tytuł + krzyżyk). Panel ma padding 24 px,
	// więc pasek wychodzi na krawędzie (-24 px) i klei się do samej góry (top: -24px).
	$c .= "#rwz-harmono .rwz-hm-head { position: sticky; top: -24px; z-index: 3; display: flex; align-items: center; gap: 12px; margin: -24px -24px 12px; padding: 14px 16px 12px 24px; background: rgba({$rgb},.97); border-bottom: 1px solid {$line}; border-radius: 14px 14px 0 0; -webkit-backdrop-filter: blur(6px); backdrop-filter: blur(6px); }\n";
	$c .= "#rwz-harmono .rwz-hm-head h3 { flex: 1; min-width: 0; margin: 0 !important; }\n";
	$c .= "#rwz-harmono .rwz-hm-x { flex: 0 0 36px; width: 36px; height: 36px; margin: 0; padding: 0; border: 1.5px solid {$accent} !important; border-radius: 50%; background: #fff !important; color: #2b2b2b !important; font-size: 16px; line-height: 1; cursor: pointer; display: flex; align-items: center; justify-content: center; box-shadow: none; }\n";
	$c .= $with( '#rwz-harmono .rwz-hm-x', array( ':hover', ':focus' ) ) . " { background: {$soft_hov} !important; color: #2b2b2b !important; }\n";
	$c .= "#rwz-harmono .rwz-hm-body { font-size: {$x_sz};" . $fw( 'popup_text_weight' ) . " color: {$txt}; }\n";
	$c .= "#rwz-harmono .rwz-hm-empty { margin: 0; color: {$muted}; }\n";
	$c .= "#rwz-harmono .rwz-hm-day { display: flex; gap: 14px; padding: 12px 10px; border-bottom: 1px solid {$line}; }\n";
	$c .= "#rwz-harmono .rwz-hm-day:last-child { border-bottom: 0; }\n";
	$c .= "#rwz-harmono .rwz-hm-day.is-today { box-shadow: inset 0 0 0 2px {$accent}; border-radius: 12px; border-bottom-color: transparent; }\n";
	$c .= "#rwz-harmono .rwz-hm-day.is-past { opacity: .45; }\n";
	$c .= "#rwz-harmono .rwz-hm-day.is-past img { filter: grayscale(1); }\n";
	$c .= "#rwz-harmono .rwz-hm-date { flex: 0 0 96px; font-size: {$l_sz}; line-height: 1.3; }\n";
	$c .= "#rwz-harmono .rwz-hm-date strong { display: block; font-weight: 700; }\n";
	$c .= "#rwz-harmono .rwz-hm-date span { display: block; color: {$faint}; }\n";
	$c .= "#rwz-harmono .rwz-hm-date em { display: inline-block; margin-top: 4px; padding: 1px 8px; border-radius: 10px; background: {$accent}; color: {$on_accent}; font-style: normal; font-size: 11px; font-weight: 700; }\n";
	$c .= "#rwz-harmono .rwz-hm-main { flex: 1; min-width: 0; }\n";
	$c .= "#rwz-harmono .rwz-hm-dishes { list-style: none; margin: 0; padding: 0; }\n";
	$c .= "#rwz-harmono .rwz-hm-dishes li { display: flex; align-items: center; gap: 10px; margin: 0 0 6px; padding: 0; line-height: 1.3; }\n";
	$c .= "#rwz-harmono .rwz-hm-dishes li::before { content: none; }\n";
	// miniatura klikalna → duże zdjęcie (#rwz-hm-zoom, nad okienkiem).
	$c .= "#rwz-harmono img.rwz-hm-img { cursor: zoom-in; }\n";
	$c .= "#rwz-hm-zoom { position: fixed; inset: 0; z-index: 100005; display: flex; align-items: center; justify-content: center; padding: 16px; background: rgba(0,0,0,.82); cursor: zoom-out; }\n#rwz-hm-zoom[hidden] { display: none !important; }\n";
	$c .= "#rwz-hm-zoom figure { margin: 0; max-width: 100%; text-align: center; }\n";
	$c .= "#rwz-hm-zoom img { display: block; max-width: min(92vw, 900px); max-height: 80vh; width: auto; height: auto; margin: 0 auto; border-radius: 12px; box-shadow: 0 10px 40px rgba(0,0,0,.5); }\n";
	$c .= "#rwz-hm-zoom figcaption { margin-top: 10px; color: #fff; font-size: 16px; font-weight: 600; }\n";
	$c .= "#rwz-hm-zoom .rwz-hm-zoom-x { position: absolute; top: calc(12px + env(safe-area-inset-top, 0px)); right: 12px; width: 40px; height: 40px; padding: 0; border: 0 !important; border-radius: 50%; background: rgba(255,255,255,.92) !important; color: #2b2b2b !important; font-size: 18px; line-height: 40px; cursor: pointer; }\n";
	$c .= "#rwz-harmono img.rwz-hm-img { flex: 0 0 48px; width: 48px; height: 48px; max-width: none; object-fit: cover; border-radius: 10px; margin: 0; }\n";
	$c .= "#rwz-harmono .rwz-hm-addons { margin-top: 2px; color: {$muted}; font-size: " . max( 10, (float) $s['popup_text_size'] - 1 ) . "px; }\n";
	// przycisk pod daniami na całą szerokość wiersza (wiersz się zawija).
	$c .= "#rwz-harmono .rwz-hm-day { flex-wrap: wrap; row-gap: 10px; }\n";
	$c .= "#rwz-harmono .rwz-hm-side { flex: 0 0 100%; }\n";
	$c .= "#rwz-harmono .rwz-hm-add { display: block; width: 100%; margin: 0; padding: 10px 14px; border: 1.5px solid {$accent} !important; border-radius: " . min( 10, (float) $s['popup_btn_radius'] ) . "px; background: #fff !important; color: #2b2b2b !important; cursor: pointer; font-family: inherit; font-size: {$x_sz}; font-weight: 600; line-height: 1.25; text-align: center; text-decoration: none; transition: background .15s; }\n";
	$c .= $with( '#rwz-harmono .rwz-hm-add', array( ':hover', ':focus' ) ) . " { background: {$soft_hov} !important; color: #2b2b2b !important; }\n";
	$c .= "#rwz-harmono .rwz-hm-closed { display: block; color: {$faint}; font-size: 12px; line-height: 1.25; text-align: center; }\n";
	$c .= "@media (max-width: 480px) { #rwz-harmono .rwz-hm-day { gap: 10px; padding: 10px 6px; } #rwz-harmono .rwz-hm-date { flex-basis: 78px; } }\n";

	// przegląd zamówienia (moduł 10) – pasek z tytułem i ✕ u góry, podsumowanie
	// z przyciskiem u dołu (oba przyklejone), lista pomiędzy. Telefon: pełny ekran.
	$c .= "#rzd-review .dc-panel { max-width: 560px; }\n";
	$c .= "#rzd-review .rzd-rv-head { position: sticky; top: -24px; z-index: 3; display: flex; align-items: center; gap: 12px; margin: -24px -24px 12px; padding: 14px 16px 12px 24px; background: rgba({$rgb},.97); border-bottom: 1px solid {$line}; border-radius: 14px 14px 0 0; }\n";
	$c .= "#rzd-review .rzd-rv-head h3 { flex: 1; min-width: 0; margin: 0 !important; }\n";
	$c .= "#rzd-review .rzd-rv-x { flex: 0 0 36px; width: 36px; height: 36px; margin: 0; padding: 0; border: 1.5px solid {$accent} !important; border-radius: 50%; background: #fff !important; color: #2b2b2b !important; font-size: 16px; line-height: 1; cursor: pointer; display: flex; align-items: center; justify-content: center; box-shadow: none; }\n";
	$c .= $with( '#rzd-review .rzd-rv-x', array( ':hover', ':focus' ) ) . " { background: {$soft_hov} !important; }\n";
	$c .= "#rzd-review .rzd-rv-list { font-size: {$x_sz};" . $fw( 'popup_text_weight' ) . " color: {$txt}; }\n";
	$c .= "#rzd-review .rzd-rv-item { padding: 14px 0; border-bottom: 1px solid {$line}; }\n";
	$c .= "#rzd-review .rzd-rv-item:last-child { border-bottom: 0; }\n";
	$c .= "#rzd-review .rzd-rv-name { display: flex; align-items: baseline; gap: 10px; font-size: {$l_sz}; font-weight: 700; line-height: 1.3; }\n";
	$c .= "#rzd-review .rzd-rv-name span { flex: 1; min-width: 0; }\n";
	$c .= "#rzd-review .rzd-rv-price { flex: 0 0 auto; white-space: nowrap; }\n";
	// kosz przy pozycji + pasek „Usunięto … Cofnij”.
	$c .= "#rzd-review .rzd-rv-del { flex: 0 0 32px; width: 32px; height: 32px; margin: -6px -4px -6px 2px; padding: 0; border: 0 !important; border-radius: 50%; background: transparent !important; color: {$muted} !important; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; box-shadow: none !important; align-self: center; }\n";
	$c .= $with( '#rzd-review .rzd-rv-del', array( ':hover', ':focus' ) ) . " { color: #d63638 !important; background: " . $mix( $txt, $pbg, .10 ) . " !important; }\n";
	$c .= "#rzd-review .rzd-rv-del:disabled { opacity: .4; cursor: default; }\n";
	$c .= "#rzd-review .rzd-rv-undo { display: flex; align-items: center; justify-content: space-between; gap: 10px; margin: 0 0 12px; padding: 10px 12px; border: 1px solid {$line}; border-radius: 10px; background: " . $mix( $txt, $pbg, .08 ) . "; color: {$txt}; font-size: 14px; }\n";
	$c .= "#rzd-review .rzd-rv-undo span { flex: 1; min-width: 0; }\n";
	$c .= "#rzd-review .rzd-rv-notice { margin: 0 0 12px; padding: 10px 12px; border: 1px solid #b4540a; border-radius: 10px; background: #fff4ec; color: #7a3606; font-size: 14px; line-height: 1.45; }\n";
	$c .= "#rzd-review .rzd-rv-undo-btn { flex: 0 0 auto; padding: 6px 14px; border: 1.5px solid {$accent} !important; border-radius: 8px; background: #fff !important; color: #2b2b2b !important; font: inherit; font-weight: 700; cursor: pointer; box-shadow: none !important; }\n";
	$c .= "#rzd-review img.rzd-rv-img { display: block; width: 120px; height: 120px; max-width: 100%; object-fit: cover; border-radius: 10px; margin: 8px 0; }\n";
	$c .= "#rzd-review .rzd-rv-sklad, #rzd-review .rzd-rv-mods { margin-top: 4px; color: {$muted}; line-height: 1.45; }\n";
	$c .= "#rzd-review .rzd-rv-mods { color: {$txt}; }\n";
	$c .= "#rzd-review .rzd-rv-comps { list-style: none; margin: 8px 0 0; padding: 0; }\n";
	$c .= "#rzd-review .rzd-rv-comps li { display: flex; gap: 10px; align-items: flex-start; margin: 0 0 8px; padding: 0; line-height: 1.35; }\n";
	$c .= "#rzd-review .rzd-rv-comps li::before { content: none; }\n";
	$c .= "#rzd-review .rzd-rv-comps img { flex: 0 0 48px; width: 48px; height: 48px; object-fit: cover; border-radius: 8px; margin: 0; }\n";
	$c .= "#rzd-review .rzd-rv-add { display: block; width: 100%; margin: 10px 0 0; padding: 10px 14px; border: 1.5px solid {$accent} !important; border-radius: " . min( 10, (float) $s['popup_btn_radius'] ) . "px; background: #fff !important; color: #2b2b2b !important; cursor: pointer; font-family: inherit; font-size: {$x_sz}; font-weight: 600; line-height: 1.25; text-align: center; }\n";
	$c .= $with( '#rzd-review .rzd-rv-add', array( ':hover', ':focus' ) ) . " { background: {$soft_hov} !important; }\n";
	$c .= "#rzd-review .rzd-rv-foot { position: sticky; bottom: -24px; z-index: 3; margin: 12px -24px -24px; padding: 12px 24px 16px; background: rgba({$rgb},.97); border-top: 1px solid {$line}; border-radius: 0 0 14px 14px; }\n";
	$c .= "#rzd-review .rzd-rv-sum { font-size: {$x_sz}; color: {$txt}; }\n";
	$c .= "#rzd-review .rzd-rv-sum div { display: flex; justify-content: space-between; gap: 10px; margin: 2px 0; }\n";
	$c .= "#rzd-review .rzd-rv-sum .rzd-rv-total { font-weight: 700; font-size: {$l_sz}; margin-top: 6px; }\n";
	$c .= "#rzd-review .rzd-rv-sum small { display: block; color: {$faint}; font-size: 12px; text-align: right; }\n";
	$c .= "#rzd-review .dc-actions { margin-top: 12px; }\n#rzd-review .dc-act { flex: 1 1 100%; }\n";
	$c .= "@media (max-width: 600px) { #rzd-review { padding: 0; } #rzd-review .dc-panel { max-width: none; width: 100%; height: 100%; max-height: none; border-radius: 0; } #rzd-review .rzd-rv-head { border-radius: 0; padding-top: calc(14px + env(safe-area-inset-top, 0px)); } #rzd-review .rzd-rv-foot { border-radius: 0; padding-bottom: calc(16px + env(safe-area-inset-bottom, 0px)); } }\n";

	// Okienko "Dodano do koszyka": lista pozycji
	$c .= "#kc-added .kc-added-main { font-weight: 700; color: {$txt}; font-size: 14px; }\n";
	$c .= "#kc-added ul { margin: 6px 0 0 18px; padding: 0; color: {$txt}; font-size: 14px; }\n";

	// okienko modyfikacji (moduł 10) ma własny styl z ciemnym tekstem –
	// przy innym kolorze tekstu/tła okienek podmieniamy tylko kolory napisów.
	if ( '#2b2b2b' !== strtolower( $txt ) || $is_dark ) {
		$c .= "#rzd-mods .rzd-panel, #rzd-mods h3, #rzd-mods .rzd-gh { color: {$txt} !important; }\n";
		$c .= "#rzd-mods .rzd-section-desc, #rzd-mods .rzd-lock-note { color: {$muted} !important; }\n";
		$c .= "#rzd-mods .rzd-stepper-btn { border-color: {$txt} !important; color: {$txt} !important; }\n";
		$c .= "#rzd-mods .rzd-stepper-btn:hover { background: {$txt} !important; color: {$pbg} !important; }\n";
		$c .= "#rzd-mods .rzd-square.rzd-on, #rzd-mods .rzd-tap.rzd-on { border-color: {$accent} !important; }\n";
		// pasek „Dopłata / Razem” (dawniej jasnoszary #f6f6f6 – na ciemnym okienku biały pas z niewidocznym tekstem).
		$c .= "#rzd-mods .rzd-summary { background: " . $mix( $txt, $pbg, .10 ) . " !important; border-color: " . $mix( $txt, $pbg, .22 ) . " !important; color: {$txt} !important; }\n";
		$c .= "#rzd-mods .rzd-section-block { border-bottom-color: " . $mix( $txt, $pbg, .22 ) . " !important; }\n";
	}
	return $c;
}

/**
 * Jednorazowa migracja: pierwsza wersja panelu miała czarne domyślne kolory
 * przycisku (#222222 / biały tekst na hoverze). Kto kiedykolwiek kliknął
 * "Zapisz" w panelu, zapisał je na stałe – i nowe, jasne domyślne (złoty
 * akcent, biały hover) nigdy się u niego nie pojawiły. Podmieniamy WYŁĄCZNIE
 * wartości identyczne ze starymi domyślnymi; wszystko, co ktoś ustawił po
 * swojemu, zostaje nietknięte. Wykonuje się raz.
 */
add_action( 'init', function () {
	if ( get_option( 'rzd_style_migrated_2131' ) ) {
		return;
	}
	$saved = get_option( 'rzd_list_style', null );
	if ( is_array( $saved ) ) {
		$old_defaults = array(
			'button_text_color'   => '#222222',
			'button_border_color' => '#222222',
			'button_hover_bg'     => '#222222',
			'button_hover_text'   => '#ffffff',
		);
		$new     = rzd_list_style_defaults();
		$changed = false;
		foreach ( $old_defaults as $key => $old ) {
			if ( isset( $saved[ $key ] ) && strtolower( $saved[ $key ] ) === $old ) {
				$saved[ $key ] = $new[ $key ];
				$changed       = true;
			}
		}
		if ( $changed ) {
			update_option( 'rzd_list_style', $saved, true );
		}
	}
	update_option( 'rzd_style_migrated_2131', '1', true );
}, 5 );

// Doklejamy PO statycznym pliku CSS (moduł 03) – ta sama kolejność ładowania
// wygrywa remisy specyficzności, więc te reguły faktycznie nadpisują plik.
add_action( 'wp_enqueue_scripts', function () {
	if ( ! wp_style_is( 'rzd-lista-zamowien', 'registered' ) && ! wp_style_is( 'rzd-lista-zamowien', 'enqueued' ) ) {
		return; // moduł 03 nie zarejestrował stylu (np. wyłączony) – nie ma do czego doklejać
	}
	// CSS z panelu jako PLIK (uploads/rzd/), a nie wklejany w każdą
	// stronę – przeglądarka trzyma go w pamięci podręcznej, serwer nie składa
	// go od nowa przy każdym wyświetleniu. Nazwa pliku zawiera skrót ustawień,
	// więc po zmianie w panelu powstaje nowy plik. Gdy zapis się nie uda –
	// jak dawniej, CSS wklejony w stronę.
	$file = rzd_style_css_file();
	if ( $file ) {
		wp_enqueue_style( 'rzd-lista-custom', $file, array( 'rzd-lista-zamowien' ), null );
	} else {
		wp_add_inline_style( 'rzd-lista-zamowien', rzd_list_style_css() );
	}
}, 20 );

/**
 * Adres pliku CSS z ustawieniami „Wygląd listy” (tworzy go, gdy brakuje albo
 * ustawienia/wersja się zmieniły). '' = nie da się zapisać – użyj CSS w stronie.
 */
function rzd_style_css_file() {
	$key  = substr( md5( RZD_PLUGIN_VERSION . '|' . maybe_serialize( get_option( 'rzd_list_style', array() ) ) ), 0, 12 );
	$info = get_option( 'rzd_style_css_file', array() );
	$up   = wp_upload_dir( null, false );
	if ( ! empty( $up['error'] ) ) {
		return '';
	}
	$dir  = trailingslashit( $up['basedir'] ) . 'rzd';
	$name = 'rzd-wyglad-' . $key . '.css';
	$path = $dir . '/' . $name;
	$url  = set_url_scheme( trailingslashit( $up['baseurl'] ) . 'rzd/' . $name );
	if ( is_array( $info ) && isset( $info['key'] ) && $info['key'] === $key && file_exists( $path ) ) {
		return $url;
	}
	if ( ! wp_mkdir_p( $dir ) ) {
		return '';
	}
	$css = "/* Restauracja – Wygląd listy (wygenerowane " . gmdate( 'Y-m-d H:i' ) . ") */\n" . rzd_list_style_css();
	if ( false === @file_put_contents( $path, $css, LOCK_EX ) ) { // phpcs:ignore
		return '';
	}
	// Stare pliki (poprzednie ustawienia) usuwamy.
	foreach ( (array) glob( $dir . '/rzd-wyglad-*.css' ) as $old ) {
		if ( $old && $old !== $path ) {
			@unlink( $old ); // phpcs:ignore
		}
	}
	update_option( 'rzd_style_css_file', array( 'key' => $key ), true );
	return $url;
}

