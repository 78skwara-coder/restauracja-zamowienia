<?php
/**
 * Moduł 15-wyglad-listy – zapis i podgląd „Wyglądu listy” (ekran: Panel restauracji → Wygląd, moduł 34).
 * Część modułu (pliki wczytywane po kolei – kolejność jak w dawnym jednym pliku).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 3. ZAPIS I PODGLĄD (Panel restauracji → Wygląd, moduł 34; do 2.45.0 strona kokpitu)
 * ============================================================ */
/**
 * Ustawienia z płaskiej tablicy pól (nazwy jak dawny formularz: klucz, m_klucz, klucz_on, m_on_<sekcja>).
 * Start od zapisanych – pola telefonu sekcji wyłączonych zostają na później (jak dotąd).
 */
function rzd_list_style_build( $p ) {
	$p        = is_array( $p ) ? $p : array();
	$defaults = rzd_list_style_defaults();
	$s        = rzd_list_style_get( true );
	foreach ( rzd_list_style_fields() as $sid => $sec ) {
		foreach ( $sec[1] as $f ) {
			if ( empty( $f['k'] ) ) {
				continue;
			}
			$s = rzd_style_clean_field( $s, $f, $p, '', $defaults );
		}
		if ( isset( $sec[2] ) && false === $sec[2] ) {
			continue; // sekcja bez wersji telefonu
		}
		$on                  = empty( $p[ 'm_on_' . $sid ] ) ? 0 : 1;
		$s[ 'm_on_' . $sid ] = $on;
		if ( $on ) {
			foreach ( $sec[1] as $f ) {
				if ( ! empty( $f['k'] ) && empty( $f['shared'] ) ) {
					$s = rzd_style_clean_field( $s, $f, $p, 'm_', $defaults );
				}
			}
		}
	}
	$s['style_v'] = 5;
	return $s;
}

function rzd_list_style_save( $p ) {
	update_option( 'rzd_list_style', rzd_list_style_build( $p ), true );
	return rzd_list_style_get( true );
}

/** Podgląd NIEZAPISANYCH ustawień (panel – na żywo): dokument jak rzd_style_preview_doc z wartościami z $p. */
function rzd_list_style_preview( $p ) {
	$draft = rzd_list_style_build( $p );
	$f     = function () use ( $draft ) {
		return $draft;
	};
	add_filter( 'pre_option_rzd_list_style', $f, 99 );
	rzd_list_style_get( true );
	$doc = rzd_style_preview_doc( $draft );
	remove_filter( 'pre_option_rzd_list_style', $f, 99 );
	rzd_list_style_get( true );
	return $doc;
}

// Jedno pole z formularza → $s. $pre = '' (komputer) albo 'm_' (telefon).
// Gdy pola telefonu brak w POST, wartością zapasową jest wartość komputera.
function rzd_style_clean_field( $s, $f, $p, $pre, $defaults ) {
	$k    = $f['k'];
	$name = $pre . $k;
	$fall = ( '' === $pre ) ? ( isset( $defaults[ $k ] ) ? $defaults[ $k ] : '' ) : $s[ $k ];
	switch ( $f['t'] ) {
		case 'check':
			$s[ $name ] = empty( $p[ $name ] ) ? 0 : 1;
			break;
		case 'color':
			$s[ $name ] = ( isset( $p[ $name ] ) && preg_match( '/^#[0-9a-fA-F]{6}$/', $p[ $name ] ) ) ? $p[ $name ] : $fall;
			if ( ! empty( $f['toggle'] ) ) {
				$s[ $name . '_on' ] = empty( $p[ $name . '_on' ] ) ? 0 : 1;
			}
			break;
		case 'number':
			$s[ $name ] = ( isset( $p[ $name ] ) && '' !== $p[ $name ] && is_numeric( $p[ $name ] ) ) ? (float) $p[ $name ] : $fall;
			break;
		case 'weight':
		case 'select':
			$s[ $name ] = ( isset( $p[ $name ] ) && array_key_exists( (string) $p[ $name ], $f['o'] ) ) ? (string) $p[ $name ] : $fall;
			break;
		case 'title':
			$t          = isset( $p[ $name ] ) ? trim( sanitize_text_field( $p[ $name ] ) ) : '';
			$s[ $name ] = '' !== $t ? $t : $defaults[ $k ];
			break;
		default: // text
			$s[ $name ] = sanitize_text_field( isset( $p[ $name ] ) ? $p[ $name ] : $fall );
	}
	return $s;
}

/**
 * Podgląd: osobny dokument w <iframe>, więc reguły @media działają według
 * szerokości ramki – w ramce telefonu widać dokładnie wygląd telefonu.
 */
function rzd_style_preview_doc( $s ) {
	$css_url = RZD_PLUGIN_URL . 'assets/css/lista-zamowien.css?v=' . rawurlencode( RZD_PLUGIN_VERSION . '.' . (int) @filemtime( RZD_PLUGIN_DIR . 'assets/css/lista-zamowien.css' ) );
	$fonts   = function_exists( 'rzd_fonts_url' ) ? '<link rel="stylesheet" href="' . esc_url( function_exists( 'rzd_fonts_href' ) ? rzd_fonts_href() : rzd_fonts_url() ) . '">' : '';
	$times   = '';
	foreach ( array( '08:30–09:30', '09:30–10:30', '10:30–11:30', '11:30–12:30' ) as $i => $t ) {
		$times .= '<button type="button" class="dc-time' . ( 1 === $i ? ' dc-on' : '' ) . '">' . $t . '</button>';
	}
	ob_start();
	?>
<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<?php echo $fonts; // phpcs:ignore ?>
<link rel="stylesheet" href="<?php echo esc_url( $css_url ); ?>">
<style><?php echo rzd_list_style_css(); // phpcs:ignore ?></style>
<style>
body{margin:0;padding:14px;background:#fafafa;font-family:'Lato',sans-serif}
.rzd-prev-label{font:600 12px/1.4 sans-serif;color:#777;margin:22px 0 8px;text-transform:uppercase;letter-spacing:.05em}
#dc-modal.rzd-prev-popup{position:static!important;display:flex!important;inset:auto;padding:28px 12px;border-radius:12px;background:linear-gradient(135deg,#b5532e 0%,#e8b04a 45%,#7a9e5b 70%,#3d6b8f 100%)!important}
.rzd-prev-thumb{width:100%;height:100%;background:#d9cdb8;border-radius:inherit;display:flex;align-items:center;justify-content:center;color:#8a7a5c;font-size:11px}
</style></head><body>
<div class="rl">
	<div class="rl-cat-heading">Zupy</div>
	<div class="rl2-row">
		<div class="rl-thumb"><div class="rzd-prev-thumb">zdjęcie</div></div>
		<span class="rl-name">Pomidorowa z makaronem</span>
		<div class="rl-price"><?php echo function_exists( 'wc_price' ) ? rzd_price_parts_html( 12 ) : '12,00 zł'; // phpcs:ignore ?></div>
		<div class="rl2-rest">
			<div class="rl2-allergens"><span class="rl-alergen">Gluten</span><span class="rl-alergen">Jaja</span></div>
			<details class="rl-harmono"><summary><?php echo esc_html( rzd_list_label( 'harmono' ) ); ?></summary><div class="rl-harmono-body">Pon, Śr, Pt</div></details>
			<details class="rl2-delivery"><summary><?php echo esc_html( rzd_list_label( 'delivery' ) ); ?></summary><div class="rl2-delivery-body"><strong>Pon–Pt:</strong> 08:30–09:30, 09:30–10:30</div></details>
			<div class="rl2-order"><div class="rl-buy">
				<div class="rl2-qty"><button type="button" class="rl2-qty-btn rl2-qty-minus">−</button><input type="number" value="1" readonly><button type="button" class="rl2-qty-btn rl2-qty-plus">+</button></div>
				<button type="button">Dodaj do koszyka</button>
			</div></div>
		</div>
		<div class="rl2-bottom">
			<div class="rl-short">Domowa pomidorowa z makaronem i natką pietruszki.</div>
			<details class="rl-more"><summary><?php echo esc_html( rzd_list_label( 'more' ) ); ?></summary><div>Pełny opis produktu.</div></details>
		</div>
	</div>
</div>
<div class="rzd-prev-label">Strona kategorii sklepu (motyw może coś zmienić)</div>
<?php $rzd_ph = 'data:image/svg+xml,' . rawurlencode( '<svg xmlns="http://www.w3.org/2000/svg" width="300" height="300"><rect width="300" height="300" fill="#d9cdb8"/><text x="150" y="155" font-family="sans-serif" font-size="18" fill="#8a7a5c" text-anchor="middle">zdjęcie</text></svg>' ); ?>
<div class="woocommerce"><ul class="products" style="list-style:none;margin:0;padding:0;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px">
	<?php foreach ( array( array( 'Cynamonki', 12 ), array( 'Wypiek dnia', 15 ) ) as $rzd_pp ) : ?>
	<li class="product" style="margin:0;width:auto;float:none"><a href="#" onclick="return false"><img src="<?php echo esc_attr( $rzd_ph ); ?>" alt="" style="width:100%;height:auto;display:block"><h2 class="woocommerce-loop-product__title"><?php echo esc_html( $rzd_pp[0] ); ?></h2><span class="price"><?php echo function_exists( 'wc_price' ) ? wc_price( $rzd_pp[1] ) : esc_html( $rzd_pp[1] . ',00 zł' ); // phpcs:ignore ?></span></a><a href="#" class="button" onclick="return false">Dodaj do koszyka</a></li>
	<?php endforeach; ?>
</ul></div>
<div class="rzd-prev-label">Kafle kategorii [kategorie_zamowien]</div>
<?php echo function_exists( 'rzd_kategorie_tiles_html' ) ? rzd_kategorie_tiles_html( rzd_kategorie_terms( '' ), 4 ) : ''; // phpcs:ignore ?>
<div class="rzd-prev-label">Okienko (kolorowe tło pokazuje przezroczystość)</div>
<div id="dc-modal" class="rzd-prev-popup"><div class="dc-panel">
	<h3 class="dc-title">Wybierz termin dostawy</h3>
	<p class="dc-msg">Najwcześniejszy możliwy termin jest zaznaczony. Całe zamówienie zostanie dostarczone o wybranej godzinie.</p>
	<label class="dc-field">Miejscowość dostawy<select class="dc-town"><option>Piła - miasto</option></select></label>
	<label class="dc-field">Data dostawy<select class="dc-date"><option>piątek, 2 października 2026</option></select></label>
	<div class="dc-field">Godzina dostawy<div class="dc-times"><?php echo $times; // phpcs:ignore ?></div></div>
	<div class="dc-actions">
		<div class="dc-act"><button type="button" class="dc-cancel">Anuluj</button></div>
		<div class="dc-act"><button type="button" class="dc-ok">Zatwierdź termin</button></div>
	</div>
</div></div>
</body></html>
	<?php
	return ob_get_clean();
}
