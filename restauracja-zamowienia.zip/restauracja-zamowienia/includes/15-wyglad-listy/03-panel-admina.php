<?php
/**
 * Moduł 15-wyglad-listy – panel admina „Wygląd listy”.
 * Część modułu (pliki wczytywane po kolei – kolejność jak w dawnym jednym pliku).
 */

/* ============================================================
 * 3. PANEL ADMINA
 * ============================================================ */
add_action( 'admin_menu', function () {
	add_menu_page( 'Wygląd listy', 'Wygląd listy', 'rzd_p_settings', 'rzd-wyglad-listy', 'rzd_render_style_page', 'dashicons-admin-appearance', 58 );
} );

add_action( 'admin_post_rzd_save_list_style', function () {
	if ( ! current_user_can( 'rzd_p_settings' ) ) {
		wp_die( 'Brak uprawnień.' );
	}
	check_admin_referer( 'rzd_save_list_style' );

	$p        = wp_unslash( $_POST );
	$defaults = rzd_list_style_defaults();
	$s        = rzd_list_style_get(); // start od zapisanych – m_* sekcji wyłączonych zostają na później

	foreach ( rzd_list_style_fields() as $sid => $sec ) {
		foreach ( $sec[1] as $f ) {
			if ( empty( $f['k'] ) ) {
				continue;
			}
			$s = rzd_style_clean_field( $s, $f, $p, '', $defaults );
		}
		if ( isset( $sec[2] ) && false === $sec[2] ) {
			continue; // sekcja bez wersji telefonu
		}
		$on                  = empty( $p[ 'm_on_' . $sid ] ) ? 0 : 1;
		$s[ 'm_on_' . $sid ] = $on;
		if ( $on ) {
			foreach ( $sec[1] as $f ) {
				if ( ! empty( $f['k'] ) && empty( $f['shared'] ) ) {
					$s = rzd_style_clean_field( $s, $f, $p, 'm_', $defaults );
				}
			}
		}
	}
	$s['style_v'] = 5;

	update_option( 'rzd_list_style', $s, true );
	$view = ( isset( $p['rzd_view'] ) && 'mobile' === $p['rzd_view'] ) ? 'mobile' : 'desktop';
	wp_safe_redirect( add_query_arg( array( 'page' => 'rzd-wyglad-listy', 'saved' => 1, 'widok' => $view ), admin_url( 'admin.php' ) ) );
	exit;
} );

// Jedno pole z formularza → $s. $pre = '' (komputer) albo 'm_' (telefon).
// Gdy pola telefonu brak w POST, wartością zapasową jest wartość komputera.
function rzd_style_clean_field( $s, $f, $p, $pre, $defaults ) {
	$k    = $f['k'];
	$name = $pre . $k;
	$fall = ( '' === $pre ) ? ( isset( $defaults[ $k ] ) ? $defaults[ $k ] : '' ) : $s[ $k ];
	switch ( $f['t'] ) {
		case 'check':
			$s[ $name ] = empty( $p[ $name ] ) ? 0 : 1;
			break;
		case 'color':
			$s[ $name ] = ( isset( $p[ $name ] ) && preg_match( '/^#[0-9a-fA-F]{6}$/', $p[ $name ] ) ) ? $p[ $name ] : $fall;
			if ( ! empty( $f['toggle'] ) ) {
				$s[ $name . '_on' ] = empty( $p[ $name . '_on' ] ) ? 0 : 1;
			}
			break;
		case 'number':
			$s[ $name ] = ( isset( $p[ $name ] ) && '' !== $p[ $name ] && is_numeric( $p[ $name ] ) ) ? (float) $p[ $name ] : $fall;
			break;
		case 'weight':
		case 'select':
			$s[ $name ] = ( isset( $p[ $name ] ) && array_key_exists( (string) $p[ $name ], $f['o'] ) ) ? (string) $p[ $name ] : $fall;
			break;
		case 'title':
			$t          = isset( $p[ $name ] ) ? trim( sanitize_text_field( $p[ $name ] ) ) : '';
			$s[ $name ] = '' !== $t ? $t : $defaults[ $k ];
			break;
		default: // text
			$s[ $name ] = sanitize_text_field( isset( $p[ $name ] ) ? $p[ $name ] : $fall );
	}
	return $s;
}

// Jedno pole formularza. $pre = '' / 'm_'; $v = wartość do pokazania.
function rzd_style_field_html( $f, $s, $pre ) {
	$t = $f['t'];
	if ( 'note' === $t ) {
		return '<p class="description">' . esc_html( $f['l'] ) . '</p>';
	}
	if ( 'sub' === $t ) {
		return '<p class="rzd-field rzd-sub"><strong>' . esc_html( $f['l'] ) . '</strong></p>';
	}
	$k    = $f['k'];
	$name = $pre . $k;
	$val  = ( '' !== $pre && isset( $s[ $name ] ) ) ? $s[ $name ] : $s[ $k ];
	$id   = 'rzd-' . $name;
	$h    = '<p class="rzd-field">';
	switch ( $t ) {
		case 'check':
			$h .= '<label><input type="checkbox" name="' . esc_attr( $name ) . '" value="1"' . checked( ! empty( $val ), true, false ) . '> <strong>' . esc_html( $f['l'] ) . '</strong></label>';
			break;
		case 'color':
			if ( ! empty( $f['toggle'] ) ) {
				$on  = ( '' !== $pre && isset( $s[ $name . '_on' ] ) ) ? $s[ $name . '_on' ] : $s[ $k . '_on' ];
				$h  .= '<label><input type="checkbox" name="' . esc_attr( $name . '_on' ) . '" value="1"' . checked( ! empty( $on ), true, false ) . '> <strong>' . esc_html( $f['l'] ) . '</strong></label>';
				$h  .= ' <input type="color" name="' . esc_attr( $name ) . '" value="' . esc_attr( $val ) . '"> <span class="description">zaznacz, żeby nadpisać kolor z motywu</span>';
			} else {
				$h .= '<label for="' . esc_attr( $id ) . '"><strong>' . esc_html( $f['l'] ) . '</strong></label> <input id="' . esc_attr( $id ) . '" type="color" name="' . esc_attr( $name ) . '" value="' . esc_attr( $val ) . '">';
			}
			break;
		case 'number':
			$step = isset( $f['step'] ) ? $f['step'] : 1;
			$unit = isset( $f['u'] ) ? $f['u'] : 'px';
			$h   .= '<label for="' . esc_attr( $id ) . '"><strong>' . esc_html( $f['l'] ) . '</strong></label> <input id="' . esc_attr( $id ) . '" type="number" step="' . esc_attr( $step ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $val ) . '" style="width:90px;"> ' . esc_html( $unit );
			break;
		case 'weight':
		case 'select':
			$h .= '<label for="' . esc_attr( $id ) . '"><strong>' . esc_html( $f['l'] ) . '</strong></label> <select id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '">';
			foreach ( $f['o'] as $ov => $ol ) {
				$h .= '<option value="' . esc_attr( $ov ) . '"' . selected( (string) $val, (string) $ov, false ) . '>' . esc_html( $ol ) . '</option>';
			}
			$h .= '</select>';
			break;
		default: // text, title
			$h .= '<label for="' . esc_attr( $id ) . '"><strong>' . esc_html( $f['l'] ) . '</strong></label> <input id="' . esc_attr( $id ) . '" type="text" name="' . esc_attr( $name ) . '" value="' . esc_attr( $val ) . '" style="width:260px;">';
	}
	return $h . '</p>';
}

/**
 * Podgląd: osobny dokument w <iframe>, więc reguły @media działają według
 * szerokości ramki – w ramce telefonu widać dokładnie wygląd telefonu.
 */
function rzd_style_preview_doc( $s ) {
	$css_url = RZD_PLUGIN_URL . 'assets/css/lista-zamowien.css?v=' . rawurlencode( RZD_PLUGIN_VERSION . '.' . (int) @filemtime( RZD_PLUGIN_DIR . 'assets/css/lista-zamowien.css' ) );
	$fonts   = function_exists( 'rzd_fonts_url' ) ? '<link rel="stylesheet" href="' . esc_url( function_exists( 'rzd_fonts_href' ) ? rzd_fonts_href() : rzd_fonts_url() ) . '">' : '';
	$times   = '';
	foreach ( array( '08:30–09:30', '09:30–10:30', '10:30–11:30', '11:30–12:30' ) as $i => $t ) {
		$times .= '<button type="button" class="dc-time' . ( 1 === $i ? ' dc-on' : '' ) . '">' . $t . '</button>';
	}
	ob_start();
	?>
<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<?php echo $fonts; // phpcs:ignore ?>
<link rel="stylesheet" href="<?php echo esc_url( $css_url ); ?>">
<style><?php echo rzd_list_style_css(); // phpcs:ignore ?></style>
<style>
body{margin:0;padding:14px;background:#fafafa;font-family:'Lato',sans-serif}
.rzd-prev-label{font:600 12px/1.4 sans-serif;color:#777;margin:22px 0 8px;text-transform:uppercase;letter-spacing:.05em}
#dc-modal.rzd-prev-popup{position:static!important;display:flex!important;inset:auto;padding:28px 12px;border-radius:12px;background:linear-gradient(135deg,#b5532e 0%,#e8b04a 45%,#7a9e5b 70%,#3d6b8f 100%)!important}
.rzd-prev-thumb{width:100%;height:100%;background:#d9cdb8;border-radius:inherit;display:flex;align-items:center;justify-content:center;color:#8a7a5c;font-size:11px}
</style></head><body>
<div class="rl">
	<div class="rl-cat-heading">Zupy</div>
	<div class="rl2-row">
		<div class="rl-thumb"><div class="rzd-prev-thumb">zdjęcie</div></div>
		<span class="rl-name">Pomidorowa z makaronem</span>
		<div class="rl-price"><?php echo function_exists( 'wc_price' ) ? rzd_price_parts_html( 12 ) : '12,00 zł'; // phpcs:ignore ?></div>
		<div class="rl2-rest">
			<div class="rl2-allergens"><span class="rl-alergen">Gluten</span><span class="rl-alergen">Jaja</span></div>
			<details class="rl-harmono"><summary><?php echo esc_html( rzd_list_label( 'harmono' ) ); ?></summary><div class="rl-harmono-body">Pon, Śr, Pt</div></details>
			<details class="rl2-delivery"><summary><?php echo esc_html( rzd_list_label( 'delivery' ) ); ?></summary><div class="rl2-delivery-body"><strong>Pon–Pt:</strong> 08:30–09:30, 09:30–10:30</div></details>
			<div class="rl2-order"><div class="rl-buy">
				<div class="rl2-qty"><button type="button" class="rl2-qty-btn rl2-qty-minus">−</button><input type="number" value="1" readonly><button type="button" class="rl2-qty-btn rl2-qty-plus">+</button></div>
				<button type="button">Dodaj do koszyka</button>
			</div></div>
		</div>
		<div class="rl2-bottom">
			<div class="rl-short">Domowa pomidorowa z makaronem i natką pietruszki.</div>
			<details class="rl-more"><summary><?php echo esc_html( rzd_list_label( 'more' ) ); ?></summary><div>Pełny opis produktu.</div></details>
		</div>
	</div>
</div>
<div class="rzd-prev-label">Strona kategorii sklepu (motyw może coś zmienić)</div>
<?php $rzd_ph = 'data:image/svg+xml,' . rawurlencode( '<svg xmlns="http://www.w3.org/2000/svg" width="300" height="300"><rect width="300" height="300" fill="#d9cdb8"/><text x="150" y="155" font-family="sans-serif" font-size="18" fill="#8a7a5c" text-anchor="middle">zdjęcie</text></svg>' ); ?>
<div class="woocommerce"><ul class="products" style="list-style:none;margin:0;padding:0;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px">
	<?php foreach ( array( array( 'Cynamonki', 12 ), array( 'Wypiek dnia', 15 ) ) as $rzd_pp ) : ?>
	<li class="product" style="margin:0;width:auto;float:none"><a href="#" onclick="return false"><img src="<?php echo esc_attr( $rzd_ph ); ?>" alt="" style="width:100%;height:auto;display:block"><h2 class="woocommerce-loop-product__title"><?php echo esc_html( $rzd_pp[0] ); ?></h2><span class="price"><?php echo function_exists( 'wc_price' ) ? wc_price( $rzd_pp[1] ) : esc_html( $rzd_pp[1] . ',00 zł' ); // phpcs:ignore ?></span></a><a href="#" class="button" onclick="return false">Dodaj do koszyka</a></li>
	<?php endforeach; ?>
</ul></div>
<div class="rzd-prev-label">Kafle kategorii [kategorie_zamowien]</div>
<?php echo function_exists( 'rzd_kategorie_tiles_html' ) ? rzd_kategorie_tiles_html( rzd_kategorie_terms( '' ), 4 ) : ''; // phpcs:ignore ?>
<div class="rzd-prev-label">Okienko (kolorowe tło pokazuje przezroczystość)</div>
<div id="dc-modal" class="rzd-prev-popup"><div class="dc-panel">
	<h3 class="dc-title">Wybierz termin dostawy</h3>
	<p class="dc-msg">Najwcześniejszy możliwy termin jest zaznaczony. Całe zamówienie zostanie dostarczone o wybranej godzinie.</p>
	<label class="dc-field">Miejscowość dostawy<select class="dc-town"><option>Piła - miasto</option></select></label>
	<label class="dc-field">Data dostawy<select class="dc-date"><option>piątek, 2 października 2026</option></select></label>
	<div class="dc-field">Godzina dostawy<div class="dc-times"><?php echo $times; // phpcs:ignore ?></div></div>
	<div class="dc-actions">
		<div class="dc-act"><button type="button" class="dc-cancel">Anuluj</button></div>
		<div class="dc-act"><button type="button" class="dc-ok">Zatwierdź termin</button></div>
	</div>
</div></div>
</body></html>
	<?php
	return ob_get_clean();
}

function rzd_render_style_page() {
	if ( ! current_user_can( 'rzd_p_settings' ) ) {
		return;
	}
	$s    = rzd_list_style_get();
	$view = ( isset( $_GET['widok'] ) && 'mobile' === $_GET['widok'] ) ? 'mobile' : 'desktop'; // phpcs:ignore
	$doc  = rzd_style_preview_doc( $s );
	?>
	<div class="wrap rzd-style-wrap" data-view="<?php echo esc_attr( $view ); ?>">
		<h1>Wygląd listy</h1>
		<?php if ( isset( $_GET['saved'] ) ) : // phpcs:ignore ?>
			<div class="notice notice-success is-dismissible"><p>Zapisano.</p></div>
		<?php endif; ?>
		<p class="description">Lista zamówień (<code>[lista_zamowien]</code>) i okienka dla klienta. Komputer = ekran od <?php echo (int) RZD_STYLE_BREAKPOINT; ?> px szerokości, telefon = węższy. Telefon bierze ustawienia z komputera, chyba że w danej sekcji zaznaczysz „Na telefonie inaczej”.</p>

		<?php echo rzd_css_tag( 'assets/css/admin/rzd-wyglad-panel.css' ); // phpcs:ignore ?>

		<h2 class="nav-tab-wrapper">
			<a class="nav-tab" data-view="desktop">🖥 Komputer (i ustawienia wspólne)</a>
			<a class="nav-tab" data-view="mobile">📱 Telefon</a>
		</h2>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="rzd_save_list_style">
			<input type="hidden" name="rzd_view" value="<?php echo esc_attr( $view ); ?>">
			<?php wp_nonce_field( 'rzd_save_list_style' ); ?>

			<div class="rzd-style-cols">
				<div class="rzd-style-form">
					<div class="rzd-pane" data-view="desktop">
						<?php foreach ( rzd_list_style_fields() as $sid => $sec ) : ?>
							<div class="rzd-style-section">
								<h2><?php echo esc_html( $sec[0] ); ?></h2>
								<?php
								foreach ( $sec[1] as $f ) {
									echo rzd_style_field_html( $f, $s, '' ); // phpcs:ignore
								}
								?>
							</div>
						<?php endforeach; ?>
					</div>

					<div class="rzd-pane" data-view="mobile">
						<?php foreach ( rzd_list_style_fields() as $sid => $sec ) : ?>
							<?php
							$own    = array_filter( $sec[1], function ( $f ) { return empty( $f['shared'] ); } );
							$has_in = (bool) rzd_style_section_keys( $sec[1] );
							if ( ! $has_in ) {
								continue;
							}
							$on = ! empty( $s[ 'm_on_' . $sid ] );
							?>
							<div class="rzd-style-section rzd-mob-section<?php echo $on ? '' : ' rzd-mob-off'; ?>">
								<h2><?php echo esc_html( $sec[0] ); ?></h2>
								<label class="rzd-mob-toggle"><input type="checkbox" class="rzd-mob-on" name="<?php echo esc_attr( 'm_on_' . $sid ); ?>" value="1" <?php checked( $on ); ?>> Na telefonie inaczej niż na komputerze</label>
								<div class="rzd-mob-fields">
									<?php
									foreach ( $own as $f ) {
										echo rzd_style_field_html( $f, $s, 'm_' ); // phpcs:ignore
									}
									if ( count( $own ) < count( $sec[1] ) ) {
										echo '<p class="description">Pozostałe pola tej sekcji są wspólne – zmienisz je w zakładce Komputer.</p>';
									}
									?>
								</div>
							</div>
						<?php endforeach; ?>
					</div>

					<button type="submit" class="button button-primary button-large">Zapisz wygląd</button>
				</div>

				<div class="rzd-style-preview">
					<h2 style="margin-top:0;">Podgląd (po zapisaniu)</h2>
					<div class="rzd-prev rzd-prev-desktop" data-view="desktop">
						<div class="rzd-prev-frame"><iframe title="Podgląd – komputer" data-w="1000" srcdoc="<?php echo esc_attr( $doc ); ?>"></iframe></div>
						<p class="description">Komputer – ekran 1000 px pomniejszony do szerokości kolumny.</p>
					</div>
					<div class="rzd-prev rzd-prev-mobile" data-view="mobile">
						<div class="rzd-prev-frame"><iframe title="Podgląd – telefon" data-w="390" srcdoc="<?php echo esc_attr( $doc ); ?>"></iframe></div>
						<p class="description" style="text-align:center;">Telefon – 390 px, dokładnie tak jak na ekranie telefonu.</p>
					</div>
					<p class="description">Podgląd pokazuje ostatnio ZAPISANE ustawienia – zapisz, żeby zobaczyć efekt.</p>
				</div>
			</div>
		</form>
	</div>
	<?php echo rzd_js_tag( 'assets/js/admin/rzd-wyglad-panel.js' ); // phpcs:ignore ?>
	<?php
}
