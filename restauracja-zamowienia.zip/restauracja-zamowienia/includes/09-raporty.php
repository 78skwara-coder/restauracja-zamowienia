<?php
/**
 * SNIPPET 9: Raporty
 * Code Snippets → Run everywhere (pomiń pierwszą linię "<?php")
 *
 * Nowa pozycja w menu admina: "Raporty". Na start jest jeden raport:
 * "Zamówienia wg terminu dostawy" – wybierasz zakres dat (i opcjonalnie
 * godzin) dostawy, klikasz "Generuj CSV" i przeglądarka pobiera plik
 * (standardowe okno zapisu przeglądarki – WordPress nie może go zastąpić
 * własnym, ale efekt jest ten sam: wskazujesz, gdzie zapisać plik).
 *
 * Dwa warianty raportu:
 * - Szczegółowo wg terminu – wiersz na każdą pozycję w każdym terminie
 *   (data, godzina, produkt/danie, ilość, wartość).
 * - Podsumowanie produktów – jeden wiersz na produkt/danie z sumą ilości
 *   i wartości z całego wybranego zakresu (to, czego potrzebuje kuchnia
 *   do zbiorczego przygotowania).
 *
 * Wymaga snippetu 6 (DeliveryCalendar) – stamtąd bierze termin dostawy
 * zapisany przy zamówieniu. Rozpoznaje też dania z zestawów i dodatki
 * (snippet 4) – liczy je z osobna, po nazwie konkretnego dania/dodatku,
 * a nie po nazwie samego "Zestawu dnia".
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 1. MENU
 * ============================================================ */
add_action( 'admin_menu', function () {
	add_menu_page( 'Raporty', 'Raporty', 'manage_woocommerce', 'rr-raporty', 'rr_render_admin_page', 'dashicons-chart-bar', 58 );
} );

function rr_statuses_default() {
	// domyślnie liczymy zamówienia przyjęte do realizacji lub zrealizowane
	$s = array( 'wc-processing', 'wc-completed', 'wc-on-hold' );
	if ( function_exists( 'rzd_kitchen_statuses' ) ) {
		foreach ( array_keys( rzd_kitchen_statuses() ) as $slug ) {
			$s[] = 'wc-' . $slug;
		}
	}
	return $s;
}

/* ============================================================
 * 2. POBRANIE DANYCH: pozycje zamówień w zadanym zakresie
 * ============================================================ */
// Zwraca listę wierszy: [ 'date','time','name','qty','total', czy_dodatek ]
// $with_order = true -> dołącz nr zamówienia / klienta / adres (raport szczegółowy)
function rr_collect_rows( $date_from, $date_to, $time_from, $time_to, $only_confirmed, $with_order = false ) {
	$rows   = array();
	$meta_q = array(
		array( 'key' => '_dc_delivery_date', 'value' => array( $date_from, $date_to ), 'compare' => 'BETWEEN', 'type' => 'DATE' ),
	);

	$args = array(
		'limit'      => -1,
		'meta_query' => $meta_q, // phpcs:ignore
		'orderby'    => 'date',
		'order'      => 'ASC',
		'return'     => 'objects',
	);
	if ( $only_confirmed ) {
		$args['status'] = rr_statuses_default();
	}

	$orders = wc_get_orders( $args );

	foreach ( $orders as $order ) {
		$d = $order->get_meta( '_dc_delivery_date' );
		$t = $order->get_meta( '_dc_delivery_time' );
		if ( ! $d ) {
			continue;
		}
		if ( $time_from && $t && $t < $time_from ) {
			continue;
		}
		if ( $time_to && $t && $t > $time_to ) {
			continue;
		}

		$order_extra = array();
		if ( $with_order ) {
			$addr = trim( implode( ', ', array_filter( array(
				$order->get_shipping_address_1() ?: $order->get_billing_address_1(),
				$order->get_shipping_city() ?: $order->get_billing_city(),
				$order->get_shipping_postcode() ?: $order->get_billing_postcode(),
			) ) ) );
			$order_extra = array(
				'order_id' => $order->get_order_number(),
				'customer' => trim( $order->get_formatted_billing_full_name() ),
				'phone'    => $order->get_billing_phone(),
				'payment'  => function_exists( 'kuchnia_payment_text' ) ? kuchnia_payment_text( $order ) : $order->get_payment_method_title(),
				'address'  => $addr,
			);
		}

		foreach ( $order->get_items() as $item ) {
			$qty = (int) $item->get_quantity();
			if ( $qty <= 0 ) {
				continue;
			}
			$total  = (float) $item->get_total();
			$w_zest = $item->get_meta( 'W zestawie' );
			$dania  = $w_zest ? array_filter( array_map( 'trim', explode( ',', $w_zest ) ) ) : array();

			if ( $dania ) {
				// zestaw: liczymy KAŻDE danie z osobna pod jego własną nazwą
				$share = $total / count( $dania ); // orientacyjny podział wartości między dania
				foreach ( $dania as $nazwa ) {
					$rows[] = array_merge( array( 'date' => $d, 'time' => $t, 'name' => $nazwa, 'qty' => $qty, 'total' => $share, 'addon' => false, 'kind' => 'danie' ), $order_extra );
				}
			} else {
				$rows[] = array_merge( array(
					'date'  => $d,
					'time'  => $t,
					'name'  => $item->get_name(),
					'qty'   => $qty,
					'total' => $total,
					'addon' => (bool) $item->get_meta( 'Dodatek do' ),
					'kind'  => $item->get_meta( 'Dodatek do' ) ? 'dodatki' : 'danie',
				), $order_extra );
			}

			// Dodatki z modułu 10 (katalog Składników) – osobne wiersze, wartość 0
			// (ich cena jest już wliczona w cenę pozycji $total powyżej) – tu
			// liczy się wyłącznie ILOŚĆ, do zestawień "ile sztuk czego".
			if ( function_exists( 'rzd_item_addon_usage' ) ) {
				foreach ( rzd_item_addon_usage( $item ) as $u ) {
					$kind    = function_exists( 'rzd_usage_kind' ) ? rzd_usage_kind( $u ) : 'dodatki';
					$name    = ( 'bez' === $kind ) ? ( 'Bez: ' . $u['name'] ) : $u['name'];
					$rows[] = array_merge( array( 'date' => $d, 'time' => $t, 'name' => $name, 'qty' => (int) $u['qty'] * $qty, 'total' => 0.0, 'addon' => true, 'kind' => $kind ), $order_extra );
				}
			}
		}

		// Opakowania (moduł 21): ilość i wartość z zamówienia.
		if ( function_exists( 'rzd_order_packaging' ) ) {
			foreach ( rzd_order_packaging( $order ) as $p ) {
				if ( ! empty( $p['count'] ) ) {
					$rows[] = array_merge( array( 'date' => $d, 'time' => $t, 'name' => $p['name'], 'qty' => (int) $p['count'], 'total' => (float) $p['price'] * (int) $p['count'], 'addon' => true, 'kind' => 'opakowanie' ), $order_extra );
				}
			}
		}
	}
	return $rows;
}

// Raport szczegółowy: BEZ sumowania – jeden wiersz na pozycję zamówienia,
// żeby dało się przypisać do konkretnego zamówienia/klienta/adresu.
function rr_group_by_slot( $rows ) {
	usort( $rows, function ( $a, $b ) {
		return array( $a['date'], $a['time'], $a['name'] ) <=> array( $b['date'], $b['time'], $b['name'] );
	} );
	return $rows;
}

// Rodzaj pozycji w raporcie (od 2.24.0: danie / wybór w zestawie / dodatek płatny / obowiązkowe / bez).
function rr_kind_label( $r ) {
	$kind = isset( $r['kind'] ) ? $r['kind'] : ( $r['addon'] ? 'dodatki' : 'danie' );
	return function_exists( 'rzd_kind_label' ) ? rzd_kind_label( $kind ) : ( $r['addon'] ? 'Dodatek' : 'Danie/produkt' );
}

function rr_group_summary( $rows ) {
	$out = array();
	foreach ( $rows as $r ) {
		$kind = isset( $r['kind'] ) ? $r['kind'] : ( $r['addon'] ? 'dodatki' : 'danie' );
		$key  = $kind . '|' . $r['name']; // frytki "w zestawie" i "dodatek płatny" osobno
		if ( ! isset( $out[ $key ] ) ) {
			$out[ $key ] = array( 'name' => $r['name'], 'qty' => 0, 'total' => 0, 'addon' => $r['addon'], 'kind' => $kind );
		}
		$out[ $key ]['qty']   += $r['qty'];
		$out[ $key ]['total'] += $r['total'];
	}
	usort( $out, function ( $a, $b ) {
		return $b['qty'] <=> $a['qty']; // od najczęściej zamawianych
	} );
	return $out;
}

/* ============================================================
 * 3. EKSPORT CSV
 * ============================================================ */
function rr_csv_cell( $v ) {
	return str_replace( array( "\r", "\n" ), ' ', (string) $v );
}

function rr_output_csv( $filename, $header, $rows ) {
	nocache_headers();
	header( 'Content-Type: text/csv; charset=UTF-8' );
	header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
	$out = fopen( 'php://output', 'w' );
	fwrite( $out, "\xEF\xBB\xBF" ); // BOM – polskie znaki poprawnie w Excelu
	fputcsv( $out, $header, ';' );
	foreach ( $rows as $row ) {
		fputcsv( $out, array_map( 'rr_csv_cell', $row ), ';' );
	}
	fclose( $out );
	exit;
}

add_action( 'admin_post_rr_export', function () {
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		wp_die( 'Brak uprawnień.' );
	}
	check_admin_referer( 'rr_export' );

	$date_from = isset( $_POST['date_from'] ) ? sanitize_text_field( wp_unslash( $_POST['date_from'] ) ) : '';
	$date_to   = isset( $_POST['date_to'] ) ? sanitize_text_field( wp_unslash( $_POST['date_to'] ) ) : '';
	$time_from = isset( $_POST['time_from'] ) ? sanitize_text_field( wp_unslash( $_POST['time_from'] ) ) : '';
	$time_to   = isset( $_POST['time_to'] ) ? sanitize_text_field( wp_unslash( $_POST['time_to'] ) ) : '';
	$confirmed = ! empty( $_POST['only_confirmed'] );
	$mode      = ( isset( $_POST['mode'] ) && 'summary' === $_POST['mode'] ) ? 'summary' : 'detail';

	if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date_from ) || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date_to ) ) {
		wp_die( 'Wybierz poprawny zakres dat.' );
	}
	if ( $date_from > $date_to ) {
		list( $date_from, $date_to ) = array( $date_to, $date_from );
	}

	$rows = rr_collect_rows( $date_from, $date_to, $time_from, $time_to, $confirmed, 'detail' === $mode );

	if ( 'summary' === $mode ) {
		$data = rr_group_summary( $rows );
		$out  = array();
		foreach ( $data as $r ) {
			$out[] = array( $r['name'], rr_kind_label( $r ), $r['qty'], number_format( $r['total'], 2, ',', '' ) );
		}
		rr_output_csv(
			'podsumowanie-produktow_' . $date_from . '_' . $date_to . '.csv',
			array( 'Produkt', 'Rodzaj', 'Ilość łącznie', 'Wartość łącznie' ),
			$out
		);
	} else {
		$data = rr_group_by_slot( $rows );
		$out  = array();
		foreach ( $data as $r ) {
			$out[] = array( $r['date'], $r['time'] ?: '—', $r['name'], rr_kind_label( $r ), $r['qty'], number_format( $r['total'], 2, ',', '' ), $r['order_id'] ?? '', $r['customer'] ?? '', $r['phone'] ?? '', $r['address'] ?? '', $r['payment'] ?? '' );
		}
		rr_output_csv(
			'zamowienia-wg-terminu_' . $date_from . '_' . $date_to . '.csv',
			array( 'Data dostawy', 'Godzina', 'Produkt', 'Rodzaj', 'Ilość', 'Wartość', 'Nr zamówienia', 'Klient', 'Telefon', 'Adres', 'Płatność' ),
			$out
		);
	}
} );

/* ============================================================
 * 4. PANEL: formularz + podgląd na ekranie (bez pobierania)
 * ============================================================ */
function rr_render_admin_page() {
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		return;
	}
	$today = current_time( 'Y-m-d' );

	$preview   = isset( $_GET['preview'] ) && '1' === $_GET['preview'];
	$date_from = isset( $_GET['date_from'] ) ? sanitize_text_field( $_GET['date_from'] ) : $today;
	$date_to   = isset( $_GET['date_to'] ) ? sanitize_text_field( $_GET['date_to'] ) : $today;
	$time_from = isset( $_GET['time_from'] ) ? sanitize_text_field( $_GET['time_from'] ) : '';
	$time_to   = isset( $_GET['time_to'] ) ? sanitize_text_field( $_GET['time_to'] ) : '';
	$confirmed = ! isset( $_GET['only_confirmed'] ) || '1' === $_GET['only_confirmed'];
	$mode      = ( isset( $_GET['mode'] ) && 'summary' === $_GET['mode'] ) ? 'summary' : 'detail';
	?>
	<div class="wrap">
		<style>
			.rr-actions{display:flex;flex-wrap:wrap;gap:10px;margin-top:14px}
			.rr-actions .button{padding:10px 18px;min-height:44px;font-size:15px;line-height:1.4}
			@media (max-width:600px){.rr-actions{flex-direction:column}.rr-actions .button{width:100%;text-align:center}}
		</style>
		<h1>Raporty</h1>
		<h2>Zamówienia wg terminu dostawy</h2>
		<p class="description">Wybierz zakres. Godziny są opcjonalne – zostaw puste, żeby objąć cały dzień. „Podgląd” pokazuje wynik na ekranie, „Generuj CSV” pobiera plik.</p>

		<form method="get" style="background:#fff;border:1px solid #c3c4c7;padding:14px 16px;max-width:720px;margin-bottom:20px">
			<input type="hidden" name="page" value="rr-raporty">
			<input type="hidden" name="preview" value="1">
			<table class="form-table" role="presentation"><tbody>
				<tr>
					<th scope="row">Data dostawy</th>
					<td>
						od <input type="date" name="date_from" value="<?php echo esc_attr( $date_from ); ?>">
						do <input type="date" name="date_to" value="<?php echo esc_attr( $date_to ); ?>">
					</td>
				</tr>
				<tr>
					<th scope="row">Godzina dostawy</th>
					<td>
						od <input type="time" name="time_from" value="<?php echo esc_attr( $time_from ); ?>">
						do <input type="time" name="time_to" value="<?php echo esc_attr( $time_to ); ?>">
						<p class="description">Puste = bez ograniczenia godziny.</p>
					</td>
				</tr>
				<tr>
					<th scope="row">Rodzaj raportu</th>
					<td>
						<label><input type="radio" name="mode" value="detail" <?php checked( $mode, 'detail' ); ?>> Szczegółowo wg terminu (data, godzina, produkt)</label><br>
						<label><input type="radio" name="mode" value="summary" <?php checked( $mode, 'summary' ); ?>> Podsumowanie produktów (suma z całego zakresu)</label>
					</td>
				</tr>
				<tr>
					<th scope="row">Zamówienia</th>
					<td><label><input type="checkbox" name="only_confirmed" value="1" <?php checked( $confirmed ); ?>> Tylko przyjęte do realizacji lub zrealizowane (pomiń anulowane, nieopłacone, zwroty)</label></td>
				</tr>
			</tbody></table>
			<div class="rr-actions">
				<button type="submit" class="button">Podgląd na ekranie</button>
				<button type="submit" formaction="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" formmethod="post" name="rr_go" value="1" onclick="return rrSubmitExport(this)" class="button button-primary">Generuj CSV</button>
			</div>
		</form>

		<script>
		function rrSubmitExport(btn) {
			var form = btn.closest('form');
			var hidden = document.createElement('input');
			hidden.type = 'hidden'; hidden.name = 'action'; hidden.value = 'rr_export';
			form.appendChild(hidden);
			var nonce = document.createElement('input');
			nonce.type = 'hidden'; nonce.name = '_wpnonce'; nonce.value = '<?php echo esc_js( wp_create_nonce( 'rr_export' ) ); ?>';
			form.appendChild(nonce);
			return true;
		}
		</script>

		<?php if ( $preview ) : ?>
			<?php
			$rows = rr_collect_rows( $date_from, $date_to, $time_from, $time_to, $confirmed, 'detail' === $mode );
			$data = ( 'summary' === $mode ) ? rr_group_summary( $rows ) : rr_group_by_slot( $rows );
			?>
			<h2>Podgląd (<?php echo (int) count( $data ); ?> <?php echo ( 'summary' === $mode ) ? 'produktów' : 'pozycji'; ?>)</h2>
			<?php if ( ! $data ) : ?>
				<p>Brak zamówień w wybranym zakresie.</p>
			<?php else : ?>
				<table class="widefat striped" style="max-width:820px">
					<thead><tr>
						<?php if ( 'summary' === $mode ) : ?>
							<th>Produkt</th><th>Rodzaj</th><th>Ilość</th><th>Wartość</th>
						<?php else : ?>
							<th>Data</th><th>Godzina</th><th>Produkt</th><th>Rodzaj</th><th>Ilość</th><th>Wartość</th><th>Nr zam.</th><th>Klient</th><th>Adres</th>
						<?php endif; ?>
					</tr></thead>
					<tbody>
					<?php foreach ( $data as $r ) : ?>
						<tr>
							<?php if ( 'summary' === $mode ) : ?>
								<td><?php echo esc_html( $r['name'] ); ?></td>
								<td><?php echo rr_kind_label( $r ); ?></td>
								<td><?php echo (int) $r['qty']; ?></td>
								<td><?php echo wp_kses_post( wc_price( $r['total'] ) ); ?></td>
							<?php else : ?>
								<td><?php echo esc_html( dc_date_label( $r['date'] ) ); ?></td>
								<td><?php echo esc_html( $r['time'] ?: '—' ); ?></td>
								<td><?php echo esc_html( $r['name'] ); ?></td>
								<td><?php echo rr_kind_label( $r ); ?></td>
								<td><?php echo (int) $r['qty']; ?></td>
								<td><?php echo wp_kses_post( wc_price( $r['total'] ) ); ?></td>
								<td><?php echo esc_html( $r['order_id'] ?? '' ); ?></td>
								<td><?php echo esc_html( $r['customer'] ?? '' ); ?></td>
								<td><?php echo esc_html( $r['address'] ?? '' ); ?></td>
							<?php endif; ?>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>
		<?php endif; ?>
	</div>
	<?php
}
