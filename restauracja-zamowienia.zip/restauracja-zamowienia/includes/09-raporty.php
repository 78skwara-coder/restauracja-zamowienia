<?php
/**
 * MODUŁ 09: Raporty
 *
 * Ekran: Panel restauracji → Raporty (moduł 34; do 2.43.x Restauracja → Raporty w kokpicie).
 * Raport "Zamówienia wg terminu dostawy" – zakres dat (i opcjonalnie godzin) dostawy,
 * „Podgląd” na ekranie albo „Pobierz CSV” (admin-post rr_export).
 *
 * Dwa warianty raportu:
 * - Szczegółowo wg terminu – wiersz na każdą pozycję w każdym terminie
 *   (data, godzina, produkt/danie, ilość, wartość).
 * - Podsumowanie produktów – jeden wiersz na produkt/danie z sumą ilości
 *   i wartości z całego wybranego zakresu (to, czego potrzebuje kuchnia
 *   do zbiorczego przygotowania).
 *
 * Wymaga modułu 06 (Terminy) – stamtąd bierze termin dostawy
 * zapisany przy zamówieniu. Rozpoznaje też dania z zestawów i dodatki
 * (moduł 04) – liczy je z osobna, po nazwie konkretnego dania/dodatku,
 * a nie po nazwie samego "Zestawu dnia".
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 2. POBRANIE DANYCH: pozycje zamówień w zadanym zakresie
 * ============================================================ */
// Zwraca listę wierszy: [ 'date','time','name','qty','total', czy_dodatek ]
// $with_order = true -> dołącz nr zamówienia / klienta / adres (raport szczegółowy)
function rzd_raport_collect_rows( $date_from, $date_to, $time_from, $time_to, $only_confirmed, $with_order = false ) {
	$rows   = array();
	$meta_q = array(
		array( 'key' => '_dc_delivery_date', 'value' => array( $date_from, $date_to ), 'compare' => 'BETWEEN', 'type' => 'DATE' ),
	);

	$args = array(
		'limit'      => -1,
		'meta_query' => $meta_q, // phpcs:ignore
		'orderby'    => 'date',
		'order'      => 'ASC',
		'return'     => 'objects',
	);
	if ( $only_confirmed ) {
		$args['status'] = rzd_order_statuses_active();
	}

	$orders = wc_get_orders( $args );

	foreach ( $orders as $order ) {
		$d = $order->get_meta( '_dc_delivery_date' );
		$t = $order->get_meta( '_dc_delivery_time' );
		if ( ! $d ) {
			continue;
		}
		if ( $time_from && $t && $t < $time_from ) {
			continue;
		}
		if ( $time_to && $t && $t > $time_to ) {
			continue;
		}

		$order_extra = array();
		if ( $with_order ) {
			$addr = trim( implode( ', ', array_filter( array(
				$order->get_shipping_address_1() ?: $order->get_billing_address_1(),
				$order->get_shipping_city() ?: $order->get_billing_city(),
				$order->get_shipping_postcode() ?: $order->get_billing_postcode(),
			) ) ) );
			$order_extra = array(
				'order_id' => $order->get_order_number(),
				'customer' => trim( $order->get_formatted_billing_full_name() ),
				'phone'    => $order->get_billing_phone(),
				'payment'  => function_exists( 'rzd_kuchnia_payment_text' ) ? rzd_kuchnia_payment_text( $order ) : $order->get_payment_method_title(),
				'address'  => $addr,
			);
		}

		foreach ( $order->get_items() as $item ) {
			$qty = (int) $item->get_quantity();
			if ( $qty <= 0 ) {
				continue;
			}
			$total  = (float) $item->get_total();
			$w_zest = $item->get_meta( 'W zestawie' );
			$dania  = $w_zest ? array_filter( array_map( 'trim', explode( ',', $w_zest ) ) ) : array();

			if ( $dania ) {
				// zestaw: liczymy KAŻDE danie z osobna pod jego własną nazwą
				$share = $total / count( $dania ); // orientacyjny podział wartości między dania
				foreach ( $dania as $nazwa ) {
					$rows[] = array_merge( array( 'date' => $d, 'time' => $t, 'name' => $nazwa, 'qty' => $qty, 'total' => $share, 'addon' => false, 'kind' => 'danie' ), $order_extra );
				}
			} else {
				$rows[] = array_merge( array(
					'date'  => $d,
					'time'  => $t,
					'name'  => $item->get_name(),
					'qty'   => $qty,
					'total' => $total,
					'addon' => (bool) $item->get_meta( 'Dodatek do' ),
					'kind'  => $item->get_meta( 'Dodatek do' ) ? 'dodatki' : 'danie',
				), $order_extra );
			}

			// Dodatki z modułu 10 (katalog Składników) – osobne wiersze, wartość 0
			// (ich cena jest już wliczona w cenę pozycji $total powyżej) – tu
			// liczy się wyłącznie ILOŚĆ, do zestawień "ile sztuk czego".
			if ( function_exists( 'rzd_item_addon_usage' ) ) {
				foreach ( rzd_item_addon_usage( $item ) as $u ) {
					$kind    = function_exists( 'rzd_usage_kind' ) ? rzd_usage_kind( $u ) : 'dodatki';
					$name    = ( 'bez' === $kind ) ? ( 'Bez: ' . $u['name'] ) : $u['name'];
					$rows[] = array_merge( array( 'date' => $d, 'time' => $t, 'name' => $name, 'qty' => (int) $u['qty'] * $qty, 'total' => 0.0, 'addon' => true, 'kind' => $kind ), $order_extra );
				}
			}
		}

		// Opakowania (moduł 21): ilość i wartość z zamówienia.
		if ( function_exists( 'rzd_order_packaging' ) ) {
			foreach ( rzd_order_packaging( $order ) as $p ) {
				if ( ! empty( $p['count'] ) ) {
					$rows[] = array_merge( array( 'date' => $d, 'time' => $t, 'name' => $p['name'], 'qty' => (int) $p['count'], 'total' => (float) $p['price'] * (int) $p['count'], 'addon' => true, 'kind' => 'opakowanie' ), $order_extra );
				}
			}
		}
	}
	return $rows;
}

// Raport szczegółowy: BEZ sumowania – jeden wiersz na pozycję zamówienia,
// żeby dało się przypisać do konkretnego zamówienia/klienta/adresu.
function rzd_raport_group_by_slot( $rows ) {
	usort( $rows, function ( $a, $b ) {
		return array( $a['date'], $a['time'], $a['name'] ) <=> array( $b['date'], $b['time'], $b['name'] );
	} );
	return $rows;
}

// Rodzaj pozycji w raporcie (danie / wybór w zestawie / dodatek płatny / obowiązkowe / bez).
function rzd_raport_kind_label( $r ) {
	$kind = isset( $r['kind'] ) ? $r['kind'] : ( $r['addon'] ? 'dodatki' : 'danie' );
	return function_exists( 'rzd_kind_label' ) ? rzd_kind_label( $kind ) : ( $r['addon'] ? 'Dodatek' : 'Danie/produkt' );
}

function rzd_raport_group_summary( $rows ) {
	$out = array();
	foreach ( $rows as $r ) {
		$kind = isset( $r['kind'] ) ? $r['kind'] : ( $r['addon'] ? 'dodatki' : 'danie' );
		$key  = $kind . '|' . $r['name']; // frytki "w zestawie" i "dodatek płatny" osobno
		if ( ! isset( $out[ $key ] ) ) {
			$out[ $key ] = array( 'name' => $r['name'], 'qty' => 0, 'total' => 0, 'addon' => $r['addon'], 'kind' => $kind );
		}
		$out[ $key ]['qty']   += $r['qty'];
		$out[ $key ]['total'] += $r['total'];
	}
	usort( $out, function ( $a, $b ) {
		return $b['qty'] <=> $a['qty']; // od najczęściej zamawianych
	} );
	return $out;
}

/* ============================================================
 * 3. EKSPORT CSV
 * ============================================================ */
function rzd_raport_csv_cell( $v ) {
	$v = str_replace( array( "\r", "\n" ), ' ', (string) $v );
	// Ochrona przed wstrzyknięciem formuły (CSV injection): tekst od = + - @ (albo tabulatora) Excel
	// liczy jako formułę – np. uwagi klienta „=HYPERLINK(…)”. Apostrof = „to jest tekst”. Liczby bez zmian.
	if ( '' !== $v && ! is_numeric( str_replace( ',', '.', $v ) ) && in_array( $v[0], array( '=', '+', '-', '@', "\t" ), true ) ) {
		$v = "'" . $v;
	}
	return $v;
}

function rzd_raport_output_csv( $filename, $header, $rows ) {
	nocache_headers();
	header( 'Content-Type: text/csv; charset=UTF-8' );
	header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
	$out = fopen( 'php://output', 'w' );
	fwrite( $out, "\xEF\xBB\xBF" ); // BOM – polskie znaki poprawnie w Excelu
	fputcsv( $out, $header, ';' );
	foreach ( $rows as $row ) {
		fputcsv( $out, array_map( 'rzd_raport_csv_cell', $row ), ';' );
	}
	fclose( $out );
	exit;
}

/**
 * Dane raportu (wspólne dla podglądu w Panelu restauracji i pliku CSV).
 * $q: date_from, date_to (RRRR-MM-DD), time_from, time_to (GG:MM, puste = cały dzień),
 * only_confirmed (bool), mode ('detail'|'summary'). Zwraca WP_Error albo
 * [ 'file', 'head', 'rows' (do CSV), 'preview' (do ekranu – liczby i daty czytelne) ].
 */
function rzd_raport_data( $q ) {
	$date_from = isset( $q['date_from'] ) ? sanitize_text_field( (string) $q['date_from'] ) : '';
	$date_to   = isset( $q['date_to'] ) ? sanitize_text_field( (string) $q['date_to'] ) : '';
	$time_from = isset( $q['time_from'] ) ? rzd_clean_time( (string) $q['time_from'] ) : '';
	$time_to   = isset( $q['time_to'] ) ? rzd_clean_time( (string) $q['time_to'] ) : '';
	$confirmed = ! empty( $q['only_confirmed'] );
	$mode      = ( isset( $q['mode'] ) && 'summary' === $q['mode'] ) ? 'summary' : 'detail';
	if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date_from ) || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date_to ) ) {
		return new WP_Error( 'dates', 'Wybierz poprawny zakres dat.' );
	}
	if ( $date_from > $date_to ) {
		list( $date_from, $date_to ) = array( $date_to, $date_from );
	}
	$rows = rzd_raport_collect_rows( $date_from, $date_to, $time_from, $time_to, $confirmed, 'detail' === $mode );
	$out  = array();
	$view = array();
	if ( 'summary' === $mode ) {
		foreach ( rzd_raport_group_summary( $rows ) as $r ) {
			$out[]  = array( $r['name'], rzd_raport_kind_label( $r ), $r['qty'], number_format( $r['total'], 2, ',', '' ) );
			$view[] = array( $r['name'], rzd_raport_kind_label( $r ), (int) $r['qty'], rzd_price_txt( $r['total'] ) );
		}
		return array(
			'file'    => 'podsumowanie-produktow_' . $date_from . '_' . $date_to . '.csv',
			'head'    => array( 'Produkt', 'Rodzaj', 'Ilość łącznie', 'Wartość łącznie' ),
			'rows'    => $out,
			'vhead'   => array( 'Produkt', 'Rodzaj', 'Ilość', 'Wartość' ),
			'preview' => $view,
		);
	}
	foreach ( rzd_raport_group_by_slot( $rows ) as $r ) {
		$out[]  = array( $r['date'], $r['time'] ?: '—', $r['name'], rzd_raport_kind_label( $r ), $r['qty'], number_format( $r['total'], 2, ',', '' ), $r['order_id'] ?? '', $r['customer'] ?? '', $r['phone'] ?? '', $r['address'] ?? '', $r['payment'] ?? '' );
		$view[] = array( function_exists( 'rzd_dc_date_label' ) ? rzd_dc_date_label( $r['date'] ) : $r['date'], $r['time'] ?: '—', $r['name'], rzd_raport_kind_label( $r ), (int) $r['qty'], rzd_price_txt( $r['total'] ), (string) ( $r['order_id'] ?? '' ), (string) ( $r['customer'] ?? '' ), (string) ( $r['address'] ?? '' ) );
	}
	return array(
		'file'    => 'zamowienia-wg-terminu_' . $date_from . '_' . $date_to . '.csv',
		'head'    => array( 'Data dostawy', 'Godzina', 'Produkt', 'Rodzaj', 'Ilość', 'Wartość', 'Nr zamówienia', 'Klient', 'Telefon', 'Adres', 'Płatność' ),
		'rows'    => $out,
		'vhead'   => array( 'Data', 'Godzina', 'Produkt', 'Rodzaj', 'Ilość', 'Wartość', 'Nr zam.', 'Klient', 'Adres' ),
		'preview' => $view,
	);
}

// Pobranie CSV (formularz z Panelu restauracji → Raporty; POST + nonce rr_export).
add_action( 'admin_post_rr_export', function () {
	if ( ! function_exists( 'rzd_can' ) || ! rzd_can( 'reports' ) ) {
		wp_die( 'Brak uprawnień.' );
	}
	check_admin_referer( 'rr_export' );
	$d = rzd_raport_data( wp_unslash( $_POST ) ); // phpcs:ignore -- czyszczone w rzd_raport_data
	if ( is_wp_error( $d ) ) {
		wp_die( esc_html( $d->get_error_message() ) );
	}
	rzd_raport_output_csv( $d['file'], $d['head'], $d['rows'] );
} );
