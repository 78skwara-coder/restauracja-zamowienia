<?php
/**
 * Moduł 24 – OPISY PRODUKTÓW: EDYTOR SEKCJI
 *
 * Opis krótki i długi produktu budowany z sekcji: nagłówek (nazwa + wielkość:
 * h2 duży / h3 średni / h4 mały / bez nagłówka) i treść z formatowaniem
 * (pogrubienie, kursywa, listy, linia pozioma, emotki). Edytor jest na stronie
 * [edycja_produktow] (moduł 22, assets/js/rzd-edycja.js).
 *
 * FORMAT ZAPISU (zwykły HTML w opisie produktu – jedyne źródło prawdy):
 *   <div class="rzd-opis">
 *   <section class="rzd-op-s [rzd-op-2k]">
 *     <h3 class="rzd-op-h">Nagłówek</h3>
 *     <div class="rzd-op-t"> p / ul / ol / li / hr / strong / em / br </div>
 *   </section>
 *   …
 *   </div>
 * rzd-op-2k = listy sekcji w dwóch kolumnach. Wygląd: assets/css/lista-zamowien.css.
 *
 * ODCZYT (rzd_desc_parse): nasz format, albo „zwykły” opis z samych dozwolonych
 * znaczników (akapity, listy, pogrubienia, nagłówki h2–h4 bez stylów – dzielone
 * na sekcje). Wszystko inne (style, div-y, obrazki, bloki) = NIECZYTELNY:
 * zostaje bez zmian; nadpisać można tylko świadomie („Utwórz nowy opis”).
 *
 * KOPIE (meta _rzd_desc_backup[ short|long ][ orig|prev ] = { html, date, user }):
 *  - orig – opis sprzed edytora (nieczytelny), zapisywany raz, bez limitu czasu,
 *           znika po przywróceniu albo „Usuń”,
 *  - prev – stan sprzed ostatniego zapisu / przywrócenia (jedna, nadpisywana).
 * Wykluczone z „Duplikuj produkt”.
 */

defined( 'ABSPATH' ) || exit;

/* ============================================================
 * 1. DOM – wczytanie fragmentu HTML
 * ============================================================ */

/** Fragment HTML → element-kontener (DOMElement) albo null. UTF-8 bez zamiany na encje. */
function rzd_desc_dom( $html ) {
	if ( ! class_exists( 'DOMDocument' ) ) {
		return null;
	}
	$doc  = new DOMDocument( '1.0', 'UTF-8' );
	$prev = libxml_use_internal_errors( true ); // section/article – „nieznane” dla parsera HTML4, ale działają
	$ok   = $doc->loadHTML( '<?xml encoding="UTF-8"><div id="rzd-desc-root">' . $html . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD | LIBXML_NONET );
	libxml_clear_errors();
	libxml_use_internal_errors( $prev );
	if ( ! $ok ) {
		return null;
	}
	foreach ( $doc->childNodes as $n ) {
		if ( XML_ELEMENT_NODE === $n->nodeType ) {
			return $n;
		}
	}
	return null;
}

function rzd_desc_inner( $node ) {
	$out = '';
	foreach ( $node->childNodes as $c ) {
		$out .= $node->ownerDocument->saveHTML( $c );
	}
	return $out;
}

function rzd_desc_classes( $el ) {
	$c = trim( (string) $el->getAttribute( 'class' ) );
	return '' === $c ? array() : preg_split( '/\s+/', $c );
}

/** Czy element ma wyłącznie dozwolone atrybuty (domyślnie: żadnych). */
function rzd_desc_attrs_ok( $el, $allowed = array() ) {
	if ( ! $el->hasAttributes() ) {
		return true;
	}
	foreach ( $el->attributes as $a ) {
		if ( ! in_array( strtolower( $a->name ), $allowed, true ) ) {
			return false;
		}
	}
	return true;
}

/* ============================================================
 * 2. SANITYZACJA TREŚCI SEKCJI
 *    Dozwolone: p, ul, ol, li, hr (bloki) + strong, em, br (w tekście).
 *    b → strong, i → em. Div/nagłówki/tabele → akapity, span/a/font → sam
 *    tekst, skrypty/style/obrazki/ramki → usunięte. Tekst luzem → <p>.
 * ============================================================ */

function rzd_desc_tag_sets() {
	return array(
		'drop'   => array( 'script', 'style', 'iframe', 'object', 'embed', 'svg', 'math', 'template', 'noscript', 'head', 'title', 'meta', 'link', 'img', 'picture', 'video', 'audio', 'source', 'canvas', 'input', 'button', 'select', 'textarea', 'form' ),
		'blocks' => array( 'p', 'div', 'section', 'article', 'header', 'footer', 'aside', 'main', 'nav', 'blockquote', 'pre', 'figure', 'figcaption', 'address', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'ul', 'ol', 'li', 'hr', 'table', 'thead', 'tbody', 'tfoot', 'tr', 'td', 'th', 'dl', 'dt', 'dd' ),
	);
}

function rzd_desc_has_block( $el ) {
	$sets = rzd_desc_tag_sets();
	foreach ( $el->childNodes as $c ) {
		if ( XML_ELEMENT_NODE === $c->nodeType ) {
			$t = strtolower( $c->nodeName );
			if ( in_array( $t, $sets['blocks'], true ) || rzd_desc_has_block( $c ) ) {
				return true;
			}
		}
	}
	return false;
}

function rzd_desc_text( $s ) {
	$s = str_replace( array( "\r\n", "\r", "\n", "\t" ), ' ', (string) $s );
	return htmlspecialchars( $s, ENT_NOQUOTES, 'UTF-8' );
}

/** Treść w linii (wewnątrz p / li / strong / em). Bloki spłaszczane do <br>. */
function rzd_desc_emit_inline( $node ) {
	$sets = rzd_desc_tag_sets();
	$out  = '';
	foreach ( $node->childNodes as $c ) {
		if ( XML_TEXT_NODE === $c->nodeType || XML_CDATA_SECTION_NODE === $c->nodeType ) {
			$out .= rzd_desc_text( $c->nodeValue );
			continue;
		}
		if ( XML_ELEMENT_NODE !== $c->nodeType ) {
			continue; // komentarze itp.
		}
		$t = strtolower( $c->nodeName );
		if ( in_array( $t, $sets['drop'], true ) ) {
			continue;
		}
		if ( 'b' === $t || 'strong' === $t || 'em' === $t || 'i' === $t ) {
			$in  = rzd_desc_emit_inline( $c );
			$tag = ( 'b' === $t || 'strong' === $t ) ? 'strong' : 'em';
			if ( '' !== trim( str_replace( '<br>', '', $in ) ) ) {
				$out .= '<' . $tag . '>' . $in . '</' . $tag . '>';
			}
		} elseif ( 'br' === $t || 'hr' === $t ) {
			$out .= '<br>';
		} elseif ( 'li' === $t ) {
			$out .= rzd_desc_emit_inline( $c ) . '<br>';
		} elseif ( in_array( $t, $sets['blocks'], true ) ) {
			$in = rzd_desc_emit_inline( $c );
			if ( '' !== trim( $in ) ) {
				$out .= $in . '<br>';
			}
		} else {
			$out .= rzd_desc_emit_inline( $c ); // span, a, font, u…
		}
	}
	return $out;
}

/** Usuwa <br> i spacje z początku i końca fragmentu. */
function rzd_desc_trim_br( $s ) {
	return preg_replace( '#^(\s|&nbsp;|<br>)+|(\s|&nbsp;|<br>)+$#u', '', $s );
}

/**
 * Tekst w linii → akapity. Podwójne <br> = nowy akapit (tak samo robi wpautop
 * przy wyświetlaniu – lepiej zapisać to od razu poprawnie). Puste akapity znikają.
 */
function rzd_desc_paras( $in ) {
	$out = '';
	foreach ( preg_split( '#(?:<br>\s*){2,}#', (string) $in ) as $part ) {
		$part = rzd_desc_trim_br( $part );
		if ( '' !== trim( str_replace( '&nbsp;', '', strip_tags( $part ) ) ) ) {
			$out .= '<p>' . $part . '</p>';
		}
	}
	return $out;
}

/** Elementy listy: <li>…</li>; zagnieżdżone listy zostają; inne dzieci → osobny <li>. */
function rzd_desc_emit_list( $el ) {
	$out = '';
	foreach ( $el->childNodes as $c ) {
		if ( XML_TEXT_NODE === $c->nodeType ) {
			if ( '' !== trim( $c->nodeValue ) ) {
				$out .= '<li>' . rzd_desc_text( trim( $c->nodeValue ) ) . '</li>';
			}
			continue;
		}
		if ( XML_ELEMENT_NODE !== $c->nodeType ) {
			continue;
		}
		$t = strtolower( $c->nodeName );
		if ( 'ul' === $t || 'ol' === $t ) { // lista w liście bez <li> (tak robi część przeglądarek)
			$in   = rzd_desc_emit_list( $c );
			$out .= '' !== $in ? '<li><' . $t . '>' . $in . '</' . $t . '></li>' : '';
			continue;
		}
		$in = 'li' === $t ? rzd_desc_emit_li( $c ) : rzd_desc_trim_br( rzd_desc_emit_inline( $c ) );
		if ( '' !== trim( strip_tags( $in, '<ul><ol><li>' ) ) ) {
			$out .= '<li>' . $in . '</li>';
		}
	}
	return $out;
}

/** Zawartość <li>: tekst w linii + ewentualne listy zagnieżdżone. */
function rzd_desc_emit_li( $li ) {
	$out = '';
	$buf = '';
	foreach ( $li->childNodes as $c ) {
		$t = XML_ELEMENT_NODE === $c->nodeType ? strtolower( $c->nodeName ) : '';
		if ( 'ul' === $t || 'ol' === $t ) {
			$out .= rzd_desc_trim_br( $buf );
			$buf  = '';
			$in   = rzd_desc_emit_list( $c );
			$out .= '' !== $in ? '<' . $t . '>' . $in . '</' . $t . '>' : '';
			continue;
		}
		$tmp = $c->ownerDocument->createElement( 'span' );
		$tmp->appendChild( $c->cloneNode( true ) );
		$buf .= rzd_desc_emit_inline( $tmp );
	}
	return $out . rzd_desc_trim_br( $buf );
}

/** Poziom bloków (treść sekcji). */
function rzd_desc_emit_block( $node ) {
	$sets = rzd_desc_tag_sets();
	$out  = '';
	$buf  = '';
	$flush = function () use ( &$out, &$buf ) {
		$out .= rzd_desc_paras( $buf );
		$buf  = '';
	};
	foreach ( $node->childNodes as $c ) {
		if ( XML_TEXT_NODE === $c->nodeType || XML_CDATA_SECTION_NODE === $c->nodeType ) {
			$buf .= rzd_desc_text( $c->nodeValue );
			continue;
		}
		if ( XML_ELEMENT_NODE !== $c->nodeType ) {
			continue;
		}
		$t = strtolower( $c->nodeName );
		if ( in_array( $t, $sets['drop'], true ) ) {
			continue;
		}
		if ( 'ul' === $t || 'ol' === $t ) {
			$flush();
			$in   = rzd_desc_emit_list( $c );
			$out .= '' !== $in ? '<' . $t . '>' . $in . '</' . $t . '>' : '';
		} elseif ( 'li' === $t ) {
			$flush();
			$in   = rzd_desc_emit_li( $c );
			$out .= '' !== trim( $in ) ? '<ul><li>' . $in . '</li></ul>' : '';
		} elseif ( 'hr' === $t ) {
			$flush();
			$out .= '<hr>';
		} elseif ( 'br' === $t ) {
			$buf .= '<br>';
		} elseif ( in_array( $t, $sets['blocks'], true ) ) {
			$flush();
			if ( rzd_desc_has_block( $c ) ) {
				$out .= rzd_desc_emit_block( $c ); // np. <p>tekst<hr>tekst</p> z edytora przeglądarki
			} else {
				$in = rzd_desc_trim_br( rzd_desc_emit_inline( $c ) );
				if ( preg_match( '/^h[1-6]$/', $t ) ) {
					$out .= '' !== trim( strip_tags( $in ) ) ? '<p><strong>' . $in . '</strong></p>' : '';
				} else {
					$out .= rzd_desc_paras( $in );
				}
			}
		} else {
			$tmp = $c->ownerDocument->createElement( 'span' );
			$tmp->appendChild( $c->cloneNode( true ) );
			$buf .= rzd_desc_emit_inline( $tmp );
		}
	}
	$flush();
	return $out;
}

/** Treść sekcji z dowolnego HTML (wklejka, edytor przeglądarki) → czysty HTML z białej listy. */
function rzd_desc_clean( $html ) {
	$html = trim( (string) $html );
	if ( '' === $html ) {
		return '';
	}
	$root = rzd_desc_dom( $html );
	if ( ! $root ) {
		return '';
	}
	$out = rzd_desc_emit_block( $root );
	// Bezpiecznik: i tak tylko biała lista bez atrybutów.
	return wp_kses( $out, array( 'p' => array(), 'br' => array(), 'strong' => array(), 'em' => array(), 'ul' => array(), 'ol' => array(), 'li' => array(), 'hr' => array() ) );
}

/* ============================================================
 * 3. ODCZYT OPISU → SEKCJE
 * ============================================================ */

/** Czy poddrzewo zawiera tylko znaczniki edytora (bez atrybutów; $loose – akapity mogą mieć atrybuty, np. stare style). */
function rzd_desc_strict( $node, $loose = false ) {
	$ok = array( 'p', 'br', 'strong', 'b', 'em', 'i', 'ul', 'ol', 'li', 'hr' );
	foreach ( $node->childNodes as $c ) {
		if ( XML_TEXT_NODE === $c->nodeType ) {
			continue;
		}
		if ( XML_ELEMENT_NODE !== $c->nodeType ) {
			return false; // komentarz (np. bloki edytora) – nie ruszamy
		}
		$t = strtolower( $c->nodeName );
		if ( ! in_array( $t, $ok, true ) ) {
			return false;
		}
		if ( ! rzd_desc_attrs_ok( $c ) && ! ( $loose && ( 'p' === $t || 'br' === $t ) && rzd_desc_attrs_ok( $c, array( 'style', 'class', 'dir' ) ) ) ) {
			return false;
		}
		if ( ! rzd_desc_strict( $c, $loose ) ) {
			return false;
		}
	}
	return true;
}

function rzd_desc_section( $t, $lv, $cols, $html ) {
	return array( 't' => (string) $t, 'lv' => (int) $lv, 'cols' => $cols ? 1 : 0, 'html' => (string) $html );
}

/**
 * HTML opisu → [ 'ok' => bool, 'sections' => [ {t, lv, cols, html} ] ].
 * ok = false: opisu nie da się bezpiecznie przenieść do edytora.
 */
function rzd_desc_parse( $html ) {
	$html = trim( (string) $html );
	if ( '' === $html ) {
		return array( 'ok' => true, 'sections' => array() );
	}
	$fail = array( 'ok' => false, 'sections' => array() );
	$root = rzd_desc_dom( $html );
	if ( ! $root ) {
		return $fail;
	}
	$els = array();
	foreach ( $root->childNodes as $c ) {
		if ( XML_ELEMENT_NODE === $c->nodeType ) {
			$els[] = $c;
		} elseif ( XML_TEXT_NODE !== $c->nodeType || '' !== trim( $c->nodeValue ) ) {
			$els = null;
			break;
		}
	}

	// a) Nasz format
	if ( $els && 1 === count( $els ) && 'div' === strtolower( $els[0]->nodeName ) && in_array( 'rzd-opis', rzd_desc_classes( $els[0] ), true ) ) {
		$sections = array();
		foreach ( $els[0]->childNodes as $s ) {
			if ( XML_TEXT_NODE === $s->nodeType && '' === trim( $s->nodeValue ) ) {
				continue;
			}
			if ( XML_ELEMENT_NODE !== $s->nodeType || 'section' !== strtolower( $s->nodeName ) || ! rzd_desc_attrs_ok( $s, array( 'class' ) ) ) {
				return $fail;
			}
			$cls = rzd_desc_classes( $s );
			if ( array_diff( $cls, array( 'rzd-op-s', 'rzd-op-2k' ) ) ) {
				return $fail;
			}
			$t    = '';
			$lv   = 0;
			$body = null;
			foreach ( $s->childNodes as $k ) {
				if ( XML_TEXT_NODE === $k->nodeType && '' === trim( $k->nodeValue ) ) {
					continue;
				}
				if ( XML_ELEMENT_NODE !== $k->nodeType ) {
					return $fail;
				}
				$kt = strtolower( $k->nodeName );
				if ( null === $body && ! $lv && in_array( $kt, array( 'h2', 'h3', 'h4' ), true ) && rzd_desc_attrs_ok( $k, array( 'class' ) ) && 0 === $k->getElementsByTagName( '*' )->length ) {
					$t  = trim( $k->textContent );
					$lv = (int) substr( $kt, 1 );
				} elseif ( null === $body && 'div' === $kt && array( 'rzd-op-t' ) === rzd_desc_classes( $k ) && rzd_desc_attrs_ok( $k, array( 'class' ) ) && rzd_desc_strict( $k ) ) {
					$body = rzd_desc_clean( rzd_desc_inner( $k ) );
				} else {
					return $fail;
				}
			}
			$sections[] = rzd_desc_section( $t, $lv, in_array( 'rzd-op-2k', $cls, true ), null === $body ? '' : $body );
		}
		return array( 'ok' => true, 'sections' => $sections );
	}

	// b) Zwykły opis: tekst / akapity / listy / pogrubienia, nagłówki h2–h4 bez stylów → osobne sekcje
	$auto = function_exists( 'wpautop' ) ? wpautop( $html ) : $html;
	$root = rzd_desc_dom( $auto );
	if ( ! $root ) {
		return $fail;
	}
	$sections = array();
	$cur      = array( 't' => '', 'lv' => 0, 'html' => '' );
	foreach ( $root->childNodes as $c ) {
		if ( XML_TEXT_NODE === $c->nodeType ) {
			$cur['html'] .= rzd_desc_text( $c->nodeValue );
			continue;
		}
		if ( XML_ELEMENT_NODE !== $c->nodeType ) {
			return $fail;
		}
		$t = strtolower( $c->nodeName );
		if ( in_array( $t, array( 'h2', 'h3', 'h4' ), true ) && rzd_desc_attrs_ok( $c ) && 0 === $c->getElementsByTagName( '*' )->length ) {
			if ( '' !== $cur['t'] || '' !== trim( $cur['html'] ) ) {
				$sections[] = rzd_desc_section( $cur['t'], $cur['lv'], 0, rzd_desc_clean( $cur['html'] ) );
			}
			$cur = array( 't' => trim( $c->textContent ), 'lv' => (int) substr( $t, 1 ), 'html' => '' );
			continue;
		}
		$wrap = $c->ownerDocument->createElement( 'div' );
		$wrap->appendChild( $c->cloneNode( true ) );
		if ( ! rzd_desc_strict( $wrap, true ) ) {
			return $fail;
		}
		$cur['html'] .= $c->ownerDocument->saveHTML( $c );
	}
	if ( '' !== $cur['t'] || '' !== trim( $cur['html'] ) ) {
		$sections[] = rzd_desc_section( $cur['t'], $cur['lv'], 0, rzd_desc_clean( $cur['html'] ) );
	}
	return array( 'ok' => true, 'sections' => $sections );
}

/* ============================================================
 * 4. ZAPIS: SEKCJE → HTML
 * ============================================================ */

/** $kind: 'short' | 'long'. Krótki opis bez dużego nagłówka (h2 → h3). */
function rzd_desc_build( $sections, $kind ) {
	$out = '';
	$n   = 0;
	foreach ( (array) $sections as $s ) {
		if ( ! is_array( $s ) || ++$n > 40 ) {
			continue;
		}
		$t  = isset( $s['t'] ) ? trim( wp_strip_all_tags( (string) $s['t'] ) ) : '';
		$t  = function_exists( 'mb_substr' ) ? mb_substr( $t, 0, 200 ) : substr( $t, 0, 200 );
		$lv = isset( $s['lv'] ) ? (int) $s['lv'] : 3;
		$lv = in_array( $lv, array( 2, 3, 4 ), true ) ? $lv : 0;
		if ( 'short' === $kind && 2 === $lv ) {
			$lv = 3;
		}
		if ( '' === $t ) {
			$lv = 0;
		}
		$body = rzd_desc_clean( isset( $s['html'] ) ? (string) $s['html'] : '' );
		if ( ! $lv && '' === $body ) {
			continue;
		}
		$out .= '<section class="rzd-op-s' . ( ! empty( $s['cols'] ) ? ' rzd-op-2k' : '' ) . '">'
			. ( $lv ? '<h' . $lv . ' class="rzd-op-h">' . esc_html( $t ) . '</h' . $lv . '>' : '' )
			. '<div class="rzd-op-t">' . $body . '</div></section>' . "\n";
	}
	return '' === $out ? '' : '<div class="rzd-opis">' . "\n" . $out . '</div>';
}

/** Dane opisu dla edytora (moduł 22). */
function rzd_desc_doc( $html ) {
	$html = (string) $html;
	$r    = rzd_desc_parse( $html );
	$txt  = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( str_replace( '<', ' <', $html ) ) ) );
	return array(
		'ok'       => $r['ok'],
		'sections' => $r['sections'],
		'sig'      => md5( $html ),
		'raw'      => $r['ok'] ? '' : $html, // podgląd opisu, którego edytor nie odczyta
		'text'     => wp_html_excerpt( $txt, 140, '…' ),
	);
}

/* ============================================================
 * 5. KOPIE OPISU
 * ============================================================ */

function rzd_desc_backups( $pid ) {
	$b = get_post_meta( $pid, '_rzd_desc_backup', true );
	return is_array( $b ) ? $b : array();
}

function rzd_desc_backups_set( $pid, $b ) {
	foreach ( $b as $k => $v ) {
		if ( empty( $v ) ) {
			unset( $b[ $k ] );
		}
	}
	if ( $b ) {
		update_post_meta( $pid, '_rzd_desc_backup', wp_slash( $b ) ); // update_metadata zdejmuje ukośniki
	} else {
		delete_post_meta( $pid, '_rzd_desc_backup' );
	}
}

function rzd_desc_backup_entry( $html ) {
	$u = wp_get_current_user();
	return array( 'html' => (string) $html, 'date' => current_time( 'Y-m-d H:i' ), 'user' => $u && $u->exists() ? $u->display_name : '' );
}

/** Po zmianie opisu z $old na $new: oryginał (raz, gdy stary był nieczytelny) i poprzednia wersja. */
function rzd_desc_backup_after_change( $pid, $kind, $old, $new, $old_readable ) {
	$old = (string) $old;
	if ( $old === (string) $new || '' === trim( $old ) ) {
		return;
	}
	$b = rzd_desc_backups( $pid );
	if ( ! isset( $b[ $kind ] ) || ! is_array( $b[ $kind ] ) ) {
		$b[ $kind ] = array();
	}
	if ( ! $old_readable && empty( $b[ $kind ]['orig'] ) ) {
		$b[ $kind ]['orig'] = rzd_desc_backup_entry( $old );
	}
	if ( empty( $b[ $kind ]['orig'] ) || $b[ $kind ]['orig']['html'] !== $old ) {
		$b[ $kind ]['prev'] = rzd_desc_backup_entry( $old ); // oryginału nie dublujemy
	}
	rzd_desc_backups_set( $pid, $b );
}

/** Kopie dla edytora: { short: { orig?, prev? }, long: {…} } z html, datą i autorem. */
function rzd_desc_backups_info( $pid ) {
	$b   = rzd_desc_backups( $pid );
	$out = array( 'short' => new stdClass(), 'long' => new stdClass() );
	foreach ( array( 'short', 'long' ) as $k ) {
		$row = array();
		foreach ( array( 'orig', 'prev' ) as $w ) {
			if ( ! empty( $b[ $k ][ $w ]['html'] ) ) {
				$row[ $w ] = array( 'html' => (string) $b[ $k ][ $w ]['html'], 'date' => (string) $b[ $k ][ $w ]['date'], 'user' => (string) $b[ $k ][ $w ]['user'] );
			}
		}
		if ( $row ) {
			$out[ $k ] = $row;
		}
	}
	return $out;
}

// Kopie opisu należą do konkretnego dania – „Duplikuj produkt” ich nie przenosi.
add_filter( 'woocommerce_duplicate_product_exclude_meta', function ( $meta ) {
	$meta[] = '_rzd_desc_backup';
	return $meta;
} );

function rzd_desc_get( $p, $kind ) {
	return 'short' === $kind ? (string) $p->get_short_description() : (string) $p->get_description();
}

function rzd_desc_set( $p, $kind, $html ) {
	if ( 'short' === $kind ) {
		$p->set_short_description( $html );
	} else {
		$p->set_description( $html );
	}
}

/**
 * Sprawdzenie zmiany opisu z edytora PRZED zapisem czegokolwiek (moduł 22, rzd_ed_save).
 * $in = { sections[], sig, force }. Zwraca [ old, new, old_readable ] albo WP_Error.
 */
function rzd_desc_prepare( $p, $kind, $in ) {
	$old = rzd_desc_get( $p, $kind );
	if ( ! isset( $in['sig'] ) || (string) $in['sig'] !== md5( $old ) ) {
		return new WP_Error( 'sig', 'Opis tego produktu zmienił się w międzyczasie (np. w panelu). Zamknij edytor opisu, otwórz kartę ponownie i powtórz zmianę.' );
	}
	$parsed = rzd_desc_parse( $old );
	if ( ! $parsed['ok'] && empty( $in['force'] ) ) {
		return new WP_Error( 'locked', 'Obecnego opisu nie da się odczytać w edytorze – najpierw wybierz „Utwórz nowy opis”.' );
	}
	$new = rzd_desc_build( isset( $in['sections'] ) && is_array( $in['sections'] ) ? $in['sections'] : array(), $kind );
	return array( $old, $new, $parsed['ok'] );
}

/* ============================================================
 * 6. AJAX (strona edycji – uprawnienia i nonce: rzd_ed_guard z modułu 22)
 * ============================================================ */

function rzd_desc_kind_post() {
	return 'short' === rzd_ed_post( 'kind', '' ) ? 'short' : 'long';
}

// Produkty z czytelnym, niepustym opisem danego rodzaju – do „Kopiuj z innego produktu”.
add_action( 'wp_ajax_rzd_ed_desc_list', function () {
	rzd_ed_guard();
	$kind = rzd_desc_kind_post();
	$skip = absint( rzd_ed_post( 'id', 0 ) );
	$ids  = wc_get_products( array( 'status' => array( 'publish', 'private' ), 'limit' => -1, 'return' => 'ids', 'orderby' => 'title', 'order' => 'ASC' ) );
	_prime_post_caches( array_map( 'intval', $ids ), false, true );
	$out = array();
	foreach ( $ids as $id ) {
		if ( (int) $id === $skip ) {
			continue;
		}
		$p = wc_get_product( $id );
		if ( ! $p ) {
			continue;
		}
		$html = rzd_desc_get( $p, $kind );
		if ( '' === trim( $html ) ) {
			continue;
		}
		$r = rzd_desc_parse( $html );
		if ( $r['ok'] && $r['sections'] ) {
			$out[] = array( 'id' => (int) $id, 'name' => $p->get_name(), 'thumb' => rzd_ed_thumb( $p->get_image_id() ), 'n' => count( $r['sections'] ) );
		}
	}
	wp_send_json_success( array( 'list' => $out ) );
} );

add_action( 'wp_ajax_rzd_ed_desc_get', function () {
	rzd_ed_guard();
	$p = wc_get_product( absint( rzd_ed_post( 'id', 0 ) ) );
	if ( ! $p ) {
		wp_send_json_error( array( 'msg' => 'Nie ma takiego produktu.' ) );
	}
	$r = rzd_desc_parse( rzd_desc_get( $p, rzd_desc_kind_post() ) );
	if ( ! $r['ok'] ) {
		wp_send_json_error( array( 'msg' => 'Opisu tego produktu nie da się odczytać w edytorze.' ) );
	}
	wp_send_json_success( array( 'sections' => $r['sections'] ) );
} );

// Kopie: op = restore | delete, which = orig | prev.
add_action( 'wp_ajax_rzd_ed_desc_backup', function () {
	rzd_ed_guard();
	$p = wc_get_product( absint( rzd_ed_post( 'id', 0 ) ) );
	if ( ! $p ) {
		wp_send_json_error( array( 'msg' => 'Nie ma takiego produktu.' ) );
	}
	$kind  = rzd_desc_kind_post();
	$which = 'orig' === rzd_ed_post( 'which', '' ) ? 'orig' : 'prev';
	$op    = 'restore' === rzd_ed_post( 'op', '' ) ? 'restore' : 'delete';
	$b     = rzd_desc_backups( $p->get_id() );
	if ( empty( $b[ $kind ][ $which ]['html'] ) ) {
		wp_send_json_error( array( 'msg' => 'Tej kopii już nie ma.' ) );
	}
	$copy = (string) $b[ $kind ][ $which ]['html'];
	if ( 'restore' === $op ) {
		$cur = rzd_desc_get( $p, $kind );
		rzd_desc_set( $p, $kind, $copy ); // własna treść produktu sprzed zmian – zapisujemy 1:1
		$p->save();
		// Obecny opis → „Poprzednia wersja” (przywrócenie też da się cofnąć); przywrócony oryginał znika z kopii.
		if ( '' !== trim( $cur ) && $cur !== $copy ) {
			$b[ $kind ]['prev'] = rzd_desc_backup_entry( $cur );
		} elseif ( 'prev' === $which ) {
			unset( $b[ $kind ]['prev'] );
		}
		if ( 'orig' === $which ) {
			unset( $b[ $kind ]['orig'] );
		}
	} else {
		unset( $b[ $kind ][ $which ] );
	}
	rzd_desc_backups_set( $p->get_id(), $b );
	wc_delete_product_transients( $p->get_id() );
	$p = wc_get_product( $p->get_id() );
	wp_send_json_success( array( 'row' => rzd_ed_row( $p ), 'product' => rzd_ed_product_data( $p ) ) );
} );
