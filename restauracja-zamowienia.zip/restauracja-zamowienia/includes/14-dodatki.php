<?php
/**
 * MODUŁ 14: Dodatki i Składniki — dwa OSOBNE, powiązane katalogi
 *
 * "Dodatek" (np. "Mięso", "Frytki", "Opakowanie") to obiekt z własną nazwą,
 * ceną "przy dodaniu", ceną "przy odejmowaniu", flagą "obowiązkowy" i
 * ikonką. To JEGO wybierasz w konfiguratorze "Możliwe modyfikacje" na
 * karcie produktu (moduł 10) – tak jak dotąd.
 *
 * "Składnik" (np. "Kotlet schabowy", "Ziemniaki", "Surówka colesław") to
 * osobny, PROSTSZY obiekt – ma tylko nazwę i typ, ŻADNEJ ceny. Jego rola
 * jest czysto opisowa: dodajesz Składniki do "Składu" konkretnego produktu
 * (moduł 10), żeby klient widział, z czego faktycznie złożone jest danie.
 *
 * Oba obiekty łączy WSPÓLNA, jedna lista "Typów" (np. "mięso", "surówka",
 * "węglowodany"). Dzięki temu Dodatek "Mięso" (typ: mięso), użyty w
 * modyfikacji na dowolnym produkcie, może w chwili wyboru ZNALEŹĆ we
 * Składzie TEGO produktu właściwy Składnik tego samego typu (np. "Kotlet
 * schabowy" na Schabowym, "Kotlet z kurczaka" na Sznyclu) i pokazać klientowi
 * jego nazwę – ale cenę bierze zawsze z Dodatku, nigdy ze Składnika (bo
 * Składnik ceny nie ma). Dodatek BEZ typu działa wprost, swoją własną nazwą
 * i ceną, bez szukania niczego w składzie (np. "Opakowanie").
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 1. TYP TREŚCI
 * ============================================================ */
add_action( 'init', function () {
	register_post_type( 'rzd_addon', array(
		'labels'          => array(
			'name'               => 'Dodatki',
			'singular_name'      => 'Dodatek',
			'add_new'            => 'Dodaj nowy',
			'add_new_item'       => 'Dodaj dodatek',
			'edit_item'          => 'Edytuj dodatek',
			'new_item'           => 'Nowy dodatek',
			'view_item'          => 'Zobacz dodatek',
			'search_items'       => 'Szukaj dodatków',
			'not_found'          => 'Nie znaleziono dodatków',
			'all_items'          => 'Wszystkie dodatki',
		),
		'public'          => false,
		'show_ui'         => true,
		'show_in_menu'    => true,
		'menu_icon'       => 'dashicons-tag',
		'menu_position'   => 4,
		'supports'        => array( 'title', 'thumbnail' ),
		'capability_type' => 'post',
	) );

	// Typ składnika (np. mięso, surówka, węglowodany) – JEDNA, wspólna lista
	// używana zarówno przy definiowaniu składnika (poniżej), jak i przy
	// wskazywaniu typu przy dodatku (moduł 10) – to on decyduje, który
	// Składnik ze Składu produktu ma zostać dopasowany. Wspólna dla obu
	// typów treści (Dodatek i Składnik), zarządzana jak zwykła taksonomia
	// WordPressa.
	register_taxonomy( 'rzd_addon_type', array( 'rzd_addon', 'rzd_ingredient' ), array(
		'labels'            => array(
			'name'          => 'Typy',
			'singular_name' => 'Typ',
			'menu_name'     => 'Typy',
			'add_new_item'  => 'Dodaj typ',
			'edit_item'     => 'Edytuj typ',
			'search_items'  => 'Szukaj typów',
			'all_items'     => 'Wszystkie typy',
		),
		'hierarchical'      => true,
		'public'            => false,
		'show_ui'           => true,
		'show_admin_column' => true,
		'show_in_menu'      => true,
		'meta_box_cb'       => false, // własne pole niżej (rzd_addon_fields_html / rzd_ingredient_fields_html) zamiast domyślnego multi-checkboxa – DOKŁADNIE JEDEN typ
	) );

	// Składnik – element Składu produktu (moduł 10): sama nazwa + typ,
	// bez ceny. To on odpowiada za opis "z czego złożone jest danie".
	register_post_type( 'rzd_ingredient', array(
		'labels'          => array(
			'name'          => 'Składniki',
			'singular_name' => 'Składnik',
			'add_new'       => 'Dodaj nowy',
			'add_new_item'  => 'Dodaj składnik',
			'edit_item'     => 'Edytuj składnik',
			'new_item'      => 'Nowy składnik',
			'view_item'     => 'Zobacz składnik',
			'search_items'  => 'Szukaj składników',
			'not_found'     => 'Nie znaleziono składników',
			'all_items'     => 'Wszystkie składniki',
		),
		'public'          => false,
		'show_ui'         => true,
		'show_in_menu'    => true,
		'menu_icon'       => 'dashicons-carrot',
		'menu_position'   => 5,
		'supports'        => array( 'title' ),
		'capability_type' => 'post',
	) );
} );

add_action( 'add_meta_boxes', function () {
	add_meta_box( 'rzd_ingredient_fields', 'Typ składnika', 'rzd_ingredient_fields_html', 'rzd_ingredient', 'normal', 'high' );
} );

function rzd_ingredient_fields_html( $post ) {
	wp_nonce_field( 'rzd_ingredient_save', 'rzd_ingredient_nonce' );
	$cur_terms = wp_get_object_terms( $post->ID, 'rzd_addon_type', array( 'fields' => 'ids' ) );
	$cur_type  = ( ! is_wp_error( $cur_terms ) && $cur_terms ) ? (int) $cur_terms[0] : 0;
	$all_types = get_terms( array( 'taxonomy' => 'rzd_addon_type', 'hide_empty' => false ) );
	?>
	<p>
		<select name="rzd_ingredient_type">
			<option value="">— bez typu —</option>
			<?php foreach ( $all_types as $t ) : ?>
				<option value="<?php echo esc_attr( $t->term_id ); ?>" <?php selected( $cur_type, $t->term_id ); ?>><?php echo esc_html( $t->name ); ?></option>
			<?php endforeach; ?>
		</select>
		<p class="description">Ten sam typ przypisujesz potem Dodatkowi (menu Dodatki) – dzięki temu dodatek "po typie" (np. "Mięso") sam znajdzie właściwy składnik w składzie tego konkretnego produktu.</p>
	</p>
	<?php
}

add_action( 'save_post_rzd_ingredient', function ( $post_id ) {
	if ( ! isset( $_POST['rzd_ingredient_nonce'] ) || ! wp_verify_nonce( $_POST['rzd_ingredient_nonce'], 'rzd_ingredient_save' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$type_id = isset( $_POST['rzd_ingredient_type'] ) ? absint( $_POST['rzd_ingredient_type'] ) : 0;
	wp_set_object_terms( $post_id, $type_id ? array( $type_id ) : array(), 'rzd_addon_type', false );
} );

add_action( 'add_meta_boxes', function () {
	add_meta_box( 'rzd_addon_fields', 'Ustawienia dodatku', 'rzd_addon_fields_html', 'rzd_addon', 'normal', 'high' );
} );

function rzd_addon_fields_html( $post ) {
	wp_nonce_field( 'rzd_addon_save', 'rzd_addon_nonce' );
	$price       = get_post_meta( $post->ID, '_rzd_addon_price', true );
	$price_minus = get_post_meta( $post->ID, '_rzd_addon_price_minus', true );
	$mandatory   = get_post_meta( $post->ID, '_rzd_addon_mandatory', true );
	$cur_terms   = wp_get_object_terms( $post->ID, 'rzd_addon_type', array( 'fields' => 'ids' ) );
	$cur_type    = ( ! is_wp_error( $cur_terms ) && $cur_terms ) ? (int) $cur_terms[0] : 0;
	$all_types   = get_terms( array( 'taxonomy' => 'rzd_addon_type', 'hide_empty' => false ) );
	?>
	<p>
		<label><strong>Typ</strong> (opcjonalnie)</label><br>
		<select name="rzd_addon_type">
			<option value="">— bez typu, działa wprost swoją nazwą i ceną —</option>
			<?php foreach ( $all_types as $t ) : ?>
				<option value="<?php echo esc_attr( $t->term_id ); ?>" <?php selected( $cur_type, $t->term_id ); ?>><?php echo esc_html( $t->name ); ?></option>
			<?php endforeach; ?>
		</select>
		<p class="description">Jeśli ustawisz typ, ten dodatek – użyty w modyfikacji na dowolnym produkcie – sam znajdzie w Składzie TEGO produktu pasujący Składnik tego samego typu i pokaże klientowi JEGO nazwę (cenę zawsze bierze stąd, z dodatku). Bez dopasowania w składzie produktu ta modyfikacja po prostu się dla niego nie pojawi. Nowe typy dodajesz w menu Dodatki → Typy.</p>
	</p>
	<p>
		<label><strong>Wartość przy dodaniu</strong> (może być ujemna) – dolicza się, gdy modyfikacja ma rolę "Dodaje" albo "Obowiązkowa"</label><br>
		<input type="number" step="0.01" name="rzd_addon_price" value="<?php echo esc_attr( $price ); ?>" style="width:150px;">
	</p>
	<p>
		<label><strong>Wartość przy odejmowaniu</strong> (opcjonalnie) – odejmuje się, gdy modyfikacja ma rolę "Odejmuje" albo "Dezaktywuje". Zestaw zwykle kosztuje mniej niż suma cen osobnych składników (np. mięso + frytki + surówka osobno to 50 zł, w zestawie 37 zł) – dlatego to osobna wartość, a nie ta sama cena "na minus".</label><br>
		<input type="number" step="0.01" name="rzd_addon_price_minus" value="<?php echo esc_attr( $price_minus ); ?>" style="width:150px;" placeholder="puste = tyle samo co przy dodaniu">
	</p>
	<p>
		<label>
			<input type="checkbox" name="rzd_addon_mandatory" value="1" <?php checked( $mandatory, '1' ); ?>>
			<strong>Obowiązkowy</strong> – nie da się go zdjąć; front-end blokuje zmianę jego wartości wszędzie, gdzie ten dodatek jest użyty (np. opakowanie)
		</label>
	</p>
	<p class="description">Ikonkę ustawiasz jako obrazek wyróżniający (po prawej stronie edycji).</p>
	<?php
}

add_action( 'save_post_rzd_addon', function ( $post_id ) {
	if ( ! isset( $_POST['rzd_addon_nonce'] ) || ! wp_verify_nonce( $_POST['rzd_addon_nonce'], 'rzd_addon_save' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	update_post_meta( $post_id, '_rzd_addon_price', isset( $_POST['rzd_addon_price'] ) ? (float) $_POST['rzd_addon_price'] : 0 );
	// Puste pole = brak nadpisania (rzd_get_addon() użyje wtedy tej samej
	// wartości co "Wartość przy dodaniu") – dlatego usuwamy meta zamiast zapisać 0.
	if ( isset( $_POST['rzd_addon_price_minus'] ) && '' !== trim( $_POST['rzd_addon_price_minus'] ) ) {
		update_post_meta( $post_id, '_rzd_addon_price_minus', (float) $_POST['rzd_addon_price_minus'] );
	} else {
		delete_post_meta( $post_id, '_rzd_addon_price_minus' );
	}
	update_post_meta( $post_id, '_rzd_addon_mandatory', empty( $_POST['rzd_addon_mandatory'] ) ? '' : '1' );

	$type_id = isset( $_POST['rzd_addon_type'] ) ? absint( $_POST['rzd_addon_type'] ) : 0;
	wp_set_object_terms( $post_id, $type_id ? array( $type_id ) : array(), 'rzd_addon_type', false ); // false = zastąp, nie dołączaj – składnik ma dokładnie jeden typ
} );

/* Kolumny na liście: ikonka, cena, obowiązkowy */
add_filter( 'manage_rzd_addon_posts_columns', function ( $cols ) {
	$new = array();
	foreach ( $cols as $k => $v ) {
		if ( 'title' === $k ) {
			$new['rzd_icon'] = 'Ikonka';
		}
		$new[ $k ] = $v;
		if ( 'title' === $k ) {
			$new['rzd_price']     = 'Cena';
			$new['rzd_mandatory'] = 'Obowiązkowy';
		}
	}
	return $new;
} );
add_action( 'manage_rzd_addon_posts_custom_column', function ( $col, $post_id ) {
	if ( 'rzd_icon' === $col ) {
		echo has_post_thumbnail( $post_id ) ? get_the_post_thumbnail( $post_id, array( 32, 32 ) ) : '—';
	} elseif ( 'rzd_price' === $col ) {
		$addon = rzd_get_addon( $post_id );
		if ( ! $addon ) {
			echo '—';
		} elseif ( abs( $addon['price'] - $addon['price_minus'] ) < 0.001 ) {
			echo esc_html( number_format( $addon['price'], 2, ',', '' ) . ' zł' );
		} else {
			echo esc_html( '+' . number_format( $addon['price'], 2, ',', '' ) . ' zł / -' . number_format( $addon['price_minus'], 2, ',', '' ) . ' zł' );
		}
	} elseif ( 'rzd_mandatory' === $col ) {
		echo get_post_meta( $post_id, '_rzd_addon_mandatory', true ) ? '✓' : '—';
	}
}, 10, 2 );

/* ============================================================
 * 2. ODCZYT DODATKU – używane przez moduł 10 (modyfikacje) i 12/9 (kuchnia/raporty)
 * ============================================================ */
function rzd_get_addon( $id ) {
	$id = (int) $id;
	if ( ! $id ) {
		return null;
	}
	static $cache = array();
	if ( isset( $cache[ $id ] ) ) {
		return $cache[ $id ];
	}
	$post = get_post( $id );
	if ( ! $post || 'rzd_addon' !== $post->post_type || 'publish' !== $post->post_status ) {
		return $cache[ $id ] = null;
	}
	$price          = (float) get_post_meta( $id, '_rzd_addon_price', true );
	$price_minus_raw = get_post_meta( $id, '_rzd_addon_price_minus', true );
	// Puste pole = brak osobnej wartości dla odejmowania – używamy tej samej
	// ceny co przy dodaniu (zachowanie sprzed wprowadzenia tego podziału).
	$price_minus = ( '' === $price_minus_raw ) ? $price : (float) $price_minus_raw;

	$type_terms = wp_get_object_terms( $id, 'rzd_addon_type', array( 'fields' => 'ids' ) );
	$cache[ $id ] = array(
		'id'          => $id,
		'name'        => $post->post_title,
		'type_id'     => ( ! is_wp_error( $type_terms ) && $type_terms ) ? (int) $type_terms[0] : 0,
		'price'       => $price,        // wartość przy roli "dodaje" / "obowiązkowa"
		'price_minus' => $price_minus,  // wartość przy roli "odejmuje" / "dezaktywuje" (dodatnia liczba – znak dokłada wywołujący kod)
		'mandatory'   => (bool) get_post_meta( $id, '_rzd_addon_mandatory', true ),
		'icon_url'    => get_the_post_thumbnail_url( $id, array( 48, 48 ) ) ?: '',
	);
	return $cache[ $id ];
}

function rzd_get_all_addon_types() {
	$terms = get_terms( array( 'taxonomy' => 'rzd_addon_type', 'hide_empty' => false ) );
	return is_wp_error( $terms ) ? array() : $terms;
}

/**
 * Skład produktu – lista ID składników wybranych w zakładce "Możliwe
 * modyfikacje" (sekcja "Skład"), czysto do WYŚWIETLANIA (nazwa produktu +
 * lista składników mniejszą czcionką) i do WYSZUKIWANIA "który konkretnie
 * składnik ma dany typ w TYM produkcie" (patrz niżej).
 */
function rzd_get_ingredient( $id ) {
	$id = (int) $id;
	if ( ! $id ) {
		return null;
	}
	static $cache = array();
	if ( isset( $cache[ $id ] ) ) {
		return $cache[ $id ];
	}
	$post = get_post( $id );
	if ( ! $post || 'rzd_ingredient' !== $post->post_type || 'publish' !== $post->post_status ) {
		return $cache[ $id ] = null;
	}
	$type_terms   = wp_get_object_terms( $id, 'rzd_addon_type', array( 'fields' => 'ids' ) );
	$cache[ $id ] = array(
		'id'      => $id,
		'name'    => $post->post_title,
		'type_id' => ( ! is_wp_error( $type_terms ) && $type_terms ) ? (int) $type_terms[0] : 0,
	);
	return $cache[ $id ];
}

function rzd_get_all_ingredients() {
	$posts = get_posts( array(
		'post_type'   => 'rzd_ingredient',
		'post_status' => 'publish',
		'numberposts' => -1,
		'orderby'     => 'title',
		'order'       => 'ASC',
	) );
	$out = array();
	foreach ( $posts as $p ) {
		$out[] = rzd_get_ingredient( $p->ID );
	}
	return $out;
}

/**
 * Skład produktu – lista Składników wybranych w zakładce "Możliwe
 * modyfikacje" (sekcja "Skład"), czysto do WYŚWIETLANIA (nazwa produktu +
 * lista składników mniejszą czcionką) i do WYSZUKIWANIA "który konkretnie
 * Składnik ma dany typ w TYM produkcie" (patrz rzd_find_ingredient_by_type).
 */
function rzd_get_product_sklad( $product_id ) {
	$ids = get_post_meta( $product_id, '_rzd_sklad', true );
	if ( ! is_array( $ids ) ) {
		return array();
	}
	$out = array();
	foreach ( $ids as $id ) {
		$i = rzd_get_ingredient( $id );
		if ( $i ) {
			$out[] = $i;
		}
	}
	return $out;
}

/**
 * Serce mechanizmu "dodatek po typie": zakładamy, że w składzie JEDNEGO
 * produktu jest NAJWYŻEJ JEDEN składnik danego typu (np. jedno "mięso") –
 * dzięki temu jeden Dodatek (np. "Mięso", typ: mięso) działa poprawnie na
 * różnych produktach, zawsze trafiając we właściwy, konkretny Składnik TEGO
 * produktu (Kotlet schabowy na Schabowym, Kotlet z kurczaka na Sznyclu) –
 * ale CENĘ zawsze bierze z Dodatku, nigdy ze Składnika (bo Składnik ceny
 * w ogóle nie ma). Brak dopasowania (produkt nie ma w składzie tego typu) =
 * null – modyfikacja jest wtedy pomijana dla tego konkretnego produktu.
 */
function rzd_find_ingredient_by_type( $product_id, $type_id ) {
	if ( ! $type_id ) {
		return null;
	}
	foreach ( rzd_get_product_sklad( $product_id ) as $i ) {
		if ( (int) $i['type_id'] === (int) $type_id ) {
			return $i;
		}
	}
	return null;
}

/**
 * Nazwa produktu + (jeśli zdefiniowany) skład mniejszą czcionką pod spodem.
 * Bez zdefiniowanego składu – sama nazwa, bez zmian. Używane wszędzie tam,
 * gdzie dotąd pokazywaliśmy samą nazwę produktu (lista, kuchnia, koszyk…).
 */
function rzd_product_name_with_sklad_html( $product_id, $name ) {
	$sklad = rzd_get_product_sklad( $product_id );
	if ( ! $sklad ) {
		return esc_html( $name );
	}
	$names = array_map( function ( $i ) { return esc_html( $i['name'] ); }, $sklad );
	return esc_html( $name ) . '<br><span class="rzd-sklad-note">' . implode( ', ', $names ) . '</span>';
}

function rzd_get_all_addons() {
	$posts = get_posts( array(
		'post_type'      => 'rzd_addon',
		'post_status'    => 'publish',
		'numberposts'    => -1,
		'orderby'        => 'title',
		'order'          => 'ASC',
	) );
	$out = array();
	foreach ( $posts as $p ) {
		$out[] = rzd_get_addon( $p->ID );
	}
	return $out;
}
