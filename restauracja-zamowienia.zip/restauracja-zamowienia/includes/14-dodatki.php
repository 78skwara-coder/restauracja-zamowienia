<?php
/**
 * MODUŁ 14: Dodatki – JEDEN katalog (od 2.32.0; wcześniej osobno Dodatki i Składniki)
 *
 * Dodatek (np. "Kotlet schabowy", "Ziemniaki gotowane", "Frytki", "Sos czosnkowy")
 * ma nazwę, opcjonalny TYP (np. Mięso, Warzywa, Węglowodany), ikonkę, wartość
 * "przy dodaniu" (dopłata / cena dokładki), wartość "przy odejmowaniu" i flagę
 * "obowiązkowy".
 *
 * SKŁAD produktu (moduł 10, meta _rzd_sklad_addons) to lista dodatków – z czego
 * danie się składa. Wybór klienta przed koszykiem zmienia skład (rzd_effective_sklad):
 * wybrana opcja zastępuje dodatek tego samego typu albo się dopisuje, opcja
 * "Bez …" (rola Odejmuje / Dezaktywuje) go skreśla. Dodatek z typem w modyfikacji
 * pokazuje nazwę dodatku tego typu ze składu – w "Dodatkach płatnych" ze składu
 * PO wyborze klienta (wybrał ziemniaki → "Ziemniaki gotowane").
 *
 * Dawny katalog Składników (rzd_ingredient) jest przenoszony jednorazowo
 * (rzd_skl_migrate) i zostaje w bazie bez zmian – powrót do 2.31.0 działa.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 1. TYP TREŚCI
 * ============================================================ */
add_action( 'init', function () {
	register_post_type( 'rzd_addon', array(
		'labels'          => array(
			'name'               => 'Dodatki',
			'singular_name'      => 'Dodatek',
			'add_new'            => 'Dodaj nowy',
			'add_new_item'       => 'Dodaj dodatek',
			'edit_item'          => 'Edytuj dodatek',
			'new_item'           => 'Nowy dodatek',
			'view_item'          => 'Zobacz dodatek',
			'search_items'       => 'Szukaj dodatków',
			'not_found'          => 'Nie znaleziono dodatków',
			'all_items'          => 'Wszystkie dodatki',
		),
		'public'          => false,
		'show_ui'         => true,
		'show_in_menu'    => false, // w menu Restauracja (moduł 00-menu)
		'supports'        => array( 'title', 'thumbnail' ),
		'capability_type' => 'post',
	) );

	// Typ składnika (np. mięso, surówka, węglowodany) – JEDNA, wspólna lista
	// używana zarówno przy definiowaniu składnika (poniżej), jak i przy
	// wskazywaniu typu przy dodatku (moduł 10) – to on decyduje, który
	// Składnik ze Składu produktu ma zostać dopasowany. Wspólna dla obu
	// typów treści (Dodatek i Składnik), zarządzana jak zwykła taksonomia
	// WordPressa.
	register_taxonomy( 'rzd_addon_type', array( 'rzd_addon', 'rzd_ingredient' ), array(
		'labels'            => array(
			'name'          => 'Typy',
			'singular_name' => 'Typ',
			'menu_name'     => 'Typy',
			'add_new_item'  => 'Dodaj typ',
			'edit_item'     => 'Edytuj typ',
			'search_items'  => 'Szukaj typów',
			'all_items'     => 'Wszystkie typy',
		),
		'hierarchical'      => true,
		'public'            => false,
		'show_ui'           => true,
		'show_admin_column' => true,
		'show_in_menu'      => false, // w menu Restauracja (moduł 00-menu)
		'meta_box_cb'       => false, // własne pole niżej (rzd_addon_fields_html / rzd_ingredient_fields_html) zamiast domyślnego multi-checkboxa – DOKŁADNIE JEDEN typ
	) );

	// Składnik – element Składu produktu (moduł 10): sama nazwa + typ,
	// bez ceny. To on odpowiada za opis "z czego złożone jest danie".
	register_post_type( 'rzd_ingredient', array(
		'labels'          => array(
			'name'          => 'Składniki',
			'singular_name' => 'Składnik',
			'add_new'       => 'Dodaj nowy',
			'add_new_item'  => 'Dodaj składnik',
			'edit_item'     => 'Edytuj składnik',
			'new_item'      => 'Nowy składnik',
			'view_item'     => 'Zobacz składnik',
			'search_items'  => 'Szukaj składników',
			'not_found'     => 'Nie znaleziono składników',
			'all_items'     => 'Wszystkie składniki',
		),
		'public'          => false,
		'show_ui'         => true,
		'show_in_menu'    => false, // od 2.32.0 skład = dodatki; dane zostają (powrót do 2.31.0)
		'menu_icon'       => 'dashicons-carrot',
		'menu_position'   => 5,
		'supports'        => array( 'title' ),
		'capability_type' => 'post',
	) );
} );

add_action( 'add_meta_boxes', function () {
	add_meta_box( 'rzd_ingredient_fields', 'Typ składnika', 'rzd_ingredient_fields_html', 'rzd_ingredient', 'normal', 'high' );
} );

function rzd_ingredient_fields_html( $post ) {
	wp_nonce_field( 'rzd_ingredient_save', 'rzd_ingredient_nonce' );
	$cur_terms = wp_get_object_terms( $post->ID, 'rzd_addon_type', array( 'fields' => 'ids' ) );
	$cur_type  = ( ! is_wp_error( $cur_terms ) && $cur_terms ) ? (int) $cur_terms[0] : 0;
	$all_types = get_terms( array( 'taxonomy' => 'rzd_addon_type', 'hide_empty' => false ) );
	?>
	<p>
		<select name="rzd_ingredient_type">
			<option value="">— bez typu —</option>
			<?php foreach ( $all_types as $t ) : ?>
				<option value="<?php echo esc_attr( $t->term_id ); ?>" <?php selected( $cur_type, $t->term_id ); ?>><?php echo esc_html( $t->name ); ?></option>
			<?php endforeach; ?>
		</select>
		<p class="description">Ten sam typ przypisujesz potem Dodatkowi (menu Dodatki) – dzięki temu dodatek "po typie" (np. "Mięso") sam znajdzie właściwy składnik w składzie tego konkretnego produktu.</p>
	</p>
	<?php
}

add_action( 'save_post_rzd_ingredient', function ( $post_id ) {
	if ( ! isset( $_POST['rzd_ingredient_nonce'] ) || ! wp_verify_nonce( $_POST['rzd_ingredient_nonce'], 'rzd_ingredient_save' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$type_id = isset( $_POST['rzd_ingredient_type'] ) ? absint( $_POST['rzd_ingredient_type'] ) : 0;
	wp_set_object_terms( $post_id, $type_id ? array( $type_id ) : array(), 'rzd_addon_type', false );
} );

/* ============================================================
 * 1a. ZAPIS DODATKU (od 2.45.0 – Panel restauracji → Menu → Dodatki; ekran kokpitu
 *     przekierowuje do panelu). Te same pola meta co dawny formularz.
 * ============================================================ */

/**
 * Tworzy / zmienia dodatek. $in: name, type (term_id albo 0), price, price_minus ('' = jak przy
 * dodaniu), mandatory, pack (id opakowania albo 0), cap. Zwraca ID albo WP_Error.
 */
function rzd_addon_save( $id, $in ) {
	$in   = is_array( $in ) ? $in : array();
	$name = isset( $in['name'] ) ? trim( sanitize_text_field( $in['name'] ) ) : '';
	if ( '' === $name ) {
		return new WP_Error( 'name', 'Podaj nazwę dodatku.' );
	}
	$num = function ( $v ) {
		$v = str_replace( ',', '.', trim( (string) $v ) );
		return is_numeric( $v ) ? round( (float) $v, 2 ) : null;
	};
	$id = absint( $id );
	if ( $id ) {
		if ( 'rzd_addon' !== get_post_type( $id ) ) {
			return new WP_Error( 'id', 'Nie ma takiego dodatku.' );
		}
		wp_update_post( array( 'ID' => $id, 'post_title' => $name ) );
	} else {
		$id = wp_insert_post( array( 'post_type' => 'rzd_addon', 'post_status' => 'publish', 'post_title' => $name ), true );
		if ( is_wp_error( $id ) ) {
			return $id;
		}
	}
	$price = $num( isset( $in['price'] ) ? $in['price'] : '' );
	update_post_meta( $id, '_rzd_addon_price', null === $price ? 0 : $price );
	// puste = brak nadpisania (rzd_get_addon() użyje wartości „przy dodaniu”)
	$minus = $num( isset( $in['price_minus'] ) ? $in['price_minus'] : '' );
	if ( null === $minus ) {
		delete_post_meta( $id, '_rzd_addon_price_minus' );
	} else {
		update_post_meta( $id, '_rzd_addon_price_minus', $minus );
	}
	update_post_meta( $id, '_rzd_addon_mandatory', empty( $in['mandatory'] ) ? '' : '1' );
	$pack = isset( $in['pack'] ) ? absint( $in['pack'] ) : 0;
	if ( $pack && function_exists( 'rzd_packaging_get' ) && rzd_packaging_get( $pack ) ) {
		update_post_meta( $id, '_rzd_addon_packaging', $pack );
	} else {
		delete_post_meta( $id, '_rzd_addon_packaging' );
	}
	update_post_meta( $id, '_rzd_addon_pack_capacity', max( 1, absint( isset( $in['cap'] ) ? $in['cap'] : 1 ) ) );
	$type = isset( $in['type'] ) ? absint( $in['type'] ) : 0;
	if ( $type && ! term_exists( $type, 'rzd_addon_type' ) ) {
		$type = 0;
	}
	wp_set_object_terms( $id, $type ? array( $type ) : array(), 'rzd_addon_type', false ); // dokładnie jeden typ
	clean_post_cache( $id );
	return (int) $id;
}

/**
 * Gdzie użyte są dodatki: [ addon_id => [ 'Pierogi (skład)', 'Kotlet (modyfikacje)', 'Wzór: Sosy' ] ].
 * Przegląda skład i grupy modyfikacji produktów oraz grupy wzorów – usunięcie użytego dodatku
 * po cichu wycięłoby modyfikacje przy następnym zapisie dania, dlatego panel je blokuje.
 */
function rzd_addon_refs() {
	global $wpdb;
	$out  = array();
	$add  = function ( $aid, $label ) use ( &$out ) {
		$aid = (int) $aid;
		if ( $aid && ( ! isset( $out[ $aid ] ) || ! in_array( $label, $out[ $aid ], true ) ) ) {
			$out[ $aid ][] = $label;
		}
	};
	$walk = function ( $sections, $label ) use ( $add ) {
		foreach ( (array) $sections as $sec ) {
			// grupa z modyfikacjami albo (dawny, płaski zapis) sama modyfikacja
			$items = ( is_array( $sec ) && isset( $sec['items'] ) ) ? (array) $sec['items'] : array( $sec );
			foreach ( $items as $it ) {
				if ( ! is_array( $it ) ) {
					continue;
				}
				if ( ! empty( $it['addon_id'] ) ) {
					$add( $it['addon_id'], $label );
				}
				foreach ( ( isset( $it['options'] ) && is_array( $it['options'] ) ) ? $it['options'] : array() as $o ) {
					if ( ! empty( $o['addon_id'] ) ) {
						$add( $o['addon_id'], $label );
					}
				}
			}
		}
	};
	$rows = $wpdb->get_results( "SELECT pm.post_id, pm.meta_key, pm.meta_value, p.post_title, p.post_type FROM {$wpdb->postmeta} pm JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE pm.meta_key IN ('_rzd_sklad_addons','_rzd_modifiers','_rzd_preset_sections') AND p.post_status NOT IN ('trash','auto-draft')" ); // phpcs:ignore
	foreach ( (array) $rows as $r ) {
		$v = maybe_unserialize( $r->meta_value );
		if ( '_rzd_sklad_addons' === $r->meta_key ) {
			foreach ( (array) $v as $aid ) {
				$add( $aid, $r->post_title . ' (skład)' );
			}
		} elseif ( '_rzd_preset_sections' === $r->meta_key ) {
			$walk( $v, 'Wzór: ' . $r->post_title );
		} else {
			$walk( $v, $r->post_title . ' (modyfikacje)' );
		}
	}
	return $out;
}

/* ============================================================
 * 2. ODCZYT DODATKU – używane przez moduł 10 (modyfikacje) i 12/9 (kuchnia/raporty)
 * ============================================================ */
function rzd_get_addon( $id ) {
	$id = (int) $id;
	if ( ! $id ) {
		return null;
	}
	static $cache = array();
	if ( isset( $cache[ $id ] ) ) {
		return $cache[ $id ];
	}
	rzd_prime_post_type( 'rzd_addon' ); // wszystkie dodatki jednym zapytaniem
	$post = get_post( $id );
	if ( ! $post || 'rzd_addon' !== $post->post_type || 'publish' !== $post->post_status ) {
		return $cache[ $id ] = null;
	}
	$price          = (float) get_post_meta( $id, '_rzd_addon_price', true );
	$price_minus_raw = get_post_meta( $id, '_rzd_addon_price_minus', true );
	// Puste pole = brak osobnej wartości dla odejmowania – używamy tej samej
	// ceny co przy dodaniu (zachowanie sprzed wprowadzenia tego podziału).
	$price_minus = ( '' === $price_minus_raw ) ? $price : (float) $price_minus_raw;

	$type_terms = wp_get_object_terms( $id, 'rzd_addon_type', array( 'fields' => 'ids' ) );
	$cache[ $id ] = array(
		'id'          => $id,
		'name'        => $post->post_title,
		'type_id'     => ( ! is_wp_error( $type_terms ) && $type_terms ) ? (int) $type_terms[0] : 0,
		'type_name'   => '',
		'price'       => $price,        // wartość przy roli "dodaje" / "obowiązkowa"
		'price_minus' => $price_minus,  // wartość przy roli "odejmuje" / "dezaktywuje" (dodatnia liczba – znak dokłada wywołujący kod)
		'mandatory'   => (bool) get_post_meta( $id, '_rzd_addon_mandatory', true ),
		'icon_url'    => get_the_post_thumbnail_url( $id, array( 48, 48 ) ) ?: '',
		// opakowanie dodatku – tylko przy wyborze z dopłatą (moduł 21).
		'packaging'     => (int) get_post_meta( $id, '_rzd_addon_packaging', true ),
		'pack_capacity' => max( 1, (int) get_post_meta( $id, '_rzd_addon_pack_capacity', true ) ),
	);
	if ( $cache[ $id ]['type_id'] ) {
		$t                         = get_term( $cache[ $id ]['type_id'], 'rzd_addon_type' );
		$cache[ $id ]['type_name'] = ( $t && ! is_wp_error( $t ) ) ? $t->name : '';
	}
	return $cache[ $id ];
}

// Etykieta dodatku w listach wyboru panelu: nazwa + typ (dwa dodatki o tej samej nazwie da się odróżnić).
function rzd_addon_admin_label( $a ) {
	return $a['name'] . ( ! empty( $a['type_name'] ) ? ' [' . $a['type_name'] . ']' : '' );
}

function rzd_get_all_addon_types() {
	$terms = get_terms( array( 'taxonomy' => 'rzd_addon_type', 'hide_empty' => false ) );
	return is_wp_error( $terms ) ? array() : $terms;
}

/**
 * Skład produktu – lista ID składników wybranych w zakładce "Możliwe
 * modyfikacje" (sekcja "Skład"), czysto do WYŚWIETLANIA (nazwa produktu +
 * lista składników mniejszą czcionką) i do WYSZUKIWANIA "który konkretnie
 * składnik ma dany typ w TYM produkcie" (patrz niżej).
 */
/**
 * wczytuje RAZ na żądanie wszystkie opublikowane wpisy danego typu
 * (dodatki / składniki – zwykle kilkadziesiąt) razem z metadanymi i (opcjonalnie)
 * typami – kolejne get_post()/get_post_meta() nie pytają już bazy osobno.
 */
function rzd_prime_post_type( $type, $terms = false ) {
	static $done = array();
	if ( isset( $done[ $type ] ) ) {
		return;
	}
	$done[ $type ] = true;
	get_posts( array(
		'post_type'              => $type,
		'post_status'            => 'publish',
		'numberposts'            => -1,
		'no_found_rows'          => true,
		'suppress_filters'       => true,
		'update_post_meta_cache' => true,
		'update_post_term_cache' => (bool) $terms,
	) );
}

function rzd_get_ingredient( $id ) {
	$id = (int) $id;
	if ( ! $id ) {
		return null;
	}
	static $cache = array();
	if ( isset( $cache[ $id ] ) ) {
		return $cache[ $id ];
	}
	rzd_prime_post_type( 'rzd_ingredient', true ); // wszystkie składniki (z typami) jednym zapytaniem
	$post = get_post( $id );
	if ( ! $post || 'rzd_ingredient' !== $post->post_type || 'publish' !== $post->post_status ) {
		return $cache[ $id ] = null;
	}
	$type_terms   = get_the_terms( $id, 'rzd_addon_type' ); // z pamięci podręcznej (wcześniej zapytanie na składnik)
	$cache[ $id ] = array(
		'id'      => $id,
		'name'    => $post->post_title,
		'type_id' => ( $type_terms && ! is_wp_error( $type_terms ) ) ? (int) $type_terms[0]->term_id : 0,
	);
	return $cache[ $id ];
}

function rzd_get_all_ingredients() {
	$posts = get_posts( array(
		'post_type'   => 'rzd_ingredient',
		'post_status' => 'publish',
		'numberposts' => -1,
		'orderby'     => 'title',
		'order'       => 'ASC',
	) );
	$out = array();
	foreach ( $posts as $p ) {
		$out[] = rzd_get_ingredient( $p->ID );
	}
	return $out;
}

/**
 * Skład produktu – lista DODATKÓW (meta _rzd_sklad_addons), w kolejności.
 * Przed przeniesieniem (rzd_skl_migrate) – dawne Składniki z _rzd_sklad
 * (wg mapy przeniesienia, jeśli już jest; inaczej same składniki – te same pola).
 */
function rzd_get_product_sklad( $product_id ) {
	$product_id = (int) $product_id;
	if ( metadata_exists( 'post', $product_id, '_rzd_sklad_addons' ) ) {
		$ids = get_post_meta( $product_id, '_rzd_sklad_addons', true );
		$out = array();
		foreach ( is_array( $ids ) ? $ids : array() as $id ) {
			$a = rzd_get_addon( $id );
			if ( $a ) {
				$out[] = $a;
			}
		}
		return $out;
	}
	$ids = get_post_meta( $product_id, '_rzd_sklad', true );
	if ( ! is_array( $ids ) ) {
		return array();
	}
	$map = get_option( 'rzd_skl_map', array() );
	$out = array();
	foreach ( $ids as $id ) {
		$i = isset( $map[ (int) $id ] ) ? rzd_get_addon( $map[ (int) $id ] ) : rzd_get_ingredient( $id );
		if ( $i ) {
			$out[] = $i;
		}
	}
	return $out;
}

// Zapis składu (lista ID dodatków; pusta lista = danie bez składu). Dawne _rzd_sklad zostaje nietknięte.
function rzd_set_product_sklad( $product_id, $ids ) {
	$ids = array_values( array_unique( array_filter( array_map( 'absint', (array) $ids ) ) ) );
	$ids = array_values( array_filter( $ids, function ( $id ) { return (bool) rzd_get_addon( $id ); } ) );
	update_post_meta( $product_id, '_rzd_sklad_addons', $ids );
}

/**
 * Pierwszy dodatek danego typu w składzie (null = brak). Zakładamy najwyżej
 * jeden dodatek danego typu w składzie jednego dania.
 */
function rzd_find_ingredient_by_type( $product_id, $type_id ) {
	return rzd_find_in_sklad_by_type( rzd_get_product_sklad( $product_id ), $type_id );
}
function rzd_find_in_sklad_by_type( $sklad, $type_id ) {
	if ( ! $type_id ) {
		return null;
	}
	foreach ( (array) $sklad as $i ) {
		if ( (int) $i['type_id'] === (int) $type_id ) {
			return $i;
		}
	}
	return null;
}

/**
 * Nazwa produktu + (jeśli zdefiniowany) skład mniejszą czcionką pod spodem.
 * Bez zdefiniowanego składu – sama nazwa, bez zmian. Używane wszędzie tam,
 * gdzie dotąd pokazywaliśmy samą nazwę produktu (lista, kuchnia, koszyk…).
 */
function rzd_product_name_with_sklad_html( $product_id, $name ) {
	$sklad = rzd_get_product_sklad( $product_id );
	if ( ! $sklad ) {
		return esc_html( $name );
	}
	$names = array_map( function ( $i ) { return esc_html( $i['name'] ); }, $sklad );
	return esc_html( $name ) . '<br><span class="rzd-sklad-note">' . implode( ', ', $names ) . '</span>';
}

function rzd_get_all_addons() {
	$posts = get_posts( array(
		'post_type'      => 'rzd_addon',
		'post_status'    => 'publish',
		'numberposts'    => -1,
		'orderby'        => 'title',
		'order'          => 'ASC',
	) );
	$out = array();
	foreach ( $posts as $p ) {
		$out[] = rzd_get_addon( $p->ID );
	}
	return $out;
}

/* ============================================================
 * 3. PRZENIESIENIE dawnych Składników do Dodatków (jednorazowo, 2.32.0)
 * ============================================================
 * Składnik → dodatek o tej samej nazwie I tym samym typie (jeśli jest), inaczej
 * nowy dodatek (wartości 0 – nic nie dolicza; cenę dokładki ustawia się potem).
 * Typów istniejących dodatków NIE zmieniamy (zmieniłoby to działanie modyfikacji).
 * Skład produktu → nowe pole _rzd_sklad_addons; _rzd_sklad i składniki zostają
 * w bazie bez zmian (powrót do 2.31.0). Raport: opcja rzd_skl_report (komunikat w panelu).
 */
function rzd_skl_norm( $s ) {
	$s = trim( preg_replace( '/\s+/u', ' ', (string) $s ) );
	return function_exists( 'mb_strtolower' ) ? mb_strtolower( $s, 'UTF-8' ) : strtolower( $s );
}

function rzd_skl_migrate( $force = false ) {
	if ( ! $force && (int) get_option( 'rzd_skl_v' ) >= 2 ) {
		return;
	}
	$type_of = function ( $id ) {
		$t = wp_get_object_terms( $id, 'rzd_addon_type', array( 'fields' => 'ids' ) );
		return ( ! is_wp_error( $t ) && $t ) ? (int) $t[0] : 0;
	};
	$addons = array(); // klucz: nazwa|typ → ID
	$names  = array(); // nazwa → typy (do ostrzeżenia o duplikatach)
	foreach ( get_posts( array( 'post_type' => 'rzd_addon', 'post_status' => 'publish', 'numberposts' => -1, 'fields' => 'ids', 'orderby' => 'ID', 'order' => 'ASC' ) ) as $aid ) {
		$k = rzd_skl_norm( get_the_title( $aid ) ) . '|' . $type_of( $aid );
		if ( ! isset( $addons[ $k ] ) ) {
			$addons[ $k ] = (int) $aid;
		}
		$names[ rzd_skl_norm( get_the_title( $aid ) ) ][ $type_of( $aid ) ] = true;
	}
	$map    = get_option( 'rzd_skl_map', array() );
	$report = array( 'reused' => array(), 'created' => array(), 'same_name' => array(), 'products' => 0 );
	foreach ( get_posts( array( 'post_type' => 'rzd_ingredient', 'post_status' => array( 'publish', 'draft', 'private' ), 'numberposts' => -1, 'fields' => 'ids', 'orderby' => 'ID', 'order' => 'ASC' ) ) as $iid ) {
		$title = get_the_title( $iid );
		$type  = $type_of( $iid );
		$k     = rzd_skl_norm( $title ) . '|' . $type;
		if ( isset( $map[ (int) $iid ] ) && get_post( $map[ (int) $iid ] ) ) {
			continue;
		}
		if ( isset( $addons[ $k ] ) ) {
			$map[ (int) $iid ]   = $addons[ $k ];
			$report['reused'][]  = $title;
		} else {
			$aid = wp_insert_post( array( 'post_type' => 'rzd_addon', 'post_title' => $title, 'post_status' => 'publish' ) );
			if ( ! $aid || is_wp_error( $aid ) ) {
				continue;
			}
			update_post_meta( $aid, '_rzd_addon_price', 0 );
			update_post_meta( $aid, '_rzd_addon_price_minus', 0 );
			update_post_meta( $aid, '_rzd_from_ingredient', (int) $iid );
			if ( $type ) {
				wp_set_object_terms( $aid, array( $type ), 'rzd_addon_type', false );
			}
			$addons[ $k ]       = (int) $aid;
			$map[ (int) $iid ]  = (int) $aid;
			$report['created'][] = $title;
			if ( isset( $names[ rzd_skl_norm( $title ) ] ) ) {
				$report['same_name'][] = $title; // jest już dodatek o tej nazwie, ale z innym typem
			}
			$names[ rzd_skl_norm( $title ) ][ $type ] = true;
		}
	}
	update_option( 'rzd_skl_map', $map, false );
	global $wpdb;
	foreach ( $wpdb->get_col( "SELECT DISTINCT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_rzd_sklad'" ) as $pid ) {
		if ( metadata_exists( 'post', (int) $pid, '_rzd_sklad_addons' ) ) {
			continue;
		}
		$old = get_post_meta( (int) $pid, '_rzd_sklad', true );
		$new = array();
		foreach ( is_array( $old ) ? $old : array() as $iid ) {
			if ( isset( $map[ (int) $iid ] ) ) {
				$new[] = (int) $map[ (int) $iid ];
			}
		}
		update_post_meta( (int) $pid, '_rzd_sklad_addons', array_values( array_unique( $new ) ) );
		$report['products']++;
	}
	update_option( 'rzd_skl_v', 2, false );
	if ( $report['reused'] || $report['created'] || $report['products'] ) {
		update_option( 'rzd_skl_report', $report, false );
	}
}
add_action( 'init', function () {
	if ( (int) get_option( 'rzd_skl_v' ) < 2 ) {
		rzd_skl_migrate();
	}
}, 30 );

// Jednorazowy komunikat w panelu: co przeniesiono (do przejrzenia), „Ukryj” kasuje raport.
add_action( 'admin_notices', function () {
	$r = get_option( 'rzd_skl_report' );
	if ( ! $r || ! current_user_can( 'manage_woocommerce' ) ) {
		return;
	}
	if ( isset( $_GET['rzd_skl_ok'] ) && check_admin_referer( 'rzd_skl_ok' ) ) {
		delete_option( 'rzd_skl_report' );
		return;
	}
	$li = function ( $a ) { return $a ? esc_html( implode( ', ', array_unique( $a ) ) ) : '—'; };
	echo '<div class="notice notice-info"><p><strong>Restauracja: Składniki są teraz Dodatkami (jeden katalog).</strong> Przeniesiono skład ' . (int) $r['products'] . ' produktów.</p>';
	echo '<p>Połączone z istniejącym dodatkiem (ta sama nazwa i typ): ' . $li( $r['reused'] ) . '<br>Nowe dodatki (z ceną 0 zł – ustaw cenę, jeśli ma być dokładka): ' . $li( $r['created'] ) . '</p>';
	if ( $r['same_name'] ) {
		echo '<p><strong>Uwaga:</strong> te nazwy są teraz w Dodatkach dwa razy (z różnym typem) – w listach wyboru widać typ w nawiasie [ ]: ' . $li( $r['same_name'] ) . '</p>';
	}
	echo '<p><a class="button" href="' . esc_url( function_exists( 'rzd_panel_url' ) ? rzd_panel_url( 'menu' ) : admin_url() ) . '">Otwórz Dodatki</a> <a class="button" href="' . esc_url( wp_nonce_url( add_query_arg( 'rzd_skl_ok', 1 ), 'rzd_skl_ok' ) ) . '">Ukryj komunikat</a></p></div>';
} );

/* ============================================================
 * 4. SKŁAD PO WYBORZE KLIENTA
 * ============================================================
 * Skład dania $src po wyborach klienta z $raw (zaznaczenia z okna, jak rzd_raw
 * w pozycji koszyka) w modyfikacjach PRZED dodaniem do koszyka:
 *  - wybór „jedno z kilku” z rolą neutralna/dodaje → zastępuje dodatek tego samego
 *    typu albo się dopisuje (dodatek bez typu – dopisuje się, chyba że już jest);
 *  - wybór z rolą odejmuje/dezaktywuje („Bez dodatku”) i przycisk „Bez …” →
 *    usuwa dodatek tego samego typu / ten sam dodatek.
 * Zwraca [ 'items' => [ dodatki ], 'removed' => [ dodatki lub [name,type_id] ] ].
 */
function rzd_effective_sklad( $product_id, $src, $raw ) {
	$items   = rzd_get_product_sklad( $src );
	$removed = array();
	$groups  = function_exists( 'rzd_get_modifier_groups' ) ? rzd_get_modifier_groups( $product_id ) : array();
	foreach ( $groups as $gi => $g ) {
		if ( ( isset( $g['_src'] ) ? (int) $g['_src'] : (int) $product_id ) !== (int) $src || 'cart' === rzd_group_place( $g ) ) {
			continue;
		}
		$val = isset( $raw[ $gi ]['val'] ) ? (string) $raw[ $gi ]['val'] : '';
		if ( '' === $val ) {
			continue;
		}
		if ( 'radio' === $g['type'] ) {
			$opt = isset( $g['options'][ absint( $val ) ] ) ? $g['options'][ absint( $val ) ] : null;
			$a   = $opt ? rzd_get_addon( $opt['addon_id'] ) : null;
			if ( ! $a ) {
				continue;
			}
			$role = $opt['role'];
		} elseif ( 'tap' === $g['type'] && '1' === $val ) {
			$a    = rzd_get_addon( $g['addon_id'] );
			$role = $g['role'];
			if ( ! $a || ! in_array( $role, array( 'odejmuje', 'dezaktywuje' ), true ) ) {
				continue; // dopłacany przycisk przed koszykiem nie zmienia składu
			}
		} else {
			continue;
		}
		// który dodatek składu dotyczy: ten sam ID, inaczej ten sam typ
		$hit = -1;
		foreach ( $items as $k => $it ) {
			if ( (int) $it['id'] === (int) $a['id'] ) {
				$hit = $k;
				break;
			}
		}
		if ( -1 === $hit && $a['type_id'] ) {
			foreach ( $items as $k => $it ) {
				if ( (int) $it['type_id'] === (int) $a['type_id'] ) {
					$hit = $k;
					break;
				}
			}
		}
		if ( in_array( $role, array( 'odejmuje', 'dezaktywuje' ), true ) ) {
			if ( $hit >= 0 ) {
				$removed[] = $items[ $hit ];
				array_splice( $items, $hit, 1 );
			} else {
				$removed[] = $a;
			}
		} elseif ( $hit >= 0 ) {
			$items[ $hit ] = $a;
		} else {
			$items[] = $a;
		}
	}
	return array( 'items' => $items, 'removed' => $removed );
}

// Nazwy składu po wyborze (do „Zawiera już”, przeglądu).
function rzd_effective_sklad_names( $product_id, $src, $raw ) {
	return array_map( function ( $a ) { return $a['name']; }, rzd_effective_sklad( $product_id, $src, $raw )['items'] );
}
