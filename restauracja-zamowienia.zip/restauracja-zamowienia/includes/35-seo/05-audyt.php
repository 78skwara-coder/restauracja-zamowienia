<?php
/**
 * Moduł 35-seo – lista „do poprawy” (Panel restauracji → SEO → Do poprawy) i naprawy jednym kliknięciem:
 * widoczność dla wyszukiwarek (blog_public), alt zdjęć dań = nazwa dania.
 * Pozycja: { key, level error|warning|info|ok, text, count, items [ {name, url} ], fix { type tab|link|action, … } }.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function rzd_seo_dish_url( $pid ) {
	$u = function_exists( 'rzd_ed_page_url' ) ? rzd_ed_page_url() : '';
	return '' !== $u ? add_query_arg( 'danie', (int) $pid, $u ) : get_edit_post_link( $pid, 'raw' );
}

/** Dania widoczne w sklepie, których zdjęcie (główne) nie ma tekstu alternatywnego. */
function rzd_seo_products_missing_alt() {
	$out = array();
	foreach ( rzd_seo_visible_products() as $p ) {
		$img = (int) $p->get_image_id();
		if ( $img && '' === trim( (string) get_post_meta( $img, '_wp_attachment_image_alt', true ) ) ) {
			$out[ $img ] = $p;
		}
	}
	return $out;
}

/** Uzupełnia alt nazwą dania (tylko puste). Zwraca liczbę poprawionych zdjęć. */
function rzd_seo_fix_alt() {
	$n = 0;
	foreach ( rzd_seo_products_missing_alt() as $img => $p ) {
		update_post_meta( $img, '_wp_attachment_image_alt', sanitize_text_field( html_entity_decode( $p->get_name(), ENT_QUOTES, 'UTF-8' ) ) );
		++$n;
	}
	return $n;
}

function rzd_seo_audit() {
	$s    = rzd_seo_settings();
	$out  = array();
	$item = function ( $p ) {
		return array( 'name' => html_entity_decode( $p->get_name(), ENT_QUOTES, 'UTF-8' ), 'url' => rzd_seo_dish_url( $p->get_id() ) );
	};
	if ( ! get_option( 'blog_public' ) ) {
		$out[] = array( 'key' => 'public', 'level' => 'error', 'text' => 'Strona jest UKRYTA przed wyszukiwarkami (WordPress: Ustawienia → Czytanie → „Proś wyszukiwarki o nieindeksowanie”). Google nie pokaże sklepu.', 'fix' => array( 'type' => 'action', 'action' => 'seo_public', 'label' => 'Odkryj stronę dla wyszukiwarek' ) );
	}
	$plugin = rzd_seo_plugin();
	if ( '' !== $plugin ) {
		$out[] = array( 'key' => 'plugin', 'level' => 'info', 'text' => 'Działa wtyczka ' . $plugin . ' – ona ustawia tytuły, opisy, udostępnianie (Open Graph), kody weryfikacji i mapę witryny. Tu zostają: wizytówka restauracji, menu dla Google, ukrycie stron obsługi i ta lista.' );
	}
	if ( 'separate' === $s['mode'] ) {
		if ( '' === $s['snippet_hash'] ) {
			$out[] = array( 'key' => 'snippet', 'level' => 'warning', 'text' => 'Wizytówka restauracji jest na stronie głównej (' . $s['main_url'] . ') – skopiuj kod z zakładki Wizytówka i wklej go w <head> strony głównej.', 'fix' => array( 'type' => 'tab', 'tab' => 'wizytowka', 'label' => 'Pokaż kod' ) );
		} elseif ( rzd_seo_snippet_stale() ) {
			$out[] = array( 'key' => 'snippet', 'level' => 'warning', 'text' => 'Kod wizytówki na stronie głównej jest nieaktualny (zmieniły się dane: godziny, miejscowości, adres…) – skopiuj go ponownie.', 'fix' => array( 'type' => 'tab', 'tab' => 'wizytowka', 'label' => 'Pokaż kod' ) );
		}
	}
	if ( ! rzd_seo_card_ready() ) {
		$out[] = array( 'key' => 'card', 'level' => 'warning', 'text' => 'Wizytówka restauracji niepełna – Google nie dostaje adresu ani obszaru dostaw.', 'fix' => array( 'type' => 'tab', 'tab' => 'wizytowka', 'label' => 'Uzupełnij' ) );
	} else {
		$miss = array();
		if ( '' === $s['phone'] ) {
			$miss[] = 'telefon';
		}
		$any = false;
		foreach ( $s['hours'] as $h ) {
			$any = $any || ( empty( $h['c'] ) && '' !== $h['from'] );
		}
		if ( ! $any ) {
			$miss[] = 'godziny otwarcia';
		}
		if ( '' === $s['street'] . $s['city'] ) {
			$miss[] = 'adres';
		}
		if ( $miss ) {
			$out[] = array( 'key' => 'card2', 'level' => 'warning', 'text' => 'W wizytówce brakuje: ' . implode( ', ', $miss ) . '.', 'fix' => array( 'type' => 'tab', 'tab' => 'wizytowka', 'label' => 'Uzupełnij' ) );
		}
	}
	if ( ! rzd_seo_logo_id() ) {
		$out[] = array( 'key' => 'logo', 'level' => 'warning', 'text' => 'Brak logo (ani w motywie, ani w wizytówce).', 'fix' => array( 'type' => 'tab', 'tab' => 'wizytowka', 'label' => 'Dodaj logo' ) );
	}
	if ( '' === $plugin && ! $s['og_image_id'] ) {
		$out[] = array( 'key' => 'og', 'level' => 'info', 'text' => 'Brak obrazka do udostępniania – link do strony głównej i listy dań pokaże na Facebooku logo albo nic.', 'fix' => array( 'type' => 'tab', 'tab' => 'udostepnianie', 'label' => 'Dodaj obrazek' ) );
	}
	if ( '' === rzd_seo_list_url() ) {
		$out[] = array( 'key' => 'list', 'level' => 'warning', 'text' => 'Nie ma opublikowanej strony z listą dań [lista_zamowien] – Google nie dostanie menu ani przycisku „Zamów online”.' );
	}
	$prods = rzd_seo_visible_products();
	$nodesc = array_values( array_filter( $prods, function ( $p ) {
		return '' === trim( wp_strip_all_tags( $p->get_short_description() . $p->get_description() ) );
	} ) );
	if ( $nodesc ) {
		$out[] = array( 'key' => 'desc', 'level' => 'warning', 'text' => 'Dania bez opisu (' . count( $nodesc ) . ') – Google i klient nie wiedzą, co to jest.', 'count' => count( $nodesc ), 'items' => array_map( $item, array_slice( $nodesc, 0, 15 ) ) );
	}
	$noimg = array_values( array_filter( $prods, function ( $p ) {
		return ! $p->get_image_id();
	} ) );
	if ( $noimg ) {
		$out[] = array( 'key' => 'img', 'level' => 'warning', 'text' => 'Dania bez zdjęcia (' . count( $noimg ) . ').', 'count' => count( $noimg ), 'items' => array_map( $item, array_slice( $noimg, 0, 15 ) ) );
	}
	$noalt = rzd_seo_products_missing_alt();
	if ( $noalt ) {
		$out[] = array( 'key' => 'alt', 'level' => 'info', 'text' => 'Zdjęcia dań bez tekstu alternatywnego (' . count( $noalt ) . ') – opis dla wyszukiwarki grafiki i czytników ekranu.', 'count' => count( $noalt ), 'items' => array_map( $item, array_slice( array_values( $noalt ), 0, 15 ) ), 'fix' => array( 'type' => 'action', 'action' => 'seo_fix_alt', 'label' => 'Uzupełnij nazwą dania' ) );
	}
	$names = array();
	foreach ( $prods as $p ) {
		$names[ mb_strtolower( trim( $p->get_name() ) ) ][] = $p;
	}
	$dups = array();
	foreach ( $names as $list ) {
		if ( count( $list ) > 1 ) {
			$dups = array_merge( $dups, $list );
		}
	}
	if ( $dups ) {
		$out[] = array( 'key' => 'dup', 'level' => 'info', 'text' => 'Dania o tej samej nazwie (' . count( $dups ) . ') – dla Google to „ta sama strona dwa razy”; warto je rozróżnić (np. „Pierogi ruskie – 10 szt.”).', 'count' => count( $dups ), 'items' => array_map( $item, array_slice( $dups, 0, 15 ) ) );
	}
	$hidden = rzd_seo_hidden_cat_ids();
	$cats   = array();
	foreach ( get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => true ) ) as $t ) {
		if ( ! in_array( (int) $t->term_id, $hidden, true ) && 'uncategorized' !== $t->slug && '' === trim( wp_strip_all_tags( $t->description ) ) ) {
			$cats[] = array( 'name' => html_entity_decode( $t->name, ENT_QUOTES, 'UTF-8' ), 'url' => function_exists( 'rzd_ed_page_url' ) ? rzd_ed_page_url() : '' );
		}
	}
	if ( $cats ) {
		$out[] = array( 'key' => 'cats', 'level' => 'info', 'text' => 'Kategorie bez opisu (' . count( $cats ) . ') – opis kategorii to tekst strony kategorii w Google.', 'count' => count( $cats ), 'items' => array_slice( $cats, 0, 15 ) );
	}
	if ( ! array_filter( $out, function ( $x ) {
		return in_array( $x['level'], array( 'error', 'warning' ), true );
	} ) ) {
		array_unshift( $out, array( 'key' => 'ok', 'level' => 'ok', 'text' => 'Nic pilnego do poprawy.' ) );
	}
	return $out;
}
