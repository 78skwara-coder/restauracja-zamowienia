<?php
/**
 * MODUŁ 35: SEO (2.46.0) – dla każdej instalacji wtyczki, nie tylko jednej restauracji.
 *
 * Działa bez wypełniania: sprzątanie indeksu (02) i udostępnianie (04) od razu po instalacji;
 * wizytówka (03 – dane strukturalne schema.org) włącza się, gdy są nazwa i adres albo obszar dostaw.
 * Dwa układy: „main” – ta strona to główna strona restauracji (pełna wizytówka tutaj);
 * „separate” – sklep na osobnym adresie (np. subdomena), wizytówka na stronie głównej:
 * tutaj tylko odniesienie, a panel daje gotowy kod JSON-LD do wklejenia na stronę główną.
 * Przy wtyczce SEO (Yoast, Rank Math, All in One SEO, SEOPress) wyłączone są: Open Graph,
 * kody weryfikacji i zmiany mapy witryny – nie dublujemy znaczników.
 * Ustawienia: opcja `rzd_seo`. Ekran: Panel restauracji → SEO (moduł 34, 13-seo.php).
 *
 * Części: 01-dane (ustawienia, wykrywanie, strony), 02-indeks (noindex, mapa witryny, weryfikacja),
 * 03-schema (JSON-LD), 04-og (Open Graph), 05-audyt (lista „do poprawy”).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function rzd_seo_days() {
	return array( 'Mon' => 'Monday', 'Tue' => 'Tuesday', 'Wed' => 'Wednesday', 'Thu' => 'Thursday', 'Fri' => 'Friday', 'Sat' => 'Saturday', 'Sun' => 'Sunday' );
}

/** Rodzaje lokalu → typ schema.org. */
function rzd_seo_types() {
	return array(
		'Restaurant'          => 'Restauracja',
		'FastFoodRestaurant'  => 'Bar szybkiej obsługi',
		'CafeOrCoffeeShop'    => 'Kawiarnia',
		'Bakery'              => 'Piekarnia / cukiernia',
		'BarOrPub'            => 'Pub / bar',
		'FoodEstablishment'   => 'Inny lokal gastronomiczny (np. catering)',
	);
}

function rzd_seo_defaults() {
	$hours = array();
	foreach ( array_keys( rzd_seo_days() ) as $d ) {
		$hours[ $d ] = array( 'c' => 0, 'from' => '', 'to' => '' );
	}
	$country = function_exists( 'WC' ) && WC()->countries ? WC()->countries->get_base_country() : 'PL';
	return array(
		'mode'         => 'main',     // main | separate
		'main_url'     => '',         // separate: adres strony głównej
		'type'         => 'Restaurant',
		'name'         => '',         // puste = nazwa strony
		'desc'         => '',
		'street'       => '',
		'postcode'     => '',
		'city'         => '',
		'country'      => $country ? $country : 'PL',
		'phone'        => '',
		'email'        => '',
		'cuisine'      => '',         // np. „polska, domowa”
		'price'        => '',         // np. „20–50 zł”
		'logo_id'      => 0,          // 0 = logo motywu
		'image_id'     => 0,
		'hours'        => $hours,
		'same_as'      => '',         // profile – jeden adres w linii
		'reservations' => 0,
		'og_image_id'  => 0,
		'og_desc'      => '',
		'verify_google' => '',
		'verify_bing'  => '',
		'snippet_hash' => '',         // skrót kodu skopiowanego na stronę główną (przypomnienie o zmianach)
	);
}

function rzd_seo_settings() {
	$s = get_option( 'rzd_seo', array() );
	$s = wp_parse_args( is_array( $s ) ? $s : array(), rzd_seo_defaults() );
	$d = rzd_seo_defaults();
	$h = is_array( $s['hours'] ) ? $s['hours'] : array();
	foreach ( $d['hours'] as $k => $v ) {
		$s['hours'][ $k ] = isset( $h[ $k ] ) && is_array( $h[ $k ] ) ? wp_parse_args( $h[ $k ], $v ) : $v;
	}
	return $s;
}

function rzd_seo_hm( $v ) {
	$v = trim( (string) $v );
	return preg_match( '/^([01]?\d|2[0-3]):[0-5]\d$/', $v ) ? str_pad( $v, 5, '0', STR_PAD_LEFT ) : '';
}

/** Zapis z panelu (klucze jak w opcji). Zwraca zapisane ustawienia. */
function rzd_seo_save( $in ) {
	$in  = is_array( $in ) ? $in : array();
	$old = rzd_seo_settings();
	$d   = rzd_seo_defaults();
	$t   = function ( $k, $max = 200 ) use ( $in, $old ) {
		$v = isset( $in[ $k ] ) ? sanitize_text_field( (string) $in[ $k ] ) : $old[ $k ];
		return function_exists( 'mb_substr' ) ? mb_substr( $v, 0, $max ) : substr( $v, 0, $max );
	};
	$img = function ( $k ) use ( $in, $old ) {
		$id = isset( $in[ $k ] ) ? absint( $in[ $k ] ) : (int) $old[ $k ];
		return $id && wp_attachment_is_image( $id ) ? $id : 0;
	};
	$hours = array();
	$hin   = isset( $in['hours'] ) && is_array( $in['hours'] ) ? $in['hours'] : $old['hours'];
	foreach ( array_keys( rzd_seo_days() ) as $day ) {
		$r            = isset( $hin[ $day ] ) && is_array( $hin[ $day ] ) ? $hin[ $day ] : array();
		$hours[ $day ] = array( 'c' => empty( $r['c'] ) ? 0 : 1, 'from' => rzd_seo_hm( isset( $r['from'] ) ? $r['from'] : '' ), 'to' => rzd_seo_hm( isset( $r['to'] ) ? $r['to'] : '' ) );
	}
	$same = array();
	foreach ( preg_split( '/[\r\n,]+/', (string) ( isset( $in['same_as'] ) ? $in['same_as'] : $old['same_as'] ) ) as $u ) {
		$u = trim( $u );
		$u = preg_match( '#^https?://#i', $u ) ? esc_url_raw( $u, array( 'http', 'https' ) ) : ''; // tylko pełne adresy
		if ( '' !== $u ) {
			$same[] = $u;
		}
	}
	$email = isset( $in['email'] ) ? sanitize_email( (string) $in['email'] ) : $old['email'];
	$verify = function ( $k ) use ( $in, $old ) {
		$v = isset( $in[ $k ] ) ? (string) $in[ $k ] : $old[ $k ];
		if ( preg_match( '/content=["\']([^"\']+)["\']/', $v, $m ) ) {
			$v = $m[1]; // wklejono cały znacznik <meta …> – bierzemy samą wartość
		}
		return preg_replace( '/[^A-Za-z0-9_\-]/', '', $v );
	};
	$s = array(
		'mode'          => isset( $in['mode'] ) ? ( 'separate' === $in['mode'] ? 'separate' : 'main' ) : $old['mode'],
		'main_url'      => isset( $in['main_url'] ) ? esc_url_raw( trim( (string) $in['main_url'] ), array( 'http', 'https' ) ) : $old['main_url'],
		'type'          => isset( $in['type'] ) && isset( rzd_seo_types()[ $in['type'] ] ) ? $in['type'] : $old['type'],
		'name'          => $t( 'name', 120 ),
		'desc'          => isset( $in['desc'] ) ? sanitize_textarea_field( (string) $in['desc'] ) : $old['desc'],
		'street'        => $t( 'street' ),
		'postcode'      => $t( 'postcode', 12 ),
		'city'          => $t( 'city', 80 ),
		'country'       => isset( $in['country'] ) && preg_match( '/^[A-Za-z]{2}$/', (string) $in['country'] ) ? strtoupper( $in['country'] ) : $old['country'],
		'phone'         => isset( $in['phone'] ) ? preg_replace( '/[^0-9+ ()\-]/', '', (string) $in['phone'] ) : $old['phone'],
		'email'         => is_email( $email ) ? $email : '',
		'cuisine'       => $t( 'cuisine', 120 ),
		'price'         => $t( 'price', 40 ),
		'logo_id'       => $img( 'logo_id' ),
		'image_id'      => $img( 'image_id' ),
		'hours'         => $hours,
		'same_as'       => implode( "\n", array_unique( $same ) ),
		'reservations'  => isset( $in['reservations'] ) ? ( empty( $in['reservations'] ) ? 0 : 1 ) : (int) $old['reservations'],
		'og_image_id'   => $img( 'og_image_id' ),
		'og_desc'       => isset( $in['og_desc'] ) ? sanitize_textarea_field( (string) $in['og_desc'] ) : $old['og_desc'],
		'verify_google' => $verify( 'verify_google' ),
		'verify_bing'   => $verify( 'verify_bing' ),
		'snippet_hash'  => $old['snippet_hash'],
	);
	if ( 'separate' === $s['mode'] && '' === $s['main_url'] ) {
		$s['mode'] = 'main'; // bez adresu strony głównej układ „osobny sklep” nie ma sensu
	}
	update_option( 'rzd_seo', $s, true );
	return rzd_seo_settings();
}

/** Działająca wtyczka SEO (nazwa) albo ''. */
function rzd_seo_plugin() {
	$name = '';
	if ( defined( 'WPSEO_VERSION' ) ) {
		$name = 'Yoast SEO';
	} elseif ( defined( 'RANK_MATH_VERSION' ) || class_exists( 'RankMath' ) ) {
		$name = 'Rank Math';
	} elseif ( defined( 'AIOSEO_VERSION' ) || function_exists( 'aioseo' ) ) {
		$name = 'All in One SEO';
	} elseif ( defined( 'SEOPRESS_VERSION' ) ) {
		$name = 'SEOPress';
	}
	return (string) apply_filters( 'rzd_seo_plugin', $name );
}

function rzd_seo_name() {
	$s = rzd_seo_settings();
	return '' !== $s['name'] ? $s['name'] : html_entity_decode( get_bloginfo( 'name' ), ENT_QUOTES, 'UTF-8' );
}

/** Adres strony z listą dań ([lista_zamowien]) albo ''. */
function rzd_seo_list_url() {
	return function_exists( 'rzd_page_url_opt' ) ? rzd_page_url_opt( 'rzd_list_page_id', 'lista_zamowien' ) : '';
}
function rzd_seo_list_page_id() {
	return rzd_seo_list_url() ? (int) get_option( 'rzd_list_page_id' ) : 0;
}

/** Shortcode'y ekranów obsługi – te strony nie mają nic do szukania w Google. */
function rzd_seo_staff_shortcodes() {
	return array( 'kuchnia_dashboard', 'kurier_dashboard', 'edycja_produktow', 'rzd_sala', 'rzd_panel' );
}

/** Id stron obsługi (opublikowane strony z tymi shortcode'ami). */
function rzd_seo_staff_page_ids() {
	static $ids = null;
	if ( null !== $ids ) {
		return $ids;
	}
	$ids = get_transient( 'rzd_seo_staff_ids' );
	if ( is_array( $ids ) ) {
		return $ids;
	}
	$ids = array();
	foreach ( get_posts( array( 'post_type' => 'page', 'post_status' => 'publish', 'numberposts' => 200, 'fields' => 'ids' ) ) as $pid ) {
		$c = (string) get_post_field( 'post_content', $pid );
		foreach ( rzd_seo_staff_shortcodes() as $sc ) {
			if ( false !== strpos( $c, '[' . $sc ) && has_shortcode( $c, $sc ) ) {
				$ids[] = (int) $pid;
				break;
			}
		}
	}
	set_transient( 'rzd_seo_staff_ids', $ids, DAY_IN_SECONDS );
	return $ids;
}
add_action( 'save_post_page', function () {
	delete_transient( 'rzd_seo_staff_ids' );
} );

function rzd_seo_is_staff_page() {
	if ( is_admin() || ! is_singular( 'page' ) ) {
		return false;
	}
	$p = get_post();
	if ( ! $p ) {
		return false;
	}
	foreach ( rzd_seo_staff_shortcodes() as $sc ) {
		if ( has_shortcode( (string) $p->post_content, $sc ) ) {
			return true;
		}
	}
	return false;
}

/** Danie poza sprzedażą online: kategoria „Nie wyświetlaj w sklepie” albo „tylko na miejscu” (sala). */
function rzd_seo_hidden_product( $pid ) {
	if ( function_exists( 'rzd_zestaw_product_in_hidden_category' ) && rzd_zestaw_product_in_hidden_category( $pid ) ) {
		return true;
	}
	return function_exists( 'rzd_product_sell' ) && 'onsite' === rzd_product_sell( $pid );
}

function rzd_seo_hidden_cat_ids() {
	$out = array();
	// meta_query (nie meta_key/meta_value – przy fields=ids WordPress je pomija, zob. 2.43.1)
	foreach ( get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false, 'fields' => 'ids', 'meta_query' => array( array( 'key' => 'rwz_hide_in_shop', 'value' => '1' ) ) ) ) as $id ) { // phpcs:ignore
		$out[] = (int) $id;
	}
	return $out;
}

/** Dania widoczne w sklepie (do menu w Google i do listy „do poprawy”). */
function rzd_seo_visible_products( $limit = 400 ) {
	if ( ! function_exists( 'wc_get_products' ) ) {
		return array();
	}
	$out = array();
	foreach ( wc_get_products( array( 'status' => 'publish', 'limit' => $limit, 'visibility' => 'catalog', 'orderby' => 'title', 'order' => 'ASC' ) ) as $p ) {
		if ( '' !== (string) $p->get_post_password() || rzd_seo_hidden_product( $p->get_id() ) ) {
			continue;
		}
		$out[] = $p;
	}
	return $out;
}

function rzd_seo_logo_id() {
	$s = rzd_seo_settings();
	return $s['logo_id'] ? (int) $s['logo_id'] : (int) get_theme_mod( 'custom_logo' );
}

/** Wizytówka gotowa: nazwa + (adres albo obszar dostaw). Układ „separate” – jest adres strony głównej. */
function rzd_seo_card_ready() {
	$s = rzd_seo_settings();
	$towns = function_exists( 'rzd_towns' ) ? rzd_towns() : array();
	return ( '' !== trim( $s['street'] . $s['city'] ) || $towns ) && '' !== rzd_seo_name();
}
