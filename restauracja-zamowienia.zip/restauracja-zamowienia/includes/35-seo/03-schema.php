<?php
/**
 * Moduł 35-seo – dane strukturalne (schema.org, JSON-LD w <head>).
 *
 * Układ „main”: na każdej stronie sklepu wizytówka restauracji (typ z ustawień, @id …/#restaurant) +
 * WebSite; na stronie z listą dań – Menu (sekcje = kategorie, pozycje = dania z ceną).
 * Układ „separate”: tutaj WebSite sklepu z odniesieniem do restauracji na stronie głównej (@id
 * <adres głównej>#restaurant) i Menu na liście dań; pełna wizytówka – rzd_seo_snippet() do wklejenia
 * na stronę główną (z „Zamów online” → lista dań w sklepie).
 * Strony dań: dane produktu wysyła WooCommerce – nie dublujemy.
 * Pomijane: strony obsługi, koszyk, kasa, konto (tam nie ma czego opisywać).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function rzd_seo_restaurant_id( $s = null ) {
	$s = $s ? $s : rzd_seo_settings();
	$base = 'separate' === $s['mode'] && '' !== $s['main_url'] ? $s['main_url'] : home_url( '/' );
	return trailingslashit( $base ) . '#restaurant';
}

function rzd_seo_img( $id, $size = 'large' ) {
	$u = $id ? wp_get_attachment_image_url( (int) $id, $size ) : '';
	return $u ? $u : '';
}

/** Pełna wizytówka restauracji (tablica JSON-LD bez @context). */
function rzd_seo_restaurant_node() {
	$s    = rzd_seo_settings();
	$main = 'separate' === $s['mode'] && '' !== $s['main_url'] ? $s['main_url'] : home_url( '/' );
	$list = rzd_seo_list_url();
	$n    = array(
		'@type' => $s['type'],
		'@id'   => rzd_seo_restaurant_id( $s ),
		'name'  => rzd_seo_name(),
		'url'   => $main,
	);
	if ( '' !== $s['desc'] ) {
		$n['description'] = $s['desc'];
	}
	if ( '' !== trim( $s['street'] . $s['city'] ) ) {
		$n['address'] = array_filter( array(
			'@type'           => 'PostalAddress',
			'streetAddress'   => $s['street'],
			'postalCode'      => $s['postcode'],
			'addressLocality' => $s['city'],
			'addressCountry'  => $s['country'],
		) );
	}
	if ( '' !== $s['phone'] ) {
		$n['telephone'] = $s['phone'];
	}
	if ( '' !== $s['email'] ) {
		$n['email'] = $s['email'];
	}
	$logo = rzd_seo_img( rzd_seo_logo_id(), 'full' );
	if ( $logo ) {
		$n['logo'] = $logo;
	}
	$img = rzd_seo_img( $s['image_id'] ? $s['image_id'] : ( $s['og_image_id'] ? $s['og_image_id'] : rzd_seo_logo_id() ), 'full' );
	if ( $img ) {
		$n['image'] = $img;
	}
	if ( '' !== $s['cuisine'] ) {
		$n['servesCuisine'] = array_values( array_filter( array_map( 'trim', explode( ',', $s['cuisine'] ) ) ) );
	}
	if ( '' !== $s['price'] ) {
		$n['priceRange'] = $s['price'];
	}
	$hours = array();
	foreach ( rzd_seo_days() as $k => $day ) {
		$h = $s['hours'][ $k ];
		if ( empty( $h['c'] ) && '' !== $h['from'] && '' !== $h['to'] ) {
			$hours[] = array( '@type' => 'OpeningHoursSpecification', 'dayOfWeek' => 'https://schema.org/' . $day, 'opens' => $h['from'], 'closes' => $h['to'] );
		}
	}
	if ( $hours ) {
		$n['openingHoursSpecification'] = $hours;
	}
	$area = array();
	foreach ( function_exists( 'rzd_towns' ) ? rzd_towns() : array() as $t ) {
		if ( ! empty( $t['name'] ) ) {
			$area[] = array( '@type' => 'City', 'name' => (string) $t['name'] );
		}
	}
	if ( $area ) {
		$n['areaServed'] = $area;
	}
	$n['acceptsReservations'] = ! empty( $s['reservations'] );
	$same = array_values( array_filter( array_map( 'trim', explode( "\n", (string) $s['same_as'] ) ) ) );
	if ( $same ) {
		$n['sameAs'] = $same;
	}
	if ( '' !== $list ) {
		$n['hasMenu']         = $list;
		$n['potentialAction'] = array(
			'@type'  => 'OrderAction',
			'target' => array(
				'@type'          => 'EntryPoint',
				'urlTemplate'    => $list,
				'inLanguage'     => str_replace( '_', '-', get_locale() ),
				'actionPlatform' => array( 'https://schema.org/DesktopWebPlatform', 'https://schema.org/MobileWebPlatform' ),
			),
			'deliveryMethod' => array( 'http://purl.org/goodrelations/v1#DeliveryModeOwnFleet' ),
		);
	}
	return $n;
}

/** Menu z dań widocznych w sklepie: sekcje = kategorie (kolejność kafli), pozycje z ceną. */
function rzd_seo_menu_node() {
	$list = rzd_seo_list_url();
	if ( '' === $list ) {
		return null;
	}
	$key = 'rzd_seo_menu_' . md5( RZD_PLUGIN_VERSION . '|' . (int) get_option( 'rzd_seo_menu_v' ) . '|' . get_lastpostmodified( 'gmt', 'product' ) . '|' . $list . '|' . get_woocommerce_currency() );
	$c   = get_transient( $key );
	if ( is_array( $c ) ) {
		return $c;
	}
	$hidden = rzd_seo_hidden_cat_ids();
	$secs   = array();
	$order  = array();
	foreach ( rzd_seo_visible_products() as $p ) {
		$cat = null;
		foreach ( wp_get_post_terms( $p->get_id(), 'product_cat' ) as $t ) {
			if ( ! in_array( (int) $t->term_id, $hidden, true ) ) {
				$cat = $t;
				break;
			}
		}
		$cid  = $cat ? (int) $cat->term_id : 0;
		$item = array( '@type' => 'MenuItem', 'name' => html_entity_decode( $p->get_name(), ENT_QUOTES, 'UTF-8' ) );
		$desc = trim( wp_strip_all_tags( $p->get_short_description() ? $p->get_short_description() : $p->get_description() ) );
		if ( '' !== $desc ) {
			$item['description'] = wp_html_excerpt( $desc, 300, '…' );
		}
		$img = rzd_seo_img( $p->get_image_id() );
		if ( $img ) {
			$item['image'] = $img;
		}
		$price = $p->is_type( 'variable' ) ? $p->get_variation_price( 'min' ) : $p->get_price();
		if ( '' !== (string) $price ) {
			$item['offers'] = array( '@type' => 'Offer', 'price' => wc_format_decimal( $price, wc_get_price_decimals() ), 'priceCurrency' => get_woocommerce_currency() );
		}
		if ( ! isset( $secs[ $cid ] ) ) {
			$secs[ $cid ]  = array( '@type' => 'MenuSection', 'name' => $cat ? html_entity_decode( $cat->name, ENT_QUOTES, 'UTF-8' ) : 'Menu', 'hasMenuItem' => array() );
			$order[ $cid ] = $cat;
		}
		$secs[ $cid ]['hasMenuItem'][] = $item;
	}
	if ( ! $secs ) {
		return null;
	}
	$terms = array_filter( $order );
	if ( $terms && function_exists( 'rzd_kategorie_sort' ) ) {
		$terms = rzd_kategorie_sort( array_values( $terms ) );
	}
	$sorted = array();
	foreach ( $terms as $t ) {
		$sorted[] = $secs[ (int) $t->term_id ];
	}
	if ( isset( $secs[0] ) ) {
		$sorted[] = $secs[0];
	}
	$node = array( '@type' => 'Menu', '@id' => trailingslashit( $list ) . '#menu', 'name' => 'Menu – ' . rzd_seo_name(), 'url' => $list, 'inLanguage' => str_replace( '_', '-', get_locale() ), 'hasMenuSection' => $sorted );
	set_transient( $key, $node, 6 * HOUR_IN_SECONDS );
	return $node;
}

// Menu w pamięci (transient) – nowa wersja po zmianie dania (zdjęcie, cena, opis, kategoria), także z Edycji menu.
function rzd_seo_menu_bump() {
	update_option( 'rzd_seo_menu_v', (int) get_option( 'rzd_seo_menu_v' ) + 1, true );
}
add_action( 'save_post_product', 'rzd_seo_menu_bump' );
add_action( 'edited_product_cat', 'rzd_seo_menu_bump' );
foreach ( array( 'added_post_meta', 'updated_post_meta', 'deleted_post_meta' ) as $rzd_seo_h ) {
	add_action( $rzd_seo_h, function ( $mid, $pid, $key ) {
		if ( in_array( $key, array( '_thumbnail_id', '_price', '_regular_price', '_sale_price' ), true ) && 'product' === get_post_type( $pid ) ) {
			rzd_seo_menu_bump();
		}
	}, 10, 3 );
}
foreach ( array( 'added_term_meta', 'updated_term_meta', 'deleted_term_meta' ) as $rzd_seo_h ) {
	add_action( $rzd_seo_h, function ( $mid, $tid, $key ) {
		if ( in_array( $key, array( 'rwz_hide_in_shop', 'rzd_sell', 'rzd_kategoria_order' ), true ) ) {
			rzd_seo_menu_bump(); // ukrycie kategorii, „tylko na miejscu”, kolejność sekcji
		}
	}, 10, 3 );
}

/** Graf dla bieżącej strony albo null. */
function rzd_seo_graph() {
	if ( is_admin() || is_404() || rzd_seo_is_staff_page() || ( function_exists( 'is_cart' ) && ( is_cart() || is_checkout() || is_account_page() ) ) ) {
		return null;
	}
	$s     = rzd_seo_settings();
	$graph = array();
	$rid   = rzd_seo_restaurant_id( $s );
	$ready = rzd_seo_card_ready();
	if ( 'main' === $s['mode'] ) {
		if ( $ready ) {
			$graph[] = rzd_seo_restaurant_node();
		}
	} else {
		$graph[] = array( '@type' => $s['type'], '@id' => $rid, 'name' => rzd_seo_name(), 'url' => $s['main_url'] ); // odniesienie – pełna wizytówka na stronie głównej
	}
	$site = array( '@type' => 'WebSite', '@id' => home_url( '/#website' ), 'url' => home_url( '/' ), 'name' => html_entity_decode( get_bloginfo( 'name' ), ENT_QUOTES, 'UTF-8' ), 'inLanguage' => str_replace( '_', '-', get_locale() ) );
	if ( $ready || 'separate' === $s['mode'] ) {
		$site['publisher'] = array( '@id' => $rid );
	}
	$graph[] = $site;
	$lid = rzd_seo_list_page_id();
	if ( $lid && is_page( $lid ) ) {
		$menu = rzd_seo_menu_node();
		if ( $menu ) {
			$graph[] = $menu;
		}
	}
	return array( '@context' => 'https://schema.org', '@graph' => $graph );
}

function rzd_seo_json( $data ) {
	return wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP );
}

add_action( 'wp_head', function () {
	$g = rzd_seo_graph();
	if ( $g ) {
		echo '<script type="application/ld+json" class="rzd-seo-schema">' . rzd_seo_json( $g ) . "</script>\n"; // JSON_HEX_TAG – bez „</script>” w treści
	}
}, 30 );

/** Kod wizytówki do wklejenia na stronę główną (układ „separate”). */
function rzd_seo_snippet() {
	$n = array_merge( array( '@context' => 'https://schema.org' ), rzd_seo_restaurant_node() );
	return '<script type="application/ld+json">' . "\n" . wp_json_encode( $n, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_PRETTY_PRINT ) . "\n</script>";
}
function rzd_seo_snippet_hash() {
	return substr( md5( rzd_seo_snippet() ), 0, 12 );
}
/** Kod na stronie głównej nieaktualny (skopiowano, potem zmieniły się dane). */
function rzd_seo_snippet_stale() {
	$s = rzd_seo_settings();
	return 'separate' === $s['mode'] && '' !== $s['snippet_hash'] && $s['snippet_hash'] !== rzd_seo_snippet_hash();
}
