<?php
/**
 * Moduł 35-seo – indeksowanie: noindex stron obsługi (meta robots + nagłówek X-Robots-Tag – działa też
 * przy wtyczkach SEO, które wymieniają meta robots), noindex dań poza sprzedażą online, mapa witryny
 * WordPressa bez nich (i bez ukrytych kategorii), kody weryfikacji Google / Bing.
 * Koszyk, kasa, konto – noindex daje sam WooCommerce (wc_page_noindex).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Co robić z bieżącą stroną: '' | 'staff' (noindex,nofollow) | 'hidden' (noindex,follow). */
function rzd_seo_robots_kind() {
	if ( rzd_seo_is_staff_page() ) {
		return 'staff';
	}
	if ( function_exists( 'is_product' ) && is_product() && rzd_seo_hidden_product( get_queried_object_id() ) ) {
		return 'hidden';
	}
	if ( function_exists( 'is_product_category' ) && is_product_category() && in_array( get_queried_object_id(), rzd_seo_hidden_cat_ids(), true ) ) {
		return 'hidden';
	}
	return '';
}

add_filter( 'wp_robots', function ( $robots ) {
	$k = rzd_seo_robots_kind();
	if ( 'staff' === $k ) {
		return array( 'noindex' => true, 'nofollow' => true );
	}
	if ( 'hidden' === $k ) {
		unset( $robots['max-image-preview'] );
		$robots['noindex'] = true;
		if ( empty( $robots['nofollow'] ) ) {
			$robots['follow'] = true; // linki z dania (np. do zestawu) – dalej liczą się
		}
	}
	return $robots;
}, 20 );

// Nagłówek HTTP – niezależny od motywu i wtyczek SEO (Google traktuje go jak meta robots).
add_action( 'template_redirect', function () {
	$k = rzd_seo_robots_kind();
	if ( '' !== $k && ! headers_sent() ) {
		header( 'X-Robots-Tag: ' . ( 'staff' === $k ? 'noindex, nofollow' : 'noindex, follow' ), true );
	}
}, 1 );

// Wtyczki SEO z własnym meta robots.
add_filter( 'wpseo_robots', function ( $r ) {
	$k = rzd_seo_robots_kind();
	return '' === $k ? $r : ( 'staff' === $k ? 'noindex, nofollow' : 'noindex, follow' );
} );
add_filter( 'rank_math/frontend/robots', function ( $r ) {
	$k = rzd_seo_robots_kind();
	if ( '' !== $k ) {
		$r['index']  = 'noindex';
		$r['follow'] = 'staff' === $k ? 'nofollow' : 'follow';
	}
	return $r;
} );

/* ---------- mapa witryny WordPressa (wp-sitemap.xml) ---------- */
function rzd_seo_hidden_product_ids() {
	static $ids = null;
	if ( null !== $ids ) {
		return $ids;
	}
	$ids = array();
	if ( function_exists( 'wc_get_products' ) ) {
		foreach ( wc_get_products( array( 'status' => 'publish', 'limit' => 1000, 'return' => 'ids' ) ) as $pid ) {
			if ( rzd_seo_hidden_product( $pid ) ) {
				$ids[] = (int) $pid;
			}
		}
	}
	return $ids;
}

add_filter( 'wp_sitemaps_posts_query_args', function ( $args, $post_type ) {
	$ex = array();
	if ( 'page' === $post_type ) {
		$ex = rzd_seo_staff_page_ids();
		foreach ( array( 'cart', 'checkout', 'myaccount' ) as $wp ) { // WooCommerce daje im noindex – w mapie też ich nie chcemy
			$id = function_exists( 'wc_get_page_id' ) ? (int) wc_get_page_id( $wp ) : 0;
			if ( $id > 0 ) {
				$ex[] = $id;
			}
		}
	} elseif ( 'product' === $post_type ) {
		$ex = rzd_seo_hidden_product_ids();
	}
	if ( $ex ) {
		$args['post__not_in'] = array_merge( isset( $args['post__not_in'] ) ? (array) $args['post__not_in'] : array(), $ex );
	}
	return $args;
}, 10, 2 );

add_filter( 'wp_sitemaps_taxonomies_query_args', function ( $args, $tax ) {
	if ( 'product_cat' === $tax && rzd_seo_hidden_cat_ids() ) {
		$args['exclude'] = array_merge( isset( $args['exclude'] ) ? (array) $args['exclude'] : array(), rzd_seo_hidden_cat_ids() );
	}
	return $args;
}, 10, 2 );

// Yoast ma własną mapę – też bez stron obsługi i ukrytych dań.
add_filter( 'wpseo_exclude_from_sitemap_by_post_ids', function ( $ids ) {
	return array_values( array_unique( array_merge( (array) $ids, rzd_seo_staff_page_ids(), rzd_seo_hidden_product_ids() ) ) );
} );

/* ---------- kody weryfikacji (tylko bez wtyczki SEO – ona ma swoje pole) ---------- */
add_action( 'wp_head', function () {
	if ( '' !== rzd_seo_plugin() || is_admin() ) {
		return;
	}
	$s = rzd_seo_settings();
	if ( '' !== $s['verify_google'] ) {
		echo '<meta name="google-site-verification" content="' . esc_attr( $s['verify_google'] ) . '">' . "\n";
	}
	if ( '' !== $s['verify_bing'] ) {
		echo '<meta name="msvalidate.01" content="' . esc_attr( $s['verify_bing'] ) . '">' . "\n";
	}
}, 2 );
