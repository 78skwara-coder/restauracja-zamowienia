<?php
/**
 * Moduł 35-seo – udostępnianie (Open Graph + karta Twittera/X): jak wygląda link wklejony na Facebooka.
 * Danie – zdjęcie, nazwa, cena; zestaw – zdjęcie dzisiejszego dania (pierwszego ze zdjęciem); kategoria –
 * zdjęcie kafla; strona główna i lista – opis i obrazek z ustawień. Tylko gdy NIE działa wtyczka SEO
 * (ona robi to sama – nie dublujemy znaczników).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Zdjęcie zestawu: dzisiejsze danie główne ze zdjęciem (gdy brak – zdjęcie samego produktu). */
function rzd_seo_set_image_id( $pid ) {
	if ( function_exists( 'rzd_zestaw_is_set_product' ) && rzd_zestaw_is_set_product( $pid ) && function_exists( 'rzd_zestaw_get_active_components' ) ) {
		$c     = rzd_zestaw_get_active_components( $pid );
		$first = 0;
		foreach ( array_merge( array_values( (array) $c['main'] ), array_values( (array) $c['addon'] ) ) as $cp ) {
			$id = is_object( $cp ) ? (int) $cp->get_image_id() : 0;
			if ( ! $id ) {
				continue;
			}
			if ( ! empty( $c['roles'][ $cp->get_id() ]['photo'] ) ) {
				return $id; // danie zaznaczone „Zdjęcie” w zestawie
			}
			$first = $first ? $first : $id;
		}
		if ( $first ) {
			return $first;
		}
	}
	return (int) get_post_thumbnail_id( $pid );
}

/** Dane karty dla bieżącej strony: [ type, title, desc, url, image_id, price ] albo null. */
function rzd_seo_og_data() {
	if ( is_admin() || is_404() || rzd_seo_is_staff_page() ) {
		return null;
	}
	$s    = rzd_seo_settings();
	$site = html_entity_decode( get_bloginfo( 'name' ), ENT_QUOTES, 'UTF-8' );
	$d    = array(
		'type'  => 'website',
		'title' => $site,
		'desc'  => '' !== $s['og_desc'] ? $s['og_desc'] : html_entity_decode( get_bloginfo( 'description' ), ENT_QUOTES, 'UTF-8' ),
		'url'   => home_url( '/' ),
		'img'   => (int) ( $s['og_image_id'] ? $s['og_image_id'] : rzd_seo_logo_id() ),
		'price' => '',
	);
	$lid = rzd_seo_list_page_id();
	if ( function_exists( 'is_product' ) && is_product() ) {
		$p = wc_get_product( get_queried_object_id() );
		if ( $p ) {
			$d['type']  = 'product';
			$d['title'] = html_entity_decode( $p->get_name(), ENT_QUOTES, 'UTF-8' );
			$desc       = trim( wp_strip_all_tags( $p->get_short_description() ? $p->get_short_description() : $p->get_description() ) );
			$d['desc']  = '' !== $desc ? wp_html_excerpt( $desc, 200, '…' ) : $d['desc'];
			$d['url']   = get_permalink( $p->get_id() );
			$img        = rzd_seo_set_image_id( $p->get_id() );
			$d['img']   = $img ? $img : $d['img'];
			$d['price'] = (string) $p->get_price();
		}
	} elseif ( function_exists( 'is_product_category' ) && is_product_category() ) {
		$t = get_queried_object();
		$d['title'] = html_entity_decode( $t->name, ENT_QUOTES, 'UTF-8' ) . ' – ' . $site;
		$desc       = trim( wp_strip_all_tags( term_description( $t->term_id ) ) );
		$d['desc']  = '' !== $desc ? wp_html_excerpt( $desc, 200, '…' ) : $d['desc'];
		$d['url']   = get_term_link( $t );
		$img        = (int) get_term_meta( $t->term_id, 'thumbnail_id', true );
		$d['img']   = $img ? $img : $d['img'];
	} elseif ( is_singular() && ! is_front_page() ) {
		$post       = get_post();
		$d['title'] = html_entity_decode( get_the_title( $post ), ENT_QUOTES, 'UTF-8' ) . ( $lid && (int) $post->ID === $lid ? ' – ' . $site : '' );
		$ex         = has_excerpt( $post ) ? trim( wp_strip_all_tags( get_the_excerpt( $post ) ) ) : '';
		$d['desc']  = '' !== $ex ? $ex : $d['desc'];
		$d['url']   = get_permalink( $post );
		$img        = (int) get_post_thumbnail_id( $post );
		$d['img']   = $img ? $img : $d['img'];
	}
	return $d;
}

add_action( 'wp_head', function () {
	if ( '' !== rzd_seo_plugin() ) {
		return;
	}
	$d = rzd_seo_og_data();
	if ( ! $d ) {
		return;
	}
	$m = array(
		'og:type'      => $d['type'],
		'og:site_name' => html_entity_decode( get_bloginfo( 'name' ), ENT_QUOTES, 'UTF-8' ),
		'og:locale'    => get_locale(),
		'og:title'     => $d['title'],
		'og:description' => $d['desc'],
		'og:url'       => $d['url'],
	);
	$src = $d['img'] ? wp_get_attachment_image_src( $d['img'], 'large' ) : null;
	if ( $src ) {
		$m['og:image']        = $src[0];
		$m['og:image:width']  = (string) $src[1];
		$m['og:image:height'] = (string) $src[2];
		$alt                  = (string) get_post_meta( $d['img'], '_wp_attachment_image_alt', true );
		if ( '' !== $alt ) {
			$m['og:image:alt'] = $alt;
		}
	}
	if ( '' !== $d['price'] && function_exists( 'get_woocommerce_currency' ) ) {
		$m['product:price:amount']   = wc_format_decimal( $d['price'], wc_get_price_decimals() );
		$m['product:price:currency'] = get_woocommerce_currency();
	}
	echo "<!-- Restauracja: udostępnianie (Open Graph) -->\n";
	foreach ( $m as $k => $v ) {
		if ( '' !== (string) $v ) {
			echo '<meta property="' . esc_attr( $k ) . '" content="' . esc_attr( $v ) . '">' . "\n";
		}
	}
	echo '<meta name="twitter:card" content="' . ( $src ? 'summary_large_image' : 'summary' ) . '">' . "\n";
	if ( '' !== rzd_seo_settings()['og_desc'] && ! ( function_exists( 'is_product' ) && is_product() ) && ( is_front_page() || ( rzd_seo_list_page_id() && is_page( rzd_seo_list_page_id() ) ) ) ) {
		echo '<meta name="description" content="' . esc_attr( $d['desc'] ) . '">' . "\n"; // opis w Google: strona główna i lista dań
	}
}, 5 );
