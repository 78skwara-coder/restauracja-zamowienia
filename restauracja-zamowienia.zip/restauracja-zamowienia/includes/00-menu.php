<?php
/**
 * MODUŁ 00-menu: jedno menu wtyczki w panelu – „Restauracja” z podstronami.
 *
 * Całe menu rejestrowane TU, w jednej kolejności; strony (funkcje wyświetlające) zostają
 * w swoich modułach. Adresy stron (?page=…, edit.php?post_type=…) są te same co przed 2.33.0 –
 * zakładki i linki działają dalej. Każda podstrona ma swoje uprawnienie; kto nie ma dostępu
 * do Kuchni, a ma do innej podstrony, dostaje menu prowadzące do pierwszej dostępnej
 * (mechanizm WordPressa). Nazwa menu – jedna stała (zmiana nazwy = jedna linia).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'RZD_MENU_TITLE' ) ) {
	define( 'RZD_MENU_TITLE', 'Restauracja' );
}
// Adres menu głównego = Kuchnia (pierwsza podstrona). Ten sam co przed 2.33.0.
define( 'RZD_MENU_SLUG', 'rzd-kuchnia' );

// Uprawnienie do listy typu treści / taksonomii (jak ustawił WordPress przy rejestracji).
function rzd_menu_cap_pt( $pt ) {
	$o = get_post_type_object( $pt );
	return $o ? $o->cap->edit_posts : 'edit_posts';
}
function rzd_menu_cap_tax( $tax ) {
	$o = get_taxonomy( $tax );
	return $o ? $o->cap->manage_terms : 'manage_categories';
}

// Podstrony w kolejności. [ tytuł strony, nazwa w menu, uprawnienie, adres, funkcja ]
function rzd_menu_items() {
	return array(
		array( 'Kuchnia', 'Kuchnia', 'manage_woocommerce', 'rzd-kuchnia', 'rzd_kuchnia_render_page' ),
		array( 'Kurier', 'Kurier', 'rzd_p_courier', 'rzd-kurier', 'rzd_kurier_admin_page' ),
		array( 'Zestawy dnia', 'Zestawy dnia', 'manage_woocommerce', 'rzd-zestawy', 'rzd_render_zestawy_page' ),
		array( 'Dodatki', 'Dodatki', rzd_menu_cap_pt( 'rzd_addon' ), 'edit.php?post_type=rzd_addon', null ),
		array( 'Typy dodatków', 'Typy dodatków', rzd_menu_cap_tax( 'rzd_addon_type' ), 'edit-tags.php?taxonomy=rzd_addon_type&post_type=rzd_addon', null ),
		array( 'Wzory modyfikacji', 'Wzory modyfikacji', rzd_menu_cap_pt( 'rzd_mod_preset' ), 'edit.php?post_type=rzd_mod_preset', null ),
		array( 'Opakowania', 'Opakowania', rzd_menu_cap_pt( 'rzd_packaging' ), 'edit.php?post_type=rzd_packaging', null ),
		array( 'Etykiety na zestawie', 'Etykiety na zestawie', rzd_menu_cap_tax( 'rzd_set_label' ), 'edit-tags.php?taxonomy=rzd_set_label&post_type=product', null ),
		array( 'Terminy', 'Terminy', 'rzd_p_settings', 'delivery-calendar', 'rzd_dc_render_admin_page' ),
		array( 'Miejscowości dostaw', 'Miejscowości', 'rzd_p_settings', 'rzd-towns', 'rzd_towns_admin_page' ),
		array( 'Koszyk', 'Koszyk', 'rzd_p_settings', 'kc-koszyk', 'rzd_koszyk_render_admin_page' ),
		array( 'Wygląd listy', 'Wygląd listy', 'rzd_p_settings', 'rzd-wyglad-listy', 'rzd_render_style_page' ),
		array( 'Raporty', 'Raporty', 'rzd_p_reports', 'rr-raporty', 'rzd_raport_render_admin_page' ),
	);
}

add_action( 'admin_menu', function () {
	add_menu_page( RZD_MENU_TITLE, RZD_MENU_TITLE, 'manage_woocommerce', RZD_MENU_SLUG, 'rzd_kuchnia_render_page', 'dashicons-food', 3 );
	foreach ( rzd_menu_items() as $it ) {
		add_submenu_page( RZD_MENU_SLUG, $it[0], $it[1], $it[2], $it[3], $it[4] ? $it[4] : '' );
	}
} );

// Czy to strona wtyczki o adresie ?page=$slug (nazwa hooka zależy od menu – tu nie).
function rzd_is_admin_page( $hook, $slug ) {
	$end = '_page_' . $slug;
	return is_string( $hook ) && substr( $hook, -strlen( $end ) ) === $end;
}

// Podświetlenie „Restauracja” na listach i ekranach edycji Dodatków, Wzorów, Opakowań i taksonomii.
add_filter( 'parent_file', function ( $parent ) {
	global $submenu_file;
	$s = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( ! $s ) {
		return $parent;
	}
	if ( 'edit-tags' === $s->base || 'term' === $s->base ) {
		if ( in_array( $s->taxonomy, array( 'rzd_addon_type', 'rzd_set_label' ), true ) ) {
			$submenu_file = 'rzd_addon_type' === $s->taxonomy ? 'edit-tags.php?taxonomy=rzd_addon_type&post_type=rzd_addon' : 'edit-tags.php?taxonomy=rzd_set_label&post_type=product'; // phpcs:ignore
			return RZD_MENU_SLUG;
		}
		return $parent;
	}
	if ( in_array( $s->post_type, array( 'rzd_addon', 'rzd_mod_preset', 'rzd_packaging' ), true ) && in_array( $s->base, array( 'edit', 'post' ), true ) ) {
		$submenu_file = 'edit.php?post_type=' . $s->post_type; // phpcs:ignore
		return RZD_MENU_SLUG;
	}
	return $parent;
} );
