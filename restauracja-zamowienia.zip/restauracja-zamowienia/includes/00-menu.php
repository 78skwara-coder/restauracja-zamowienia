<?php
/**
 * MODUŁ 00-menu: jedno menu wtyczki w panelu – „Restauracja” z podstronami.
 *
 * Całe menu rejestrowane TU, w jednej kolejności; strony (funkcje wyświetlające) zostają
 * w swoich modułach. Adresy stron (?page=…, edit.php?post_type=…) są te same co przed 2.33.0 –
 * zakładki i linki działają dalej. Każda podstrona ma swoje uprawnienie; kto nie ma dostępu
 * do Kuchni, a ma do innej podstrony, dostaje menu prowadzące do pierwszej dostępnej
 * (mechanizm WordPressa). Nazwa menu – jedna stała (zmiana nazwy = jedna linia).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'RZD_MENU_TITLE' ) ) {
	define( 'RZD_MENU_TITLE', 'Restauracja' );
}
// Adres menu głównego = Kuchnia (pierwsza podstrona). Ten sam co przed 2.33.0.
define( 'RZD_MENU_SLUG', 'rzd-kuchnia' );

// Uprawnienie do listy typu treści / taksonomii (jak ustawił WordPress przy rejestracji).
function rzd_menu_cap_pt( $pt ) {
	$o = get_post_type_object( $pt );
	return $o ? $o->cap->edit_posts : 'edit_posts';
}
function rzd_menu_cap_tax( $tax ) {
	$o = get_taxonomy( $tax );
	return $o ? $o->cap->manage_terms : 'manage_categories';
}

// Podstrony w kolejności. [ tytuł strony, nazwa w menu, uprawnienie, adres, funkcja ]
function rzd_menu_items() {
	$items = array(
		array( 'Kuchnia', 'Kuchnia', 'manage_woocommerce', 'rzd-kuchnia', 'rzd_kuchnia_render_page' ),
		array( 'Kurier', 'Kurier', 'rzd_p_courier', 'rzd-kurier', 'rzd_kurier_admin_page' ),
		// tylko Administrator: dane serwera poczty (zmiana = przejęcie maili, np. resetu hasła)
		array( 'Stan i poczta', 'Stan i poczta', 'manage_options', 'rzd-stan', 'rzd_stan_page' ),
	);
	// 2.44.0: ustawienia przenoszone do Panelu restauracji (moduł 34) – tu tylko wejście do niego
	// (z licznikiem nowych wiadomości). Miejscowości, Sala, Wiadomości, Raporty (2.44.0) oraz Terminy,
	// Zestawy, Dodatki, Typy dodatków, Wzory, Opakowania, Etykiety, Koszyk, Formularz zamówienia, Wygląd listy,
	// Menu strony, Formularze kontaktowe i Użytkownicy → Uprawnienia (2.45.0) są już tylko w panelu.
	if ( function_exists( 'rzd_panel_can' ) && rzd_panel_can() ) {
		$new = (int) get_option( 'rzd_kf_new' );
		// na początek listy przy rejestracji (pozycja 0) – Kuchnia musi być dodana pierwsza (ten sam adres co
		// „Restauracja”), inaczej WordPress dokłada zdublowaną pozycję „Restauracja”
		$items[] = array( 'Panel restauracji', 'Panel restauracji' . ( $new > 0 && function_exists( 'rzd_kf_can' ) && rzd_kf_can() ? ' <span class="awaiting-mod">' . $new . '</span>' : '' ), 'read', 'rzd-panel', 'rzd_panel_admin_page', 0 );
	}
	return $items;
}

add_action( 'admin_menu', function () {
	add_menu_page( RZD_MENU_TITLE, RZD_MENU_TITLE, 'manage_woocommerce', RZD_MENU_SLUG, 'rzd_kuchnia_render_page', 'dashicons-food', 3 );
	foreach ( rzd_menu_items() as $it ) {
		add_submenu_page( RZD_MENU_SLUG, $it[0], $it[1], $it[2], $it[3], $it[4] ? $it[4] : '', isset( $it[5] ) ? $it[5] : null );
	}
} );

// Czy to strona wtyczki o adresie ?page=$slug (nazwa hooka zależy od menu – tu nie).
function rzd_is_admin_page( $hook, $slug ) {
	$end = '_page_' . $slug;
	return is_string( $hook ) && substr( $hook, -strlen( $end ) ) === $end;
}

// Podświetlenie „Restauracja” na listach i ekranach edycji Dodatków, Wzorów, Opakowań i taksonomii.
add_filter( 'parent_file', function ( $parent ) {
	global $submenu_file;
	$s = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( ! $s ) {
		return $parent;
	}
	if ( 'edit-tags' === $s->base || 'term' === $s->base ) {
		if ( in_array( $s->taxonomy, array( 'rzd_addon_type', 'rzd_set_label' ), true ) ) {
			$submenu_file = 'rzd_addon_type' === $s->taxonomy ? 'edit-tags.php?taxonomy=rzd_addon_type&post_type=rzd_addon' : 'edit-tags.php?taxonomy=rzd_set_label&post_type=product'; // phpcs:ignore
			return RZD_MENU_SLUG;
		}
		return $parent;
	}
	if ( in_array( $s->post_type, array( 'rzd_addon', 'rzd_mod_preset', 'rzd_packaging' ), true ) && in_array( $s->base, array( 'edit', 'post' ), true ) ) {
		$submenu_file = 'edit.php?post_type=' . $s->post_type; // phpcs:ignore
		return RZD_MENU_SLUG;
	}
	return $parent;
} );
