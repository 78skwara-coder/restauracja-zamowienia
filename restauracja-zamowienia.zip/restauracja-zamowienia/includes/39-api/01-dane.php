<?php
/**
 * Moduł 39-api – Połączenia API (2.51.0): jedno miejsce na klucze i połączenia, z których korzystają różne funkcje
 * (Post dnia, Opisy AI). Opcja rzd_api (autoload no): gemini_key, fb_token – zaszyfrowane jak hasło poczty
 * (rzd_mail_encrypt), albo stałe RZD_GEMINI_KEY / RZD_FB_TOKEN w wp-config.php (mają pierwszeństwo); model, fb_page.
 * Przeniesienie: przy pierwszym odczycie (brak opcji) wartości kopiują się z ustawień postów (rzd_posts) – tam
 * zostają jako zapas na wypadek powrotu do starszej wersji, ale wtyczka czyta już tylko rzd_api.
 * Ustawienia postów (rzd_posts_settings) dostają te pola z rzd_api, więc kod postów działa bez zmian.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function rzd_api_fields() {
	return array( 'gemini_key', 'model', 'fb_page', 'fb_token' );
}

function rzd_api_settings( $reset = false ) {
	static $s = null;
	if ( $reset ) {
		$s = null;
	}
	if ( null !== $s ) {
		return $s;
	}
	$def = array_fill_keys( rzd_api_fields(), '' );
	$o   = get_option( 'rzd_api', null );
	if ( ! is_array( $o ) ) { // sprzed 2.51.0 – z ustawień postów
		$old = get_option( 'rzd_posts', array() );
		$o   = array();
		foreach ( rzd_api_fields() as $f ) {
			$o[ $f ] = is_array( $old ) && isset( $old[ $f ] ) ? (string) $old[ $f ] : '';
		}
		add_option( 'rzd_api', $o, '', false );
	}
	$s = array_merge( $def, array_intersect_key( $o, $def ) );
	return $s;
}

/** Sekret: stała w wp-config.php albo odszyfrowana wartość z bazy. */
function rzd_api_secret( $field ) {
	$const = array( 'gemini_key' => 'RZD_GEMINI_KEY', 'fb_token' => 'RZD_FB_TOKEN' );
	if ( isset( $const[ $field ] ) && defined( $const[ $field ] ) ) {
		return (string) constant( $const[ $field ] );
	}
	$s = rzd_api_settings();
	return isset( $s[ $field ] ) && function_exists( 'rzd_mail_decrypt' ) ? (string) rzd_mail_decrypt( (string) $s[ $field ] ) : '';
}

/** Zapis (częściowy – brak pola = bez zmian). Sekret pusty = bez zmian; „-” = usuń. [ ok, komunikat ]. */
function rzd_api_save( $in ) {
	$in = is_array( $in ) ? $in : array();
	$s  = rzd_api_settings();
	foreach ( array( 'gemini_key', 'fb_token' ) as $f ) {
		$v = isset( $in[ $f ] ) ? trim( (string) $in[ $f ] ) : '';
		if ( '-' === $v ) {
			$s[ $f ] = '';
		} elseif ( '' !== $v ) {
			$s[ $f ] = function_exists( 'rzd_mail_encrypt' ) ? rzd_mail_encrypt( $v ) : '';
		}
	}
	if ( isset( $in['model'] ) ) {
		$s['model'] = preg_replace( '/[^a-z0-9._\-\/]/i', '', (string) $in['model'] );
	}
	if ( isset( $in['fb_page'] ) ) {
		$s['fb_page'] = preg_replace( '/\D/', '', (string) $in['fb_page'] );
	}
	update_option( 'rzd_api', $s, false );
	rzd_api_settings( true );
	if ( function_exists( 'rzd_posts_settings' ) ) {
		rzd_posts_settings( true );
	}
	return array( true, 'Zapisano połączenia.' );
}

/** Stan połączeń – linia w Post dnia i kafelki w Połączeniach API. */
function rzd_api_status() {
	$s = rzd_api_settings();
	return array(
		'ai'      => '' !== rzd_api_secret( 'gemini_key' ) && '' !== $s['model'],
		'model'   => $s['model'],
		'fb'      => '' !== rzd_api_secret( 'fb_token' ) && '' !== $s['fb_page'],
		'fb_page' => $s['fb_page'],
	);
}
