<?php
/**
 * Moduł 39-api – Połączenia API (2.51.0): jedno miejsce na klucze i połączenia, z których korzystają różne funkcje
 * (Post dnia, Opisy AI). Opcja rzd_api (autoload no): gemini_key, fb_token – zaszyfrowane jak hasło poczty
 * (rzd_mail_encrypt), albo stałe RZD_GEMINI_KEY / RZD_FB_TOKEN w wp-config.php (mają pierwszeństwo); model, fb_page.
 * Przeniesienie: przy pierwszym odczycie (brak opcji) wartości kopiują się z ustawień postów (rzd_posts) – tam
 * zostają jako zapas na wypadek powrotu do starszej wersji, ale wtyczka czyta już tylko rzd_api.
 * Ustawienia postów (rzd_posts_settings) dostają te pola z rzd_api, więc kod postów działa bez zmian.
 * (2.53.0) Trzech dostawców AI: Gemini (gemini_key, model), Claude (claude_key, claude_model), OpenAI (openai_key,
 * openai_model); ai_default – domyślny (pusty = pierwszy skonfigurowany). Stałe RZD_CLAUDE_KEY / RZD_OPENAI_KEY.
 * Jedno „Generuj” = jedno zapytanie do JEDNEGO wybranego dostawcy (decyzja użytkownika – bez mnożenia kosztów).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function rzd_api_fields() {
	return array( 'gemini_key', 'model', 'fb_page', 'fb_token', 'claude_key', 'claude_model', 'openai_key', 'openai_model', 'ai_default', 'ig_id', 'ig_user', 'sms_token', 'sms_from', 'sms_test' ); // (2.55.0) ig_* – konto Instagram połączone ze stroną; (2.58.0) sms_* – SMSAPI
}

/** Dostawcy AI: klucz => [ nazwa, pole klucza, pole modelu ]. */
function rzd_ai_providers() {
	return array(
		'gemini' => array( 'Google Gemini', 'gemini_key', 'model' ),
		'claude' => array( 'Anthropic Claude', 'claude_key', 'claude_model' ),
		'openai' => array( 'OpenAI (ChatGPT)', 'openai_key', 'openai_model' ),
	);
}

/** Czy dostawca ma klucz i model. */
function rzd_ai_provider_ready( $p ) {
	$ps = rzd_ai_providers();
	return isset( $ps[ $p ] ) && '' !== rzd_api_secret( $ps[ $p ][1] ) && '' !== rzd_api_settings()[ $ps[ $p ][2] ];
}

/** Domyślny dostawca: ustawiony i skonfigurowany, inaczej pierwszy skonfigurowany ('' – żaden). */
function rzd_ai_default() {
	$d = rzd_api_settings()['ai_default'];
	if ( '' !== $d && rzd_ai_provider_ready( $d ) ) {
		return $d;
	}
	foreach ( array_keys( rzd_ai_providers() ) as $p ) {
		if ( rzd_ai_provider_ready( $p ) ) {
			return $p;
		}
	}
	return '';
}

/** Lista do pól wyboru „AI:” w narzędziach: [ {k, n, ready, model} ] + domyślny. */
function rzd_ai_choices() {
	$out = array();
	$s   = rzd_api_settings();
	foreach ( rzd_ai_providers() as $k => $p ) {
		$out[] = array( 'k' => $k, 'n' => $p[0], 'ready' => rzd_ai_provider_ready( $k ), 'model' => $s[ $p[2] ] );
	}
	return array( 'list' => $out, 'def' => rzd_ai_default() );
}

function rzd_api_settings( $reset = false ) {
	static $s = null;
	if ( $reset ) {
		$s = null;
	}
	if ( null !== $s ) {
		return $s;
	}
	$def = array_fill_keys( rzd_api_fields(), '' );
	$o   = get_option( 'rzd_api', null );
	if ( ! is_array( $o ) ) { // sprzed 2.51.0 – z ustawień postów
		$old = get_option( 'rzd_posts', array() );
		$o   = array();
		foreach ( rzd_api_fields() as $f ) {
			$o[ $f ] = is_array( $old ) && isset( $old[ $f ] ) ? (string) $old[ $f ] : '';
		}
		add_option( 'rzd_api', $o, '', false );
	}
	$s = array_merge( $def, array_intersect_key( $o, $def ) );
	return $s;
}

/** Sekret: stała w wp-config.php albo odszyfrowana wartość z bazy. */
function rzd_api_secret( $field ) {
	$const = array( 'gemini_key' => 'RZD_GEMINI_KEY', 'fb_token' => 'RZD_FB_TOKEN', 'claude_key' => 'RZD_CLAUDE_KEY', 'openai_key' => 'RZD_OPENAI_KEY', 'sms_token' => 'RZD_SMS_TOKEN' );
	if ( isset( $const[ $field ] ) && defined( $const[ $field ] ) ) {
		return (string) constant( $const[ $field ] );
	}
	$s = rzd_api_settings();
	return isset( $s[ $field ] ) && function_exists( 'rzd_mail_decrypt' ) ? (string) rzd_mail_decrypt( (string) $s[ $field ] ) : '';
}

/** Zapis (częściowy – brak pola = bez zmian). Sekret pusty = bez zmian; „-” = usuń. [ ok, komunikat ]. */
function rzd_api_save( $in ) {
	$in = is_array( $in ) ? $in : array();
	$s  = rzd_api_settings();
	foreach ( array( 'gemini_key', 'fb_token', 'claude_key', 'openai_key', 'sms_token' ) as $f ) {
		$v = isset( $in[ $f ] ) ? trim( (string) $in[ $f ] ) : '';
		if ( '-' === $v ) {
			$s[ $f ] = '';
		} elseif ( '' !== $v ) {
			$s[ $f ] = function_exists( 'rzd_mail_encrypt' ) ? rzd_mail_encrypt( $v ) : '';
		}
	}
	foreach ( array( 'model', 'claude_model', 'openai_model' ) as $f ) {
		if ( isset( $in[ $f ] ) ) {
			$s[ $f ] = preg_replace( '/[^a-z0-9._:\-\/]/i', '', (string) $in[ $f ] );
		}
	}
	if ( isset( $in['ai_default'] ) ) {
		$s['ai_default'] = isset( rzd_ai_providers()[ $in['ai_default'] ] ) ? (string) $in['ai_default'] : '';
	}
	if ( isset( $in['fb_page'] ) ) {
		$s['fb_page'] = preg_replace( '/\D/', '', (string) $in['fb_page'] );
	}
	if ( isset( $in['ig_id'] ) ) { // (2.55.0) z „Sprawdź Instagram” (strona → instagram_business_account)
		$s['ig_id'] = preg_replace( '/\D/', '', (string) $in['ig_id'] );
	}
	if ( isset( $in['sms_from'] ) ) { // (2.58.0) nazwa nadawcy SMS (zatwierdzona w SMSAPI), maks. 11 znaków
		$s['sms_from'] = substr( preg_replace( '/[^A-Za-z0-9 .\-]/', '', (string) $in['sms_from'] ), 0, 11 );
	}
	if ( isset( $in['sms_test'] ) ) {
		$s['sms_test'] = empty( $in['sms_test'] ) ? '' : '1';
	}
	if ( isset( $in['ig_user'] ) ) {
		$s['ig_user'] = preg_replace( '/[^a-z0-9._]/i', '', (string) $in['ig_user'] );
	}
	update_option( 'rzd_api', $s, false );
	rzd_api_settings( true );
	// (2.54.1) klucz zapisany, model pusty → model domyślny z listy dostawcy (Flash / Haiku / mini) – bez osobnego „Pobierz listę”
	$auto = array();
	foreach ( rzd_ai_providers() as $p => $d ) {
		if ( '' !== $s[ $d[2] ] || '' === rzd_api_secret( $d[1] ) ) {
			continue;
		}
		$m = rzd_ai_pick_model( $p );
		if ( '' !== $m ) {
			$s[ $d[2] ] = $m;
			$auto[]     = $d[0] . ' – ' . $m;
		}
	}
	if ( $auto ) {
		update_option( 'rzd_api', $s, false );
		rzd_api_settings( true );
	}
	if ( function_exists( 'rzd_posts_settings' ) ) {
		rzd_posts_settings( true );
	}
	return array( true, 'Zapisano połączenia.' . ( $auto ? ' Ustawiono model: ' . implode( '; ', $auto ) . ' (zmienisz w „Pobierz listę modeli”).' : '' ) );
}

/** (2.54.1) Model domyślny dostawcy z jego listy: Gemini – Flash, Claude – Haiku, OpenAI – mini (bez lite / preview / exp / nano). '' – lista niedostępna. */
function rzd_ai_pick_model( $p ) {
	$fn = array( 'gemini' => 'rzd_ai_gemini_models', 'claude' => 'rzd_ai_claude_models', 'openai' => 'rzd_ai_openai_models' );
	if ( ! isset( $fn[ $p ] ) || ! function_exists( $fn[ $p ] ) ) {
		return '';
	}
	list( $ok, $list ) = call_user_func( $fn[ $p ] );
	if ( ! $ok || ! $list ) {
		return '';
	}
	$re = array( 'gemini' => '/flash/i', 'claude' => '/haiku/i', 'openai' => '/mini/i' );
	foreach ( $list as $m ) {
		if ( preg_match( $re[ $p ], $m['id'] ) && ! preg_match( '/lite|preview|exp|nano/i', $m['id'] ) ) {
			return (string) $m['id'];
		}
	}
	return (string) $list[0]['id'];
}

/** (2.54.1) Czego brakuje dostawcy – dokładny komunikat ('' = gotowy). */
function rzd_ai_missing( $p ) {
	$ps = rzd_ai_providers();
	if ( ! isset( $ps[ $p ] ) ) {
		return 'Nieznany dostawca AI.';
	}
	if ( '' === rzd_api_secret( $ps[ $p ][1] ) ) {
		return $ps[ $p ][0] . ': brak klucza API – wklej klucz i kliknij „Zapisz połączenia”.';
	}
	if ( '' === rzd_api_settings()[ $ps[ $p ][2] ] ) {
		return $ps[ $p ][0] . ': klucz jest zapisany, ale nie wybrano modelu – kliknij „Pobierz listę modeli”, wybierz model i zapisz.';
	}
	return '';
}

/** Stan połączeń – linia w Post dnia i kafelki w Połączeniach API. */
function rzd_api_status() {
	$s = rzd_api_settings();
	return array(
		'ai'      => '' !== rzd_ai_default(),
		'model'   => '' !== rzd_ai_default() ? rzd_ai_providers()[ rzd_ai_default() ][0] . ' – ' . $s[ rzd_ai_providers()[ rzd_ai_default() ][2] ] : '',
		'fb'      => '' !== rzd_api_secret( 'fb_token' ) && '' !== $s['fb_page'],
		'fb_page' => $s['fb_page'],
		'ig'      => '' !== $s['ig_id'], // (2.55.0)
		'ig_user' => $s['ig_user'],
	);
}
