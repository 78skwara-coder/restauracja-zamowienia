<?php
/**
 * Moduł 39-api – Połączenia API (2.51.0): jedno miejsce na klucze i połączenia, z których korzystają różne funkcje
 * (Post dnia, Opisy AI). Opcja rzd_api (autoload no): gemini_key, fb_token – zaszyfrowane jak hasło poczty
 * (rzd_mail_encrypt), albo stałe RZD_GEMINI_KEY / RZD_FB_TOKEN w wp-config.php (mają pierwszeństwo); model, fb_page.
 * Przeniesienie: przy pierwszym odczycie (brak opcji) wartości kopiują się z ustawień postów (rzd_posts) – tam
 * zostają jako zapas na wypadek powrotu do starszej wersji, ale wtyczka czyta już tylko rzd_api.
 * Ustawienia postów (rzd_posts_settings) dostają te pola z rzd_api, więc kod postów działa bez zmian.
 * (2.53.0) Trzech dostawców AI: Gemini (gemini_key, model), Claude (claude_key, claude_model), OpenAI (openai_key,
 * openai_model); ai_default – domyślny (pusty = pierwszy skonfigurowany). Stałe RZD_CLAUDE_KEY / RZD_OPENAI_KEY.
 * Jedno „Generuj” = jedno zapytanie do JEDNEGO wybranego dostawcy (decyzja użytkownika – bez mnożenia kosztów).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function rzd_api_fields() {
	return array( 'gemini_key', 'model', 'fb_page', 'fb_token', 'claude_key', 'claude_model', 'openai_key', 'openai_model', 'ai_default' );
}

/** Dostawcy AI: klucz => [ nazwa, pole klucza, pole modelu ]. */
function rzd_ai_providers() {
	return array(
		'gemini' => array( 'Google Gemini', 'gemini_key', 'model' ),
		'claude' => array( 'Anthropic Claude', 'claude_key', 'claude_model' ),
		'openai' => array( 'OpenAI (ChatGPT)', 'openai_key', 'openai_model' ),
	);
}

/** Czy dostawca ma klucz i model. */
function rzd_ai_provider_ready( $p ) {
	$ps = rzd_ai_providers();
	return isset( $ps[ $p ] ) && '' !== rzd_api_secret( $ps[ $p ][1] ) && '' !== rzd_api_settings()[ $ps[ $p ][2] ];
}

/** Domyślny dostawca: ustawiony i skonfigurowany, inaczej pierwszy skonfigurowany ('' – żaden). */
function rzd_ai_default() {
	$d = rzd_api_settings()['ai_default'];
	if ( '' !== $d && rzd_ai_provider_ready( $d ) ) {
		return $d;
	}
	foreach ( array_keys( rzd_ai_providers() ) as $p ) {
		if ( rzd_ai_provider_ready( $p ) ) {
			return $p;
		}
	}
	return '';
}

/** Lista do pól wyboru „AI:” w narzędziach: [ {k, n, ready, model} ] + domyślny. */
function rzd_ai_choices() {
	$out = array();
	$s   = rzd_api_settings();
	foreach ( rzd_ai_providers() as $k => $p ) {
		$out[] = array( 'k' => $k, 'n' => $p[0], 'ready' => rzd_ai_provider_ready( $k ), 'model' => $s[ $p[2] ] );
	}
	return array( 'list' => $out, 'def' => rzd_ai_default() );
}

function rzd_api_settings( $reset = false ) {
	static $s = null;
	if ( $reset ) {
		$s = null;
	}
	if ( null !== $s ) {
		return $s;
	}
	$def = array_fill_keys( rzd_api_fields(), '' );
	$o   = get_option( 'rzd_api', null );
	if ( ! is_array( $o ) ) { // sprzed 2.51.0 – z ustawień postów
		$old = get_option( 'rzd_posts', array() );
		$o   = array();
		foreach ( rzd_api_fields() as $f ) {
			$o[ $f ] = is_array( $old ) && isset( $old[ $f ] ) ? (string) $old[ $f ] : '';
		}
		add_option( 'rzd_api', $o, '', false );
	}
	$s = array_merge( $def, array_intersect_key( $o, $def ) );
	return $s;
}

/** Sekret: stała w wp-config.php albo odszyfrowana wartość z bazy. */
function rzd_api_secret( $field ) {
	$const = array( 'gemini_key' => 'RZD_GEMINI_KEY', 'fb_token' => 'RZD_FB_TOKEN', 'claude_key' => 'RZD_CLAUDE_KEY', 'openai_key' => 'RZD_OPENAI_KEY' );
	if ( isset( $const[ $field ] ) && defined( $const[ $field ] ) ) {
		return (string) constant( $const[ $field ] );
	}
	$s = rzd_api_settings();
	return isset( $s[ $field ] ) && function_exists( 'rzd_mail_decrypt' ) ? (string) rzd_mail_decrypt( (string) $s[ $field ] ) : '';
}

/** Zapis (częściowy – brak pola = bez zmian). Sekret pusty = bez zmian; „-” = usuń. [ ok, komunikat ]. */
function rzd_api_save( $in ) {
	$in = is_array( $in ) ? $in : array();
	$s  = rzd_api_settings();
	foreach ( array( 'gemini_key', 'fb_token', 'claude_key', 'openai_key' ) as $f ) {
		$v = isset( $in[ $f ] ) ? trim( (string) $in[ $f ] ) : '';
		if ( '-' === $v ) {
			$s[ $f ] = '';
		} elseif ( '' !== $v ) {
			$s[ $f ] = function_exists( 'rzd_mail_encrypt' ) ? rzd_mail_encrypt( $v ) : '';
		}
	}
	foreach ( array( 'model', 'claude_model', 'openai_model' ) as $f ) {
		if ( isset( $in[ $f ] ) ) {
			$s[ $f ] = preg_replace( '/[^a-z0-9._:\-\/]/i', '', (string) $in[ $f ] );
		}
	}
	if ( isset( $in['ai_default'] ) ) {
		$s['ai_default'] = isset( rzd_ai_providers()[ $in['ai_default'] ] ) ? (string) $in['ai_default'] : '';
	}
	if ( isset( $in['fb_page'] ) ) {
		$s['fb_page'] = preg_replace( '/\D/', '', (string) $in['fb_page'] );
	}
	update_option( 'rzd_api', $s, false );
	rzd_api_settings( true );
	if ( function_exists( 'rzd_posts_settings' ) ) {
		rzd_posts_settings( true );
	}
	return array( true, 'Zapisano połączenia.' );
}

/** Stan połączeń – linia w Post dnia i kafelki w Połączeniach API. */
function rzd_api_status() {
	$s = rzd_api_settings();
	return array(
		'ai'      => '' !== rzd_ai_default(),
		'model'   => '' !== rzd_ai_default() ? rzd_ai_providers()[ rzd_ai_default() ][0] . ' – ' . $s[ rzd_ai_providers()[ rzd_ai_default() ][2] ] : '',
		'fb'      => '' !== rzd_api_secret( 'fb_token' ) && '' !== $s['fb_page'],
		'fb_page' => $s['fb_page'],
	);
}
