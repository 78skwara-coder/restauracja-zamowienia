<?php
/**
 * Moduł 39-api – Anthropic Claude (2.53.0): Messages API (POST /v1/messages, nagłówki x-api-key +
 * anthropic-version). Odpowiedź w schemacie JSON przez output_config.format (json_schema); gdy model / konto tego nie
 * przyjmie (400 o output_config / format) – drugi raz bez schematu, z prośbą o JSON w instrukcji. Temperatura odrzucona
 * przez model (400 o temperature) – ponowienie bez niej. Lista modeli: GET /v1/models. Adres – filtr rzd_ai_claude_base.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function rzd_ai_claude_base() {
	return apply_filters( 'rzd_ai_claude_base', 'https://api.anthropic.com/v1/' );
}

function rzd_ai_claude_headers( $key ) {
	return array( 'x-api-key' => $key, 'anthropic-version' => '2023-06-01', 'Content-Type' => 'application/json' );
}

/** Lista modeli: [ ok, [ {id, name} ] | komunikat ]. $key = null → zapisany klucz. */
function rzd_ai_claude_models( $key = null ) {
	$key = null === $key || '' === $key ? rzd_api_secret( 'claude_key' ) : $key;
	if ( '' === $key ) {
		return array( false, 'Wpisz klucz API Anthropic.' );
	}
	$r = wp_remote_get( rzd_ai_claude_base() . 'models?limit=100', array( 'timeout' => 20, 'headers' => rzd_ai_claude_headers( $key ) ) );
	if ( is_wp_error( $r ) ) {
		return array( false, 'Brak połączenia z Anthropic: ' . $r->get_error_message() );
	}
	$code = (int) wp_remote_retrieve_response_code( $r );
	$j    = json_decode( wp_remote_retrieve_body( $r ), true );
	if ( 200 !== $code ) {
		return array( false, rzd_ai_http_error( 'Anthropic', $code, isset( $j['error']['message'] ) ? (string) $j['error']['message'] : '', 'console.anthropic.com → Billing' ) );
	}
	$out = array();
	foreach ( isset( $j['data'] ) ? (array) $j['data'] : array() as $m ) {
		if ( ! empty( $m['id'] ) ) {
			$out[] = array( 'id' => (string) $m['id'], 'name' => ! empty( $m['display_name'] ) ? (string) $m['display_name'] : (string) $m['id'] );
		}
	}
	return $out ? array( true, $out ) : array( false, 'Anthropic nie zwrócił żadnego modelu.' );
}

function rzd_ai_claude_body( $model, $req, $schema, $temp ) {
	$content = array();
	foreach ( isset( $req['images'] ) ? (array) $req['images'] : array() as $im ) {
		$content[] = array( 'type' => 'image', 'source' => array( 'type' => 'base64', 'media_type' => $im['mime'], 'data' => $im['data'] ) );
	}
	$content[] = array( 'type' => 'text', 'text' => (string) $req['text'] );
	$system    = isset( $req['system'] ) ? trim( (string) $req['system'] ) : '';
	if ( ! empty( $req['keys'] ) && ! $schema ) {
		$system .= ( '' !== $system ? "\n\n" : '' ) . 'Odpowiedz wyłącznie obiektem JSON z kluczami: ' . implode( ', ', $req['keys'] ) . ' (wartości – tekst). Bez żadnego tekstu przed ani po JSON.';
	}
	$b = array( 'model' => $model, 'max_tokens' => 4096, 'messages' => array( array( 'role' => 'user', 'content' => $content ) ) );
	if ( ! empty( $req['web'] ) ) { // (2.54.0) wyszukiwarka Anthropic (narzędzie serwerowe), limit wyszukiwań
		$b['tools'] = array( array( 'type' => 'web_search_20250305', 'name' => 'web_search', 'max_uses' => (int) $req['web'] ) );
	}
	if ( ! empty( $req['cont'] ) ) { // pause_turn – dalszy ciąg tej samej tury
		$b['messages'][] = array( 'role' => 'assistant', 'content' => $req['cont'] );
	}
	if ( '' !== $system ) {
		$b['system'] = $system;
	}
	if ( $temp && isset( $req['temp'] ) ) {
		$b['temperature'] = min( 1, max( 0, (float) $req['temp'] ) );
	}
	if ( ! empty( $req['keys'] ) && $schema ) {
		$b['output_config'] = array( 'format' => array( 'type' => 'json_schema', 'schema' => rzd_ai_schema( $req['keys'] ) ) );
	}
	return $b;
}

/** Zapytanie: [ ok, tekst | komunikat ]; zapisuje „Ostatnie zapytanie” (z liczbą tokenów). */
function rzd_ai_claude_ask( $model, $key, $req, $what, $timeout = 0 ) {
	if ( function_exists( 'set_time_limit' ) ) {
		@set_time_limit( 200 ); // phpcs:ignore -- tam, gdzie hosting pozwala
	}
	$timeout = $timeout ? (int) $timeout : (int) apply_filters( 'rzd_posts_gemini_timeout', 150 );
	$t0      = microtime( true );
	$schema  = true;
	$temp    = true;
	$res     = array( false, 'Brak odpowiedzi z Anthropic.' );
	$usage   = null;
	$web     = 0;
	for ( $try = 0; $try < 5; $try++ ) {
		$r = wp_remote_post( rzd_ai_claude_base() . 'messages', array(
			'timeout' => $timeout,
			'headers' => rzd_ai_claude_headers( $key ),
			'body'    => wp_json_encode( rzd_ai_claude_body( $model, $req, $schema, $temp ) ),
		) );
		if ( is_wp_error( $r ) ) {
			$res = array( false, rzd_ai_wp_error_msg( 'Anthropic', $r ) );
			break;
		}
		$code = (int) wp_remote_retrieve_response_code( $r );
		$j    = json_decode( wp_remote_retrieve_body( $r ), true );
		$err  = isset( $j['error']['message'] ) ? (string) $j['error']['message'] : '';
		if ( 400 === $code && $schema && ! empty( $req['keys'] ) && preg_match( '/output_config|format|schema|structured/i', $err ) ) {
			$schema = false; // model bez structured outputs – JSON z instrukcji
			continue;
		}
		if ( 400 === $code && $temp && preg_match( '/temperature/i', $err ) ) {
			$temp = false;
			continue;
		}
		if ( 200 !== $code ) {
			$res = array( false, rzd_ai_http_error( 'Anthropic', $code, $err, 'console.anthropic.com → Billing' ) );
			break;
		}
		$txt = '';
		foreach ( isset( $j['content'] ) ? (array) $j['content'] : array() as $c ) {
			if ( isset( $c['type'] ) && 'web_search_tool_result' === $c['type'] ) {
				$txt = ''; // tekst sprzed wyszukiwania („Sprawdzę…”) – odpowiedź jest po ostatnim wyniku
			}
			if ( isset( $c['type'], $c['text'] ) && 'text' === $c['type'] ) {
				$txt .= (string) $c['text'];
			}
		}
		if ( isset( $j['usage'] ) ) {
			$web  += isset( $j['usage']['server_tool_use']['web_search_requests'] ) ? (int) $j['usage']['server_tool_use']['web_search_requests'] : 0;
			$usage = array(
				( $usage ? $usage[0] : 0 ) + ( isset( $j['usage']['input_tokens'] ) ? $j['usage']['input_tokens'] : 0 ),
				( $usage ? $usage[1] : 0 ) + ( isset( $j['usage']['output_tokens'] ) ? $j['usage']['output_tokens'] : 0 ),
				! empty( $req['web'] ) ? $web : null,
			);
		}
		$stop = isset( $j['stop_reason'] ) ? (string) $j['stop_reason'] : '';
		if ( 'pause_turn' === $stop && ! empty( $j['content'] ) ) { // wyszukiwanie w toku – kontynuacja
			$req['cont'] = $j['content'];
			continue;
		}
		if ( 'refusal' === $stop ) {
			$res = array( false, 'Claude odmówił odpowiedzi na to zapytanie. Zmień treść albo wybierz innego dostawcę.' );
		} elseif ( '' === trim( $txt ) ) {
			$res = array( false, 'Claude nie zwrócił tekstu' . ( 'max_tokens' === $stop ? ' (za długa odpowiedź)' : '' ) . '. Spróbuj ponownie.' );
		} else {
			$res = array( true, $txt );
		}
		break;
	}
	rzd_ai_log_call( 'claude', $model, $what, $t0, $schema ? 'Messages' : 'Messages, bez schematu', $res, $usage );
	return $res;
}
