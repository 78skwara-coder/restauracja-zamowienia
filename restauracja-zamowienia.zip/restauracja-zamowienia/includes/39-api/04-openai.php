<?php
/**
 * Moduł 39-api – OpenAI (ChatGPT) (2.53.0): Responses API (POST /v1/responses, Authorization: Bearer). Odpowiedź
 * w schemacie JSON: text.format = json_schema, strict. Modele „rozumujące” (gpt-5…, o…) dostają reasoning.effort =
 * low (krócej i taniej; ukryte tokeny „myślenia” są płatne jak wyjście); 400 o reasoning / temperature – ponowienie
 * bez tego parametru. Lista modeli: GET /v1/models, tylko modele tekstowe. Adres – filtr rzd_ai_openai_base.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function rzd_ai_openai_base() {
	return apply_filters( 'rzd_ai_openai_base', 'https://api.openai.com/v1/' );
}

function rzd_ai_openai_headers( $key ) {
	return array( 'Authorization' => 'Bearer ' . $key, 'Content-Type' => 'application/json' );
}

/** Model tekstowy (bez obrazów, mowy, wektorów, wyszukiwania, moderacji). */
function rzd_ai_openai_text_model( $id ) {
	return (bool) preg_match( '/^(gpt-|o\d|chatgpt-)/i', $id ) && ! preg_match( '/embedding|tts|whisper|audio|realtime|image|dall-e|transcribe|search|moderation|codex|computer|instruct/i', $id );
}

function rzd_ai_openai_models( $key = null ) {
	$key = null === $key || '' === $key ? rzd_api_secret( 'openai_key' ) : $key;
	if ( '' === $key ) {
		return array( false, 'Wpisz klucz API OpenAI.' );
	}
	$r = wp_remote_get( rzd_ai_openai_base() . 'models', array( 'timeout' => 20, 'headers' => rzd_ai_openai_headers( $key ) ) );
	if ( is_wp_error( $r ) ) {
		return array( false, 'Brak połączenia z OpenAI: ' . $r->get_error_message() );
	}
	$code = (int) wp_remote_retrieve_response_code( $r );
	$j    = json_decode( wp_remote_retrieve_body( $r ), true );
	if ( 200 !== $code ) {
		return array( false, rzd_ai_http_error( 'OpenAI', $code, isset( $j['error']['message'] ) ? (string) $j['error']['message'] : '', 'platform.openai.com → Billing' ) );
	}
	$out = array();
	foreach ( isset( $j['data'] ) ? (array) $j['data'] : array() as $m ) {
		if ( ! empty( $m['id'] ) && rzd_ai_openai_text_model( (string) $m['id'] ) ) {
			$out[] = array( 'id' => (string) $m['id'], 'name' => (string) $m['id'] );
		}
	}
	usort( $out, function ( $a, $b ) { return strcmp( $a['id'], $b['id'] ); } );
	return $out ? array( true, $out ) : array( false, 'OpenAI nie zwrócił żadnego modelu tekstowego.' );
}

function rzd_ai_openai_body( $model, $req, $reason, $temp, $maxcalls = true ) {
	$content = array( array( 'type' => 'input_text', 'text' => (string) $req['text'] ) );
	foreach ( isset( $req['images'] ) ? (array) $req['images'] : array() as $im ) {
		$content[] = array( 'type' => 'input_image', 'image_url' => 'data:' . $im['mime'] . ';base64,' . $im['data'] );
	}
	$b = array( 'model' => $model, 'input' => array( array( 'role' => 'user', 'content' => $content ) ), 'max_output_tokens' => 6000, 'store' => false );
	if ( ! empty( $req['system'] ) ) {
		$b['instructions'] = (string) $req['system'];
	}
	if ( ! empty( $req['keys'] ) ) {
		$b['text'] = array( 'format' => array( 'type' => 'json_schema', 'name' => 'odpowiedz', 'strict' => true, 'schema' => rzd_ai_schema( $req['keys'] ) ) );
	}
	if ( ! empty( $req['web'] ) ) { // (2.54.0) wyszukiwarka OpenAI, limit wywołań narzędzia
		$b['tools'] = array( array( 'type' => 'web_search' ) );
		if ( $maxcalls ) {
			$b['max_tool_calls'] = (int) $req['web'];
		}
	}
	if ( $reason ) {
		$b['reasoning'] = array( 'effort' => 'low' );
	} elseif ( $temp && isset( $req['temp'] ) ) {
		$b['temperature'] = min( 2, max( 0, (float) $req['temp'] ) );
	}
	return $b;
}

function rzd_ai_openai_ask( $model, $key, $req, $what, $timeout = 0 ) {
	if ( function_exists( 'set_time_limit' ) ) {
		@set_time_limit( 200 ); // phpcs:ignore -- tam, gdzie hosting pozwala
	}
	$timeout = $timeout ? (int) $timeout : (int) apply_filters( 'rzd_posts_gemini_timeout', 150 );
	$t0      = microtime( true );
	$reason  = (bool) preg_match( '/^(gpt-5|o\d)/i', $model );
	$temp    = true;
	$maxc    = true;
	$res     = array( false, 'Brak odpowiedzi z OpenAI.' );
	$usage   = null;
	for ( $try = 0; $try < 4; $try++ ) {
		$r = wp_remote_post( rzd_ai_openai_base() . 'responses', array(
			'timeout' => $timeout,
			'headers' => rzd_ai_openai_headers( $key ),
			'body'    => wp_json_encode( rzd_ai_openai_body( $model, $req, $reason, $temp, $maxc ) ),
		) );
		if ( is_wp_error( $r ) ) {
			$res = array( false, rzd_ai_wp_error_msg( 'OpenAI', $r ) );
			break;
		}
		$code = (int) wp_remote_retrieve_response_code( $r );
		$j    = json_decode( wp_remote_retrieve_body( $r ), true );
		$err  = isset( $j['error']['message'] ) ? (string) $j['error']['message'] : '';
		if ( 400 === $code && $reason && preg_match( '/reasoning/i', $err ) ) {
			$reason = false;
			continue;
		}
		if ( 400 === $code && $temp && preg_match( '/temperature/i', $err ) ) {
			$temp = false;
			continue;
		}
		if ( 400 === $code && $maxc && ! empty( $req['web'] ) && preg_match( '/max_tool_calls/i', $err ) ) {
			$maxc = false;
			continue;
		}
		if ( 400 === $code && ! empty( $req['web'] ) && preg_match( '/web_search|tool/i', $err ) ) {
			$res = array( false, 'Ten model ChatGPT nie obsługuje wyszukiwania w internecie (' . $err . '). Wyłącz „Szukaj w internecie” albo wybierz inny model.' );
			break;
		}
		if ( 200 !== $code ) {
			$res = array( false, rzd_ai_http_error( 'OpenAI', $code, $err . ( isset( $j['error']['code'] ) ? ' [' . $j['error']['code'] . ']' : '' ), 'platform.openai.com → Billing' ) );
			break;
		}
		$txt = isset( $j['output_text'] ) && is_string( $j['output_text'] ) ? $j['output_text'] : '';
		$ref = '';
		if ( '' === $txt ) {
			foreach ( isset( $j['output'] ) ? (array) $j['output'] : array() as $o ) {
				foreach ( isset( $o['content'] ) ? (array) $o['content'] : array() as $c ) {
					if ( isset( $c['type'] ) && 'output_text' === $c['type'] && isset( $c['text'] ) ) {
						$txt .= (string) $c['text'];
					} elseif ( isset( $c['type'] ) && 'refusal' === $c['type'] ) {
						$ref = isset( $c['refusal'] ) ? (string) $c['refusal'] : 'odmowa';
					}
				}
			}
		}
		$web = 0;
		foreach ( isset( $j['output'] ) ? (array) $j['output'] : array() as $o ) {
			$web += isset( $o['type'] ) && 'web_search_call' === $o['type'] ? 1 : 0;
		}
		if ( isset( $j['usage'] ) ) {
			$usage = array( isset( $j['usage']['input_tokens'] ) ? $j['usage']['input_tokens'] : 0, isset( $j['usage']['output_tokens'] ) ? $j['usage']['output_tokens'] : 0, ! empty( $req['web'] ) ? $web : null );
		}
		if ( '' !== $ref ) {
			$res = array( false, 'ChatGPT odmówił odpowiedzi (' . $ref . '). Zmień treść albo wybierz innego dostawcę.' );
		} elseif ( '' === trim( $txt ) ) {
			$inc = isset( $j['status'] ) && 'incomplete' === $j['status'];
			$res = array( false, 'ChatGPT nie zwrócił tekstu' . ( $inc ? ' (odpowiedź przerwana – limit długości)' : '' ) . '. Spróbuj ponownie albo wybierz inny model.' );
		} else {
			$res = array( true, $txt );
		}
		break;
	}
	rzd_ai_log_call( 'openai', $model, $what, $t0, 'Responses', $res, $usage );
	return $res;
}
