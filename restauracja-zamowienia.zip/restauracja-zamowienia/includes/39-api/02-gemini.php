<?php
/**
 * Moduł 39-api – Gemini (2.51.0; kod przeniesiony z 38-posty/02-ai bez zmiany działania). Wspólne połączenie z AI dla
 * postów i opisów dań: lista modeli, zapytanie (Interactions API z zapasem generateContent, krótkie „myślenie”,
 * warianty zapamiętywane w opcji rzd_posts_think), Test AI. Nazwy filtrów i opcji bez zmian (rzd_posts_gemini_base,
 * rzd_posts_gemini_timeout, rzd_posts_gemini_test_timeout, rzd_posts_think, rzd_posts_last_call) – dane i hooki
 * istniejących instalacji. Klucz i model – Panel → Połączenia API (01-dane).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function rzd_ai_gemini_base() {
	return apply_filters( 'rzd_posts_gemini_base', 'https://generativelanguage.googleapis.com/v1beta/' );
}

/** Modele, które piszą tekst (generateContent). [ ok, lista | komunikat ]. */
function rzd_ai_gemini_models( $key = null ) {
	$key = null === $key ? rzd_api_secret( 'gemini_key' ) : $key;
	if ( '' === $key ) {
		return array( false, 'Najpierw wpisz klucz API Gemini.' );
	}
	$r = wp_remote_get( rzd_ai_gemini_base() . 'models?pageSize=200', array( 'timeout' => 20, 'headers' => array( 'x-goog-api-key' => $key ) ) );
	if ( is_wp_error( $r ) ) {
		return array( false, 'Brak połączenia z Gemini: ' . $r->get_error_message() );
	}
	$j = json_decode( wp_remote_retrieve_body( $r ), true );
	if ( 200 !== (int) wp_remote_retrieve_response_code( $r ) ) {
		return array( false, 'Gemini odrzucił klucz: ' . ( isset( $j['error']['message'] ) ? $j['error']['message'] : 'HTTP ' . wp_remote_retrieve_response_code( $r ) ) );
	}
	$out = array();
	foreach ( isset( $j['models'] ) ? (array) $j['models'] : array() as $m ) {
		if ( empty( $m['name'] ) || ! in_array( 'generateContent', isset( $m['supportedGenerationMethods'] ) ? (array) $m['supportedGenerationMethods'] : array(), true ) ) {
			continue;
		}
		$id = preg_replace( '#^models/#', '', $m['name'] );
		if ( preg_match( '/embedding|aqa|imagen|tts|audio|image-generation|live/i', $id ) ) {
			continue;
		}
		$out[] = array( 'id' => $id, 'name' => isset( $m['displayName'] ) ? $m['displayName'] : $id );
	}
	return array( true, $out );
}

/**
 * Zapytanie do Gemini (2.48.2). Dwa sposoby: Interactions API (POST v1beta/interactions – zalecany przez Google
 * dla nowych kont i modeli 3.x; na nowym koncie gemini-3.8-flash przez generateContent potrafił nie odpowiadać
 * wcale) i zapasowo generateContent. Krótkie „myślenie”: Interactions – thinking_level low, potem bez ustawienia;
 * generateContent – thinkingLevel low, thinkingBudget 0, bez ustawienia. Pierwszy wariant, który model przyjmie,
 * jest zapamiętywany dla modelu (opcja rzd_posts_think: [ model => 'ia-low' | 'ia-none' | 'gc-low' | … ]).
 * Na Interactions → generateContent przechodzi przy odrzuceniu zapytania (400/404/501), nie przy przekroczeniu
 * czasu ani przeciążeniu (429/503). Każde zapytanie zapisuje się w rzd_posts_last_call (Ustawienia).
 * $req: system, text, images [ [mime, data] ], keys (JSON z tymi kluczami | null – zwykły tekst), temp.
 * [ ok, tekst odpowiedzi (bez „myśli” modelu) | komunikat ].
 */
function rzd_ai_gemini_ask( $model, $key, $req, $what, $timeout = 0 ) {
	if ( function_exists( 'set_time_limit' ) ) {
		@set_time_limit( 200 ); // phpcs:ignore -- tam, gdzie hosting pozwala
	}
	$timeout = $timeout ? (int) $timeout : (int) apply_filters( 'rzd_posts_gemini_timeout', 150 );
	$all     = array( 'ia-low', 'ia-none', 'gc-low', 'gc-budget', 'gc-none' );
	$known   = get_option( 'rzd_posts_think', array() );
	$known   = is_array( $known ) ? $known : array();
	$order   = $all;
	if ( isset( $known[ $model ] ) && in_array( $known[ $model ], $all, true ) ) {
		$order = array_values( array_unique( array_merge( array( $known[ $model ] ), $all ) ) );
	}
	$t0     = microtime( true );
	$res    = array( false, 'Brak odpowiedzi z Gemini.' );
	$skipia = false;
	$used   = '';
	$web    = null;
	foreach ( $order as $v ) {
		list( $api, $th ) = explode( '-', $v );
		if ( 'ia' === $api && $skipia ) {
			continue;
		}
		if ( 'ia' === $api ) {
			$url  = rzd_ai_gemini_base() . 'interactions';
			$body = rzd_ai_gemini_body_ia( $model, $req, $th );
		} else {
			$url  = rzd_ai_gemini_base() . 'models/' . rawurlencode( $model ) . ':generateContent';
			$body = rzd_ai_gemini_body_gc( $req, $th );
		}
		$r = wp_remote_post( $url, array(
			'timeout' => $timeout,
			'headers' => array( 'x-goog-api-key' => $key, 'Content-Type' => 'application/json' ),
			'body'    => wp_json_encode( $body ),
		) );
		if ( is_wp_error( $r ) ) {
			$msg = $r->get_error_message();
			$res = array( false, ( false !== stripos( $msg, 'timed out' ) || false !== stripos( $msg, 'timeout' ) ) ? 'Gemini nie odpowiedział w czasie (' . $msg . '). Wybierz inny model albo spróbuj ponownie za chwilę.' : 'Brak połączenia z Gemini: ' . $msg );
			$used = $api;
			break;
		}
		$code = (int) wp_remote_retrieve_response_code( $r );
		$j    = json_decode( wp_remote_retrieve_body( $r ), true );
		$err  = isset( $j['error']['message'] ) ? (string) $j['error']['message'] : '';
		$used = $api;
		if ( 400 === $code && 'none' !== $th && preg_match( '/thinking/i', $err ) ) {
			continue; // model nie zna tego ustawienia „myślenia” – następny wariant
		}
		if ( 'ia' === $api && in_array( $code, array( 400, 404, 501 ), true ) && ! preg_match( '/api key|API_KEY|permission/i', $err ) ) {
			$skipia = true; // Interactions odrzucone – zapasowo generateContent
			continue;
		}
		if ( in_array( $code, array( 429, 500, 503 ), true ) ) {
			$res = array( false, 'Gemini jest teraz przeciążony albo przekroczono limit (' . ( '' !== $err ? $err : 'HTTP ' . $code ) . '). Spróbuj za kilka minut albo wybierz inny model.' );
			break;
		}
		if ( 200 !== $code ) {
			$res = array( false, 'Gemini: ' . ( '' !== $err ? $err : 'HTTP ' . $code ) );
			break;
		}
		$txt = 'ia' === $api ? rzd_ai_gemini_text_ia( $j ) : rzd_ai_gemini_text_gc( $j );
		$web = ! empty( $req['web'] ) ? rzd_ai_gemini_web_count( $j ) : null;
		if ( ! is_array( $txt ) ) {
			$res = array( false, $txt );
			break;
		}
		if ( ! isset( $known[ $model ] ) || $known[ $model ] !== $v ) {
			$known[ $model ] = $v;
			update_option( 'rzd_posts_think', $known, false );
		}
		$res = array( true, $txt[0] );
		break;
	}
	update_option( 'rzd_posts_last_call', array(
		'time'     => time(),
		'secs'     => round( microtime( true ) - $t0, 1 ),
		'model'    => $model,
		'what'     => $what,
		'api'      => 'ia' === $used ? 'Interactions' : ( 'gc' === $used ? 'generateContent' : '' ),
		'ok'       => $res[0],
		'msg'      => $res[0] ? '' : $res[1],
		'provider' => 'gemini',
		'web'      => $web,
	), false );
	return $res;
}

/** (2.54.0) Liczba wyszukiwań Google w odpowiedzi (Interactions: kroki google_search_call; generateContent: webSearchQueries). */
function rzd_ai_gemini_web_count( $j ) {
	$n = 0;
	foreach ( isset( $j['steps'] ) ? (array) $j['steps'] : array() as $step ) {
		$n += isset( $step['type'] ) && false !== strpos( (string) $step['type'], 'google_search_call' ) ? 1 : 0;
	}
	if ( isset( $j['candidates'][0]['groundingMetadata']['webSearchQueries'] ) ) {
		$n += count( (array) $j['candidates'][0]['groundingMetadata']['webSearchQueries'] );
	}
	return $n;
}

/** Treść zapytania Interactions API: system_instruction, input (tekst albo części z obrazkami), JSON wg schematu. */
function rzd_ai_gemini_body_ia( $model, $req, $th ) {
	$b = array( 'model' => $model, 'store' => false );
	if ( ! empty( $req['system'] ) ) {
		$b['system_instruction'] = $req['system'];
	}
	if ( empty( $req['images'] ) ) {
		$b['input'] = $req['text'];
	} else {
		$in = array( array( 'type' => 'text', 'text' => $req['text'] ) );
		foreach ( $req['images'] as $im ) {
			$in[] = array( 'type' => 'image', 'data' => $im['data'], 'mime_type' => $im['mime'] );
		}
		$b['input'] = $in;
	}
	$gc = array();
	if ( 'low' === $th ) {
		$gc['thinking_level'] = 'low';
	}
	if ( isset( $req['temp'] ) ) {
		$gc['temperature'] = $req['temp']; // nowsze modele ignorują – nie szkodzi
	}
	if ( $gc ) {
		$b['generation_config'] = $gc;
	}
	if ( ! empty( $req['web'] ) ) { // (2.54.0) wyszukiwanie Google (grounding); JSON wtedy z instrukcji – rzd_ai_ask
		$b['tools'] = array( array( 'type' => 'google_search' ) );
	}
	if ( ! empty( $req['keys'] ) ) {
		$props = array();
		foreach ( $req['keys'] as $k ) {
			$props[ $k ] = array( 'type' => 'string' );
		}
		$b['response_format'] = array( 'type' => 'text', 'mime_type' => 'application/json', 'schema' => array( 'type' => 'object', 'properties' => $props, 'required' => array_values( $req['keys'] ) ) );
	}
	return $b;
}

/** Treść zapytania generateContent (jak do 2.48.1). */
function rzd_ai_gemini_body_gc( $req, $th ) {
	$parts = array( array( 'text' => $req['text'] ) );
	foreach ( isset( $req['images'] ) ? $req['images'] : array() as $im ) {
		$parts[] = array( 'inline_data' => array( 'mime_type' => $im['mime'], 'data' => $im['data'] ) );
	}
	$b = array( 'contents' => array( array( 'role' => 'user', 'parts' => $parts ) ), 'generationConfig' => array() );
	if ( ! empty( $req['system'] ) ) {
		$b['systemInstruction'] = array( 'parts' => array( array( 'text' => $req['system'] ) ) );
	}
	if ( isset( $req['temp'] ) ) {
		$b['generationConfig']['temperature'] = $req['temp'];
	}
	if ( ! empty( $req['keys'] ) ) {
		$props = array();
		foreach ( $req['keys'] as $k ) {
			$props[ $k ] = array( 'type' => 'STRING' );
		}
		$b['generationConfig']['responseMimeType'] = 'application/json';
		$b['generationConfig']['responseSchema']   = array( 'type' => 'OBJECT', 'properties' => $props, 'required' => array_values( $req['keys'] ) );
	}
	if ( 'low' === $th ) {
		$b['generationConfig']['thinkingConfig'] = array( 'thinkingLevel' => 'low' );
	} elseif ( 'budget' === $th ) {
		$b['generationConfig']['thinkingConfig'] = array( 'thinkingBudget' => 0 );
	}
	if ( ! empty( $req['web'] ) ) { // (2.54.0)
		$b['tools'] = array( array( 'google_search' => new stdClass() ) );
	}
	if ( ! $b['generationConfig'] ) {
		unset( $b['generationConfig'] );
	}
	return $b;
}

/** Tekst z odpowiedzi Interactions: kroki „model_output”, części „text” (bez kroków „thought”). [ tekst ] | komunikat. */
function rzd_ai_gemini_text_ia( $j ) {
	$st = isset( $j['status'] ) ? (string) $j['status'] : 'completed';
	if ( in_array( $st, array( 'failed', 'cancelled' ), true ) ) {
		return 'Gemini przerwał odpowiedź (' . $st . ( isset( $j['error']['message'] ) ? ': ' . $j['error']['message'] : '' ) . ').';
	}
	$txt = '';
	foreach ( isset( $j['steps'] ) ? (array) $j['steps'] : array() as $step ) {
		if ( isset( $step['type'] ) && 'model_output' === $step['type'] ) {
			foreach ( isset( $step['content'] ) ? (array) $step['content'] : array() as $c ) {
				$txt .= isset( $c['type'], $c['text'] ) && 'text' === $c['type'] ? $c['text'] : '';
			}
		}
	}
	foreach ( '' === $txt && isset( $j['outputs'] ) ? (array) $j['outputs'] : array() as $o ) { // starszy kształt odpowiedzi
		$txt .= isset( $o['type'], $o['text'] ) && 'text' === $o['type'] ? $o['text'] : '';
	}
	return '' === trim( $txt ) ? 'Gemini nie zwrócił tekstu (status: ' . $st . ').' : array( $txt );
}

/** Tekst z odpowiedzi generateContent (bez części „thought”). [ tekst ] | komunikat. */
function rzd_ai_gemini_text_gc( $j ) {
	$txt = '';
	foreach ( isset( $j['candidates'][0]['content']['parts'] ) ? (array) $j['candidates'][0]['content']['parts'] : array() as $p ) {
		$txt .= isset( $p['text'] ) && empty( $p['thought'] ) ? $p['text'] : '';
	}
	$why = isset( $j['candidates'][0]['finishReason'] ) ? ' (' . $j['candidates'][0]['finishReason'] . ')' : '';
	return '' === trim( $txt ) ? 'Gemini nie zwrócił tekstu' . $why . '.' : array( $txt );
}

/** „Test AI” w Ustawieniach: krótka odpowiedź, pomiar czasu, najwyżej 30 s. [ ok, komunikat ]. */
function rzd_ai_gemini_test() {
	$s   = rzd_api_settings();
	$key = rzd_api_secret( 'gemini_key' );
	if ( '' === $key || '' === $s['model'] ) {
		return array( false, 'Najpierw zapisz klucz API i model.' );
	}
	$t0 = microtime( true );
	list( $ok, $txt ) = rzd_ai_gemini_ask( $s['model'], $key, array( 'text' => 'Odpowiedz jednym słowem: działa', 'temp' => 0 ), 'test', (int) apply_filters( 'rzd_posts_gemini_test_timeout', 30 ) );
	$secs = str_replace( '.', ',', (string) round( microtime( true ) - $t0, 1 ) );
	if ( ! $ok ) {
		return array( false, $txt . ' (' . $secs . ' s)' );
	}
	$lc = get_option( 'rzd_posts_last_call' );
	return array( true, 'Gemini odpowiada: „' . mb_substr( trim( $txt ), 0, 40 ) . '” – ' . $secs . ' s (model ' . $s['model'] . ', ' . ( ! empty( $lc['api'] ) ? $lc['api'] : '' ) . ').' );
}

/**
 * (2.53.0) Dostawca na czas bieżącego żądania – ustawia go panel (pole „AI:” przy „Generuj”) albo automat postów;
 * bez ustawienia – domyślny z Połączeń API. rzd_ai_use( null ) tylko odczytuje.
 */
function rzd_ai_use( $p = null ) {
	static $cur = '';
	if ( null !== $p ) {
		$cur = isset( rzd_ai_providers()[ $p ] ) ? (string) $p : '';
	}
	return $cur;
}

/**
 * Zapytanie do AI – JEDEN dostawca (wybrany / domyślny), jedno zapytanie. $req: system, text, images [ {mime, data
 * base64} ], keys (klucze JSON odpowiedzi – wszystkie tekstowe), temp; $what – do „Ostatniego zapytania” (post, opis,
 * test). [ ok, tekst | komunikat ].
 */
function rzd_ai_ask( $req, $what = 'ai', $timeout = 0, $provider = '' ) {
	$p = '' !== $provider ? $provider : ( '' !== rzd_ai_use() ? rzd_ai_use() : rzd_ai_default() );
	if ( '' === $p ) {
		return array( false, 'Nie ma połączenia z AI – uzupełnij klucz i model w Panel → Połączenia API.' );
	}
	$ps = rzd_ai_providers();
	if ( ! isset( $ps[ $p ] ) || ! rzd_ai_provider_ready( $p ) ) {
		return array( false, ( isset( $ps[ $p ] ) ? $ps[ $p ][0] : 'Ten dostawca AI' ) . ' nie jest skonfigurowany – Panel → Połączenia API.' );
	}
	$model = rzd_api_settings()[ $ps[ $p ][2] ];
	$key   = rzd_api_secret( $ps[ $p ][1] );
	$req   = rzd_ai_web_req( $req );
	if ( 'claude' === $p ) {
		return rzd_ai_claude_ask( $model, $key, $req, $what, $timeout );
	}
	if ( 'openai' === $p ) {
		return rzd_ai_openai_ask( $model, $key, $req, $what, $timeout );
	}
	return rzd_ai_gemini_ask( $model, $key, $req, $what, $timeout );
}

/**
 * (2.54.0) Wyszukiwanie w internecie: $req['web'] = najwyżej tyle wyszukiwań (1–5). Wyszukiwanie zwraca źródła /
 * przypisy, z którymi schemat JSON bywa niezgodny (Claude: cytowania ≠ structured outputs) – wtedy klucze JSON idą
 * do instrukcji, a odpowiedź czyta rzd_ai_json() (wycina obiekt JSON z tekstu).
 */
function rzd_ai_web_req( $req ) {
	if ( empty( $req['web'] ) ) {
		unset( $req['web'] );
		return $req;
	}
	$req['web'] = max( 1, min( 5, (int) $req['web'] ) );
	if ( ! empty( $req['keys'] ) ) {
		$req['system'] = trim( ( isset( $req['system'] ) ? (string) $req['system'] : '' ) . "\n\n" . 'Odpowiedz wyłącznie obiektem JSON z kluczami: ' . implode( ', ', $req['keys'] ) . ' (wartości – tekst). Bez żadnego tekstu przed ani po JSON, bez przypisów, odnośników i nazw źródeł w treści.' );
		$req['keys']   = null;
	}
	return $req;
}

/** Obiekt JSON z odpowiedzi AI (także otoczony tekstem, ```json, przypisami po obiekcie). Tablica | null. */
function rzd_ai_json( $txt ) {
	$txt = trim( preg_replace( '/^```(?:json)?|```$/m', '', (string) $txt ) );
	$j   = json_decode( $txt, true );
	if ( is_array( $j ) ) {
		return $j;
	}
	$a = strpos( $txt, '{' );
	$b = strrpos( $txt, '}' );
	if ( false === $a || false === $b || $b <= $a ) {
		return null;
	}
	$j = json_decode( substr( $txt, $a, $b - $a + 1 ), true );
	return is_array( $j ) ? $j : null;
}

/** Czy jakikolwiek dostawca AI jest gotowy (klucz + model). */
function rzd_ai_ready() {
	return '' !== rzd_ai_default();
}

/** Test AI wybranego dostawcy. [ ok, komunikat ]. */
function rzd_ai_test( $p ) {
	$miss = rzd_ai_missing( $p ); // (2.54.1) dokładnie: brak klucza czy brak modelu
	if ( '' !== $miss ) {
		return array( false, $miss );
	}
	if ( 'gemini' === $p ) {
		return rzd_ai_gemini_test();
	}
	list( $ok, $txt ) = rzd_ai_ask( array( 'text' => 'Odpowiedz jednym słowem: działa', 'temp' => 0 ), 'test', (int) apply_filters( 'rzd_posts_gemini_test_timeout', 30 ), $p );
	if ( ! $ok ) {
		return array( false, $txt );
	}
	$lc = get_option( 'rzd_posts_last_call' );
	return array( true, rzd_ai_providers()[ $p ][0] . ' odpowiada: „' . wp_html_excerpt( trim( $txt ), 60, '…' ) . '” – ' . str_replace( '.', ',', (string) ( is_array( $lc ) ? $lc['secs'] : '' ) ) . ' s' );
}

/** Zapis „Ostatniego zapytania” (wspólny dla Claude i OpenAI; Gemini zapisuje sam). */
function rzd_ai_log_call( $provider, $model, $what, $t0, $api, $res, $usage = null ) {
	update_option( 'rzd_posts_last_call', array(
		'time'     => time(),
		'secs'     => round( microtime( true ) - $t0, 1 ),
		'model'    => $model,
		'what'     => $what,
		'api'      => $api,
		'ok'       => $res[0],
		'msg'      => $res[0] ? '' : $res[1],
		'provider' => $provider,
		'tok_in'   => is_array( $usage ) && isset( $usage[0] ) ? (int) $usage[0] : null,
		'tok_out'  => is_array( $usage ) && isset( $usage[1] ) ? (int) $usage[1] : null,
		'web'      => is_array( $usage ) && isset( $usage[2] ) ? (int) $usage[2] : null, // (2.54.0) liczba wyszukiwań
	), false );
}

/** Wspólny opis błędu HTTP dostawcy (przeciążenie, brak środków, zły klucz). */
function rzd_ai_http_error( $name, $code, $err, $billing_hint ) {
	if ( in_array( $code, array( 401, 403 ), true ) ) {
		return $name . ' odrzucił klucz API (' . ( '' !== $err ? $err : 'HTTP ' . $code ) . '). Sprawdź klucz w Połączeniach API.';
	}
	if ( preg_match( '/credit balance|insufficient_quota|billing|exceeded your current quota/i', $err ) ) {
		return $name . ': brak środków na koncie API (' . $err . '). Doładuj konto: ' . $billing_hint . '.';
	}
	if ( in_array( $code, array( 429, 500, 502, 503, 529 ), true ) ) {
		return $name . ' jest teraz przeciążony albo przekroczono limit (' . ( '' !== $err ? $err : 'HTTP ' . $code ) . '). Spróbuj za kilka minut albo wybierz innego dostawcę.';
	}
	return $name . ': ' . ( '' !== $err ? $err : 'HTTP ' . $code );
}

/** Schemat JSON odpowiedzi: wszystkie klucze tekstowe, wymagane, bez dodatkowych (wymóg Claude i OpenAI strict). */
function rzd_ai_schema( $keys ) {
	$props = array();
	foreach ( (array) $keys as $k ) {
		$props[ $k ] = array( 'type' => 'string' );
	}
	return array( 'type' => 'object', 'properties' => (object) $props, 'required' => array_values( (array) $keys ), 'additionalProperties' => false );
}

/** Wspólne: błąd połączenia (limit czasu). */
function rzd_ai_wp_error_msg( $name, $r ) {
	$msg = $r->get_error_message();
	return ( false !== stripos( $msg, 'timed out' ) || false !== stripos( $msg, 'timeout' ) ) ? $name . ' nie odpowiedział w czasie (' . $msg . '). Wybierz szybszy model albo spróbuj ponownie za chwilę.' : 'Brak połączenia z ' . $name . ': ' . $msg;
}
