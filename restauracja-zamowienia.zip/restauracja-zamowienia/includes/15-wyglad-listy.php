<?php
/**
 * MODUŁ 15: Wygląd listy — panel do samodzielnego dostosowania stylu
 *
 * Zamiast prosić o zmianę CSS za każdym razem, gdy coś ma wyglądać inaczej,
 * najważniejsze elementy listy zamówień (nazwa produktu, nagłówek kategorii,
 * cena, opis, zdjęcie, przycisk "Dodaj do koszyka", plakietki alergenów)
 * można teraz ustawić z panelu: krój i rozmiar czcionki, kolory, wielkość
 * zdjęcia, zaokrąglenia rogów tam, gdzie mają sens.
 *
 * Ustawienia zapisują się jako jedna opcja (rzd_list_style) i na froncie
 * są wstrzykiwane jako dodatkowy blok CSS DOKLEJONY do statycznego pliku
 * includes/css/lista-zamowien.css (moduł 03) – nadpisuje go tam, gdzie
 * coś faktycznie zmienisz, a wszystko inne zostaje bez zmian.
 *
 * Od 2.26.0: dwie zakładki – Komputer (wartości bazowe, od 900 px) i Telefon
 * (dziedziczy z komputera sekcjami; „Na telefonie inaczej” = własne m_*).
 * Podgląd w <iframe> o szerokości urządzenia, więc @media działają naprawdę.
 *
 * Domyślne wartości w panelu odpowiadają temu, co jest w tej chwili na
 * stronie – więc samo zainstalowanie tego modułu niczego nie zmienia,
 * dopóki czegoś nie ruszysz. Pola kolorów mają osobny checkbox "Nadpisz
 * kolor", bo bez niego nie da się bezpiecznie odróżnić "zostaw jak jest"
 * (kolor z motywu) od świadomego wyboru konkretnego koloru.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ============================================================
 * 1. DANE I DOMYŚLNE WARTOŚCI
 * ============================================================ */
function rzd_list_style_defaults() {
	return array(
		// Wartości bazowe = KOMPUTER (od 900 px). Telefon dziedziczy je sekcjami,
		// chyba że w sekcji zaznaczono „Na telefonie inaczej” (m_on_<sekcja>) –
		// wtedy bierze swoje m_<klucz>. Od 2.26.0 (style_v 2).
		'style_v'            => 5,

		'heading_font'       => 'Playfair Display',
		'body_font'          => 'Lato',
		'letter_spacing'     => 1.5,

		'name_size'          => 20,
		'name_color_on'      => 0,
		'name_color'         => '#c0392b',
		'name_gap'           => 0, // 2.26.13: odstęp pod nazwą produktu w px (0 = jak dotąd)

		'cat_size'           => 26,
		'cat_color_on'       => 0,
		'cat_color'          => '#222222',

		'price_size'         => 34, // 2.26.0: wcześniej plik CSS i tak wymuszał 34 px
		'price_color_on'     => 0,
		'price_color'        => '#222222',
		'price_cur_pos'      => 'side', // 2.26.6: side | below | above
		'price_cur_size'     => 100,    // 2.26.6: % rozmiaru ceny
		'price_dec_size'     => 100,    // 2.26.6: % rozmiaru ceny (grosze)
		'price_dec_align'    => 'base', // 2.26.6: base = w linii, top = u góry
		'price_cur_gap'      => 0,        // 2.26.12: odstęp liczba ↔ waluta w px (0 = automatycznie)
		'price_cur_align'    => 'center', // 2.26.12: przy pod/nad – left | center | right

		'desc_font'          => '', // puste = ta sama czcionka co reszta treści (body_font)
		'desc_size'          => 14,
		'desc_color_on'      => 0,
		'desc_color'         => '#666666',

		'image_size'         => 160,
		'image_radius'       => 16,
		'set_split'          => 'diag',    // 2.26.22: zdjęcie dzielone zestawu: diag = skos „/”, vert = pionowo
		'set_split_line'     => 0,         // 2.26.22: kreska podziału w px (0 = bez kreski)
		'set_split_color'    => '#ffffff', // 2.26.22: kolor kreski

		// Kolory interakcji (hover): wiersz i ramka mają DWA różne kolory,
		// inaczej ramka „znika” na tle podświetlonego wiersza.
		'row_hover_bg'       => '#faf3e3',
		'box_hover_bg'       => '#ffffff',
		'box_hover_border'   => '#c08a2e',

		'button_padding_v'   => 8,
		'button_padding_h'   => 14,
		'button_radius'      => 6,
		'button_font_size'   => 15,     // 2.26.4
		'button_width'       => 'fill', // 2.26.4: fill = reszta wiersza (jak dawniej), auto = wg napisu
		'button_align'       => 'left', // 2.26.5: przy „auto” – left = obok licznika, right = do prawej krawędzi
		'button_text_color'  => '#2b2110',
		'button_bg'          => '#faf3e3',
		'button_border_color'=> '#c08a2e',
		'button_hover_bg'    => '#ffffff',
		'button_hover_text'  => '#2b2110',

		'allergen_bg'        => '#f3e9d8',
		'allergen_text'      => '#5a4520',
		'allergen_radius'    => 10,

		// Ramki rozwijane (2.25.3)
		'box_border_color'    => '#c4c4c4',
		'box_border_width'    => 1.5,
		'box_radius'          => 8,
		'box_bg_on'           => 0,
		'box_bg'              => '#ffffff',
		'box_pad_v'           => 8,
		'box_pad_h'           => 12,
		'box_title_size'      => 12,
		'box_title_color'     => '#2b2b2b',
		'box_arrow_on'        => 1,
		'box_harmono_title'   => 'Harmonogram',
		'box_harmono_border'  => 1,
		'harmono_days_back'   => 7, // 2.26.1: historia w okienku harmonogramu (0 = bez)
		'box_delivery_title'  => 'Możliwe dostawy',
		'box_delivery_border' => 1,
		'box_more_title'      => 'Pełny opis',
		'box_more_border'     => 1,
		'box_allergen_title'  => 'Alergeny', // ramka alergenów (na telefonie); liczba dopisywana sama
		'box_allergen_border' => 1,

		// Licznik ilości (2.25.3)
		'qty_border_on'       => 0, // 2.26.0: przy okrągłych − / + bez ramki licznika
		'qty_border_color'    => '#c4c4c4',
		'qty_border_width'    => 1.5,
		'qty_radius'          => 8,
		'qty_bg'              => '#ffffff',
		'qty_height'          => 52,
		'qty_font_size'       => 18,
		'qty_btn_width'       => 38,
		'qty_btn_radius'      => 0,
		'qty_btn_bg'          => '#f4f4f4',
		'qty_btn_text'        => '#2b2b2b',
		'qty_btn_hover_bg'    => '#e8e8e8',
		'qty_gap'             => 16,
		'qty_input_width'     => 0, // 2.26.5: szerokość pola z liczbą w px, 0 = automatycznie
		'qty_btn_shape'       => 'circle', // 'rect' | 'circle'
		'qty_circle_size'     => 40,
		'qty_circle_border_w' => 1.5,
		'qty_circle_border_c' => '#c08a2e',

		'element_gap'         => 10,

		// Okienka: tło (2.25.3) + czcionki i przyciski (2.26.0).
		// Grubość '' = jak motyw (nic nie narzucamy).
		'popup_opacity'       => 82,
		'popup_bg_color'      => '#ffffff', // 2.26.6
		'popup_text_color'    => '#2b2b2b', // 2.26.6
		'popup_blur'          => 14,
		'popup_title_size'    => 22,
		'popup_title_weight'  => '700',
		'popup_text_size'     => 13,
		'popup_text_weight'   => '',
		'popup_label_size'    => 13,
		'popup_label_weight'  => '',
		'popup_tile_size'     => 14,
		'popup_tile_weight'   => '',
		'popup_btn_size'      => 14,
		'popup_btn_weight'    => '600',
		'popup_btn_pad_v'     => 11,
		'popup_btn_width'     => 44,
		'popup_btn_radius'    => 8,

		// 2.26.6: kafle kategorii [kategorie_zamowien] (moduł 17). Komputer = dotychczasowy
		// wygląd (zdjęcie nad napisem, 4 w wierszu), telefon = zdjęcie w tle, rozmyte,
		// przyciemnione, biały pogrubiony napis, 2 w wierszu.
		'tiles_style'         => 'below', // below | photo | plain
		'tiles_cols'          => 4,
		'tiles_gap'           => 20,
		'tiles_height'        => 80,
		'tiles_radius'        => 12,
		'tiles_blur'          => 3,
		'tiles_overlay'       => 50,
		'tiles_font_size'     => 16,
		'tiles_font_weight'   => '600',
		'tiles_text_color'    => '#2b2b2b',
		'tiles_upper'         => 0,
		'tiles_border'        => 0,
		'tiles_border_color'  => '#c4c4c4',
		'tiles_bg'            => '#ffffff',
		'tiles_hover_zoom'    => 1,
		'tiles_label_bg'      => 'none',    // 2.26.10: tło pod napisem – none | pill | band | glow
		'tiles_label_color'   => '#000000',
		'tiles_label_opacity' => 55,
		'tiles_label_blur'    => 4,         // rozmycie zdjęcia TYLKO pod napisem (szkło)
		'tiles_label_pos'     => 'center',  // center | bottom
		'tiles_collapse'      => 0,         // 2.26.12: kafle schowane w rozwijanym polu
		'm_tiles_collapse'    => 1,         // telefon – domyślnie schowane
		'tiles_collapse_title'=> 'Rozwiń',  // 2.26.20: było „Kategorie menu” (migracja style_v 5)
		'tiles_collapse_title_open' => 'Zwiń', // 2.26.20: napis, gdy kafle rozwinięte
		'tiles_wrap_gap'      => 16,        // odstęp pod całym blokiem kafli
		'm_on_tiles'          => 1,
		'm_tiles_style'       => 'photo',
		'm_tiles_cols'        => 2,
		'm_tiles_gap'         => 12,
		'm_tiles_height'      => 80,
		'm_tiles_radius'      => 10,
		'm_tiles_blur'        => 3,
		'm_tiles_overlay'     => 50,
		'm_tiles_font_size'   => 15,
		'm_tiles_font_weight' => '700',
		'm_tiles_text_color'  => '#ffffff',
		'm_tiles_upper'       => 0,
		'm_tiles_border'      => 0,
		'm_tiles_border_color'=> '#c4c4c4',
		'm_tiles_bg'          => '#3a3a3a',
		'm_tiles_hover_zoom'  => 1,

		// 2.26.6: strony sklepu WooCommerce (kategorie, sklep, podobne produkty).
		'shop_on'             => 1,
		'shop_center'         => 1,
		'shop_img_radius'     => 12,
		'shop_btn_style'      => 1,
		'shop_btn_full'       => 0,
		'shop_name_size'      => 17,
		'shop_name_weight'    => '700',
		'shop_price_size'     => 16,
		'shop_price_color_on' => 0,
		'shop_price_color'    => '#2b2b2b',
		'shop_card_gap'       => 8,
		'shop_hide_count'     => 1, // 2.26.7: „Wyświetlanie wszystkich wyników: N”
		'shop_hide_sort'      => 1, // 2.26.7: „Domyślne sortowanie”
		'shop_equal'          => 1, // 2.26.9: równe kafle – przyciski w jednej linii
		'gb_btn_style'        => 1, // 2.26.9: przyciski z bloku Gutenberga „Przyciski” w stylu listy
		'shop_related_title'  => 'Zamów razem', // 2.26.9: zamiast „Podobne produkty”

		// 2.26.6: strona pojedynczego produktu.
		'single_on'           => 1,
		'single_buy'          => 1,
		'single_one_title'    => 1,
		'single_layout'       => 1, // 2.26.7: do lewej, licznik i przycisk na dole kolumny (ilość nad przyciskiem)
		'single_harmono'      => 1, // 2.26.7: ramka „Harmonogram” zestawu na stronie produktu
		'single_head_align'   => 'right', // 2.26.8: nazwa i cena – left | center | right
		'single_buy_stack'    => 'stack', // 2.26.9: stack = ilość nad przyciskiem, row = obok siebie
		'single_tabs_line'    => 'accent', // 2.26.9: kreska nad zakładkami – accent | dark | theme
		'single_tab_cat'      => 1,        // 2.26.9: zakładka „Opis” → nazwa kategorii produktu
		'single_tab_catdesc'  => 1,        // 2.26.9: w zakładce opis kategorii + nazwa produktu zamiast „O produkcie”
		'm_on_single'         => 1,       // 2.26.9: telefon – ilość i przycisk obok siebie
		'm_single_buy_stack'  => 'center', // 2.26.9: telefon – wyśrodkowane, przycisk pod ilością
		'single_head_gap'     => 0,  // odstęp nazwa → cena (0 = motyw)
		'single_qty_size'     => 0,  // średnica − / + na stronie produktu (0 = jak na liście)
		'single_qty_font'     => 0,  // rozmiar liczby (0 = jak na liście)
		'single_btn_width'    => 0,  // szerokość przycisku w % kolumny (0 = automatycznie)
		'single_btn_height'   => 0,  // min. wysokość przycisku (0 = automatycznie)
		'm_single_qty_size'   => 54,
		'm_single_qty_font'   => 24,
		'm_single_btn_width'  => 90,
		'm_single_btn_height' => 56,
		'single_img_square'   => 1,
		'single_img_radius'   => 16,
		'single_thumb_radius' => 8,
		'single_title_size'   => 0,
		'single_price_size'   => 0,
		'single_price_color_on' => 0,
		'single_price_color'  => '#2b2b2b',

		// TELEFON – sekcje, które już przed 2.26.0 miały osobne wartości.
		'm_on_name'           => 1,
		'm_name_size'         => 16,
		'm_on_cat'            => 1,
		'm_cat_size'          => 22,
		'm_on_price'          => 1,
		'm_price_size'        => 34,
		'm_on_desc'           => 1,
		'm_desc_size'         => 13,
		'm_on_image'          => 1,
		'm_image_size'        => 112,
		'm_image_radius'      => 999, // duża wartość = pełne koło
	);
}

/**
 * Rejestr pól panelu – z niego powstaje formularz (obie zakładki), zapis
 * i dziedziczenie telefon ← komputer. 'shared' = pole wspólne dla obu
 * widoków (czcionki-nazwy, tytuły ramek); 'device' => false = sekcja bez
 * wersji telefonu.
 */
function rzd_list_style_fields() {
	$weight = array( '' => 'jak motyw', '400' => 'normalna', '500' => 'średnia', '600' => 'półgruba', '700' => 'gruba', '800' => 'bardzo gruba' );
	return array(
		'fonts'   => array( 'Czcionki ogólne', array(
			array( 't' => 'text', 'k' => 'heading_font', 'l' => 'Czcionka nagłówkowa (nazwa produktu, nagłówek kategorii)', 'shared' => 1 ),
			array( 't' => 'text', 'k' => 'body_font', 'l' => 'Czcionka treści (reszta tekstu na liście)', 'shared' => 1 ),
			array( 't' => 'note', 'l' => 'Nazwy czcionek z Google Fonts – wpisane dokładnie tak, jak tam widnieją. Wspólne dla telefonu i komputera.' ),
			array( 't' => 'number', 'k' => 'letter_spacing', 'l' => 'Odstęp między literami (nazwy, nagłówki)', 'step' => 0.1 ),
		) ),
		'name'    => array( 'Nazwa produktu', array(
			array( 't' => 'number', 'k' => 'name_size', 'l' => 'Rozmiar czcionki' ),
			array( 't' => 'color', 'k' => 'name_color', 'l' => 'Kolor', 'toggle' => 1 ),
			array( 't' => 'number', 'k' => 'name_gap', 'l' => 'Odstęp pod nazwą (0 = jak dotąd)' ),
		) ),
		'cat'     => array( 'Nagłówek kategorii', array(
			array( 't' => 'note', 'l' => 'Pojawia się, gdy w shortcodzie użyjesz parametru kategoria.' ),
			array( 't' => 'number', 'k' => 'cat_size', 'l' => 'Rozmiar czcionki' ),
			array( 't' => 'color', 'k' => 'cat_color', 'l' => 'Kolor', 'toggle' => 1 ),
		) ),
		'price'   => array( 'Cena', array(
			array( 't' => 'number', 'k' => 'price_size', 'l' => 'Rozmiar czcionki' ),
			array( 't' => 'color', 'k' => 'price_color', 'l' => 'Kolor', 'toggle' => 1 ),
			array( 't' => 'select', 'k' => 'price_cur_pos', 'l' => 'Waluta (zł)', 'o' => array( 'side' => 'obok ceny', 'below' => 'pod ceną', 'above' => 'nad ceną' ) ),
			array( 't' => 'number', 'k' => 'price_cur_size', 'l' => 'Wielkość waluty (% rozmiaru ceny)', 'u' => '%' ),
			array( 't' => 'number', 'k' => 'price_cur_gap', 'l' => 'Odstęp waluty od ceny (0 = automatycznie)' ),
			array( 't' => 'select', 'k' => 'price_cur_align', 'l' => 'Wyrównanie ceny i waluty (przy „pod ceną” / „nad ceną”)', 'o' => array( 'left' => 'do lewej', 'center' => 'do środka', 'right' => 'do prawej' ) ),
			array( 't' => 'number', 'k' => 'price_dec_size', 'l' => 'Wielkość groszy „,00” (% rozmiaru ceny)', 'u' => '%' ),
			array( 't' => 'select', 'k' => 'price_dec_align', 'l' => 'Grosze', 'o' => array( 'base' => 'w linii', 'top' => 'u góry (jak w karcie menu)' ) ),
		) ),
		'desc'    => array( 'Krótki opis', array(
			array( 't' => 'text', 'k' => 'desc_font', 'l' => 'Czcionka opisu (puste = jak reszta treści)', 'shared' => 1 ),
			array( 't' => 'number', 'k' => 'desc_size', 'l' => 'Rozmiar czcionki' ),
			array( 't' => 'color', 'k' => 'desc_color', 'l' => 'Kolor', 'toggle' => 1 ),
		) ),
		'image'   => array( 'Zdjęcie produktu', array(
			array( 't' => 'number', 'k' => 'image_size', 'l' => 'Rozmiar (szerokość i wysokość)' ),
			array( 't' => 'number', 'k' => 'image_radius', 'l' => 'Zaokrąglenie rogów (bardzo duża wartość = koło)' ),
			array( 't' => 'sub', 'l' => 'Zestaw z dwoma daniami – zdjęcie dzielone (lista, sklep i kategorie, strona produktu, koszyk, przegląd zamówienia)', 'shared' => 1 ),
			array( 't' => 'select', 'k' => 'set_split', 'l' => 'Podział zdjęcia', 'o' => array( 'diag' => 'po skosie – od prawego górnego do lewego dolnego rogu', 'vert' => 'pionowo – pół na pół' ), 'shared' => 1 ),
			array( 't' => 'number', 'k' => 'set_split_line', 'l' => 'Kreska podziału – grubość (0 = bez kreski)', 'step' => 0.5, 'shared' => 1 ),
			array( 't' => 'color', 'k' => 'set_split_color', 'l' => 'Kreska podziału – kolor', 'shared' => 1 ),
			array( 't' => 'note', 'l' => 'Pokazujemy najwyżej dwa dania. Checkbox „Zdjęcie” przy daniu w zestawie: zaznaczone jedno danie = tylko jego zdjęcie (bez podziału); kilka albo żadne = podział między dwa pierwsze dania z własnym zdjęciem. Ustawienia wspólne dla telefonu i komputera.', 'shared' => 1 ),
		) ),
		'button'  => array( 'Przycisk „Dodaj do koszyka”', array(
			array( 't' => 'select', 'k' => 'button_width', 'l' => 'Szerokość przycisku', 'o' => array( 'fill' => 'wypełnia resztę wiersza', 'auto' => 'dopasowana do napisu (węższa)' ) ),
			array( 't' => 'select', 'k' => 'button_align', 'l' => 'Położenie przycisku (przy „dopasowanej”)', 'o' => array( 'left' => 'obok licznika', 'right' => 'do prawej krawędzi' ) ),
			array( 't' => 'number', 'k' => 'button_padding_v', 'l' => 'Odstęp wewnętrzny góra / dół (przy „dopasowanej” decyduje o wysokości)' ),
			array( 't' => 'number', 'k' => 'button_padding_h', 'l' => 'Odstęp wewnętrzny lewo / prawo (przy „dopasowanej” decyduje o szerokości)' ),
			array( 't' => 'number', 'k' => 'button_font_size', 'l' => 'Wielkość czcionki' ),
			array( 't' => 'number', 'k' => 'button_radius', 'l' => 'Zaokrąglenie rogów' ),
			array( 't' => 'color', 'k' => 'button_bg', 'l' => 'Kolor tła (bez najechania)' ),
			array( 't' => 'color', 'k' => 'button_text_color', 'l' => 'Kolor tekstu (bez najechania)' ),
			array( 't' => 'color', 'k' => 'button_border_color', 'l' => 'Kolor obramowania (też akcent okienek)' ),
			array( 't' => 'color', 'k' => 'button_hover_bg', 'l' => 'Kolor tła po najechaniu' ),
			array( 't' => 'color', 'k' => 'button_hover_text', 'l' => 'Kolor tekstu po najechaniu' ),
		) ),
		'hover'   => array( 'Kolory przy najechaniu (produkt i ramki)', array(
			array( 't' => 'note', 'l' => 'Świadomie dwa różne kolory – przy tym samym ramka „znika” na tle podświetlonego wiersza.' ),
			array( 't' => 'color', 'k' => 'row_hover_bg', 'l' => 'Tło całego wiersza produktu' ),
			array( 't' => 'color', 'k' => 'box_hover_bg', 'l' => 'Tło ramki' ),
			array( 't' => 'color', 'k' => 'box_hover_border', 'l' => 'Obramowanie ramki' ),
		) ),
		'allergen' => array( 'Plakietki alergenów', array(
			array( 't' => 'color', 'k' => 'allergen_bg', 'l' => 'Kolor tła' ),
			array( 't' => 'color', 'k' => 'allergen_text', 'l' => 'Kolor tekstu' ),
			array( 't' => 'number', 'k' => 'allergen_radius', 'l' => 'Zaokrąglenie rogów' ),
		) ),
		'boxes'   => array( 'Ramki rozwijane (Harmonogram, Harmonogram dostaw, Pełny opis)', array(
			array( 't' => 'number', 'k' => 'box_border_width', 'l' => 'Grubość ramki', 'step' => 0.5 ),
			array( 't' => 'color', 'k' => 'box_border_color', 'l' => 'Kolor ramki' ),
			array( 't' => 'number', 'k' => 'box_radius', 'l' => 'Zaokrąglenie rogów' ),
			array( 't' => 'number', 'k' => 'box_pad_v', 'l' => 'Odstęp wewnętrzny – góra/dół' ),
			array( 't' => 'number', 'k' => 'box_pad_h', 'l' => 'Odstęp wewnętrzny – boki' ),
			array( 't' => 'color', 'k' => 'box_bg', 'l' => 'Kolor tła', 'toggle' => 1 ),
			array( 't' => 'number', 'k' => 'box_title_size', 'l' => 'Rozmiar tytułu' ),
			array( 't' => 'color', 'k' => 'box_title_color', 'l' => 'Kolor tytułu' ),
			array( 't' => 'check', 'k' => 'box_arrow_on', 'l' => 'Pokazuj strzałkę ▶ przed tytułem' ),
			array( 't' => 'sub', 'l' => 'Każda ramka osobno (puste pole tytułu = tytuł domyślny; tytuły wspólne dla obu widoków)' ),
			array( 't' => 'title', 'k' => 'box_harmono_title', 'l' => 'Tytuł: dni zestawu w menu', 'shared' => 1 ),
			array( 't' => 'check', 'k' => 'box_harmono_border', 'l' => 'Ramka wokół: dni zestawu w menu' ),
			array( 't' => 'number', 'k' => 'harmono_days_back', 'l' => 'Harmonogram – ile minionych dni pokazywać w okienku (0 = bez historii, max 60)', 'u' => 'dni', 'shared' => 1 ),
			array( 't' => 'title', 'k' => 'box_delivery_title', 'l' => 'Tytuł: godziny dostaw produktu', 'shared' => 1 ),
			array( 't' => 'check', 'k' => 'box_delivery_border', 'l' => 'Ramka wokół: godziny dostaw' ),
			array( 't' => 'title', 'k' => 'box_more_title', 'l' => 'Tytuł: pełny opis', 'shared' => 1 ),
			array( 't' => 'check', 'k' => 'box_more_border', 'l' => 'Ramka wokół: pełny opis' ),
			array( 't' => 'title', 'k' => 'box_allergen_title', 'l' => 'Tytuł: alergeny (na telefonie; liczba alergenów dopisuje się sama)', 'shared' => 1 ),
			array( 't' => 'check', 'k' => 'box_allergen_border', 'l' => 'Ramka wokół: alergeny' ),
		) ),
		'qty'     => array( 'Licznik ilości (− 1 +)', array(
			array( 't' => 'check', 'k' => 'qty_border_on', 'l' => 'Ramka wokół licznika (i linie przy − / +)' ),
			array( 't' => 'number', 'k' => 'qty_border_width', 'l' => 'Grubość ramki', 'step' => 0.5 ),
			array( 't' => 'color', 'k' => 'qty_border_color', 'l' => 'Kolor ramki' ),
			array( 't' => 'number', 'k' => 'qty_radius', 'l' => 'Zaokrąglenie rogów licznika' ),
			array( 't' => 'color', 'k' => 'qty_bg', 'l' => 'Tło pola z liczbą' ),
			array( 't' => 'number', 'k' => 'qty_font_size', 'l' => 'Rozmiar liczby' ),
			array( 't' => 'number', 'k' => 'qty_input_width', 'l' => 'Szerokość pola z liczbą (0 = automatycznie)' ),
			array( 't' => 'number', 'k' => 'qty_height', 'l' => 'Wysokość licznika i przycisku „Dodaj do koszyka”' ),
			array( 't' => 'sub', 'l' => 'Przyciski − i +' ),
			array( 't' => 'select', 'k' => 'qty_btn_shape', 'l' => 'Kształt', 'o' => array( 'circle' => 'koło', 'rect' => 'prostokąt' ) ),
			array( 't' => 'number', 'k' => 'qty_circle_size', 'l' => 'Koło: średnica' ),
			array( 't' => 'number', 'k' => 'qty_circle_border_w', 'l' => 'Koło: grubość obwódki (0 = bez)', 'step' => 0.5 ),
			array( 't' => 'color', 'k' => 'qty_circle_border_c', 'l' => 'Koło: kolor obwódki' ),
			array( 't' => 'number', 'k' => 'qty_btn_width', 'l' => 'Prostokąt: szerokość' ),
			array( 't' => 'number', 'k' => 'qty_btn_radius', 'l' => 'Prostokąt: zaokrąglenie rogów' ),
			array( 't' => 'color', 'k' => 'qty_btn_bg', 'l' => 'Kolor tła' ),
			array( 't' => 'color', 'k' => 'qty_btn_text', 'l' => 'Kolor znaku − / +' ),
			array( 't' => 'color', 'k' => 'qty_btn_hover_bg', 'l' => 'Kolor tła po najechaniu' ),
			array( 't' => 'number', 'k' => 'qty_gap', 'l' => 'Odstęp między licznikiem a „Dodaj do koszyka”' ),
			array( 't' => 'note', 'l' => 'Zaokrąglone przyciski − / + wyglądają najlepiej z wyłączoną ramką licznika.' ),
		) ),
		'popup'   => array( 'Okienka (termin dostawy, dostosuj produkt, dodano do koszyka, harmonogram)', array(
			array( 't' => 'number', 'k' => 'popup_opacity', 'l' => 'Krycie tła okienka (30–100; 100 = pełny kolor tła)', 'u' => '%' ),
			array( 't' => 'color', 'k' => 'popup_bg_color', 'l' => 'Kolor tła okienka (taki przy 100 % krycia)' ),
			array( 't' => 'color', 'k' => 'popup_text_color', 'l' => 'Kolor tekstu w okienku (opisy i etykiety – ten sam, trochę jaśniejszy/ciemniejszy)' ),
			array( 't' => 'number', 'k' => 'popup_blur', 'l' => 'Rozmycie strony pod okienkiem (0 = bez)' ),
			array( 't' => 'note', 'l' => 'Im mniejsze krycie, tym bardziej prześwituje strona. Przy kolorowych zdjęciach pod spodem pomaga rozmycie i większa, grubsza czcionka.' ),
			array( 't' => 'sub', 'l' => 'Czcionki' ),
			array( 't' => 'number', 'k' => 'popup_title_size', 'l' => 'Tytuł – rozmiar' ),
			array( 't' => 'weight', 'k' => 'popup_title_weight', 'l' => 'Tytuł – grubość', 'o' => $weight ),
			array( 't' => 'number', 'k' => 'popup_text_size', 'l' => 'Tekst i komunikaty – rozmiar' ),
			array( 't' => 'weight', 'k' => 'popup_text_weight', 'l' => 'Tekst i komunikaty – grubość', 'o' => $weight ),
			array( 't' => 'number', 'k' => 'popup_label_size', 'l' => 'Etykiety pól (Miejscowość, Data…) – rozmiar' ),
			array( 't' => 'weight', 'k' => 'popup_label_weight', 'l' => 'Etykiety pól – grubość', 'o' => $weight ),
			array( 't' => 'number', 'k' => 'popup_tile_size', 'l' => 'Kafelki godzin – rozmiar' ),
			array( 't' => 'weight', 'k' => 'popup_tile_weight', 'l' => 'Kafelki godzin – grubość (wybrany kafelek zawsze gruby)', 'o' => $weight ),
			array( 't' => 'sub', 'l' => 'Przyciski' ),
			array( 't' => 'number', 'k' => 'popup_btn_size', 'l' => 'Rozmiar czcionki' ),
			array( 't' => 'weight', 'k' => 'popup_btn_weight', 'l' => 'Grubość czcionki (główny przycisk o stopień grubszy)', 'o' => $weight ),
			array( 't' => 'number', 'k' => 'popup_btn_pad_v', 'l' => 'Wysokość (odstęp pionowy)' ),
			array( 't' => 'number', 'k' => 'popup_btn_width', 'l' => 'Szerokość każdego z dwóch przycisków (20–48 % okienka)', 'u' => '%' ),
			array( 't' => 'number', 'k' => 'popup_btn_radius', 'l' => 'Zaokrąglenie rogów' ),
		) ),
		'tiles'   => array( 'Kafle kategorii – shortcode [kategorie_zamowien]', array(
			array( 't' => 'check', 'k' => 'tiles_collapse', 'l' => 'Schowaj kafle w rozwijanym polu (kafle pokazują się po kliknięciu)' ),
			array( 't' => 'title', 'k' => 'tiles_collapse_title', 'l' => 'Napis na rozwijanym polu (zwinięte)', 'shared' => 1 ),
			array( 't' => 'title', 'k' => 'tiles_collapse_title_open', 'l' => 'Napis na rozwijanym polu (rozwinięte)', 'shared' => 1 ),
			array( 't' => 'number', 'k' => 'tiles_wrap_gap', 'l' => 'Odstęp pod całym blokiem kafli' ),
			array( 't' => 'select', 'k' => 'tiles_style', 'l' => 'Wygląd kafla', 'o' => array( 'photo' => 'zdjęcie w tle, napis na zdjęciu', 'below' => 'zdjęcie nad napisem', 'plain' => 'sam napis (bez zdjęcia)' ) ),
			array( 't' => 'number', 'k' => 'tiles_cols', 'l' => 'Kafli w wierszu (1–8)' ),
			array( 't' => 'number', 'k' => 'tiles_gap', 'l' => 'Odstęp między kaflami' ),
			array( 't' => 'number', 'k' => 'tiles_height', 'l' => 'Wysokość kafla (zdjęcie w tle / sam napis)' ),
			array( 't' => 'number', 'k' => 'tiles_radius', 'l' => 'Zaokrąglenie rogów' ),
			array( 't' => 'sub', 'l' => 'Zdjęcie w tle' ),
			array( 't' => 'number', 'k' => 'tiles_blur', 'l' => 'Rozmycie zdjęcia (0 = ostre)' ),
			array( 't' => 'number', 'k' => 'tiles_overlay', 'l' => 'Przyciemnienie zdjęcia (0–90)', 'u' => '%' ),
			array( 't' => 'check', 'k' => 'tiles_hover_zoom', 'l' => 'Lekkie powiększenie zdjęcia po najechaniu' ),
			array( 't' => 'sub', 'l' => 'Napis' ),
			array( 't' => 'number', 'k' => 'tiles_font_size', 'l' => 'Rozmiar czcionki' ),
			array( 't' => 'weight', 'k' => 'tiles_font_weight', 'l' => 'Grubość czcionki', 'o' => $weight ),
			array( 't' => 'color', 'k' => 'tiles_text_color', 'l' => 'Kolor napisu' ),
			array( 't' => 'check', 'k' => 'tiles_upper', 'l' => 'WIELKIE LITERY' ),
			array( 't' => 'sub', 'l' => 'Tło pod napisem (czytelny napis nawet na ostrym zdjęciu)' ),
			array( 't' => 'select', 'k' => 'tiles_label_bg', 'l' => 'Rodzaj', 'o' => array( 'none' => 'brak', 'glow' => 'miękka poświata za napisem', 'pill' => 'zaokrąglona plakietka', 'band' => 'pas na całą szerokość kafla' ) ),
			array( 't' => 'color', 'k' => 'tiles_label_color', 'l' => 'Kolor tła napisu' ),
			array( 't' => 'number', 'k' => 'tiles_label_opacity', 'l' => 'Krycie tła napisu (0–100)', 'u' => '%' ),
			array( 't' => 'number', 'k' => 'tiles_label_blur', 'l' => 'Rozmycie zdjęcia pod napisem – efekt szkła (0 = bez; plakietka i pas)' ),
			array( 't' => 'select', 'k' => 'tiles_label_pos', 'l' => 'Położenie napisu', 'o' => array( 'center' => 'na środku', 'bottom' => 'na dole kafla' ) ),
			array( 't' => 'sub', 'l' => 'Tło i ramka' ),
			array( 't' => 'color', 'k' => 'tiles_bg', 'l' => 'Tło kafla (sam napis; przy zdjęciu w tle – gdy kategoria nie ma zdjęcia)' ),
			array( 't' => 'check', 'k' => 'tiles_border', 'l' => 'Ramka wokół kafla' ),
			array( 't' => 'color', 'k' => 'tiles_border_color', 'l' => 'Kolor ramki' ),
			array( 't' => 'note', 'l' => 'Zdjęcie kafla to zdjęcie kategorii z Produkty → Kategorie → Edytuj → Zdjęcie. Tam też jest „Adres docelowy”, pod który prowadzi kafel.' ),
		) ),
		'shop'    => array( 'Strony sklepu WooCommerce (kategorie, sklep, podobne produkty)', array(
			array( 't' => 'check', 'k' => 'shop_on', 'l' => 'Stosuj nasz wygląd na stronach sklepu (wyłączone = wygląd motywu)' ),
			array( 't' => 'check', 'k' => 'shop_center', 'l' => 'Wyrównaj do środka (zdjęcie, kategoria, nazwa, cena, przycisk)' ),
			array( 't' => 'check', 'k' => 'shop_hide_count', 'l' => 'Ukryj „Wyświetlanie wszystkich wyników: …”' ),
			array( 't' => 'check', 'k' => 'shop_hide_sort', 'l' => 'Ukryj „Domyślne sortowanie” (wybór kolejności)' ),
			array( 't' => 'check', 'k' => 'shop_equal', 'l' => 'Równe kafle – ceny i przyciski „Dodaj do koszyka” w jednej linii (nawet gdy nazwa ma kilka wierszy)' ),
			array( 't' => 'title', 'k' => 'shop_related_title', 'l' => 'Nagłówek nad produktami pod kartą produktu (zamiast „Podobne produkty”; puste pole = „Zamów razem”)', 'shared' => 1 ),
			array( 't' => 'number', 'k' => 'shop_img_radius', 'l' => 'Zaokrąglenie rogów zdjęć' ),
			array( 't' => 'number', 'k' => 'shop_card_gap', 'l' => 'Odstęp między zdjęciem, nazwą, ceną i przyciskiem' ),
			array( 't' => 'number', 'k' => 'shop_name_size', 'l' => 'Nazwa produktu – rozmiar' ),
			array( 't' => 'weight', 'k' => 'shop_name_weight', 'l' => 'Nazwa produktu – grubość', 'o' => $weight ),
			array( 't' => 'number', 'k' => 'shop_price_size', 'l' => 'Cena – rozmiar' ),
			array( 't' => 'color', 'k' => 'shop_price_color', 'l' => 'Cena – kolor', 'toggle' => 1 ),
			array( 't' => 'check', 'k' => 'shop_btn_style', 'l' => 'Przycisk „Dodaj do koszyka” w stylu listy (kolory, odstępy, zaokrąglenie, czcionka z sekcji „Przycisk »Dodaj do koszyka«”)' ),
			array( 't' => 'check', 'k' => 'shop_btn_full', 'l' => 'Przycisk na całą szerokość kafla' ),
			array( 't' => 'check', 'k' => 'gb_btn_style', 'l' => 'Pozostałe przyciski w stylu listy: blok „Przyciski” z edytora stron (np. „Idź do koszyka”), w koszyku „Wróć do listy produktów” i „Przejdź do płatności”, w kasie „Kupuję i płacę”' ),
		) ),
		'single'  => array( 'Strona produktu', array(
			array( 't' => 'check', 'k' => 'single_on', 'l' => 'Stosuj nasz wygląd na stronie produktu (wyłączone = wygląd motywu)', 'shared' => 1 ),
			array( 't' => 'check', 'k' => 'single_buy', 'l' => 'Licznik ilości (− / +) i przycisk „Dodaj do koszyka” jak na liście', 'shared' => 1 ),
			array( 't' => 'check', 'k' => 'single_one_title', 'l' => 'Jeden tytuł (ukryj tytuł motywu, gdy wtyczka pokazuje własny – np. nazwa zestawu)', 'shared' => 1 ),
			array( 't' => 'check', 'k' => 'single_layout', 'l' => 'Układ: wszystko do lewej, na dole kolumny ilość, a pod nią „Dodaj do koszyka”' ),
			array( 't' => 'check', 'k' => 'single_harmono', 'l' => 'Pokaż „Harmonogram” przy zestawach (to samo okienko co na liście)', 'shared' => 1 ),
			array( 't' => 'select', 'k' => 'single_head_align', 'l' => 'Nazwa i cena – wyrównanie', 'o' => array( 'left' => 'do lewej', 'center' => 'do środka', 'right' => 'do prawej' ) ),
			array( 't' => 'select', 'k' => 'single_buy_stack', 'l' => 'Ilość i „Dodaj do koszyka”', 'o' => array( 'stack' => 'ilość nad przyciskiem, do lewej', 'center' => 'ilość nad przyciskiem, wyśrodkowane', 'row' => 'obok siebie (przycisk wypełnia resztę)' ) ),
			array( 't' => 'number', 'k' => 'single_qty_size', 'l' => 'Przyciski − / + – średnica (0 = jak na liście)' ),
			array( 't' => 'number', 'k' => 'single_qty_font', 'l' => 'Liczba sztuk – rozmiar (0 = jak na liście)' ),
			array( 't' => 'number', 'k' => 'single_btn_width', 'l' => '„Dodaj do koszyka” – szerokość (0 = automatycznie)', 'u' => '%' ),
			array( 't' => 'number', 'k' => 'single_btn_height', 'l' => '„Dodaj do koszyka” – wysokość (0 = automatycznie)' ),
			array( 't' => 'select', 'k' => 'single_tabs_line', 'l' => 'Kreska nad zakładkami (Opis / Opinie)', 'o' => array( 'accent' => 'cienka, w kolorze przycisków', 'dark' => 'cienka, czarna', 'theme' => 'jak motyw' ) ),
			array( 't' => 'check', 'k' => 'single_tab_cat', 'l' => 'Zakładka „Opis” nazywa się jak kategoria produktu (np. „Bajgle”)', 'shared' => 1 ),
			array( 't' => 'check', 'k' => 'single_tab_catdesc', 'l' => 'W zakładce: opis kategorii, pod nim nazwa produktu (zamiast „O produkcie”) i opis produktu', 'shared' => 1 ),
			array( 't' => 'check', 'k' => 'single_img_square', 'l' => 'Zdjęcie w kwadracie (przycięte do środka)' ),
			array( 't' => 'number', 'k' => 'single_img_radius', 'l' => 'Zaokrąglenie rogów zdjęcia (999 = koło)' ),
			array( 't' => 'number', 'k' => 'single_thumb_radius', 'l' => 'Zaokrąglenie miniaturek galerii (999 = koła)' ),
			array( 't' => 'number', 'k' => 'single_title_size', 'l' => 'Tytuł – rozmiar (0 = jak motyw)' ),
			array( 't' => 'number', 'k' => 'single_price_size', 'l' => 'Cena – rozmiar (0 = jak motyw)' ),
			array( 't' => 'number', 'k' => 'single_head_gap', 'l' => 'Odstęp między nazwą a ceną (0 = jak motyw)' ),
			array( 't' => 'color', 'k' => 'single_price_color', 'l' => 'Cena – kolor', 'toggle' => 1 ),
			array( 't' => 'note', 'l' => 'Wygląd licznika i przycisku bierze się z sekcji „Licznik ilości” i „Przycisk »Dodaj do koszyka«” – zmieniasz raz, działa na liście i na stronie produktu. „Podobne produkty” pod produktem mają wygląd z sekcji „Strony sklepu WooCommerce”.' ),
		) ),
		'gap'     => array( 'Odstępy', array(
			array( 't' => 'number', 'k' => 'element_gap', 'l' => 'Odstęp między elementami pod zdjęciem (alergeny, ramki, licznik, opis)' ),
		) ),
	);
}

// Klucze sekcji, które telefon może mieć inaczej (bez pól wspólnych).
function rzd_style_section_keys( $fields ) {
	$keys = array();
	foreach ( $fields as $f ) {
		if ( empty( $f['k'] ) || ! empty( $f['shared'] ) ) {
			continue;
		}
		$keys[] = $f['k'];
		if ( ! empty( $f['toggle'] ) ) {
			$keys[] = $f['k'] . '_on';
		}
	}
	return $keys;
}

// Tytuły ramek rozwijanych: 'harmono' | 'delivery' | 'more'.
function rzd_list_label( $which ) {
	$s   = rzd_list_style_get();
	$key = 'box_' . $which . '_title';
	if ( isset( $s[ $key ] ) && '' !== trim( (string) $s[ $key ] ) ) {
		return (string) $s[ $key ];
	}
	$d = rzd_list_style_defaults();
	return isset( $d[ $key ] ) ? $d[ $key ] : '';
}

/**
 * Migracja do 2.26.0: przed nią wartości bazowe były TELEFONEM, a pola
 * *_desktop komputerem (tylko rozmiary czcionek i zdjęcie). Teraz baza =
 * komputer, telefon = m_*. Przenosimy dokładnie te same liczby, więc wygląd
 * na obu urządzeniach się nie zmienia.
 */
function rzd_list_style_migrate_v2( $saved ) {
	$pairs = array(
		'name_size'    => array( 'name_size_desktop', 20 ),
		'cat_size'     => array( 'cat_size_desktop', 26 ),
		'price_size'   => array( 'price_size_desktop', 28 ),
		'desc_size'    => array( 'desc_size_desktop', 14 ),
		'image_size'   => array( 'image_size_desktop', 160 ),
		'image_radius' => array( 'image_radius_desktop', 16 ),
	);
	foreach ( $pairs as $k => $d ) {
		if ( isset( $saved[ $k ] ) ) {
			$saved[ 'm_' . $k ] = $saved[ $k ]; // telefon = dotychczasowa wartość bazowa
		}
		$saved[ $k ] = isset( $saved[ $d[0] ] ) ? $saved[ $d[0] ] : $d[1]; // komputer = dotychczasowe *_desktop
		unset( $saved[ $d[0] ] );
	}
	foreach ( array( 'name', 'cat', 'price', 'desc', 'image' ) as $sid ) {
		$saved[ 'm_on_' . $sid ] = 1;
	}
	$saved['style_v'] = 2;
	return $saved;
}

function rzd_list_style_get( $fresh = false ) {
	// 2.26.13: wynik trzymany na czas żądania – funkcję woła każdy wiersz listy
	// (etykiety ramek), strona produktu, okienka… a wp_parse_args na ~250
	// ustawieniach to niepotrzebna praca przy każdym wywołaniu.
	static $memo = null;
	if ( null !== $memo && ! $fresh ) {
		return $memo;
	}
	$saved = get_option( 'rzd_list_style', array() );
	$saved = is_array( $saved ) ? $saved : array();
	if ( $saved && ( empty( $saved['style_v'] ) || (int) $saved['style_v'] < 3 ) ) {
		$saved['style_v'] = isset( $saved['style_v'] ) ? $saved['style_v'] : 0;
		if ( empty( $saved['style_v'] ) ) {
			$saved = rzd_list_style_migrate_v2( $saved );
		}
		// v3 (2.26.0): pole rozmiaru ceny wreszcie działa (wcześniej plik CSS
		// wymuszał 34 px z !important) – ustawiamy 34 px, czyli to, co klienci
		// faktycznie widzieli, na obu urządzeniach.
		if ( (int) ( isset( $saved['style_v'] ) ? $saved['style_v'] : 0 ) < 3 ) {
			$saved['price_size']   = 34;
			$saved['m_price_size'] = 34;
		}
		$saved['style_v'] = 3;
	}
	// v4 (2.26.0): uzgodnione zmiany wyglądu – „Możliwe dostawy” (tylko gdy tytuł
	// był domyślny), okrągłe − / + bez ramki licznika, większy odstęp do „Dodaj”.
	if ( $saved && (int) $saved['style_v'] < 4 ) {
		if ( ! isset( $saved['box_delivery_title'] ) || 'Harmonogram dostaw dla produktu' === $saved['box_delivery_title'] ) {
			$saved['box_delivery_title'] = 'Możliwe dostawy';
		}
		$saved['qty_btn_shape'] = 'circle';
		$saved['qty_border_on'] = 0;
		if ( ! isset( $saved['qty_gap'] ) || 10 == $saved['qty_gap'] ) { // phpcs:ignore
			$saved['qty_gap'] = 16;
		}
		$saved['style_v'] = 4;
		update_option( 'rzd_list_style', $saved, true );
	}
	// v5 (2.26.20): rozwijane pole kafli – „Rozwiń” / „Zwiń” zamiast „Kategorie menu”
	// (tylko gdy napis był domyślny; własny napis zostaje).
	if ( $saved && (int) $saved['style_v'] < 5 ) {
		if ( ! isset( $saved['tiles_collapse_title'] ) || 'Kategorie menu' === $saved['tiles_collapse_title'] ) {
			$saved['tiles_collapse_title'] = 'Rozwiń';
		}
		$saved['style_v'] = 5;
		update_option( 'rzd_list_style', $saved, true );
	}
	$memo = wp_parse_args( $saved, rzd_list_style_defaults() );
	return $memo;
}

// Wartości dla urządzenia: 'desktop' = baza; 'mobile' = baza + sekcje „inaczej”.
function rzd_style_for_device( $s, $device ) {
	if ( 'mobile' !== $device ) {
		return $s;
	}
	foreach ( rzd_list_style_fields() as $sid => $sec ) {
		if ( empty( $s[ 'm_on_' . $sid ] ) ) {
			continue;
		}
		foreach ( rzd_style_section_keys( $sec[1] ) as $k ) {
			if ( isset( $s[ 'm_' . $k ] ) ) {
				$s[ $k ] = $s[ 'm_' . $k ];
			}
		}
	}
	return $s;
}

/**
 * 2.26.6: rozbija cenę z WooCommerce na części, które da się osobno stylować:
 * <bdi class="rl-pbdi"><span class="rl-pnum">12<span class="rl-pdec">,00</span></span>
 * <span class="woocommerce-Price-currencySymbol">zł</span></bdi>. Działa też
 * dla promocji (<del>/<ins>) i zakresów cen – każda kwota osobno. Kolejność
 * liczba/waluta zostaje taka, jak w ustawieniach sklepu.
 */
function rzd_price_split_html( $html ) {
	$dec = function_exists( 'wc_get_price_decimal_separator' ) ? wc_get_price_decimal_separator() : ',';
	return preg_replace_callback( '#<bdi>(.*?)</bdi>#s', function ( $m ) use ( $dec ) {
		// 2.26.10: waluta rozpoznawana po samej klasie (dowolne inne atrybuty/cudzysłowy).
		$cur_re = '#(<span[^>]*class=["\'][^"\']*woocommerce-Price-currencySymbol[^"\']*["\'][^>]*>.*?</span>)#s';
		$parts  = preg_split( $cur_re, $m[1], -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY );
		$out    = '';
		foreach ( (array) $parts as $part ) {
			if ( preg_match( '#^<span[^>]*woocommerce-Price-currencySymbol#', $part ) ) {
				$out .= '<span class="woocommerce-Price-currencySymbol">' . wp_strip_all_tags( $part ) . '</span>';
				continue;
			}
			$t = trim( str_replace( array( '&nbsp;', "\xC2\xA0" ), ' ', $part ) );
			if ( '' === $t ) {
				continue;
			}
			$pos = ( '' !== $dec && false === strpos( $t, '<' ) ) ? strrpos( $t, $dec ) : false;
			if ( false !== $pos ) {
				$t = substr( $t, 0, $pos ) . '<span class="rl-pdec">' . substr( $t, $pos ) . '</span>';
			}
			$out .= '<span class="rl-pnum">' . $t . '</span>';
		}
		return '<bdi class="rl-pbdi">' . $out . '</bdi>';
	}, (string) $html );
}

/**
 * 2.26.10: cena składana od zera z liczby (bez parsowania HTML motywu/wtyczek):
 * <span class="woocommerce-Price-amount amount"><bdi class="rl-pbdi">
 *   <span class="rl-pnum">22<span class="rl-pdec">,00</span></span>
 *   <span class="woocommerce-Price-currencySymbol">zł</span></bdi></span>
 * Kolejność liczba/waluta wg ustawienia sklepu (Waluta → Pozycja).
 */
function rzd_price_parts_html( $amount ) {
	$amount = (float) $amount;
	$decs   = function_exists( 'wc_get_price_decimals' ) ? wc_get_price_decimals() : 2;
	$dsep   = function_exists( 'wc_get_price_decimal_separator' ) ? wc_get_price_decimal_separator() : ',';
	$tsep   = function_exists( 'wc_get_price_thousand_separator' ) ? wc_get_price_thousand_separator() : ' ';
	$num    = number_format( abs( $amount ), $decs, $dsep, $tsep );
	$int    = $num;
	$frac   = '';
	if ( $decs > 0 && '' !== $dsep && false !== ( $pos = strrpos( $num, $dsep ) ) ) {
		$int  = substr( $num, 0, $pos );
		$frac = substr( $num, $pos );
	}
	$pnum = '<span class="rl-pnum">' . ( $amount < 0 ? '-' : '' ) . esc_html( $int ) . ( '' !== $frac ? '<span class="rl-pdec">' . esc_html( $frac ) . '</span>' : '' ) . '</span>';
	$pcur = '<span class="woocommerce-Price-currencySymbol">' . ( function_exists( 'get_woocommerce_currency_symbol' ) ? get_woocommerce_currency_symbol() : 'zł' ) . '</span>';
	$left = in_array( get_option( 'woocommerce_currency_pos', 'right_space' ), array( 'left', 'left_space' ), true );
	return '<span class="woocommerce-Price-amount amount"><bdi class="rl-pbdi">' . ( $left ? $pcur . $pnum : $pnum . $pcur ) . '</bdi></span>';
}

/**
 * Cena produktu na liście: zwykła cena – składana od zera (pewne części do
 * stylowania); promocja, zakres cen (warianty), grupowy – HTML WooCommerce
 * rozbity przez rzd_price_split_html().
 */
function rzd_list_price_html( $p ) {
	if ( ! $p || '' === (string) $p->get_price() ) {
		return $p ? $p->get_price_html() : '';
	}
	if ( $p->is_on_sale() || $p->is_type( array( 'variable', 'grouped' ) ) ) {
		return rzd_price_split_html( $p->get_price_html() );
	}
	$html = rzd_price_parts_html( wc_get_price_to_display( $p ) );
	return apply_filters( 'rzd_list_price_html', $html . $p->get_price_suffix(), $p );
}

/* ============================================================
 * 2. GENEROWANIE CSS Z USTAWIEŃ
 * ============================================================ */
// Granica telefon/komputer – ta sama co przed 2.26.0.
define( 'RZD_STYLE_BREAKPOINT', 900 );

function rzd_list_style_css() {
	$s  = rzd_list_style_get();
	$bp = RZD_STYLE_BREAKPOINT;
	$any_mobile = false;
	foreach ( array_keys( rzd_list_style_fields() ) as $sid ) {
		if ( ! empty( $s[ 'm_on_' . $sid ] ) ) {
			$any_mobile = true;
			break;
		}
	}
	if ( ! $any_mobile ) {
		return rzd_list_style_rules( $s ); // telefon = komputer: jeden zestaw reguł
	}
	// Dwa rozłączne zakresy: „not all and (min-width)” to dokładne dopełnienie –
	// bez dziury przy ułamkowych szerokościach (zoom przeglądarki).
	return "@media (min-width: {$bp}px) {\n" . rzd_list_style_rules( rzd_style_for_device( $s, 'desktop' ) ) . "}\n"
		. "@media not all and (min-width: {$bp}px) {\n" . rzd_list_style_rules( rzd_style_for_device( $s, 'mobile' ) ) . "}\n";
}

// Reguły dla JEDNEGO urządzenia (bez @media) – $s już rozwiązane.
function rzd_list_style_rules( $s ) {
	$css = '';

	// Czcionki + odstęp liter (nazwa produktu i nagłówek kategorii)
	$css .= ".rl-name, .rl-cat-heading { font-family: '" . esc_attr( $s['heading_font'] ) . "', Georgia, serif; letter-spacing: " . esc_attr( $s['letter_spacing'] ) . "px; }\n";
	$css .= ".rl { font-family: '" . esc_attr( $s['body_font'] ) . "', -apple-system, BlinkMacSystemFont, sans-serif; }\n";

	$css .= ".rl-name { font-size: " . (float) $s['name_size'] . "px; }\n";
	if ( (float) $s['name_gap'] > 0 ) { // 2.26.13: odstęp pod nazwą (np. nad zdjęciem na telefonie)
		$css .= ".rl2-row > .rl-name, .rl-name { margin-bottom: " . (float) $s['name_gap'] . "px !important; }\n";
	}
	if ( ! empty( $s['name_color_on'] ) ) {
		$css .= ".rl-name { color: " . esc_attr( $s['name_color'] ) . " !important; }\n";
	}
	$css .= ".rl-cat-heading { font-size: " . (float) $s['cat_size'] . "px; }\n";
	if ( ! empty( $s['cat_color_on'] ) ) {
		$css .= ".rl-cat-heading { color: " . esc_attr( $s['cat_color'] ) . "; }\n";
	}
	$css .= ".rl-price, .rl2-row > .rl-price { font-size: " . (float) $s['price_size'] . "px; }\n";
	if ( ! empty( $s['price_color_on'] ) ) {
		$css .= ".rl-price { color: " . esc_attr( $s['price_color'] ) . "; }\n";
	}
	// 2.26.6: części ceny (rzd_price_split_html): .rl-pnum = liczba, .rl-pdec = grosze,
	// .woocommerce-Price-currencySymbol = waluta; .rl-pbdi = całość jednej kwoty.
	$cur_pct = max( 20, min( 200, (float) $s['price_cur_size'] ) ) / 100;
	$dec_pct = max( 20, min( 200, (float) $s['price_dec_size'] ) ) / 100;
	$css .= ".rl-price .rl-pbdi { display: inline-flex; align-items: baseline; gap: " . ( (float) $s['price_cur_gap'] > 0 ? (float) $s['price_cur_gap'] . 'px' : '.12em' ) . "; white-space: nowrap; }\n";
	$css .= ".rl-price .rl-pnum { line-height: 1; }\n";
	$css .= ".rl-price .rl-pbdi .woocommerce-Price-currencySymbol { font-size: {$cur_pct}em; line-height: 1; }\n";
	$css .= ".rl-price .rl-pdec { font-size: {$dec_pct}em; }\n";
	if ( 'top' === $s['price_dec_align'] ) {
		$css .= ".rl-price .rl-pdec { vertical-align: top; line-height: 1; }\n";
	}
	$cgap = (float) $s['price_cur_gap'];
	if ( in_array( $s['price_cur_pos'], array( 'below', 'above' ), true ) ) {
		$ai = array( 'left' => 'flex-start', 'center' => 'center', 'right' => 'flex-end' );
		$al = isset( $ai[ $s['price_cur_align'] ] ) ? $ai[ $s['price_cur_align'] ] : 'center';
		$css .= ".rl-price .rl-pbdi { flex-direction: column; align-items: {$al}; gap: " . ( $cgap > 0 ? $cgap . 'px' : '.05em' ) . "; }\n";
		$css .= ".rl-price .rl-pbdi .woocommerce-Price-currencySymbol { order: " . ( 'above' === $s['price_cur_pos'] ? '-1' : '2' ) . "; }\n";
	}
	if ( $s['desc_font'] ) {
		$css .= ".rl-short { font-family: '" . esc_attr( $s['desc_font'] ) . "', -apple-system, BlinkMacSystemFont, sans-serif; }\n";
	}
	$css .= ".rl-short { font-size: " . (float) $s['desc_size'] . "px; }\n";
	if ( ! empty( $s['desc_color_on'] ) ) {
		$css .= ".rl-short { color: " . esc_attr( $s['desc_color'] ) . "; }\n";
	}

	// Zdjęcie
	$css .= ".rl-thumb, .rl-thumb img { width: " . (int) $s['image_size'] . "px !important; height: " . (int) $s['image_size'] . "px !important; flex-basis: " . (int) $s['image_size'] . "px !important; }\n";
	$css .= ".rl-thumb img { border-radius: " . (int) $s['image_radius'] . "px !important; }\n";

	// Przycisk "Dodaj do koszyka" (bez − / + licznika)
	$css .= ".rl-buy button:not(.rl2-qty-btn), .rl-choose, .rl-addon button {\n"
		. "\tpadding: " . (int) $s['button_padding_v'] . "px " . (int) $s['button_padding_h'] . "px !important;\n"
		. "\tborder-radius: " . (int) $s['button_radius'] . "px !important;\n"
		. "\tfont-size: " . max( 10, (float) $s['button_font_size'] ) . "px !important;\n"
		. "\tbackground: " . esc_attr( $s['button_bg'] ) . " !important;\n"
		. "\tcolor: " . esc_attr( $s['button_text_color'] ) . " !important;\n"
		. "\tborder-color: " . esc_attr( $s['button_border_color'] ) . " !important;\n"
		. "}\n";
	$css .= ".rl-buy button:not(.rl2-qty-btn):hover, .rl-choose:hover, .rl-addon button:hover {\n"
		. "\tbackground: " . esc_attr( $s['button_hover_bg'] ) . " !important;\n"
		. "\tcolor: " . esc_attr( $s['button_hover_text'] ) . " !important;\n"
		. "}\n";

	// 2.26.4: „dopasowana do napisu” – przycisk nie rozciąga się na resztę wiersza
	// (flex: 1 z pliku CSS), a wysokość wynika z odstępów góra/dół zamiast z
	// wysokości licznika. Licznik i przycisk zostają wyśrodkowane w pionie.
	if ( 'auto' === ( isset( $s['button_width'] ) ? $s['button_width'] : 'fill' ) ) {
		$css .= ".rl-buy button:not(.rl2-qty-btn), .rl-choose, .rl-addon button, .rl2-order .rl-buy button:not(.rl2-qty-btn), .rl2-order .rl-choose { flex: 0 0 auto !important; width: auto !important; min-height: 0 !important; white-space: nowrap; }\n";
		$css .= ".rl2-order .rl-buy { align-items: center; }\n";
		if ( 'right' === ( isset( $s['button_align'] ) ? $s['button_align'] : 'left' ) ) {
			// 2.26.5: licznik po lewej, przycisk dosunięty do prawej krawędzi wiersza.
			$css .= ".rl2-order .rl-buy { max-width: none !important; width: 100%; }\n";
			$css .= ".rl-buy button:not(.rl2-qty-btn), .rl2-order .rl-buy button:not(.rl2-qty-btn), .rl2-order .rl-choose { margin-left: auto !important; }\n";
		}
	}

	// Hover wiersza i ramek
	$css .= ".rl2-row:hover, .rl2-row:active { background: " . esc_attr( $s['row_hover_bg'] ) . "; }\n";
	$css .= ".rl2-rest .rl-harmono:hover, .rl .rl2-delivery:hover, .rl2-bottom .rl-more:hover, .rl .rl2-allergen-box:hover {\n"
		. "\tbackground: " . esc_attr( $s['box_hover_bg'] ) . ";\n"
		. "\tborder-color: " . esc_attr( $s['box_hover_border'] ) . ";\n"
		. "}\n";

	// Alergeny
	$css .= ".rl-alergen { background: " . esc_attr( $s['allergen_bg'] ) . "; color: " . esc_attr( $s['allergen_text'] ) . "; border-radius: " . (int) $s['allergen_radius'] . "px; }\n";

	$css .= rzd_list_boxes_qty_css( $s );
	$css .= rzd_tiles_css( $s ); // 2.26.6: kafle kategorii (moduł 17)
	$css .= rzd_shop_css( $s );  // 2.26.6: strony sklepu WooCommerce
	$css .= rzd_single_css( $s ); // 2.26.6: strona produktu
	$css .= rzd_popup_css( $s );

	return $css;
}

/**
 * 2.25.3: ramki rozwijane, licznik ilości, odstępy. Selektory o wyższej
 * specyficzności niż plik CSS (moduł 03), a przy liczniku z !important, bo
 * plik ma !important na przyciskach w formularzu zakupu.
 */
/**
 * 2.26.6: kafle kategorii [kategorie_zamowien] (moduł 17). Wcześniej sztywny
 * <style> w shortcodzie (2 w wierszu / 4 od 900 px) – teraz z panelu, osobno
 * telefon i komputer. Znaczniki: .rk-grid > a.rk-tile(.rk-noimg) > .rk-tile-img + .rk-tile-name.
 */
function rzd_tiles_css( $s ) {
	$num   = function ( $k, $min, $max ) use ( $s ) { return max( $min, min( $max, (float) $s[ $k ] ) ); };
	$style = in_array( $s['tiles_style'], array( 'photo', 'below', 'plain' ), true ) ? $s['tiles_style'] : 'below';
	$cols  = (int) $num( 'tiles_cols', 1, 8 );
	$gap   = $num( 'tiles_gap', 0, 60 );
	$h     = $num( 'tiles_height', 30, 400 );
	$r     = $num( 'tiles_radius', 0, 200 );
	$fs    = $num( 'tiles_font_size', 9, 40 );
	$fw    = '' !== (string) $s['tiles_font_weight'] ? ' font-weight: ' . esc_attr( $s['tiles_font_weight'] ) . ';' : '';
	$col   = esc_attr( $s['tiles_text_color'] );
	$bg    = esc_attr( $s['tiles_bg'] );
	$brd   = ! empty( $s['tiles_border'] ) ? '1.5px solid ' . esc_attr( $s['tiles_border_color'] ) : '0';
	$zoom  = ! empty( $s['tiles_hover_zoom'] );
	$c     = '';
	$c .= ".rk-grid { display: grid; grid-template-columns: repeat({$cols}, minmax(0, 1fr)); gap: {$gap}px; }\n";
	// 2.26.12: rozwijane pole „Kategorie menu” (wygląd jak ramki rozwijane listy).
	$c .= '.rk-wrap { margin: 0 0 ' . $num( 'tiles_wrap_gap', 0, 80 ) . "px; }\n";
	if ( ! empty( $s['tiles_collapse'] ) ) {
		// 2.26.20: napis wyśrodkowany, strzałka ▼ przed i za; po rozwinięciu strzałki ▲ i napis „Zwiń”.
		$c .= ".rk-toggle { display: flex !important; align-items: center; justify-content: center; gap: 10px; width: 100%; box-sizing: border-box; margin: 0; padding: 12px 16px; border: 1.5px solid #dcdcdc !important; border-radius: {$r}px; background: #fff !important; color: #2b2b2b !important; font: inherit; font-size: 15px; font-weight: 700; text-align: center; cursor: pointer; box-shadow: none !important; text-transform: none; transition: background .15s, border-color .15s; }\n";
		$c .= ".rk-wrap .rk-lbl-open, .rk-wrap.is-open .rk-lbl-closed { display: none; }\n.rk-wrap.is-open .rk-lbl-open { display: inline; }\n";
		$c .= ".rk-toggle:hover, .rk-toggle:focus { background: " . esc_attr( $s['box_hover_bg'] ) . ' !important; border-color: ' . esc_attr( $s['box_hover_border'] ) . " !important; }\n";
		$c .= ".rk-arrow { display: inline-block; font-size: .8em; transition: transform .2s; }\n.rk-wrap.is-open .rk-arrow { transform: rotate(180deg); }\n";
		$c .= ".rk-wrap:not(.is-open) .rk-panel { display: none; }\n.rk-wrap.is-open .rk-panel { display: block; margin-top: 10px; }\n";
	} else {
		$c .= ".rk-toggle { display: none !important; }\n.rk-panel { display: block !important; margin-top: 0 !important; }\n";
	}
	$c .= ".rk-tile { position: relative; overflow: hidden; display: flex; align-items: center; justify-content: center; text-align: center; box-sizing: border-box; text-decoration: none !important; color: {$col} !important; font-size: {$fs}px;{$fw} line-height: 1.25; border-radius: {$r}px; transition: background .15s, border-color .15s; }\n";
	$c .= ".rk-tile-name { position: relative; z-index: 2; padding: 0 8px; overflow-wrap: anywhere; }\n";
	if ( ! empty( $s['tiles_upper'] ) ) {
		$c .= ".rk-tile-name { text-transform: uppercase; letter-spacing: .04em; }\n";
	}
	if ( 'below' === $style ) {
		$c .= ".rk-tile { flex-direction: column; justify-content: flex-start; padding: 0; min-height: 0; border: 0; border-radius: 0; background: transparent; }\n";
		$c .= ".rk-tile-img { display: block; position: static; width: 100%; aspect-ratio: 1 / 1; margin-bottom: 10px; overflow: hidden; border-radius: {$r}px; border: {$brd}; box-sizing: border-box; background: {$bg}; }\n";
		$c .= ".rk-tile-img img { display: block; width: 100%; height: 100%; object-fit: cover; filter: none; transform: none; transition: transform .2s; }\n";
		if ( $zoom ) {
			$c .= ".rk-tile:hover .rk-tile-img img { transform: scale(1.04); }\n";
		}
	} elseif ( 'photo' === $style ) {
		$blur = $num( 'tiles_blur', 0, 30 );
		$ov   = $num( 'tiles_overlay', 0, 90 ) / 100;
		$ovh  = min( .95, $ov + .15 );
		$sc   = $blur > 0 ? 1.12 : 1; // przy rozmyciu lekko powiększone – bez jasnych brzegów
		$c .= ".rk-tile { min-height: {$h}px; padding: 12px 8px; border: {$brd}; background: {$bg}; text-shadow: 0 1px 3px rgba(0,0,0,.45); }\n";
		$c .= ".rk-tile-img { display: block; position: absolute; inset: 0; z-index: 0; margin: 0; }\n";
		$c .= ".rk-tile-img img { display: block; width: 100%; height: 100%; max-width: none; object-fit: cover; filter: blur({$blur}px); transform: scale({$sc}); transition: transform .25s; }\n";
		$c .= ".rk-tile::after { content: ''; position: absolute; inset: 0; z-index: 1; background: rgba(0,0,0,{$ov}); transition: background .2s; }\n";
		$c .= ".rk-tile.rk-noimg::after { content: none; }\n";
		$c .= ".rk-tile:hover::after { background: rgba(0,0,0,{$ovh}); }\n";
		if ( $zoom ) {
			$c .= ".rk-tile:hover .rk-tile-img img { transform: scale(" . ( $sc + .06 ) . "); }\n";
		}
	}
	if ( 'plain' === $style ) {
		$c .= ".rk-tile { min-height: {$h}px; padding: 14px 10px; border: {$brd}; background: {$bg}; }\n";
		$c .= ".rk-tile:hover { background: " . esc_attr( $s['button_bg'] ) . "; border-color: " . esc_attr( $s['button_border_color'] ) . "; }\n";
		$c .= ".rk-tile-img { display: none; }\n";
	}
	// 2.26.10: tło pod samym napisem (zdjęcie w tle / sam napis) – zdjęcie może być w pełni ostre.
	$lbg = in_array( $s['tiles_label_bg'], array( 'none', 'glow', 'pill', 'band' ), true ) ? $s['tiles_label_bg'] : 'none';
	if ( 'below' !== $style && 'none' !== $lbg ) {
		$hx  = ltrim( (string) $s['tiles_label_color'], '#' );
		$rgb = preg_match( '/^[0-9a-fA-F]{6}$/', $hx ) ? hexdec( substr( $hx, 0, 2 ) ) . ',' . hexdec( substr( $hx, 2, 2 ) ) . ',' . hexdec( substr( $hx, 4, 2 ) ) : '0,0,0';
		$op  = $num( 'tiles_label_opacity', 0, 100 ) / 100;
		$lb  = $num( 'tiles_label_blur', 0, 20 );
		$bf  = $lb > 0 ? " -webkit-backdrop-filter: blur({$lb}px); backdrop-filter: blur({$lb}px);" : '';
		if ( 'glow' === $lbg ) {
			$c .= ".rk-tile-name { padding: 14px 24px; background: radial-gradient(ellipse at center, rgba({$rgb},{$op}) 0%, rgba({$rgb}," . round( $op * .6, 2 ) . ") 45%, rgba({$rgb},0) 75%); text-shadow: 0 1px 6px rgba({$rgb}," . min( 1, $op + .2 ) . "); }\n";
		} elseif ( 'pill' === $lbg ) {
			$c .= ".rk-tile-name { padding: 5px 14px; border-radius: 999px; background: rgba({$rgb},{$op});{$bf} }\n";
		} else { // band
			$c .= ".rk-tile-name { align-self: stretch; display: flex; align-items: center; justify-content: center; padding: 7px 8px; background: rgba({$rgb},{$op});{$bf} }\n";
		}
	}
	if ( 'below' !== $style && 'bottom' === $s['tiles_label_pos'] ) {
		$c .= ".rk-tile { align-items: flex-end; padding-bottom: " . ( 'band' === $lbg ? '0' : '10px' ) . "; }\n";
		if ( 'band' === $lbg ) {
			$c .= ".rk-tile { padding-left: 0; padding-right: 0; }\n.rk-tile-name { align-self: flex-end; flex: 1 1 100%; }\n";
		}
	} elseif ( 'below' !== $style && 'band' === $lbg ) {
		$c .= ".rk-tile { padding-left: 0; padding-right: 0; }\n.rk-tile-name { flex: 1 1 100%; }\n";
	}
	return $c;
}

/**
 * 2.26.6: strony sklepu WooCommerce (archiwum kategorii, sklep, „Podobne
 * produkty”) – pętla motywu ul.products > li.product. Przycisk dostaje
 * wygląd przycisku z listy; zdjęcia zaokrąglone; opcjonalnie wszystko na środku.
 * !important, bo motywy stylują te elementy bardzo mocno.
 */
function rzd_shop_css( $s ) {
	$gb = '';
	if ( ! empty( $s['gb_btn_style'] ) ) {
		// 2.26.9: blok Gutenberga „Przyciski” (.wp-block-button__link) – ten sam wygląd co
		// „Dodaj do koszyka”. Wariant „Obrys” (is-style-outline) dostaje przezroczyste tło.
		// 2.26.11: + „Wróć do listy produktów”, „Przejdź do płatności” (koszyk blokowy i klasyczny), „Kupuję i płacę” (kasa).
		$b   = '.wp-block-button .wp-block-button__link, .wp-block-button .wp-element-button, .kc-back-to-shop .button.wc-backward, '
			. '.wc-block-cart__submit-button, .wc-block-components-checkout-place-order-button, .woocommerce a.checkout-button, .woocommerce #place_order, '
			// 2.26.11: wszystkie przyciski kroków kasy i koszyka (np. „Zapisz zmiany”, „Dalej”, „Zastosuj kupon”) – też z wtyczek kroków kasy.
			. 'body.woocommerce-checkout button.button, body.woocommerce-checkout a.button:not(.wc-backward), body.woocommerce-checkout input[type=submit].button, body.woocommerce-checkout .wc-block-components-button:not(.is-link), '
			. 'body.woocommerce-cart button.button, body.woocommerce-cart .wc-block-components-button:not(.is-link), '
			// Fluid Checkout ma mocne własne style przycisków – wyższa „waga” selektorów (id / podwojone klasy).
			. 'html body.woocommerce-checkout #place_order, html body.woocommerce-checkout button.button.button, html body.woocommerce-checkout .fc-step__substep-save.fc-step__substep-save';
		$gb .= $b . ' { padding: ' . (int) $s['button_padding_v'] . 'px ' . (int) $s['button_padding_h'] . 'px !important;'
			. ' border: 1.5px solid ' . esc_attr( $s['button_border_color'] ) . ' !important;'
			. ' border-radius: ' . (int) $s['button_radius'] . 'px !important;'
			. ' background: ' . esc_attr( $s['button_bg'] ) . ' !important;'
			. ' color: ' . esc_attr( $s['button_text_color'] ) . ' !important;'
			. ' font-size: ' . max( 10, (float) $s['button_font_size'] ) . 'px !important;'
			. ' font-weight: 600 !important; line-height: 1.25 !important; text-decoration: none !important; box-shadow: none !important; text-transform: none !important; transition: background .15s, color .15s;'
			. ' box-sizing: border-box !important; max-width: 100% !important; white-space: normal; }' . "\n"; // 2.26.12: szerokość 100 % + nasz padding/ramka nie wychodzi poza kontener
		$gb .= ".wc-block-cart__submit-button .wc-block-components-button__text, .wc-block-components-checkout-place-order-button .wc-block-components-button__text { color: inherit !important; }\n";
		$gb .= '.wp-block-button .wp-block-button__link:hover, .wp-block-button .wp-block-button__link:focus, .wp-block-button .wp-element-button:hover, .kc-back-to-shop .button.wc-backward:hover, .kc-back-to-shop .button.wc-backward:focus, .wc-block-cart__submit-button:hover, .wc-block-cart__submit-button:focus, .wc-block-components-checkout-place-order-button:hover, .woocommerce a.checkout-button:hover, .woocommerce #place_order:hover, body.woocommerce-checkout button.button:hover, body.woocommerce-checkout a.button:not(.wc-backward):hover, body.woocommerce-checkout input[type=submit].button:hover, body.woocommerce-checkout .wc-block-components-button:not(.is-link):hover, body.woocommerce-cart button.button:hover, body.woocommerce-cart .wc-block-components-button:not(.is-link):hover, html body.woocommerce-checkout #place_order:hover, html body.woocommerce-checkout button.button.button:hover, html body.woocommerce-checkout .fc-step__substep-save.fc-step__substep-save:hover { background: ' . esc_attr( $s['button_hover_bg'] ) . ' !important; color: ' . esc_attr( $s['button_hover_text'] ) . " !important; }\n";
		$gb .= ".wp-block-button.is-style-outline .wp-block-button__link:not(:hover) { background: transparent !important; }\n";
	}
	if ( empty( $s['shop_on'] ) ) {
		return $gb;
	}
	$li  = '.woocommerce ul.products li.product, .woocommerce-page ul.products li.product, ul.products li.product';
	$sel = function ( $suffix ) {
		return implode( ', ', array_map( function ( $b ) use ( $suffix ) { return $b . $suffix; }, array( '.woocommerce ul.products li.product', '.woocommerce-page ul.products li.product', 'ul.products li.product' ) ) );
	};
	$r   = max( 0, (float) $s['shop_img_radius'] );
	$gap = max( 0, (float) $s['shop_card_gap'] );
	$c   = '';
	$c  .= $sel( ' img' ) . " { border-radius: {$r}px !important; }\n";
	if ( ! empty( $s['shop_equal'] ) ) {
		// 2.26.9: kafel jako kolumna, przycisk dosunięty do dołu – w rzędzie wszystkie
		// przyciski równo, niezależnie od długości nazwy. Astra trzyma nazwę/cenę/przycisk
		// w .astra-shop-summary-wrap – ona też musi się rozciągać.
		$c .= "ul.products { align-items: stretch; }\n";
		$c .= $sel( '' ) . " { display: flex !important; flex-direction: column; height: auto; }\n";
		$c .= $sel( ' .astra-shop-summary-wrap' ) . " { display: flex; flex-direction: column; flex: 1 1 auto; }\n";
		$c .= $sel( ' .button' ) . ', ' . $sel( ' .added_to_cart' ) . " { margin-top: auto !important; }\n";
		$c .= $sel( ' .price' ) . " { padding-bottom: 6px; }\n";
	}
	if ( ! empty( $s['shop_hide_count'] ) ) {
		$c .= ".woocommerce .woocommerce-result-count, .woocommerce-page .woocommerce-result-count { display: none !important; }\n";
	}
	if ( ! empty( $s['shop_hide_sort'] ) ) {
		$c .= ".woocommerce .woocommerce-ordering, .woocommerce-page .woocommerce-ordering { display: none !important; }\n";
	}
	$c  .= $sel( ' a img' ) . " { margin-bottom: {$gap}px !important; }\n";
	$c  .= $sel( ' .woocommerce-loop-product__title' ) . ' { font-size: ' . (float) $s['shop_name_size'] . 'px !important;' . ( '' !== (string) $s['shop_name_weight'] ? ' font-weight: ' . esc_attr( $s['shop_name_weight'] ) . ' !important;' : '' ) . " margin: 0 0 {$gap}px !important; padding: 0 !important; }\n";
	$c  .= $sel( ' .price' ) . ' { font-size: ' . (float) $s['shop_price_size'] . "px !important; margin: 0 0 {$gap}px !important;" . ( ! empty( $s['shop_price_color_on'] ) ? ' color: ' . esc_attr( $s['shop_price_color'] ) . ' !important;' : '' ) . " }\n";
	if ( ! empty( $s['shop_equal'] ) ) {
		// 2.26.21: cena też dosunięta do dołu (tuż nad przyciskiem) – w rzędzie ceny w jednej
		// linii, nawet gdy nazwa zajmuje 2–3 wiersze. Margines auto przejmuje cena, przycisk
		// stoi zaraz pod nią. Standardowy WooCommerce trzyma cenę w linku z obrazkiem –
		// ten link też musi być kolumną. Cena nigdy się nie łamie.
		$c .= $sel( ' a.woocommerce-LoopProduct-link' ) . " { display: flex !important; flex-direction: column; flex: 1 1 auto; }\n";
		$c .= $sel( ' .price' ) . " { margin-top: auto !important; white-space: nowrap; }\n";
		$c .= $sel( ' .button' ) . ', ' . $sel( ' a.button' ) . " { margin-top: 0 !important; }\n";
	}
	if ( ! empty( $s['shop_center'] ) ) {
		$c .= "{$li} { text-align: center !important; }\n";
		$c .= $sel( ' img' ) . " { margin-left: auto !important; margin-right: auto !important; }\n";
		$c .= $sel( ' .price' ) . ', ' . $sel( ' .star-rating' ) . " { margin-left: auto !important; margin-right: auto !important; justify-content: center; }\n";
		$c .= $sel( ' .button' ) . ', ' . $sel( ' .added_to_cart' ) . " { margin-left: auto !important; margin-right: auto !important; }\n";
		// Motywy z flexem w kafelku (np. Kadence/Astra): wyśrodkuj kolumnę.
		$c .= $sel( ' .product-details' ) . ', ' . $sel( ' .astra-shop-summary-wrap' ) . " { text-align: center !important; align-items: center !important; }\n";
	}
	if ( ! empty( $s['shop_btn_style'] ) ) {
		$btn = $sel( ' .button' ) . ', ' . $sel( ' a.button' ) . ', ' . $sel( ' .added_to_cart' );
		$c  .= $btn . ' { display: ' . ( ! empty( $s['shop_btn_full'] ) ? 'block' : 'inline-block' ) . ' !important;'
			. ( ! empty( $s['shop_btn_full'] ) ? ' width: 100% !important; box-sizing: border-box;' : ' width: auto !important;' )
			. ' padding: ' . (int) $s['button_padding_v'] . 'px ' . (int) $s['button_padding_h'] . 'px !important;'
			. ' border: 1.5px solid ' . esc_attr( $s['button_border_color'] ) . ' !important;'
			. ' border-radius: ' . (int) $s['button_radius'] . 'px !important;'
			. ' background: ' . esc_attr( $s['button_bg'] ) . ' !important;'
			. ' color: ' . esc_attr( $s['button_text_color'] ) . ' !important;'
			. ' font-size: ' . max( 10, (float) $s['button_font_size'] ) . 'px !important;'
			. ' font-weight: 600 !important; line-height: 1.25 !important; text-align: center; text-decoration: none !important; box-shadow: none !important; text-transform: none; transition: background .15s, color .15s; }' . "\n";
		$c  .= $sel( ' .button:hover' ) . ', ' . $sel( ' .button:focus' ) . ', ' . $sel( ' .added_to_cart:hover' ) . ' { background: ' . esc_attr( $s['button_hover_bg'] ) . ' !important; color: ' . esc_attr( $s['button_hover_text'] ) . ' !important; border-color: ' . esc_attr( $s['button_border_color'] ) . " !important; }\n";
		$c  .= $sel( ' .added_to_cart' ) . " { margin-top: 6px !important; }\n";
	}
	return $gb . $c;
}

/**
 * 2.26.6: strona pojedynczego produktu. Zdjęcie w kwadracie z zaokrągleniem
 * (999 = koło), miniaturki, tytuł/cena. Licznik i przycisk: skrypt
 * rzd_single_buy_script() przenosi .quantity i przycisk do <div class="rl2-order">
 * <div class="rl-buy"> i dodaje − / + – wtedy działają style listy z sekcji
 * „Licznik ilości” i „Przycisk”. Tu tylko poprawki pod motyw (float, marginesy).
 */
function rzd_single_css( $s ) {
	if ( empty( $s['single_on'] ) ) {
		return '';
	}
	$r  = max( 0, (float) $s['single_img_radius'] );
	$tr = max( 0, (float) $s['single_thumb_radius'] );
	$g  = '.woocommerce div.product div.images';
	$c  = '';
	$c .= "{$g} .woocommerce-product-gallery__wrapper, {$g} .flex-viewport, {$g} .woocommerce-product-gallery__image { border-radius: {$r}px; overflow: hidden; }\n";
	$c .= "{$g} .woocommerce-product-gallery__image img { border-radius: {$r}px; }\n";
	if ( ! empty( $s['single_img_square'] ) ) {
		$c .= "{$g} .woocommerce-product-gallery__image > a > img, {$g} .woocommerce-product-gallery__image > img { width: 100% !important; height: auto !important; aspect-ratio: 1 / 1; object-fit: cover; }\n";
	}
	$c .= "{$g} .flex-control-thumbs li img { border-radius: {$tr}px; aspect-ratio: 1 / 1; object-fit: cover; }\n";
	if ( (float) $s['single_title_size'] > 0 ) {
		$c .= '.woocommerce div.product .product_title { font-size: ' . (float) $s['single_title_size'] . "px !important; }\n";
	}
	if ( (float) $s['single_head_gap'] > 0 ) { // 2.26.9
		$c .= '.woocommerce div.product .summary .product_title { margin-bottom: ' . (float) $s['single_head_gap'] . "px !important; }\n.woocommerce div.product .summary > p.price, .woocommerce div.product .summary > .price { margin-top: 0 !important; }\n";
	}
	if ( (float) $s['single_price_size'] > 0 || ! empty( $s['single_price_color_on'] ) ) {
		$c .= '.woocommerce div.product .summary p.price, .woocommerce div.product .summary span.price {'
			. ( (float) $s['single_price_size'] > 0 ? ' font-size: ' . (float) $s['single_price_size'] . 'px !important;' : '' )
			. ( ! empty( $s['single_price_color_on'] ) ? ' color: ' . esc_attr( $s['single_price_color'] ) . ' !important;' : '' ) . " }\n";
	}
	if ( ! empty( $s['single_one_title'] ) ) {
		// Motyw dokłada własny tytuł obok tytułu wtyczki (rwz-title, moduł 4) – zostaje tylko nasz.
		$c .= ".woocommerce div.product:has(.rwz-title) .product_title:not(.rwz-title) { display: none !important; }\n";
	}
	if ( ! empty( $s['single_layout'] ) ) {
		// 2.26.7: kolumna po prawej od zdjęcia jako flex – formularz (ilość + przycisk)
		// zawsze na dole, niezależnie od kolejności haków motywu; wszystko do lewej.
		$sum = '.woocommerce div.product .summary';
		$c .= "{$sum} { display: flex; flex-direction: column; align-items: stretch; text-align: left; }\n";
		$c .= "{$sum} > * { order: 10; }\n";
		// 2.26.8: margin-top: auto = na samo dno kolumny; wysokość kolumny = wysokość
		// zdjęcia (skrypt rzd_single_layout_script, gdy zdjęcie i kolumna są obok siebie).
		$c .= "{$sum} > form.cart, {$sum} > .cart { order: 90; margin-top: auto !important; padding-top: 8px; }\n";
		$c .= "{$sum} { box-sizing: border-box; }\n";
		$c .= "{$sum} { min-width: 0; max-width: 100%; }\n{$sum} .product_title { overflow-wrap: anywhere; }\n"; // 2.26.9: nic nie wystaje poza ekran
		$c .= "{$sum} .rzd-sp-order .rl-buy .rl2-qty { flex: 0 0 auto; }\n";
		$mode = in_array( $s['single_buy_stack'], array( 'stack', 'center', 'row' ), true ) ? $s['single_buy_stack'] : 'stack';
		$bw   = max( 0, min( 100, (float) $s['single_btn_width'] ) );
		if ( 'row' === $mode ) { // 2.26.9: obok siebie
			$c .= "{$sum} .rzd-sp-order .rl-buy { flex-direction: row; align-items: center; width: 100% !important; max-width: 440px !important; }\n";
			$c .= "{$sum} .rzd-sp-order .rl-buy button:not(.rl2-qty-btn) { flex: 1 1 auto !important; align-self: auto; margin-left: 0 !important; width: auto !important; min-width: 0; }\n";
		} elseif ( 'center' === $mode ) { // 2.26.9: wyśrodkowane – ilość, pod nią szeroki przycisk
			$c .= "{$sum} .rzd-sp-order { width: 100%; }\n";
			$c .= "{$sum} .rzd-sp-order .rl-buy { flex-direction: column; align-items: center; width: 100% !important; max-width: none !important; margin: 0 auto; }\n";
			$c .= "{$sum} .rzd-sp-order .rl-buy .rl2-qty { justify-content: center; }\n";
			$c .= "{$sum} .rzd-sp-order .rl-buy button:not(.rl2-qty-btn) { align-self: center; margin: 0 auto !important; width: " . ( $bw > 0 ? $bw . '%' : 'auto' ) . " !important; max-width: 100%; }\n";
		} else {
			$c .= "{$sum} .rzd-sp-order .rl-buy { flex-direction: column; align-items: flex-start; width: auto !important; max-width: 360px !important; }\n";
			$c .= "{$sum} .rzd-sp-order .rl-buy button:not(.rl2-qty-btn) { align-self: stretch; margin-left: 0 !important; width: " . ( $bw > 0 ? $bw . '%' : '100%' ) . " !important; }\n";
		}
		// 2.26.9: większy licznik i przycisk tylko na stronie produktu.
		$qd = (float) $s['single_qty_size'];
		if ( $qd > 0 ) {
			$c .= "{$sum} .rzd-sp-order .rl2-qty .rl2-qty-btn { width: {$qd}px !important; height: {$qd}px !important; min-width: {$qd}px !important; min-height: {$qd}px !important; font-size: " . round( $qd * 0.42 ) . "px !important; }\n";
			$c .= "{$sum} .rzd-sp-order .rl2-qty { min-width: " . ( 2 * $qd + 60 ) . "px !important; gap: 8px; }\n";
		}
		$qf = (float) $s['single_qty_font'];
		if ( $qf > 0 ) {
			$c .= "{$sum} .rzd-sp-order .rl2-qty input.qty, {$sum} .rzd-sp-order .rl2-qty input[type=number] { font-size: {$qf}px !important; min-width: " . round( $qf * 2 ) . "px; }\n";
		}
		$bh = (float) $s['single_btn_height'];
		if ( $bh > 0 ) {
			$c .= "{$sum} .rzd-sp-order .rl-buy button:not(.rl2-qty-btn) { min-height: {$bh}px !important; }\n";
		}
		$c .= "{$sum} .rzd-sp-order .rl-buy { row-gap: 14px; }\n";
	}
	if ( 'theme' !== $s['single_tabs_line'] ) { // 2.26.9: delikatna kreska zakładek zamiast grubej pomarańczowej
		$lc = 'dark' === $s['single_tabs_line'] ? '#2b2b2b' : esc_attr( $s['button_border_color'] );
		$t  = '.woocommerce div.product .woocommerce-tabs ul.tabs';
		$c .= "{$t}::before { border-color: rgba(0,0,0,.08) !important; }\n";
		$c .= "{$t} li::before, {$t} li.active::before { background: {$lc} !important; height: 1px !important; }\n";
		$c .= "{$t} li.active, {$t} li.active a { border-color: {$lc} !important; }\n";
	}
	$c .= ".woocommerce div.product .rzd-cat-desc { margin: 0 0 18px; padding: 0 0 14px; border-bottom: 1px solid rgba(0,0,0,.08); }\n.woocommerce div.product .rzd-cat-desc > :last-child { margin-bottom: 0; }\n"; // 2.26.9
	$ha = in_array( $s['single_head_align'], array( 'left', 'center', 'right' ), true ) ? $s['single_head_align'] : 'left';
	if ( 'left' !== $ha ) { // 2.26.8
		$c .= ".woocommerce div.product .summary .product_title, .woocommerce div.product .summary > p.price, .woocommerce div.product .summary > .price { text-align: {$ha} !important; }\n";
	}
	if ( ! empty( $s['single_harmono'] ) ) {
		$c .= ".woocommerce div.product .summary details.rl-harmono { display: block; max-width: 360px; box-sizing: border-box; margin: 10px 0; padding: 8px 12px; border: 1.5px solid #dcdcdc; border-radius: 8px; font-size: 13px; transition: background .15s, border-color .15s; }\n";
		$c .= ".woocommerce div.product .summary details.rl-harmono:hover { background: " . esc_attr( $s['box_hover_bg'] ) . '; border-color: ' . esc_attr( $s['box_hover_border'] ) . "; }\n";
		$c .= ".woocommerce div.product .summary details.rl-harmono summary { cursor: pointer; list-style: none; font-weight: 600; }\n";
		$c .= ".woocommerce div.product .summary details.rl-harmono summary::-webkit-details-marker { display: none; }\n";
		$c .= ".woocommerce div.product .summary details.rl-harmono summary::before { content: \"▶ \"; }\n";
	}
	if ( ! empty( $s['single_buy'] ) ) {
		$c .= ".woocommerce div.product form.cart .rzd-sp-order { margin: 12px 0 16px; }\n";
		$c .= ".woocommerce div.product form.cart .rzd-sp-order .quantity, .woocommerce div.product form.cart .rzd-sp-order .button { float: none !important; margin: 0 !important; }\n";
		$c .= ".woocommerce div.product form.cart .rzd-sp-order .quantity .screen-reader-text { position: absolute !important; }\n";
		$c .= ".woocommerce div.product form.cart .rzd-sp-order .quantity input.qty { flex: 1 1 auto; width: 100%; min-width: 2.2em; text-align: center; padding: 0 !important; -moz-appearance: textfield; }\n";
		$c .= ".woocommerce div.product form.cart .rzd-sp-order .quantity input.qty::-webkit-inner-spin-button, .woocommerce div.product form.cart .rzd-sp-order .quantity input.qty::-webkit-outer-spin-button { -webkit-appearance: none; margin: 0; }\n";
	}
	return $c;
}

/**
 * Skrypt strony produktu: licznik − / + i przycisk jak na liście. Wypisywany
 * zaraz za formularzem (bez „mignięcia”), działa też dla wariantów (przycisk
 * i ilość w .woocommerce-variation-add-to-cart). Nie dubluje − / +, jeśli
 * motyw ma własne. Kliknięcia − / + obsługuje wspólny skrypt listy (moduł 02).
 */
function rzd_single_buy_script() {
	static $done = false;
	$s = rzd_list_style_get();
	if ( $done || empty( $s['single_on'] ) || empty( $s['single_buy'] ) ) {
		return;
	}
	$done = true;
	?>
	<script>
	(function () {
		Array.prototype.forEach.call(document.querySelectorAll('form.cart'), function (f) {
			if (f.getAttribute('data-rzd-buy')) { return; }
			var b = f.querySelector('button.single_add_to_cart_button, button[name="add-to-cart"]');
			if (!b) { return; }
			f.setAttribute('data-rzd-buy', '1');
			var q = f.querySelector('.quantity');
			var wrap = document.createElement('div'); wrap.className = 'rl2-order rzd-sp-order';
			var buy = document.createElement('div'); buy.className = 'rl-buy';
			wrap.appendChild(buy);
			var anchor = (q && q.parentNode === b.parentNode) ? q : b;
			anchor.parentNode.insertBefore(wrap, anchor);
			if (q) {
				var inp = q.querySelector('input.qty');
				if (inp && inp.type !== 'hidden' && !q.querySelector('.plus, .minus, button')) {
					q.classList.add('rl2-qty');
					var mk = function (cls, txt, lbl) { var x = document.createElement('button'); x.type = 'button'; x.className = 'rl2-qty-btn ' + cls; x.textContent = txt; x.setAttribute('aria-label', lbl); return x; };
					inp.parentNode.insertBefore(mk('rl2-qty-minus', '−', 'Zmniejsz ilość'), inp);
					inp.parentNode.insertBefore(mk('rl2-qty-plus', '+', 'Zwiększ ilość'), inp.nextSibling);
				}
				buy.appendChild(q);
			}
			buy.appendChild(b);
		});
	})();
	</script>
	<?php
}
add_action( 'woocommerce_after_add_to_cart_form', 'rzd_single_buy_script' );

/**
 * 2.26.8: kolumna obok zdjęcia ma co najmniej wysokość zdjęcia – wtedy ilość
 * i „Dodaj do koszyka” (margin-top: auto) stoją równo z dołem zdjęcia, nawet gdy
 * między ceną a przyciskiem nic nie ma. Gdy kolumna jest POD zdjęciem (telefon),
 * nic nie zmieniamy. Liczone po wczytaniu zdjęć, przy zmianie rozmiaru okna
 * i gdy galeria zmieni wysokość (ResizeObserver).
 */
add_action( 'wp_footer', function () {
	if ( ! function_exists( 'is_product' ) || ! is_product() ) {
		return;
	}
	$s = rzd_list_style_get();
	if ( empty( $s['single_on'] ) || empty( $s['single_layout'] ) ) {
		return;
	}
	?>
	<script>
	(function () {
		var p = document.querySelector('div.product');
		var g = p && p.querySelector('.woocommerce-product-gallery, div.images');
		var sm = p && p.querySelector('.summary');
		if (!g || !sm) { return; }
		function fit() {
			sm.style.minHeight = '';
			var gr = g.getBoundingClientRect(), sr = sm.getBoundingClientRect();
			var side = Math.abs(gr.top - sr.top) < 60 && sr.left >= gr.right - 4; // kolumna obok zdjęcia
			if (side && g.offsetHeight > sm.offsetHeight) { sm.style.minHeight = g.offsetHeight + 'px'; }
		}
		fit();
		window.addEventListener('load', fit);
		window.addEventListener('resize', fit);
		if (window.ResizeObserver) { new ResizeObserver(fit).observe(g); }
	})();
	</script>
	<?php
}, 30 );

// 2.26.9: główna kategoria produktu (pierwsza, bez „Bez kategorii”).
function rzd_product_main_cat( $product_id ) {
	$terms = get_the_terms( $product_id, 'product_cat' );
	if ( ! $terms || is_wp_error( $terms ) ) {
		return null;
	}
	foreach ( $terms as $t ) {
		if ( 'uncategorized' !== $t->slug && (int) get_option( 'default_product_cat' ) !== (int) $t->term_id ) {
			return $t;
		}
	}
	return null;
}

/**
 * 2.26.9: zakładka „Opis” na karcie produktu:
 *  - tytuł zakładki = nazwa kategorii (np. „Bajgle”),
 *  - w środku: opis kategorii (Produkty → Kategorie → Opis), pod nim nazwa
 *    produktu w miejscu „O produkcie” i opis produktu.
 * „O produkcie” zastępujemy, gdziekolwiek jest: jako nagłówek zakładki
 * (WooCommerce/motyw) albo jako nagłówek wpisany w treści opisu.
 */
add_filter( 'woocommerce_product_tabs', function ( $tabs ) {
	global $product;
	$s = rzd_list_style_get();
	if ( empty( $s['single_on'] ) || empty( $tabs['description'] ) || ! $product ) {
		return $tabs;
	}
	$cat = rzd_product_main_cat( $product->get_id() );
	if ( ! empty( $s['single_tab_cat'] ) && $cat ) {
		$tabs['description']['title'] = $cat->name;
	}
	if ( ! empty( $s['single_tab_catdesc'] ) ) {
		$tabs['description']['callback'] = 'rzd_description_tab_content';
	}
	return $tabs;
}, 98 );

function rzd_description_tab_content() {
	global $product;
	if ( ! $product ) {
		return;
	}
	$name = $product->get_name();
	$cat  = rzd_product_main_cat( $product->get_id() );
	if ( $cat ) {
		$cd = trim( (string) term_description( $cat->term_id, 'product_cat' ) );
		if ( '' !== $cd ) {
			echo '<div class="rzd-cat-desc">' . wp_kses_post( $cd ) . '</div>';
		}
	}
	$content = apply_filters( 'the_content', get_post_field( 'post_content', $product->get_id() ) ); // phpcs:ignore
	if ( '' === trim( wp_strip_all_tags( (string) $content ) ) ) {
		return;
	}
	// Nagłówek „O produkcie” wpisany w treści → nazwa produktu; brak takiego → dodajemy nazwę na górze.
	$re = '#(<h([1-6])[^>]*>)\s*O\s+produkcie\s*:?\s*(</h\2>)#iu';
	if ( preg_match( $re, $content ) ) {
		$content = preg_replace( $re, '${1}' . esc_html( $name ) . '${3}', $content, 1 );
	} else {
		$content = '<h2 class="rzd-desc-title">' . esc_html( $name ) . '</h2>' . $content;
	}
	echo $content; // phpcs:ignore – treść opisu po the_content
}


// 2.26.9: nagłówek „Podobne produkty” pod kartą produktu z panelu (domyślnie „Zamów razem”).
add_filter( 'woocommerce_product_related_products_heading', function ( $heading ) {
	$s = rzd_list_style_get();
	$t = isset( $s['shop_related_title'] ) ? trim( (string) $s['shop_related_title'] ) : '';
	return '' !== $t ? $t : $heading;
} );

function rzd_list_boxes_qty_css( $s ) {
	$n   = function ( $k ) use ( $s ) { return (float) $s[ $k ]; };
	$col = function ( $k ) use ( $s ) { return esc_attr( $s[ $k ] ); };
	$c   = '';

	// --- Ramki rozwijane ---
	$boxes = array(
		'harmono'  => '.rl2-rest .rl-harmono',
		'delivery' => '.rl .rl2-delivery',
		'more'     => '.rl2-bottom .rl-more',
		'allergen' => '.rl .rl2-allergen-box',
	);
	$all = implode( ', ', $boxes );
	$c  .= "{$all} { border: " . $n( 'box_border_width' ) . 'px solid ' . $col( 'box_border_color' ) . '; border-radius: ' . $n( 'box_radius' ) . 'px; padding: ' . $n( 'box_pad_v' ) . 'px ' . $n( 'box_pad_h' ) . 'px;'
		. ( ! empty( $s['box_bg_on'] ) ? ' background: ' . $col( 'box_bg' ) . ';' : '' ) . " }\n";
	$sum = array();
	$arr = array();
	foreach ( $boxes as $sel ) {
		$sum[] = $sel . ' summary';
		$arr[] = $sel . ' summary::before';
	}
	$c .= implode( ', ', $sum ) . ' { font-size: ' . $n( 'box_title_size' ) . 'px; color: ' . $col( 'box_title_color' ) . "; }\n";
	if ( empty( $s['box_arrow_on'] ) ) {
		$c .= implode( ', ', $arr ) . " { display: none; }\n";
	}
	// Ramka wyłączona: bez obwódki i bez bocznego odstępu – tekst równa się z resztą.
	foreach ( $boxes as $key => $sel ) {
		if ( empty( $s[ 'box_' . $key . '_border' ] ) ) {
			$c .= "{$sel} { border: 0; padding-left: 0; padding-right: 0; }\n";
		}
	}

	// --- Licznik ilości ---
	$bw   = $n( 'qty_border_width' );
	$line = $bw . 'px solid ' . $col( 'qty_border_color' );
	$h    = $n( 'qty_height' );
	$c   .= '.rl2-order .rl2-qty { border: ' . ( ! empty( $s['qty_border_on'] ) ? $line : '0' ) . '; border-radius: ' . $n( 'qty_radius' ) . 'px; background: ' . $col( 'qty_bg' ) . "; }\n";
	// Pole z liczbą: motywy (np. Elementor) dają polom input własną ramkę i
	// cień – tu zawsze zero, żeby jedyną ramką była ramka licznika z panelu.
	$c   .= '.rl2-order .rl2-qty input[type=number] { min-height: ' . $h . 'px; font-size: ' . $n( 'qty_font_size' ) . "px; border: 0 !important; border-radius: 0 !important; box-shadow: none !important; background: transparent !important; margin: 0 !important; }\n";
	$c   .= ".rl2-order .rl2-qty input[type=number]:focus { border: 0 !important; box-shadow: none !important; }\n";
	$c   .= '.rl2-qty .rl2-qty-btn { flex: 0 0 ' . $n( 'qty_btn_width' ) . 'px !important; width: ' . $n( 'qty_btn_width' ) . 'px !important; min-height: ' . $h . 'px !important; padding: 0 !important; margin: 0 !important; border: 0 !important; border-radius: ' . $n( 'qty_btn_radius' ) . 'px !important; background: ' . $col( 'qty_btn_bg' ) . ' !important; color: ' . $col( 'qty_btn_text' ) . " !important; }\n";
	$c   .= '.rl2-qty .rl2-qty-btn:hover { background: ' . $col( 'qty_btn_hover_bg' ) . ' !important; color: ' . $col( 'qty_btn_text' ) . " !important; }\n";
	if ( 'circle' === $s['qty_btn_shape'] ) {
		// Koło: szerokość = wysokość = średnica (inaczej wychodzi owal), wyśrodkowane
		// w pionie w wysokości licznika; bez linii oddzielających od liczby.
		$d   = $n( 'qty_circle_size' );
		$cbw = $n( 'qty_circle_border_w' );
		$c  .= ".rl2-order .rl2-qty { align-items: center; background: transparent; gap: 4px; min-width: " . ( 2 * $d + 44 ) . "px; }\n"; // bez prostokąta za kołami; 2.26.5: liczba nie ściśnięta między kołami
		$c  .= ".rl2-qty .rl2-qty-btn { flex: 0 0 {$d}px !important; width: {$d}px !important; height: {$d}px !important; min-height: {$d}px !important; border-radius: 50% !important; border: " . ( $cbw > 0 ? $cbw . 'px solid ' . $col( 'qty_circle_border_c' ) : '0' ) . " !important; }\n";
	} elseif ( ! empty( $s['qty_border_on'] ) ) {
		$c .= '.rl2-qty .rl2-qty-minus { border-right: ' . $line . " !important; }\n";
		$c .= '.rl2-qty .rl2-qty-plus { border-left: ' . $line . " !important; }\n";
	}
	$qw = $n( 'qty_input_width' );
	if ( $qw > 0 ) { // 2.26.5: stała szerokość pola z liczbą – licznik bierze tyle, ile potrzebuje
		$c .= ".rl2-order .rl2-qty { flex: 0 0 auto !important; min-width: 0 !important; }\n";
		$c .= ".rl2-order .rl2-qty input[type=number] { flex: 0 0 {$qw}px; width: {$qw}px !important; min-width: {$qw}px; }\n";
	}
	$c .= '.rl2-order .rl-buy { gap: ' . $n( 'qty_gap' ) . "px; }\n";
	$c .= '.rl2-order .rl-buy button:not(.rl2-qty-btn), .rl2-order .rl-choose { min-height: ' . $h . "px; }\n";

	// --- Odstępy pod zdjęciem ---
	// .rl2-rest ma gap (domyślnie 10); dolny blok (opis, Pełny opis) dostaje
	// tyle samo względem tego, co było (row-gap siatki 6px + różnica).
	$g  = max( 0, $n( 'element_gap' ) );
	$c .= ".rl2-rest { gap: {$g}px; }\n";
	$c .= ".rl2-row { --rl2-gap: {$g}px; }\n"; // telefon: odstęp w jednej kolumnie (plik CSS)
	$c .= '.rl2-bottom { margin-top: ' . ( $g - 10 ) . "px; }\n";
	$c .= ".rl2-bottom .rl-short { margin-bottom: {$g}px; }\n";

	return $c;
}

/**
 * Jeden wspólny wygląd wszystkich okienek dla klienta: wybór terminu
 * (#dc-modal), konflikt terminu (#dc-conflict), informacja z ikonki "i"
 * (#dc-info-popup) i "Dodano do koszyka" (#kc-added). Wcześniej każde miało
 * własną, prawie identyczną kopię CSS (w modułach 6 i 7) – teraz jest jedno
 * miejsce, a kolory pochodzą z tego samego panelu co lista produktów
 * (przycisk główny = przycisk "Dodaj do koszyka", akcent = jego obramowanie,
 * hover drugorzędnych = tło wiersza przy najechaniu).
 *
 * Układ przycisków: dolna sekcja to dwa równe kontenery (.dc-act / .kc-added-act),
 * a przestrzeń między nimi i po bokach jest rozdzielona równo (space-evenly) –
 * czyli odstęp od lewej krawędzi, między przyciskami i od prawej jest taki sam.
 */
function rzd_popup_css( $s ) {
	$accent   = esc_attr( $s['button_border_color'] );
	$p_bg     = esc_attr( $s['button_bg'] );
	$p_txt    = esc_attr( $s['button_text_color'] );
	$p_hbg    = esc_attr( $s['button_hover_bg'] );
	$p_htxt   = esc_attr( $s['button_hover_text'] );
	$soft_hov = esc_attr( $s['row_hover_bg'] );
	$line     = '#dcdcdc'; // jasne, nieagresywne obramowania

	// Tekst na wybranej godzinie (tło = kolor akcentu): dobieramy biały albo
	// ciemny według jasności tła, żeby nigdy nie wyszło czarne na czarnym –
	// niezależnie od tego, jaki akcent ktoś ustawi w panelu.
	$lum = function ( $hex ) {
		$h = ltrim( (string) $hex, '#' );
		if ( 3 === strlen( $h ) ) {
			$h = $h[0] . $h[0] . $h[1] . $h[1] . $h[2] . $h[2];
		}
		if ( 6 !== strlen( $h ) || ! ctype_xdigit( $h ) ) {
			return 1;
		}
		return ( 0.299 * hexdec( substr( $h, 0, 2 ) ) + 0.587 * hexdec( substr( $h, 2, 2 ) ) + 0.114 * hexdec( substr( $h, 4, 2 ) ) ) / 255;
	};
	$on_accent = $lum( $s['button_border_color'] ) < 0.55 ? '#ffffff' : '#2b2110';

	// #rwz-harmono = okienko harmonogramu zestawu (moduł 05, od 2.26.1).
	// #rzd-review = przegląd zamówienia (moduł 10, od 2.26.16).
	$ov = '#dc-modal, #dc-conflict, #dc-info-popup, #kc-added, #rwz-harmono, #rzd-review';
	$pn = '#dc-modal .dc-panel, #dc-conflict .dc-panel, #dc-info-popup .dc-panel, #kc-added .kc-added-panel, #rwz-harmono .dc-panel, #rzd-review .dc-panel';
	$h3 = '#dc-modal h3, #dc-conflict h3, #dc-info-popup h3, #kc-added h3, #rwz-harmono h3, #rzd-review h3';
	$ac = '#dc-modal .dc-actions, #dc-conflict .dc-actions, #dc-info-popup .dc-actions, #kc-added .kc-added-actions, #rzd-mods .rzd-actions, #rwz-harmono .dc-actions, #rzd-review .dc-actions';
	$ce = '#dc-modal .dc-act, #dc-conflict .dc-act, #dc-info-popup .dc-act, #kc-added .kc-added-act, #rzd-mods .rzd-act, #rwz-harmono .dc-act, #rzd-review .dc-act';
	$bt = '#dc-modal .dc-act button, #dc-conflict .dc-act button, #dc-info-popup .dc-act button, #kc-added .kc-added-act button, #kc-added .kc-added-act a, #rzd-mods .rzd-act button, #rwz-harmono .dc-act button, #rzd-review .dc-act button';
	$pr = '#dc-modal .dc-act .dc-ok, #dc-conflict .dc-act .dc-ok, #dc-info-popup .dc-act .dc-ok, #kc-added .kc-added-act .kc-added-cart, #rzd-mods .rzd-act .rzd-ok, #rwz-harmono .dc-act .dc-ok, #rzd-review .dc-act .dc-ok';

	// Dokleja pseudo-klasę do KAŻDEGO selektora z listy rozdzielonej przecinkami
	// (zwykłe "{$lista}:hover" dokleiłoby ją tylko do ostatniego).
	$with = function ( $list, $suffixes ) {
		$out = array();
		foreach ( explode( ', ', $list ) as $sel ) {
			foreach ( (array) $suffixes as $sx ) {
				$out[] = $sel . $sx;
			}
		}
		return implode( ', ', $out );
	};

	$c  = "\n/* Okienka dla klienta – wspólny wygląd (patrz rzd_popup_css) */\n";
	$c .= "{$ov} { position: fixed; inset: 0; display: flex; align-items: center; justify-content: center; background: rgba(0,0,0,.5); padding: 16px; box-sizing: border-box; font-family: 'Lato', -apple-system, BlinkMacSystemFont, sans-serif; }\n";
	$c .= "#rzd-review { z-index: 100000; }\n";
	$c .= "#dc-modal, #dc-conflict, #dc-info-popup { z-index: 100000; }\n#kc-added { z-index: 100002; }\n#rwz-harmono { z-index: 99999; }\n";
	// UWAGA: [hidden] musi trafić do KAŻDEGO okna z listy – inaczej (tak było
	// w 2.13.0) chowa się tylko ostatnie, a reszta zostaje widoczna na stronie.
	$c .= $with( $ov, '[hidden]' ) . " { display: none; }\n";
	$alpha = max( 30, min( 100, (float) $s['popup_opacity'] ) ) / 100;
	$blur  = max( 0, (float) $s['popup_blur'] );
	// 2.26.6: kolor tła i tekstu okienek z panelu (np. czarne okno, biały tekst).
	$hex2rgb = function ( $h ) {
		$h = ltrim( (string) $h, '#' );
		return preg_match( '/^[0-9a-fA-F]{6}$/', $h ) ? array( hexdec( substr( $h, 0, 2 ) ), hexdec( substr( $h, 2, 2 ) ), hexdec( substr( $h, 4, 2 ) ) ) : array( 255, 255, 255 );
	};
	$mix = function ( $a, $b, $t ) use ( $hex2rgb ) { // $t = udział koloru $a
		$x = $hex2rgb( $a );
		$y = $hex2rgb( $b );
		return sprintf( '#%02x%02x%02x', round( $x[0] * $t + $y[0] * ( 1 - $t ) ), round( $x[1] * $t + $y[1] * ( 1 - $t ) ), round( $x[2] * $t + $y[2] * ( 1 - $t ) ) );
	};
	$pbg     = preg_match( '/^#[0-9a-fA-F]{6}$/', (string) $s['popup_bg_color'] ) ? $s['popup_bg_color'] : '#ffffff';
	$txt     = preg_match( '/^#[0-9a-fA-F]{6}$/', (string) $s['popup_text_color'] ) ? $s['popup_text_color'] : '#2b2b2b';
	$muted   = $mix( $txt, $pbg, .75 ); // dawne #555/#666
	$faint   = $mix( $txt, $pbg, .55 ); // dawne #777/#999
	$rgb     = implode( ',', $hex2rgb( $pbg ) );
	$is_dark = $lum( $pbg ) < 0.5;
	$glass = 'background: rgba(' . $rgb . ',' . sprintf( '%.2F', $alpha ) . ') !important;' // %F: kropka niezależnie od locale
		. ( $blur > 0 ? " backdrop-filter: blur({$blur}px); -webkit-backdrop-filter: blur({$blur}px);" : ' backdrop-filter: none; -webkit-backdrop-filter: none;' );
	$c .= "{$pn}, #rzd-mods .rzd-panel { {$glass} }\n";
	$c .= "{$pn} { color: {$txt}; border-radius: 14px; max-width: 440px; width: 100%; padding: 24px; box-sizing: border-box; box-shadow: 0 10px 40px rgba(0,0,0,.25); max-height: 90vh; overflow: auto; font-family: inherit; }\n";
	// 2.26.0: czcionki i przyciski okienek z panelu (osobno telefon/komputer).
	// Grubość '' = jak motyw → nie wypisujemy font-weight.
	$fw    = function ( $k, $min = 0 ) use ( $s ) {
		$w = isset( $s[ $k ] ) ? (string) $s[ $k ] : '';
		if ( '' === $w ) {
			return $min ? " font-weight: {$min};" : '';
		}
		return ' font-weight: ' . max( (int) $w, (int) $min ) . ';';
	};
	$px    = function ( $k ) use ( $s ) { return (float) $s[ $k ] . 'px'; };
	$t_sz  = $px( 'popup_title_size' );
	$x_sz  = $px( 'popup_text_size' );
	$l_sz  = $px( 'popup_label_size' );
	$c .= "{$h3} { margin: 0 0 12px; color: {$txt}; font-family: inherit; font-size: {$t_sz};" . $fw( 'popup_title_weight' ) . " letter-spacing: 0; line-height: 1.25; }\n";
	$c .= "#dc-modal .dc-msg, #dc-conflict .dc-msg, #dc-info-popup .dc-msg { font-size: {$x_sz};" . $fw( 'popup_text_weight' ) . " line-height: 1.5; color: {$muted}; margin: 0 0 14px; }\n";
	// „Dostosuj produkt” (moduł 10): tytuł jak w innych okienkach; nagłówek grupy
	// o 2 px większy od etykiet i zawsze gruby; opis grupy o 1 px mniejszy od tekstu.
	$c .= "#rzd-mods .rzd-panel h3 { font-size: {$t_sz};" . $fw( 'popup_title_weight' ) . " line-height: 1.25; }\n";
	// 2.26.20: pasek tytułu okna modyfikacji z ✕ – tło i krzyżyk jak w przeglądzie zamówienia.
	$c .= "#rzd-mods .rzd-head { background: rgba({$rgb},.97) !important; }\n";
	$c .= "#rzd-mods .rzd-x { border-color: {$accent} !important; background: #fff !important; color: #2b2b2b !important; }\n";
	$c .= $with( '#rzd-mods .rzd-x', array( ':hover', ':focus' ) ) . " { background: {$soft_hov} !important; }\n";
	$c .= '#rzd-mods .rzd-panel .rzd-section-header { font-size: ' . ( (float) $s['popup_label_size'] + 2 ) . 'px;' . $fw( 'popup_label_weight', 700 ) . " }\n";
	$c .= '#rzd-mods .rzd-panel .rzd-section-desc { font-size: ' . ( (float) $s['popup_text_size'] - 1 ) . 'px;' . $fw( 'popup_text_weight' ) . " }\n";
	$c .= "#dc-modal .dc-msg.dc-err, #dc-conflict .dc-msg.dc-err, #dc-info-popup .dc-msg { color: #b32d2e; }\n";
	$c .= "#dc-modal .dc-field, #dc-conflict .dc-field { display: block; margin: 14px 0; font-size: {$l_sz};" . $fw( 'popup_label_weight' ) . " color: {$muted}; }\n";
	$c .= "#dc-modal select, #dc-conflict select, #dc-modal input.dc-town { display: block; width: 100%; box-sizing: border-box; margin-top: 6px; padding: 10px 12px; color: #2b2b2b; background: #fff; border: 1px solid {$line}; border-radius: 8px; font-family: inherit; font-size: 14px; transition: border-color .15s; }\n";
	$c .= "#dc-modal select:hover, #dc-modal select:focus, #dc-conflict select:hover, #dc-conflict select:focus { border-color: {$accent}; outline: 0; }\n";
	// Pole miejscowości: widoczne niezależnie od motywu (bez tego wyglądało jak zwykły tekst albo znikało).
	$c .= "#dc-modal input.dc-town { height: auto; min-height: 42px; opacity: 1; visibility: visible; }\n";
	$c .= "#dc-modal input.dc-town:hover, #dc-modal input.dc-town:focus { border-color: {$accent}; outline: 0; }\n";

	// Godziny: siatka o równych kolumnach – wszystkie kafelki tej samej szerokości
	$c .= "#dc-modal .dc-times, #dc-conflict .dc-times { display: grid; grid-template-columns: repeat(auto-fill, minmax(112px, 1fr)); gap: 8px; margin-top: 8px; }\n";
	$c .= "#dc-modal .dc-time, #dc-conflict .dc-time { padding: 9px 6px; border: 1px solid {$line}; border-radius: 8px; background: #fff !important; color: #2b2b2b !important; cursor: pointer; font-family: inherit; font-size: " . $px( 'popup_tile_size' ) . ';' . $fw( 'popup_tile_weight' ) . " text-align: center; transition: background .15s, border-color .15s; }\n";
	$c .= "#dc-modal .dc-time:hover, #dc-modal .dc-time:focus, #dc-conflict .dc-time:hover, #dc-conflict .dc-time:focus { background: {$soft_hov} !important; border-color: {$accent}; color: #2b2b2b !important; }\n";
	$c .= $with( '#dc-modal .dc-time.dc-on, #dc-conflict .dc-time.dc-on', array( '', ':hover', ':focus' ) ) . " { background: {$accent} !important; border-color: {$accent}; color: {$on_accent} !important;" . $fw( 'popup_tile_weight', 700 ) . " }\n";

	// Dolna sekcja: dwa równe kontenery, odstępy po bokach i między nimi równe
	$c .= "{$ac} { display: flex; justify-content: space-evenly; align-items: stretch; margin-top: 22px; }\n";
	$bw = max( 20, min( 48, (float) $s['popup_btn_width'] ) ); // dwa przyciski zawsze się mieszczą
	$c .= "{$ce} { flex: 0 1 {$bw}%; display: flex; justify-content: center; }\n";
	$c .= "#dc-conflict .dc-act[hidden] { display: none; }\n"; // przełączanie „Zmień datę” / „Przejdź do koszyka”
	$c .= "{$bt} { display: flex; align-items: center; justify-content: center; width: 100%; box-sizing: border-box; padding: " . (float) $s['popup_btn_pad_v'] . "px 10px; line-height: 1.25; border: 1.5px solid {$line}; border-radius: " . (float) $s['popup_btn_radius'] . "px; background: #fff !important; color: #2b2b2b !important; cursor: pointer; font-family: inherit; font-size: " . $px( 'popup_btn_size' ) . ';' . $fw( 'popup_btn_weight' ) . " text-align: center; text-decoration: none !important; transition: background .15s, border-color .15s; }\n";
	$c .= $with( $bt, array( ':hover', ':focus' ) ) . " { background: {$soft_hov} !important; border-color: {$accent} !important; color: #2b2b2b !important; }\n";
	$pw = '' === (string) $s['popup_btn_weight'] ? 700 : min( 900, (int) $s['popup_btn_weight'] + 100 ); // główny o stopień grubszy
	$c .= "{$pr} { background: {$p_bg} !important; color: {$p_txt} !important; border-color: {$accent} !important; font-weight: {$pw}; }\n";
	$c .= $with( $pr, array( ':hover', ':focus' ) ) . " { background: {$p_hbg} !important; color: {$p_htxt} !important; border-color: {$accent} !important; }\n";
	$c .= "#dc-modal .dc-act .dc-ok:disabled, #dc-conflict .dc-act .dc-ok:disabled, #rzd-mods .rzd-act .rzd-ok:disabled { opacity: .4; cursor: not-allowed; }\n";
	// Okienko modyfikacji (moduł 10): pasek „Dopłata” nad przyciskami ma już dolny margines.
	$c .= "#rzd-mods .rzd-actions { margin-top: 6px; }\n";

	// Okienko harmonogramu zestawu (moduł 05, 2.26.1): dzień = wiersz; po lewej
	// nazwa dnia + dd.mm.rr, po prawej dania z miniaturami 48 px, dodatki, przycisk.
	$c .= "#rwz-harmono .dc-panel { max-width: 560px; }\n";
	// 2.26.3: przyklejony pasek u góry (tytuł + krzyżyk). Panel ma padding 24 px,
	// więc pasek wychodzi na krawędzie (-24 px) i klei się do samej góry (top: -24px).
	$c .= "#rwz-harmono .rwz-hm-head { position: sticky; top: -24px; z-index: 3; display: flex; align-items: center; gap: 12px; margin: -24px -24px 12px; padding: 14px 16px 12px 24px; background: rgba({$rgb},.97); border-bottom: 1px solid {$line}; border-radius: 14px 14px 0 0; -webkit-backdrop-filter: blur(6px); backdrop-filter: blur(6px); }\n";
	$c .= "#rwz-harmono .rwz-hm-head h3 { flex: 1; min-width: 0; margin: 0 !important; }\n";
	$c .= "#rwz-harmono .rwz-hm-x { flex: 0 0 36px; width: 36px; height: 36px; margin: 0; padding: 0; border: 1.5px solid {$accent} !important; border-radius: 50%; background: #fff !important; color: #2b2b2b !important; font-size: 16px; line-height: 1; cursor: pointer; display: flex; align-items: center; justify-content: center; box-shadow: none; }\n";
	$c .= $with( '#rwz-harmono .rwz-hm-x', array( ':hover', ':focus' ) ) . " { background: {$soft_hov} !important; color: #2b2b2b !important; }\n";
	$c .= "#rwz-harmono .rwz-hm-body { font-size: {$x_sz};" . $fw( 'popup_text_weight' ) . " color: {$txt}; }\n";
	$c .= "#rwz-harmono .rwz-hm-empty { margin: 0; color: {$muted}; }\n";
	$c .= "#rwz-harmono .rwz-hm-day { display: flex; gap: 14px; padding: 12px 10px; border-bottom: 1px solid {$line}; }\n";
	$c .= "#rwz-harmono .rwz-hm-day:last-child { border-bottom: 0; }\n";
	$c .= "#rwz-harmono .rwz-hm-day.is-today { box-shadow: inset 0 0 0 2px {$accent}; border-radius: 12px; border-bottom-color: transparent; }\n";
	$c .= "#rwz-harmono .rwz-hm-day.is-past { opacity: .45; }\n";
	$c .= "#rwz-harmono .rwz-hm-day.is-past img { filter: grayscale(1); }\n";
	$c .= "#rwz-harmono .rwz-hm-date { flex: 0 0 96px; font-size: {$l_sz}; line-height: 1.3; }\n";
	$c .= "#rwz-harmono .rwz-hm-date strong { display: block; font-weight: 700; }\n";
	$c .= "#rwz-harmono .rwz-hm-date span { display: block; color: {$faint}; }\n";
	$c .= "#rwz-harmono .rwz-hm-date em { display: inline-block; margin-top: 4px; padding: 1px 8px; border-radius: 10px; background: {$accent}; color: {$on_accent}; font-style: normal; font-size: 11px; font-weight: 700; }\n";
	$c .= "#rwz-harmono .rwz-hm-main { flex: 1; min-width: 0; }\n";
	$c .= "#rwz-harmono .rwz-hm-dishes { list-style: none; margin: 0; padding: 0; }\n";
	$c .= "#rwz-harmono .rwz-hm-dishes li { display: flex; align-items: center; gap: 10px; margin: 0 0 6px; padding: 0; line-height: 1.3; }\n";
	$c .= "#rwz-harmono .rwz-hm-dishes li::before { content: none; }\n";
	// 2.26.4: miniatura klikalna → duże zdjęcie (#rwz-hm-zoom, nad okienkiem).
	$c .= "#rwz-harmono img.rwz-hm-img { cursor: zoom-in; }\n";
	$c .= "#rwz-hm-zoom { position: fixed; inset: 0; z-index: 100005; display: flex; align-items: center; justify-content: center; padding: 16px; background: rgba(0,0,0,.82); cursor: zoom-out; }\n#rwz-hm-zoom[hidden] { display: none !important; }\n";
	$c .= "#rwz-hm-zoom figure { margin: 0; max-width: 100%; text-align: center; }\n";
	$c .= "#rwz-hm-zoom img { display: block; max-width: min(92vw, 900px); max-height: 80vh; width: auto; height: auto; margin: 0 auto; border-radius: 12px; box-shadow: 0 10px 40px rgba(0,0,0,.5); }\n";
	$c .= "#rwz-hm-zoom figcaption { margin-top: 10px; color: #fff; font-size: 16px; font-weight: 600; }\n";
	$c .= "#rwz-hm-zoom .rwz-hm-zoom-x { position: absolute; top: calc(12px + env(safe-area-inset-top, 0px)); right: 12px; width: 40px; height: 40px; padding: 0; border: 0 !important; border-radius: 50%; background: rgba(255,255,255,.92) !important; color: #2b2b2b !important; font-size: 18px; line-height: 40px; cursor: pointer; }\n";
	$c .= "#rwz-harmono img.rwz-hm-img { flex: 0 0 48px; width: 48px; height: 48px; max-width: none; object-fit: cover; border-radius: 10px; margin: 0; }\n";
	$c .= "#rwz-harmono .rwz-hm-addons { margin-top: 2px; color: {$muted}; font-size: " . max( 10, (float) $s['popup_text_size'] - 1 ) . "px; }\n";
	// 2.26.4: przycisk pod daniami na całą szerokość wiersza (wiersz się zawija).
	$c .= "#rwz-harmono .rwz-hm-day { flex-wrap: wrap; row-gap: 10px; }\n";
	$c .= "#rwz-harmono .rwz-hm-side { flex: 0 0 100%; }\n";
	$c .= "#rwz-harmono .rwz-hm-add { display: block; width: 100%; margin: 0; padding: 10px 14px; border: 1.5px solid {$accent} !important; border-radius: " . min( 10, (float) $s['popup_btn_radius'] ) . "px; background: #fff !important; color: #2b2b2b !important; cursor: pointer; font-family: inherit; font-size: {$x_sz}; font-weight: 600; line-height: 1.25; text-align: center; text-decoration: none; transition: background .15s; }\n";
	$c .= $with( '#rwz-harmono .rwz-hm-add', array( ':hover', ':focus' ) ) . " { background: {$soft_hov} !important; color: #2b2b2b !important; }\n";
	$c .= "#rwz-harmono .rwz-hm-closed { display: block; color: {$faint}; font-size: 12px; line-height: 1.25; text-align: center; }\n";
	$c .= "@media (max-width: 480px) { #rwz-harmono .rwz-hm-day { gap: 10px; padding: 10px 6px; } #rwz-harmono .rwz-hm-date { flex-basis: 78px; } }\n";

	// 2.26.16: przegląd zamówienia (moduł 10) – pasek z tytułem i ✕ u góry, podsumowanie
	// z przyciskiem u dołu (oba przyklejone), lista pomiędzy. Telefon: pełny ekran.
	$c .= "#rzd-review .dc-panel { max-width: 560px; }\n";
	$c .= "#rzd-review .rzd-rv-head { position: sticky; top: -24px; z-index: 3; display: flex; align-items: center; gap: 12px; margin: -24px -24px 12px; padding: 14px 16px 12px 24px; background: rgba({$rgb},.97); border-bottom: 1px solid {$line}; border-radius: 14px 14px 0 0; }\n";
	$c .= "#rzd-review .rzd-rv-head h3 { flex: 1; min-width: 0; margin: 0 !important; }\n";
	$c .= "#rzd-review .rzd-rv-x { flex: 0 0 36px; width: 36px; height: 36px; margin: 0; padding: 0; border: 1.5px solid {$accent} !important; border-radius: 50%; background: #fff !important; color: #2b2b2b !important; font-size: 16px; line-height: 1; cursor: pointer; display: flex; align-items: center; justify-content: center; box-shadow: none; }\n";
	$c .= $with( '#rzd-review .rzd-rv-x', array( ':hover', ':focus' ) ) . " { background: {$soft_hov} !important; }\n";
	$c .= "#rzd-review .rzd-rv-list { font-size: {$x_sz};" . $fw( 'popup_text_weight' ) . " color: {$txt}; }\n";
	$c .= "#rzd-review .rzd-rv-item { padding: 14px 0; border-bottom: 1px solid {$line}; }\n";
	$c .= "#rzd-review .rzd-rv-item:last-child { border-bottom: 0; }\n";
	$c .= "#rzd-review .rzd-rv-name { display: flex; align-items: baseline; gap: 10px; font-size: {$l_sz}; font-weight: 700; line-height: 1.3; }\n";
	$c .= "#rzd-review .rzd-rv-name span { flex: 1; min-width: 0; }\n";
	$c .= "#rzd-review .rzd-rv-price { flex: 0 0 auto; white-space: nowrap; }\n";
	// 2.26.20: kosz przy pozycji + pasek „Usunięto … Cofnij”.
	$c .= "#rzd-review .rzd-rv-del { flex: 0 0 32px; width: 32px; height: 32px; margin: -6px -4px -6px 2px; padding: 0; border: 0 !important; border-radius: 50%; background: transparent !important; color: {$muted} !important; cursor: pointer; display: inline-flex; align-items: center; justify-content: center; box-shadow: none !important; align-self: center; }\n";
	$c .= $with( '#rzd-review .rzd-rv-del', array( ':hover', ':focus' ) ) . " { color: #d63638 !important; background: " . $mix( $txt, $pbg, .10 ) . " !important; }\n";
	$c .= "#rzd-review .rzd-rv-del:disabled { opacity: .4; cursor: default; }\n";
	$c .= "#rzd-review .rzd-rv-undo { display: flex; align-items: center; justify-content: space-between; gap: 10px; margin: 0 0 12px; padding: 10px 12px; border: 1px solid {$line}; border-radius: 10px; background: " . $mix( $txt, $pbg, .08 ) . "; color: {$txt}; font-size: 14px; }\n";
	$c .= "#rzd-review .rzd-rv-undo span { flex: 1; min-width: 0; }\n";
	$c .= "#rzd-review .rzd-rv-undo-btn { flex: 0 0 auto; padding: 6px 14px; border: 1.5px solid {$accent} !important; border-radius: 8px; background: #fff !important; color: #2b2b2b !important; font: inherit; font-weight: 700; cursor: pointer; box-shadow: none !important; }\n";
	$c .= "#rzd-review img.rzd-rv-img { display: block; width: 120px; height: 120px; max-width: 100%; object-fit: cover; border-radius: 10px; margin: 8px 0; }\n";
	$c .= "#rzd-review .rzd-rv-sklad, #rzd-review .rzd-rv-mods { margin-top: 4px; color: {$muted}; line-height: 1.45; }\n";
	$c .= "#rzd-review .rzd-rv-mods { color: {$txt}; }\n";
	$c .= "#rzd-review .rzd-rv-comps { list-style: none; margin: 8px 0 0; padding: 0; }\n";
	$c .= "#rzd-review .rzd-rv-comps li { display: flex; gap: 10px; align-items: flex-start; margin: 0 0 8px; padding: 0; line-height: 1.35; }\n";
	$c .= "#rzd-review .rzd-rv-comps li::before { content: none; }\n";
	$c .= "#rzd-review .rzd-rv-comps img { flex: 0 0 48px; width: 48px; height: 48px; object-fit: cover; border-radius: 8px; margin: 0; }\n";
	$c .= "#rzd-review .rzd-rv-add { display: block; width: 100%; margin: 10px 0 0; padding: 10px 14px; border: 1.5px solid {$accent} !important; border-radius: " . min( 10, (float) $s['popup_btn_radius'] ) . "px; background: #fff !important; color: #2b2b2b !important; cursor: pointer; font-family: inherit; font-size: {$x_sz}; font-weight: 600; line-height: 1.25; text-align: center; }\n";
	$c .= $with( '#rzd-review .rzd-rv-add', array( ':hover', ':focus' ) ) . " { background: {$soft_hov} !important; }\n";
	$c .= "#rzd-review .rzd-rv-foot { position: sticky; bottom: -24px; z-index: 3; margin: 12px -24px -24px; padding: 12px 24px 16px; background: rgba({$rgb},.97); border-top: 1px solid {$line}; border-radius: 0 0 14px 14px; }\n";
	$c .= "#rzd-review .rzd-rv-sum { font-size: {$x_sz}; color: {$txt}; }\n";
	$c .= "#rzd-review .rzd-rv-sum div { display: flex; justify-content: space-between; gap: 10px; margin: 2px 0; }\n";
	$c .= "#rzd-review .rzd-rv-sum .rzd-rv-total { font-weight: 700; font-size: {$l_sz}; margin-top: 6px; }\n";
	$c .= "#rzd-review .rzd-rv-sum small { display: block; color: {$faint}; font-size: 12px; text-align: right; }\n";
	$c .= "#rzd-review .dc-actions { margin-top: 12px; }\n#rzd-review .dc-act { flex: 1 1 100%; }\n";
	$c .= "@media (max-width: 600px) { #rzd-review { padding: 0; } #rzd-review .dc-panel { max-width: none; width: 100%; height: 100%; max-height: none; border-radius: 0; } #rzd-review .rzd-rv-head { border-radius: 0; padding-top: calc(14px + env(safe-area-inset-top, 0px)); } #rzd-review .rzd-rv-foot { border-radius: 0; padding-bottom: calc(16px + env(safe-area-inset-bottom, 0px)); } }\n";

	// Okienko "Dodano do koszyka": lista pozycji
	$c .= "#kc-added .kc-added-main { font-weight: 700; color: {$txt}; font-size: 14px; }\n";
	$c .= "#kc-added ul { margin: 6px 0 0 18px; padding: 0; color: {$txt}; font-size: 14px; }\n";

	// 2.26.6: okienko modyfikacji (moduł 10) ma własny styl z ciemnym tekstem –
	// przy innym kolorze tekstu/tła okienek podmieniamy tylko kolory napisów.
	if ( '#2b2b2b' !== strtolower( $txt ) || $is_dark ) {
		$c .= "#rzd-mods .rzd-panel, #rzd-mods h3, #rzd-mods .rzd-gh { color: {$txt} !important; }\n";
		$c .= "#rzd-mods .rzd-section-desc, #rzd-mods .rzd-lock-note { color: {$muted} !important; }\n";
		$c .= "#rzd-mods .rzd-stepper-btn { border-color: {$txt} !important; color: {$txt} !important; }\n";
		$c .= "#rzd-mods .rzd-stepper-btn:hover { background: {$txt} !important; color: {$pbg} !important; }\n";
		$c .= "#rzd-mods .rzd-square.rzd-on, #rzd-mods .rzd-tap.rzd-on { border-color: {$accent} !important; }\n";
		// 2.26.14: pasek „Dopłata / Razem” (dawniej jasnoszary #f6f6f6 – na ciemnym okienku biały pas z niewidocznym tekstem).
		$c .= "#rzd-mods .rzd-summary { background: " . $mix( $txt, $pbg, .10 ) . " !important; border-color: " . $mix( $txt, $pbg, .22 ) . " !important; color: {$txt} !important; }\n";
		$c .= "#rzd-mods .rzd-section-block { border-bottom-color: " . $mix( $txt, $pbg, .22 ) . " !important; }\n";
	}
	return $c;
}

/**
 * Jednorazowa migracja: pierwsza wersja panelu miała czarne domyślne kolory
 * przycisku (#222222 / biały tekst na hoverze). Kto kiedykolwiek kliknął
 * "Zapisz" w panelu, zapisał je na stałe – i nowe, jasne domyślne (złoty
 * akcent, biały hover) nigdy się u niego nie pojawiły. Podmieniamy WYŁĄCZNIE
 * wartości identyczne ze starymi domyślnymi; wszystko, co ktoś ustawił po
 * swojemu, zostaje nietknięte. Wykonuje się raz.
 */
add_action( 'init', function () {
	if ( get_option( 'rzd_style_migrated_2131' ) ) {
		return;
	}
	$saved = get_option( 'rzd_list_style', null );
	if ( is_array( $saved ) ) {
		$old_defaults = array(
			'button_text_color'   => '#222222',
			'button_border_color' => '#222222',
			'button_hover_bg'     => '#222222',
			'button_hover_text'   => '#ffffff',
		);
		$new     = rzd_list_style_defaults();
		$changed = false;
		foreach ( $old_defaults as $key => $old ) {
			if ( isset( $saved[ $key ] ) && strtolower( $saved[ $key ] ) === $old ) {
				$saved[ $key ] = $new[ $key ];
				$changed       = true;
			}
		}
		if ( $changed ) {
			update_option( 'rzd_list_style', $saved, true );
		}
	}
	update_option( 'rzd_style_migrated_2131', '1', true );
}, 5 );

// Doklejamy PO statycznym pliku CSS (moduł 03) – ta sama kolejność ładowania
// wygrywa remisy specyficzności, więc te reguły faktycznie nadpisują plik.
add_action( 'wp_enqueue_scripts', function () {
	if ( ! wp_style_is( 'rzd-lista-zamowien', 'registered' ) && ! wp_style_is( 'rzd-lista-zamowien', 'enqueued' ) ) {
		return; // moduł 03 nie zarejestrował stylu (np. wyłączony) – nie ma do czego doklejać
	}
	// 2.26.13: CSS z panelu jako PLIK (uploads/rzd/), a nie wklejany w każdą
	// stronę – przeglądarka trzyma go w pamięci podręcznej, serwer nie składa
	// go od nowa przy każdym wyświetleniu. Nazwa pliku zawiera skrót ustawień,
	// więc po zmianie w panelu powstaje nowy plik. Gdy zapis się nie uda –
	// jak dawniej, CSS wklejony w stronę.
	$file = rzd_style_css_file();
	if ( $file ) {
		wp_enqueue_style( 'rzd-lista-custom', $file, array( 'rzd-lista-zamowien' ), null );
	} else {
		wp_add_inline_style( 'rzd-lista-zamowien', rzd_list_style_css() );
	}
}, 20 );

/**
 * Adres pliku CSS z ustawieniami „Wygląd listy” (tworzy go, gdy brakuje albo
 * ustawienia/wersja się zmieniły). '' = nie da się zapisać – użyj CSS w stronie.
 */
function rzd_style_css_file() {
	$key  = substr( md5( RZD_PLUGIN_VERSION . '|' . maybe_serialize( get_option( 'rzd_list_style', array() ) ) ), 0, 12 );
	$info = get_option( 'rzd_style_css_file', array() );
	$up   = wp_upload_dir( null, false );
	if ( ! empty( $up['error'] ) ) {
		return '';
	}
	$dir  = trailingslashit( $up['basedir'] ) . 'rzd';
	$name = 'rzd-wyglad-' . $key . '.css';
	$path = $dir . '/' . $name;
	$url  = set_url_scheme( trailingslashit( $up['baseurl'] ) . 'rzd/' . $name );
	if ( is_array( $info ) && isset( $info['key'] ) && $info['key'] === $key && file_exists( $path ) ) {
		return $url;
	}
	if ( ! wp_mkdir_p( $dir ) ) {
		return '';
	}
	$css = "/* Restauracja – Wygląd listy (wygenerowane " . gmdate( 'Y-m-d H:i' ) . ") */\n" . rzd_list_style_css();
	if ( false === @file_put_contents( $path, $css, LOCK_EX ) ) { // phpcs:ignore
		return '';
	}
	// Stare pliki (poprzednie ustawienia) usuwamy.
	foreach ( (array) glob( $dir . '/rzd-wyglad-*.css' ) as $old ) {
		if ( $old && $old !== $path ) {
			@unlink( $old ); // phpcs:ignore
		}
	}
	update_option( 'rzd_style_css_file', array( 'key' => $key ), true );
	return $url;
}

/* ============================================================
 * 3. PANEL ADMINA
 * ============================================================ */
add_action( 'admin_menu', function () {
	add_menu_page( 'Wygląd listy', 'Wygląd listy', 'manage_woocommerce', 'rzd-wyglad-listy', 'rzd_render_style_page', 'dashicons-admin-appearance', 58 );
} );

add_action( 'admin_post_rzd_save_list_style', function () {
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		wp_die( 'Brak uprawnień.' );
	}
	check_admin_referer( 'rzd_save_list_style' );

	$p        = wp_unslash( $_POST );
	$defaults = rzd_list_style_defaults();
	$s        = rzd_list_style_get(); // start od zapisanych – m_* sekcji wyłączonych zostają na później

	foreach ( rzd_list_style_fields() as $sid => $sec ) {
		foreach ( $sec[1] as $f ) {
			if ( empty( $f['k'] ) ) {
				continue;
			}
			$s = rzd_style_clean_field( $s, $f, $p, '', $defaults );
		}
		if ( isset( $sec[2] ) && false === $sec[2] ) {
			continue; // sekcja bez wersji telefonu
		}
		$on                  = empty( $p[ 'm_on_' . $sid ] ) ? 0 : 1;
		$s[ 'm_on_' . $sid ] = $on;
		if ( $on ) {
			foreach ( $sec[1] as $f ) {
				if ( ! empty( $f['k'] ) && empty( $f['shared'] ) ) {
					$s = rzd_style_clean_field( $s, $f, $p, 'm_', $defaults );
				}
			}
		}
	}
	$s['style_v'] = 5;

	update_option( 'rzd_list_style', $s, true );
	$view = ( isset( $p['rzd_view'] ) && 'mobile' === $p['rzd_view'] ) ? 'mobile' : 'desktop';
	wp_safe_redirect( add_query_arg( array( 'page' => 'rzd-wyglad-listy', 'saved' => 1, 'widok' => $view ), admin_url( 'admin.php' ) ) );
	exit;
} );

// Jedno pole z formularza → $s. $pre = '' (komputer) albo 'm_' (telefon).
// Gdy pola telefonu brak w POST, wartością zapasową jest wartość komputera.
function rzd_style_clean_field( $s, $f, $p, $pre, $defaults ) {
	$k    = $f['k'];
	$name = $pre . $k;
	$fall = ( '' === $pre ) ? ( isset( $defaults[ $k ] ) ? $defaults[ $k ] : '' ) : $s[ $k ];
	switch ( $f['t'] ) {
		case 'check':
			$s[ $name ] = empty( $p[ $name ] ) ? 0 : 1;
			break;
		case 'color':
			$s[ $name ] = ( isset( $p[ $name ] ) && preg_match( '/^#[0-9a-fA-F]{6}$/', $p[ $name ] ) ) ? $p[ $name ] : $fall;
			if ( ! empty( $f['toggle'] ) ) {
				$s[ $name . '_on' ] = empty( $p[ $name . '_on' ] ) ? 0 : 1;
			}
			break;
		case 'number':
			$s[ $name ] = ( isset( $p[ $name ] ) && '' !== $p[ $name ] && is_numeric( $p[ $name ] ) ) ? (float) $p[ $name ] : $fall;
			break;
		case 'weight':
		case 'select':
			$s[ $name ] = ( isset( $p[ $name ] ) && array_key_exists( (string) $p[ $name ], $f['o'] ) ) ? (string) $p[ $name ] : $fall;
			break;
		case 'title':
			$t          = isset( $p[ $name ] ) ? trim( sanitize_text_field( $p[ $name ] ) ) : '';
			$s[ $name ] = '' !== $t ? $t : $defaults[ $k ];
			break;
		default: // text
			$s[ $name ] = sanitize_text_field( isset( $p[ $name ] ) ? $p[ $name ] : $fall );
	}
	return $s;
}

// Jedno pole formularza. $pre = '' / 'm_'; $v = wartość do pokazania.
function rzd_style_field_html( $f, $s, $pre ) {
	$t = $f['t'];
	if ( 'note' === $t ) {
		return '<p class="description">' . esc_html( $f['l'] ) . '</p>';
	}
	if ( 'sub' === $t ) {
		return '<p class="rzd-field rzd-sub"><strong>' . esc_html( $f['l'] ) . '</strong></p>';
	}
	$k    = $f['k'];
	$name = $pre . $k;
	$val  = ( '' !== $pre && isset( $s[ $name ] ) ) ? $s[ $name ] : $s[ $k ];
	$id   = 'rzd-' . $name;
	$h    = '<p class="rzd-field">';
	switch ( $t ) {
		case 'check':
			$h .= '<label><input type="checkbox" name="' . esc_attr( $name ) . '" value="1"' . checked( ! empty( $val ), true, false ) . '> <strong>' . esc_html( $f['l'] ) . '</strong></label>';
			break;
		case 'color':
			if ( ! empty( $f['toggle'] ) ) {
				$on  = ( '' !== $pre && isset( $s[ $name . '_on' ] ) ) ? $s[ $name . '_on' ] : $s[ $k . '_on' ];
				$h  .= '<label><input type="checkbox" name="' . esc_attr( $name . '_on' ) . '" value="1"' . checked( ! empty( $on ), true, false ) . '> <strong>' . esc_html( $f['l'] ) . '</strong></label>';
				$h  .= ' <input type="color" name="' . esc_attr( $name ) . '" value="' . esc_attr( $val ) . '"> <span class="description">zaznacz, żeby nadpisać kolor z motywu</span>';
			} else {
				$h .= '<label for="' . esc_attr( $id ) . '"><strong>' . esc_html( $f['l'] ) . '</strong></label> <input id="' . esc_attr( $id ) . '" type="color" name="' . esc_attr( $name ) . '" value="' . esc_attr( $val ) . '">';
			}
			break;
		case 'number':
			$step = isset( $f['step'] ) ? $f['step'] : 1;
			$unit = isset( $f['u'] ) ? $f['u'] : 'px';
			$h   .= '<label for="' . esc_attr( $id ) . '"><strong>' . esc_html( $f['l'] ) . '</strong></label> <input id="' . esc_attr( $id ) . '" type="number" step="' . esc_attr( $step ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $val ) . '" style="width:90px;"> ' . esc_html( $unit );
			break;
		case 'weight':
		case 'select':
			$h .= '<label for="' . esc_attr( $id ) . '"><strong>' . esc_html( $f['l'] ) . '</strong></label> <select id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '">';
			foreach ( $f['o'] as $ov => $ol ) {
				$h .= '<option value="' . esc_attr( $ov ) . '"' . selected( (string) $val, (string) $ov, false ) . '>' . esc_html( $ol ) . '</option>';
			}
			$h .= '</select>';
			break;
		default: // text, title
			$h .= '<label for="' . esc_attr( $id ) . '"><strong>' . esc_html( $f['l'] ) . '</strong></label> <input id="' . esc_attr( $id ) . '" type="text" name="' . esc_attr( $name ) . '" value="' . esc_attr( $val ) . '" style="width:260px;">';
	}
	return $h . '</p>';
}

/**
 * Podgląd: osobny dokument w <iframe>, więc reguły @media działają według
 * szerokości ramki – w ramce telefonu widać dokładnie wygląd telefonu.
 */
function rzd_style_preview_doc( $s ) {
	$css_url = RZD_PLUGIN_URL . 'includes/css/lista-zamowien.css?v=' . rawurlencode( RZD_PLUGIN_VERSION . '.' . (int) @filemtime( RZD_PLUGIN_DIR . 'includes/css/lista-zamowien.css' ) );
	$fonts   = function_exists( 'rzd_fonts_url' ) ? '<link rel="stylesheet" href="' . esc_url( rzd_fonts_url() ) . '">' : '';
	$times   = '';
	foreach ( array( '08:30–09:30', '09:30–10:30', '10:30–11:30', '11:30–12:30' ) as $i => $t ) {
		$times .= '<button type="button" class="dc-time' . ( 1 === $i ? ' dc-on' : '' ) . '">' . $t . '</button>';
	}
	ob_start();
	?>
<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<?php echo $fonts; // phpcs:ignore ?>
<link rel="stylesheet" href="<?php echo esc_url( $css_url ); ?>">
<style><?php echo rzd_list_style_css(); // phpcs:ignore ?></style>
<style>
body{margin:0;padding:14px;background:#fafafa;font-family:'Lato',sans-serif}
.rzd-prev-label{font:600 12px/1.4 sans-serif;color:#777;margin:22px 0 8px;text-transform:uppercase;letter-spacing:.05em}
#dc-modal.rzd-prev-popup{position:static!important;display:flex!important;inset:auto;padding:28px 12px;border-radius:12px;background:linear-gradient(135deg,#b5532e 0%,#e8b04a 45%,#7a9e5b 70%,#3d6b8f 100%)!important}
.rzd-prev-thumb{width:100%;height:100%;background:#d9cdb8;border-radius:inherit;display:flex;align-items:center;justify-content:center;color:#8a7a5c;font-size:11px}
</style></head><body>
<div class="rl">
	<div class="rl-cat-heading">Zupy</div>
	<div class="rl2-row">
		<div class="rl-thumb"><div class="rzd-prev-thumb">zdjęcie</div></div>
		<span class="rl-name">Pomidorowa z makaronem</span>
		<div class="rl-price"><?php echo function_exists( 'wc_price' ) ? rzd_price_parts_html( 12 ) : '12,00 zł'; // phpcs:ignore ?></div>
		<div class="rl2-rest">
			<div class="rl2-allergens"><span class="rl-alergen">Gluten</span><span class="rl-alergen">Jaja</span></div>
			<details class="rl-harmono"><summary><?php echo esc_html( rzd_list_label( 'harmono' ) ); ?></summary><div class="rl-harmono-body">Pon, Śr, Pt</div></details>
			<details class="rl2-delivery"><summary><?php echo esc_html( rzd_list_label( 'delivery' ) ); ?></summary><div class="rl2-delivery-body"><strong>Pon–Pt:</strong> 08:30–09:30, 09:30–10:30</div></details>
			<div class="rl2-order"><div class="rl-buy">
				<div class="rl2-qty"><button type="button" class="rl2-qty-btn rl2-qty-minus">−</button><input type="number" value="1" readonly><button type="button" class="rl2-qty-btn rl2-qty-plus">+</button></div>
				<button type="button">Dodaj do koszyka</button>
			</div></div>
		</div>
		<div class="rl2-bottom">
			<div class="rl-short">Domowa pomidorowa z makaronem i natką pietruszki.</div>
			<details class="rl-more"><summary><?php echo esc_html( rzd_list_label( 'more' ) ); ?></summary><div>Pełny opis produktu.</div></details>
		</div>
	</div>
</div>
<div class="rzd-prev-label">Strona kategorii sklepu (motyw może coś zmienić)</div>
<?php $rzd_ph = 'data:image/svg+xml,' . rawurlencode( '<svg xmlns="http://www.w3.org/2000/svg" width="300" height="300"><rect width="300" height="300" fill="#d9cdb8"/><text x="150" y="155" font-family="sans-serif" font-size="18" fill="#8a7a5c" text-anchor="middle">zdjęcie</text></svg>' ); ?>
<div class="woocommerce"><ul class="products" style="list-style:none;margin:0;padding:0;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px">
	<?php foreach ( array( array( 'Cynamonki', 12 ), array( 'Wypiek dnia', 15 ) ) as $rzd_pp ) : ?>
	<li class="product" style="margin:0;width:auto;float:none"><a href="#" onclick="return false"><img src="<?php echo esc_attr( $rzd_ph ); ?>" alt="" style="width:100%;height:auto;display:block"><h2 class="woocommerce-loop-product__title"><?php echo esc_html( $rzd_pp[0] ); ?></h2><span class="price"><?php echo function_exists( 'wc_price' ) ? wc_price( $rzd_pp[1] ) : esc_html( $rzd_pp[1] . ',00 zł' ); // phpcs:ignore ?></span></a><a href="#" class="button" onclick="return false">Dodaj do koszyka</a></li>
	<?php endforeach; ?>
</ul></div>
<div class="rzd-prev-label">Kafle kategorii [kategorie_zamowien]</div>
<?php echo function_exists( 'rzd_kategorie_tiles_html' ) ? rzd_kategorie_tiles_html( rzd_kategorie_terms( '' ), 4 ) : ''; // phpcs:ignore ?>
<div class="rzd-prev-label">Okienko (kolorowe tło pokazuje przezroczystość)</div>
<div id="dc-modal" class="rzd-prev-popup"><div class="dc-panel">
	<h3 class="dc-title">Wybierz termin dostawy</h3>
	<p class="dc-msg">Najwcześniejszy możliwy termin jest zaznaczony. Całe zamówienie zostanie dostarczone o wybranej godzinie.</p>
	<label class="dc-field">Miejscowość dostawy<select class="dc-town"><option>Piła - miasto</option></select></label>
	<label class="dc-field">Data dostawy<select class="dc-date"><option>piątek, 2 października 2026</option></select></label>
	<div class="dc-field">Godzina dostawy<div class="dc-times"><?php echo $times; // phpcs:ignore ?></div></div>
	<div class="dc-actions">
		<div class="dc-act"><button type="button" class="dc-cancel">Anuluj</button></div>
		<div class="dc-act"><button type="button" class="dc-ok">Zatwierdź termin</button></div>
	</div>
</div></div>
</body></html>
	<?php
	return ob_get_clean();
}

function rzd_render_style_page() {
	if ( ! current_user_can( 'manage_woocommerce' ) ) {
		return;
	}
	$s    = rzd_list_style_get();
	$view = ( isset( $_GET['widok'] ) && 'mobile' === $_GET['widok'] ) ? 'mobile' : 'desktop'; // phpcs:ignore
	$doc  = rzd_style_preview_doc( $s );
	?>
	<div class="wrap rzd-style-wrap" data-view="<?php echo esc_attr( $view ); ?>">
		<h1>Wygląd listy</h1>
		<?php if ( isset( $_GET['saved'] ) ) : // phpcs:ignore ?>
			<div class="notice notice-success is-dismissible"><p>Zapisano.</p></div>
		<?php endif; ?>
		<p class="description">Lista zamówień (<code>[lista_zamowien]</code>) i okienka dla klienta. Komputer = ekran od <?php echo (int) RZD_STYLE_BREAKPOINT; ?> px szerokości, telefon = węższy. Telefon bierze ustawienia z komputera, chyba że w danej sekcji zaznaczysz „Na telefonie inaczej”.</p>

		<style>
			.rzd-style-wrap .nav-tab-wrapper { margin-bottom: 0; }
			.rzd-style-wrap .nav-tab { cursor: pointer; font-size: 15px; }
			.rzd-style-cols { display: flex; flex-wrap: wrap; gap: 24px; align-items: flex-start; margin-top: 16px; }
			.rzd-style-form { flex: 1 1 460px; min-width: 320px; }
			.rzd-style-preview { flex: 1 1 420px; min-width: 300px; position: sticky; top: 40px; }
			.rzd-style-section { background: #fff; border: 1px solid #ccd0d4; border-radius: 8px; padding: 16px; margin-bottom: 16px; }
			.rzd-style-section h2 { margin-top: 0; font-size: 15px; }
			.rzd-field { margin: 0 0 12px; }
			.rzd-field label { display: inline-flex; align-items: center; gap: 6px; margin-right: 8px; }
			.rzd-sub { margin-top: 16px; }
			.rzd-mob-toggle { display: block; padding: 8px 10px; margin: -4px 0 12px; background: #f0f6fc; border: 1px solid #c5d9ed; border-radius: 6px; font-weight: 600; }
			.rzd-mob-off .rzd-mob-fields { opacity: .45; }
			.rzd-pane[hidden], .rzd-prev[hidden] { display: none; }
			.rzd-prev-frame { background: #fff; border: 1px solid #ddd; border-radius: 8px; overflow: hidden; }
			.rzd-prev-frame iframe { display: block; border: 0; transform-origin: 0 0; }
			.rzd-prev-mobile .rzd-prev-frame { width: 390px; max-width: 100%; margin: 0 auto; border: 8px solid #222; border-radius: 26px; }
		</style>

		<h2 class="nav-tab-wrapper">
			<a class="nav-tab" data-view="desktop">🖥 Komputer (i ustawienia wspólne)</a>
			<a class="nav-tab" data-view="mobile">📱 Telefon</a>
		</h2>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="rzd_save_list_style">
			<input type="hidden" name="rzd_view" value="<?php echo esc_attr( $view ); ?>">
			<?php wp_nonce_field( 'rzd_save_list_style' ); ?>

			<div class="rzd-style-cols">
				<div class="rzd-style-form">
					<div class="rzd-pane" data-view="desktop">
						<?php foreach ( rzd_list_style_fields() as $sid => $sec ) : ?>
							<div class="rzd-style-section">
								<h2><?php echo esc_html( $sec[0] ); ?></h2>
								<?php
								foreach ( $sec[1] as $f ) {
									echo rzd_style_field_html( $f, $s, '' ); // phpcs:ignore
								}
								?>
							</div>
						<?php endforeach; ?>
					</div>

					<div class="rzd-pane" data-view="mobile">
						<?php foreach ( rzd_list_style_fields() as $sid => $sec ) : ?>
							<?php
							$own    = array_filter( $sec[1], function ( $f ) { return empty( $f['shared'] ); } );
							$has_in = (bool) rzd_style_section_keys( $sec[1] );
							if ( ! $has_in ) {
								continue;
							}
							$on = ! empty( $s[ 'm_on_' . $sid ] );
							?>
							<div class="rzd-style-section rzd-mob-section<?php echo $on ? '' : ' rzd-mob-off'; ?>">
								<h2><?php echo esc_html( $sec[0] ); ?></h2>
								<label class="rzd-mob-toggle"><input type="checkbox" class="rzd-mob-on" name="<?php echo esc_attr( 'm_on_' . $sid ); ?>" value="1" <?php checked( $on ); ?>> Na telefonie inaczej niż na komputerze</label>
								<div class="rzd-mob-fields">
									<?php
									foreach ( $own as $f ) {
										echo rzd_style_field_html( $f, $s, 'm_' ); // phpcs:ignore
									}
									if ( count( $own ) < count( $sec[1] ) ) {
										echo '<p class="description">Pozostałe pola tej sekcji są wspólne – zmienisz je w zakładce Komputer.</p>';
									}
									?>
								</div>
							</div>
						<?php endforeach; ?>
					</div>

					<button type="submit" class="button button-primary button-large">Zapisz wygląd</button>
				</div>

				<div class="rzd-style-preview">
					<h2 style="margin-top:0;">Podgląd (po zapisaniu)</h2>
					<div class="rzd-prev rzd-prev-desktop" data-view="desktop">
						<div class="rzd-prev-frame"><iframe title="Podgląd – komputer" data-w="1000" srcdoc="<?php echo esc_attr( $doc ); ?>"></iframe></div>
						<p class="description">Komputer – ekran 1000 px pomniejszony do szerokości kolumny.</p>
					</div>
					<div class="rzd-prev rzd-prev-mobile" data-view="mobile">
						<div class="rzd-prev-frame"><iframe title="Podgląd – telefon" data-w="390" srcdoc="<?php echo esc_attr( $doc ); ?>"></iframe></div>
						<p class="description" style="text-align:center;">Telefon – 390 px, dokładnie tak jak na ekranie telefonu.</p>
					</div>
					<p class="description">Podgląd pokazuje ostatnio ZAPISANE ustawienia – zapisz, żeby zobaczyć efekt.</p>
				</div>
			</div>
		</form>
	</div>
	<script>
	(function () {
		var wrap = document.querySelector('.rzd-style-wrap');
		var input = wrap.querySelector('input[name="rzd_view"]');

		function fit(frame) {
			var box = frame.parentNode, w = +frame.getAttribute('data-w');
			var avail = box.clientWidth || w, k = Math.min(1, avail / w);
			frame.style.width = w + 'px';
			var doc = frame.contentDocument;
			var h = doc && doc.documentElement ? doc.documentElement.scrollHeight : 900;
			frame.style.height = h + 'px';
			frame.style.transform = k < 1 ? 'scale(' + k + ')' : '';
			box.style.height = Math.ceil(h * k) + 'px';
		}
		function show(view) {
			wrap.setAttribute('data-view', view);
			input.value = view;
			wrap.querySelectorAll('.nav-tab').forEach(function (t) { t.classList.toggle('nav-tab-active', t.getAttribute('data-view') === view); });
			wrap.querySelectorAll('.rzd-pane, .rzd-prev').forEach(function (el) { el.hidden = el.getAttribute('data-view') !== view; });
			wrap.querySelectorAll('.rzd-prev:not([hidden]) iframe').forEach(fit);
		}
		wrap.querySelectorAll('.nav-tab').forEach(function (t) {
			t.addEventListener('click', function () { show(t.getAttribute('data-view')); });
		});
		wrap.querySelectorAll('iframe').forEach(function (f) {
			f.addEventListener('load', function () { if (!f.closest('.rzd-prev').hidden) { fit(f); } });
		});
		window.addEventListener('resize', function () { wrap.querySelectorAll('.rzd-prev:not([hidden]) iframe').forEach(fit); });

		// Sekcja telefonu bez „inaczej”: pola wyszarzone i wyłączone (nie idą
		// w zapisie – zapisane wcześniej wartości telefonu zostają na później).
		wrap.querySelectorAll('.rzd-mob-section').forEach(function (sec) {
			var cb = sec.querySelector('.rzd-mob-on');
			function sync() {
				sec.classList.toggle('rzd-mob-off', !cb.checked);
				sec.querySelectorAll('.rzd-mob-fields input, .rzd-mob-fields select').forEach(function (i) { i.disabled = !cb.checked; });
			}
			cb.addEventListener('change', sync);
			sync();
		});

		show(wrap.getAttribute('data-view'));
	})();
	</script>
	<?php
}
