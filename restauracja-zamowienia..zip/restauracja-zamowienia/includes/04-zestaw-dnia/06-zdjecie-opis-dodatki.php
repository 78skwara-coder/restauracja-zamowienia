<?php
/**
 * Moduł 04-zestaw-dnia – zdjęcie, opis i dodatki dania dnia.
 * Część modułu (pliki wczytywane po kolei – kolejność jak w dawnym jednym pliku).
 */

// 6) Podmień główne zdjęcie produktu na zdjęcie dzisiejszego dania
add_filter( 'woocommerce_single_product_image_thumbnail_html', 'rwz_override_main_image', 10, 2 );
function rwz_override_main_image( $html, $post_thumbnail_id ) {
	$product = rzd_current_product(); // obiekt produktu albo null (globalne $product bywa napisem – szablony blokowe)
	if ( ! $product ) {
		return $html;
	}

	// te same zasady co wszędzie (checkbox „Zdjęcie”, najwyżej dwa dania).
	$ids = rwz_get_display_image_ids( $product->get_id() );
	if ( empty( $ids ) ) {
		return $html; // brak dania z własnym zdjęciem – zostaje zdjęcie "Zestawu dnia"
	}

	// Dwa dania: zdjęcie dzielone (zastąpiło rząd podpisanych zdjęć `rwz-multi-images`).
	if ( count( $ids ) > 1 ) {
		$split = rwz_split_image_html( $product->get_id(), 'woocommerce_single', array( 'class' => 'wp-post-image', 'loading' => 'eager' ) );
		if ( $split ) {
			return $split;
		}
	}

	// Jedno danie (albo nie udało się złożyć pliku): pełne zdjęcie dania jak zwykłe zdjęcie produktu
	return wp_get_attachment_image( $ids[0], 'woocommerce_single', false, array( 'class' => 'wp-post-image' ) );
}

// 7) Podmień krótki opis na opis dzisiejszego dania
add_filter( 'woocommerce_short_description', 'rwz_override_short_description' );
function rwz_override_short_description( $description ) {
	$product = rzd_current_product(); // obiekt produktu albo null (globalne $product bywa napisem – szablony blokowe)
	if ( ! $product ) {
		return $description;
	}

	$active = rwz_get_active_components( $product->get_id() );
	if ( empty( $active['main'] ) ) {
		return $description;
	}

	$parts = array();
	foreach ( $active['main'] as $main_product ) {
		if ( $main_product->get_id() === $product->get_id() ) {
			continue;
		}
		$desc    = $main_product->get_short_description();
		$parts[] = $desc
			? '<strong>' . esc_html( $main_product->get_name() ) . ':</strong> ' . $desc
			: '<strong>' . esc_html( $main_product->get_name() ) . '</strong>';
	}

	if ( empty( $parts ) ) {
		return $description;
	}

	return implode( '</p><p>', $parts );
}

// 8) Pokaż dostępne dziś dodatki (np. zupę) z osobnym przyciskiem zakupu
add_action( 'woocommerce_single_product_summary', 'rwz_render_addons', 35 );
function rwz_render_addons() {
	$product = rzd_current_product(); // obiekt produktu albo null (globalne $product bywa napisem – szablony blokowe)
	if ( ! $product ) {
		return;
	}

	$active = rwz_get_active_components( $product->get_id() );
	if ( empty( $active['addon'] ) ) {
		return;
	}

	echo '<div class="rwz-addons" style="margin-top:15px;">';
	echo '<h4>' . esc_html__( 'Dodatki dostępne dziś:', 'woocommerce' ) . '</h4>';
	echo '<ul style="list-style:none; padding-left:0;">';
	foreach ( $active['addon'] as $addon ) {
		echo '<li style="margin-bottom:8px; display:flex; align-items:center; gap:8px;">';
		echo '<span>' . esc_html( $addon->get_name() ) . ' &mdash; ' . wp_kses_post( wc_price( wc_get_price_to_display( $addon ) ) ) . '</span>';
		echo do_shortcode( '[add_to_cart id="' . $addon->get_id() . '" show_price="false"]' );
		echo '</li>';
	}
	echo '</ul>';
	echo '</div>';
}

// 8b) Przy dodaniu "Zestawu dnia" do koszyka — zapisz w koszyku listę
//     WSZYSTKICH aktywnych dań głównych. "Zamrażamy" listę w tym momencie,
//     żeby to, co widać w koszyku/zamówieniu, nie zmieniło się, gdyby klient
//     trzymał produkt w koszyku do następnego terminu.
add_filter( 'woocommerce_add_cart_item_data', 'rwz_add_cart_item_data', 10, 2 );
function rwz_add_cart_item_data( $cart_item_data, $product_id ) {
	$active = rwz_get_active_components( $product_id );
	if ( empty( $active['main'] ) ) {
		return $cart_item_data;
	}

	$names = array_map(
		function ( $p ) {
			return $p->get_name();
		},
		$active['main']
	);

	$cart_item_data['rwz_components'] = $names;
	// także ID dań – kontrola koszyka (rwz_cart_sync) porównuje po ID,
	// więc poprawka literówki w nazwie dania nie wyrzuca zestawu z koszyka.
	$cart_item_data['rwz_component_ids'] = rwz_component_ids( $active['main'] );
	// Unikalny klucz — żeby WooCommerce nie łączył tej pozycji z inną,
	// dodaną w innym terminie z inną zawartością zestawu
	$cart_item_data['unique_key'] = md5( wp_json_encode( $names ) . microtime() );

	return $cart_item_data;
}

// Posortowane ID produktów (do porównania składu zestawu).
function rwz_component_ids( $products ) {
	$ids = array_map( function ( $p ) { return (int) $p->get_id(); }, array_values( (array) $products ) );
	sort( $ids );
	return $ids;
}

/**
 * czy zestaw ma w danym dniu choć jedno PRAWDZIWE danie (produkt,
 * który sam nie jest zestawem). Sam zestaw pośredni bez dania (np. „Zupa dnia”
 * bez zupy) się nie liczy. Decyzja użytkownika: zestaw bez dania na dany dzień
 * jest w tym dniu niedostępny (lista, okienko terminu, dodawanie, koszyk).
 */
function rwz_set_has_dish( $product_id, $date ) {
	$a = rwz_get_active_components( $product_id, $date );
	foreach ( (array) $a['main'] as $p ) {
		if ( (int) $p->get_id() !== (int) $product_id && ! rwz_get_slots( $p->get_id() ) ) {
			return true;
		}
	}
	return false;
}

/**
 * KONTROLA ZESTAWÓW W KOSZYKU – przy wejściu do koszyka, kasy
 * i okienka „Sprawdź zamówienie” (decyzje użytkownika):
 *  - termin dostawy koszyka minął → usuwamy ZESTAWY (zwykłe produkty zostają,
 *    klient wybiera nowy termin – komunikat modułu 06),
 *  - zestaw nie ma dania na dzień koszyka → usuwamy,
 *  - skład zestawu na ten dzień zmienił się po dodaniu (np. szefowa podmieniła
 *    danie) → usuwamy (dodatki i wybory klienta były do starego dania).
 * Zwraca listę komunikatów; $notify = true → także wc_add_notice().
 * Zmiana terminu przez KLIENTA (dc_ajax_set_slot) przelicza skład po cichu –
 * to świadomy wybór innego dnia, tej kontroli nie dotyczy.
 */
function rwz_cart_sync( $notify = true ) {
	static $done = null, $notified = false;
	if ( null !== $done ) {
		if ( $notify && ! $notified ) {
			$notified = true;
			foreach ( $done as $m ) {
				wc_add_notice( $m, 'error' );
			}
		}
		return $done;
	}
	$done = array();
	if ( ! function_exists( 'WC' ) || ! WC()->cart || WC()->cart->is_empty() || ! function_exists( 'dc_get_slot' ) ) {
		return $done;
	}
	if ( function_exists( 'dc_enabled' ) && ! dc_enabled() ) {
		return $done;
	}
	$slot = dc_get_slot();
	if ( ! $slot ) {
		return $done; // brak terminu – moduł 06 i tak każe go wybrać
	}
	// „Minął” = wyjazd w przeszłości ALBO zamknięte przyjmowanie zamówień (cutoff) –
	// w obu przypadkach klient i tak musi wybrać nowy termin.
	$expired = dc_slot_expired( $slot ) || ( function_exists( 'dc_is_cutoff_passed' ) && dc_is_cutoff_passed( $slot['date'], $slot['time'] ) );
	$day     = function_exists( 'dc_date_label' ) ? dc_date_label( $slot['date'] ) : $slot['date'];
	$gone    = array( 'expired' => array(), 'nodish' => array(), 'changed' => array() );

	foreach ( WC()->cart->get_cart() as $key => $it ) {
		$pid = (int) $it['product_id'];
		if ( ! isset( $it['rwz_components'] ) && ! rwz_get_slots( $pid ) ) {
			continue; // nie zestaw
		}
		$name = get_the_title( $pid );
		if ( $expired ) {
			$why = 'expired';
		} elseif ( ! rwz_set_has_dish( $pid, $slot['date'] ) ) {
			$why = 'nodish';
		} else {
			$active = rwz_get_active_components( $pid, $slot['date'] );
			if ( isset( $it['rwz_component_ids'] ) ) {
				$same = rwz_component_ids( $active['main'] ) === array_map( 'intval', (array) $it['rwz_component_ids'] );
			} else { // pozycja sprzed 2.26.23 – tylko nazwy
				$now  = array_map( function ( $p ) { return $p->get_name(); }, $active['main'] );
				$old  = array_map( 'strval', (array) ( isset( $it['rwz_components'] ) ? $it['rwz_components'] : array() ) );
				sort( $now );
				sort( $old );
				$same = $now === $old;
			}
			if ( $same ) {
				continue;
			}
			$why = 'changed';
		}
		WC()->cart->remove_cart_item( $key );
		$gone[ $why ][] = '„' . $name . '”';
	}

	$gone = array_map( 'array_unique', $gone ); // ten sam zestaw dwa razy w koszyku – raz w komunikacie
	if ( $gone['expired'] ) {
		$done[] = sprintf( 'Termin dostawy %1$s już minął albo zamknęliśmy przyjmowanie zamówień na niego. Usunęliśmy z koszyka: %2$s – skład zestawu zależy od dnia dostawy. Wybierz nowy termin i dodaj zestaw ponownie.', function_exists( 'dc_slot_label' ) ? dc_slot_label( $slot ) : $day, implode( ', ', $gone['expired'] ) );
	}
	if ( $gone['nodish'] ) {
		$done[] = sprintf( 'Na %1$s nie ma już dania w: %2$s. Usunęliśmy z koszyka.', $day, implode( ', ', $gone['nodish'] ) );
	}
	if ( $gone['changed'] ) {
		$done[] = sprintf( 'Zmienił się skład na %1$s: %2$s. Usunęliśmy z koszyka – dodaj ponownie, żeby zobaczyć nowe danie i wybrać do niego dodatki.', $day, implode( ', ', $gone['changed'] ) );
	}
	if ( $done && ( $gone['nodish'] || $gone['changed'] ) ) {
		WC()->cart->calculate_totals();
	}
	if ( $notify ) {
		$notified = true;
		foreach ( $done as $m ) {
			wc_add_notice( $m, 'error' );
		}
	}
	return $done;
}

// Koszyk i kasa (klasyczne i blokowe): przed wyświetleniem strony.
add_action( 'template_redirect', function () {
	if ( ( function_exists( 'is_cart' ) && is_cart() ) || ( function_exists( 'is_checkout' ) && is_checkout() && ! is_wc_endpoint_url( 'order-received' ) ) ) {
		rwz_cart_sync( true );
	}
}, 5 );
// Przy składaniu zamówienia (i w innych miejscach, które wołają check_cart_items) – przed kontrolą terminu (moduł 06).
add_action( 'woocommerce_check_cart_items', function () {
	rwz_cart_sync( true );
}, 5 );

// 8c) Pokaż zapisaną listę składników w koszyku i na stronie checkout
add_filter( 'woocommerce_get_item_data', 'rwz_display_cart_item_components', 10, 2 );
function rwz_display_cart_item_components( $item_data, $cart_item ) {
	if ( ! empty( $cart_item['rwz_components'] ) ) {
		$item_data[] = array(
			'key'   => __( 'W zestawie', 'woocommerce' ),
			'value' => implode( ', ', array_map( 'wc_clean', $cart_item['rwz_components'] ) ),
		);
	}
	return $item_data;
}

// 8d) Zapisz tę samą listę jako metadane pozycji ZAMÓWIENIA — widać ją
//     w panelu admina, mailach i na koncie klienta. Cena pozycji zamówienia
//     pozostaje ceną samego "Zestawu dnia".
add_action( 'woocommerce_checkout_create_order_line_item', 'rwz_add_order_line_item_meta', 10, 4 );
function rwz_add_order_line_item_meta( $item, $cart_item_key, $values, $order ) {
	if ( ! empty( $values['rwz_components'] ) ) {
		$item->add_meta_data( __( 'W zestawie', 'woocommerce' ), implode( ', ', $values['rwz_components'] ), true );
	}
	// ID dań (ukryte, prefiks „_”) – Kuchnia pokazuje skład każdego dania zestawu.
	if ( ! empty( $values['rwz_component_ids'] ) ) {
		$item->add_meta_data( '_rwz_component_ids', array_map( 'intval', (array) $values['rwz_component_ids'] ), true );
	}
}

