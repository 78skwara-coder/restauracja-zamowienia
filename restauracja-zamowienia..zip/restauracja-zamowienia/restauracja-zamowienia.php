<?php
/**
 * Plugin Name:       Restauracja – Zamówienia i Dostawy
 * Description:       System zamówień restauracji na WooCommerce: lista produktów z alergenami, zestawy dnia, kalendarz terminów dostawy, koszyk, dodatki do produktów, raporty.
 * Version:           2.32.1
 * Requires Plugins:  woocommerce
 * Text Domain:       rzd
 *
 * Moduły (includes/, ładowane w tej kolejności; duże moduły to katalogi – pliki 01-…, 02-… po kolei):
 *  00 Wspólne funkcje pomocnicze
 *  01 Alergeny                                         14 Dodatki (katalog)
 *  02 Lista zamówień [lista_zamowien]                  15 Wygląd listy
 *  03 Style listy                                      16 Aktualizacje (GitHub → WordPress)
 *  04 Zestaw dnia                                      17 Kategorie [kategorie_zamowien]
 *  05 Zestawy na liście                                18 Wzory modyfikacji
 *  06 Kalendarz terminów dostawy [wybierz_date_dostawy]  19 Kurier [kurier_dashboard]
 *  07 Koszyk                                           20 Dostawa wg miejscowości [koszty_dostawy]
 *  08 Brama dodawania do koszyka                       21 Opakowania
 *  09 Raporty                                          22 Edycja menu [edycja_produktow]
 *  10 Modyfikacje produktu                             23 Dashboard sprzedaży
 *  11 Zestawy dnia – menu                              24 Opisy produktów (edytor sekcji)
 *  12 Kuchnia [kuchnia_dashboard]                      25 Dostęp i uprawnienia (role, logowanie obsługi)
 *  13 Statusy zamówień                                 26 Konfigurator uprawnień
 *
 * Dane (meta, opcje, taksonomie, typy treści, shortcody, role) mają stałe nazwy –
 * to adresy danych żywych sklepów; zmieniać tylko z migracją.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'RZD_PLUGIN_FILE', __FILE__ );
define( 'RZD_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'RZD_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
// Wersja wtyczki – MUSI być równa „Version:” w nagłówku (pilnuje tego pakowanie).
// Stała zamiast get_file_data() – bez czytania tego pliku przy każdym wyświetleniu strony.
define( 'RZD_PLUGIN_VERSION', '2.32.1' );

// Wersja pliku z katalogu wtyczki do ?ver= (wersja + data zmiany pliku).
function rzd_asset_ver( $rel ) {
	return RZD_PLUGIN_VERSION . '.' . (int) @filemtime( RZD_PLUGIN_DIR . $rel ); // phpcs:ignore
}

/**
 * Arkusz stylów / skrypt z assets/ wstawiany W MIEJSCU dawnego <style> / <script>.
 * To samo miejsce w kodzie strony = ta sama kolejność reguł CSS i wykonania skryptów
 * (przeglądarka zapamiętuje plik, kod strony jest lżejszy).
 */
function rzd_css_tag( $rel, $id = '' ) {
	return '<link rel="stylesheet"' . ( $id ? ' id="' . esc_attr( $id ) . '"' : '' ) . ' href="' . esc_url( RZD_PLUGIN_URL . $rel . '?ver=' . rzd_asset_ver( $rel ) ) . '">';
}
function rzd_js_tag( $rel ) {
	return '<script src="' . esc_url( RZD_PLUGIN_URL . $rel . '?ver=' . rzd_asset_ver( $rel ) ) . '"></script>';
}

/**
 * WYDAJNOŚĆ: ustawienia czytane na KAŻDEJ stronie sklepu były zapisane
 * z autoload = nie – każde get_option() takiej opcji to osobne zapytanie SQL
 * przy każdym wyświetleniu strony (bez Redisa/Memcached). Raz przełączamy je
 * na autoload (WordPress wczytuje je wtedy jednym zapytaniem razem z resztą).
 */
add_action( 'init', function () {
	if ( '2' === get_option( 'rzd_perf_autoload' ) ) {
		return;
	}
	$names = array( 'dc_settings', 'rzd_list_style', 'rzd_towns', 'rzd_style_migrated_2131', 'kc_settings', 'rzd_style_css_file' );
	if ( function_exists( 'wp_set_option_autoload_values' ) ) {
		wp_set_option_autoload_values( array_fill_keys( $names, true ) );
	} else {
		foreach ( $names as $n ) {
			$v = get_option( $n, null );
			if ( null !== $v ) {
				delete_option( $n );
				add_option( $n, $v, '', 'yes' );
			}
		}
	}
	update_option( 'rzd_perf_autoload', '2', true );
}, 1 );

/**
 * WooCommerce musi być aktywny – reszta wtyczki zakłada jego obecność
 * (klasy WC_Product, WC_Order, funkcje wc_get_product() itd.).
 */
function rzd_woocommerce_missing_notice() {
	echo '<div class="notice notice-error"><p><strong>Restauracja – Zamówienia i Dostawy:</strong> ta wtyczka wymaga aktywnej wtyczki WooCommerce.</p></div>';
}

add_action( 'plugins_loaded', function () {
	if ( ! class_exists( 'WooCommerce' ) ) {
		add_action( 'admin_notices', 'rzd_woocommerce_missing_notice' );
		return;
	}

	$modules = array(
		'includes/00-wspolne.php',
		'includes/01-alergeny.php',
		'includes/02-lista-zamowien.php',
		'includes/03-style-listy.php',
		'includes/04-zestaw-dnia',
		'includes/05-zestaw-dla-listy.php',
		'includes/06-kalendarz',
		'includes/07-koszyk.php',
		'includes/08-brama-dodawania.php',
		'includes/09-raporty.php',
		'includes/10-modyfikacje',
		'includes/11-zestawy-menu.php',
		'includes/12-kuchnia',
		'includes/13-statusy.php',
		'includes/14-dodatki.php',
		'includes/15-wyglad-listy',
		'includes/16-aktualizacje.php',
		'includes/17-kategorie.php',
		'includes/18-wzory-modyfikacji.php',
		'includes/19-kurier.php',
		'includes/20-miejscowosci.php',
		'includes/21-opakowania.php',
		'includes/22-edycja-menu',
		'includes/23-dashboard.php',
		'includes/24-opisy.php',
		'includes/25-dostep.php',
		'includes/26-uprawnienia.php',
	);

	// Moduł = plik albo katalog (duże moduły): pliki katalogu wczytywane po kolei wg nazwy (01-…, 02-…).
	foreach ( $modules as $relative_path ) {
		$path = RZD_PLUGIN_DIR . $relative_path;
		if ( is_dir( $path ) ) {
			$parts = glob( $path . '/*.php' );
			sort( $parts );
			foreach ( $parts as $part ) {
				require_once $part;
			}
		} elseif ( file_exists( $path ) ) {
			require_once $path;
		}
	}
}, 20 ); // po WooCommerce (plugins_loaded priorytet 10), przed większością motywów
