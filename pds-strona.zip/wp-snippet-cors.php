<?php
/**
 * PDS: pozwala stronie www.poddobrymiskrzydlami.pl pobierać produkty i ceny
 * ze sklepu (WooCommerce Store API) na zamow.poddobrymiskrzydlami.pl.
 * Wklej jako snippet (WPCode) albo do wtyczki w instalacji na subdomenie "zamow".
 * Udostępnia tylko odczyt publicznych danych o produktach, bez koszyka ani zamówień.
 */
add_filter( 'allowed_http_origins', function ( $origins ) {
	$origins[] = 'https://www.poddobrymiskrzydlami.pl';
	$origins[] = 'https://poddobrymiskrzydlami.pl';
	return $origins;
} );

add_filter( 'rest_pre_serve_request', function ( $served, $result, $request ) {
	$origin = get_http_origin();
	if ( $origin && is_allowed_http_origin( $origin )
		&& strpos( $request->get_route(), '/wc/store/v1/products' ) === 0
		&& $request->get_method() === 'GET' ) {
		header( 'Access-Control-Allow-Origin: ' . esc_url_raw( $origin ) );
		header( 'Vary: Origin', false );
	}
	return $served;
}, 20, 3 );
